// @flow
// Configurations Required:
// Refer To Tripovo Agency Details, Site, API Providers,and Payment Databases
// Refer To Flight API Providers
// New Implementation Required:
// Feature Flag Configuration
// Language Override and Implementation
import { IncomingMessage } from 'http';
import { type Element } from 'react';

export type RouterModel = {
  path: string,
  page: string,
  patterns?: Array<string>,
  trackName?: string,
};

export type ReducerAction<PayloadType> = {
  type: string,
  payload: PayloadType,
};

// #region Validation
export type ValidationResult<T> = {
  isSuccess: boolean,
  value: T,
};

export type Validation<T> = {
  status: number,
  message: string,
  value: T,
};

export type PaxInfo = {
  adults: number,
  children: Array<number>,
};

export type ValidatedQuery = {
  validOrigin: Validation<string>,
  validDestination: Validation<string>,
  validDepartDate: Validation<string>,
  validReturnDate: Validation<string>,
  validPax: Validation<Array<PaxInfo>>,
};

export type SearchParameterQuery = {
  origin: string,
  destination: string,
  departureDate: string,
  returnDate: string,
  rooms: Array<PaxInfo>,
};

export type GetPackageQueryResponse = SearchParameterQuery & {
  currency: string,
};
// #endregion

// #region Configuration
export type Environment = {
  hotelsApi: string,
  flightsApi: string,
  segmentId: string,
  googleAnalyticsIdGoQuo?: string,
  googleAnalyticsIdClient?: string,
  clevertapId?: string,
  mixpanelId?: string,
};

export type FeatureFlags = {
  // If true, use the flight list, else will use the flight matix.
  useFlightList: boolean,
  // If true, use total price instead of per person price in hotel listing page
  useTotalPrice: boolean,
  // If true, open destination as soon as user clicks.
  // If false, user must type characters before the To field returns results
  isDestinationListOpenOnClick: boolean,
  // If true, open origin as soon as user clicks.
  // If false, user must type characters before From field returns results
  isOriginListOpenOnClick: boolean,
};

export type GeneralInfo = {
  name: string, // Shall Convert To SiteName
  logo: string, // Shall have setting for small medium and big
  favicon: string,
  primaryColor: string,
  primaryColorHover: string,
  primaryColorText: string,
  secondaryColor: string,
  secondaryColorHover: string,
  secondaryColorText: string,
  linkColor: string,
  linkColorHover: string,
  currencies: Array<string>,
  defaultCurrency: string,
  languages: Array<string>,
  defaultLanguage: string,
  backgroundImage: string,
  footerText: string,
  minBookingPeriod: number,
  maxBookingPeriod: number,
  minBookingDays: number,
  maxBookingDays: number,
  maxRooms: number,
  maxPax: number,
  email: string,
  contactNumber: string,
};

export type TrackingInfo = {
  googleAnalyticsIdGoQuo?: string,
  googleAnalyticsIdClient?: string,
  clevertapId?: string,
  mixpanelId?: string,
};

export type Config = {
  general: GeneralInfo,
  features: FeatureFlags,
  environment: Environment,
};

export type SearchQueryConfig = {
  minBookingPeriod: number,
  maxBookingPeriod: number,
  minBookingDays: number,
  maxBookingDays: number,
  maxRooms: number,
  maxPax: number,
};
// #endregion

// #region common styles props
export type LoadingStyles = {
  loadingState?: boolean,
  textLoading?: string,
  contentLoading?: string,
  btnDisabled?: string,
};
// #endregion

// #region React Helper Type
export type StandardEventFunction = (
  e: SyntheticEvent<HTMLElement>,
  styleClass: string,
  isDisabled?: boolean,
) => void;
// #endregion

// #region API Models: Common
export type ContactDetail = {
  name: string,
  email: string,
  contactNumber: string,
};

export type FlightAirportDetails = {
  airportCode: string,
  airportName: string,
  date: string, // TODO: change to dateString
  time: string, // TODO: change to timeString
};

export type LegItem = {
  airlineCodes: string,
  airlineName: string,
  flightNumber: string,
  aircraftModel: string,
  cabinClassCode: string,
  cabinClassName: string,
  baggageWeight: number,
  duration: number, // TODO: Change to durationMin
  transitDuration: number,
  departure: FlightAirportDetails,
  arrival: FlightAirportDetails,
};

export type FlightItem = {
  flightId: string,
  airlineCodes: string[],
  duration: number, // TODO: Change to durationMin
  departure: FlightAirportDetails,
  arrival: FlightAirportDetails,
  legDetails: Array<LegItem>,
  hotelNights: number,
  price: {
    additionalPerPerson: number,
    additionalPerPackage: number,
  },
};

export type FlightSummary = {
  departFlight?: ?FlightItem | empty,
  returnFlight?: ?FlightItem | empty,
};

export type SidebarFlightProps = {
  flightSummary: FlightSummary,
  toggleLegInfo: Function,
  showLegInfo: boolean,
};

export type HotelPrice = {
  perPerson: {
    price: number,
    originalPrice: number,
    hotelSavings: number,
  },
  perPackage: {
    price: number,
    originalPrice: number,
    hotelSavings: number,
  },
};

export const EBoardType = {
  ROOM_ONLY: 1,
  BREAKFAST: 2,
  HALF_BOARD: 3,
  FULL_BOARD: 4,
  ALL_INCLUSIVE: 5,
  SELF_CATERING: 6,
};

export type ProgressStatus = {
  percent: number,
  loadingMsg: string,
};

// TODO: rename doB as dob and combined same type with PasssengerDetail
export type PassengerSummaryDetails = {
  dob: string,
  firstName: string,
  lastName: string,
  title: string,
  type: string,
  nationality: string,
};

// export type EBoardType = $Keys<typeof eBoardType>;

export type HotelSummary = {
  name: string,
  room: string, // TODO: change to roomName
  roomCount: number,
  // Note: EBoardType checking works but is better to use number for flexibility purpose
  boardType: number,
  checkin: string, // TODO: change to checkinDateString
  checkout: string, // TODO: change to checkoutDateString
  freeCancellationBefore: string, // TODO: suggest freeCancelBeforeDateString
  image: string, // TODO: change to image url
  changeUrl?: string,
};

export type PassengerDetails = {
  type: 'adult' | 'child' | 'infant',
  title: string,
  firstName: string,
  lastName: string,
  nationality: string,
  dob: string,
};

export type PaxCounts = {
  adult?: number,
  child?: number,
  infant?: number,
};

export type Addons = {
  transfer: number, // TODO: put transferPrice
};

export type PriceSummary = {
  currency: string,
  adult?: ?number, // TODO: put pricePerAdult
  child?: ?number, // TODO: put pricePerChild
  infant?: ?number, // TODO: put pricePerInfant
  taxesFees?: number,
  savings?: number,
  total: number,
  addons?: Addons,
  paxCounts?: PaxCounts,
};

export type SearchQuery = {
  from: string,
  to: string,
  depart: string,
  return: string,
  adultCount: number,
  childCount: number,
  infantCount: number,
  roomCount: number,
};

export type TransferDetails = {
  date: string,
  time: string,
  maxBags: number,
  maxPax: number,
  pickup: string,
  dropoff: string,
};

export type Vehicle = {
  id: string,
  title: string,
  description: string,
  image: string, // TODO: change to imageUrl
  minPax: number,
  maxPax: number,
  maxBags: number,
  direction: string,
  duration: number,
  price: {
    originalPrice: number,
    price: number,
  },
};

export type TransferItem = {
  type: string,
  image: string, // TODO: change to imageUrl
  maxPax: number,
  maxBags: number,
  duration: number,
  price: {
    originalPrice: number,
    price: number,
  },
  vehicles: Array<Vehicle>,
};

export type TransferSummary = {
  price: number,
  details: TransferItem,
};

export type TrustYouRating = {
  score: string,
  text: string,
  reviews: number, // TODO: change to reviewCount
  locationText: string,
  locationNearby: string,
};

export type AddOnSummary = {
  transferSummary: TransferSummary,
};

export type SummaryDetails = {
  priceSummary: PriceSummary,
  hotelSummary: HotelSummary,
  flightSummary: FlightSummary,
  searchQuery: SearchQuery,
  addonSummary: AddOnSummary,
};

export type SummaryDetailsRequestModel = {
  packageId?: string,
  roomId?: string,
  departureFlightId?: string,
  returnFlightId?: string,
  lang?: string,
  addons?: {
    transfers: {
      arrivalTransfer: string,
      departureTransfer: string,
    },
  },
};

export type HandleToggleGallery = (
  e: SyntheticEvent<HTMLElement>,
  isGalleryOpen: boolean,
  hotelId?: string,
) => void;

export type EHotelFilterKey = 'minPrice' | 'maxPrice' | 'stars' | 'minReview' | 'name' | 'sortBy';

export type PriceValue = {
  min: number,
  max: number,
};

export type HotelFilterUpdate = {
  key: EHotelFilterKey,
  value: string | number,
};

export type HandleChangeFilterFunction = (update: HotelFilterUpdate) => void;
// #endregion

// #region API Models: Response Received
export type PackageDetail = {
  departureDate: string, // TODO: change to depatureDateString
  returnDate: string, // TODO: change to returnDateString
  checkInDate: string, // TODO: change to checkInDateString
  checkOutDate: string, // TODO: change to checkOutDateString
  originCityName: string,
  destinationCityName: string,
  long: number,
  lat: number,
  paxCount: number,
};

export type GetHotelsSuccessResponse = {
  hotels: Array<{
    name: string,
    hotelId: string,
    url: string, // TODO: change to hotelDetailsUrl
    image: string,
    stars: number,
    location: {
      area: string,
      distanceAirport: number,
      distanceCity: number,
    },
    rating: TrustYouRating,
    price: HotelPrice,
  }>,
  filter: {
    maxPricePackage: number,
    maxPricePerson: number,
  },
  page: {
    current: number,
    max: number,
  },
  package: PackageDetail,
  isComplete: boolean,
  totalHotels: number,
};
// #endregion

// #region API Models: Fire

export type ESortType = 'reviewHigh' | 'recommended' | 'nearAirport' | 'nearCity' | 'priceLow';

export type Dispatch = (action: any) => any;

export type HotelFilterOption = {
  minPrice: number,
  maxPrice: number,
  // minStars: number,
  stars: Array<number>,
  minReview: number,
  name: string,
  sortBy: ESortType,
};

export type MapFilterParams = {
  minPrice: number,
  maxPrice: number,
  // minStars: number,
  stars: Array<number>,
  minReview: number,
  priceType: string,
  name: string,
  nwLon: number,
  nwLat: number,
  seLon: number,
  seLat: number,
  lang: string,
};

// #endregion

export type TrustYouReviewProps = {
  score: string,
  text: string,
  reviews: number,
  position?: string,
  direction?: string,
};

export type StarsRatingSingleProps = {
  stars: number,
  size: string,
};

export type HandleDetailChangeEvents = (
  event: SyntheticEvent<HTMLElement>,
  validationType: string,
) => void;

// form input field
export type InputProps = {
  name: string,
  type: string,
  id: string,
  value: any,
  handleOnChange: HandleDetailChangeEvents,
  placeholder: string,
  validationType: string,
  stateKey: string,
};

// form select field
export type SelectProps = {
  name: string,
  type: string,
  id: string,
  value: any,
  handleOnChange: HandleDetailChangeEvents,
  placeholder: string,
  validationType: string,
  stateKey: string,
  options: Object,
};

// form status
export type FieldStatus<T> = {
  status: number | boolean,
  required?: boolean,
  message?: Element<Object>, // This is FormattedMessage
  value: T,
  name?: string,
};

export type SetDOB = (
  e: SyntheticEvent<HTMLElement>,
  dob: string,
  paxIndex: number,
  validationType: string,
) => void;

// form DOB field
export type DobDropdownProps = {
  personInfo: Object,
  stateKey: string,
  setDOB: SetDOB,
  DOBStatus: {
    day: FieldStatus<number>,
    month: FieldStatus<number>,
    year: FieldStatus<number>,
  },
  title: string,
};

export type CalendarItem = Array<{
  text: number,
  value: number,
  id: number,
}>;

export type DobDropdownState = {
  DOB: {
    day: string,
    month: string,
    year: string,
  },
  daysOption: CalendarItem,
};

export type FormGroupProps = {
  validation: Object, // TODO Recheck with sathesh
  title: string,
  name: string,
  placeholderText: string,
  type: string,
  validationType: string,
};

export type HotelSummaryProps = {
  hotelSummary: Object,
};

export type AirportData = Array<{
  airportCode: string,
  airportName: string,
  cityCode: string,
  cityName: string,
  countryCode: string,
  countryName: string,
  type: string,
}>;

export type SearchParams = {
  airports: string[],
  departureTimeMin: string,
  departureTimeMax: string,
  arrivalTimeMin: string,
  arrivalTimeMax: string,
  maxPrice: string,
  maxPriceType: string,
  stops: number,
  maxDuration: number,
  sortBy: string,
  sortByAsc: boolean,
};

export type PathParams = {
  packageId: string,
  roomId?: string,
  departureFlightId?: string,
  returnFlightId?: string,
  slug: string,
};

export type MapCoordinates = {
  nwLon: number,
  nwLat: number,
  seLon: number,
  seLat: number,
};

export type Query = {
  packageId: string,
  hotelId: string,
  roomId: string,
  departureFlightId: string,
  airports: string[],
  departureTimeMin: string,
  departureTimeMax: string,
  arrivalTimeMin: string,
  arrivalTimeMax: string,
  maxPrice: string,
  maxPriceType: string,
  stops: number,
  maxDuration: number,
  sortBy: string,
  sortByAsc: boolean,
  slug: string,
};

// #region FE Application flow-types
export type PageInitPayload<T: Object> = {
  config: Config,
  locale: string,
  combinedQueryParams: T,
  selectedCurrency: string,
  cultureCode: string,
  urlLocale: string,
};

export type LoadedRequest = IncomingMessage & {
  config: Config,
  locale: string,
  params: Object,
};

export type InitialPropsCtx<T: Object> = {
  isServer: boolean,
  store: Object,
  req: LoadedRequest,
  query: Object,
  asPath?: string,
  initPayload: PageInitPayload<T>,
};

export type Context<T: Object> = {
  ctx: InitialPropsCtx<T>,
};

export type TrackPurchaseItem = {
  id?: string,
  name?: string,
  brand?: string,
  category?: string,
  variant?: string,
  quantity?: number,
  price?: string,
};
// #endregion

export type FlightLegInfo = {
  isDetailOpen: boolean,
  legDetails: LegItem[],
  isConfirmation: boolean,
  cultureCode: string,
};
