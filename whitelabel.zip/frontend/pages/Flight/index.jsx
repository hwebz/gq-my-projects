import React from 'react';
import Router from 'next/router';
import update from 'immutability-helper';
import { CSSTransition } from 'react-transition-group';
import ScrollableAnchor, { configureAnchors, goToAnchor } from 'react-scrollable-anchor';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import BreadCrumbs from 'components/BreadCrumbs/index';
import PageBase from '../PageBase';

import FlightResultHeaderContainer from './components/FlightResultHeaderContainer';
import FlightSortBar from './components/FlightSortBar';
import FlightResults from './components/FlightResults';
import SelectedFlight from './components/SelectedFlight';
import MobileFlightBar from './components/MobileFlightBar';
import DockedFooter from '../../components/DockedFooter';
import {
  getSortFlightsRequest, getFilterFlightsRequest, getFlightsRequest,
} from '../../store-app/modules/flights/actions';
import { FILTER_TYPES } from './components/FlightFilters';

import {
  getDepartureFlights,
  getReturnFlights,
  getPriceSummary,
  getFlightFetchStatus,
  getDepartureFilters,
  getReturnFilters,
} from '../../store-app/modules/flights/selectors';

import { getPackageSummaryDetails } from '../../store-app/modules/package/selectors';

import { getPackageSummary } from '../../store-app/modules/package/actions';

import { hasMissingQuery } from '../../react-next/utils/query-string';
import { isEmptyOrZero } from '../../react-next/utils/validation-utils';
import { hourToString } from '../../react-next/utils/time-utils';
import { getUseTotalPrice } from '../../services/sagas/global-selectors';

import './Flight.scss';
import HotelSummaryContainer from './components/HotelSummaryContainer';

// @flow
import {
  type FlightsProps,
  type FlightsQuery,
  type FlightQueryParam,
  type FlightsState,
  type Context,
  type FlightItem,
  type EFlightToggleType,
} from './types';

const track = require('../../react-next/utils/track-utils');

class Flight extends React.Component<FlightsProps, FlightsState> {
  constructor(props: FlightsProps) {
    super(props);
    const { departureFilters, isUseTotalPrice } = props;
    this.filtersRef = React.createRef();
    this.state = {
      selectedDepartureFlight: null,
      // selectedReturnFlight: null,
      selectedFilters: {
        airports: {
          departure: [],
          arrival: [],
        },
        price: isUseTotalPrice
          ? departureFilters.priceBound.maxPricePerPackage
          : departureFilters.priceBound.maxPricePerPerson,
        time: departureFilters.time,
        durationStop: departureFilters.durationStop,
      },
      selectedSorts: {
        sortBy: null,
        sortByAsc: null,
      },
      openItem: '',
      isPreselectAirports: false,
    };

    this.onSort = this.onSort.bind(this);
    this.onSelectDepartureFlight = this.onSelectDepartureFlight.bind(this);
    this.onChangeDepartureFlight = this.onChangeDepartureFlight.bind(this);
    this.onSelectReturnFlight = this.onSelectReturnFlight.bind(this);
    this.onFilter = this.onFilter.bind(this);
    this.loadFlights = this.loadFlights.bind(this);
    this.onResetFilters = this.onResetFilters.bind(this);
    this.onToggleMobileItem = this.onToggleMobileItem.bind(this);
  }

  componentDidMount() {
    this.loadFlights();
    const { dispatch, combinedQueryParams, cultureCode } = this.props;
    const hasQueryError = hasMissingQuery(combinedQueryParams, ['packageId', 'room']);
    if (!hasQueryError) {
      const summaryDetailsRequestModel: SummaryDetailsRequestModel = {
        packageId: combinedQueryParams.packageId,
        roomId: combinedQueryParams.room,
        lang: cultureCode,
      };
      dispatch(getPackageSummary(summaryDetailsRequestModel));
    }
  }

  /*/
  componentDidUpdate(prevProps: FlightsProps  ) {
    const { dispatch, combinedQueryParams, selectedCurrency } = this.props;
    if (
      selectedCurrency !== prevProps.selectedCurrency
      || prevProps.flightsQuery !== flightsQuery
    ) {
      dispatch({
        type: actionTypes.GET_FLIGHTS_PAGE_REQUEST,
        payload: { flightsQuery, isClient: true },
      });
    }
  }
  /*/

  onSort(type: string, sortByAsc: boolean): void {
    const { dispatch } = this.props;
    const { selectedSorts } = this.state;
    const updatedSelectedSorts = update(selectedSorts, {
      $merge: { sortBy: type, sortByAsc },
    });
    this.setState({ selectedSorts: updatedSelectedSorts }, () => {
      dispatch(getSortFlightsRequest(this.buildFlightsQuery()));
    });
  }

  onSelectDepartureFlight(flight: FlightItem): void {
    this.setState({
      selectedDepartureFlight: flight,
      collapseSelectedFlight: true,
      fadeIn: true,
    }, () => {
      this.loadFlights();
    });
    // Smooth scroll to anchor
    goToAnchor('departure', true);
    const { router } = this.props;
    track.event(
      router.pathname,
      'FLIGHT Selected departure flight',
      flight.flightId,
      {
        flightId: flight.flightId,
      },
    );
    configureAnchors({ offset: -5, scrollDuration: 300 });
  }

  onChangeDepartureFlight(): void {
    this.setState({
      fadeIn: true,
    });
    this.setState({
      collapseSelectedFlight: false,
    });
    setTimeout(() => {
      this.setState({
        selectedDepartureFlight: null,
      }, () => {
        this.onResetFilters();
      });
    }, 200);
  }

  onSelectReturnFlight(flight: FlightItem): void {
    const { selectedDepartureFlight } = this.state;
    const { combinedQueryParams, urlLocale, router } = this.props;
    track.event(
      router.pathname,
      'FLIGHT Selected return flight',
      flight.flightId,
      {
        flightId: flight.flightId,
      },
    );
    Router.push(
      `/Summary?packageId=${combinedQueryParams.packageId}&room=${
        combinedQueryParams.room
      }&outbound=${selectedDepartureFlight.flightId}&inbound=${flight.flightId}`,
      `${urlLocale}/summary/${combinedQueryParams.packageId}?room=${
        combinedQueryParams.room
      }&outbound=${selectedDepartureFlight.flightId}&inbound=${flight.flightId}`,
    ).then(() => window.scrollTo(0, 0));
  }

  onFilter(type: FILTER_TYPES, value: any, isSkipRequest: boolean = false): void {
    const { dispatch } = this.props;
    const { selectedFilters } = this.state;
    const mergedFilters = update(selectedFilters, { $merge: { [type]: value } });
    this.setState({
      selectedFilters: mergedFilters,
    }, () => {
      if (!isSkipRequest) {
        dispatch(getFilterFlightsRequest(this.buildFlightsQuery()));
      }
    });
    this.setState({
      fadeIn: true,
    });
  }

  onResetFilters(): void {
    this.filtersRef.resetFilters();
  }

  onToggleMobileItem(item: EFlightToggleType, isDisabled: boolean): void {
    if (!isDisabled) {
      const { openItem } = this.state;
      const newOpenItem = openItem === item ? '' : item;
      this.setState({
        openItem: newOpenItem,
      });
    }
  }

  static async getInitialProps({ ctx }: Context<FlightQueryParam>) {
    const {
      initPayload: { combinedQueryParams, cultureCode },
    } = ctx;
    const hasQueryError = hasMissingQuery(combinedQueryParams, ['packageId', 'room']);
    if (!hasQueryError) {
      const summaryDetailsRequestModel: SummaryDetailsRequestModel = {
        packageId: combinedQueryParams.packageId,
        roomId: combinedQueryParams.room,
        lang: cultureCode,
      };

      const flightsQuery: Query = {
        packageId: combinedQueryParams.packageId,
        roomId: combinedQueryParams.room,
      };
      return { hasQueryError, summaryDetailsRequestModel, flightsQuery };
    }
    return { hasQueryError };
  }

  loadFlights(): void {
    const { dispatch, flightsQuery } = this.props;
    const { selectedDepartureFlight } = this.state;
    const departureFlightId = selectedDepartureFlight ? selectedDepartureFlight.flightId : null;
    this.setState({
      fadeIn: true,
      isPreselectAirports: true,
    }, () => {
      dispatch(getFlightsRequest({ departureFlightId, ...flightsQuery }));
    });
  }

  buildFlightsQuery(): FlightsQuery {
    const { isUseTotalPrice, flightsQuery } = this.props;
    const { selectedFilters, selectedSorts, selectedDepartureFlight } = this.state;
    const { sortBy, sortByAsc } = selectedSorts;
    const { time, price, durationStop } = selectedFilters;
    let airports;
    const { departure, arrival } = selectedFilters.airports;
    if (!isEmptyOrZero(departure) || !isEmptyOrZero(arrival)) {
      airports = [...departure, ...arrival];
    }
    const departureFlightId = selectedDepartureFlight ? selectedDepartureFlight.flightId : null;
    const newFlightsQuery = update(
      { ...flightsQuery },
      {
        $merge: {
          departureFlightId,
          sortBy,
          sortByAsc,
          airports,
          departureTimeMin: hourToString(time.departure.min),
          departureTimeMax: hourToString(time.departure.max),
          arrivalTimeMin: hourToString(time.arrival.min),
          arrivalTimeMax: hourToString(time.arrival.max),
          maxAdditionalPrice: price.max,
          maxAdditionalPriceType: isUseTotalPrice ? 'package' : 'person',
          stops: durationStop.stop,
          maxDuration: durationStop.duration,
        },
      },
    );
    return newFlightsQuery;
  }

  render() {
    const {
      departureFlights,
      returnFlights,
      packageSummary,
      isFetching,
      router,
      config,
      defaultConfig,
      departureFilters,
      returnFilters,
    } = this.props;
    const { searchQuery } = packageSummary;
    const departDate = searchQuery ? searchQuery.depart : '';
    const returnDate = searchQuery ? searchQuery.return : '';
    const {
      selectedDepartureFlight,
      openItem,
      collapseSelectedFlight,
      fadeIn,
      isPreselectAirports,
    } = this.state;
    if (!isFetching) {
      if (selectedDepartureFlight === null) {
        track.page(
          '/Flight',
          defaultConfig.environment,
          {
            Origin: searchQuery ? searchQuery.from : '',
            Destination: searchQuery ? searchQuery.to : '',
            HasDepartureFlightFound: (departureFlights.length > 0),
            DepartureFlightsFound: departureFlights.length,
          },
        );
      }
      router.prefetch('/Summary');
    }

    return (
      <div>
        <FormattedMessage id="Flight.title" defaultMessage="Your Flights">
          {title => (
            <Helmet>
              <title>
                {`${title} | ${config.general.name}`}
              </title>
            </Helmet>
          )}
        </FormattedMessage>

        <BreadCrumbs currentPage={3} />
        <div className="container visible-md">
          <HotelSummaryContainer
            MainView={HotelSummaryContainer}
            isLoading={isFetching}
            isSummary
            router={router}
          />
        </div>

        <MobileFlightBar handleOpenMobileItem={this.onToggleMobileItem} isFetching={isFetching} />

        {/* Display when a departure flight is selected */}
        {selectedDepartureFlight && (
          <ScrollableAnchor id="departure">
            <div>
              <CSSTransition
                in={collapseSelectedFlight}
                timeout={400}
                classNames="slide"
                unmountOnExit
              >
                <SelectedFlight
                  flightItem={selectedDepartureFlight}
                  onSelectFlight={this.onSelectReturnFlight}
                  onChangeDepartureFlight={this.onChangeDepartureFlight}
                />
              </CSSTransition>
            </div>
          </ScrollableAnchor>
        )}
        <FlightResultHeaderContainer
          title={selectedDepartureFlight ? 'Return' : 'Departure'}
          isFetching={isFetching}
          onFilter={this.onFilter}
          loadFlights={this.loadFlights}
          isMobileOpen={openItem === 'filter'}
          onToggleMobileItem={this.onToggleMobileItem}
          router={router}
          onRef={(comp) => {
            if (comp) {
              this.filtersRef = comp;
            }
          }}
          flightDate={
            selectedDepartureFlight
              ? returnDate
              : departDate
          }
          isPreselectAirports={isPreselectAirports}
        />
        <FlightSortBar
          onSort={this.onSort}
          isFetching={isFetching}
          isMobileOpen={openItem === 'sort'}
          onToggleMobileItem={this.onToggleMobileItem}
          router={router}
          isReturnFlight={selectedDepartureFlight != null}
          departureFilters={departureFilters.airports}
          returnFilters={returnFilters.airports}
        />
        <CSSTransition
          in={fadeIn}
          timeout={300}
          classNames="flight"
          unmountOnExit={isFetching === false}
        >
          <FlightResults
            flights={selectedDepartureFlight ? returnFlights : departureFlights}
            searchQuery={searchQuery}
            onResetFilters={this.onResetFilters}
            onSelectFlight={
              selectedDepartureFlight ? this.onSelectReturnFlight : this.onSelectDepartureFlight
            }
            hotelSummary={packageSummary.hotelSummary || {}}
            currency={
              (packageSummary.priceSummary && packageSummary.priceSummary.currency)
              || config.general.defaultCurrency
            }
            isReturnFlight={selectedDepartureFlight != null}
            router={router}
          />
        </CSSTransition>
        <DockedFooter
          summary={packageSummary.priceSummary || {}}
          MainView={HotelSummaryContainer}
          isLoading={isFetching}
          isSummary
        />
      </div>
    );
  }
}

const mapStateToProps = state => ({
  isFetching: getFlightFetchStatus(state),
  departureFlights: getDepartureFlights(state),
  departureFilters: getDepartureFilters(state),
  packageSummary: getPackageSummaryDetails(state),
  priceSummary: getPriceSummary(state),
  returnFlights: getReturnFlights(state),
  returnFilters: getReturnFilters(state),
  isUseTotalPrice: getUseTotalPrice(state),
});

export default PageBase(Flight, { mapStateToProps, hasCurrencySwitcher: false });
