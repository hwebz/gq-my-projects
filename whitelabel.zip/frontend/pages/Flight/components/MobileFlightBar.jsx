import React from 'react';
import { FormattedMessage } from 'react-intl';
import { TiFilter as IconFilter } from 'react-icons/ti';
// import { IoIosMap as IconMap } from 'react-icons/io';
import { MdSort as IconSort /* MdFormatListBulleted as ListIcon */ } from 'react-icons/md';
import './MobileFlightBar.scss';
// @flow
import { type MobileFlightBarProps } from './types';

const MobileFlightBar: Function = ({ handleOpenMobileItem, isFetching }: MobileFlightBarProps) => {
  const disableBar: string = isFetching ? 'bar-disabled' : '';
  return (
    <div className={`mobile-nav-bar ${disableBar}`}>
      <div
        className="mobile-nav-bar__button btn-theme-secondary"
        onClick={() => {
          handleOpenMobileItem('sort', isFetching);
        }}
        role="presentation"
      >
        <i>
          <IconSort />
        </i>
        <span>
          <FormattedMessage id="flight.MobileFlightBar.sort" defaultMessage="Sort" />
        </span>
      </div>
      <div
        className="mobile-nav-bar__button btn-theme-secondary"
        onClick={() => {
          handleOpenMobileItem('filter', isFetching);
        }}
        role="presentation"
      >
        <i>
          <IconFilter />
        </i>
        <span>
          <FormattedMessage id="flight.MobileFlightBar.filter" defaultMessage="Filter" />
        </span>
      </div>
    </div>
  );
};
export default MobileFlightBar;
