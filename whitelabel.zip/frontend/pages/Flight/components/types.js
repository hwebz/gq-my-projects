// @flow
import { type StandardEventFunction, type PriceSummary } from 'flow-types';
import {
  type HotelSummary, type FlightItem,
  type PackageSummary, type Filters,
} from '../types';

export type EFlightFilterType = 'airport' | 'durationStop' | 'price' | 'time';
type EFlightType = 'Departure' | 'Return';

export type FlightResultTitleProps = {
  flightType: string,
  isSelected: boolean,
  flightDate: string,
  onChangeDepartureFlight: StandardEventFunction,
  cultureCode: string,
};

export type HotelSummaryProps = {
  summary: PriceSummary,
  packageSummary: PackageSummary,
  isFetching: boolean,
};

export type MobileFlightBarProps = {
  handleOpenMobileItem: StandardEventFunction,
  isFetching: boolean,
};

export type FlightNoResultProps = {
  onResetFilters: StandardEventFunction,
};

export type FlightResultsProps = {
  flights: FlightItem[],
  onSelectFlight: StandardEventFunction,
  isFetching: boolean,
  onResetFilters: StandardEventFunction,
  hotelSummary: HotelSummary,
  currency: string,
  isReturnFlight: boolean,
};

export type FlightFilterListProps = {
  departureFilters: Filters,
  returnFilters: Filters,
  isReturn: boolean,
  onFilter: Function,
  loadFlights: Function,
  isFetching: boolean,
  departureFlights: FlightItem[],
  returnFlights: FlightItem[],
  isUseTotalPrice: boolean,
};

export type FlightFilterListState = {
  isOpen: string,
  filtersActive: boolean,
};

export type FlightResultHeaderContainerProps = {
  title: EFlightType,
  isFetching: boolean,
  onFilter: Function,
  isMobileOpen: boolean,
  onToggleMobileItem: StandardEventFunction,
  flightDate: string,
};

export type FlightSortBarProps = {
  onSort: Function,
  isFetching: boolean,
  isMobileOpen: boolean,
  onToggleMobileItem: StandardEventFunction,
};

export type FlightSortBarState = {
  sorting: {
    price?: {
      sortByAsc: boolean,
    },
    departure?: {
      sortByAsc: boolean,
    },
    arrival?: {
      sortByAsc: boolean,
    },
    duration?: {
      sortByAsc: boolean,
    },
  },
};

export type SelectedFlightProps = {
  flightItem: FlightItem,
  onChangeDepartureFlight: StandardEventFunction,
};

export type AirportsFilter = {
  departure: string[],
  arrival: string[],
  codeMap: {
    [string]: string,
  },
};

export type AirportFilterProps = {
  airports: AirportsFilter,
  onFilter: Function,
  isFetching: boolean,
  isOpen: boolean,
  onToggle: Function,
  filtersActive: boolean,
  isPreselectAirports: boolean,
};
