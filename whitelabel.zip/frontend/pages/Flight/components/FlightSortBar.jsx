import React from 'react';
import { FormattedMessage } from 'react-intl';

import { MdExpandMore, MdExpandLess, MdArrowBack as IconArrowLeft } from 'react-icons/md';

import './FlightSortBar.scss';

// @flow
import { type FlightSortBarProps, type FlightSortBarState } from './types';

export const SORT_TYPE = {
  DEPARTURE: 'DepartureDate',
  ARRIVAL: 'ArrivalDate',
  DURATION: 'Duration',
  PRICE: 'Price',
};

const track = require('../../../react-next/utils/track-utils');

const SORT_ALLOW_DESC = {
  [SORT_TYPE.DEPARTURE]: true,
  [SORT_TYPE.ARRIVAL]: true,
};

class FlightSortBar extends React.Component<FlightSortBarProps, FlightSortBarState> {
  constructor(props) {
    super(props);

    this.state = {
      sorting: {
        [SORT_TYPE.PRICE]: {
          sortByAsc: true,
        },
      },
    };

    this.sort = this.sort.bind(this);
  }

  sort(type: string) {
    const {
      onSort,
      isFetching,
      onToggleMobileItem,
      isReturnFlight,
      departureFilters,
      returnFilters,
      router,
    } = this.props;
    if (!isFetching) {
      const { sorting } = this.state;
      let sortByAsc;
      if (Object.keys(sorting).indexOf(type) !== -1) {
        if (SORT_ALLOW_DESC[type]) {
          // eslint-disable-next-line no need to deconstructing here
          sortByAsc = !sorting[type].sortByAsc;
        } else {
          return; // Not continue to sort
        }
      } else {
        sortByAsc = true;
      }

      this.setState({
        sorting: {
          [type]: {
            sortByAsc,
          },
        },
      });
      onSort(type, sortByAsc);
      const flightType = isReturnFlight ? 'return' : 'departure';
      const properties = {
        sortByAsc,
        From: !isReturnFlight ? departureFilters.departure[0] : departureFilters.arrival[0],
        To: !isReturnFlight ? returnFilters.departure[0] : returnFilters.arrival[0],
      };
      track.event(
        router.pathname,
        `SORT Selected ${flightType} flight by ${type}`,
        sortByAsc,
        {
          ...properties,
        },
      );
      onToggleMobileItem('sort');
    }
  }

  render() {
    const { sorting } = this.state;
    const { isMobileOpen, onToggleMobileItem, isFetching } = this.props;
    const openClass = isMobileOpen ? 'is-open' : '';
    const fetchingClass = isFetching ? 'disabled' : '';
    return (
      <div className={`flight-sort-bar full-width-container panel-mobile ${openClass}`}>
        <div className="container no-padding-on-small">
          <div className="panel-mobile__title">
            <i>
              <IconArrowLeft onClick={() => onToggleMobileItem('sort')} />
            </i>
            <strong>
              <FormattedMessage
                id="FlightSortBar.sortBy"
                defaultMessage="Sort by"
              />
            </strong>
          </div>
          <div className={`flight-sort-bar__container ${fetchingClass}`}>
            <div className="flight-sort-bar__group">
              <div
                className={`flight-sort-bar__wrapper sort-bar-theme-secondary departure ${
                  sorting[SORT_TYPE.DEPARTURE] ? 'selected' : ''
                }`}
                role="presentation"
                onClick={() => this.sort(SORT_TYPE.DEPARTURE)}
              >
                <label
                  className={`flight-sort-bar__title ${(!sorting[SORT_TYPE.DEPARTURE]
                    || sorting[SORT_TYPE.DEPARTURE].sortByAsc)
                    && 'active'}`}
                  htmlFor="departure"
                >
                  <FormattedMessage
                    id="flights:sorting_departure_asc"
                    defaultMessage="Earliest Departure"
                  >
                    {(...content) => (
                      <span className="flight-sort-bar__title__span">
                        {content}
                      </span>
                    )}
                  </FormattedMessage>
                  <MdExpandMore size={16} className="sorting-arrow" />
                </label>
                <label
                  className={`flight-sort-bar__title ${sorting[SORT_TYPE.DEPARTURE]
                    && !sorting[SORT_TYPE.DEPARTURE].sortByAsc
                    && 'active'}`}
                  htmlFor="departure"
                >
                  <FormattedMessage
                    id="flights:sorting_departure_desc"
                    defaultMessage="Latest Departure"
                  >
                    {(...content) => (
                      <span className="flight-sort-bar__title__span">
                        {content}
                      </span>
                    )}
                  </FormattedMessage>
                  <MdExpandLess size={16} className="sorting-arrow" />
                </label>
              </div>
              <div
                className={`flight-sort-bar__wrapper sort-bar-theme-secondary duration-stops ${
                  sorting[SORT_TYPE.DURATION] ? 'selected' : ''
                }`}
                role="presentation"
                onClick={() => this.sort(SORT_TYPE.DURATION)}
              >
                <label className="flight-sort-bar__title active" htmlFor="stops">
                  <FormattedMessage id="flights:sorting_duration_asc" defaultMessage="Shortest">
                    {(...content) => (
                      <span className="flight-sort-bar__title__span">
                        {content}
                      </span>
                    )}
                  </FormattedMessage>
                </label>
              </div>
              <div
                className={`flight-sort-bar__wrapper sort-bar-theme-secondary arrival ${sorting[SORT_TYPE.ARRIVAL] ? 'selected' : ''}`}
                role="presentation"
                onClick={() => this.sort(SORT_TYPE.ARRIVAL)}
              >
                <label
                  className={`flight-sort-bar__title ${(!sorting[SORT_TYPE.ARRIVAL]
                    || sorting[SORT_TYPE.ARRIVAL].sortByAsc)
                    && 'active'}`}
                  htmlFor="arrival"
                >
                  <FormattedMessage
                    id="flights:sorting_arrival_asc"
                    defaultMessage="Earliest Arrival"
                  >
                    {(...content) => (
                      <span className="flight-sort-bar__title__span">
                        {content}
                      </span>
                    )}
                  </FormattedMessage>
                  <MdExpandMore size={16} className="sorting-arrow" />
                </label>
                <label
                  className={`flight-sort-bar__title ${sorting[SORT_TYPE.ARRIVAL]
                    && !sorting[SORT_TYPE.ARRIVAL].sortByAsc
                    && 'active'}`}
                  htmlFor="arrival"
                >
                  <FormattedMessage
                    id="flights:sorting_arrival_desc"
                    defaultMessage="Latest Arrival"
                  >
                    {(...content) => (
                      <span className="flight-sort-bar__title__span">
                        {content}
                      </span>
                    )}
                  </FormattedMessage>
                  <MdExpandMore size={16} className="sorting-arrow" />
                </label>
              </div>
            </div>
            <div
              className={`flight-sort-bar__wrapper sort-bar-theme-secondary price ${sorting[SORT_TYPE.PRICE] ? 'selected' : ''}`}
              role="presentation"
              onClick={() => this.sort(SORT_TYPE.PRICE)}
            >
              <label className="flight-sort-bar__title active" htmlFor="fare">
                <FormattedMessage id="flights:sorting_price_asc" defaultMessage="Lowest Fare">
                  {(...content) => (
                    <span className="flight-sort-bar__title__span">
                      {content}
                    </span>
                  )}
                </FormattedMessage>
              </label>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default FlightSortBar;
