import React from 'react';
import { FormattedMessage } from 'react-intl';
import { connect } from 'react-redux';
import { differenceInDays } from 'date-fns';

import { getFlightFetchStatus } from '../../../store-app/modules/flights/selectors';
import { emptyFlight } from '../../../store-app/modules/flights/constants';

import FlightItemCard from '../../../components/FlightItemCard';
import NoResults from '../../../components/NoResults';
// import LoadMoreFlight from './LoadMoreFlights';

import './FlightResults.scss';

// @flow
import { type FlightResultsProps } from './types';

function FlightResults(props: FlightResultsProps) {
  const {
    isFetching, flights, onSelectFlight, onResetFilters, hotelSummary, currency,
    isReturnFlight, router, searchQuery,
  } = props;
  const nightsCount: ?number = hotelSummary
    ? differenceInDays(hotelSummary.checkout, hotelSummary.checkin)
    : null;

  const messages = {
    noFilterResultHeader: <FormattedMessage
      id="FlightResults.noFilterResultHeader"
      defaultMessage="No Flights Match Your Filters"
    />,
    noFilterResultSubheader: <FormattedMessage
      id="FlightResults.noFilterResultSubheader"
      defaultMessage="We couldn't find any flights matching your filters."
    />,
  };

  let paxCount = 0;
  if (searchQuery) {
    paxCount = searchQuery.adultCount + searchQuery.childCount + searchQuery.infantCount;
  }

  return (
    <div className="full-width-container mob-dialog-bottom-space">
      <div className="container flight-result-container">
        <ul className="flight-result-list">
          {isFetching && (
            <React.Fragment>
              <FlightItemCard flightItem={emptyFlight} isFetching={isFetching} />
              <FlightItemCard flightItem={emptyFlight} isFetching={isFetching} />
              <FlightItemCard flightItem={emptyFlight} isFetching={isFetching} />
              <FlightItemCard flightItem={emptyFlight} isFetching={isFetching} />
              <FlightItemCard flightItem={emptyFlight} isFetching={isFetching} />
            </React.Fragment>)
          || (flights && flights.length > 0 && (
            flights.map(flight => (
              <FlightItemCard
                key={flight.flightId}
                flightItem={flight}
                onSelectFlight={onSelectFlight}
                nightsCount={nightsCount}
                currency={currency}
                isReturnFlight={isReturnFlight}
                router={router}
                hotelSummary={hotelSummary}
                popOverInfo={{
                  roomCount: searchQuery ? searchQuery.roomCount : 0,
                  paxCount,
                  nightsCount,
                  destination: searchQuery ? searchQuery.to : '',
                  origin: searchQuery ? searchQuery.from : '',
                  departureDate: searchQuery ? searchQuery.depart : '',
                  returnDate: searchQuery ? searchQuery.return : '',
                }}
              />
            ))
          )) || (
            <NoResults
              handleResetFilter={onResetFilters}
              messages={messages}
              isNoFilterResults
            />
          )}
        </ul>
        {/* <LoadMoreFlight /> */}
      </div>
    </div>
  );
}

const mapStateToProps = state => ({
  isFetching: getFlightFetchStatus(state),
});

export default connect(mapStateToProps)(FlightResults);
