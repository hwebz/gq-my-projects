import React from 'react';
import { connect } from 'react-redux';
import {
  getDepartureFilters,
  getReturnFilters,
  getDepartureFlights,
  getReturnFlights,
  getCurrency,
} from '../../../store-app/modules/flights/selectors';
import { getUseTotalPrice } from '../../../services/sagas/global-selectors';

import {
  AirportFilter, PriceFilter, TimeFilter, DurationStopFilter,
} from './FlightFilters/index';
import Backdrop from '../../../components/Common/Backdrop';

import './FlightFilters/FlightFilters.scss';

// @flow
import { type FlightFilterListProps, type FlightFilterListState, type EFlightFilterType } from './types';

const track = require('../../../react-next/utils/track-utils');

class FlightFilterList extends React.Component<FlightFilterListProps, FlightFilterListState> {
  constructor(props: FlightFilterListProps) {
    super(props);
    this.airportFilterRef = React.createRef();
    this.priceFilterRef = React.createRef();
    this.timeFilterRef = React.createRef();
    this.durationStopFilterRef = React.createRef();

    this.state = {
      isOpen: '',
      filtersActive: false,
    };
  }

  state: FlightFilterListState;

  componentDidMount() {
    const { onRef } = this.props;
    onRef(this);
  }

  componentWillUnmount() {
    const { onRef } = this.props;
    onRef(undefined);
  }

  onToggle = (type: EFlightFilterType, value: boolean): void => {
    const { isFetching } = this.props;
    if (!isFetching) {
      this.setState({
        isOpen: value ? type : '',
        filtersActive: true,
      });
      this.eventTracking(type);
    }
  }

  hideFilters = (): void => {
    this.setState({
      isOpen: '',
      filtersActive: false,
    });
  }

  resetFilters = (): void => {
    const { loadFlights } = this.props;
    this.airportFilterRef.onClearFilter();
    this.priceFilterRef.onClearFilter();
    this.timeFilterRef.onClearFilter();
    this.durationStopFilterRef.onClearFilter();
    loadFlights();
    this.hideFilters();
  }

  eventTracking(label) {
    const {
      router,
      isReturn,
      departureFilters,
      returnFilters,
      departureFlights,
      returnFlights,
    } = this.props;
    const flightType = isReturn ? 'return' : 'departure';
    const properties = {
      From:
        isReturn ? returnFilters.airports.departure[0] : departureFilters.airports.departure[0],
      To:
      isReturn ? returnFilters.airports.arrival[0] : departureFilters.airports.arrival[0],
      NumberOfAvailableFlights:
      isReturn ? returnFlights.length : departureFlights.length,
    };
    if (label === 'time') {
      properties.arrivalTimeMin = isReturn ? returnFilters.time.arrival.min
        : departureFilters.time.departure.min;
      properties.arrivalTimeMax = isReturn ? returnFilters.time.arrival.max
        : departureFilters.time.arrival.max;
    }
    console.log(this.props, label);
    track.event(
      router.pathname,
      `FILTER Selected ${flightType} flight ${label} airport}`,
      'value.value',
      {
        ...properties,
      },
    );
  }

  props: FlightFilterListProps;

  render() {
    const {
      departureFilters,
      returnFilters,
      isFetching,
      isReturn,
      onFilter,
      departureFlights,
      returnFlights,
      isUseTotalPrice,
      currency,
      isPreselectAirports,
    } = this.props;
    const { isOpen, filtersActive } = this.state;
    const filters = isReturn ? returnFilters : departureFilters;
    const flights = isReturn ? returnFlights : departureFlights;
    const {
      airports, price, time, durationStop, durationStopBound, priceBound, isMultipleStops,
    } = filters;
    return (
      <React.Fragment>
        {flights && (
          <div className="flight-filter-list">
            <AirportFilter
              airports={airports}
              onFilter={onFilter}
              isOpen={isOpen === 'airport'}
              onToggle={this.onToggle}
              onRef={(comp) => {
                if (comp) { this.airportFilterRef = comp; }
              }}
              isFetching={isFetching}
              filtersActive={filtersActive}
              isPreselectAirports={isPreselectAirports}
            />
            <PriceFilter
              onFilter={onFilter}
              priceBound={priceBound}
              price={price}
              isOpen={isOpen === 'price'}
              onToggle={this.onToggle}
              isUseTotalPrice={isUseTotalPrice}
              onRef={(comp) => {
                if (comp) { this.priceFilterRef = comp; }
              }}
              isFetching={isFetching}
              filtersActive={filtersActive}
              currency={currency}
            />
            <TimeFilter
              onFilter={onFilter}
              initTime={time}
              isOpen={isOpen === 'time'}
              onToggle={this.onToggle}
              onRef={(comp) => {
                if (comp) { this.timeFilterRef = comp; }
              }}
              isFetching={isFetching}
              filtersActive={filtersActive}
            />
            <DurationStopFilter
              onFilter={onFilter}
              durationStopBound={durationStopBound}
              durationStop={durationStop}
              isOpen={isOpen === 'durationStop'}
              onToggle={this.onToggle}
              isMultipleStops={isMultipleStops}
              onRef={(comp) => {
                if (comp) { this.durationStopFilterRef = comp; }
              }}
              isFetching={isFetching}
              filtersActive={filtersActive}
            />
          </div>
        )}
        <Backdrop isOpen={isOpen} onClick={this.hideFilters} />
      </React.Fragment>
    );
  }
}

const mapPropsToState = state => ({
  departureFilters: getDepartureFilters(state),
  returnFilters: getReturnFilters(state),
  departureFlights: getDepartureFlights(state),
  returnFlights: getReturnFlights(state),
  isUseTotalPrice: getUseTotalPrice(state),
  currency: getCurrency(state),
});

export default connect(
  mapPropsToState,
  null,
  null,
  { withRef: true },
)(FlightFilterList);
