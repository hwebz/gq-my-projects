import React, { type Element } from 'react';
import { FormattedMessage } from 'react-intl';
import DateFormat from '../../../components/DateFormat';
import type { Format } from '../../../components/DateFormat';

// @flow
import ComponentBase, { type GenericComponent } from '../../../components/ComponentBase';
import { type FlightResultTitleProps } from './types';
import './FlightResultTitle.scss';

function FlightResultTitle(props: FlightResultTitleProps) {
  const {
    flightType, isSelected, flightDate, onChangeDepartureFlight, cultureCode,
  } = props;
  let title: Element = '';

  if (flightType.toLowerCase() === 'departure') {
    title = (
      <FormattedMessage
        id="FlightResultTitle.departure"
        defaultMessage="Departure flight"
      />
    );
  } else {
    title = (
      <FormattedMessage
        id="FlightResultTitle.return"
        defaultMessage="Return flight"
      />
    );
  }

  return (
    <h1 className="flight-result-title clear">
      {title}
      <small className="sub">
        <DateFormat value={flightDate} format={('LONG': Format)} locale={`${cultureCode}`} />
        {isSelected && (
        // eslint-disable-next-line
          <a className="link-theme-color" role="presentation" onClick={onChangeDepartureFlight}>
            <FormattedMessage
              id="FlightResultTitle.change"
              defaultMessage="Change"
            />
          </a>
        )}
      </small>
    </h1>
  );
}

const injection: GenericComponent<FlightResultTitleProps> = ComponentBase;

export default injection(FlightResultTitle, { hasCultureCode: true });
