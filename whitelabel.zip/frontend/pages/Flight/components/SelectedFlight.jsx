import React from 'react';
import FlightItemCard from '../../../components/FlightItemCard';

import './SelectedFlight.scss';
import FlightResultTitle from './FlightResultTitle';

// @flow
import { type SelectedFlightProps } from './types';

const SelectedFlight: Function = (props: SelectedFlightProps) => {
  const { flightItem, onChangeDepartureFlight } = props;
  return (
    <div className="full-width-container clear selected-flight">
      <div className="container">
        <FlightResultTitle
          flightType="Departure"
          flightDate={flightItem.departure.date}
          isSelected
          onChangeDepartureFlight={onChangeDepartureFlight}
        />

        <div className="selectedFlight__wrapper">
          <FlightItemCard
            flightItem={flightItem || {}}
            isSelected
            isSummary
            toggleDetails={false}
            isDetailOpen={false}
          />
        </div>
      </div>
    </div>
  );
};

export default SelectedFlight;
