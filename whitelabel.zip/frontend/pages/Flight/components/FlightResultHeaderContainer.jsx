import React from 'react';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { MdArrowBack as IconArrowLeft } from 'react-icons/md';
import {
  getDepartureFlights,
  getReturnFlights,
} from '../../../store-app/modules/flights/selectors';

import FlightResultTitle from './FlightResultTitle';
import FlightFilterList from './FlightFilterList';

import './FlightResultHeaderContainer.scss';

// @flow
import { type FlightResultHeaderContainerProps } from './types';

class FlightResultHeaderContainer extends React.Component<FlightResultHeaderContainerProps> {
  constructor(props) {
    super(props);
    this.filtersListRef = React.createRef();
    this.resetFilters = this.resetFilters.bind(this);
  }

  componentDidMount() {
    const { onRef } = this.props;
    onRef(this);
  }

  componentWillUnmount() {
    const { onRef } = this.props;
    onRef(undefined);
  }

  resetFilters() {
    this.filtersListRef.resetFilters();
  }

  render() {
    const {
      title,
      isFetching,
      onFilter,
      loadFlights,
      isMobileOpen,
      onToggleMobileItem,
      flightDate,
      departureFlights,
      returnFlights,
      isPreselectAirports,
      router,
    } = this.props;
    const openClass = isMobileOpen ? 'is-open' : '';
    const flights = (title === 'Return') ? returnFlights : departureFlights;
    return (
      <div className="full-width-container clear">
        <div className="flight-result-header-container container">
          <FlightResultTitle flightType={title} isFetching={isFetching} flightDate={flightDate} />
          <div className={`flight-filter-container panel-mobile ${openClass}`}>
            <div className="panel-mobile__title">
              <i>
                <IconArrowLeft onClick={() => onToggleMobileItem('filter')} />
              </i>
              <strong>
                <FormattedMessage
                  id="FlightResultHeaderContainer.filter"
                  defaultMessage="Filter"
                />
              </strong>
              <span
                className="btn-apply"
                onClick={() => onToggleMobileItem('filter')}
                role="presentation"
              >
                <FormattedMessage
                  id="FlightResultHeaderContainer.apply"
                  defaultMessage="Apply"
                />
              </span>
            </div>
            {flights && (
              <React.Fragment>
                <label className="flight-filter-container__label">
                  <FormattedMessage
                    id="FlightResultHeaderContainer.filters"
                    defaultMessage="Filters"
                  />
                </label>
                <FlightFilterList
                  isReturn={title === 'Return'}
                  onFilter={onFilter}
                  loadFlights={loadFlights}
                  isFetching={isFetching}
                  router={router}
                  onRef={(comp) => {
                    if (comp) {
                      this.filtersListRef = comp;
                    }
                  }}
                  isPreselectAirports={isPreselectAirports}
                />
              </React.Fragment>
            )}
          </div>
        </div>
      </div>
    );
  }
}

const mapPropsToState = state => ({
  departureFlights: getDepartureFlights(state),
  returnFlights: getReturnFlights(state),
});

export default connect(
  mapPropsToState,
  null,
  null,
  { withRef: true },
)(FlightResultHeaderContainer);
