// possible to make it as common component
import React from 'react';
import { FormattedMessage } from 'react-intl';

export default function () {
  return (
    <div className="text-center">
      <button
        type="button"
        className="button button--lg button--bordered button--with-border-radius"
      >
        <FormattedMessage
          id="LoadMoreFlights.buttonText"
          defaultMessage="Load more flights"
        />
      </button>
    </div>
  );
}
