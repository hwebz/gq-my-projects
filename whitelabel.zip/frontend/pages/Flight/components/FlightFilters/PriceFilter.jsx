import React from 'react';
import { FormattedMessage } from 'react-intl';
import InputRange from 'react-input-range';
import { MdArrowDropDown, MdCancel } from 'react-icons/md';
import NumberFormat from '../../../../components/NumberFormat';

// @flow
import { FILTER_TYPES } from './constants';

type PriceFilterProps = {
  priceBound: {
    maxPricePerPerson: number,
    maxPricePerPackage: number,
  },
  onFilter: Function,
  onToggle: Function,
  isFetching: boolean,
  isOpen: boolean,
  isUseTotalPrice: boolean,
  filtersActive: boolean,
  currency: string,
  onRef: Function,
};

const calculateStep = (maxPrice) => {
  let step;
  if (maxPrice < 500) {
    step = 10;
  } else if (maxPrice < 10000) {
    step = 500;
  } else if (maxPrice < 100000) {
    step = 5000;
  } else if (maxPrice < 500000) {
    step = 25000;
  } else if (maxPrice < 1000000) {
    step = 50000;
  } else if (maxPrice < 10000000) {
    step = 500000;
  } else if (maxPrice <= 100000000) {
    step = 5000000;
  } else {
    step = 5000000;
  }

  return step;
};

class PriceFilter extends React.Component<PriceFilterProps> {
  constructor(props) {
    super(props);

    this.state = {
      selectedPrice: { min: 0, max: 1 },
      activeClass: '',
      isUpdatedFromClient: false,
    };

    this.onChange = this.onChange.bind(this);
    this.onClearFilter = this.onClearFilter.bind(this);
    this.onChangeComplete = this.onChangeComplete.bind(this);
    this.toggle = this.toggle.bind(this);
  }

  componentDidMount() {
    const { onRef } = this.props;
    onRef(this);
  }

  componentWillReceiveProps(nextProps) {
    const { isUpdatedFromClient } = this.state;
    const { isUseTotalPrice } = this.props;
    const { priceBound } = nextProps;
    if (!isUpdatedFromClient) {
      this.setState({
        selectedPrice: {
          min: 0,
          max: isUseTotalPrice ? priceBound.maxPricePerPackage : priceBound.maxPricePerPerson,
        },
        isUpdatedFromClient: true,
      });
    }
  }

  componentWillUnmount() {
    const { onRef } = this.props;
    onRef(undefined);
  }

  onChange(selectedPrice) {
    this.setState({
      selectedPrice: {
        min: 0,
        max: selectedPrice,
      },
    });
  }

  onClearFilter(e: SyntheticEvent<HTMLDivElement>) {
    const {
      priceBound, onFilter, onToggle, isUseTotalPrice,
    } = this.props;
    const activeClass = '';
    const selectedPrice = {
      min: 0,
      max: isUseTotalPrice ? priceBound.maxPricePerPackage : priceBound.maxPricePerPerson,
    };
    this.setState({
      activeClass,
      selectedPrice,
    });
    onFilter(FILTER_TYPES.PRICE, selectedPrice, e == null);
    onToggle('price', false);
    if (e) {
      e.stopPropagation();
    }
  }

  onChangeComplete(selectedPrice) {
    const { onFilter, priceBound, isUseTotalPrice } = this.props;
    const maxBound = isUseTotalPrice ? priceBound.maxPricePerPackage : priceBound.maxPricePerPerson;
    const price = {
      min: 0,
      max: selectedPrice,
    };
    const activeClass = selectedPrice.min !== 0
      || maxBound
        !== (isUseTotalPrice ? selectedPrice.maxPricePerPackage : selectedPrice.maxPricePerPerson)
      ? 'pills--active'
      : '';
    this.setState({
      activeClass,
    });
    onFilter(FILTER_TYPES.PRICE, price);
  }

  toggle() {
    const { onToggle, isOpen } = this.props;
    onToggle('price', !isOpen);
  }

  render() {
    const {
      selectedPrice, activeClass, isUseTotalPrice,
    } = this.state;
    const {
      isFetching, isOpen, filtersActive, currency, priceBound,
    } = this.props;
    const maxBound = isUseTotalPrice ? priceBound.maxPricePerPackage : priceBound.maxPricePerPerson;
    const step = calculateStep(maxBound); // Slider step
    const disabledClass = isFetching ? 'disabled' : '';
    const filtersActiveClass = filtersActive ? 'filters-active' : '';
    return (
      <React.Fragment>
        {priceBound && (priceBound.maxPricePerPerson > 0 || priceBound.maxPricePerPackage > 0) && (
          <div className={`flight-filter-item ${disabledClass} ${filtersActiveClass}`}>
            <div
              className={`pills text-overflow ${activeClass}`}
              onClick={this.toggle}
              role="presentation"
            >
              <MdCancel size={24} className="pills__close" onClick={this.onClearFilter} />
              <FormattedMessage id="PriceFilter.price" defaultMessage="Price" />
              <MdArrowDropDown size={16} className="icon" />
            </div>
            <div className={`flight-filter-item__list ${isOpen ? 'active' : ''}`}>
              <div className="flight-filter-item__title">
                <span>
                  <FormattedMessage id="PriceFilter.maxFlightPrice" defaultMessage="Maximum flight price" />
                </span>
              </div>
              <div className="flight-filter-item__label flight-filter-item--with-padding theme-secondary-text">
                <span>
                  <NumberFormat
                    value={selectedPrice.min}
                    currency={currency}
                  />
                </span>
                <span className="float-right">
                  <NumberFormat
                    value={selectedPrice.max}
                    currency={currency}
                  />
                </span>
              </div>
              <div className="flight-filter-item__item flight-filter-item--with-padding no-range-label">
                <InputRange
                  // formatLabel={value => `${'RM' || ''} ${value}`}
                  minValue={0}
                  maxValue={maxBound}
                  value={selectedPrice.max}
                  step={step}
                  // disabled={!(filters && !isDisabled)}
                  onChange={this.onChange}
                  onChangeComplete={this.onChangeComplete}
                />
              </div>
            </div>
          </div>
        ) || null}
      </React.Fragment>
    );
  }
}

export default PriceFilter;
