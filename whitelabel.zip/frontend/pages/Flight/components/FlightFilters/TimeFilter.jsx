import React from 'react';
import { FormattedMessage } from 'react-intl';
import InputRange from 'react-input-range';
import { MdArrowDropDown, MdCancel } from 'react-icons/md';
import update from 'immutability-helper';
import { hourToString } from '../../../../react-next/utils/time-utils';

// @flow
import { FILTER_TYPES } from './constants';

type TimeFilterProps = {
  initTime: {
    min: number,
    max: number,
  },
  onFilter: Function,
  onToggle: Function,
  isFetching: boolean,
  isOpen: boolean,
  filtersActive: boolean,
};

class TimeFilter extends React.Component<TimeFilterProps> {
  constructor(props) {
    super(props);

    const { initTime } = props;
    this.defaultMinTime = 0;
    this.defaultMaxTime = 24;
    this.state = {
      initTime: initTime
      || {
        departure: { min: this.defaultMinTime, max: this.defaultMaxTime },
        arrival: { min: this.defaultMinTime, max: this.defaultMaxTime },
      },
      selectedTime: {
        departure: { min: this.defaultMinTime, max: this.defaultMaxTime },
        arrival: { min: this.defaultMinTime, max: this.defaultMaxTime },
      },
      activeClass: '',
    };

    this.onChange = this.onChange.bind(this);
    this.onClearFilter = this.onClearFilter.bind(this);
    this.onChangeComplete = this.onChangeComplete.bind(this);
    this.toggle = this.toggle.bind(this);
  }

  componentDidMount() {
    const { onRef } = this.props;
    onRef(this);
  }

  componentWillUnmount() {
    const { onRef } = this.props;
    onRef(undefined);
  }

  onChange(type, value) {
    if (value.min !== value.max) {
      const { selectedTime } = this.state;
      const newSelectedTime = update(selectedTime, {
        $merge: {
          [type]: value,
        },
      });
      this.setState({
        selectedTime: newSelectedTime,
      });
    }
  }

  onClearFilter(e: SyntheticEvent<HTMLDivElement>) {
    const { initTime, onFilter, onToggle } = this.props;
    const activeClass = '';
    const selectedTime = initTime || { min: this.defaultMinTime, max: this.defaultMaxTime };
    this.setState({
      activeClass,
      selectedTime,
    });
    onFilter(FILTER_TYPES.TIME, selectedTime, e == null);
    onToggle('time', false);
    if (e) {
      e.stopPropagation();
    }
  }

  onChangeComplete(type, value) {
    const { onFilter } = this.props;
    const { selectedTime, initTime } = this.state;
    const activeClass = initTime[type].min !== selectedTime[type].min
      || initTime[type].max !== selectedTime[type].max
      ? 'pills--active'
      : '';
    this.setState({
      activeClass,
    });
    const newSelectedTime = update(selectedTime, {
      $merge: {
        [type]: value,
      },
    });
    onFilter(FILTER_TYPES.TIME, newSelectedTime);
  }

  toggle() {
    const { onToggle, isOpen } = this.props;
    onToggle('time', !isOpen);
  }

  render() {
    const { selectedTime, activeClass } = this.state;
    const {
      initTime, isFetching, isOpen, filtersActive,
    } = this.props;
    const disabledClass = isFetching ? 'disabled' : '';
    const filtersActiveClass = filtersActive ? 'filters-active' : '';
    return (
      <div className={`flight-filter-item ${disabledClass} ${filtersActiveClass}`}>
        <div
          className={`pills text-overflow ${activeClass}`}
          onClick={this.toggle}
          role="presentation"
        >
          <MdCancel size={24} className="pills__close" onClick={this.onClearFilter} />
          <FormattedMessage id="TimeFilter.times" defaultMessage="Times" />
          <MdArrowDropDown size={16} className="icon" />
        </div>
        <div className={`flight-filter-item__list ${isOpen ? 'active' : ''}`}>
          <div className="flight-filter-item__title">
            <span>
              <FormattedMessage id="TimeFilter.departureTime" defaultMessage="Departure time" />
            </span>
          </div>
          <div className="flight-filter-item__label flight-filter-item--with-padding theme-secondary-text">
            <span>
              {hourToString(selectedTime.departure.min)}
            </span>
            <span className="float-right">
              {hourToString(selectedTime.departure.max)}
            </span>
          </div>
          <div className="flight-filter-item__item flight-filter-item--with-padding no-range-label">
            <InputRange
              // formatLabel={value => (value === 24 ? '23:59' : `${value}:00`)}
              minValue={initTime ? initTime.departure.min : this.defaultMinTime}
              maxValue={initTime ? initTime.departure.max : this.defaultMaxTime}
              value={selectedTime.departure}
              // disabled={!(filters && !isDisabled)}
              onChange={value => this.onChange('departure', value)}
              onChangeComplete={value => this.onChangeComplete('departure', value)}
            />
          </div>
          <div className="flight-filter-item__title">
            <span>
              <FormattedMessage id="TimeFilter.arrivalTime" defaultMessage="Arrival time" />
            </span>
          </div>
          <div className="flight-filter-item__label flight-filter-item--with-padding theme-secondary-text">
            <span>
              {hourToString(selectedTime.arrival.min)}
            </span>
            <span className="float-right">
              {hourToString(selectedTime.arrival.max)}
            </span>
          </div>
          <div className="flight-filter-item__item flight-filter-item--with-padding no-range-label">
            <InputRange
              // formatLabel={value => (value === 24 ? '23:59' : `${value}:00`)}
              minValue={initTime ? initTime.arrival.min : this.defaultMinTime}
              maxValue={initTime ? initTime.arrival.max : this.defaultMaxTime}
              value={selectedTime.arrival}
              // disabled={!(filters && !isDisabled)}
              onChange={value => this.onChange('arrival', value)}
              onChangeComplete={value => this.onChangeComplete('arrival', value)}
            />
          </div>
        </div>
      </div>
    );
  }
}

export default TimeFilter;
