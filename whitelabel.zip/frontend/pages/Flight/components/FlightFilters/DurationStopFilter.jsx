import React from 'react';
import { FormattedMessage } from 'react-intl';
import { MdArrowDropDown, MdCancel } from 'react-icons/md';
import InputRange from 'react-input-range';
import update from 'immutability-helper';

// @flow
import { FILTER_TYPES } from './constants';

type DurationStopFilterProps = {
  isFetching: boolean,
  isOpen: boolean,
  onToggle: Function,
  durationStop: {
    stop: number,
    duration: {
      min: number,
      max: number,
    },
  },
  durationStopBound: {
    stop: number,
    duration: {
      min: number,
      max: number,
    },
  },
  onFilter: Function,
  isMultipleStops: boolean,
  filtersActive: boolean,
};

const calculateStep = (maxPrice) => {
  let step;
  if (maxPrice < 720) {
    step = 60;
  } else if (maxPrice < 1440) {
    step = 120;
  } else if (maxPrice < 2880) {
    step = 240;
  } else if (maxPrice <= 3600) {
    step = 300;
  } else {
    step = 360;
  }

  return step;
};

class DurationStopFilter extends React.Component<DurationStopFilterProps> {
  constructor(props) {
    super(props);

    const { durationStop, durationStopBound } = props;

    this.state = {
      selectedDurationStop: durationStop || {
        stop: 0,
        duration: 0,
      },
      durationStopBound,
      activeClass: '',
      isUpdatedFromClient: false,
    };

    this.toggle = this.toggle.bind(this);
    this.onChange = this.onChange.bind(this);
    this.onClearFilter = this.onClearFilter.bind(this);
    this.onChangeComplete = this.onChangeComplete.bind(this);
    this.selectDirectFlight = this.selectDirectFlight.bind(this);
  }

  componentDidMount() {
    const { onRef } = this.props;
    onRef(this);
  }

  componentWillReceiveProps(nextProps) {
    const { isUpdatedFromClient } = this.state;
    const { durationStop, durationStopBound } = nextProps;
    if (!isUpdatedFromClient) {
      this.setState({
        selectedDurationStop: durationStop,
        durationStopBound,
        isUpdatedFromClient: true,
      });
    }
  }

  componentWillUnmount() {
    const { onRef } = this.props;
    onRef(undefined);
  }

  onChange(selectedDuration) {
    if (selectedDuration > 0) {
      const { selectedDurationStop } = this.state;
      const newDurationStop = update(selectedDurationStop, {
        $merge: { duration: selectedDuration },
      });

      this.setState({
        selectedDurationStop: newDurationStop,
      });
    }
  }

  onClearFilter(e: SyntheticEvent<HTMLDivElement>) {
    const { onFilter, onToggle, durationStopBound } = this.props;
    const activeClass = '';
    this.setState({
      activeClass,
      selectedDurationStop: durationStopBound,
    });
    onFilter(FILTER_TYPES.DURATION_STOP, durationStopBound, e == null);
    onToggle('durationStop', false);
    if (e) {
      e.stopPropagation();
    }
  }

  onChangeComplete(selectedDuration) {
    const { onFilter, durationStopBound } = this.props;
    const { selectedDurationStop } = this.state;
    const activeClass = durationStopBound.stop !== selectedDurationStop.stop
      || Math.ceil(durationStopBound.duration / 60) * 60 !== selectedDuration
      ? 'pills--active'
      : '';
    this.setState({
      activeClass,
    });
    onFilter(FILTER_TYPES.DURATION_STOP, selectedDurationStop);
  }

  selectDirectFlight(e) {
    const { selectedDurationStop } = this.state;
    const { onFilter, durationStopBound } = this.props;
    const newDurationStop = update(selectedDurationStop, {
      $merge: { stop: e.target.checked ? 1 : 0 },
    });

    const activeClass = durationStopBound.stop !== newDurationStop.stop
      || durationStopBound.duration.min !== newDurationStop.duration.min
      || durationStopBound.duration.max !== newDurationStop.duration.max
      ? 'pills--active'
      : '';

    this.setState({
      selectedDurationStop: newDurationStop,
      activeClass,
    });

    onFilter(FILTER_TYPES.DURATION_STOP, newDurationStop);
  }

  toggle() {
    const { onToggle, isOpen } = this.props;
    onToggle('durationStop', !isOpen);
  }

  render() {
    const { activeClass, selectedDurationStop, durationStopBound } = this.state;
    const {
      isFetching, isOpen, isMultipleStops, filtersActive,
    } = this.props;
    const step = calculateStep(durationStopBound.duration);
    const disabledClass = isFetching ? 'disabled' : '';
    const filtersActiveClass = filtersActive ? 'filters-active' : '';
    return (
      <div className={`flight-filter-item ${disabledClass} ${filtersActiveClass}`}>
        <div
          className={`pills text-overflow ${activeClass}`}
          onClick={this.toggle}
          role="presentation"
        >
          <MdCancel size={24} className="pills__close" onClick={this.onClearFilter} />
          <FormattedMessage id="DurationStopFilter.durationStops" defaultMessage="Duration & Stops" />
          <MdArrowDropDown size={16} className="icon" />
        </div>
        <div className={`flight-filter-item__list ${isOpen ? 'active' : ''}`}>
          {isMultipleStops && (
            <React.Fragment>
              <div className="flight-filter-item__title">
                <span>
                  <FormattedMessage id="DurationStopFilter.stops" defaultMessage="Stops" />
                </span>
              </div>
              <label className="flight-filter-item__item" htmlFor="non-stop">
                <input
                  type="checkbox"
                  id="non-stop"
                  checked={selectedDurationStop.stop}
                  className="filter-check"
                  name="stops"
                  onChange={this.selectDirectFlight}
                />
                <FormattedMessage id="DurationStopFilter.directFlightOnly" defaultMessage="Direct Flight Only" />
              </label>
            </React.Fragment>
          )}
          <div className="flight-filter-item__title">
            <span>
              <FormattedMessage id="DurationStopFilter.MaxDuration" defaultMessage="Maximum duration" />
            </span>
          </div>
          <div className="flight-filter-item__label flight-filter-item--with-padding theme-secondary-text">
            <span>
              &nbsp;
            </span>
            <span className="float-right">
              {`${Math.ceil(selectedDurationStop.duration / 60)}h`}
            </span>
          </div>
          <div className="flight-filter-item__item flight-filter-item--with-padding  no-range-label">
            <InputRange
              formatLabel={value => `${Math.ceil(value / 60)}h`}
              minValue={0}
              maxValue={durationStopBound ? Math.ceil(durationStopBound.duration / 60) * 60 : 0}
              value={selectedDurationStop ? Math.ceil(selectedDurationStop.duration / 60) * 60 : 0}
              step={step}
              // disabled={!(filters && !isDisabled)}
              onChange={this.onChange}
              onChangeComplete={this.onChangeComplete}
            />
          </div>
        </div>
      </div>
    );
  }
}

export default DurationStopFilter;
