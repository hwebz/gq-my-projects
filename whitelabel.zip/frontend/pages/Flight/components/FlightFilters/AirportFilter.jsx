import React from 'react';
import { FormattedMessage } from 'react-intl';
import { MdArrowDropDown, MdCancel } from 'react-icons/md';
import { AirportFilterProps, AirportsFilter } from '../types';
import { FILTER_TYPES } from './constants';

// @flow
class AirportFilter extends React.Component<AirportFilterProps> {
  constructor(props) {
    super(props);
    const { airports: { departure, arrival }, isPreselectAirports } = props;
    this.state = {
      selectedAirports: {
        departure: isPreselectAirports ? [...departure] : [],
        arrival: isPreselectAirports ? [...arrival] : [],
      },
      activeClass: '',
    };

    this.onClearFilter = this.onClearFilter.bind(this);
    this.toggle = this.toggle.bind(this);
    this.editSelectedAirports = this.editSelectedAirports.bind(this);
  }

  componentDidMount() {
    const { onRef } = this.props;
    onRef(this);
  }

  componentWillUnmount() {
    const { onRef } = this.props;
    onRef(undefined);
  }

  onClearFilter(e: SyntheticEvent<HTMLDivElement>) {
    const { onFilter, onToggle, airports } = this.props;
    const selectedAirports = this.preselectAirports(airports);
    onFilter(FILTER_TYPES.AIRPORT, selectedAirports, e == null);
    onToggle('airport', false);
    if (e) {
      e.stopPropagation();
    }
  }

  preselectAirports(airports: AirportsFilter) {
    const { departure, arrival } = airports;
    const selectedAirports = {
      departure: [...departure],
      arrival: [...arrival],
    };
    this.setState({
      activeClass: '',
      selectedAirports,
    });
    return selectedAirports;
  }

  toggle() {
    const { onToggle, isOpen } = this.props;
    onToggle('airport', !isOpen);
  }

  editSelectedAirports(e, isArrival: boolean, code: string) {
    const isAdding = e.target.checked;
    const { onFilter, airports } = this.props;
    const { departure, arrival } = airports;

    const { selectedAirports } = this.state;
    if (isArrival) {
      if (isAdding) {
        selectedAirports.arrival.push(code);
      } else {
        const index = selectedAirports.arrival.indexOf(code);
        if (!selectedAirports.arrival || selectedAirports.arrival.length <= 1) {
          e.preventDefault();
          return;
        }
        if (index !== -1) {
          selectedAirports.arrival.splice(index, 1);
        }
      }
    } else if (isAdding) {
      selectedAirports.departure.push(code);
    } else {
      const index = selectedAirports.departure.indexOf(code);
      if (!selectedAirports.departure || selectedAirports.departure.length <= 1) {
        e.preventDefault();
        return;
      }
      if (index !== -1) {
        selectedAirports.departure.splice(index, 1);
      }
    }
    // Active if some but not all airports selected
    const activeClass = (selectedAirports.departure.length
        && selectedAirports.departure.length < departure.length)
      || (selectedAirports.arrival.length
        && selectedAirports.arrival.length < arrival.length) ? 'pills--active' : '';

    this.setState({
      selectedAirports,
      activeClass,
    });

    onFilter(FILTER_TYPES.AIRPORT, selectedAirports);
  }

  render() {
    const {
      airports, isFetching, isOpen, filtersActive,
    } = this.props;
    const { activeClass, selectedAirports } = this.state;
    const disabledClass = isFetching ? 'disabled' : '';
    const filtersActiveClass = filtersActive ? 'filters-active' : '';
    const emptyClass = airports && (airports.departure.length === 1 && airports.arrival.length === 1) ? 'empty' : '';
    const isSingleDeparture = airports && airports.departure.length === 1;
    const isSingleArrival = airports && airports.arrival.length === 1;
    const isSingleDepartureClass = isSingleDeparture ? 'single-airport' : '';
    const isSingleArrivalClass = isSingleArrival ? 'single-airport' : '';
    return (
      <div className={`flight-filter-item ${disabledClass} ${filtersActiveClass} ${emptyClass}`}>
        <div
          className={`pills text-overflow ${activeClass}`}
          onClick={this.toggle}
          role="presentation"
        >
          <MdCancel size={20} className="pills__close" onClick={this.onClearFilter} />
          <FormattedMessage id="AirportFilter.airports" defaultMessage="Airports" />
          <MdArrowDropDown size={16} className="icon" />
        </div>
        <div className={`flight-filter-item__list ${isOpen ? 'active' : ''}`}>
          <div className="flight-filter-item__title">
            <FormattedMessage id="AirportFilter.origin" defaultMessage="Origin airport" />
          </div>
          {airports
            && airports.departure.length >= 1
            && airports.departure.map(airportCode => (
              <label
                className={`flight-filter-item__item ${isSingleDepartureClass}`}
                htmlFor={`depart_${airportCode}`}
                key={`depart_${airportCode}`}
              >
                <input
                  type="checkbox"
                  className="filter-check"
                  checked={
                    selectedAirports.departure.indexOf(airportCode) !== -1
                    || isSingleDeparture
                  }
                  id={`depart_${airportCode}`}
                  onChange={e => this.editSelectedAirports(e, false, airportCode)}
                />
                <span className="flight-filter-item__item__label">
                  <span className="text-overflow">
                    {airports.codeMap[airportCode]}
                  </span>
                  <small>
                    {`(${airportCode})`}
                  </small>
                </span>
              </label>
            ))}
          <div className="flight-filter-item__title">
            <FormattedMessage id="AirportFilter.destination" defaultMessage="Destination airport" />
          </div>
          {airports
            && airports.arrival.length >= 1
            && airports.arrival.map(airportCode => (
              <label
                className={`flight-filter-item__item ${isSingleArrivalClass}`}
                htmlFor={`arrival_${airportCode}`}
                key={`arrival_${airportCode}`}
              >
                <input
                  type="checkbox"
                  className="filter-check"
                  checked={
                    selectedAirports.arrival.indexOf(airportCode) !== -1
                    || isSingleArrival
                  }
                  id={`arrival_${airportCode}`}
                  onChange={e => this.editSelectedAirports(e, true, airportCode)}
                />
                <span className="flight-filter-item__item__label">
                  <span className="text-overflow">
                    {airports.codeMap[airportCode]}
                  </span>
                  <small>
                    {`(${airportCode})`}
                  </small>
                </span>
              </label>
            ))}
        </div>
      </div>
    );
  }
}

export default AirportFilter;
