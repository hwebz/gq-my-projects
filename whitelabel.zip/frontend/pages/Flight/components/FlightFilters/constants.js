// TODO: Refactor to enum
// eslint-disable-next-line
export const FILTER_TYPES = {
  AIRPORT: 'airports',
  PRICE: 'price',
  DURATION_STOP: 'durationStop',
  TIME: 'time',
};
