import React from 'react';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import {
  getClientFlightFetchStatus, getPriceSummary,
} from '../../../store-app/modules/flights/selectors';

import {
  getPackageSummaryDetails,
} from '../../../store-app/modules/package/selectors';

import PackageTotalPriceSummary from '../../../components/HotelSummary/PackageTotalPriceSummary';
import HotelDetailSummary from '../../../components/HotelSummary/HotelDetailSummary';
import './HotelSummaryContainer.scss';

// @flow
import { type HotelSummaryProps } from './types';

function HotelSummary(props: HotelSummaryProps) {
  const {
    packageSummary, isFetching, flightsPriceSummary, router,
    // onClose, // unused, unsure if future needing it
  } = props;
  const { priceSummary, searchQuery } = packageSummary;
  const price = Object.keys(flightsPriceSummary).length > 0 ? flightsPriceSummary : priceSummary;
  return (
    <div className="hotel-summary-container__wrapper">
      <PackageTotalPriceSummary summary={price || {}} searchQuery={searchQuery || {}} />
      <div className="hotel-summary-container__header">
        <h3>
          <FormattedMessage
            id="HotelSummaryContainer.selectedHotels"
            defaultMessage="Selected Hotels"
          />
        </h3>
      </div>
      <HotelDetailSummary
        summary={packageSummary.hotelSummary || {}}
        isFetching={isFetching}
        router={router}
        price={price}
      />
    </div>
  );
}

const mapStateToProps = state => ({
  flightsPriceSummary: getPriceSummary(state),
  packageSummary: getPackageSummaryDetails(state),
  isFetching: getClientFlightFetchStatus(state),
});

export default connect(mapStateToProps)(HotelSummary);
