// @flow
import { type PageBaseProps } from '../PageBase/types';

import {
  type FlightItem,
  type PriceSummary,
  type HotelSummary,
  type SearchQuery,
  type FlightSummary,
} from '../../flow-types';

export * from '../../flow-types';

export type EFlightToggleType = 'filter' | 'sort';

export type Airport = {
  airportCode: string,
  airportName: string,
};

export type Filters = {
  airports?: {
    departure: string[],
    arrival: string[],
    codeMap: {
      [string]: string,
    },
  },
  price: {
    min: number,
    max: number,
  },
  durationStop: {
    stop: number,
    duration: number,
  },
  durationStopBound: {
    stop: number,
    duration: number,
  },
  priceBound: {
    maxPricePerPerson: number,
    maxPricePerPackage: number,
  },
  time: string,
  isMultipleStops: boolean,
};

export type Sorts = {
  sortBy: string,
  sortByAsc: boolean,
};

export type FlightQueryParam = {
  packageId: string,
  room: string, // TODO: this is roomId, shall we refactor this?
};

export type FlightsQuery = {
  packageId: string,
  hotelId: string,
  roomId: string,
  departureFlightId: string,
  airports: string[],
  departureTimeMin: string,
  departureTimeMax: string,
  arrivalTimeMin: string,
  arrivalTimeMax: string,
  maxPrice: string,
  maxPriceType: string,
  stops: number,
  maxDuration: number,
  sortBy: string,
  sortByAsc: boolean,
};

export type PackageSummary = {
  priceSummary: PriceSummary,
  hotelSummary: HotelSummary,
  searchQuery: SearchQuery,
  flightSummary: FlightSummary,
};

export type FlightsProps = PageBaseProps<FlightQueryParam> & {
  packageSummary: PackageSummary,
  departureFlights: FlightItem[],
  returnFlights: FlightItem[],
  // priceSummary: PriceSummary,
  isFetching: boolean,
};

export type FlightsState = {
  selectedDepartureFlight: FlightItem,
  // selectedReturnFlight: FlightItem,
  selectedFilters: Filters,
  selectedSorts: Sorts,
  openItem: string,
  collapseSelectedFlight: boolean,
  fadeIn: boolean,
  isPreselectAirports: boolean,
};

export type FlightFilterBound = {
  maxPricePerPerson: number,
  maxPricePerPackage: number,
  maxDuration: number,
  maxStops: number,
  departureAirports: Airport[],
  returnAirports: Airport[],
};
