import React from 'react';
import { FormattedMessage } from 'react-intl';

// import Link from 'next/link';
// @flow
import './SummaryAddonContainer.scss';
import { type SummaryAddonContainerProps } from '../types';
import SummaryAddonItem from './SummaryAddonItem';

function SummaryAddonContainer({
  initialLoadingStyles,
  addons,
  hotelName,
  currency,
  cultureCode,
  transfers,
  airportName,
  handleAddTransfer,
  handleRemoveTransfer,
}: SummaryAddonContainerProps) {
  const isTransferSelected: boolean = () => {
    if (addons) {
      return addons.transfer != null && addons.transfer > 0;
    }
    return false;
  };

  return (
    <div className="summary-addon">
      <div className="summary-addon__header">
        <div className="container">
          <div className="flex-wrapper flex-wrapper--half">
            <div className="flex-wrapper__left">
              <h2 className="heading heading--h2">
                <FormattedMessage
                  id="SummaryAddonContainer.addOn"
                  defaultMessage="Add to your trip"
                />
              </h2>
              <small>
                <FormattedMessage
                  id="SummaryAddonContainer.addOnSmall"
                  defaultMessage="Need a ride to/from the hotel? We got you covered!"
                />
              </small>
            </div>
            {/* eslint-disable */
            /*/
              <div className="flex-wrapper__right">
                <div className="wrapper">
                  <strong>
Super Savings!
                  </strong>
                  <small>
Up to 30% if you book now!
                  </small>
                </div>
                <i>
                  <svg width="32" height="32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M.74 19.587A.742.742 0 0 1 .1 18.478l.966-1.695L.11 15.23a.745.745 0 0 1-.018-.749l1.002-1.818-1.022-2.155a.743.743 0 0 1-.006-.625l1.032-2.285L.0945.792a.75.75 0 0 1-.011-.7l1.014-1.98L.079 1.074a.745.745 0 0 1 .03-.722A.746.746 0 0 1 .742 0h30.515c.41 0 .741.333.741.742V15.58c.003.021.098 1.695-1.013 2.883-.696.745-1.68 1.123-2.922 1.123h-3.187a.741.741 0 0 1 0-1.484h3.187c.812 0 1.43-.218 1.835-.646.673-.71.622-1.82.62-1.832V1.484H1.94l.65 1.299c.105.211.104.46-.004.67L1.582 5.415 2.575 7.2a.748.748 0 0 1 .026.667L1.558 10.18l1.038 2.188a.745.745 0 0 1-.021.676l-.977 1.775.958 1.56a.743.743 0 0 1 .012.757l-.551.967h13.418L26.963 5.478a.742.742 0 0 1 1.075-.02c.096.098 2.358 2.435 1.546 4.932-.305.935-2.842 3.41-5.826 6.318l-.007.007-.014.014-.054.052a290.3 290.3 0 0 0-3.842 3.795l1.332 1.46a5.233 5.233 0 0 1 2.37-.567 5.265 5.265 0 0 1 5.253 5.5 5.236 5.236 0 0 1-1.702 3.65A5.234 5.234 0 0 1 23.55 32a5.272 5.272 0 0 1-3.883-1.713 5.248 5.248 0 0 1-1.358-3.904 578.201 578.201 0 0 1-2.15-2.123 522.74 522.74 0 0 1-2.156 2.122 5.256 5.256 0 0 1-1.358 3.905A5.267 5.267 0 0 1 8.762 32a5.235 5.235 0 0 1-3.546-1.38 5.24 5.24 0 0 1-1.703-3.65 5.24 5.24 0 0 1 1.374-3.79 5.27 5.27 0 0 1 3.88-1.711c.834 0 1.643.196 2.37.566l1.337-1.464s-1.237-.971-1.248-.984H.74zm8.022 10.929a3.787 3.787 0 0 0 2.79-1.231 3.794 3.794 0 0 0-.237-5.344 3.766 3.766 0 0 0-2.546-.99 3.787 3.787 0 0 0-2.789 1.23 3.754 3.754 0 0 0-.986 2.722 3.766 3.766 0 0 0 1.22 2.622c.7.639 1.604.99 2.548.99zm18.554-3.613a3.75 3.75 0 0 0-.987-2.72 3.776 3.776 0 0 0-2.788-1.231c-.944 0-1.848.351-2.546.99a3.794 3.794 0 0 0-.236 5.344 3.783 3.783 0 0 0 2.788 1.23c.946 0 1.85-.353 2.547-.991a3.757 3.757 0 0 0 1.222-2.622zm-8.61-2.21a5.207 5.207 0 0 1 1.244-1.799l-1.154-1.266c-.55.553-1.083 1.086-1.584 1.586.59.588 1.1 1.091 1.494 1.48zm9.47-14.763c.34-1.046-.236-2.15-.7-2.816l-15.114 15.78a5.237 5.237 0 0 1 1.244 1.802c1.621-1.592 3.26-3.18 4.823-4.696l.107-.104.07-.068.03-.03.004-.003c5.032-4.879 9.241-8.96 9.536-9.865zM15.659 20.985a.744.744 0 0 0 .522.214.766.766 0 0 0 .527-.214.762.762 0 0 0 .214-.529.747.747 0 0 0-.213-.522c-.279-.272-.778-.272-1.05 0a.746.746 0 0 0-.22.522.77.77 0 0 0 .22.53zm7.885 8.464a2.706 2.706 0 0 1-2.628-2.054 2.697 2.697 0 0 1 .305-2.057 2.695 2.695 0 0 1 2.326-1.321 2.71 2.71 0 0 1 2.63 2.054 2.71 2.71 0 0 1-.304 2.056 2.691 2.691 0 0 1-1.667 1.24 2.69 2.69 0 0 1-.662.082zm-.299-3.912a1.22 1.22 0 0 0-.755.563 1.226 1.226 0 0 0-.137.933 1.238 1.238 0 0 0 1.491.894c.32-.079.587-.279.756-.561a1.23 1.23 0 0 0-1.355-1.828zm-14.48-1.52a2.702 2.702 0 0 1 2.33 1.321c.371.624.48 1.355.303 2.058a2.707 2.707 0 0 1-3.292 1.972 2.693 2.693 0 0 1-1.666-1.24 2.699 2.699 0 0 1-.303-2.056 2.708 2.708 0 0 1 2.628-2.054zm-.299 3.91a1.237 1.237 0 0 0 1.492-.894 1.227 1.227 0 0 0-1.193-1.532c-.564 0-1.053.383-1.191.932-.08.319-.032.65.138.933.168.281.436.482.754.561zm.63-21.016c.788 0 1.453.501 1.453 1.095a.742.742 0 1 0 1.482 0c0-1.421-1.316-2.578-2.934-2.578h-.008V5.11a.741.741 0 0 0-1.481 0v.317l-.276-.001c-1.618 0-2.933 1.156-2.933 2.578v.1c0 .813.55 1.515 1.638 2.085.06.033.125.055.194.07l.055.01.016.006a.148.148 0 0 0 .025.007l1.283.263v2.387l-.278.001c-.789 0-1.455-.503-1.455-1.099a.74.74 0 1 0-1.482 0c0 1.424 1.317 2.583 2.937 2.583h.276v.405a.742.742 0 1 0 1.482 0v-.405h.008c1.616 0 2.932-1.157 2.932-2.583v-.098c0-.561-.29-1.382-1.671-2.11a.744.744 0 0 0-.197-.07l-.88-.18-.19-.038V6.914l.005-.003zm1.45 4.924c0 .595-.664 1.099-1.45 1.099H9.09v-2.083l.337.069.331.067c.622.346.789.638.789.749v.1zM7.609 9.031l-.975-.201c-.554-.307-.755-.58-.755-.722v-.1c0-.595.665-1.096 1.452-1.096h.277l.001 2.119zm6.895-7.25c.41 0 .742.333.742.742v1.78a.741.741 0 1 1-1.482 0v-1.78a.74.74 0 0 1 .74-.742zm.002 12.464a.741.741 0 0 0-.74.742v1.781a.741.741 0 1 0 1.481 0v-1.78a.743.743 0 0 0-.741-.743zm-.002-8.31c.41 0 .742.333.742.742v1.781a.741.741 0 1 1-1.482 0v-1.78a.74.74 0 0 1 .74-.743zm.742 4.897a.742.742 0 1 0-1.482 0v1.78a.741.741 0 1 0 1.482 0v-1.78zm2.546-7.655h4.91a.741.741 0 0 1 0 1.485h-4.91a.741.741 0 0 1 0-1.485zm7.082 0a.742.742 0 0 0 0 1.485h2.074a.742.742 0 0 0 0-1.485h-2.074zm-6.236 4.638h-.846a.74.74 0 0 1-.741-.742.74.74 0 0 1 .74-.742h.847a.742.742 0 1 1 0 1.484zm4.064 0a.741.741 0 0 0 0-1.484h-1.714a.741.741 0 0 0 0 1.484h1.714zm-2.764 3.115h-2.146a.74.74 0 0 1-.741-.742.74.74 0 0 1 .74-.743h2.147c.41 0 .74.332.74.743 0 .41-.331.742-.74.742z"
                      fill="#fff"
                    />
                  </svg>
                </i>
              </div>
              /*/
            /* eslint-enable */}
          </div>
        </div>
      </div>
      <div className="summary-addon__body">
        {(transfers
          && transfers.length > 0
          && transfers.map((transfer) => {
            const transferId: string = transfer.vehicles && transfer.vehicles.length > 0
              ? transfer.vehicles[0].id : transfer.type;
            const isSelected: boolean = isTransferSelected();
            return (
              <SummaryAddonItem
                key={transferId}
                hotelName={hotelName}
                currency={currency}
                cultureCode={cultureCode}
                initialLoadingStyles={initialLoadingStyles}
                transfer={transfer}
                airportName={airportName}
                handleAddTransfer={handleAddTransfer}
                handleRemoveTransfer={handleRemoveTransfer}
                isSelected={isSelected}
              />
            );
          })) || <SummaryAddonItem initialLoadingStyles={initialLoadingStyles} transfer={{}} />}
      </div>
    </div>
  );
}

export default SummaryAddonContainer;
