import React from 'react';
import { FormattedMessage } from 'react-intl';
// import Link from 'next/link';
// @flow
import NumberFormat from 'components/NumberFormat';

import './SummaryAddonItem.scss';
import {
  MdCompareArrows as IconArrowReturn,
  MdPerson as IconPerson,
  MdAccessTime as IconClock,
  MdClose as IconClose,
} from 'react-icons/md';
import FormattedDuration from '../../../components/DurationFormat';
import { type SummaryAddonItemProps, type LoadingStyles } from '../types';

import InitialLoadingStyle from '../../../utils/initialLoading';
import { getImageUrlsString } from '../../../utils/image-utils';

function SummaryAddonItem({
  transfer,
  hotelName,
  airportName,
  currency,
  cultureCode,
  initialLoadingStyles,
  handleAddTransfer,
  handleRemoveTransfer,
  isSelected,
}: SummaryAddonItemProps) {
  const {
    type, image, maxPax, maxBags, duration, price, vehicles,
  } = transfer;
  const loadingStyles: LoadingStyles = Object.keys(initialLoadingStyles).length === 0
    ? InitialLoadingStyle(true)
    : initialLoadingStyles;
  const { textLoading, loadingState } = loadingStyles;
  return (
    <div className="container">
      <div className="summary-addon__card flex-wrapper">
        <div
          className="product-img"
          style={{ backgroundImage: getImageUrlsString(image, 'TRANSFERS', loadingState) }}
        />
        <div className="summary-addon__details">
          <div className="summary-addon__details-title">
            <h3 className={`heading heading--h3 ${textLoading}`}>
              {type === 'private' && (
                <FormattedMessage
                  id="SummaryAddonItem.privateTransferTitle"
                  defaultMessage="Return Private Transfer"
                />
              ) || (
                <FormattedMessage
                  id="SummaryAddonItem.sharedTransferTitle"
                  defaultMessage="Return Shared Transfer"
                />
              )}
            </h3>
            {/* <i className="icon icon--info">
              <IconInfo />
            </i> */}
          </div>

          <div className={`summary-addon__details-location ${textLoading}`}>
            <small>
              {airportName}
            </small>
            <i>
              <IconArrowReturn />
            </i>
            <small>
              {hotelName}
            </small>
          </div>

          <div className={`summary-addon__details-info ${textLoading}`}>
            {!!maxPax && (
              <span className="summary-addon__details-info__maxpax">
                <i className="icon icon--person">
                  <IconPerson size="24" />
                </i>
                <small>
                  <FormattedMessage
                    id="SummaryAddonItem.maxPax"
                    defaultMessage={'{maxPax, plural, one {# Passenger} other {# Passengers}}'}
                    values={{ maxPax }}
                  />
                </small>
              </span>
            )}
            {!!maxBags && (
              <span className="summary-addon__details-info__maxbags">
                <i className="icon icon--luggage">
                  <svg width="17" height="24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13.802 3.16h-2.223v-.765A2.397 2.397 0 0 0 9.185 0H6.79a2.397 2.397 0 0 0-2.395 2.395v.766H2.173C.963 3.16 0 4.148 0 5.334v16.591c0 .47.395.865.864.865H1.95v.272a.938.938 0 1 0 1.877 0v-.272h8.37v.272a.938.938 0 1 0 1.877 0v-.272h1.085a.875.875 0 0 0 .865-.865V5.334c-.05-1.186-1.038-2.173-2.222-2.173zM.839 5.335c0-.716.592-1.31 1.309-1.31h.74A2.52 2.52 0 0 1 .84 6.075v-.74zm12.963-1.31c.715 0 1.308.593 1.308 1.31v.74a2.52 2.52 0 0 1-2.05-2.05h.742zM5.678 2.397c0-.592.494-1.086 1.086-1.086h2.395c.592 0 1.086.494 1.086 1.086v.766L5.678 3.16v-.765z" />
                  </svg>
                </i>
                <small>
                  <FormattedMessage
                    id="SummaryAddonItem.maxBags"
                    defaultMessage={'{maxBags, plural, one {Up to # bag} other {Up to # bags}}'}
                    values={{ maxBags }}
                  />
                </small>
              </span>
            )}
            {!!duration && (
              <span className="summary-addon__details-info__duration">
                <i className="icon icon--clock">
                  <IconClock size="24" />
                </i>
                <small>
                  <FormattedMessage
                    id="SummaryAddonItem.duration"
                    defaultMessage={'Within {duration}'}
                    values={{ duration: <FormattedDuration minutes={duration} /> }}
                  />
                </small>
              </span>
            )}
          </div>
        </div>

        <div className={`summary-addon__details-pricing ${textLoading}`}>
          {price && (
            <div className="details-pricing__wrapper">
              {(!!price.originalPrice && price.originalPrice > price.price) && (
                <strong className="details-pricing__strike">
                  <div className="value">
                    <NumberFormat
                      value={`${price.originalPrice}`}
                      locale={`${cultureCode}`}
                      currency={`${currency}`}
                    />
                  </div>
                </strong>
              )}
              <strong className="price--2 theme-primary-text">
                <div className="value">
                  <NumberFormat
                    value={`${price.price}`}
                    locale={`${cultureCode}`}
                    currency={`${currency}`}
                  />
                </div>
              </strong>
            </div>
          )}
          {/* Hide / show Add Transfer button */}
          {isSelected && (
            <React.Fragment>
              <button
                type="button"
                className="button btn-remove-transfer"
                onClick={() => {
                  handleRemoveTransfer();
                }}
              >
                <FormattedMessage
                  id="SummaryAddonItem.removeTransfer"
                  defaultMessage="Added"
                />
                <i className="icon icon--close">
                  <IconClose />
                </i>
              </button>
            </React.Fragment>
          ) || (
            <button
              type="button"
              className="button btn-theme-primary btn-add-transfer"
              onClick={() => {
                handleAddTransfer(vehicles);
              }}
            >
              <FormattedMessage
                id="SummaryAddonItem.addTransfer"
                defaultMessage="Add Transfer"
              />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default SummaryAddonItem;
