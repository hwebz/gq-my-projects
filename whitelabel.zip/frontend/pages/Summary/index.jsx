import React from 'react';
import { defineMessages } from 'react-intl';

import Link from 'next/link';
// @flow
import { Helmet } from 'react-helmet';
import SidebarSummary from 'components/Sidebars/SidebarSummary';
import LoadingAnimation from 'components/Common/LoadingAnimation';
import JumpingShapes from 'components/CommonLoadingAnimation/JumpingShapes';
import { emptyFlight } from '../../store-app/modules/flights/constants';
import DockedFooter from '../../components/DockedFooter';
import FlightItemCard from '../../components/FlightItemCard';
// import LoadingOverlay from '../../components/LoadingOverlay';
import DateFormat from '../../components/DateFormat';
import BreadCrumbs from '../../components/BreadCrumbs';
import PageBase from '../PageBase';
import HotelDetailSummary from '../../components/HotelSummary/HotelDetailSummary';
import SummaryAddonContainer from './components/SummaryAddonContainer';
import InitialLoadingStyle from '../../utils/initialLoading';
import { hasMissingQuery } from '../../react-next/utils/query-string';
import './Summary.scss';
import {
  type SummaryPageProps,
  type SummaryDetailsRequestModel,
  type SummaryQueryParams,
  type Context,
  type Vehicle,
  type LoadingStyles,
} from './types';

import { getPackageSummaryDetails } from '../../store-app/modules/package/selectors';

import { getPackageSummary, updatePackageSummary } from '../../store-app/modules/package/actions';

import { pollStartAction, addToPackage } from '../../store-app/modules/transfers/actions';

import { getIsPackageUpdating } from '../../store-app/modules/transfers/selectors';

const track = require('../../react-next/utils/track-utils');

const defaultMessages = defineMessages({
  summaryPageTitle: {
    id: 'summary.pageTitle',
    defaultMessage: 'Confirm Your Trip | {siteName}',
  },
  summaryTitle: {
    id: 'summary.title',
    defaultMessage: 'Summary',
  },
  departureTitle: {
    id: 'summary.departure',
    defaultMessage: 'Your Departure Flight',
  },
  returnTitle: {
    id: 'summary.return',
    defaultMessage: 'Your Return Flight',
  },
  changeFlight: {
    id: 'summary.changeFlight',
    defaultMessage: 'Change flight',
  },
  proceedToPassenger: {
    id: 'summary.proceedToPassenger',
    defaultMessage: 'Continue',
  },
  submitPackage: {
    id: 'summary.submitPackage',
    defaultMessage: 'Creating booking...',
  },
});

class Summary extends React.Component<SummaryPageProps> {
  componentDidMount() {
    const {
      dispatch,
      summaryDetailsRequestModel,
      combinedQueryParams: { packageId },
    } = this.props;
    dispatch(getPackageSummary(summaryDetailsRequestModel));
    dispatch(pollStartAction({ packageId, ...summaryDetailsRequestModel }));
  }

  componentDidUpdate(prevProps) {
    const {
      dispatch,
      cultureCode,
      summaryDetailsRequestModel,
    } = this.props;

    const prevCultureCode = prevProps.cultureCode;
    if (
      prevCultureCode !== cultureCode
    ) {
      summaryDetailsRequestModel.lang = cultureCode;
      dispatch(
        getPackageSummary(summaryDetailsRequestModel),
      );
      if (this.hasTransfers()) {
        dispatch(pollStartAction(summaryDetailsRequestModel));
      }
      return false;
    }
    return null;
  }

  static async getInitialProps({ ctx }: Context<SummaryQueryParams>) {
    // Gets query params from url
    const {
      initPayload: { combinedQueryParams, cultureCode },
    } = ctx;

    const hasQueryError: boolean = hasMissingQuery(combinedQueryParams, [
      'packageId',
      'room',
      'outbound',
      'inbound',
    ]);

    if (!hasQueryError) {
      const summaryUpdateModel = {
        roomId: combinedQueryParams.room,
        departureFlightId: combinedQueryParams.outbound,
        returnFlightId: combinedQueryParams.inbound,
        lang: cultureCode,
      };
      const summaryDetailsRequestModel: SummaryDetailsRequestModel = {
        packageId: combinedQueryParams.packageId,
        ...summaryUpdateModel,
      };
      return { hasQueryError, summaryDetailsRequestModel, summaryUpdateModel };
    }

    return { hasQueryError };
  }

  getVehicleIds = (vehicles: Vehicle) => {
    let arrivalTransfer;
    let departureTransfer;
    Object.keys(vehicles).forEach((key) => {
      switch (vehicles[key].direction) {
        case 'ah':
          arrivalTransfer = vehicles[key].id;
          break;
        case 'ha':
          departureTransfer = vehicles[key].id;
          break;
        default:
          break;
      }
    });

    return { arrivalTransfer, departureTransfer };
  };

  hasTransfers = () => {
    const { transfersApiResponse } = this.props;
    if (transfersApiResponse.transfers) {
      return transfersApiResponse.transfers.length > 0;
    }
    return false;
  };

  handleAddTransfer = (selectedVehicle: Array<Vehicle>) => {
    const {
      cultureCode, dispatch, combinedQueryParams,
      summaryUpdateModel,
    } = this.props;
    summaryUpdateModel.lang = cultureCode;
    const transfers = this.getVehicleIds(selectedVehicle);
    summaryUpdateModel.addons = !summaryUpdateModel.addons ? {
      transfers,
    } : {
      ...summaryUpdateModel.addons,
      transfers,
    };
    this.eventTracking(
      transfers.departureTransfer,
      'TRANSFER Added transfer into package',
      transfers,
    );
    dispatch(
      updatePackageSummary(combinedQueryParams.packageId, summaryUpdateModel),
    );
    return false;
  };

  handleRemoveTransfer = () => {
    const { dispatch, combinedQueryParams, summaryUpdateModel } = this.props;
    const { addons } = summaryUpdateModel;
    const { transfers } = addons;
    this.eventTracking(
      transfers.departureTransfer,
      'TRANSFER Removed transfer from package',
      transfers,
    );
    const removedTransfers = { arrivalTransfer: null, departureTransfer: null };
    summaryUpdateModel.addons = !summaryUpdateModel.addons ? {
      transfers: removedTransfers,
    } : {
      ...summaryUpdateModel.addons,
      transfers: removedTransfers,
    };
    dispatch(
      updatePackageSummary(combinedQueryParams.packageId, summaryUpdateModel),
    );
    return false;
  };

  handleContinue = () => {
    const {
      combinedQueryParams: { packageId },
      summaryUpdateModel,
      dispatch,
      urlLocale,
    } = this.props;
    const {
      roomId, departureFlightId, returnFlightId, addons,
    } = summaryUpdateModel;
    const requestParams = {
      roomId,
      departureFlightId,
      returnFlightId,
      addons,
    };
    dispatch(addToPackage(packageId, requestParams, urlLocale));
    return false;
  };

  scrollToTransfers = () => {
    if (this.node) {
      this.node.scrollIntoView({ block: 'start', behavior: 'smooth' });
    }
  };

  eventTracking = (label, action, properties) => {
    const { router } = this.props;
    console.log(label, action, properties);
    track.event(
      router.pathname,
      action,
      label,
      {
        ...properties,
      },
    );
  }

  render() {
    const {
      summaryDetails,
      transfersApiResponse,
      isPackageUpdating,
      cultureCode,
      intl,
      urlLocale,
      config,
      combinedQueryParams,
      router,
      defaultConfig,
    } = this.props;
    const { formatMessage } = intl;

    const {
      hotelSummary,
      flightSummary,
      priceSummary,
      searchQuery,
    } = summaryDetails;

    const paxCounts: {
      adult: number,
      child: number,
      infant: number
    } = {};
    if (summaryDetails.searchQuery) {
      paxCounts.adult = searchQuery.adultCount;
      paxCounts.child = searchQuery.childCount;
      paxCounts.infant = searchQuery.infantCount;
    }
    const roomCount: number = searchQuery ? searchQuery.roomCount : 0;
    const hotelName: string = hotelSummary ? hotelSummary.name : '';

    const sidebarSummary = {
      ...priceSummary,
      paxCounts,
    };
    const initialLoadingStyles: LoadingStyles = InitialLoadingStyle(
      !transfersApiResponse.isComplete,
    );
    const {
      packageId,
      room,
      inbound,
      outbound,
    } = combinedQueryParams;
    const siteName: string = config.general.name;
    const flightPathName: string = `/Flight?packageId=${packageId}&room=${room}`;
    const flightUrl: string = `${urlLocale}/flights/${packageId}?room=${room}`;

    if (flightSummary && transfersApiResponse.isComplete) {
      router.prefetch('/Details');
      const HasTransferFound = this.hasTransfers();
      const TransfersFound = HasTransferFound ? transfersApiResponse.transfers.length : 'No transfers';
      track.page(
        '/Summary',
        defaultConfig.environment,
        {
          Origin: searchQuery ? searchQuery.from : '',
          Destination: searchQuery ? searchQuery.to : '',
          HotelID: room,
          SelectedDepartureFlightID: outbound,
          SelectedReturnFlightID: inbound,
          HasTransferFound,
          TransfersFound,
        },
      );
    }
    return (
      <div>
        <Helmet>
          <title>{formatMessage(defaultMessages.summaryPageTitle, { siteName })}</title>
        </Helmet>
        {isPackageUpdating && (
          <LoadingAnimation
            TimeoutIconSvg={JumpingShapes}
            msg={formatMessage(defaultMessages.submitPackage)}
          />
        )}
        {/* {priceSummary
          && hotelSummary
          && flightSummary && ( */}
        <React.Fragment>
          <BreadCrumbs currentPage={4} />
          <div className="summary__wrap">
            <div className="container">
              <div className="summary__title">
                <h1>{formatMessage(defaultMessages.summaryTitle)}</h1>
              </div>
              <div className="summary__content summary">
                <div className="summary__detail">
                  {/* {hotelSummary && ( */}
                  <HotelDetailSummary
                    summary={hotelSummary || {}}
                    roomCount={roomCount || ''}
                    isConfirmation={false}
                    cultureCode={cultureCode}
                    router={router}
                  />
                  {/* )} */}
                  <div className="card card--with-border ">
                    <div className="card__body summary__flight">
                      <div className="summary__flight__title">
                        <strong>{formatMessage(defaultMessages.departureTitle)}</strong>
                        <small className="link-theme-color">
                          <Link href={{ pathname: flightPathName }} as={flightUrl}>
                            {/* eslint-disable-next-line */}
                            <a onClick={() => { this.eventTracking(flightSummary.departFlight.flightId, 'CHANGE Selected to change departure flight', { flightId: flightSummary.departFlight.flightId }); } }>
                              {formatMessage(defaultMessages.changeFlight)}
                            </a>
                          </Link>
                        </small>
                      </div>
                      <div className="summary__flight__date">
                        {(flightSummary && (
                          <DateFormat
                            value={flightSummary.departFlight.departure.date}
                            format={('LONG': Format)}
                            locale={`${cultureCode}`}
                          />
                        ))
                          || ''}
                      </div>
                    </div>
                    {(flightSummary && (
                      <FlightItemCard
                        isSummary
                        isDetailOpen
                        isConfirmation={false}
                        flightItem={flightSummary.departFlight}
                        cultureCode={cultureCode}
                        currency={priceSummary.currency}
                        router={router}
                      />
                    )) || (
                      <FlightItemCard flightItem={emptyFlight} isFetching />
                    )}
                    <div className="card__body summary__flight">
                      <div className="summary__flight__title">
                        <strong>{formatMessage(defaultMessages.returnTitle)}</strong>
                        <small className="link-theme-color">
                          <Link href={{ pathname: flightPathName }} as={flightUrl}>
                            {/* eslint-disable-next-line */}
                            <a onClick={() => { this.eventTracking(flightSummary.returnFlight.flightId, 'CHANGE Selected to change Return flight', { flightId: flightSummary.returnFlight.flightId }); }}>
                              {formatMessage(defaultMessages.changeFlight)}
                            </a>
                          </Link>
                        </small>
                      </div>
                      <div className="summary__flight__date">
                        {(flightSummary && (
                          <DateFormat
                            value={flightSummary.returnFlight.departure.date}
                            format={('LONG': Format)}
                            locale={`${cultureCode}`}
                          />
                        ))
                          || ''}
                      </div>
                    </div>
                    {(flightSummary && (
                      <FlightItemCard
                        isSummary
                        isDetailOpen
                        isConfirmation={false}
                        flightItem={flightSummary.returnFlight}
                        router={router}
                      />
                    )) || (
                      <FlightItemCard flightItem={emptyFlight} isFetching />
                    )}
                  </div>
                </div>
                <div className="summary__sidebar visible-md">
                  {priceSummary && (
                    <SidebarSummary
                      summary={sidebarSummary}
                      canAddTransfer={this.hasTransfers()}
                      cultureCode={cultureCode}
                      isSummary
                      initialLoadingStyles={initialLoadingStyles}
                      handleContinue={this.handleContinue}
                      scrollToTransfers={this.scrollToTransfers}
                      isUpdating={isPackageUpdating}
                    />
                  )}
                </div>
              </div>
            </div>
          </div>
          {(!transfersApiResponse.isComplete || this.hasTransfers()) && (
            <div
              className="summary__transfers"
              ref={(node) => {
                this.node = node;
              }}
            >
              <SummaryAddonContainer
                initialLoadingStyles={initialLoadingStyles}
                addons={priceSummary ? priceSummary.addons : {}}
                hotelName={hotelName}
                canAddTransfer={this.hasTransfers()}
                transfers={transfersApiResponse.transfers || {}}
                airportName={flightSummary ? flightSummary.departFlight.arrival.airportName : ''}
                currency={transfersApiResponse.currency}
                cultureCode={cultureCode}
                handleAddTransfer={this.handleAddTransfer}
                handleRemoveTransfer={this.handleRemoveTransfer}
              />
            </div>
          )}
          <div className="summary__continue-btn text-center">
            <button
              type="button"
              className="button btn-lg btn-theme-primary"
              onClick={() => {
                this.handleContinue();
              }}
            >
              {formatMessage(defaultMessages.proceedToPassenger)}
            </button>
          </div>
          <DockedFooter
            summary={sidebarSummary}
            MainView={SidebarSummary}
            isLoading={initialLoadingStyles.loadingState}
            isSummary
          />
        </React.Fragment>
        {/* )} */}
      </div>
    );
  }
}

const mapStateToProps = state => ({
  summaryDetails: getPackageSummaryDetails(state),
  transfersApiResponse: state.transfers,
  isPackageUpdating: getIsPackageUpdating(state),
});

export default PageBase(Summary, {
  mapStateToProps,
  hasCurrencySwitcher: false,
});
