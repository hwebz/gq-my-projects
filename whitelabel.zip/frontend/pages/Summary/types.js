/**
 * @flow
 */
import { type IntlShape } from 'react-intl';
import {
  type TransferItem,
  type HotelSummary,
  type SummaryDetails,
  type Config,
  type LoadingStyles,
  type Vehicle,
  type Addons,
  type SummaryDetailsRequestModel,
} from '../../flow-types';

import { type PageBaseProps } from '../PageBase/types';

export * from '../../flow-types';

export type SummaryQueryParams = {
  packageId: string,
  room: string, // roomId,
  outbound: string,
  inbound: string
};

export type TransfersApiResponse = {
  transfers: Array<TransferItem>,
  isComplete: boolean,
  currency: string,
};

export type SummaryPageProps = PageBaseProps<SummaryQueryParams> & {
  summaryDetails: SummaryDetails,
  transfersApiResponse: TransfersApiResponse,
  summaryDetailsRequestModel: SummaryDetailsRequestModel,
  isPackageUpdating: boolean,
  config: Config,
  cultureCode: string,
  intl: IntlShape,
  urlLocale: string,
  room: string,
  packageId: string
};

export type GetVehicleIdsReturnTypes = {
  arrivalTransfer: string,
  departureTransfer: string
};

export type SummaryAddonContainerProps = {
  hotelName: string,
  currency: string,
  cultureCode: string,
  transfers: Array<TransferItem>,
  airportName: string,
  initialLoadingStyles: LoadingStyles,
  addons: Addons,
  handleAddTransfer: (vehicles: Array<Vehicle>) => boolean,
  handleRemoveTransfer: () => boolean
};

export type SummaryAddonItemProps = {
  transfer: TransferItem,
  hotelName: string,
  hotelSummary: HotelSummary,
  airportName: string,
  currency: string,
  cultureCode: string,
  initialLoadingStyles: LoadingStyles,
  handleAddTransfer: (vehicles: Array<Vehicle>) => boolean,
  handleRemoveTransfer: () => boolean,
  isSelected: boolean
};
