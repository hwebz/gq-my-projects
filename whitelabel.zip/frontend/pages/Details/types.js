// @flow
import { type PageBaseProps } from '../PageBase/types';

import {
  type GetBookingDetailsResponse,
  type GetPaymentGatewaysResponse,
  type FieldStatus,
  type HandleDetailChangeEvents,
  type SetDOB,
  type PassengerSummaryDetails,
} from '../../flow-types';

export * from '../../flow-types';

export type FormPassengerDetails = {
  Title: FieldStatus<string>,
  FirstName: FieldStatus<string>,
  LastName: FieldStatus<string>,
  nationality: FieldStatus<string>,
  DateOfBirth: {
    day: FieldStatus<string>,
    month: FieldStatus<string>,
    year: FieldStatus<string>,
  },
};

export type FormFieldsType = {
  Name: FieldStatus<string>,
  Email: FieldStatus<string>,
  MobilePhone: FieldStatus<string>,
  passengerDetails: Array<FormPassengerDetails>,
  NameOntheCard: FieldStatus<string>,
  CreditCardExpiryDate: FieldStatus<string>,
  CreditCardNo: FieldStatus<string>,
  CreditCardCVV: FieldStatus<string>,
};

export type PassengerData = {
  type: string,
  title: string,
  firstName: string,
  lastName: string,
  nationality: string,
  dob: string,
};

type ContactDetail = {
  name: string,
  email: string,
  contactNumber: string,
};

type CreditCard = {
  cardNumber: string,
  expiryMonth: number,
  expiryYear: number,
  ccv: string,
  cardHolderName: string,
  paymentProcessor: string,
};

export type FormData = {
  contactDetail: ContactDetail,
  adultPassengers: PassengerData[],
  childPassengers: PassengerData[],
  infantPassengers: PassengerData[],
  creditCard: CreditCard,
};

export type PaymentData = {
  redirectUrl?: string,
};

// #region Functions

export type GetFormData = (formFields: FormFieldsType) => FormData;
export type EmptyFunctionMethod = () => void;
export type GetCardIcon = () => string;
export type GetCardTypes = () => array;
export type GetPaymentGatewayId = () => string;
export type SetCardType = (type: string) => void;
export type HandleCardField = (value: string, name: string, valid: boolean) => void;
export type IsValidCardField = (
  value: string,
  valid: boolean,
  fieldName: string,
) => FieldStatus<string>;
export type IsValidExpiredDate = ({
  error: string,
  year: string,
  month: string,
}) => FieldStatus<string>;
export type HandleMobileNumberChange = (
  name: string,
  phoneNum: string,
  validationType: string,
) => void;
export type UpdateCardDetails = (cardState: FormFieldsType) => void;
export type SetPaymentGatewayId = (paymentId: string) => void;
// #regionEnd

export type DetailsMSP = {
  isFetching?: boolean,
  bookingSummary: ?GetBookingDetailsResponse | empty,
  paymentDetails: ?GetPaymentGatewaysResponse | empty,
  paymentData: ?PaymentData | empty,
};

export type BookingDetaisQueryParams = {
  bookingId: string,
};

export type BookingDetailsProps = PageBaseProps<BookingDetaisQueryParams> & {
  bookingDetails: DetailsMSP,
};

export type BookingDetailsState = {
  formFields: FormFieldsType,
  formSubmitReady: boolean,
};

export type FormContainerProps = {
  formFields: FormFieldsType,
  handleOnChange: HandleDetailChangeEvents,
  handleMobileNumberChange: HandleMobileNumberChange,
  generatePaxFields: EmptyFunctionMethod,
  updateCardDetails: UpdateCardDetails,
  paymentDetails: GetPaymentGatewaysResponse,
  setPaymentGateWayId: string,
  hasErrorResponse: boolean,
  disablePayment: boolean,
};

type TitleOptionsItem = {
  text: string,
  value: string,
  id: string,
};

export type TitleOptionsType = {
  Adult: Array<TitleOptionsItem>,
  Child: Array<TitleOptionsItem>,
  Infant: Array<TitleOptionsItem>,
};

export type PaxInfoTypes = {
  paxFields: Array<PassengerSummaryDetails>,
  handlePaxChange: HandleDetailChangeEvents,
  personInfo: Object,
  totalPassengers: number,
  dateOfBirth: Object,
  titleOptions: TitleOptionsType,
  setDOB: SetDOB,
};

export type FormRedirectionTypes = {
  paymentData: PaymentData,
};

export type PaymentDetailsTypes = {
  formFields: FormFieldsType,
  handleOnChange: HandleDetailChangeEvents,
  updateCardDetails: UpdateCardDetails,
  paymentDetails: GetPaymentGatewaysResponse,
  setPaymentGateWayId: string,
};

export type PaymentDetailsActionPayload = {
  payload: {
    packageId: string,
  },
};

export type ContactDetailsTypes = {
  formFields: FormFieldsType,
  handleOnChange: HandleDetailChangeEvents,
  handleMobileNumberChange: HandleMobileNumberChange,
};

export type CreditCardFormProps = {
  formFields: FormFieldsType,
  handleOnChange: HandleDetailChangeEvents,
};

export type CreditCardFormState = {
  currentCardType: string,
};
