import React, { Component } from 'react';
import { goToTop, goToAnchor, configureAnchors } from 'react-scrollable-anchor';
import { defineMessages } from 'react-intl';
// Common components
import CriticalMsgDisplay from 'components/Common/CriticalMsgDisplay';
import SidebarHotel from 'components/Sidebars/SidebarHotel';
import SidebarFlight from 'components/Sidebars/SidebarFlight';
import SidebarSummary from 'components/Sidebars/SidebarSummary';
import DockedFooter from 'components/DockedFooter';
// utility functions
import { validateField, validateForm } from '../../utils/formFieldValidation';
import getCardTypes from '../../utils/paymentUtils';
// @flow
import {
  type BookingDetailsProps,
  type BookingDetaisQueryParams,
  type Context,
  type TitleOptionsType,
  type BookingDetailsState,
  type SetDOB,
  type FieldStatus,
  type GetFormData,
  type FormData,
  type PassengerData,
  type HandleDetailChangeEvents,
  type EmptyFunctionMethod,
  type FormFieldsType,
  type UpdateCardDetails,
  type SetPaymentGatewayId,
  type HandleMobileNumberChange,
  type FormPassengerDetails,
} from './types';
import { hasMissingQuery } from '../../react-next/utils/query-string';
import PageBase from '../PageBase';
// Child Components
import BreadCrumbs from '../../components/BreadCrumbs';
import FormContainer from './components/FormContainer';
import FormRedirection from './components/FormRedirection';
import PassengerInfo from './components/PassengerInfo';
// Styles
import './details.scss';
import { getBookingSummary, postBookingForm, getPaymentDetails } from '../../store-app/modules/details/actions';
import { getCountryList } from '../../store-app/modules/country/actions';

// countries.registerLocale(require('i18n-iso-countries/langs/zh.json'));
const track = require('../../react-next/utils/track-utils');

const defaultMessages = defineMessages({
  paxTitleMr: {
    id: 'Details.paxTitleMr',
    defaultMessage: 'Mr',
  },
  paxTitleMrs: {
    id: 'Details.paxTitleMrs',
    defaultMessage: 'Mrs',
  },
  paxTitleMs: {
    id: 'Details.paxTitleMs',
    defaultMessage: 'Ms',
  },
  paxTitleMstr: {
    id: 'Details.paxTitleMstr',
    defaultMessage: 'Mstr',
  },
  paxTitleMiss: {
    id: 'Details.paxTitleMiss',
    defaultMessage: 'Miss',
  },
  passengerInformation: {
    id: 'Details.PassengerInformation',
    defaultMessage: 'Passenger Information',
  },
  confirmNPay: {
    id: 'Details.ConfirmNPay',
    defaultMessage: 'Confirm & Pay',
  },
  confirmNPay_Text1: {
    id: 'Details.ConfirmNPay_Text1',
    defaultMessage: 'You will be redirected to a payment gateway.',
  },
  confirmNPay_Text2: {
    id: 'Details.ConfirmNPay_Text2',
    defaultMessage: 'Please ensure that your pop-up blocker is disabled. Do not refresh the page until transaction is complete.',
  },
  RES0: {
    id: 'Details.RES0',
    defaultMessage: 'Payment failed! Please enter the correct card details and try again.',
  },
});

class Details extends Component<BookingDetailsProps, BookingDetailsState> {

  static checkErrors = responseObject => (responseObject ? responseObject.Errors : false);

  constructor(props: BookingDetailsProps) {
    super(props);
    // state property name & form field name should be same
    // eg: email <input name='email'>
    this.state = {
      formFields: {
        contactDetail: {
          firstName: { value: '', required: true, status: true },
          lastName: { value: '', required: true, status: true },
          email: { value: '', required: true, status: true },
          contactNumber: { value: '', required: true, status: true },
        },
        passengers: [],
        creditCard: {
          cardHolderName: { value: '', required: true, status: true },
          cardNumber: { value: '', required: true, status: true },
          ccv: { value: '', required: true, status: true },
          expiryMonth: { value: '', required: true, status: true },
          expiryYear: { value: '', required: true, status: true },
          paymentProcessor: { value: '', required: true, status: true },
        },
        // get it from paymentDetails api
        paymentId: { value: '', required: true, status: false },
      },
      formSubmitReady: false,
      selectedLegInfo: '',
      firstPageLoad: true,
    };
  }

  state: BookingDetailsState;

  componentDidMount() {
    const { dispatch, combinedQueryParams } = this.props;
    dispatch(getBookingSummary(combinedQueryParams.packageId));
    dispatch(getPaymentDetails(combinedQueryParams.packageId));
    dispatch(getCountryList());
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    const { firstPageLoad } = prevState;
    const {
      bookingDetails,
      defaultConfig,
      selectedCurrency,
    } = nextProps;
    const { bookingSummary, paymentDetails } = bookingDetails;
    const isError = Details.checkErrors(bookingSummary) && Details.checkErrors(paymentDetails);
    if (bookingSummary && paymentDetails && !isError && firstPageLoad) {
      const cards = getCardTypes(paymentDetails);
      track.page(
        '/Details',
        defaultConfig.environment,
        {
          Passengers: bookingSummary.passengers.length,
          Payments: paymentDetails.length,
          PaymentMethods: cards.join(','),
          Currency: selectedCurrency,
          hasTermsAndConds: false,
          hasHotelCancellationPolicy: false,
        },
      );
      return {
        firstPageLoad: false,
      };
    }
    return null;
  }


  setPageLoadStatus() {
    this.setState({ firstPageLoad: false });
  }

  // this function is pass to the DOBDropdown component to set the state
  setDOB: SetDOB = (e: SyntheticEvent<HTMLElement>, dob: string) => {
    const { formFields } = this.state;
    const { passengers } = formFields;
    const stateKey: string = e.target.name.split('.');
    // const fieldName: string = stateKey[0].toString();
    const fieldIndex: number = parseInt(stateKey[1], 10);
    const fieldStatus: FieldStatus<string> = validateField('DATE', dob, e.type);
    // fieldStatus.name = fieldName;
    // Validates the date and returns an object
    // fieldStatus.name = e.target.name;
    // mutating state to avoid the dupicate objects since it onChange event
    passengers[fieldIndex].dob = fieldStatus;
    this.setState({ formFields });
  };

  setPaymentGatewayId: SetPaymentGatewayId = (payGTId: string, payProccesor: string) => {
    const { formFields } = this.state;
    const { paymentId, creditCard } = formFields;
    paymentId.value = payGTId;
    paymentId.status = true;
    creditCard.paymentProcessor.value = payProccesor;
    creditCard.paymentProcessor.status = true;
    this.setState({ formFields });
  };

  getFieldStatus = (fields: FormPassengerDetails) => {
    let status: boolean = true;
    // Note at any point status is false
    Object.keys(fields).forEach((fieldName) => {
      if (!fields[fieldName].status) {
        status = false;
      }
    });
    return status;
  };

  getFormData: GetFormData = (formFields) => {
    const formData: FormData = {};
    const passengers: Array<PassengerData> = [];
    Object.keys(formFields).forEach((fieldName) => {
      if (fieldName === 'passengers') {
        formFields.passengers.forEach((paxInfo) => {
          const passenger: PassengerData = {};
          Object.entries(paxInfo).forEach((key) => {
            passenger[key[0]] = key[1].value;
          });
          passengers.push(passenger);
        });
        formData.passengers = passengers;
      } else if (fieldName === 'paymentId') {
        formData.paymentId = formFields.paymentId.value;
      } else {
        const otherDetails = {};
        Object.keys(formFields[fieldName]).forEach((key) => {
          otherDetails[key] = formFields[fieldName][key].value;
        });
        formData[fieldName] = otherDetails;
      }
    });
    return formData;
  };

  static async getInitialProps({ ctx }: Context<BookingDetaisQueryParams>) {
    const {
      initPayload: { combinedQueryParams },
    } = ctx;
    const hasQueryError = hasMissingQuery(combinedQueryParams, ['packageId']);

    if (!hasQueryError) {
      return { hasQueryError, bookingId: combinedQueryParams.bookingId };
    }

    return { hasQueryError };
  }

  initializePaxFields = (paxFieldConfig: Array<Object>, type: string, numOfPax: number) => {
    const { formFields } = this.state;
    // Initializing passengers based on total number of pax
    let initialTitle: string = '';
    if (type.toLowerCase() === 'adult') {
      initialTitle = paxFieldConfig.title || 'Mr';
    } else {
      initialTitle = paxFieldConfig.title || 'Mstr';
    }
    if (formFields.passengers.length < numOfPax) {
      formFields.passengers.push({
        title: {
          value: initialTitle,
          status: true,
          required: true,
          name: 'title',
        },
        type: {
          value: type,
          status: true,
          required: true,
        },
        firstName: { value: paxFieldConfig.firstName, required: true, status: true },
        lastName: { value: paxFieldConfig.lastName, required: true, status: true },
        nationality: { value: paxFieldConfig.nationality, required: true, status: true },
        dob: { value: paxFieldConfig.dob, required: true, status: true },
        minDob: { value: paxFieldConfig.minDob, required: false, status: true },
        maxDob: { value: paxFieldConfig.maxDob, required: false, status: true },
      });
    }
  };

  generatePaxFields: EmptyFunctionMethod = () => {
    const { formFields } = this.state;
    const { bookingDetails, intl } = this.props;
    const { formatMessage } = intl;
    const { bookingSummary } = bookingDetails;
    const isError = Details.checkErrors(bookingSummary);
    if (bookingSummary && !isError) {
      const TitleOptions: TitleOptionsType = {
        Adult: [
          { text: formatMessage(defaultMessages.paxTitleMr), value: 'Mr', id: '1' },
          { text: formatMessage(defaultMessages.paxTitleMrs), value: 'Mrs', id: '2' },
          { text: formatMessage(defaultMessages.paxTitleMs), value: 'Ms', id: '3' },
        ],
        Child: [{ text: formatMessage(defaultMessages.paxTitleMstr), value: 'Mstr', id: '4' }, { text: formatMessage(defaultMessages.paxTitleMiss), value: 'Miss', id: '5' }],
        Infant: [
          { text: formatMessage(defaultMessages.paxTitleMstr), value: 'Mstr', id: '6' },
          { text: formatMessage(defaultMessages.paxTitleMiss), value: 'Miss', id: '7' },
        ],
      };
      const onPaxChange = this.handlePaxChange;
      // TODO Call the API to get the data
      const paxInfo = bookingSummary.passengers;
      return paxInfo.map((pax, index) => {
        const tOptions = TitleOptions[pax.type];
        // TODO set initial state for titles once assigned
        this.initializePaxFields(pax, pax.type, paxInfo.length);
        return (
          <PassengerInfo
            key={index.toString()}
            paxIndex={index.toString()}
            paxFields={formFields.passengers}
            handlePaxChange={onPaxChange}
            personInfo={pax}
            totalPassengers={paxInfo.length}
            titleOptions={tOptions}
            setDOB={this.setDOB}
          />
        );
      });
    }
    return null;
  };

  handleMobileNumberChange: HandleMobileNumberChange = (
    name: string,
    phoneNum: string,
    validationType: string,
    eventType: string,
  ) => {
    const { formFields } = this.state;
    const fieldStatus: FieldStatus<string> = validateField(validationType, phoneNum, eventType);
    // mutating state to avoid the dupicate objects since it onChange event
    formFields.contactDetail[name] = fieldStatus;
    console.log(fieldStatus);
    this.setState({ formFields });
  };

  handleOnChange: HandleDetailChangeEvents = (
    event: SyntheticEvent<HTMLElement>,
    validationType: string,
  ) => {
    const { formFields } = this.state;
    // to target the object name in the state
    const fieldName: string = event.target.name.split('.');
    // eslint-disable-next-line
    const fieldStatus: FieldStatus<string> = validateField(validationType, event.target.value, event.type);

    // mutating state to avoid the dupicate objects since it onChange event
    formFields[fieldName[0]][fieldName[1]] = fieldStatus;
    if (event.type === 'blur' && fieldName[0] === 'contactDetail') {
      if (fieldName[1] === 'firstName') {
        const firstAdult = formFields.passengers.find(pax => pax.type.value === 'Adult');
        firstAdult.firstName = fieldStatus;
      } else if (fieldName[1] === 'lastName') {
        // formFields.passengers[0].lastName = fieldStatus;
        const firstAdult = formFields.passengers.find(pax => pax.type.value === 'Adult');
        firstAdult.lastName = fieldStatus;
      }
      const ccStatus: FieldStatus<string> = validateField(
        'CARD_NAME',
        `${formFields.contactDetail.firstName.value || ''} ${formFields.contactDetail.lastName.value || ''}`,
        event.type,
      );
      formFields.creditCard.cardHolderName = ccStatus;
    }
    console.log(formFields);
    this.setState({ formFields });
  };

  handlePaxChange: HandleDetailChangeEvents = (
    event: SyntheticEvent<HTMLElement>,
    validationType: string,
  ) => {
    const { formFields } = this.state;
    const { passengers } = formFields;
    const stateKey: string = event.target.name.split('.');
    const fieldName: string = stateKey[0].toString();
    const fieldIndex: number = parseInt(stateKey[1], 10);
    // eslint-disable-next-line
    const fieldStatus: FieldStatus<string> = validateField(validationType, event.target.value, event.type);
    // mutating state to avoid the dupicate objects since it onChange event
    passengers[fieldIndex][fieldName] = fieldStatus;
    this.setState({ formFields });
  };

  updateCardDetails: UpdateCardDetails = (cardState: FormFieldsType) => {
    const { formFields } = this.state;
    formFields.creditCard = cardState;
    this.setState({ formFields });
  };

  setFormSubmit = (formStatus) => {
    this.setState({ formSubmitReady: formStatus });
  }

  handleFormSubmit = (event: SyntheticEvent<HTMLElement>) => {
    event.preventDefault();
    const { formFields } = this.state;
    const { dispatch, combinedQueryParams, router } = this.props;
    let isValidForm: boolean = false;
    let isValidPaxInfo: boolean = false;
    let isValidContactInfo: boolean = false;
    let isValidCardInfo: boolean = false;
    let isValidOtherInfo: boolean = false;
    const formFieldStatus = validateForm(formFields);
    let errorSection: string = ''; // to indicate which section has error field
    Object.keys(formFieldStatus).map((fieldName) => {
      if (fieldName === 'contactDetail') {
        isValidContactInfo = this.getFieldStatus(formFieldStatus.contactDetail);
        errorSection = !isValidContactInfo ? fieldName : '';
      } else if (fieldName === 'passengers') {
        // to ignore line length
        // eslint-disable-next-line
        const paxInfoStatus: Array = formFieldStatus.passengers.map(paxInfo => this.getFieldStatus(paxInfo));
        isValidPaxInfo = paxInfoStatus.indexOf(false) === -1; // checks array contains false
        errorSection = (!isValidPaxInfo && !errorSection) ? `passenger${paxInfoStatus.indexOf(false)}` : errorSection;
      } else if (fieldName === 'creditCard') {
        isValidCardInfo = this.getFieldStatus(formFieldStatus.creditCard);
        errorSection = (!isValidCardInfo && !errorSection) ? fieldName : errorSection;
      } else if (formFieldStatus[fieldName].status) {
        isValidOtherInfo = true;
      }
      if (isValidPaxInfo && isValidContactInfo && isValidCardInfo && isValidOtherInfo) {
        isValidForm = true;
      } else if (errorSection) {
        goToAnchor(errorSection);
        configureAnchors({ offset: -3, scrollDuration: 200 });
      }
      return isValidForm;
    });
    this.setState({ formFields: formFieldStatus });
    if (isValidForm) {
      goToTop();
      const formData = this.getFormData(formFieldStatus);
      this.setFormSubmit(true);
      // event tracking
      track.event(
        router.pathname,
        'PAY Selected to book now continue to payment',
        combinedQueryParams.packageId,
        {
          bookingId: combinedQueryParams.packageId,
        },
      );
      dispatch(postBookingForm(formData, combinedQueryParams.packageId));
    }
  };

  toggleLegInfo = (event, id) => {
    event.preventDefault();
    const { bookingDetails, router } = this.props;
    const { bookingSummary } = bookingDetails;
    const { flightSummary } = bookingSummary;
    const flightType = id === 'out' ? 'departure' : 'return';
    const flightId = id === 'out' ? flightSummary.departFlight.flightId : flightSummary.returnFlight.flightId;
    track.event(
      router.pathname,
      `VIEW Viewed ${flightType} flight details`,
      flightId,
      {
        flightId,
      },
    );
    this.setState({ selectedLegInfo: id });
  };


  props: BookingDetailsProps;
  render() {
    const {
      formFields, formSubmitReady, selectedLegInfo,
    } = this.state;
    const {
      bookingDetails,
      combinedQueryParams,
      intl,
    } = this.props;
    const { bookingSummary, paymentData, paymentDetails } = bookingDetails;
    const paxCounts = {};
    // const searchQueryString = bookingSummary ? bookingSummary.searchQuery : {};
    let sidebarSummary = {};
    const errorList = ['E201', 'E202', 'E203', 'E211', 'E212', 'E213']; // enable all form fields, these error are throw back to the details page
    // const hasBSError: boolean = (bookingSummary && bookingSummary.Errors) ? ('Code' in bookingSummary.Errors[0]) : false;
    // const hasPaxError: boolean = (paymentDetails && paymentDetails.Errors) ? ('Code' in paymentDetails.Errors[0]) : false;
    // const hasPaymentErrorRes: boolean = (paymentData && paymentData.Errors) ? ('Code' in paymentData.Errors[0]) : false;
    const hasBSError: boolean = Details.checkErrors(bookingSummary);
    const hasPaxError: boolean = Details.checkErrors(paymentDetails);
    const hasPaymentErrorRes: boolean = Details.checkErrors(paymentData);
    const paymentErrorResponseCode: boolean = ('ResponseCode' in combinedQueryParams) ? combinedQueryParams.ResponseCode : 1;
    const hasErrorResponse: boolean = hasBSError
      || hasPaxError
      || (hasPaymentErrorRes && errorList.indexOf(paymentData.Errors[0].Code) < 0);
    if (bookingSummary && !hasErrorResponse) {
      paxCounts.adult = bookingSummary.searchQuery.adultCount;
      paxCounts.child = bookingSummary.searchQuery.childCount;
      paxCounts.infant = bookingSummary.searchQuery.infantCount;
      sidebarSummary = {
        ...bookingSummary.priceSummary,
        paxCounts,
        hasContinueButton: false,
        canAddTransfer: false,
      };
    }
    const hotelSummary = bookingSummary && !hasBSError ? bookingSummary.hotelSummary : '';
    const flightSummary = bookingSummary && !hasBSError ? bookingSummary.flightSummary : {};
    const { formatMessage } = intl;
    return (
      <div>
        <form method="post" action="/details" name="bookingForm" onSubmit={this.handleFormSubmit}>
          <BreadCrumbs currentPage={5} />
          <div className="summary__wrap">
            <div className="container">
              <div className="summary__title">
                <h1>
                  {formatMessage(defaultMessages.passengerInformation)}
                </h1>
              </div>
              <div className="summary__content">
                <div className="summary__detail">
                  { hasBSError && (
                    <CriticalMsgDisplay error={bookingSummary.Errors} type="danger" url={bookingSummary.Url || ''} />
                  ) || hasPaxError && (
                    <CriticalMsgDisplay error={paymentDetails.Errors} type="danger" url={paymentDetails.Url || ''} />
                  ) || hasPaymentErrorRes && (
                    <CriticalMsgDisplay error={paymentData.Errors} type="danger" url={paymentData.Url || ''} />
                  ) || paymentErrorResponseCode === '0' && (
                    <CriticalMsgDisplay error={[{ Code: 'RES-0', Value: formatMessage(defaultMessages.RES0) }]} type="warn" />
                  )}
                  <FormContainer
                    formFields={formFields}
                    handleOnChange={this.handleOnChange}
                    handleMobileNumberChange={this.handleMobileNumberChange}
                    generatePaxFields={this.generatePaxFields}
                    updateCardDetails={this.updateCardDetails}
                    paymentDetails={paymentDetails}
                    setPaymentGateWayId={this.setPaymentGatewayId}
                    hasErrorResponse={hasErrorResponse}
                  />
                </div>
                <div className="summary__sidebar">
                  <React.Fragment>
                    <SidebarHotel hotelSummary={hotelSummary} />
                    <SidebarFlight
                      flightSummary={flightSummary}
                      toggleLegInfo={this.toggleLegInfo}
                      selectedLegInfo={selectedLegInfo}
                    />
                    <SidebarSummary
                      summary={sidebarSummary}
                      paxCounts={paxCounts}
                      hasContinueButton={false}
                      canAddTransfer={false}
                    />
                    <DockedFooter
                      summary={sidebarSummary}
                      MainView={SidebarSummary}
                      currency="MYR"
                      cultureCode="en-US"
                    />
                  </React.Fragment>
                </div>
              </div>
            </div>
            <div className="summary__control text-center">
              <button type="submit" className="btn btn-primary btn-lg btn-theme-primary">
                {formatMessage(defaultMessages.confirmNPay)}
              </button>
              <div className="summary__control__text">
                <span>{formatMessage(defaultMessages.confirmNPay_Text1)}</span>
                <span>{formatMessage(defaultMessages.confirmNPay_Text2)}</span>
              </div>
            </div>
          </div>
        </form>
        {formSubmitReady && !hasErrorResponse
          && (<FormRedirection
            paymentData={paymentData}
            setFormSubmit={this.setFormSubmit}
            formSubmitReady={formSubmitReady}
          />
          )}
      </div>
    );
  }
}
export default PageBase(Details);
