import React from 'react';
// @flow
// import { type FormRedirectionTypes } from '../types';
type FormHiddenFieldProps = {
  name: string,
  value: string | number,
};

function FormHiddenField({ name, value }: FormHiddenFieldProps) {
  return <input type="hidden" name={name} value={value} />;
}

export default FormHiddenField;
