import React, { Component } from 'react';
import { defineMessages } from 'react-intl';
import Input from 'components/FormFields/Input';
import { Number, Cvc, Expiration } from 'react-credit-card-primitives';
import ComponentBase, {
  type GenericComponent,
} from '../../../components/ComponentBase';
// @flow
import {
  type CreditCardFormProps, type CreditCardFormState, type EmptyFunctionMethod,
  type SetCardType, type HandleCardField, type IsValidCardField,
  type IsValidExpiredDate, type GetCardIcon, type GetCardTypes,
  type GetPaymentGatewayId,
} from '../types';
// Styles
import './CreditCardForm.scss';

const defaultMessages = defineMessages({
  cardSupported: {
    id: 'CreditCardForm.cardSupported',
    defaultMessage: 'Cards we support',
  },
  cardNumber: {
    id: 'CreditCardForm.cardNumber',
    defaultMessage: 'Card number',
  },
  cardNumberPlaceholder: {
    id: 'CreditCardForm.cardNumberPlaceholder',
    defaultMessage: 'Card number',
  },
  expiryDate: {
    id: 'CreditCardForm.expiryDate',
    defaultMessage: 'Expiry date',
  },
  expiryDatePlaceholder: {
    id: 'CreditCardForm.expiryDatePlaceholder',
    defaultMessage: 'MM / YY',
  },
  cvc: {
    id: 'CreditCardForm.cvc',
    defaultMessage: 'CVC',
  },
  nameOnCard: {
    id: 'CreditCardForm.nameOnCard',
    defaultMessage: 'Name on the card',
  },
  nameOnCardPlaceholder: {
    id: 'CreditCardForm.nameOnCardPlaceholder',
    defaultMessage: 'Enter your name',
  },
});

class CreditCardForm extends Component<CreditCardFormProps, CreditCardFormState> {
  constructor(props: CreditCardFormProps) {
    super(props);
    // property name & form field name should be same
    // eg: email <input name='email'>
    this.state = {
      currentCardType: '', // to check CVC number for card type
    };
  }

  state: CreditCardFormState;

  // set the card type when user enter the card number
  setCardType: SetCardType = (type: string) => {
    this.setState({ currentCardType: type });
  }

  // get the card type when user enter the card number
  getCardType: GetCardType = () => {
    const { currentCardType } = this.state;
    return currentCardType;
  }

  // get card icons when user enters the card number
  getCardIcon: GetCardIcon = (cardType, index) => {
    let cardIcon;
    if (cardType === 'Visa') {
      cardIcon = <img src="../static/imgs/credit-cards/visa.png" alt={cardType} key={index} />;
    } else if (cardType === 'Mastercard') {
      cardIcon = <img src="../static/imgs/credit-cards/mastercard.png" alt={cardType} key={index} />;
    } else if (cardType === 'Maestro') {
      cardIcon = <img src="../static/imgs/credit-cards/maestro.png" alt={cardType} key={index} />;
    } else if (cardType === 'American Express') {
      cardIcon = <img src="../static/imgs/credit-cards/americanexpress.png" alt={cardType} key={index} />;
    } else if (cardType === 'Diners Club') {
      cardIcon = <img src="../static/imgs/credit-cards/dinerclub.png" alt={cardType} key={index} />;
    } else if (cardType === 'Discover') {
      cardIcon = <img src="../static/imgs/credit-cards/discover.png" alt={cardType} key={index} />;
    } else if (cardType === 'JCB') {
      cardIcon = <img src="../static/imgs/credit-cards/JCB.png" alt={cardType} key={index} />;
    } else if (cardType === 'UnionPay') {
      cardIcon = <img src="../static/imgs/credit-cards/unionpay.png" alt={cardType} key={index} />;
    } else if (cardType === 'Dankort') {
      cardIcon = <img src="../static/imgs/credit-cards/dankort.png" alt={cardType} key={index} />;
    } else {
      cardIcon = <img src="../static/imgs/credit-cards/credit-card.png" alt={cardType} key={index} />;
    }
    return cardIcon;
  }

  getCardTypes: GetCardTypes = () => {
    const { paymentDetails } = this.props;
    let supportedCards;
    if (paymentDetails && paymentDetails.length > 0) {
      paymentDetails.forEach((item) => {
        if (item.category === 1) {
          supportedCards = item.paymentOptions.map(elem => (
            elem.type.replace(/\s*,\s*/g, ',') // removes blank space after comma from card name
          )).join(',').split(',');
        }
      });
    }
    return supportedCards;
  }

  getPaymentGatewayId: GetPaymentGatewayId = (cardType: string) => {
    const { paymentDetails, setPaymentGateWayId } = this.props;
    let paymentGTId = '';
    if (paymentDetails && paymentDetails.length > 0) {
      paymentDetails.forEach((item) => {
        if (item.category === 1) {
          /* eslint-disable*/
          // nothing to return
          item.paymentOptions.map((elem) => {
            const cardFound = elem.type.replace(/\s*,\s*/g, ',').search(cardType);
            if (cardFound > -1) {
              paymentGTId = elem.paymentGatewayId;
            }
          });
        }
      });
    }
    setPaymentGateWayId(paymentGTId, cardType);
  }

  // to map the card and its payment gateway id
  mapPaymentIdToCCard: EmptyFunctionMethod = () => {
    const { paymentDetails } = this.props;
    paymentDetails.map(item => (
      item.paymentOptions.map(elem => (
        elem.type
      ))
    ));
  }

  handleCardField: HandleCardField = (value, name, valid, type: '', eventType) => {
    const { creditCardDetails, updateCardDetails } = this.props;
    if (name === 'cardNumber' || name === 'ccv') {
      const { text, message, status } = this.isValidCardField(value, valid, name, type, eventType);
      creditCardDetails[name].value = text;
      creditCardDetails[name].message = message;
      creditCardDetails[name].status = status;
    } else if (name === 'CreditCardExpiryDate') {
      const { message, text, status } = this.isValidExpireDate(value, eventType);
      if (status) {
        creditCardDetails.expiryMonth.value = text.m;
        creditCardDetails.expiryYear.value = text.y;
      }
      creditCardDetails.expiryMonth.status = status;
      creditCardDetails.expiryMonth.message = message;
      creditCardDetails.expiryYear.status = status;
      creditCardDetails.expiryYear.message = message;
    }
    updateCardDetails(creditCardDetails);
  }

  isSupportedCard = (cardType) => {
    let isSupported = false;
    this.getCardTypes().forEach((item) => {
      if (item === cardType && cardType) {
        isSupported = true;
      }
    });
    return isSupported;
  }

  getStatus = (eventType: string) => {
    if (eventType === 'blur') {
      return false;
    }
    return true;
  }

  isValidCardField: IsValidCardField = (value, valid, fieldName, cardType, eventType) => {
    let fieldStatus: FieldStatus<string> = { text: value, message: 'success', status: true };
    const isSupportedCard = this.isSupportedCard(cardType);
    if (fieldName === 'cardNumber' && !valid) {
      fieldStatus = {
        text: value,
        message: 'Please enter a valid card number',
        status: this.getStatus(eventType),
        name: fieldName,
      };
    } else if (fieldName === 'cardNumber' && !isSupportedCard) {
      fieldStatus = {
        text: value,
        message: `Sorry, We don't accept ${cardType}`,
        status: this.getStatus(eventType),
        name: fieldName,
      };
    }
    if (fieldName === 'ccv' && !valid) {
      fieldStatus = {
        text: value,
        message: 'Please enter a correct number',
        status: this.getStatus(eventType),
        name: fieldName,
      };
    }
    return fieldStatus;
  }

  isValidExpireDate: IsValidExpiredDate = (value, eventType): { value: object } => {
    const {
      error,
      year,
      month,
    } = value;
    const fieldStatus: FieldStatus<string> = { message: 'Success', text: { m: month, y: year }, status: true };
    switch (error) {
      case 'err_monthyear':
        fieldStatus.message = 'Please enter valid month and year';
        fieldStatus.status = this.getStatus(eventType);
        break;
      case 'err_month':
        fieldStatus.message = 'Please enter valid month';
        fieldStatus.status = this.getStatus(eventType);
        break;
      case 'err_year':
        fieldStatus.message = 'Please enter valid year';
        fieldStatus.status = this.getStatus(eventType);
        break;
      case 'err_pastdate':
        fieldStatus.message = 'Please enter a date in the future.';
        fieldStatus.status = this.getStatus(eventType);
        break;
      default:
        break;
    }
    return fieldStatus;
  }

  props: CreditCardFormTypes;

  render() {
    const {
      creditCardDetails,
      handleOnChange,
      intl,
    } = this.props;
    const {
      cardHolderName,
      cardNumber,
      ccv,
      expiryMonth,
      expiryYear,
      paymentProcessor,
    } = creditCardDetails;
    const { currentCardType } = this.state;
    const { formatMessage } = intl;
    return (
      <div className="summary__panel__wrap">
        <div className="payment-details__content">
          <p className="cards">
            <span>{formatMessage(defaultMessages.cardSupported)}</span>
            {this.getCardTypes().map((card, index) => (
              this.getCardIcon(card, index.toString())
            ))}
          </p>
          <div className="form__default">
            <div className="form__row">
              <div className="form__group form__group__collect">
                <div className={`${(cardNumber.status || cardNumber.status === undefined) ? '' : 'error-field'} form__group__item ccfield`}>
                  <div className="form__label">
                    <label>
                      {formatMessage(defaultMessages.cardNumber)}
                    </label>
                  </div>
                  <div className="form__input">
                    <Number
                      onChange={({ value, valid, type }) => {
                        this.setCardType(type);
                        this.getPaymentGatewayId(type);
                        this.handleCardField(value, 'cardNumber', valid, type);
                      }}
                      render={({
                        getInputProps,
                        valid,
                        type,
                        value,
                      }) => (
                        <div className="card_number_holder">
                          <input {...getInputProps()} className={`${valid ? '' : 'error'} form__input__control`}
                          placeholder={formatMessage(defaultMessages.cardNumberPlaceholder)}
                          onBlur={() => {
                          this.handleCardField(value, 'cardNumber', valid, type, 'blur');
                          }}
                          type="text"
                          />
                          {this.getCardIcon(type)}
                        </div>
                      )}
                    />
                  </div>
                  {!cardNumber.status && (
                    <span className="error-msg">
                      {cardNumber.message}
                    </span>
                  )}
                  {!paymentProcessor.status && (
                    <span className="error-msg">
                      {paymentProcessor.message}
                    </span>
                  )}
                </div>
              </div>
              <div className="form__group form__group__collect">
                <div className={`${((expiryMonth.status && expiryYear.status) || (expiryMonth.status === undefined && expiryYear.status === undefined)) ? '' : 'error-field'} form__group__item`}>
                  <div className="form__label">
                    <label>
                      {formatMessage(defaultMessages.expiryDate)}
                    </label>
                  </div>
                  <div className="form__input">
                    <Expiration
                      onChange={({
                        month,
                        year,
                        valid,
                        error,
                      }) => {
                        this.handleCardField({ month, year, error }, 'CreditCardExpiryDate', valid);
                      }}
                      render={({
                        getInputProps,
                        valid,
                        year,
                        month,
                        error,
                      }) => (
                        <div>
                          <input
                            {...getInputProps()}
                            className={`${valid ? '' : 'error'} form__input__control`}
                            placeholder={formatMessage(defaultMessages.expiryDatePlaceholder)}
                            maxLength="7"
                            onBlur={(e) => {
                              this.handleCardField({ month, year, error }, 'CreditCardExpiryDate', valid, '', 'blur');
                            }}
                          />
                          <Input
                            handleOnChange={handleOnChange}
                            name="expiryMonth" // should be same as state name
                            type="hidden"
                            validationType="STRING"
                            value={month}
                          />
                          <Input
                            handleOnChange={handleOnChange}
                            name="expiryYear" // should be same as state name
                            type="hidden"
                            validationType="STRING"
                            value={year}
                          />
                        </div>
                      )}
                    />
                  </div>
                  {(!expiryMonth.status || !expiryYear.status) && (
                    <span className="error-msg">
                      {expiryMonth.message || expiryYear.message}
                    </span>
                  )}
                </div>
              </div>

              <div className="form__group form__group__collect">
                <div className={`${(ccv.status || ccv.status === undefined) ? '' : 'error-field'} form__group__item`}>
                  <div className="form__label">
                    <label>
                      {formatMessage(defaultMessages.cvc)}
                    </label>
                  </div>
                  <div className="form__input">
                    <Cvc
                      onChange={({ value, valid }) => {
                        this.handleCardField(value, 'ccv', valid, currentCardType);
                      }}
                      cardType={currentCardType}
                      render={({ getInputProps, value, valid }) => (
                        <div>
                          <input {...getInputProps()}
                            className="form__input__control"
                            type="password"
                            placeholder={formatMessage(defaultMessages.cvc)}
                            onBlur={(e) => {
                              this.handleCardField(value, 'ccv', valid, currentCardType, 'blur');
                            }}
                          />
                          <Input
                            handleOnChange={handleOnChange}
                            name="ccv" // should be same as state name
                            type="hidden"
                            validationType="STRING"
                            value={value}
                          />
                        </div>
                      )}
                    />
                  </div>
                  {!ccv.status && (
                    <span className="error-msg">
                      {ccv.message}
                    </span>
                  )}
                </div>
              </div>
            </div>
            <div className="form__row">
              <div className="form__group">
                <div className={`${(cardHolderName.status || cardHolderName.status === undefined) ? '' : 'error-field'} form__group__item`}>
                  <div className="form__label">
                    <label>
                      {formatMessage(defaultMessages.nameOnCard)}
                    </label>
                  </div>
                  <div className="form__input">
                    <Input
                      handleOnChange={handleOnChange}
                      name="creditCard.cardHolderName" // should be same as state name
                      placeholder={formatMessage(defaultMessages.nameOnCardPlaceholder)}
                      type="text"
                      validationType="CARD_NAME"
                      value={cardHolderName.value}
                    />
                  </div>
                  {!cardHolderName.status && (
                    <span className="error-msg">
                      {cardHolderName.message}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const injection: GenericComponent<CreditCardFormProp> = ComponentBase;

export default injection(CreditCardForm);
