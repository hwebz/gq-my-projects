import React from 'react';
import { defineMessages } from 'react-intl';
import ScrollableAnchor from 'react-scrollable-anchor';
import Input from 'components/FormFields/Input';
import Select from 'components/FormFields/Select';
import Country from 'components/Country';
import DOBDropdown from 'components/FormFields/DOBDropdown';
import ComponentBase, {
  type GenericComponent,
} from '../../../components/ComponentBase';
import './PassengerInfo.scss';
// @flow
import { type PaxInfoTypes } from '../types';

const defaultMessages = defineMessages({
  title: {
    id: 'PassengerInfo.title',
    defaultMessage: '{paxType} #{paxNumber}',
  },
  titleNote: {
    id: 'PassengerInfo.titleNote',
    defaultMessage: 'Passenger {currentPax} of {totalPax}',
  },
  paxTitle: {
    id: 'PassengerInfo.paxTitle',
    defaultMessage: 'Title',
  },
  firstName: {
    id: 'PassengerInfo.firstName',
    defaultMessage: 'First name',
  },
  lastName: {
    id: 'PassengerInfo.lastName',
    defaultMessage: 'Last name',
  },
  passport: {
    id: 'PassengerInfo.passport',
    defaultMessage: 'Passport issuing country',
  },
  dob: {
    id: 'PassengerInfo.dob',
    defaultMessage: 'Date of birth',
  },
});

const PassengerInfo = (props: PaxInfoTypes) => {
  const {
    paxIndex, paxFields, handlePaxChange,
    personInfo, totalPassengers, titleOptions,
    setDOB, intl,
  } = props;
  const { type } = personInfo;
  let firstName: string = '';
  let lastName: string = '';
  let title: string = '';
  let nationality: string = '';
  let DOB: string = '';
  if (paxFields.length > 0 && paxFields !== undefined) {
    // eslint-disable-next-line prefer-destructuring
    firstName = paxFields[paxIndex].firstName;
    // eslint-disable-next-line prefer-destructuring
    lastName = paxFields[paxIndex].lastName;
    // eslint-disable-next-line prefer-destructuring
    title = paxFields[paxIndex].title;
    // eslint-disable-next-line prefer-destructuring
    nationality = paxFields[paxIndex].nationality;
    // eslint-disable-next-line prefer-destructuring
    DOB = paxFields[paxIndex].dob;
  }
  const { formatMessage } = intl;
  // list of props needed
  // Title options, totalpax and pax index, nationality, DOB with options
  return (
    <ScrollableAnchor id={`passenger${paxIndex}`}>
      <div className="summary__panel">
        <div className="summary__panel__title">
          <div className="title-text">
            <h2>
              {formatMessage(
                defaultMessages.title,
                { paxType: type, paxNumber: parseInt(paxIndex, 10) + 1 },
              )}
            </h2>
          </div>
          <div className="title-note">
            <span>
              {formatMessage(
                defaultMessages.titleNote,
                { currentPax: parseInt(paxIndex, 10) + 1, totalPax: totalPassengers },
              )}
            </span>
          </div>
        </div>
        <div className="summary__panel__content">
          <div className="summary__panel__wrap">
            <div className="form__default">
              <div className="form__row">
                <div className="form__group form__group__collect">
                  <div
                    className={`${
                      title.status || title.status === undefined ? '' : 'error-field'
                    } form__group__item form__size__title`}
                  >
                    <div className="form__label">
                      <label>
                        {formatMessage(defaultMessages.paxTitle)}
                      </label>
                    </div>
                    <div className="form__input">
                      <Select
                        name={`title.${paxIndex}`}
                        handleOnChange={handlePaxChange}
                        placeholder=""
                        type="text"
                        validationType="STRING"
                        options={titleOptions}
                        fieldType="DROPDOWN"
                        value={title.value}
                      />
                    </div>
                    {!title.status && (
                    <span className="error-msg">
                      {title.message}
                    </span>
                    )}
                  </div>
                  <div
                    className={`${
                      firstName.status || firstName.status === undefined ? '' : 'error-field'
                    } form__group__item`}
                  >
                    <div className="form__label">
                      <label>
                        {formatMessage(defaultMessages.firstName)}
                      </label>
                    </div>
                    <div className="form__input">
                      <Input
                        handleOnChange={handlePaxChange}
                        name={`firstName.${paxIndex}`}
                        type="text"
                        validationType="NAME"
                        value={firstName.value}
                      />
                    </div>
                    {!firstName.status && (
                    <span className="error-msg">
                      {firstName.message}
                    </span>
                    )}
                  </div>
                </div>
                <div
                  className={`${
                    lastName.status || lastName.status === undefined ? '' : 'error-field'
                  } form__group`}
                >
                  <div className="form__label">
                    <label>
                      {formatMessage(defaultMessages.lastName)}
                    </label>
                  </div>
                  <div className="form__input">
                    <Input
                      handleOnChange={handlePaxChange}
                      name={`lastName.${paxIndex}`}
                      type="text"
                      validationType="NAME"
                      value={lastName.value}
                    />
                  </div>
                  {!lastName.status && (
                  <span className="error-msg">
                    {lastName.message}
                  </span>
                  )}
                </div>
              </div>
              <div className="form__row">
                <div
                  className={`${
                    nationality.status || nationality.status === undefined ? '' : 'error-field'
                  } form__group`}
                >
                  <div className="form__label">
                    <label>
                      {formatMessage(defaultMessages.passport)}
                    </label>
                  </div>
                  <div className="form__input">
                    <Country
                      name={`nationality.${paxIndex}`}
                      type="countries-only"
                      value={nationality.value || ''}
                      handleOnChange={handlePaxChange}
                    />
                  </div>
                  {!nationality.status && (
                  <span className="error-msg">
                    {nationality.message}
                  </span>
                  )}
                </div>
                <DOBDropdown
                  personInfo={personInfo}
                  handlePaxChange={handlePaxChange}
                  setDOB={setDOB}
                  title={formatMessage(defaultMessages.dob)}
                  DOBStatus={DOB}
                  paxIndex={paxIndex}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </ScrollableAnchor>
  );
};

const injection: GenericComponent<PassengerInfoProp> = ComponentBase;

export default injection(PassengerInfo);
