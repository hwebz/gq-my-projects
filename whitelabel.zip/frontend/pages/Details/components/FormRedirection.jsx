import React, { Component } from 'react';
import { FormattedMessage } from 'react-intl';
import Router from 'next/router';
import TravelLoadingAnimation from 'components/TravelLoadingAnimation';
import './FormRedirection.scss';
import FormHiddenField from './FormHiddenField';
import { apiDomain } from '../../../services/services';
// @flow
import { type FormRedirectionTypes, type EmptyFunctionMethod, type FormData } from '../types';

// const FormRedirection = ({ paymentData, handleFakeFormSubmit }: FormRedirectionTypes) => {
class FormRedirection extends Component<FormRedirectionTypes> {
  constructor(props: FormRedirectionTypes) {
    super(props);
    this.autoFormSubmit = React.createRef();
  }

  componentDidUpdate() {
    this.handleFakeFormSubmit();
  }

  generateHiddenFields = (formData: FormData) => Object.keys(formData).map((name) => {
    let value;
    if (typeof formData[name] === 'object') {
      value = JSON.stringify(formData[name]);
    } else {
      value = formData[name].toString();
    }
    return <FormHiddenField key={name} name={name} value={value} />;
  });

  handleFakeFormSubmit: EmptyFunctionMethod = () => {
    const { paymentData, setFormSubmit, formSubmitReady } = this.props;
    const { redirectURL } = paymentData;
    if (redirectURL) {
      // const paymentURL = `http://dp-4976.feature.goquo.vn${redirectURL}`; // HARDCODE for LOCAL HOST ONLY
      const paymentURL = `${apiDomain}${redirectURL.replace(/^\//, '')}`; // regex is to remove first backward slash from the urls
      Router.push(paymentURL);
    } else if (formSubmitReady) {
      setFormSubmit(false);
    }
  };

  props: FormRedirectionTypes;
  render() {
    const { paymentData, formSubmitReady } = this.props;
    let paymentRedirectUrl = '';
    if (paymentData) {
      paymentRedirectUrl = paymentData.data;
    }
    return (
      <React.Fragment>
        {formSubmitReady && (
          <div className="paymentform">
            <div className="paymentform__container">
              <div className="paymentform__top">
                <TravelLoadingAnimation />
              </div>
              <div className="paymentform__bottom">
                <h1>
                  <FormattedMessage
                    id="FormRedirection.text_1"
                    defaultMessage="Great!"
                  />
                </h1>
                <p>
                  <FormattedMessage
                    id="FormRedirection.text_2"
                    defaultMessage="We are processing your payment, Please wait..."
                  />
                </p>
                {paymentData
                  && paymentData.data && (
                    <form
                      action={paymentRedirectUrl}
                      method="POST"
                      onSubmit={this.handleFakeFormSubmit}
                      ref={this.autoFormSubmit}
                    />
                )}
              </div>
            </div>
          </div>
        )}
      </React.Fragment>
    );
  }
}

export default FormRedirection;
