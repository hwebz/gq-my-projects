import React from 'react';
import { FormattedMessage } from 'react-intl';
import ScrollableAnchor from 'react-scrollable-anchor';
// @flow
import type { PaymentDetailsTypes } from '../types';
import './PaymentDetails.scss';
import CreditCardForm from './CreditCardForm';

const PaymentDetails = ({
  creditCardDetails,
  handleOnChange,
  updateCardDetails,
  paymentDetails,
  setPaymentGateWayId,
}: PaymentDetailsTypes) => {
  const paymentMethods = [];
  const errorMessage = [];
  if (paymentDetails && paymentDetails.length > 0) {
    paymentDetails.forEach((item) => {
      if (item.category === 1) {
        paymentMethods.push('Credit Cards');
      } else if (item.Code) {
        errorMessage.push(item.Value);
      }
    });
  }
  return (
    <ScrollableAnchor id="creditCard">
      <div className="summary__panel__content">
        <div className="summary__panel__caption">
          <h3>
            <FormattedMessage
              id="PaymentDetails.securePayment"
              defaultMessage="Secure Payment Process"
            />
          </h3>
        </div>
        { paymentMethods.length > 1 && (
          <React.Fragment>
            <div className="summary__panel__caption">
              <div className="payment-details__header">
                <div className="payment-details__title">
                  <FormattedMessage
                    id="PaymentDetails.selectPayment"
                    defaultMessage="Select your payment method"
                  />
                </div>
                <div className="payment-details__nav">
                  { paymentMethods.map((item, index) => (
                    <div key={item} className={`${index === 0 ? 'active' : ''} payment-details__nav__item`}>
                      <strong>
                        {item}
                      </strong>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </React.Fragment>
        )}
        <CreditCardForm
          creditCardDetails={creditCardDetails}
          handleOnChange={handleOnChange}
          updateCardDetails={updateCardDetails}
          paymentDetails={paymentDetails}
          setPaymentGateWayId={setPaymentGateWayId}
        />
      </div>
    </ScrollableAnchor>
  );
};
export default PaymentDetails;
