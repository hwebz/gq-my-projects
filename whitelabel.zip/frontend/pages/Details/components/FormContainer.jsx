import React from 'react';
// @flow
import { type FormContainerProps } from '../types';
import ContactDetails from './ContactDetails';
import PaymentDetails from './PaymentDetails';
// styles
import './FormContainer.scss';

function FormContainer({
  formFields,
  handleOnChange,
  handleMobileNumberChange,
  generatePaxFields,
  updateCardDetails,
  paymentDetails,
  setPaymentGateWayId,
  hasErrorResponse,
}: FormContainerProps) {
  return (
    <div>
      <ContactDetails
        contactDetail={formFields.contactDetail}
        handleOnChange={handleOnChange}
        handleMobileNumberChange={handleMobileNumberChange}
      />
      {generatePaxFields()}
      { paymentDetails && !hasErrorResponse && (
        <PaymentDetails
          creditCardDetails={formFields.creditCard}
          handleOnChange={handleOnChange}
          updateCardDetails={updateCardDetails}
          paymentDetails={paymentDetails}
          setPaymentGateWayId={setPaymentGateWayId}
        />
      )}
    </div>
  );
}
export default FormContainer;
