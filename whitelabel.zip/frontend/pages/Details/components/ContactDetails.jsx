import React from 'react';
import { defineMessages } from 'react-intl';
import ScrollableAnchor from 'react-scrollable-anchor';
import './ContactDetails.scss';
import { IoAndroidAlert as IconAlert } from 'react-icons/io';
import Input from 'components/FormFields/Input';
import Country from 'components/Country';
import ComponentBase, {
  type GenericComponent,
} from '../../../components/ComponentBase';
// @flow
import { type ContactDetailsTypes } from '../types';

const defaultMessages = defineMessages({
  title: {
    id: 'ContactDetails.title',
    defaultMessage: 'Contact details',
  },
  fieldsRequired: {
    id: 'ContactDetails.fieldsRequired',
    defaultMessage: 'All fields are required',
  },
  firstName: {
    id: 'ContactDetails.firstName',
    defaultMessage: 'First Name',
  },
  lastName: {
    id: 'ContactDetails.lastName',
    defaultMessage: 'Last Name',
  },
  namePlaceholder: {
    id: 'ContactDetails.namePlaceholder',
    defaultMessage: 'Enter your name',
  },
  nameNote: {
    id: 'ContactDetails.nameNote',
    defaultMessage: 'Should we need to contact you with any updates related to this booking, this is the person we’ll be reaching out to.',
  },
  email: {
    id: 'ContactDetails.email',
    defaultMessage: 'Email address',
  },
  emailPlaceholder: {
    id: 'ContactDetails.emailPlaceholder',
    defaultMessage: 'Enter valid email',
  },
  emailNote: {
    id: 'ContactDetails.emailNote',
    defaultMessage: 'We’ll send your receipts and travel itineraries to this email address. Please ensure that its correct',
  },
  phone: {
    id: 'ContactDetails.phone',
    defaultMessage: 'Mobile number',
  },
  phoneNote: {
    id: 'ContactDetails.phoneNote',
    defaultMessage: 'In case of any last-minute changes, or updates, we’ll reach out to you at this number.',
  },
});

function ContactDetails(props: ContactDetailsTypes) {
  const {
    contactDetail, handleOnChange,
    handleMobileNumberChange, intl,
  } = props;
  const {
    firstName,
    lastName,
    email,
    contactNumber,
  } = contactDetail;
  const { formatMessage } = intl;
  return (
    <ScrollableAnchor id="contactDetail">
      <div className="summary__panel">
        <div className="summary__panel__title">
          <div className="title-text">
            <h2>{formatMessage(defaultMessages.title)}</h2>
          </div>
          <div className="title-note color-danger">
            <span>{formatMessage(defaultMessages.fieldsRequired)}</span>
          </div>
        </div>
        <div className="summary__panel__content">
          <div className="summary__panel__wrap">
            <div className="form__default">
              <div className="form__row">
                <div className="form__column-group">
                  <div className={`${(firstName.status || firstName.status === undefined) ? '' : 'error-field'} form__group`}>
                    <label htmlFor="name" className="form__label">
                      {formatMessage(defaultMessages.firstName)}
                    </label>
                    <div className="form__input">
                      <Input
                        handleOnChange={handleOnChange}
                        name="contactDetail.firstName" // should be same as state name
                        type="text"
                        validationType="NAME"
                        value={firstName.value}
                      />
                    </div>
                    {!firstName.status && (
                      <span className="error-msg">
                        {firstName.message}
                      </span>
                    )}
                  </div>
                  <div className={`${(lastName.status || lastName.status === undefined) ? '' : 'error-field'} form__group`}>
                    <label htmlFor="name" className="form__label">
                      {formatMessage(defaultMessages.lastName)}
                    </label>
                    <div className="form__input">
                      <Input
                        handleOnChange={handleOnChange}
                        name="contactDetail.lastName" // should be same as state name
                        type="text"
                        validationType="NAME"
                        value={lastName.value}
                      />
                    </div>
                    {!lastName.status && (
                      <span className="error-msg">
                        {lastName.message}
                      </span>
                    )}
                  </div>
                </div>
                <div className="form__group">
                  <div className="form__alert">
                    <i>
                      <IconAlert />
                    </i>
                    <span>
                      {formatMessage(defaultMessages.nameNote)}
                    </span>
                  </div>
                </div>
              </div>
              <div className="form__row">
                <div className={`${(email.status || email.status === undefined) ? '' : 'error-field'} form__group`}>
                  <label htmlFor="email" className="form__label">
                    {formatMessage(defaultMessages.email)}
                  </label>
                  <div className="form__input">
                    <Input
                      handleOnChange={handleOnChange}
                      name="contactDetail.email"
                      type="text"
                      validationType="EMAIL"
                      value={email.value}
                    />
                  </div>
                  {!email.status && (
                    <span className="error-msg">
                      {email.message}
                    </span>
                  )}
                </div>
                <div className="form__group">
                  <div className="form__alert">
                    <i>
                      <IconAlert />
                    </i>
                    <span>
                      {formatMessage(defaultMessages.emailNote)}
                    </span>
                  </div>
                </div>
              </div>
              <div className="form__row">
                <div className={`${(contactNumber.status || contactNumber.status === undefined) ? '' : 'error-field'} form__group`}>
                  <label htmlFor="contactDetail.contactNumber" className="form__label">
                    {formatMessage(defaultMessages.phone)}
                  </label>
                  <div className="form__input">
                    <Country
                      type="with-phonecode"
                      value={contactNumber.value}
                      handleOnChange={handleOnChange}
                      handleMobileNumberChange={handleMobileNumberChange}
                      name="contactNumber"
                    />
                  </div>
                  {!contactNumber.status && (
                    <span className="error-msg">
                      {contactNumber.message}
                    </span>
                  )}
                </div>

                <div className="form__group">
                  <div className="form__alert">
                    <i>
                      <IconAlert />
                    </i>
                    <span>
                      {formatMessage(defaultMessages.phoneNote)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ScrollableAnchor>
  );
}

const injection: GenericComponent<ContactDetailsProp> = ComponentBase;

export default injection(ContactDetails);
