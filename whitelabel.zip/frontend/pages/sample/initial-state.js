// @flow
import { type SampleState } from './types';

const state: SampleState = {
  departureDate: '',
  returnDate: '',
  from: '',
  to: '',
};

export default state;
