// @flow
export type TestState = {
  testStateValue: number,
}

export type TestProps = {
  testValue: number,
  intl: any,
}
