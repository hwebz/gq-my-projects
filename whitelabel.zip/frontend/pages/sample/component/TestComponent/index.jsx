// @flow

import React from 'react';
import { type TestProps } from './types';
import ComponentBase, { type GenericComponent } from '../../../../components/ComponentBase';

function TestComponent(props: TestProps) {
  const { testValue /* cultureCode, intl */ } = props;
  // console.log(intl); // by default return react-intl injected intl prop
  // console.log(cultureCode); // will Return Culture Code because flag is true
  return (
    <span>
      This is on Test Component
      {`${testValue}`}
    </span>
  );
}

const injection: GenericComponent<TestProps> = ComponentBase;

export default injection(TestComponent, {
  hasCultureCode: true,
  mapStateToProps: undefined,
});
