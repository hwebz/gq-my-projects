import React from 'react';
import Link from 'next/link';
import DateFormat from 'components/DateFormat';
import { Feature } from '@paralleldrive/react-feature-toggles';
import { FormattedMessage } from 'react-intl';

import NumberFormat from 'components/NumberFormat';
// import actionTypes from 'store-app/modules/alert/action-types';
import PageBase from '../PageBase';
// import ErrorHandler from '../../client-error';

// @flow
import { qsMessages, getFormattedMessage } from '../../utils/query/validation/FormattedMessages';
import TestComponent from './component/TestComponent';
// import { type TestProps, type TestState } from './component/TestComponent/types';
import { type SampleProps, type SampleState } from './types';
// This was added during testing
// import { getErrorFormattedMessages } from '../../utils/api-error';

// import { type ErrorResponse } from '../../store-app/modules/alert/types';
import { type EDateFormat } from '../../components/DateFormat/types';
// This Is Suppose to be A Test Components with some props
class Sample extends React.Component<SampleProps, SampleState> {
  // static async getInitialProps(context) {
  //   const { ctx: { store } } = context;

  //   console.log("Test Raven Logging");

  //   return {
  //     ...this.props,
  //   };
  // }

  componentDidMount() {
    // Following are test codes
    /*/
    const {
      selectedCurrency,
      dispatch,
    } = this.props;

    const error: ErrorResponse = {
      errorCodes: [{ code: 'E138' }, { code: 'E139' }],
      url: '/',
    };
    /*/
    /*/
    dispatch({
      type: actionTypes.SHOW_ALERT,
      payload: { FormattedMessages: getErrorFormattedMessages(error), url: '/' },
    });
    /*/
    // Working
    // console.log('componentDidMount');
    // console.log(selectedCurrency);
  }

  render() {
    // TODO: Sample For Date Format and Localisation
    // Can use intl here
    // const { intl } = this.props;
    const {
      cultureCode,
      urlLocale,
      selectedCurrency, // config // not being used
    } = this.props;
    // This is not stateless class

    // TODO: Make This into LocalizedLink
    // Note Second Condition is because locale en is a fallback for failed translation
    /*/
    const urlLocale = ((cultureCode === config.general.defaultLanguage)
      ? ''
      : `/${cultureCode}`).toLowerCase();
    /*/
    // ErrorHandler.logInfo('This Is Working For Info??', { page: 'Sample' });

    const testValue = 'This is Test Value';
    console.log('Url Locale', urlLocale);
    return (
      <div>
        <h1>
          This is the Sample Page. The prop is
          <Link href={{ pathname: '/sample2' }} as={`${urlLocale}/sample2?currency=USD`}>
            Here
          </Link>
          to read more
        </h1>
        <FormattedMessage
          id="sample.greetings"
          defaultMessage={
            'Hello {name}, you have {unreadCount, number} {unreadCount, plural, one {message} other {messages}}'
          }
          values={{ name: 'Wilson', unreadCount: 10 }}
        />
        <FormattedMessage
          id="sample.greetings2"
          defaultMessage={
            'Hello {name}, you have {unreadCount, number} {unreadCount, plural, one {message} other {messages}}'
          }
          values={{ name: 'Wilson', unreadCount: 10 }}
        />
        <DateFormat value="1987-08-02" format={('LONG': EDateFormat)} locale={`${cultureCode}`} />
        <NumberFormat value="3000.00" currency="MYR" locale={`${cultureCode}`} />

        {getFormattedMessage(qsMessages.ROOM_INFANT_EXCEED_ADULT.id, { test: 'Whatever' })}

        <Feature
          name="noSuchFeature"
          activeComponent={() => (
            <span>
              Sample For Simple HTML Stuff
              {`${testValue}`}
            </span>
          )}
          inactiveComponent={() => (
            <span>
Inactive Component
            </span>
          )}
        />

        <br />
        <Feature name="useFlightList" activeComponent={() => <TestComponent testValue={10} />} />
        <span>
          Current Selected Currency:
          {`${selectedCurrency}`}
        </span>
      </div>
    );
    /*/
    <button onClick = {(e) => { e.stopPropagation(); this.props.handleAlertBox() }
  }> Open alert</button>
    /*/
    // {<Alert isAlertOpen message={"aher aher"} />}
  }
}

export default PageBase(Sample, { isFeatured: true });
