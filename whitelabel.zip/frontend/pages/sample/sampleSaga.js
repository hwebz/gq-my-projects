import axios from 'axios';
import {
  all, fork, put, takeLatest,
} from 'redux-saga/effects';
import { actionTypes, failure, getClientConfigDataSuccess } from './actions';
import services from '../../services/services'; // all api services can be accessed

function* getClientConfigSaga() {
  try {
    const { data } = yield axios(services.getConfig);
    yield put(getClientConfigDataSuccess(data));
  } catch (err) {
    yield put(failure(err));
  }
}

export default function* sampleSaga() {
  yield all([
    fork(takeLatest, actionTypes.GET_CLIENT_CONFIG, getClientConfigSaga),
  ]);
}
