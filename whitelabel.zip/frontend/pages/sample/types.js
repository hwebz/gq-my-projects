/**
 * @flow
 */
import { type Config } from 'flow-types';

export * from '../../flow-types';

export type SampleState = {
  departureDate: string,
  returnDate: string,
  from: string,
  to: string,
}

export type SampleProps = {
  config: Config,
  cultureCode: string,
  intl: any,
}
