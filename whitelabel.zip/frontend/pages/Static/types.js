// @flow
import { type IntlShape } from 'react-intl';
import { type Config } from '../../flow-types';
import { type PageBaseProps } from '../PageBase/types';

export type StaticQueryParams = {
  slug: string,
};

export type StaticPageProps = PageBaseProps<StaticQueryParams> & {
  htmlContent: string,
  title: string,
  intl: IntlShape,
  config: Config,
};

export type StaticPageRequestModel = {
  slug: string,
  lang: string,
}
