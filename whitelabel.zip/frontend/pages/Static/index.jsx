import React from 'react';
import { defineMessages } from 'react-intl';
import { connect } from 'react-redux';
import scrollIntoView from 'scroll-into-view';
import { Helmet } from 'react-helmet';
import Router from 'next/router';
import PageBase from '../PageBase';

import { hasMissingQuery } from '../../react-next/utils/query-string';
import { getStatic } from '../../store-app/modules/static-page/actions';
import { getStaticHtml, getTitle } from '../../store-app/modules/static-page/selectors';

import './static.scss';

// @flow
import { type Context } from '../../flow-types';
import { type StaticPageProps, type StaticPageRequestModel, type StaticQueryParams } from './types';


const defaultMessages = defineMessages({
  staticDefaultPageTitle: {
    id: 'static.defaultPageTitle',
    defaultMessage: 'Welcome',
  },
});

class StaticPage extends React.Component<StaticPageProps> {
  componentDidMount() {
    if (typeof window !== 'undefined') {
      const { htmlContent } = this.props;
      if (!htmlContent) {
        Router.push('/error/404', window.location.href);
      }

      const {
        location: { hash },
      } = window;

      if (hash) {
        const target = document.querySelector(hash);
        if (target) {
          setTimeout(
            () => scrollIntoView(target, {
              time: 200,
              align: {
                top: 0,
                topOffset: 5,
              },
            }),
            100,
          );
        }
      }
    }
  }

  static async getInitialProps({ ctx }: Context<StaticQueryParams>) {
    // Gets query params from url
    const {
      store,
      initPayload: { combinedQueryParams, cultureCode },
      isServer,
    } = ctx;
    console.log('Static Page getInitialProps', combinedQueryParams);
    const hasQueryError: boolean = hasMissingQuery(combinedQueryParams, ['slug']);
    if (!hasQueryError) {
      const staticPageRequestModel: StaticPageRequestModel = {
        slug: combinedQueryParams.slug,
        lang: cultureCode,
      };
      //*/
      await store.execSagaTasks(isServer, (dispatch) => {
        dispatch(getStatic(staticPageRequestModel));
      });
      //*/
      return { hasQueryError, staticPageRequestModel };
    }
    return { hasQueryError };
  }

  render() {
    const {
      htmlContent, config, title, intl,
    } = this.props;
    const { formatMessage } = intl;
    const siteName: string = config.general.name;

    return (
      <div>
        <Helmet>
          <title>
            {`${title || formatMessage(defaultMessages.staticDefaultPageTitle)} | ${siteName}`}
          </title>
        </Helmet>
        <div
          className="static-content container"
          /* eslint-disable react/no-danger */
          dangerouslySetInnerHTML={{ __html: htmlContent }}
          /* eslint-enable react/no-danger */
        />
      </div>
    );
  }
}

const mapStateToProps = state => ({
  htmlContent: getStaticHtml(state),
  title: getTitle(state),
});

export default connect(mapStateToProps)(PageBase(StaticPage, { hasCurrencySwitcher: false }));
