import React from 'react';
/*
In production the stylesheet is compiled to .next/static/style.css.
The file will be served from /_next/static/style.css
You could include it into the page using either next/head or a custom _document.js.
*/
import Document, { Head, Main, NextScript } from 'next/document';
import flush from 'styled-jsx/server';
import Helmet from 'react-helmet';
import en from 'react-intl/locale-data/en';

// @flow
import IntlUtils from 'react-next/utils/intl-utils';
import EventTrackingManager from '../components/EventTrackingManager';

export default class WhiteLabel extends Document {
  static async getInitialProps(context) {
    const props = await super.getInitialProps(context);
    let { req: { locale, localeDataScript } } = context;
    const { req: { config } } = context;

    if (!locale || !localeDataScript) {
      locale = 'en-US';
      localeDataScript = en;
    }

    return {
      ...props,
      locale,
      localeDataScript,
      config,
      helmet: Helmet.renderStatic(),
    };
  }

  // should render on <html>
  get helmetHtmlAttrComponents() {
    return this.props.helmet.htmlAttributes.toComponent();
  }

  // should render on <body>
  get helmetBodyAttrComponents() {
    return this.props.helmet.bodyAttributes.toComponent();
  }

  // should render on <head>
  get helmetHeadComponents() {
    return Object.keys(this.props.helmet)
      .filter(el => el !== 'htmlAttributes' && el !== 'bodyAttributes')
      .map(el => this.props.helmet[el].toComponent());
  }

  // eslint-disable-next-line class-methods-use-this
  get helmetJsx() {
    return (
      <Helmet title="Welcome" meta={[{ name: 'description', content: 'Book a package' }]} />
    );
  }

  render() {
    const {
      locale,
      localeDataScript,
      config,
    } = this.props;
    const polyfill = `https://cdn.polyfill.io/v2/polyfill.min.js?features=Intl.~locale.${IntlUtils.cultureCodeToISO(locale)}`;
    const style = flush(); // SSR styles
    return (
      <html lang={locale} {...this.helmetHtmlAttrComponents}>
        <Head>
          {this.helmetJsx}
          {this.helmetHeadComponents}
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" />
          <link rel="stylesheet" href="/_next/static/style.css" />
          { config && config.environment && EventTrackingManager(config.environment) }
          { style }
        </Head>
        <body {...this.helmetBodyAttrComponents}>
          <Main />
          <script src={polyfill} />
          <script
            // eslint-disable-next-line react/no-danger
            dangerouslySetInnerHTML={{
              __html: localeDataScript,
            }}
          />
          <NextScript />
        </body>
      </html>
    );
  }
}
