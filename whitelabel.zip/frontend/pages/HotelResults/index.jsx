// @flow
import React, { Component } from 'react';
import { goToAnchor } from 'react-scrollable-anchor';
import dynamic from 'next/dynamic';
import { Helmet } from 'react-helmet';
/* eslint-disable */
import { differenceInDays } from 'date-fns';
// $FlowIgnore because there is no flow types for css
import 'mapbox-gl/dist/mapbox-gl.css';
// import queryString from 'query-string';
import { FormattedMessage } from 'react-intl';

import { type HotelFilterOption } from 'flow-types';
import InitialLoadingStyle from '../../utils/initialLoading';
import ValidateQuery from '../../utils/query/validation';
import PageBase from '../PageBase';

import { getSearchDestinationCityName } from '../../store-app/modules/search-form/selectors';
import { getHotelResultsAppState } from '../../store-app/modules/hotel-list/selectors';
import {
  type HotelResultProps,
  type HotelResultState,
  type ValidatedQuery,
  type HotelFilterUpdate,
  type EHotelFilterKey,
  type StandardEventFunction,
  type HotelResultsQueryParams,
  type MapCoordinates,
  type Context,
} from './types';

import './HotelResults.scss';
import { hotelResultTemplate } from './HotelResultTemplate';
import {
  createPackage,
  getFilteredHotels,
  changeFilter,
  resetFilter,
  handleDropdownClass,
  setPage,
  getMapHotel,
  handleInputRangeChange,
} from '../../store-app/modules/hotel-list/actions';

import { getAirportRequest } from '../../store-app/modules/search-form/actions';
import { qsMessages } from '../../utils/query/validation/FormattedMessages';

const track = require('../../react-next/utils/track-utils');

const HotelResultPage = dynamic(import('./HotelResultTemplate'), {
  loading: () => hotelResultTemplate,
  ssr: false,
});

class HotelResults extends Component<HotelResultProps, HotelResultState> {
  constructor(props: HotelResultProps) {
    super(props);
    this.state = {
      openMobileItemClass: '',
      toggleMapView: false,
      hasError: false,
      selectedHotelGalleryId: '',
      changedVQ: false,
      validatedQueryState: props.validatedQuery,
      firstPageLoad: true,
    };
  }

  state: HotelResultState;

  componentDidMount() {
    const {
      validatedQuery,
      searchForm,
    } = this.props;
    const { validatedQueryState } = this.state;
    const { airportNameFailureType } = searchForm;
    if (!airportNameFailureType) {
      const error = this.checkErrors(validatedQueryState);
      if (!error) {
        this.handleCreatePackage();
      }
    } else {
      // This is to show error alert when user enter wrong origin/ destination code
      const newValidatedQuery = {
        validDepartDate: validatedQuery.validDepartDate,
        validReturnDate: validatedQuery.validReturnDate,
        validPax: validatedQuery.validPax,
        validOrigin:
          airportNameFailureType === 'origin'
            ? {
              message: qsMessages.INVALID_ORIGIN.id,
              status: 0,
              value: validatedQuery.validOrigin.value,
            }
            : validatedQuery.validOrigin,
        validDestination:
          airportNameFailureType === 'destination'
            ? {
              message: qsMessages.INVALID_DESTINATION.id,
              status: 0,
              value: validatedQuery.validDestination.value,
            }
            : validatedQuery.validDestination,
      };
      this.setState({
        validatedQueryState: newValidatedQuery,
        changedVQ: true,
      });
      this.checkErrors(validatedQueryState);
    }
  }

  componentDidUpdate(prevProps) {
    const { toggleMapView } = this.state;
    const {
      hotelResultsMSP,
      selectedCurrency,
      validatedQuery,
      dispatch,
    } = this.props;
    const { validatedQueryState } = this.state;
    const { currentCoordinates, inputRangeChangeDone } = hotelResultsMSP;
    // Need to call api when search date different
    if (prevProps.validatedQuery !== validatedQuery) {
      if (!this.checkErrors(validatedQueryState)) {
        this.handleCreatePackage();
        dispatch(
          getAirportRequest({
            origin: validatedQueryState.validOrigin.value,
            destination: validatedQueryState.validDestination.value,
          }),
        );
      }
    }

    if (
      prevProps.hotelResultsMSP.filterOption !== hotelResultsMSP.filterOption
      && inputRangeChangeDone
    ) {
      if (toggleMapView) {
        this.handlGetMapHotel(currentCoordinates, false);
        dispatch(handleDropdownClass(''));
      } else {
        this.handleHotelApiQuery('FILTER_OPTION');
      }
      // because when filter options change current page shall be reset to first page
    } else if (prevProps.hotelResultsMSP.currentPage !== hotelResultsMSP.currentPage) {
      this.handleHotelApiQuery('PAGE');
    }
    // when user changes currency
    if (prevProps.selectedCurrency !== selectedCurrency && prevProps.selectedCurrency) {
      this.handleCreatePackage();
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    // This is to update the state that will
    // show error alert when user enter wrong origin/ destination code
    if (prevState.changedVQ) {
      return {
        changedVQ: false,
        validatedQueryState: prevState.validatedQueryState,
        hasError: true,
      };
    }
    // To check if validatedQuery have changed and assign to state
    if (prevState.validatedQueryState !== nextProps.validatedQuery) {
      return {
        validatedQueryState: nextProps.validatedQuery,
      };
    }
    const { firstPageLoad } = prevState;
    const {
      hotelResultsMSP,
      router,
      combinedQueryParams,
      defaultConfig,
    } = nextProps;
    const { apiResponse, isNoHotelResult } = hotelResultsMSP;
    const { totalHotels } = apiResponse;
    // page tracking
    const { destination, origin, depart } = combinedQueryParams;
    if (firstPageLoad && hotelResultsMSP.isComplete) {
      const daysAheadToFly = differenceInDays(new Date(depart), new Date());
      track.page(
        router.pathname,
        defaultConfig.environment,
        {
          Origin: origin,
          Destination: destination,
          DaysAhead: daysAheadToFly,
          HasHotelFound: !isNoHotelResult,
          HotelsFound: totalHotels,
        },
      );
      return {
        firstPageLoad: false,
      };
    }

    return null;
  }

  static async getInitialProps({ ctx }: Context<HotelResultsQueryParams>) {
    // Gets query params from url
    console.log('Initial Props Hotel Results');
    const { initPayload, store, isServer } = ctx;
    const { config, combinedQueryParams } = initPayload;
    // const { query } = queryString.parseUrl(asPath);
    // const qs = asPath.split('?');
    // const queryPar = querystring.parse(qs[1]);
    // console.log(queryPar);
    // let { validatedQuery } = this.state
    const validatedQuery: ValidatedQuery = ValidateQuery(combinedQueryParams, config.general);
    await store.execSagaTasks(isServer, (dispatch) => {
      dispatch(
        getAirportRequest({
          origin: validatedQuery.validOrigin.value,
          destination: validatedQuery.validDestination.value,
        }),
      );
    });
    const isClientSide = isServer === false; // This is for searchForm's getDerivedStateToProps
    return { combinedQueryParams, validatedQuery, isClientSide };
  }

  getTotalPages = (totalHotels, pageSize) => {
    let totalPages = 0;
    if (totalHotels) {
      totalPages = Math.ceil(parseInt(totalHotels, 10) / pageSize);
    }
    return totalPages;
  };

  /**
   * Open navigation bar for mobile item
   * @type {StandardEventFunction}
   * @memberof HotelResults
   */
  handleOpenMobileItem: StandardEventFunction = (
    e: SyntheticEvent<HTMLElement>,
    value: string,
    isDisabled?: boolean = false,
  ) => {
    e.stopPropagation();
    if (!isDisabled) {
      this.setState({ openMobileItemClass: value });
      if (value === 'navbar-mapView') {
        this.setState({ toggleMapView: true });
      }
    } else {
      this.setState({ openMobileItemClass: '' });
    }
  };

  handlePriceRangeChange = (value: PriceValue, currentValue: PriceValue) => {
    if (value.min !== Math.round(currentValue.min)) {
      this.handleChangeFilter({ key: 'minPrice', value: value.min });
    }
    if (value.max !== Math.round(currentValue.max)) {
      this.handleChangeFilter({ key: 'maxPrice', value: value.max });
    }
  };

  handleChangeFilter = (value: HotelFilterUpdate) => {
    const {
      dispatch,
      router,
      hotelResultsMSP,
      combinedQueryParams,
    } = this.props;
    const { apiResponse } = hotelResultsMSP;
    if (value.key !== ('maxPrice': EHotelFilterKey)
    && value.key !== ('minPrice': EHotelFilterKey)) {
      dispatch(handleInputRangeChange(true));
      // event tracking for price filter
      const trackAction = value.key === 'sortBy' ? 'SORT' : 'FILTER';
      track.event(
        router.pathname,
        `${trackAction} Changed ${value.key}`,
        value.value,
        {
          NumberOfPassenger: apiResponse.package.paxCount,
          Destination: combinedQueryParams.destination,
          DepartureDate: combinedQueryParams.depart,
          ReturnDate: combinedQueryParams.return,
        },
      );
    }
    dispatch(changeFilter(value));
    return false;
  };

  handleInputRangeOnChange = (value: number) => {
    const {
      dispatch,
      router,
      hotelResultsMSP,
      combinedQueryParams,
    } = this.props;
    dispatch({ type: 'HANDLE_INPUT_RANGE_CHANGE', value: true });
    const { filterOption, apiResponse } = hotelResultsMSP;
    // event tracking for price filter
    track.event(
      router.pathname,
      'FILTER Changed Maximun Price',
      filterOption.maxPrice,
      {
        NumberOfPassenger: apiResponse.package.paxCount,
        Destination: combinedQueryParams.destination,
        DepartureDate: combinedQueryParams.depart,
        ReturnDate: combinedQueryParams.return,
      },
    );
    // Line below is removed as eslint is not allowing setState in componentDidUpdate
    // this.onUpdate({ maxPrice: value });
    dispatch(changeFilter(value));
    return false;
  };

  handleToggleMapView = () => {
    const { toggleMapView } = this.state;
    const { router, hotelResults, combinedQueryParams } = this.props;
    const { currentCoordinates } = hotelResults;
    if (!toggleMapView && currentCoordinates && combinedQueryParams) {
      // event tracking for map view
      track.event(
        router.pathname,
        'MAP Switched to Map View',
        combinedQueryParams.destination,
        {
          nwLon: currentCoordinates.nwLon,
          nwLat: currentCoordinates.nwLat,
          seLat: currentCoordinates.seLat,
          seLon: currentCoordinates.seLon,
          DepartureDate: combinedQueryParams.depart,
          ReturnDate: combinedQueryParams.return,
        },
      );
    } else {
      this.handleHotelApiQuery('FILTER_OPTION');
    }
    this.setState({
      toggleMapView: !toggleMapView,
    });
  };

  handleResetFilter = () => {
    const { dispatch, hotelResultsMSP, config } = this.props;
    const filter: HotelFilterOption = {
      minPrice: 0,
      maxPrice: config.features.useTotalPrice
        ? hotelResultsMSP.apiResponse.filter.maxPricePackage
        : hotelResultsMSP.apiResponse.filter.maxPricePerson,
      // minStars: 1,
      stars: [],
      minReview: 0,
      name: '',
      sortBy: 'reviewHigh',
    };

    dispatch(resetFilter(filter));
    return false;
  };

  handleOpenDropdown = (
    e: SyntheticEvent<HTMLDivElement>,
    styleClass: string,
    isDisabled: boolean,
  ) => {
    const { hotelResultsMSP, dispatch } = this.props;
    const { openDropdownClass } = hotelResultsMSP;
    e.stopPropagation();
    if (!isDisabled && styleClass) {
      dispatch(handleDropdownClass(styleClass));
    } else if (!isDisabled && openDropdownClass) {
      dispatch(handleDropdownClass(''));
    }
  };

  handleSetPage = (page: string) => {
    const {
      dispatch,
      hotelResultsMSP,
      combinedQueryParams,
      router,
    } = this.props;
    const { currentPage, pageSize } = hotelResultsMSP;
    const { totalHotels } = hotelResultsMSP.apiResponse;
    const totalPages = this.getTotalPages(totalHotels, pageSize);
    // // event tracking for price filter
    const DestinationPageNumber = page === 'NEXT' ? currentPage + 1 : currentPage - 1;
    track.event(
      router.pathname,
      `NAVI Proceed to ${page} Page of Hotel Listing`,
      DestinationPageNumber,
      {
        DestinationPageNumber,
        Destination: combinedQueryParams.destination,
        CurrentPageNumber: currentPage,
      },
    );
    goToAnchor('HotelResultHeader', true);
    if (page === 'NEXT') {
      if (currentPage < totalPages) {
        dispatch(setPage(currentPage + 1));
      }
    } else if (page === 'PREVIOUS') {
      if (currentPage > 1) {
        dispatch(setPage(currentPage - 1));
      }
    }
  };

  checkErrors = (validatedQuery: ValidatedQuery): boolean => {
    let isError = false;
    Object.values(validatedQuery).forEach((value: any) => {
      // checks if there is any errors
      if (parseInt(value.status, 10) === 0) {
        isError = true;
      }
    });
    this.setState({ hasError: isError });
    return isError;
  };

  // This function is needed in the index of pagebase if gallery is used.
  handleToggleGallery = (
    e: SyntheticEvent<HTMLElement>,
    isGalleryOpen: boolean,
    hotelId: string,
  ) => {
    e.stopPropagation();
    e.preventDefault();
    this.setState({
      selectedHotelGalleryId: hotelId,
    });
  };

  handleCreatePackage = () => {
    const {
      dispatch, cultureCode, hotelResultsMSP, selectedCurrency, config,
    } = this.props;
    const { validatedQueryState, toggleMapView } = this.state;

    const { defaultCurrency } = config.general;
    const { pageSize, currentPage } = hotelResultsMSP;
    const currency = selectedCurrency || defaultCurrency;

    // Gets the validated query string
    // From getInitialProps
    const {
      validOrigin,
      validDestination,
      validDepartDate,
      validReturnDate,
      validPax,
    } = validatedQueryState;

    const roomsArray = []; // Array is needed for rooms in request body
    validPax.value.forEach((pax) => {
      const room = {
        adults: pax.adults,
        // ChildAge fallback to default value if not available
        childAge1: pax.children[0] || 0,
        childAge2: pax.children[1] || 0,
        childAge3: pax.children[2] || 0,
      };
      roomsArray.push(room);
    });

    // Collect all request body to create package
    const packageData = {
      from: validOrigin.value,
      to: validDestination.value,
      depart: validDepartDate.value,
      return: validReturnDate.value,
      rooms: roomsArray,
      currency,
      lang: cultureCode,
    };

    // TODO get currency code from HOC
    if (toggleMapView) {
      this.setState({ toggleMapView: false });
    }

    dispatch(
      createPackage({
        payload: {
          cultureCode,
          pageSize,
          currentPage: 1,
          currency,
          packageData,
          useTotalPrice: config.features.useTotalPrice,
        },
      }),
    );
  };

  handleHotelApiQuery = (queryType: 'FILTER_OPTION' | 'PAGE') => {
    const {
      hotelResultsMSP, config, dispatch, cultureCode,
    } = this.props;
    const { defaultLanguage } = config.general;

    console.log('Call Hotel API QUERY: Filter Option', hotelResultsMSP.filterOption);

    const hotelApiQuery = {};
    hotelApiQuery.page = queryType === 'FILTER_OPTION' ? 1 : hotelResultsMSP.currentPage;
    hotelApiQuery.pageSize = hotelResultsMSP.pageSize; // TODO get from config
    hotelApiQuery.cultureCode = cultureCode || defaultLanguage;
    hotelApiQuery.filterOption = hotelResultsMSP.filterOption;
    hotelApiQuery.useTotalPrice = config.features.useTotalPrice;
    dispatch(getFilteredHotels(hotelResultsMSP.packageId, hotelApiQuery));
  };

  handlGetMapHotel = (coordinates: MapCoordinates, isMapFirstLoad: boolean): void => {
    const {
      config, hotelResultsMSP, dispatch,
    } = this.props;
    const priceType = config.features.useTotalPrice ? 'package' : 'person';
    const { defaultLanguage } = config.general;
    const mapFilterParams = {
      ...coordinates,
      ...hotelResultsMSP.filterOption,
      priceType,
      lang: defaultLanguage,
    };
    dispatch(getMapHotel(hotelResultsMSP.packageId, mapFilterParams, coordinates, isMapFirstLoad));
  };

  props: HotelResultProps;

  render() {
    // TODO: Check out on props validation, and best way to handle props
    const {
      config,
      combinedQueryParams,
      hotelResultsMSP,
      cultureCode,
      urlLocale,
      isClientSide,
      destinationCity,
      router,
    } = this.props;
    const {
      openMobileItemClass,
      toggleMapView,
      hasError,
      selectedHotelGalleryId,
      validatedQueryState,
    } = this.state;
    const { isNoHotelResult, openDropdownClass } = hotelResultsMSP;
    // when SSR the hotelResults will not be available
    const destination = destinationCity ? `in ${destinationCity}` : '';
    const { name } = config.general;

    return (
      <div>
        <FormattedMessage id="hotelResult.title" defaultMessage="Flight + Hotel Packages">
          {(title: string) => (
            <Helmet>
              <title>{`${title} ${destination} | ${name}`}</title>
            </Helmet>
          )}
        </FormattedMessage>
        <div>
          {config
            && ((
              <HotelResultPage
                cultureCode={cultureCode}
                urlLocale={urlLocale}
                queryParams={combinedQueryParams}
                initialLoadingStyles={InitialLoadingStyle(hotelResultsMSP.isUpdating)}
                isPolling={hotelResultsMSP.isPolling}
                progressStatus={hotelResultsMSP.progressStatus}
                validatedQuery={validatedQueryState}
                hotelResults={hotelResultsMSP}
                handleOpenDropdown={this.handleOpenDropdown}
                openDropdownClass={openDropdownClass}
                filterOption={hotelResultsMSP.filterOption}
                isNoHotelResult={isNoHotelResult}
                handleChangeFilter={this.handleChangeFilter}
                handlePriceRangeChange={this.handlePriceRangeChange}
                handleInputRangeOnChange={this.handleInputRangeOnChange}
                handleResetFilter={this.handleResetFilter}
                handleOpenMobileItem={this.handleOpenMobileItem}
                openMobileItemClass={openMobileItemClass}
                handleSetPage={this.handleSetPage}
                handleToggleGallery={this.handleToggleGallery}
                selectedHotelGalleryId={selectedHotelGalleryId}
                hasError={hasError}
                getTotalPages={this.getTotalPages}
                handleToggleMapView={this.handleToggleMapView}
                toggleMapView={toggleMapView}
                handlGetMapHotel={this.handlGetMapHotel}
                isClientSide={isClientSide}
                router={router}
              />
            )
              || hotelResultTemplate)}
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  hotelResultsMSP: getHotelResultsAppState(state),
  destinationCity: getSearchDestinationCityName(state),
});
// TODO, recheck with Wilson, something related with
// using the props that is returned from getInitialProps
// and not having mapStateToProps because Summary page is also having the same issue
// when using the props that is returned from getInitialProps

// $FlowIgnore
export default PageBase(HotelResults, { mapStateToProps });
