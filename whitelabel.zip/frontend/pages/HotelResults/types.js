/*
 * @flow
 */

// To Change ValidateQuery - Rename -> Not String
// Coordinate

import {
  type ValidatedQuery,
  type ESortType,
  type HotelFilterUpdate,
  type HandleChangeFilterFunction,
  type StandardEventFunction,
  type PackageDetail,
  type GetHotelsResponse,
  type HandleToggleGallery,
  type LoadingStyles,
  type ProgressStatus,
  type MapHotelInfo,
  type MapCoordinates,
  type HotelFilterOption,
  type SearchQueryConfig,
  type GeneralInfo,
  type Config,
  type SearchFormAppState,
  type HotelResultsAppState,
  type PriceValue,
} from '../../flow-types';

import { type PageBaseProps } from '../PageBase/types';

export * from '../../flow-types';

type HandleResetFilter = () => boolean;

type HandleGetMapHotel = (coordinates: MapCoordinates, isMapFirstLoad: ?boolean) => void;

export type HotelResultsQueryParams = {
  origin: string,
  destinationCity: string,
  departDate: string,
  returnDate: string
  // TODO: How to write variable for room[0], room[1]? these are string keys @.@
};

// define all the props in Alphabetical order
export type HotelResultProps = PageBaseProps<HotelResultsQueryParams> & {
  validatedQuery: ValidatedQuery,
  hotelResultsMSP: HotelResultsAppState,
  isClientSide: boolean,
  searchForm: SearchFormAppState,
  destinationCity?: string
};

export type HotelResultState = {
  openMobileItemClass: string,
  selectedHotelGalleryId: string,
  toggleMapView: boolean,
  hasError: boolean,
  changedVQ: boolean,
  validatedQueryState: ValidatedQuery,
};

export type HotelResultTemplateProps = {
  config: Config,
  cultureCode: string,
  urlLocale: string,
  queryParams: Object,
  initialLoadingStyles: LoadingStyles,
  isPolling: boolean,
  validatedQuery: ValidatedQuery,
  hotelResults: HotelResultsAppState,
  handlePriceRangeChange: (
    value: PriceValue,
    currentValue: PriceValue,
  ) => void,
  handleOpenDropdown: (
    e: SyntheticEvent<HTMLDivElement>,
    styleClass: string,
    isDisabled?: boolean
  ) => void,
  openDropdownClass: string,
  filterOption: HotelFilterOption,
  handleChangeFilter: HandleChangeFilterFunction,
  handleInputRangeOnChange: (value: number) => void,
  handleResetFilter: HandleResetFilter,
  handleOpenMobileItem: StandardEventFunction,
  openMobileItemClass: string,
  isNoHotelResult: boolean,
  progressStatus: ProgressStatus,
  handleSetPage: (page: string) => void,
  handleToggleGallery: HandleToggleGallery,
  selectedHotelGalleryId: string,
  handleToggleMapView: () => void,
  toggleMapView: boolean,
  hasError: boolean,
  handlGetMapHotel: HandleGetMapHotel,
  isClientSide: boolean,
  isFiltering: boolean
};

export type HotelResultHeaderProps = {
  initialLoadingStyles: LoadingStyles,
  progressStatus: ProgressStatus,
  isPolling: boolean,
  packageDetails: PackageDetail,
  isComplete: boolean,
  isInitialPoll: boolean,
  handleToggleMapView: () => void,
  toggleMapView: boolean
};

export type HotelResultContainerProps = {
  initialLoadingStyles: LoadingStyles,
  hotelResults: HotelResultsAppState,
  config: SearchQueryConfig,
  isNoHotelResult: boolean,
  handleResetFilter: HandleResetFilter,
  isDisabled: boolean,
  handleToggleGallery: HandleToggleGallery,
  urlLocale: string,
  nightCount: number,
  selectedHotelGalleryId: string
};

export type HotelResultListProps = {
  initialLoadingStyles: LoadingStyles,
  hotelResults: HotelResultsAppState,
  handleResetFilter: HandleResetFilter,
  isNoHotelResult: boolean,
  config: SearchQueryConfig,
  isDisabled: boolean,
  handleToggleGallery: HandleToggleGallery,
  urlLocale: string,
  cultureCode: string,
  nightCount: number,
  selectedHotelGalleryId: string
};

export type HotelResultListItemProps = {
  initialLoadingStyles: LoadingStyles,
  hotel: GetHotelsResponse,
  config: Object,
  isDisabled: boolean,
  handleToggleGallery: HandleToggleGallery,
  selectedHotelGalleryId: string,
  paxCount: Number,
  nightCount: Number,
  isWithWrapper: boolean,
  currency: string
};

export type PaginationProps = {
  handleSetPage: (page: string) => void,
  currentPage: number,
  totalPages: number,
  isDisabled: boolean
};
export type HotelResultSortbarProps = {
  sort: ESortType,
  handleChangeFilter: (update: HotelFilterUpdate) => void,
  handleOpenMobileItem: StandardEventFunction,
  isDisabled: boolean,
  openMobileItemClass: string,
  filterOption: Object,
  maxPrice: Number,
  handleResetFilter: Function
};

export type MobileNavBarProps = {
  handleOpenMobileItem: StandardEventFunction,
  isDisabled: boolean,
  toggleMapView: boolean,
  handleToggleMapView: () => void
};

export type HotelResultMapProps = {
  hotelResults: HotelResultsAppState,
  handlGetMapHotel: HandleGetMapHotel,
  useTotalPrice: boolean,
  nightCount: number
};

export type HotelResultMapItemProps = {
  apiResponse: GetHotelsResponse,
  generalConfig: GeneralInfo,
  handlGetMapHotel: HandleGetMapHotel,
  cultureCode: string,
  useTotalPrice: boolean,
  nightCount: number
};

type MapViewport = {
  latitude: number,
  longitude: number,
  zoom: number,
  bearing: number,
  pitch: number,
};


export type HotelResultMapItemState = {
  viewport: MapViewport,
  hotelId: ?string,
  selectedHotel: ?MapHotelInfo | {},
  currentBoundaries: MapCoordinates,
};

export type HotelResultMapItemPopupProps = {
  hotel: MapHotelInfo,
  currency: string,
  cultureCode: string,
  useTotalPrice: boolean,
  nightCount: number,
  paxCount: number
};

export type NoResultsProps = {
  handleResetFilter?: HandleResetFilter,
  isNoFilterResults: boolean
};

export type ApiErrorProps = {
  callbackText: string
};

// HotelResultMapItem function flow declaration

export type GetCurrency = () => string;
export type UpdateViewport = (viewport: MapViewport) => void;
export type MarkerClick = (hotel: MapHotelInfo) => void;
export type HandleGetMapHotels = () => boolean;
export type EmptyFunction = () => void;
