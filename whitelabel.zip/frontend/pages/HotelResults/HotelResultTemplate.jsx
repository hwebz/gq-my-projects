import React from 'react';
import { connect } from 'react-redux';
import ScrollableAnchor from 'react-scrollable-anchor';
// eslint-disable-next-line import/no-unresolved
import FilterBar from 'components/FilterBar';
import { differenceInDays } from 'date-fns';

// @flow
// import AlertMsg from 'components/Common/AlertMsg';
import AlertMessages from 'components/Common/AlertMessages';
import Pagination from './components/Pagination';
import HotelResultHeader from './components/HotelResultHeader';
import HotelResultSortbar from './components/HotelResultSortbar';
import HotelResultContainer from './components/HotelResultContainer';
import HotelResultMap from './components/HotelResultMap';
// import NoHotelFilterResults from './components/NoHotelFilterResults';
import MobileNavBar from './components/MobileNavBar';
import { getFormattedMessage } from '../../utils/query/validation/FormattedMessages';
// @flow
import { type HotelResultTemplateProps } from './types';
import ModifySearch from '../../components/ModifySearch';
// import { startSearch } from '../../store-app/modules/search-form/actions';

function getMaxPrice(useTotalPrice: boolean, hotelResults: Object): number {
  let maxPrice = 0;
  if (
    hotelResults
    && hotelResults.apiResponse
    && hotelResults.apiResponse.filter
  ) {
    // Setting the maxPrice for filters, based on features flag
    maxPrice = useTotalPrice
      ? hotelResults.apiResponse.filter.maxPricePackage
      : hotelResults.apiResponse.filter.maxPricePerson;
  }
  return maxPrice;
}

function HotelResultTemplate({
  config,
  cultureCode,
  urlLocale,
  queryParams,
  initialLoadingStyles,
  isPolling,
  validatedQuery,
  hotelResults,
  handleOpenDropdown,
  openDropdownClass,
  filterOption,
  handleChangeFilter,
  handlePriceRangeChange,
  handleInputRangeOnChange,
  handleResetFilter,
  handleOpenMobileItem,
  openMobileItemClass,
  isNoHotelResult,
  progressStatus,
  handleSetPage,
  handleToggleGallery,
  selectedHotelGalleryId,
  handleToggleMapView,
  toggleMapView,
  hasError,
  // getTotalPages,
  handlGetMapHotel,
  isClientSide,
  router,
}: HotelResultTemplateProps) {
  // const totalPage = getTotalPages(hotelResults.apiResponse.totalHotels, hotelResults.pageSize);
  const totalPage = hotelResults.totalPage ? hotelResults.totalPage : 0;

  // Get maxPrice for filter price input range
  const maxPrice = getMaxPrice(config.features.useTotalPrice, hotelResults);
  let isDisabled = true;
  let nightCount = 0;
  const packageDetails = hotelResults.apiResponse.package;

  if (hotelResults.apiResponse.totalHotels > 0) {
    isDisabled = false;
    // To calculate the number of nights
    const { checkInDate, checkOutDate } = hotelResults.apiResponse.package;
    nightCount = differenceInDays(checkOutDate, checkInDate);
  }

  const searchQuery = {
    origin: validatedQuery.validOrigin.value,
    destination: validatedQuery.validDestination.value,
    departureDate: validatedQuery.validDepartDate.value,
    returnDate: validatedQuery.validReturnDate.value,
    rooms: validatedQuery.validPax.value,
  };

  return (
    <div>
      <ModifySearch searchQuery={searchQuery} isClientSide={isClientSide} router={router} />
      {!hasError && (
        <React.Fragment>
          <MobileNavBar
            handleOpenMobileItem={handleOpenMobileItem}
            isDisabled={isDisabled}
            toggleMapView={toggleMapView}
            handleToggleMapView={handleToggleMapView}
            isPolling={isPolling}
          />
          <ScrollableAnchor id="HotelResultHeader">
            <HotelResultHeader
              isInitialPoll={hotelResults.isInitialPoll}
              progressStatus={progressStatus}
              queryParams={queryParams}
              initialLoadingStyles={initialLoadingStyles}
              handleOpenMobileItem={handleOpenMobileItem}
              isPolling={isPolling}
              packageDetails={packageDetails}
              handleToggleMapView={handleToggleMapView}
              toggleMapView={toggleMapView}
            />
          </ScrollableAnchor>
          <FilterBar
            currency={
              (hotelResults.apiResponse && hotelResults.apiResponse.currency)
              || config.general.defaultCurrency
            }
            isDisabled={isDisabled}
            isPolling={isPolling}
            handleOpenDropdown={handleOpenDropdown}
            openDropdownClass={openDropdownClass}
            filterOption={filterOption}
            handlePriceRangeChange={handlePriceRangeChange}
            handleChangeFilter={handleChangeFilter}
            handleInputRangeOnChange={handleInputRangeOnChange}
            maxPrice={maxPrice}
            handleOpenMobileItem={handleOpenMobileItem}
            openMobileItemClass={openMobileItemClass}
            hotelFilterConfig={hotelResults.apiResponse.filter}
            handleResetFilter={handleResetFilter}
          />
          {!toggleMapView && (
            <HotelResultSortbar
              isDisabled={isDisabled}
              isPolling={isPolling}
              sort={filterOption.sortBy}
              handleChangeFilter={handleChangeFilter}
              handleOpenMobileItem={handleOpenMobileItem}
              openMobileItemClass={openMobileItemClass}
              handleResetFilter={handleResetFilter}
              filterOption={filterOption}
              maxPrice={maxPrice}
            />
          )}
        </React.Fragment>
      )}
      <AlertMessages
        errors={validatedQuery}
        messageFormatter={getFormattedMessage}
      />
      {!hasError
        && ((!toggleMapView && (
          <React.Fragment>
            <HotelResultContainer
              initialLoadingStyles={initialLoadingStyles}
              validatedQuery={validatedQuery}
              hotelResults={hotelResults}
              nightCount={nightCount}
              cultureCode={cultureCode}
              urlLocale={urlLocale}
              isNoHotelResult={isNoHotelResult}
              handleResetFilter={handleResetFilter}
              isDisabled={isDisabled}
              handleToggleGallery={handleToggleGallery}
              selectedHotelGalleryId={selectedHotelGalleryId}
            />
            {!isDisabled && totalPage > 0 && (
              <Pagination
                handleSetPage={handleSetPage}
                totalPages={totalPage}
                currentPage={hotelResults.currentPage}
              />
            )}
          </React.Fragment>
        )) || (
          <HotelResultMap
            hotelResults={hotelResults}
            handlGetMapHotel={handlGetMapHotel}
            useTotalPrice={config.features.useTotalPrice}
            nightCount={nightCount}
          />
        ))}
    </div>
  );
}

const mapStateToProps = state => ({
  config: state.defaultConfig,
  isFiltering: state.hotelResults.isFiltering,
  packageId: state.hotelResults.packageId,
});


export default connect(mapStateToProps)(HotelResultTemplate);

export const hotelResultTemplate: HTMLDocument = (
  <div>
    <ModifySearch />
    <MobileNavBar handleOpenMobileItem={{}} isDisabled />
    <HotelResultHeader initialLoadingStyles={{}} />
    <FilterBar />
    <HotelResultSortbar />
    <HotelResultContainer initialLoadingStyles={{}} hotelLists={{}} />
  </div>
);
