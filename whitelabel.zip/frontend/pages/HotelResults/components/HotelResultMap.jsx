import React from 'react';
import { FormattedMessage } from 'react-intl';
import './HotelResultMap.scss';
import Map from './HotelResultMapItem';
// @flow
import { type HotelResultMapProps } from '../types';

function HotelResultMap({
  hotelResults,
  handlGetMapHotel,
  useTotalPrice,
  nightCount,
}: HotelResultMapProps) {
  let isOverlay = true;
  if (hotelResults.apiResponse
    && !hotelResults.isMapFirstLoad
  ) {
    isOverlay = false;
  }
  return (
    <div className="container no-padding-on-small">
      <div className={`hotel-result-map ${isOverlay ? 'map-overlay' : ''}`}>
        {isOverlay && (
          <div className="map-loader">
            <FormattedMessage
              id="HotelResultMap.fetching"
              defaultMessage="Fetching hotels.."
            />
          </div>
        )}
        {hotelResults && (
          <Map
            apiResponse={hotelResults.apiResponse}
            handlGetMapHotel={handlGetMapHotel}
            useTotalPrice={useTotalPrice}
            nightCount={nightCount}
          />
        )}
      </div>
    </div>
  );
}

export default HotelResultMap;
