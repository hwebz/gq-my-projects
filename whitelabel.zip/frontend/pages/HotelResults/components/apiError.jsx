import React from 'react';
import './apiError.scss';
// @flow
import { type ApiErrorProps } from '../types';

function ApiError({ callbackText }: ApiErrorProps) {
  return (
    <div className="container">
      <p className="text-center">
        {callbackText}
      </p>
    </div>
  );
}

export default ApiError;
