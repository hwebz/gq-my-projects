import { MapController } from 'react-map-gl';

export default class MyMapController extends MapController {
  // register custom events
  events = ['panend', 'pinchend'];

  // override default event handler
  handleEvent(event) {
    super.handleEvent(event);
  }

  // override default pan end event handler
  _onPanEnd() {
    const mapHotel = () => {
      this.onMoveEnd.getMapHotels(false);
    };
    mapHotel();
  }

  _onPinchEnd() {
    const mapHotel = () => {
      this.onMoveEnd.getMapHotels(false);
    };
    mapHotel();
  }

  setOptions(options) {
    this.onMoveEnd = options.onMoveEnd;
    this.timer = null;
    super.setOptions(options);
  }
}
