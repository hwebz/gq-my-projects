import React from 'react';
// eslint disable-next-line import/no-unresolved
import HotelResultList from './HotelResultList';
import './HotelResultContainer.scss';
// @flow
import { type HotelResultContainerProps } from '../types';

const HotelResultContainer = ({
  initialLoadingStyles,
  hotelResults,
  cultureCode,
  urlLocale,
  isNoHotelResult,
  handleResetFilter,
  isDisabled,
  handleToggleGallery,
  selectedHotelGalleryId,
  nightCount,
}: HotelResultContainerProps) => (
  <div>
    <HotelResultList
      initialLoadingStyles={initialLoadingStyles}
      hotelResults={hotelResults}
      cultureCode={cultureCode}
      urlLocale={urlLocale}
      isNoHotelResult={isNoHotelResult}
      handleResetFilter={handleResetFilter}
      isDisabled={isDisabled}
      handleToggleGallery={handleToggleGallery}
      selectedHotelGalleryId={selectedHotelGalleryId}
      nightCount={nightCount}
    />
  </div>
);

export default HotelResultContainer;
