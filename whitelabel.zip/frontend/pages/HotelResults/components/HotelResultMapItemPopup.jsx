import React from 'react';
import { FormattedMessage } from 'react-intl';
import NumberFormat from 'components/NumberFormat';
import StarsRatingSingle from 'components/StarsRating/StarsRatingSingle';
import ReviewRating from 'components/ReviewRating';
// @flow
import { type HotelResultMapItemPopupProps } from '../types';
import { getImageUrlsString } from '../../../utils/image-utils';

const HotelResultMapItemPopup = ({
  hotel,
  currency,
  cultureCode,
  useTotalPrice,
  nightCount,
  paxCount,
}: HotelResultMapItemPopupProps) => {
  const newPrice = useTotalPrice ? hotel.price.perPackage.price : hotel.price.perPerson.price;
  const backgroundImage = {
    backgroundImage: getImageUrlsString(hotel.image, 'HOTEL'),
  };
  return (
    <div className="map-popup__container">
      <div className="map-popup__img">
        <div style={backgroundImage} className="img" />
      </div>
      <div className="map-popup__wrapper">
        <div className="map-popup__flex-wrapper">
          <div className="map-popup__name">
            {hotel ? hotel.name : '----------------------------------------'}
          </div>
          <div className="map-popup__item map-popup__item--rating map-popup__rating">
            {hotel.stars > 0 && <StarsRatingSingle stars={hotel.stars} size="map-popup-rating" />}

            {hotel.rating && hotel.rating.score > 0 && (
              <ReviewRating
                {...{
                  position: 'right',
                  direction: 'inline',
                  ...hotel.rating,
                }}
              />
            )}
          </div>
        </div>

        <div className="map-popup__item map-popup__item--price map-popup__price">
          <div className=" theme-primary-text">
            <NumberFormat
              value={`${newPrice}`}
              currency={`${currency}`}
              locale={`${cultureCode}`}
              withSmall
            />
          </div>
          <div className="map-popup__price-note map-popup__price__note">
            <span>
              {(useTotalPrice && (
                <FormattedMessage
                  id="HotelResultMapItemPopup.totalPriceForPeople"
                  defaultMessage={'total  price for {count} people'}
                  values={{ count: paxCount }}
                />
              )) || (
                <FormattedMessage
                  id="HotelResultMapItemPopup.perPerson"
                  defaultMessage={
                    'per person for {count, number} {count, plural, one {night} other {nights}}'
                  } // TODO pluralize night & no of nights from gethotels api
                  values={{ count: nightCount }}
                />
              )}
            </span>
            <span>
              <FormattedMessage
                id="HotelResultMapItemPopup.includingTaxesAndFees"
                defaultMessage="including taxes &amp; fees"
              />
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
export default HotelResultMapItemPopup;
