import React from 'react';

import { FormattedMessage } from 'react-intl';

import './HotelResultListItem.scss';

import { FaMapMarker as IconLocation } from 'react-icons/fa';
import { MdBusiness as IconBusiness, MdFlight as IconFlight } from 'react-icons/md';
// import { IoIosPricetags as IconTags } from 'react-icons/io';
import HotelDetailPrice from 'components/Price/HotelDetailPrice';
import ReviewRating from 'components/ReviewRating';
import Gallery from 'components/Common/Gallery';
import StarsRatingSingle from 'components/StarsRating/StarsRatingSingle';
import Spinner from 'components/Common/Spinner';

import InitialLoadingStyle from '../../../utils/initialLoading';
import ValidatorUtils from '../../../react-next/utils/validation-utils';
import { getImageUrlsString } from '../../../utils/image-utils';

// @flow
import { type HotelResultListItemProps, type LoadingStyles } from '../types';

import ComponentBase, {
  type GenericComponent,
} from '../../../components/ComponentBase';

import { getHotelListCurrency } from '../../../store-app/modules/hotel-list/selectors';

function HotelResultListItem({
  initialLoadingStyles,
  selectedHotelGalleryId,
  hotel,
  isPolling,
  handleToggleGallery,
  paxCount,
  nightCount,
  isWithWrapper,
  currency,
  filterOption,
}: HotelResultListItemProps) {
  // const savings = false;
  let loadingStyles: LoadingStyles = initialLoadingStyles;
  if (Object.keys(initialLoadingStyles).length === 0) {
    loadingStyles = InitialLoadingStyle(true);
  }
  const { contentLoading, loadingState, textLoading } = loadingStyles;
  const galleryDisable: string = hotel && ValidatorUtils.isEmptyOrZero(hotel.image) ? 'btn-disabled' : '';
  return (
    <div
      className={`hotel-result__item ${isWithWrapper ? 'with-wrapper' : ''}`}
    >
      <div
        className={`hotel-result__picture ${galleryDisable}`}
        onClick={
          (hotel && ValidatorUtils.isEmptyOrZero(hotel.image))
            ? null
            : (e) => {
              handleToggleGallery(e, true, hotel.hotelId);
            }
        }
        role="presentation"
      >
        <div className="hotel-result__picture__image">
          {(loadingState && <Spinner />) || (
            // to be replaced with a new image not available
            <div
              className="hotel-result__picture__image--inner"
              style={{ backgroundImage: getImageUrlsString(hotel.image, 'HOTEL') }}
              // src={hotel.image}
              // src={getPlaceHolderUrl('HOTEL')}
              // onError={(e) => {
              //   e.target.src = getPlaceHolderUrl('HOTEL');
              //   e.target.className = 'hotel-result__picture--error';
              // }}
              // alt={hotel.name || ''}
            />
          )}
        </div>
      </div>
      {hotel
        && selectedHotelGalleryId === hotel.hotelId && (
          <Gallery
            isGalleryOpen
            handleToggleGallery={handleToggleGallery}
            hotelId={hotel.hotelId}
          />
      )}
      <div className="hotel-result__detail">
        <div>
          <div className="hotel-result__title">
            <h2 className={`title ${textLoading}`}>
              {/* Translated from api */}
              {hotel ? hotel.name : 'Hotel the Celestine Tokyo Shiba'}
            </h2>
            <div>
              {!loadingState
                && hotel.stars > 0 && <StarsRatingSingle stars={hotel.stars} />}
            </div>
          </div>
          <div className={`hotel-result__location ${textLoading}`}>
            {(loadingState && (
              <div>
                {'-------------------------------------------'}
              </div>
            ))
              || (hotel
                && hotel.location.area && (
                  <React.Fragment>
                    <i>
                      <IconLocation />
                    </i>
                    <div className="hotel-result__location__text">
                      <span>
                        {/* Translated from api */}
                        {hotel.location.area}
                      </span>
                      {/* TODO: Add map popup */}
                      {/* <a href="#viewOnMap" className="link-primary link-theme-color">
                  <FormattedMessage
                    id="HotelResultListItem.viewOnMap"
                    defaultMessage="View on map"
                  />
                </a> */}
                    </div>
                  </React.Fragment>
              ))}
          </div>
          <div className={`hotel-result__location ${textLoading}`}>
            {(filterOption && filterOption.sortBy === 'nearCity' && hotel
                && hotel.location.distanceCity && (
                  <React.Fragment>
                    <i>
                      <IconBusiness />
                    </i>
                    <div className="hotel-result__location__text">
                      <span>
                        <FormattedMessage
                          id="HotelResultListItem.distanceCity"
                          defaultMessage={'{distance} km from city center'}
                          values={{ distance: hotel.location.distanceCity.toFixed(2) }}
                        />
                      </span>
                    </div>
                  </React.Fragment>
            ))}
            {(filterOption && filterOption.sortBy === 'nearAirport' && hotel
                && hotel.location.distanceAirport && (
                  <React.Fragment>
                    <i>
                      <IconBusiness />
                    </i>
                    <div className="hotel-result__location__text">
                      <span>
                        <FormattedMessage
                          id="HotelResultListItem.distanceAirport"
                          defaultMessage={'{distance} km from airport'}
                          values={{ distance: hotel.location.distanceAirport.toFixed(2) }}
                        />
                      </span>
                    </div>
                  </React.Fragment>
            ))}
          </div>
        </div>
        <div className={`location-rating ${textLoading}`}>
          {hotel
            && hotel.rating.locationText && (
              <div className="location-rating__wrapper">
                <i className="icon-badge--small" />
                {/* Translated from api */}
                {hotel.rating.locationText && (
                  <React.Fragment>
                    <FormattedMessage
                      id="HotelResultListItem.locationText"
                      defaultMessage={'{rating}'}
                      values={{
                        rating: hotel ? hotel.rating.locationText : '&nbsp;',
                      }}
                    />
                    <br />
                  </React.Fragment>
                )}
              </div>
          )}
          {hotel
            && hotel.rating.locationNearby && (
              <div className="location-rating__wrapper">
                <i className="icon-badge--small" />
                {/* Translated from api */}
                {hotel.rating.locationNearby && (
                  <FormattedMessage
                    id="HotelResultListItem.locationNearby"
                    defaultMessage={'{rating}'}
                    values={{
                      rating: hotel ? hotel.rating.locationNearby : '&nbsp;',
                    }}
                  />
                )}
              </div>
          )}
          <div className="location-rating__wrapper">
            <i className="icon-flight">
              <IconFlight />
            </i>
            <span>
              <FormattedMessage
                id="HotelResultListItem.taxFees"
                defaultMessage="Package includes flights, hotel, tax and fees"
              />
            </span>
          </div>
        </div>
      </div>
      <div className="hotel-result__control">
        <div className="hotel-result__control__row">
          {!loadingState
            && hotel.rating.score > 0 && (
              <ReviewRating
                {...{
                  position: 'right',
                  ...hotel.rating,
                }}
              />
          )}
        </div>
        <div className="hotel-result__control__row">
          {(hotel && (
            <HotelDetailPrice
              initialLoadingStyles={initialLoadingStyles}
              isPolling={isPolling}
              prices={hotel ? hotel.price : ''}
              paxCount={paxCount}
              nightCount={nightCount}
              currency={currency}
            />
          )) || (
            <div className="price">
              <div className={`${contentLoading}`}>
                <div className="HotelResultPrice">
                  <div className="price__old">
                    {'--------------'}
                  </div>
                  <div className="price__now theme-primary-text">
                    <small>
                      {'-----'}
                    </small>
                    <b>
                      {'----------------'}
                    </b>
                  </div>
                </div>
              </div>
              <div className={`${textLoading} price__note`}>
                <span>
                  <FormattedMessage
                    id="HotelResultListItem.totalPriceForPeople"
                    defaultMessage={'total  price for {count} people'}
                    values={{ count: '4' }}
                  />
                </span>
                <span>
                  <FormattedMessage
                    id="HotelResultListItem.includingTaxesAndFees"
                    defaultMessage="including taxes & fees"
                  />
                </span>
              </div>
            </div>
          )}

          <div className="hotel-result__button">
            {hotel && (
              <button
                className="btn btn-lg btn-primary btn-theme-primary btn-uppercase btn-block"
                type="button"
              >
                <FormattedMessage
                  id="HotelResultListItem.select"
                  defaultMessage="Select"
                />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

const injection: GenericComponent<HotelResultListItemProps> = ComponentBase;

const mapStateToProps = state => ({
  currency: getHotelListCurrency(state),
});

export default injection(HotelResultListItem, { mapStateToProps });
