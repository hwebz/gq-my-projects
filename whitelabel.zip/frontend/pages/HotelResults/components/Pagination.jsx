import React from 'react';
import {
  IoAndroidArrowDropleft as IconPaginationLeft,
  IoAndroidArrowDropright as IconPaginationRight,
} from 'react-icons/io';
import './Pagination.scss';
// @flow
import { type PaginationProps } from '../types';

function Pagination({
  handleSetPage, totalPages, currentPage,
}: PaginationProps) {
  const disablePreviousBtn = currentPage <= 1 ? 'btn-disabled' : '';
  const disableNextBtn = currentPage >= totalPages ? 'btn-disabled' : '';
  return (
    <div className="pagination">
      <button
        className={`${disablePreviousBtn} pagination__button btn-theme-secondary-halo`}
        type="button"
        onClick={() => {
          handleSetPage('PREVIOUS');
        }}
      >
        <i>
          <IconPaginationLeft size={24} />
        </i>
      </button>
      <div className="pagination__count">
        <span>
          {(totalPages === 0) ? '' : `Page ${currentPage} of ${totalPages}`}
          {/* TODO Page size and current page might change when apply filters */}
        </span>
      </div>
      <button
        className={`${disableNextBtn} pagination__button btn-theme-secondary-halo`}
        type="button"
        onClick={() => {
          handleSetPage('NEXT');
        }}
      >
        <i>
          <IconPaginationRight size={24} />
        </i>
      </button>
    </div>
  );
}

export default Pagination;
