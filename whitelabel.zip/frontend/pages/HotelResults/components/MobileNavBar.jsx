import React from 'react';
import { FormattedMessage } from 'react-intl';
// $FlowIgnore
import { TiFilter as IconFilter } from 'react-icons/ti';
// $FlowIgnore
import { IoMap as IconMap } from 'react-icons/io';
// $FlowIgnore
import { MdSort as IconSort, MdFormatListBulleted as ListIcon } from 'react-icons/md';
import './MobileNavBar.scss';
// @flow
import { type MobileNavBarProps } from '../types';

const MobileNavBar: Function = ({
  handleOpenMobileItem,
  isDisabled,
  isPolling,
  toggleMapView,
  handleToggleMapView,
}: MobileNavBarProps) => {
  const disableBar: string = isDisabled ? 'bar-disabled' : '';
  return (
    <div className={`mobile-nav-bar ${disableBar}`}>
      {!toggleMapView && (
        <a
          className="mobile-nav-bar__button btn-theme-secondary"
          href="#sort"
          onClick={(e: SyntheticEvent) => {
            handleOpenMobileItem(e, 'navbar-sort', isDisabled);
          }}
        >
          <i>
            <IconSort />
          </i>
          <FormattedMessage id="mobileNavBar.sort" defaultMessage="Sort" />
        </a>
      )}
      <a
        className="mobile-nav-bar__button btn-theme-secondary"
        href="#filter"
        onClick={(e: SyntheticEvent) => {
          handleOpenMobileItem(e, 'navbar-filter', isDisabled);
        }}
      >
        <i>
          <IconFilter />
        </i>
        <FormattedMessage id="mobileNavBar.filter" defaultMessage="Filter" />
      </a>
      <a
        className={`mobile-nav-bar__button btn-theme-secondary ${!isDisabled && isPolling ? 'bar-disabled' : ''}`}
        href="#mapView"
        onClick={() => (
          !isPolling ? handleToggleMapView() : null
        )}
      >
        {(toggleMapView && (
          <React.Fragment>
            <i>
              <ListIcon />
            </i>
            <span>
              <FormattedMessage id="mobileNavBar.listView" defaultMessage="List View" />
            </span>
          </React.Fragment>
        )) || (
          <React.Fragment>
            <i>
              <IconMap />
            </i>
            <span>
              <FormattedMessage id="mobileNavBar.mapView" defaultMessage="Map View" />
            </span>
          </React.Fragment>
        )}
      </a>
    </div>
  );
};
export default MobileNavBar;
