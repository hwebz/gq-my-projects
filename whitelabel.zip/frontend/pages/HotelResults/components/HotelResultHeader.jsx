import React from 'react';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import ProgressBar from 'components/Progress/ProgressBar';
import { IoMap as IconMap } from 'react-icons/io';
import { MdFormatListBulleted as ListIcon } from 'react-icons/md';
import './HotelResultHeader.scss';
import InitialLoadingStyle from '../../../utils/initialLoading';
import {
  getSearchOriginCityName,
  getSearchDestinationCityName,
} from '../../../store-app/modules/search-form/selectors';
// @flow
import { type HotelResultHeaderProps, type LoadingStyles } from '../types';

function HotelResultHeader({
  isInitialPoll,
  initialLoadingStyles,
  progressStatus,
  isPolling,
  handleToggleMapView,
  toggleMapView,
  originCity,
  destinationCity,
}: HotelResultHeaderProps) {
  let loadingStyles: LoadingStyles = initialLoadingStyles;

  if (Object.keys(initialLoadingStyles).length === 0) {
    loadingStyles = InitialLoadingStyle(true);
  }

  const disableBtn: string = isPolling ? 'btn-disabled' : '';
  const { loadingState } = loadingStyles;
  return (
    <div className="container">
      <div className="header-nav__caption">
        <div className="header-nav__title">
          <h1>
            <FormattedMessage
              id="hotelResultHeader.availablePackages"
              defaultMessage="Available Packages"
            />
          </h1>
          <span
            className="header-nav__title__sub"
          >
            {(originCity
              && destinationCity && (
                <span>
                  <FormattedMessage
                    id="hotelResultHeader.titleText"
                    defaultMessage="From {origin} to {destination}"
                    values={{
                      origin: originCity,
                      destination: destinationCity,
                    }}
                  />
                </span>
            ))
              || (loadingState && (
                <div>
                  {'-----------------------'}
                </div>
              ))}
          </span>
        </div>
        <div className="header-nav__progress">
          {progressStatus
            && isPolling
            && isInitialPoll && <ProgressBar progressStatus={progressStatus} />}
        </div>
        <div className={`header-nav__button ${isPolling ? 'header-nav--overlay' : ''} `}>
          <button
            type="button"
            className={`${disableBtn} btn-icon-right button button--bordered btn--with-icon btn-theme-secondary-halo`}
            onClick={() => {
              handleToggleMapView();
            }}
          >
            {(toggleMapView && (
              <React.Fragment>
                <span className="btn--text">
                  <FormattedMessage id="hotelResultHeader.listView" defaultMessage="List View" />
                </span>
                <i className="btn-icon">
                  <ListIcon />
                </i>
              </React.Fragment>
            )) || (
              <React.Fragment>
                <span className="btn--text">
                  <FormattedMessage id="hotelResultHeader.mapView" defaultMessage="Map View" />
                </span>
                <i className="btn-icon">
                  <IconMap />
                </i>
              </React.Fragment>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

const mapStateToProps = state => ({
  originCity: getSearchOriginCityName(state),
  destinationCity: getSearchDestinationCityName(state),
});

export default connect(mapStateToProps)(HotelResultHeader);
