import React from 'react';
import MapGL, {
  Marker, Popup, NavigationControl, FlyToInterpolator,
} from 'react-map-gl';
import WebMercatorViewport from 'viewport-mercator-project';
import './HotelResultMapItem.scss';
// @flow
import { getCurrencyText } from 'react-next/intl/currency-symbols';
import HotelResultMapItemPopup from './HotelResultMapItemPopup';
import {
  type HotelResultMapItemProps,
  type HotelResultMapItemState,
  type MapHotelInfo,
  type GetCurrency,
  type UpdateViewport,
  type MarkerClick,
  type HandleGetMapHotels,
  type EmptyFunction,
  type MapViewport,
} from '../types';

import ComponentBase, {
  type GenericComponent,
} from '../../../components/ComponentBase';

import MapController from './HotelResultMapController';

const customController = new MapController();

const accessToken = 'pk.eyJ1IjoiZ29xdW8td2hpdGVsYWJlbCIsImEiOiJjams3MTljMGIxNTB3M3BvNHUyNWRza2JrIn0.tkmROUS49HhH-xVfHn3RPA';

class HotelResultMapItem extends React.Component<
  HotelResultMapItemProps,
  HotelResultMapItemState
> {
  constructor(props: HotelResultMapItemProps) {
    super(props);
    const centerLat = (props.apiResponse.package.long && props.apiResponse.package.lat)
      ? props.apiResponse.package.lat : 0;
    const centerLong = (props.apiResponse.package.long && props.apiResponse.package.lat)
      ? props.apiResponse.package.long : 0;
    this.state = {
      hotelId: undefined,
      selectedHotel: {},
      viewport: {
        latitude: centerLat,
        longitude: centerLong,
        zoom: 10,
        bearing: 0,
        pitch: 0,
      },
      currentBoundaries: {},
    };
    this.handleGetMapHotels = this.handleGetMapHotels.bind(this);
    this.timer = null;
    this.mapRef = React.createRef();
  }

  state: HotelResultMapItemState;

  getCurrency: GetCurrency = () => {
    const { apiResponse, generalConfig } = this.props;

    if (apiResponse.map) {
      return apiResponse.map.currency;
    }

    return generalConfig.defaultCurrency;
  }

  _updateViewport: UpdateViewport = (viewport: MapViewport) => {
    this.setState({ viewport });
  }

  // Method that will show the specific popup based in clicked marker
  markerClick: MarkerClick = (hotel: MapHotelInfo) => {
    const { viewport, currentBoundaries } = this.state;

    const {
      nwLon, nwLat,
      seLon, seLat,
    } = currentBoundaries;
    const { longitude, latitude, zoom } = new WebMercatorViewport(viewport)
      .fitBounds([[nwLon, nwLat], [seLon, seLat]], {
        padding: 30,
        offset: [0, -100],
      });
    const newViewport = {
      ...viewport,
      longitude,
      latitude,
      zoom,
      transitionDuration: 500,
      transitionInterpolator: new FlyToInterpolator(),
    };
    this.setState({
      viewport: newViewport,
      hotelId: hotel.hotelId,
      selectedHotel: hotel,
    });
  };

  handleGetMapHotels: HandleGetMapHotels = (isMapFirstLoad) => {
    const { handlGetMapHotel } = this.props;
    const { viewport } = this.state;
    // To get the coordinates for North-West and South-East long lat
    const map = this.mapRef.getMap();
    const nw = map.getBounds().getNorthWest();
    const se = map.getBounds().getSouthEast();

    const coordinates = {
      nwLon: nw.lng,
      nwLat: nw.lat,
      seLon: se.lng,
      seLat: se.lat,
    };

    this.setState({
      currentBoundaries: coordinates,
      viewport: {
        ...viewport,
        height: map.transform.height,
        width: map.transform.width,
      },
    });
    const mapHotel = () => {
      handlGetMapHotel(coordinates, isMapFirstLoad);
    };
    mapHotel();
    return false;
  };

  closePopup: EmptyFunction = () => {
    const { hotelId } = this.state;
    if (hotelId) {
      this.setState({
        hotelId: undefined,
        selectedHotel: undefined,
      });
    }
  };

  _onWheel: EmptyFunction = () => {
    if (this.timer) {
      clearTimeout(this.timer);
    }
    this.timer = setTimeout(() => (this.handleGetMapHotels(false)), 1000);
  }

  handleNavigationControl = (event) => {
    // Target is used in order to detect only navigation control is clicked
    const clickTarget = event.target.offsetParent.className;
    const navigationControlParentClass = 'map-navigation-control';
    if (
      clickTarget === navigationControlParentClass || clickTarget === navigationControlParentClass
    ) {
      this.handleGetMapHotels(false);
    }
  }

  timer: number;
  mapRef: React.Ref<*>;
  props: HotelResultMapItemProps;

  render() {
    const {
      apiResponse,
      cultureCode,
      useTotalPrice,
      nightCount,
    } = this.props;

    const {
      hotelId, selectedHotel, viewport,
    } = this.state;
    let mapHotels = [];
    if (apiResponse) {
      if (apiResponse.map) {
        mapHotels = apiResponse.map.hotels;
      }
    }
    return (
      <React.Fragment>
        <MapGL
          {...viewport}
          ref={(map) => { this.mapRef = map; }}
          width="100%"
          height="100%"
          doubleClickZoom={false}
          mapStyle="mapbox://styles/mapbox/streets-v9"
          /* eslint-disable */
          // To be ignored to override existing function
          onViewportChange={this._updateViewport}
          onWheel={this._onWheel}
          /* eslint-enable */
          controller={customController}
          onLoad={() => (this.handleGetMapHotels(true))}
          mapboxApiAccessToken={accessToken}
          onMoveEnd={{
            getMapHotels: this.handleGetMapHotels,
          }}
          onClick={() => {
            this.closePopup();
          }}
          onMouseUp={this.handleNavigationControl}
          onTouchEnd={this.handleNavigationControl}
        >
          <div className="map-navigation-control">
            <NavigationControl
              /* eslint-disable */
              // To be ignored to override existing function
              onViewportChange={this._updateViewport}
              /* eslint-enable */
              showCompass={false}
            />
          </div>
          {mapHotels.length > 0
            && mapHotels.map(hotel => (
              <Marker
                latitude={hotel.lat}
                longitude={hotel.lon}
                offsetLeft={-30}
                offsetTop={-10}
                key={hotel.hotelId}
              >
                <div
                  onClick={(e) => { e.stopPropagation(); this.markerClick(hotel); }}
                  role="presentation"
                  className="map-marker"
                >
                  {getCurrencyText(
                    cultureCode,
                    this.getCurrency(),
                    Math.round(
                      useTotalPrice ? hotel.price.perPackage.price : hotel.price.perPerson.price,
                    ),
                  )}
                </div>
              </Marker>
            ))}
          {hotelId && (
            <Popup
              latitude={selectedHotel.lat}
              longitude={selectedHotel.lon}
              closeButton={false}
              dynamicPosition={false}
              offsetTop={4}
            >
              <a
                href={selectedHotel.url}
                target="_blank"
                rel="noopener noreferrer"
              >
                <HotelResultMapItemPopup
                  hotel={selectedHotel}
                  useTotalPrice={useTotalPrice}
                  nightCount={nightCount}
                  paxCount={apiResponse.package.paxCount}
                  cultureCode={cultureCode}
                  currency={this.getCurrency()}
                />
              </a>
            </Popup>
          )}
        </MapGL>
      </React.Fragment>
    );
  }
}

const injection: GenericComponent<HotelResultMapItemProps> = ComponentBase;

export default injection(HotelResultMapItem, {
  hasGeneralConfig: true,
  hasCultureCode: true,
});
