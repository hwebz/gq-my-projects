// @flow
import React from 'react';
import { defineMessages, FormattedMessage } from 'react-intl';
import './HotelResultSortbar.scss';
// $FlowIgnore react-icons don't have flow
import { MdArrowBack as IconArrowLeft, MdDone as IconCheck, MdReplay as IconReset } from 'react-icons/md';
import { type HotelResultSortbarProps, type ESortType } from '../types';
import ValidationUtils from '../../../react-next/utils/validation-utils';

const sortFormatted = defineMessages({
  sortBy: {
    id: 'HotelResultSortbar.sortBy',
    defaultMessage: 'Sort by',
  },
  bestRated: {
    id: 'HotelResultSortbar.bestRated',
    defaultMessage: 'Best Rated',
  },
  lth: {
    id: 'HotelResultSortbar.lth',
    defaultMessage: 'Low to high price',
  },
  ncc: {
    id: 'HotelResultSortbar.ncc',
    defaultMessage: 'Nearest to city center',
  },
  nta: {
    id: 'HotelResultSortbar.nta',
    defaultMessage: 'Nearest to airport',
  },
});

const HotelResultSortbar = ({
  sort,
  handleChangeFilter,
  isDisabled,
  handleOpenMobileItem,
  openMobileItemClass,
  filterOption,
  maxPrice,
  handleResetFilter,
}: HotelResultSortbarProps) => {
  const disableClass = isDisabled ? 'disable-filters' : '';
  console.log(disableClass, isDisabled);
  // Check if filters are active
  const isFiltersActive = filterOption
    && (
      !ValidationUtils.isEmptyOrZero(filterOption.minPrice)
      || !( // Check if maxPrice is 0 or default maxPrice
        ValidationUtils.isEmptyOrZero(filterOption.maxPrice)
        || (Math.round(filterOption.maxPrice) >= Math.round(maxPrice))
      )
      || !ValidationUtils.isEmptyOrZero(filterOption.minReview)
      || !ValidationUtils.isEmptyOrZero(filterOption.name)
      || !ValidationUtils.isEmptyOrZero(filterOption.stars)
    );
  return (
    <div
      className={`filter-bar panel-mobile ${openMobileItemClass === 'navbar-sort' ? 'is-open' : ''}`}
    >
      <div
        className="panel-mobile__title"
        onClick={(e: SyntheticEvent<HTMLDivElement>) => {
          handleOpenMobileItem(e, '');
        }}
        role="presentation"
      >
        <i>
          <IconArrowLeft />
        </i>
        <strong>
          <FormattedMessage {...sortFormatted.sortBy} />
        </strong>
      </div>
      <div className="panel-mobile__content container">
        <div className="filter-bar__container">
          <div className="filter-bar__title">
            <FormattedMessage {...sortFormatted.sortBy} />
          </div>
          <div className={`${disableClass} filter-bar__wrap filter-bar__wrap--sort ${isDisabled ? 'sort-bar--overlay' : ''}`}>
            <div
              className="sort-bar__list"
            >
              <a
                href="#rvw"
                className={`sort-bar__item ${
                  sort === ('reviewHigh': ESortType) ? 'sort-bar__item--active' : ''
                }`}
                onClick={() => {
                  handleChangeFilter({ key: 'sortBy', value: 'reviewHigh' });
                }}
              >
                <FormattedMessage {...sortFormatted.bestRated} />
                <i>
                  <IconCheck size={16} />
                </i>
              </a>
              {/* <a
                href="#rcmd"
                className={`sort-bar__item ${
                  sort === ('recommended': ESortType) ? 'sort-bar__item--active' : ''
                }`}
                onClick={() => {
                  handleChangeFilter({ key: 'sortBy', value: 'recommended' });
                }}
              >
                Recommended
                <i>
                  <IconCheck size={16} />
                </i>
              </a> */}
              <a
                href="#lth"
                className={`sort-bar__item ${
                  sort === ('priceLow': ESortType) ? 'sort-bar__item--active' : ''
                }`}
                onClick={() => {
                  handleChangeFilter({ key: 'sortBy', value: 'priceLow' });
                }}
              >
                <FormattedMessage {...sortFormatted.lth} />
                <i>
                  <IconCheck size={16} />
                </i>
              </a>
              <a
                href="#ncc"
                className={`sort-bar__item ${
                  sort === ('nearCity': ESortType) ? 'sort-bar__item--active' : ''
                }`}
                onClick={() => {
                  handleChangeFilter({ key: 'sortBy', value: 'nearCity' });
                }}
              >
                <FormattedMessage {...sortFormatted.ncc} />
                <i>
                  <IconCheck size={16} />
                </i>
              </a>
              <a
                href="#nta"
                className={`sort-bar__item ${
                  sort === ('nearAirport': ESortType)
                    ? 'link-theme-primary sort-bar__item--active'
                    : ''
                }`}
                onClick={() => {
                  handleChangeFilter({ key: 'sortBy', value: 'nearAirport' });
                }}
              >
                <FormattedMessage {...sortFormatted.nta} />
                <i>
                  <IconCheck size={16} />
                </i>
              </a>
            </div>
          </div>
          <div className={`${disableClass} sort-bar__reset--btn`}>
            <IconReset size={14} />
            <button
              onClick={() => { handleResetFilter(); }}
              type="button"
              className={`link ${
                openMobileItemClass === 'navbar-filter' ? 'btn-block' : ''
              } ${isFiltersActive ? '' : 'btn-disabled'}`}
              disabled={`${!isFiltersActive || isDisabled ? 'disabled' : ''}`}
            >
              <FormattedMessage id="FilterBar.reset_filter" defaultMessage="Reset Filter" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default HotelResultSortbar;
