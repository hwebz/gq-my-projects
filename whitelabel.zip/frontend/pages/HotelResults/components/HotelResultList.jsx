import React from 'react';
import { FormattedMessage } from 'react-intl';
import HotelResultListItem from './HotelResultListItem';
import NoResults from '../../../components/NoResults';
import './HotelResultList.scss';
// @flow
import { type HotelResultListProps } from '../types';

function getHotels(props: HotelResultListProps) {
  const {
    initialLoadingStyles,
    hotelResults,
    urlLocale,
    handleToggleGallery,
    selectedHotelGalleryId,
    nightCount,
  } = props;

  const languageCode = urlLocale ? `${urlLocale}` : '';
  const hotelsArray = [];
  const { hotels } = hotelResults.apiResponse;

  hotels.map(hotel => (
    hotelsArray.push(
      <React.Fragment key={hotel.hotelId}>
        {/* eslint-disable-next-line */}
        <a
          href={`${languageCode}${hotel.url}`}
          target="_blank"
          rel="noopener noreferrer"
          className="hotel-result__item-wrapper"
        >
          <HotelResultListItem
            initialLoadingStyles={initialLoadingStyles}
            hotel={hotel}
            isPolling={hotelResults.isPolling}
            handleToggleGallery={handleToggleGallery}
            selectedHotelGalleryId={selectedHotelGalleryId}
            paxCount={hotelResults.apiResponse.package.paxCount}
            nightCount={nightCount}
            isWithWrapper
            filterOption={hotelResults.filterOption}
          />
        </a>
        <div className="hotel-result__item-separator" />
      </React.Fragment>,
    )
  ));
  if (!hotelResults.apiResponse.isComplete && hotels.length < 10) {
    const remainingHotels = 10 - hotels.length;
    for (let j = 0; j < remainingHotels; j++) {
      hotelsArray.push(
        <HotelResultListItem initialLoadingStyles={{}} config={{}} />,
      );
    }
  }

  return (<React.Fragment>{hotelsArray}</React.Fragment>);
}

function getNoHotelsView(props: HotelResultListProps, messages) {
  const {
    hotelResults,
    handleResetFilter,
  } = props;

  if (hotelResults.apiResponse.totalHotels > 0) {
    return (
      <NoResults
        handleResetFilter={
          handleResetFilter // Logic need to change -> Confusing -> should be isLooading
        }
        messages={messages}
        isNoFilterResults
      />
    );
  }

  if (
    (hotelResults.apiResponse.isComplete && hotelResults.apiResponse.totalHotels <= 0)
    || hotelResults.isNoPackage
  ) {
    return (
      <NoResults isNoFilterResults={false} messages={messages} />
    );
  }
  return null;
}

function HotelResultList(props: HotelResultListProps) {
  const {
    hotelResults,
    isNoHotelResult,
  } = props;

  const messages = {
    noFilterResultHeader: <FormattedMessage
      id="HotelResultList.noFilterResultHeader"
      defaultMessage="No Packages Match Your Filters"
    />,
    noResultHeader: <FormattedMessage
      id="HotelResultList.noResultHeader"
      defaultMessage="No Packages Available on This Date"
    />,
    noFilterResultSubheader: <FormattedMessage
      id="HotelResultList.noFilterResultSubheader"
      defaultMessage="We couldn't find any packages matching your filters."
    />,
    noResultSubheader: <FormattedMessage
      id="HotelResultList.noResultSubheader"
      defaultMessage="Try changing the selected dates for more options."
    />,
  };

  return (
    <div className="container">
      <div className="hotel-result">
        {(hotelResults
          && (
            (
              hotelResults.apiResponse.hotels.length > 0
              && getHotels(props)
            )
            || (isNoHotelResult
              && getNoHotelsView(props, messages)
            )
          )
        ) || (
          <div>
            <HotelResultListItem initialLoadingStyles={{}} config={{}} />
            <HotelResultListItem initialLoadingStyles={{}} config={{}} />
            <HotelResultListItem initialLoadingStyles={{}} config={{}} />
            <HotelResultListItem initialLoadingStyles={{}} config={{}} />
            <HotelResultListItem initialLoadingStyles={{}} config={{}} />
            <HotelResultListItem initialLoadingStyles={{}} config={{}} />
            <HotelResultListItem initialLoadingStyles={{}} config={{}} />
            <HotelResultListItem initialLoadingStyles={{}} config={{}} />
            <HotelResultListItem initialLoadingStyles={{}} config={{}} />
          </div>
        )}
      </div>
    </div>
  );
}
export default HotelResultList;
