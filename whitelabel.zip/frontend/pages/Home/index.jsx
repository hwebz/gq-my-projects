import React from 'react';
import { Helmet } from 'react-helmet';
// import Link from 'next/link';

import { FormattedMessage } from 'react-intl';

import SearchForm from '../../components/SearchForm';
import PageBase from '../PageBase';

import './Home.scss';

// @flow
import { type HomeProps, type HomeState } from './types';

const track = require('../../react-next/utils/track-utils');

class Home extends React.Component<HomeProps> {
  state: HomeState;

  static getInitialProps({ ctx }) {
    const { isServer } = ctx;
    return { isServer };
  }

  componentDidMount() {
    const {
      router,
      selectedCurrency,
      cultureCode,
      defaultConfig,
    } = this.props;
    router.prefetch('/HotelResults');
    // tracking
    track.page(
      router.pathname,
      defaultConfig.environment,
      {
        Language: cultureCode,
        Currency: selectedCurrency,
        Referrer: '',
      },
    );
  }

  render() {
    // TODO: Check out on props validation, and best way to handle props
    const {
      config: { general },
      router,
      isServer,
    } = this.props;

    return (
      <div className="wrap-container background-theme-primary">
        <FormattedMessage id="home.title" defaultMessage="Book a Package">
          {title => (
            <Helmet>
              <title>{`${title} | ${general.name}`}</title>
            </Helmet>
          )}
        </FormattedMessage>
        <style jsx>
          {`
            .background-theme-primary {
              background-image: url(${general.backgroundImage
                || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg'});
            }
          `}
        </style>
        <div className="home">
          <div className="container">
            <div className="home__wrap">
              <div className="home__title">
                <h1>
                  <FormattedMessage id="home.caption" defaultMessage="Book a Package" />
                </h1>
              </div>
              <div className="home__header">
                <strong>
                  <FormattedMessage id="home.flighthotel" defaultMessage="Flight + Hotel" />
                </strong>
              </div>
              <SearchForm configSearchForm={general} router={router} isClientSide={!isServer} />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default PageBase(Home);
