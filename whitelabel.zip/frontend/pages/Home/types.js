/**
 * @flow
 */
import { type Config } from 'flow-types';

export * from 'flow-types';

export type HomeProps = {
  config: Config,
};

export type HomeState = {};
