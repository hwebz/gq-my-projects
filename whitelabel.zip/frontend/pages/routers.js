// @flow
import type { RouterModel } from '../flow-types';

const routers: Array<RouterModel> = [
  {
    path: '/error/404',
    page: '/error/404',
  },
  {
    path: '/error/500',
    page: '/error/500',
  },
  {
    path: '/',
    page: '/Home',
    trackName: '10HO',
    pageId: 'Ho',
  },
  {
    path: '/sample2',
    page: '/sample2',
  },
  {
    path: '/sample3',
    page: '/sample3',
  },
  {
    path: '/sample',
    page: '/sample',
  },
  {
    path: '/search',
    page: '/HotelResults',
    patterns: ['origin:/destination'],
    trackName: '20HL',
    pageId: 'HL',
  },
  {
    path: '/hotel',
    page: '/HotelDetail',
    patterns: ['cityCode:/hotel'],
    trackName: '30HD',
    pageId: 'HD',
  },
  {
    path: '/flights',
    page: '/Flight',
    patterns: ['packageId'],
    trackName: '40FL',
    pageId: 'FL',
  },
  {
    path: '/summary',
    page: '/Summary',
    patterns: ['packageId'],
    trackName: '50SU',
    pageId: 'Sy',
  },
  {
    path: '/details',
    page: '/Details',
    patterns: ['packageId'], // Need to change to bookingId
    trackName: '60PD',
    pageId: 'PD',
  },
  {
    path: '/confirmation',
    page: '/Confirmation',
    patterns: ['bookingId'],
    trackName: '70CO',
    pageId: 'Cn',
  },
  {
    path: '/p',
    page: '/Static',
    patterns: ['slug'],
  },
];

module.exports = routers;
