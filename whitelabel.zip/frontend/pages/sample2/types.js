/**
 * @flow
 */
import { type Config } from 'flow-types';

export * from 'flow-types';

export type SampleProps = {
  config: Config,
  cultureCode: string,
  intl: any,
};
