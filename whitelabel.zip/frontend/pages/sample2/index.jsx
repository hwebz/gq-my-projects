import React from 'react';
import Link from 'next/link';

// @flow
import { type SampleProps } from './types';
import PageBase from '../PageBase';

class Sample extends React.Component<SampleProps> {
  componentDidMount() {
    /*
    * Empty Firts
    */
  }

  render() {
    // TODO: Check out on props validation, and best way to handle props
    // Can use intl here
    // const { intl } = this.props;
    const { config, cultureCode } = this.props;
    const urlLocale = ((cultureCode === config.general.defaultLanguage) ? '' : `/${cultureCode}`).toLowerCase();

    return (
      <div>
        <h1>
          This is the Sample Page 2. The prop is
          <Link href="/sample" as={`${urlLocale}/sample`}>
            <i>
              here
            </i>
          </Link>
          to read more
        </h1>
      </div>
    );
  }
}

export default PageBase(Sample);
