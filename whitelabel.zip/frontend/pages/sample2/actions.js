export const actionTypes = {
  FAILURE: 'FAILURE',
  GET_CLIENT_CONFIG: 'GET_CLIENT_CONFIG',
  GET_CLIENT_CONFIG_SUCCESS: 'GET_CLIENT_CONFIG_SUCCESS',
};

export function failure(error) {
  return {
    type: actionTypes.FAILURE,
    error,
  };
}

export function getClientConfigData() {
  return {
    type: actionTypes.GET_CLIENT_CONFIG,
  };
}

export function getClientConfigDataSuccess(data) {
  console.log('Sample 2: GetClientConfig: Success');
  return {
    type: actionTypes.GET_CLIENT_CONFIG_SUCCESS,
    data,
  };
}
