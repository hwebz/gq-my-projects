// Important Note: No Longer Working

import { actionTypes } from './actions';

function reducer(state = {}, action) {
  switch (action.type) {
    case actionTypes.FAILURE:
      return {
        ...state,
        ...{ error: action.error, isFetching: false },
      };

    case actionTypes.GET_CLIENT_CONFIG:
      return {
        ...state,
        ...{ isFetching: true },
      };

    case actionTypes.GET_CLIENT_CONFIG_SUCCESS:
      return {
        ...state,
        ...{ response: action.data, isFetching: false },
      };

    case actionTypes.GET_CLIENT_CONFIG_FAILED:
      return {
        ...state,
        ...{ response: null },
      };

    default:
      return state;
  }
}

export default reducer;
