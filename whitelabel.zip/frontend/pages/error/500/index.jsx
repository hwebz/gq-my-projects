// @flow
import React from 'react';

import PageBase from '../../PageBase';
import ErrorComponent from '../components/500';
import '../error.scss';

import { type ErrorProps } from '../types';

function ErrorPage({ urlLocale }: ErrorProps) {
  return <ErrorComponent urlLocale={urlLocale} />;
}

export default PageBase(ErrorPage, { hasCurrencySwitcher: false });
