// @flow

export type ErrorProps = {
  urlLocale: string,
};
