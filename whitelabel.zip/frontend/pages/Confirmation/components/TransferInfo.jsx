import React from 'react';
import { FormattedMessage } from 'react-intl';
// import PassengerInfoItem from './PassengerInfoItem';
import DateFormat from 'components/DateFormat';
import type { Format } from 'components/DateFormat';
import ComponentBase from 'components/ComponentBase';
import './TransferInfo.scss';

// @flow
import type { TransferInfoProps } from './types';

const TransferInfo = (props: TransferInfoProps) => {
  const {
    title,
    date,
    time,
    pickupPoint,
    dropOffPoint,
    cultureCode,
  } = props;

  return (
    <div className="card__body transfer-info">
      <div className="transfer-info__title">
        {title}
      </div>
      <div className="transfer-info__details">
        <div className="transfer-info__wrap date-time">
          <div className="transfer-info__group">
            <span className="transfer-info__label">
              <FormattedMessage
                id="TransferInfo.dateTitle"
                defaultMessage="Date"
              />
            </span>
            <span>
              <DateFormat
                value={date}
                format={('MEDIUM': Format)}
                locale={`${cultureCode}`}
              />
            </span>
          </div>
          <div className="transfer-info__group">
            <span className="transfer-info__label">
              <FormattedMessage
                id="TransferInfo.timeTitle"
                defaultMessage="Time"
              />
            </span>
            <span>
              <FormattedMessage
                id="TransferInfo.timeValue"
                defaultMessage="{time} (Local Time)"
                values={{ time }}
              />
            </span>
          </div>
        </div>
        <div className="transfer-info__wrap">
          <div className="transfer-info__icon">
            <svg width="24" height="24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M17.786 13.868l3.047-3.374a.65.65 0 0 0-.043-.914.64.64 0 0 0-.909.044l-2.095 2.32V3.586A2.579 2.579 0 0 0 15.214 1H8.786a2.58 2.58 0 0 0-2.572 2.586v8.358L4.12 9.624a.64.64 0 0 0-.909-.044.65.65 0 0 0-.043.914l3.047 3.374v6.546A2.579 2.579 0 0 0 8.786 23h6.428a2.58 2.58 0 0 0 2.572-2.586v-6.546zM16.5 6.199a2.546 2.546 0 0 0-1.286-.346H8.786c-.469 0-.908.126-1.286.346V3.586a1.29 1.29 0 0 1 1.286-1.292h6.428c.71 0 1.286.579 1.286 1.292v2.613zm0 8.69v5.525a1.29 1.29 0 0 1-1.286 1.292H8.786c-.71 0-1.286-.579-1.286-1.292V14.89c.378.22.817.346 1.286.346h6.428c.469 0 .908-.126 1.286-.346zm-9-2.243V8.442a1.29 1.29 0 0 1 1.286-1.295h6.428c.71 0 1.286.58 1.286 1.295v4.204a1.29 1.29 0 0 1-1.286 1.295H8.786A1.29 1.29 0 0 1 7.5 12.646z" fill="#999" />
            </svg>
            <div className="transfer-info__group">
              <span className="transfer-info__label">
                <FormattedMessage
                  id="TransferInfo.pickupTitle"
                  defaultMessage="Pick-Up"
                />
              </span>
              <span>
                {pickupPoint}
              </span>
            </div>
          </div>
          <div className="transfer-info__icon">
            <svg width="24" height="24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M11.43 22.832a.82.82 0 0 0 .573.241.796.796 0 0 0 .574-.241l5.183-5.183a.813.813 0 0 0 0-1.154.813.813 0 0 0-1.154 0l-3.788 3.793V1.743a.812.812 0 0 0-.815-.816.812.812 0 0 0-.816.816v18.545l-3.793-3.793a.813.813 0 0 0-1.154 0 .813.813 0 0 0 0 1.154l5.19 5.183z" fill="#999" />
            </svg>
            <div className="transfer-info__group">
              &nbsp;
            </div>
          </div>
          <div className="transfer-info__icon">
            <svg width="24" height="24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 1C7.589 1 4 4.589 4 9c0 1.49.413 2.945 1.194 4.207l6.35 10.233a.667.667 0 0 0 .567.316h.005a.667.667 0 0 0 .567-.325L18.872 13.1A7.99 7.99 0 0 0 20 9c0-4.411-3.589-8-8-8zm5.727 11.414l-5.626 9.394-5.774-9.304A6.659 6.659 0 0 1 5.324 9c0-3.676 3-6.676 6.676-6.676s6.671 3 6.671 6.676c0 1.205-.33 2.386-.944 3.414z" fill="#999" />
              <path d="M12 5C9.794 5 8 6.794 8 9c0 2.191 1.765 4 4 4 2.262 0 4-1.833 4-4 0-2.206-1.794-4-4-4zm0 6.676A2.678 2.678 0 0 1 9.324 9 2.685 2.685 0 0 1 12 6.324 2.681 2.681 0 0 1 14.671 9 2.672 2.672 0 0 1 12 11.676z" fill="#999" />
            </svg>
            <div className="transfer-info__group">
              <span className="transfer-info__label">
                <FormattedMessage
                  id="TransferInfo.dropOffTitle"
                  defaultMessage="Drop-Off"
                />
              </span>
              <span>
                {dropOffPoint}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComponentBase(TransferInfo, {
  hasCultureCode: true,
});
