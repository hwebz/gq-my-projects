import React from 'react';

import { defineMessages } from 'react-intl';
import './ContactInfo.scss';

// @flow
import type { ContactInfoProps } from './types';

const defaultMessages = defineMessages({
  emailTitle: {
    id: 'contactInfo.emailTitle',
    defaultMessage: 'Email:',
  },
  mobileNumberTitle: {
    id: 'contactInfo.mobileNumberTitle',
    defaultMessage: 'Mobile Number:',
  },
});

const ContactInfo: Function = (props: ContactInfoProps) => {
  const { contactDetails, intl } = props;

  const { formatMessage } = intl;
  return (
    <div className="card card--with-border">
      <div className="card__body contact-info">
        <div className="contact-info__name">
          <strong>
            {`${contactDetails.firstName} ${contactDetails.lastName}`}
          </strong>
        </div>
        <p className="contact-info--grey">
          {contactDetails.email && (
            <React.Fragment>
              <span>
                {formatMessage(defaultMessages.emailTitle)}
              </span>
              <b>
                {contactDetails.email}
              </b>
            </React.Fragment>
          )}
          {contactDetails.phone && (
            <React.Fragment>
              <br />
              <span>
                {formatMessage(defaultMessages.mobileNumberTitle)}
              </span>
              <b>
                {contactDetails.phone}
              </b>
            </React.Fragment>
          )}
        </p>
      </div>
    </div>
  );
};

export default ContactInfo;
