import React from 'react';
import PassengerInfoItem from './PassengerInfoItem';
import './PassengerInfo.scss';

// @flow
import type { PassengerInfoProps } from './types';

const PassengerInfo: Function = (props: PassengerInfoProps) => {
  const { passengerDetails } = props;
  return (
    <div className="card card--with-border">
      {passengerDetails.map((item, indexPassenger) => (
        <PassengerInfoItem
          passenger={item}
          key={`PassengerInfo_item_${indexPassenger.toString()}`}
          passengerStt={indexPassenger + 1} // Passenger number
        />
      ))}
    </div>
  );
};

export default PassengerInfo;
