/*
 * @flow
 */
import type { IntlShape } from 'react-intl';
import type {
  ConfirmationData,
  ConfirmationStatus,
  ContactDetail,
  PassengerDetails,
} from '../types';

export * from 'flow-types';

export type ConfirmationHeaderProps = {
  title: string,
  classMore: string,
  icon: string,
};

export type ConfirmationMessageProps = {
  confirmationData: ConfirmationData,
  confirmationStatus: ConfirmationStatus,
};

export type ConfirmationMessageItemProps = {
  icon: string,
  type: string,
  title: string,
  text: string,
  animation: string,
};

export type ContactInfoProps = {
  contactDetail: ContactDetail,
  intl: IntlShape,
};

export type PassengerInfoProps = {
  passengerDetails: PassengerDetails,
};

export type PassengerInfoItemProps = {
  passenger: PassengerDetails,
  passengerStt: number,
  intl: IntlShape,
  cultureCode: string,
};

export type TransferInfoProps = {
  title: string,
  date: string,
  time: string,
  pickupPoint: string,
  dropOffPoint: string,
  cultureCode: string,
};
