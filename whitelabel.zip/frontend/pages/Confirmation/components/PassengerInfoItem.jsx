import React from 'react';
import { defineMessages } from 'react-intl';
import DateFormat from 'components/DateFormat';
import type { Format } from 'components/DateFormat';
import ComponentBase from 'components/ComponentBase';
// @flow
import type { PassengerInfoItemProps } from './types';

const defaultMessages = defineMessages({
  passengerTitle: {
    id: 'passengerInfoItem.passengerTitle',
    defaultMessage: 'Passenger',
  },
  dateOfBirth: {
    id: 'passengerInfoItem.dateOfBirth',
    defaultMessage: 'Date of Birth:',
  },
  citizenship: {
    id: 'passengerInfoItem.citizenship',
    defaultMessage: 'Citizenship:',
  },
});

const PassengerInfoItem: Function = (props: PassengerInfoItemProps) => {
  const {
    passenger, passengerStt, intl, cultureCode,
  } = props;

  const { formatMessage } = intl;

  return (
    <div className="card__body passenger-info">
      <div className="passenger-info__count passenger-info--grey">
        <strong>
          {formatMessage(defaultMessages.passengerTitle)}
          {' '}
          {passengerStt}
        </strong>
      </div>
      <div className="passenger-info__details">
        <div className="passenger-info__details__name">
          {`${passenger.title} ${passenger.firstName} ${passenger.lastName}`}
        </div>
        <p className="passenger-info--grey">
          {passenger.nationality && (
            <React.Fragment>
              <span>
                {formatMessage(defaultMessages.citizenship)}
              </span>
              <b>
                {passenger.nationality}
              </b>
              <br />
            </React.Fragment>
          )}
          {passenger.dob && (
            <React.Fragment>
              <span>
                {formatMessage(defaultMessages.dateOfBirth)}
              </span>
              <b>
                <DateFormat
                  value={passenger.dob}
                  format={('MEDIUM': Format)}
                  locale={`${cultureCode}`}
                />
              </b>
            </React.Fragment>
          )}
        </p>
      </div>
    </div>
  );
};

export default ComponentBase(PassengerInfoItem, {
  hasCultureCode: true,
});
