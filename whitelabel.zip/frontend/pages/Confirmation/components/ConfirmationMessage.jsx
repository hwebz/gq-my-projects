import React from 'react';
import { FormattedMessage } from 'react-intl';
import ConfirmationMessageItem from './ConfirmationMessageItem';
import './ConfirmationMessage.scss';


// @flow
import type { ConfirmationMessageProps } from './types';

const loadingIcon: HTMLDocument = (
  <svg data-name="payment-loader" xmlns="http://www.w3.org/2000/svg" width="96" height="96" fill="#343a40">
    <path d="M3.13 32.37h72.53v14A18.66 18.66 0 0 0 58.47 63H5.9c-2 0-2.77-.79-2.77-2.77zm72.53-11.26H3.13v-2.86c0-2 .78-2.77 2.77-2.77h67c2 0 2.77.78 2.77 2.77zM4.2 12.36a4.2 4.2 0 0 0-4.2 4.2v45.37a4.2 4.2 0 0 0 4.2 4.2h54.19a18.65 18.65 0 1 0 20.4-19.71V16.56a4.2 4.2 0 0 0-4.2-4.2zm57.7 52.83a15.32 15.32 0 1 1 15.32 15.33A15.32 15.32 0 0 1 61.9 65.19z" />
    <circle id="firstDot" cx="70.87" cy="64.88" r="2.08" />
    <animate xlinkHref="#firstDot" attributeName="opacity" attributeType="XML" values="1; .2; 1" begin="0s" dur="1s" repeatCount="indefinite" />
    <circle id="secondDot" cx="77.53" cy="64.88" r="2.08" />
    <animate xlinkHref="#secondDot" attributeName="opacity" attributeType="XML" values="1; .2; 1" begin="0.2s" dur="1s" repeatCount="indefinite" />
    <circle id="thirdDot" cx="83.99" cy="64.88" r="2.08" />
    <animate xlinkHref="#thirdDot" attributeName="opacity" attributeType="XML" values="1; .2; 1" begin="0.4s" dur="1s" repeatCount="indefinite" />
  </svg>
);

const successIcon: HTMLDocument = (
  <svg width={88} height={88} fill="none">
    <path
      d="M44 0C19.738 0 0 19.738 0 44c0 24.261 19.738 44 44 44 24.261 0 44-19.739 44-44-.002-24.262-19.739-44-44-44zm0 80.908c-20.351 0-36.908-16.557-36.908-36.91C7.092 23.647 23.649 7.09 44 7.09 64.351 7.09 80.908 23.65 80.908 44c0 20.351-16.557 36.908-36.908 36.908z"
      fill="#fff"
    />
    <path
      d="M58.025 29.97L37.487 50.508l-7.515-7.515a3.542 3.542 0 0 0-5.013 0 3.542 3.542 0 0 0 0 5.013l10.022 10.022a3.538 3.538 0 0 0 5.013 0L63.04 34.984a3.547 3.547 0 0 0-5.014-5.015z"
      fill="#fff"
    />
  </svg>
);

const successAnimation: HTMLDocument = (
  <svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 200 1366 100">
    <g id="airplane" transform="translate(31, -68)">
      <path d="M-32.3 71.2l-.1-1.3c-.1-.4 0-.7.1-1l-5.4-2.5c-.8-.4-.8-.8.1-.8l4.9-.4-6.4-15.9c-.3-.6-.2-1.1.4-1.1l3.5-.1c1.1-.1 2.2.5 3 1.3l13.8 12.9 7.6 3 52.4-3.7c6.9-.4 17.3 1.8 17.5 5.6.2 3.7-9.9 7.5-16.8 8.1l-7.3.5c-.5 2.2-3.3 3.9-5.5 4.1l-6.6-.5c-3.4-.7-5.3-1.1-5.9-2.3l-11.4.7c-14.1.7-37.7-2.9-37.9-6.6zm.1-2.4zm16.9 3.4h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6h-.1c-.4.1-.6.3-.6.7l.1.6c.2.4.5.6.7.6zm3.1-.2h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6h-.1c-.4.1-.6.3-.6.7l.1.6c.1.4.4.6.7.6zm3-.2h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6h-.1c-.3 0-.6.3-.6.7l.1.6c.1.4.4.6.7.6zm3.1-.2h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6h-.1c-.3 0-.6.3-.6.7l.1.6c0 .4.3.7.7.6zm3.1-.1h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6h-.1c-.3 0-.6.3-.6.7l.1.6c0 .4.3.6.7.6zm3-.2h.1c.4-.1.6-.3.6-.7L.6 70c0-.3-.3-.6-.7-.6h-.1c-.4.1-.6.3-.6.7l.1.6c.1.3.4.6.7.6zm3-.2h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6h-.1c-.4.1-.6.3-.6.7l.1.6c.1.3.4.6.7.6zm3-.2h.1c.4-.1.6-.3.6-.7l-.1-.6c.1-.3-.2-.6-.6-.6h-.1c-.4.1-.6.3-.6.7l.1.6c.1.3.3.6.6.6zm3.1-.2h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6h-.1c-.4.1-.6.3-.6.7l.1.6c0 .4.4.6.7.6zm3-.2h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6h-.1c-.4.1-.6.3-.6.7l.1.6c.1.4.4.6.7.6zm3.1-.2h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6H15c-.4.1-.6.3-.6.7l.1.6c0 .4.3.6.7.6zm3-.2h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6H18c-.4.1-.6.3-.6.7l.1.6c.1.3.3.6.7.6zm3-.3h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6H21c-.3 0-.6.3-.6.7l.1.6c.1.4.4.7.7.6zm3.1 0h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6h-.1c-.3 0-.6.3-.6.7l.1.6c.1.3.3.5.7.6zm3-.2h.1c.4-.1.6-.3.6-.7v-.7c0-.3-.3-.6-.7-.6h-.1c-.3 0-.6.3-.6.7l.1.6c.1.4.3.6.6.7zm3.1-.2h.1c.4-.1.6-.3.6-.7L31 68c0-.3-.3-.6-.7-.6h-.1c-.4.1-.6.3-.6.7l.1.6c0 .4.4.7.7.7zm3-.3h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6h-.1c-.4.1-.6.3-.6.7l.1.6c.1.4.4.6.7.6zm3-.2h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6h-.1c-.4.1-.6.3-.6.7l.1.6c.1.4.4.7.7.6zm3.1-.2h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6h-.1c-.4.1-.6.3-.6.7l.1.6c0 .4.3.7.7.6zm3-.2h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6h-.1c-.4.1-.6.3-.6.7l.1.6c.1.4.4.7.7.6zm3-.1h.1c.4-.1.6-.3.6-.7l-.1-.7c0-.3-.3-.6-.7-.6h-.1c-.3 0-.6.3-.6.7l.1.6c.1.4.4.7.7.7zm3-.3h.1c.4-.1.6-.3.6-.7l-.1-.6c0-.3-.3-.6-.7-.6h-.1c-.3 0-.6.3-.6.7l.1.6c.2.4.4.6.7.6z" fill="#fff" />
    </g>
    <path id="line" d="M111 276s764-6.2 1056-108.6" fill="none" stroke="#fff" strokeDasharray="4 8" />
    <path id="linePath" d="M1171.5,167c0,0-180.5,64-533,86.5S85.5,276,85.5,276" />
    <animateMotion
      xlinkHref="#airplane"
      dur="1.6s"
      begin="0s"
      fill="freeze"
      keyPoints="1;0"
      keyTimes="0;1"
      calcMode="linear"
      rotate="auto-reverse"
    >
      <mpath xlinkHref="#linePath" />
    </animateMotion>
  </svg>
);

const pendingIcon: HTMLDocument = (
  <svg width="88" height="88" viewBox="0 0 88 88" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M44 0C19.7385 0 0 19.7385 0 44C0 68.2615 19.7385 88 44 88C68.2615 88 88 68.2615 88 44C87.9984 19.7385 68.2615 0 44 0ZM44 80.9081C23.6486 80.9081 7.09188 64.3514 7.09188 43.9984C7.09188 23.647 23.6486 7.0903 44 7.0903C64.3514 7.0903 80.9081 23.6486 80.9081 44C80.9081 64.3514 64.3514 80.9081 44 80.9081Z" fill="white" />
    <path d="M57.75 61.5H55.25V54C55.2445 49.7819 52.88 45.9214 49.1251 44C51.5046 42.7753 53.3723 40.7462 54.3961 38.2737C54.4126 38.2389 54.4224 38.2038 54.4361 38.1663C54.9711 36.8421 55.2473 35.4279 55.25 34V26.5H57.75C58.4403 26.5 59 25.9403 59 25.25C59 24.5597 58.4403 24 57.75 24H30.25C29.5597 24 29 24.5597 29 25.25C29 25.9403 29.5597 26.5 30.25 26.5H32.75V34C32.7512 35.4276 33.0259 36.8418 33.5587 38.1663C33.5724 38.2038 33.5825 38.2389 33.599 38.2737C34.6241 40.7471 36.4939 42.7762 38.8752 44C35.12 45.9214 32.7555 49.7822 32.75 54V61.5H30.25C29.5597 61.5 29 62.0597 29 62.75C29 63.4403 29.5597 64 30.25 64H57.75C58.4403 64 59 63.4403 59 62.75C59 62.0597 58.4403 61.5 57.75 61.5ZM52.75 26.5V34C52.7476 34.8472 52.6212 35.6895 52.3749 36.5H35.6251C35.3788 35.6895 35.2524 34.8472 35.25 34V26.5H52.75ZM36.8299 39H51.1701C48.4196 42.96 42.9795 43.9402 39.0198 41.1896C38.165 40.5961 37.4235 39.8545 36.8299 39ZM42.75 45.3501V49C42.75 49.6903 43.3097 50.25 44 50.25C44.6903 50.25 45.25 49.6903 45.25 49V45.3501C49.5496 45.9739 52.7418 49.6555 52.75 54V55.25H35.25V54C35.2582 49.6555 38.4504 45.9739 42.75 45.3501ZM35.25 61.5V57.75H52.75V61.5H35.25Z" fill="white" stroke="white" strokeWidth="2" />
  </svg>
);


const ConfirmationMessage: Function = (props: ConfirmationMessageProps) => {
  const {
    confirmationData,
    confirmationStatus,
  } = props;

  const loadingText = (
    <FormattedMessage
      id="ConfirmationMessage.loadingText"
      defaultMessage="Please do not close or refresh this window. {breakline} This might take up to a minute."
      values={{
        breakline: (<br />),
      }}
    />
  );

  const successText = (
    <FormattedMessage
      id="ConfirmationMessage.successText"
      defaultMessage="Thank you for completing the booking with us. {breakline} Your receipt and itinerary has been sent to {email}"
      values={{
        email: (
          <strong>
            {confirmationData ? confirmationData.contactDetails.email : ''}
          </strong>
        ),
        breakline: (<br />),
      }}
    />
  );

  const pendingText = (
    <FormattedMessage
      id="ConfirmationMessage.pendingText"
      defaultMessage="We’ll deliver your trip vouchers within 1-2 working days to email {email} {breakline} Your payment has been received, please contact support@email.com if you have any issues."
      values={{
        email: (
          <strong>
            {confirmationData ? confirmationData.contactDetails.email : ''}
          </strong>
        ),
        breakline: (<br />),
      }}
    />
  );

  return confirmationStatus ? (
    <div>
      {
        confirmationStatus === 1 && (
          <ConfirmationMessageItem
            icon={successIcon}
            type="success"
            title={<FormattedMessage id="ConfirmationMessage.successTitle" defaultMessage="Your trip booking is successful." />}
            text={successText}
            animation={successAnimation}
          />
        )
      }
      {
        confirmationStatus === 2 && (
          <ConfirmationMessageItem
            icon={pendingIcon}
            type="pending"
            title={<FormattedMessage id="ConfirmationMessage.pendingTitle" defaultMessage="Your booking is being processed." />}
            text={pendingText}
          />
        )
      }
      {
        confirmationStatus === 0 && (
          <ConfirmationMessageItem
            icon={loadingIcon}
            type="loading"
            title={<FormattedMessage id="ConfirmationMessage.loadingTitle" defaultMessage="Processing Payment" />}
            text={loadingText}
          />
        )
      }
    </div>
  ) : (
    <ConfirmationMessageItem
      icon={loadingIcon}
      type="loading"
      title={<FormattedMessage id="ConfirmationMessage.loadingTitle" defaultMessage="Processing Payment" />}
      text={loadingText}
    />
  );
};

export default ConfirmationMessage;
