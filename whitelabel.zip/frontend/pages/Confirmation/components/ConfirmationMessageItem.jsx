import React from 'react';

// @flow
import type { ConfirmationMessageItemProps } from './types';

const ConfirmationMessageItem: Function = (props: ConfirmationMessageItemProps) => {
  const {
    icon, type, title, text, animation,
  } = props;
  return (
    <div
      className={` ${
        type !== 'loading' ? 'animated fade-in' : ''
      } confirmation-notify confirmation-notify__${type} text-center`}
    >
      <div className="confirmation-notify__icon">
        {icon}
      </div>
      <div className="confirmation-notify__detail">
        <div className="confirmation-notify__title">
          {title}
        </div>
        <div className="confirmation-notify__text">
          <p>
            {text || ''}
          </p>
        </div>
      </div>
      {animation && (
      <div className="confirmation-notify__animation">
        {animation}
      </div>
      )}
    </div>
  );
};

export default ConfirmationMessageItem;
