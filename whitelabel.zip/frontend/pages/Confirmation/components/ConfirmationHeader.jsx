import React from 'react';

// @flow
import type { ConfirmationHeaderProps } from './types';

const ConfirmationHeader: Function = (props: ConfirmationHeaderProps) => {
  const { classMore, title, icon } = props;
  return (
    <h2 className={`confirmation__header ${classMore}`}>
      <i>
        {icon}
      </i>
      <strong>
        {title}
      </strong>
    </h2>
  );
};

export default ConfirmationHeader;
