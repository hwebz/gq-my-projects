// @flow
import { type IntlShape } from 'react-intl';
import {
  type HotelSummary,
  type PassengerSummaryDetails,
  type Dispatch,
  type Config,
  type FlightSummary,
  type ContactDetails,
} from '../../flow-types';
import { type SearchQuery } from '../Flight/types';
import { type PageBaseProps } from '../PageBase/types';

export * from '../../flow-types';

export type ConfirmationQueryParams = {
  bookingId: string,
};

export type ConfirmationProps = PageBaseProps<ConfirmationQueryParams> & {
  bookingId: string,
  intl: IntlShape,
  config: Config,
};

export type DepartureArrivalInfo = {
  airportCode: string,
  airportName: string,
  date: string,
  time: string,
};

export type FlightLegDetails = {
  aircraftModel: string,
  airlineCodes: string,
  airlineName: string,
  arrival: DepartureArrivalInfo,
  baggageWeight: number,
  cabinClassCode: string,
  cabinClassName: string,
  departure: DepartureArrivalInfo,
  duration: number,
  flightNumber: string,
  transitDuration: ?number,
};

export type ConfirmationData = {
  contactDetails: ContactDetails,
  firstView: boolean,
  flightSummary: FlightSummary,
  hotelSummary: HotelSummary,
  passengerDetails: Array<PassengerSummaryDetails>,
  priceSummary: {
    addons: {
      transfer: number,
    },
    adult: number,
    child: number,
    currency: string,
    infant: number,
    savings: number,
    taxesFees: number,
    total: number,
  },
  reference: string,
  searchQuery: SearchQuery,
};

export type ConfirmationStatus = {
  status: number,
};

export type ConfirmationContainerProps = {
  confirmationData: ConfirmationData,
  confirmationStatus: ConfirmationStatus,
  cultureCode: string,
  dispatch: Dispatch,
  intl: IntlShape,
  bookingId: string,
};
