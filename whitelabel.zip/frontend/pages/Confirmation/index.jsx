import React from 'react';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import PageBase from '../PageBase';
import ConfirmationContainer from './ConfirmationContainer';
import { hasMissingQuery } from '../../react-next/utils/query-string';
import { getConfirmationRequest } from '../../store-app/modules/confirmation-page/actions';

// @flow
import { type ConfirmationProps, type ConfirmationQueryParams, type Context } from './types';

class Confirmation extends React.Component<ConfirmationProps> {
  static async getInitialProps({ ctx }: Context<ConfirmationQueryParams>) {
    const {
      store,
      initPayload: { combinedQueryParams },
    } = ctx;

    const hasQueryError = hasMissingQuery(combinedQueryParams, ['bookingId']);

    if (!hasQueryError) {
      store.dispatch(getConfirmationRequest(combinedQueryParams.bookingId));
      return { hasQueryError, bookingId: combinedQueryParams.bookingId };
    }

    return { hasQueryError };
  }

  render() {
    const { bookingId, config } = this.props;
    const { name } = config.general;
    return (
      <React.Fragment>
        <FormattedMessage
          id="confirmation.title"
          defaultMessage="Thank you for booking with {name}"
          values={{ name }}
        >
          {title => (
            <Helmet>
              <title>
                {title}
              </title>
            </Helmet>
          )}
        </FormattedMessage>
        <ConfirmationContainer bookingId={bookingId} />
      </React.Fragment>
    );
  }
}

export default PageBase(Confirmation, { hasCurrencySwitcher: false });
