import React from 'react';
import {
  MdHotel,
  MdAirplanemodeActive,
  MdPerson,
  MdPermContactCalendar,
  MdAttachMoney,
  MdDirectionsCar,
} from 'react-icons/md';

import { defineMessages } from 'react-intl';
import DateFormat from 'components/DateFormat';
import type { Format } from 'components/DateFormat';

import {
  pollStatusRequest,
  setTrackRequest,
} from '../../store-app/modules/confirmation-page/actions';

import {
  getConfirmationData,
  getConfirmationStatus,
  getIsFetching,
} from '../../store-app/modules/confirmation-page/selectors';

import './Confirmation.scss';
import ConfirmationMessage from './components/ConfirmationMessage';
import HotelDetailSummary from '../../components/HotelSummary/HotelDetailSummary';
import FlightItemCard from '../../components/FlightItemCard';
import PassengerInfo from './components/PassengerInfo';
import ContactInfo from './components/ContactInfo';
import SidebarSummary from '../../components/Sidebars/SidebarSummary';
import ConfirmationHeader from './components/ConfirmationHeader';

// @flow
import { type ConfirmationContainerProps } from './types';
import TransferInfo from './components/TransferInfo';
import ComponentBase, {
  type GenericComponent,
} from '../../components/ComponentBase';

const track = require('../../react-next/utils/track-utils');

const defaultMessages = defineMessages({
  tripBookingId: {
    id: 'confirmation.tripBookingId',
    defaultMessage: 'TRIP BOOKING ID',
  },
  hotelInfoTitle: {
    id: 'confirmation.hotelInfo',
    defaultMessage: 'Hotel Info',
  },
  flightInfoTitle: {
    id: 'confirmation.flightInfo',
    defaultMessage: 'Flight Info',
  },
  departureTitle: {
    id: 'confirmation.departure',
    defaultMessage: 'Departure',
  },
  returnTitle: {
    id: 'confirmation.return',
    defaultMessage: 'Return',
  },
  passengerInfoTitle: {
    id: 'confirmation.pasengerInfo',
    defaultMessage: 'Passenger info',
  },
  transferInfoTitle: {
    id: 'confirmation.transferInfo',
    defaultMessage: 'Your Ride',
  },
  contactInfoTitle: {
    id: 'confirmation.contactInfo',
    defaultMessage: 'Contact info',
  },
  paymentDetailTitle: {
    id: 'confirmation.paymentDetail',
    defaultMessage: 'Payment Detail',
  },
});

class ConfirmationContainer extends React.Component<
  ConfirmationContainerProps
> {
  constructor(props: ConfirmationContainerProps) {
    super(props);
    this.state = {};
  }

  componentDidMount() {
    const { dispatch, confirmationData, bookingId } = this.props;
    dispatch(pollStatusRequest(bookingId));
    if (confirmationData && confirmationData.firstView) {
      // console.log('tracked'); // TODO Trigger event tracking call
      track.ecommerce(bookingId, confirmationData);
      dispatch(setTrackRequest(bookingId));
    }
  }

  render() {
    const {
      confirmationData,
      confirmationStatus,
      cultureCode,
      intl,
    } = this.props;

    const paxCounts = {};
    let hasTransferSummary = true;
    let sidebarSummary = {};
    if (confirmationData) {
      // Make paxCounts object
      paxCounts.adult = confirmationData.searchQuery.adultCount;
      paxCounts.child = confirmationData.searchQuery.childCount;
      paxCounts.infant = confirmationData.searchQuery.infantCount;

      // Check transferSummary
      if (
        confirmationData.transferSummary === undefined
        || !confirmationData
        || !(confirmationData.transferSummary.arrivalTransfer
          && confirmationData.transferSummary.departureTransfer)
      ) {
        hasTransferSummary = false;
      }

      sidebarSummary = {
        ...confirmationData.priceSummary,
        paxCounts,
      };
    }

    const { formatMessage } = intl;
    return (
      <div>
        <ConfirmationMessage
          confirmationData={confirmationData}
          confirmationStatus={confirmationStatus}
          formatMessage={formatMessage}
        />

        <div className="summary__wrap">
          <div className="summary__bookingid">
            <div className="summary__bookingid__box">
              <span>{formatMessage(defaultMessages.tripBookingId)}</span>
              <strong>{confirmationData ? confirmationData.reference : ''}</strong>
            </div>
          </div>
          <div className="container no-padding-on-small">
            <div className="summary__content confirmation">
              <div className="summary__detail">
                <ConfirmationHeader
                  classMore=""
                  title={formatMessage(defaultMessages.hotelInfoTitle)}
                  icon={<MdHotel />}
                />
                {(confirmationData && (
                  <HotelDetailSummary
                    summary={confirmationData.hotelSummary}
                    cultureCode={cultureCode}
                    isConfirmation
                    isFetching={false}
                  />
                )) || (
                  <div className="confirmation__loading content-placeholder">
                    &nbsp;
                  </div>
                )}
                <ConfirmationHeader
                  classMore=""
                  title={formatMessage(defaultMessages.flightInfoTitle)}
                  icon={<MdAirplanemodeActive />}
                />
                {(confirmationData && confirmationData.flightSummary && (
                  <div className="card card--with-border ">
                    <div className="card__body confirmation__flight">
                      <h2 className="confirmation__flight__title">
                        {formatMessage(defaultMessages.departureTitle)}
                      </h2>
                      <div className="confirmation__flight__date">
                        <DateFormat
                          value={
                            confirmationData.flightSummary.departFlight
                              .departure.date
                          }
                          format={('LONG': Format)}
                          locale={`${cultureCode}`}
                        />
                      </div>
                    </div>
                    <FlightItemCard
                      isSummary
                      isDetailOpen
                      isConfirmation
                      flightItem={confirmationData.flightSummary.departFlight}
                      currency={confirmationData.priceSummary.currency}
                    />
                    <div className="card__body confirmation__flight">
                      <h2 className="confirmation__flight__title">
                        {formatMessage(defaultMessages.returnTitle)}
                      </h2>
                      <div className="confirmation__flight__date">
                        <DateFormat
                          value={
                            confirmationData.flightSummary.returnFlight
                              .departure.date
                          }
                          format={('LONG': Format)}
                          locale={`${cultureCode}`}
                        />
                      </div>
                    </div>
                    <FlightItemCard
                      isSummary
                      isDetailOpen
                      isConfirmation
                      flightItem={confirmationData.flightSummary.returnFlight}
                      currency={confirmationData.priceSummary.currency}
                    />
                  </div>
                )) || (
                  <div className="confirmation__loading content-placeholder">
                    &nbsp;
                  </div>
                )}
                {hasTransferSummary && (
                  <React.Fragment>
                    <ConfirmationHeader
                      classMore=""
                      title={formatMessage(defaultMessages.transferInfoTitle)}
                      icon={<MdDirectionsCar />}
                    />
                    <div className="card card--with-border">
                      {(confirmationData && (
                        <React.Fragment>
                          <TransferInfo
                            title="Arrival Transfer"
                            date={
                              confirmationData.transferSummary.arrivalTransfer
                                .date
                            }
                            time={
                              confirmationData.transferSummary.arrivalTransfer
                                .time
                            }
                            pickupPoint={
                              confirmationData.transferSummary.arrivalTransfer
                                .pickup
                            }
                            dropOffPoint={
                              confirmationData.transferSummary.arrivalTransfer
                                .dropoff
                            }
                          />
                          <TransferInfo
                            title="Departing Transfer"
                            date={
                              confirmationData.transferSummary.departureTransfer
                                .date
                            }
                            time={
                              confirmationData.transferSummary.departureTransfer
                                .time
                            }
                            pickupPoint={
                              confirmationData.transferSummary.departureTransfer
                                .pickup
                            }
                            dropOffPoint={
                              confirmationData.transferSummary.departureTransfer
                                .dropoff
                            }
                          />
                        </React.Fragment>
                      )) || (
                        <div className="confirmation__loading content-placeholder">
                          &nbsp;
                        </div>
                      )}
                    </div>
                  </React.Fragment>
                )}
                <ConfirmationHeader
                  classMore=""
                  title={formatMessage(defaultMessages.passengerInfoTitle)}
                  icon={<MdPerson />}
                />
                {(confirmationData && (
                  <PassengerInfo
                    passengerDetails={confirmationData.passengerDetails}
                  />
                )) || (
                  <div className="confirmation__loading content-placeholder">
                    &nbsp;
                  </div>
                )}
                <ConfirmationHeader
                  classMore=""
                  title={formatMessage(defaultMessages.contactInfoTitle)}
                  icon={<MdPermContactCalendar />}
                />
                {(confirmationData && (
                  <ContactInfo
                    contactDetails={confirmationData.contactDetails}
                    intl={intl}
                  />
                )) || (
                  <div className="confirmation__loading content-placeholder">
                    &nbsp;
                  </div>
                )}
              </div>
              <div className="summary__sidebar">
                <ConfirmationHeader
                  classMore=""
                  title={formatMessage(defaultMessages.paymentDetailTitle)}
                  icon={<MdAttachMoney />}
                />
                {(confirmationData && (
                  <SidebarSummary
                    hasContinueButton={false}
                    canAddTransfer={false}
                    summary={sidebarSummary}
                  />
                )) || (
                  <div className="confirmation__loading content-placeholder">
                    &nbsp;
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  confirmationData: getConfirmationData(state),
  confirmationStatus: getConfirmationStatus(state),
  isFetching: getIsFetching(state),
});

const injection: GenericComponent<ConfirmationContainerProps> = ComponentBase;

export default injection(ConfirmationContainer, {
  mapStateToProps,
  hasCultureCode: true,
  hasUrlLocale: true,
});
