// @flow
import { type GeneralInfo } from '../../../../flow-types';

export type HeaderProps = {
  generalConfig: GeneralInfo,
  locale: string,
  hasCurrencySwitcher: boolean,
};
