import React from 'react';
// import { connect } from 'react-redux';

import CurrenciesSwitcher from '../../../../components/CurrenciesSwitcher';

import './Header.scss';

// @flow
import { type HeaderProps } from './types';

const sortAlphabetically = (name1, name2) => {
  if (name1 < name2) return -1;
  if (name1 > name2) return 1;
  return 0;
};

const Header = (props: HeaderProps) => {
  const { generalConfig, hasCurrencySwitcher } = props;
  const { currencies } = generalConfig;
  currencies.sort((cr1, cr2) => sortAlphabetically(cr1, cr2));
  const logo = generalConfig.logo || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/logo-default.png';
  const name = generalConfig.name || 'GoQuo';
  return (
    <header className="header">
      <div className="container container--header">
        <div className="header__logo">
          <a href="/">
            <img className="img-responsive" src={logo} alt={name} />
          </a>
        </div>
        <div className="header__lang" />
        {hasCurrencySwitcher && currencies && currencies.length > 1 ? (
          <CurrenciesSwitcher currencies={currencies} />
        ) : null}
      </div>
    </header>
  );
};

export default Header;
