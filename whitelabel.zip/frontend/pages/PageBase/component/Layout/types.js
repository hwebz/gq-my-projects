// @flow

import { type GeneralInfo } from 'flow-types';

export * from 'flow-types';

export type LayoutProps = {
  generalConfig: GeneralInfo,
  children: any,
  hasCurrencySwitcher: boolean,
};
