// @flow

import React from 'react';
import Header from '../Header';
import Footer from '../Footer';
import { type LayoutProps } from './types';

const Layout = ({ children, generalConfig, hasCurrencySwitcher }: LayoutProps) => (
  <div>
    <Header generalConfig={generalConfig} hasCurrencySwitcher={hasCurrencySwitcher} />
    {children}
    <Footer generalConfig={generalConfig} />
  </div>
);

export default Layout;
