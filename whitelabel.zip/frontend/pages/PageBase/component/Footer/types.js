// @flow
export type FooterProps = {
  clientConfig: any,
};
