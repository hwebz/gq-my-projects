import React from 'react';
import { FormattedMessage } from 'react-intl';
import './Footer.scss';

// @flow
import { type FooterProps } from './types';


const Footer = ({ generalConfig }: FooterProps) => {
  const date = new Date();
  const year = date.getFullYear();
  const { footerText } = generalConfig;

  /* eslint-disable react/no-danger */
  return (
    <footer className="footer">
      <div className="container">
        {footerText && (
          <p
            className="footer__text"
            dangerouslySetInnerHTML={{
              __html: footerText,
            }}
          />
        ) || (
          <p className="footer__text">
            <FormattedMessage id="Footer.text" defaultMessage="Copyright (c) {year}" values={{ year }} />
          </p>
        )}
      </div>
    </footer>
  );
  /* eslint-enable react/no-danger */
};

export default Footer;
