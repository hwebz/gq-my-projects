// @flow
import React, { type ComponentType } from 'react';
import axios from 'axios';
import { Helmet } from 'react-helmet';
import { FeatureToggles } from '@paralleldrive/react-feature-toggles';
import { type PageBaseProps, type Config, type Context } from './types';

// Utils
import ComponentUtils from 'react-next/utils/component-utils';
import RouterUtils from 'react-next/utils/router-utils';
import { removeQuery } from 'react-next/utils/query-string';
import CustomRouter from '../../utils/custom-router';

// Components
import ComponentError404 from '../error/components/404';
import ComponentError500 from '../error/components/500';
import Layout from './component/Layout';
import Alert from '../../components/Alert';
import AlertMessages from '../../components/Common/AlertMessages';

// redux store:
import { resetStates as resetErrorStates } from '../../store-app/modules/error/actions';
import { getIsShow } from '../../store-app/modules/alert/selectors';
import { getCultureCode, getUrlLocale } from '../../store-app/modules/locale-selection/selectors';
import currencyActionTypes from '../../store-app/modules/currency-selection/action-types';
import { getSelectedCurrency } from '../../store-app/modules/currency-selection/selectors';
import { getCountryCodeFromCookie } from '../../store-app/modules/country/actions';
import setConfig from '../../store-app/modules/config/actions';
import { closePopup } from '../../store-app/modules/alert/actions';
import setCultureCode from '../../store-app/modules/locale-selection/actions';

function getPageBase(
  Page: ComponentType<*>,
  isFeatured?: boolean = false,
  isLayouted?: boolean = true,
  hasCurrencySwitcher?: boolean = true,
) {
  return class PageBase extends React.Component<PageBaseProps<Object>> {
    static withLayout(config: Config, page) {
      return (
        <Layout generalConfig={config.general} hasCurrencySwitcher={hasCurrencySwitcher}>
          {page}
        </Layout>
      );
    }

    // Important Note: This should be the way to wrap any provider
    // Only if the provider is not huge like PageWithIntl
    static withFeatured(config: Config, page) {
      const features = [];
      const featureKeys = Object.keys(config.features);

      featureKeys.forEach((element) => {
        if (config.features[element]) {
          features.push(element);
        }
      });

      return <FeatureToggles features={features}>{page}</FeatureToggles>;
    }

    /*/
    // isShowAlertBox will use mapStateToProps
    constructor(props) {
      super(props);
      this.state = {
        isShowAlertBox: false,
      };
    }
    /*/

    componentDidMount() {
      const {
        hasUrlCurrency, selectedCurrency, dispatch, cookies,
      } = this.props;
      if (hasUrlCurrency) {
        dispatch({
          type: currencyActionTypes.SELECT_CURRENCY,
          currency: selectedCurrency,
        });
      }
      dispatch(getCountryCodeFromCookie({ cookie: cookies }));
    }

    static async getInitialProps(context: Context<Object>) {
      const {
        ctx: {
          req, store, query, isServer, asPath,
        },
      } = context;

      // console.log('GetInitialProps - Pagebase - initPayload', context);
      // console.log('GetInitialProps - Pagebase - asPath', asPath);
      // console.log('GetInitialProps - Pagebase - query', query);
      // get the request object
      let localParams = {};
      if (req && req.headers && req.headers.host) {
        axios.defaults.headers.common.origin = req.headers.host;
        axios.interceptors.request.use((request) => {
          console.log('Axios: Starting Request', request);
          return request;
        });
        axios.interceptors.response.use((response) => {
          console.log('Axios: Response:', response);
          return response;
        });
      }

      if (!isServer) {
        // Get Params
        if (asPath) {
          const routerInfo = CustomRouter.getRouteInfo(removeQuery(asPath));
          if (routerInfo.route) {
            localParams = CustomRouter.getReqParams(routerInfo.pathWithoutLocale, routerInfo.route);
          }
        }
      }

      const { config, locale } = req || ComponentUtils.getWindowInitialPageProps().pageProps;

      // This is because context.ctx.initPayload is required to be reassigned
      // and passed to WrappedPage Component
      const combinedQueryParams = RouterUtils.combineQueryAndParams(
        query,
        req ? req.params : localParams,
      );

      /*
      * Change cultureCode to getting from state and re-render page for culture code change,
      * Don't need to make a url call to hit node server
      */
      let hasUrlCurrency: boolean = false;

      store.dispatch(resetErrorStates());
      store.dispatch(setConfig(config));
      store.dispatch(setCultureCode(locale, config));
      if (typeof query.currency !== 'undefined') {
        hasUrlCurrency = true;
        store.dispatch({
          type: currencyActionTypes.SELECT_CURRENCY_FROM_URL_REQUEST,
          payload: { currency: query.currency, cookie: req ? req.headers.cookie : null },
        });
      } else {
        store.dispatch({
          type: currencyActionTypes.GET_SELECTED_CURRENCY_REQUEST,
          /* Add this condition to avoid silly react-next reloading error,
          but apparently req should not be undefined */
          payload: { cookie: req ? req.headers.cookie : null },
        });
      }

      let props;

      // eslint-disable-next-line
      context.ctx.initPayload = {
        config,
        locale,
        combinedQueryParams,
        selectedCurrency: getSelectedCurrency(store.getState()),
        cultureCode: getCultureCode(store.getState()),
        urlLocale: getUrlLocale(store.getState()),
      };

      // $FlowIgnore ignore as it is to check if the property exist
      if (typeof Page.getInitialProps === 'function') {
        props = await Page.getInitialProps(context); // This will call pages getInitialProps
      }

      return {
        config,
        combinedQueryParams,
        hasUrlCurrency,
        hasQueryError: false, // Initial state is false
        cookies: req ? req.headers.cookie : null,
        ...props,
      };
    }

    getPage(pageProps: PageBaseProps<Object>) {
      const {
        isShowAlertBox, urlLocale, hasQueryError, hasError404, hasError500,
      } = this.props;
      // eslint-disable-next-line
      // const message = 'This is an alert message and it will be a long one. This is an alert message and it will be a long one. This is an alert message and it will be a long one. This is an alert message and it will be a long one. This is an alert message and it will be a long one.';
      // isAlertOpen message={message} alertType={0} redirectionUrl="/"
      const alert = isShowAlertBox ? (
        <Alert handleAlertBox={this.closeAlertBox} urlLocale={urlLocale} />
      ) : null;

      if (hasError404) {
        return <ComponentError404 urlLocale={urlLocale} />;
      }

      if (hasError500) {
        return <ComponentError500 urlLocale={urlLocale} />;
      }
      /*/
      const finalProps = {
        showAlertBox: this.showAlertBox,
        ...pageProps,
      };
      /*/
      if (hasQueryError) {
        return (
          <AlertMessages
            errors={{
              general: {
                status: 0,
                message: 'Invalid page request',
              },
            }}
          />
        );
      }

      return (
        <React.Fragment>
          {alert}
          <Page {...pageProps} />
        </React.Fragment>
      );
    }

    closeAlertBox = () => {
      const { isShowAlertBox, dispatch } = this.props;
      if (isShowAlertBox) {
        dispatch(closePopup());
      }
    };

    baseRender(config: Config, pageProps) {
      return (
        <div>
          <Helmet>
            <link
              rel="icon"
              type="image/png"
              href={
                config.general.favicon
                || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/favicon-default.png'
              }
            />
          </Helmet>
          <style jsx global>
            {`
              .theme-primary-text {
                color: ${config.general.primaryColor || '#4583c4'};
              }
              .theme-secondary-text {
                color: ${config.general.secondaryColor || '#17b36e'};
              }
              .btn-theme-primary {
                background: ${config.general.primaryColor || '#4583c4'};
                color: ${config.general.primaryColorText || '#fff'};
                border-color: ${config.general.primaryColor || '#4583c4'};
              }
              .btn-theme-primary:hover {
                background: ${config.general.primaryColorHover || '#3f78b3'};
                color: ${config.general.primaryColorText || '#fff'};
              }
              .btn-theme-primary:focus {
                background: ${config.general.primaryColorHover || '#3f78b3'};
                color: ${config.general.primaryColorText || '#fff'};
              }
              .btn-theme-primary-outline {
                background: ${config.general.primaryColorText || '#fff'};
                border-color: ${config.general.primaryColor || '#4583c4'};
                color: ${config.general.primaryColor || '#4583c4'};
              }
              .btn-theme-primary-outline:hover {
                background: ${config.general.primaryColor || '#fff'};
                border-color: ${config.general.primaryColor || '#4583c4'};
                color: ${config.general.primaryColorText || '#4583c4'};
              }
              .btn-theme-primary-outline:focus {
                background: ${config.general.primaryColor || '#fff'};
                border-color: ${config.general.primaryColor || '#4583c4'};
                color: ${config.general.primaryColorText || '#4583c4'};
              }
              .btn-theme-secondary {
                background: ${config.general.secondaryColor || '#17b36e'};
                color: ${config.general.secondaryColorText || '#fff'};
                border: ${config.general.secondaryColor || '#17b36e'};
              }
              .btn-theme-secondary:hover {
                background: ${config.general.secondaryColorHover || '#15a364'};
                color: ${config.general.secondaryColorText || '#fff'};
              }
              .btn-theme-secondary:focus {
                background: ${config.general.secondaryColorHover || '#15a364'};
                color: ${config.general.secondaryColorText || '#fff'};
              }
              .btn-theme-secondary-outline {
                background: ${config.general.secondaryColorText || '#fff'};
                border-color: ${config.general.secondaryColor || '#4583c4'};
                color: ${config.general.secondaryColor || '#4583c4'};
              }
              .btn-theme-secondary-outline:hover,
              .btn-theme-secondary-outline.is-active {
                background: ${config.general.secondaryColor || '#fff'};
                border-color: ${config.general.secondaryColor || '#4583c4'};
                color: ${config.general.secondaryColorText || '#4583c4'};
              }
              .btn-theme-secondary-outline:focus {
                background: ${config.general.secondaryColor || '#fff'};
                border-color: ${config.general.secondaryColor || '#4583c4'};
                color: ${config.general.secondaryColorText || '#4583c4'};
              }
              .btn-theme-secondary-halo {
                background: 'transparent';
                border-color: ${config.general.secondaryColor || '#4583c4'};
                color: ${config.general.secondaryColor || '#4583c4'};
              }
              .btn-theme-secondary-halo:hover {
                background: ${config.general.secondaryColor || '#4583c4'};
                border-color: ${config.general.secondaryColor || '#4583c4'};
                color: ${config.general.secondaryColorText || '#fff'};
              }
              .btn-theme-secondary-halo:focus,
              .btn-theme-secondary-halo:active {
                background: #fff;
                border-color: ${config.general.secondaryColor || '#4583c4'};
                color: ${config.general.secondaryColor || '#4583c4'};
              }
              .btn-theme-secondary-halo:hover .btn-icon {
                color: ${config.general.secondaryColor || '#4583c4'};
                border-color: ${config.general.secondaryColor || '#4583c4'};
              }
              .panel-mobile__title {
                background: ${config.general.secondaryColor || '#17b36e'};
                color: '#fff';
              }
              .link-theme-primary {
                color: ${config.general.linkColor || '#4583c4'};
              }
              .sort-bar__item--active,
              .sort-bar-theme-secondary.selected,
              .sort-bar-theme-secondary.selected .active {
                color: ${config.general.secondaryColor || '#4583c4'};
                border-color: ${config.general.secondaryColor || '#4583c4'};
              }
              .sort-bar__item:focus {
                color: ${config.general.secondaryColor || '#4583c4'};
                border-color: ${config.general.secondaryColor || '#4583c4'};
              }
              .sort-bar__item:hover {
                color: ${config.general.secondaryColor || '#4583c4'};
              }
              .sort-bar__item--active:before {
                background-color: ${config.general.secondaryColor || '#4583c4'};
              }
              .filter-bar__price-range,
              .input-range__label {
                color: ${config.general.secondaryColor || '#4583c4'};
              }
              .input-range__track--active,
              .input-range__slider {
                background: ${config.general.secondaryColor || '#4583c4'};
                border: ${config.general.secondaryColor || '#4583c4'};
              }
              .sidebar-summary__addOns {
                fill: ${config.general.secondaryColor || '#4583c4'};
              }
              .flight-result-item:hover .flight-buttons__select-button {
                background-color: ${config.general.primaryColorHover || '#4583c4'};
              }
            `}
          </style>
          {isLayouted
            ? PageBase.withLayout(config, this.getPage(pageProps))
            : this.getPage(pageProps)}
        </div>
      );
    }

    render() {
      const {
        config, cultureCode, urlLocale, selectedCurrency, ...props
      } = this.props;

      const pageProps = {
        config,
        cultureCode,
        urlLocale,
        selectedCurrency,
        ...props,
      };

      let pageSetup = this.baseRender(config, pageProps);

      if (isFeatured) {
        pageSetup = PageBase.withFeatured(config, pageSetup);
      }

      return pageSetup;
    }
  };
}

export default getPageBase;
