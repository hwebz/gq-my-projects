// @flow
import { type IntlShape } from 'react-intl';

import { type Config, type Dispatch, } from '../../flow-types';

export * from '../../flow-types';

export type PageBaseProps<T: Object> = {
  config: Config,
  cultureCode: string,
  urlLocale: string,
  selectedCurrency: string,
  isShowAlertBox: boolean,
  hasUrlCurrency: boolean,
  combinedQueryParams: T,
  dispatch: Dispatch,
  hasQueryError: boolean,
  hasError404: boolean,
  hasError500: boolean,
  intl: IntlShape,
  cookie: Object, // Cookie
};

export type OptionsObject = {
  mapStateToProps?: Function,
  isFeatured?: boolean,
  isLayouted?: boolean,
  hasCurrencySwitcher?: boolean,
};
