// This will be the HOC to do most of the wrapping so pages.
// Intention:
// 1. Reduce Import Codes at Child Pages and Plugins Dependencies
// 2. Handle Common Functionalities across pages
// 3. Child Pages will only need to concern on compositing the components

// @flow
import React, { type ComponentType } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'next/router';

import PageWithIntl from 'react-next/components/PageWithIntl';
import JsonUtils from 'react-next/utils/json-utils';

import { getIsShow } from 'store-app/modules/alert/selectors';
import { getCultureCode, getUrlLocale } from 'store-app/modules/locale-selection/selectors';
import { getSelectedCurrency } from 'store-app/modules/currency-selection/selectors';
import { getHasError404, getHasError500 } from 'store-app/modules/error/selectors';

import {
  type OptionsObject
} from './types';

import getPageBase from './hoc';

// When Provider Grows, Prepare a set of Providers True False
const defaultMapStateToProps: Function = state => ({
  selectedCurrency: getSelectedCurrency(state),
  cultureCode: getCultureCode(state),
  urlLocale: getUrlLocale(state),
  isShowAlertBox: getIsShow(state),
  hasError404: getHasError404(state),
  hasError500: getHasError500(state),
});

const defaultPageOption: OptionsObject = {
  mapStateToProps: undefined,
  isFeatured: false,
  isLayouted: true,
  hasCurrencySwitcher: true,
};

export default function (Page: ComponentType<*>, options?: OptionsObject = defaultPageOption) {
  let pageOption = options;

  if (options !== defaultPageOption) {
    pageOption = JsonUtils.overrideValues(defaultPageOption, options);
  }

  const combinedMapStateToProps = state => ({
    ...state,
    ...defaultMapStateToProps(state),
    ...(pageOption.mapStateToProps ? pageOption.mapStateToProps(state) : {}),
  });

  return withRouter(
    connect(combinedMapStateToProps)(
      PageWithIntl(
        getPageBase(
          Page,
          pageOption.isFeatured,
          pageOption.isLayouted,
          pageOption.hasCurrencySwitcher,
        ),
      ),
    ),
  );
}

/*/
export default (Page, isFeatured: boolean = false) => connect(state => ({
  ...state,
  selectedCurrency: getSelectedCurrency(state),
  cultureCode: getCultureCode(state),
  urlLocale: getUrlLocale(state),
}))(PageWithIntl(getPageBase(Page, isFeatured)));
/*/
