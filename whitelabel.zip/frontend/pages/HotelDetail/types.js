/**
 * @flow
 */
import {
  type GetStaticHotelInfoResponse,
  type GetHotelImageGalleryResponse,
  type GetPackageQueryResponse,
  type GetRoomDetailsResponse,
  type Dispatch,
} from '../../flow-types';

import { type PageBaseProps } from '../PageBase/types';

export * from '../../flow-types';

export type EFilterRoomOptions = "breakfast" | "cancellation";

export type HotelDetailState = {
  isGalleryOpen: boolean,
  roomFilter: {
    isBreakfast: boolean,
    isCancellation: boolean
  }
};

export type HotelDetailQueryParams = {
  cityCode: string,
  hotel: string,
  id: string
};

export type HotelDetailProps = PageBaseProps<HotelDetailQueryParams> & {
  hotelData: ?GetStaticHotelInfoResponse,
  dispatch: Dispatch,
  hotelImages: GetHotelImageGalleryResponse,
  packageDetails: GetPackageQueryResponse,
  hotelId?: string,
  packageId: string,
  roomData: GetRoomDetailsResponse,
  isRoomDataFetching: boolean,
  isFetching?: boolean,
  isClientSide: boolean
};
