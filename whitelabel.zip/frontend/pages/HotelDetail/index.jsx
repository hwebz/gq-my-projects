import React, { Component } from 'react';
import { defineMessages } from 'react-intl';
import { Helmet } from 'react-helmet';
import ScrollableAnchor, { configureAnchors, goToAnchor } from 'react-scrollable-anchor';
// import Link from 'next/link';
// icon imports
import { MdCameraAlt as IconCamera } from 'react-icons/md';
import { differenceInDays } from 'date-fns';
import 'mapbox-gl/dist/mapbox-gl.css';
// Common components
// import DockedFooter from 'components/DockedFooter';
import ModifySearch from 'components/ModifySearch';
import DockedFooter from '../../components/DockedFooter';

// @flow
// Local proptypes
import {
  type HotelDetailProps,
  type HotelDetailState,
  type HotelDetailQueryParams,
  type Context,
  type EFilterRoomOptions,
  type StandardEventFunction,
  type HotelRoomPriceItem,
} from './types';
import { getHotelDetails, getRooms } from '../../store-app/modules/hotel-details/actions';
import PageBase from '../PageBase';
import { getPackageQuery } from '../../store-app/modules/package/actions';
import { getPackageQueryDetails } from '../../store-app/modules/package/selectors';
import { getSearchDestinationCityName } from '../../store-app/modules/search-form/selectors';

// Local styling
import './HotelDetail.scss';

// Components
import HotelDetailsTitle from './components/HotelDetailsTitle';
import PackageSummary from './components/PackageSummary';
import HotelPackagePrice from './components/HotelPackagePrice';
import HotelTrustYouSummary from './components/HotelTrustYouSummary';
import HotelRoomResultContainer from './components/HotelRoomResultContainer';
import HotelReviewList from './components/HotelReviewList';
import HotelDetailInfo from './components/HotelDetailInfo';
import Gallery from '../../components/Common/Gallery';
import { getImageUrlsString } from '../../utils/image-utils';
import { hasMissingQuery } from '../../react-next/utils/query-string';
import { getAirportRequest } from '../../store-app/modules/search-form/actions';
import {
  getRoomData,
  getHotelData,
  getIsRoomDataFetching,
} from '../../store-app/modules/hotel-details/selectors';

const track = require('../../react-next/utils/track-utils');

const defaultMessages = defineMessages({
  HotelPageTitle: {
    id: 'hotel.pageTitle',
    defaultMessage: '{hotelName} in {cityName} - Package Deals & Reviews | {siteName}',
  },
});

class HotelDetail extends Component<HotelDetailProps, HotelDetailState> {
  constructor(props) {
    super(props);
    this.state = {
      isGalleryOpen: false,
      roomFilter: {
        isBreakfast: false,
        isCancellation: false,
      },
    };
  }

  componentDidMount() {
    const {
      dispatch,
      hotelId,
      packageId,
      router,
      defaultConfig,
      hotelDetail,
    } = this.props;
    dispatch(getRooms({
      hotelId,
      packageId,
    }));
    // eslint-disable-next-line
    const { packageQueryDetails } = this.props.package;
    const { origin, destination, rooms } = packageQueryDetails;
    const { hotelData } = hotelDetail;
    let adults = 0;
    let children = 0;
    let infants = 0;
    // eslint-disable-next-line
    rooms.map((pax) => {
      adults += pax.adults;
      if (pax.children.length) {
        // eslint-disable-next-line
        pax.children.map((age) => {
          if (age > 2) {
            children += 1;
          } else {
            infants += 1;
          }
        });
      }
    });
    if (packageQueryDetails && hotelData) {
      track.page(
        router.pathname,
        defaultConfig.environment,
        {
          Origin: origin,
          Destination: destination,
          HotelName: hotelData.name,
          HotelID: hotelId,
          StarCategory: hotelData.stars,
          Rating: hotelData.review ? hotelData.review.score : 'No Rating',
          Rooms: rooms.length,
          Adults: adults,
          Children: children,
          Infant: infants,
        },
      );
    }
  }

  static onSelectHotelRoom() {
    // Smooth scroll to anchor
    goToAnchor('roomOption', true);
    configureAnchors({ scrollDuration: 300 });
  }

  static async getInitialProps({ ctx }: Context<HotelDetailQueryParams>) {
    const {
      store,
      initPayload: { combinedQueryParams, cultureCode },
      isServer,
    } = ctx;

    const hasQueryError: boolean = hasMissingQuery(combinedQueryParams, [
      'id',
      'cityCode',
      'hotel',
    ]);
    if (!hasQueryError) {
      const packageId: string = combinedQueryParams.id;
      const hotelId: string = combinedQueryParams.hotel.substr(
        0,
        combinedQueryParams.hotel.indexOf('-'),
      );

      await store.execSagaTasks(isServer, (dispatch) => {
        dispatch(getPackageQuery(packageId));
        dispatch(getHotelDetails(hotelId, cultureCode));
      });

      const { packageQueryDetails } = store.getState().package;
      store.dispatch(
        getAirportRequest({
          origin: packageQueryDetails.origin,
          destination: packageQueryDetails.destination,
        }),
      );
      const isClientSide: boolean = isServer === false;
      return {
        hasQueryError,
        cityCode: combinedQueryParams.cityCode,
        hotelId,
        packageId,
        isClientSide,
      };
    }

    return { hasQueryError };
  }

  // This function is needed in the index of pagebase if gallery is used.
  handleToggleGallery = (e: SyntheticEvent<HTMLElement>, isGalleryOpen: boolean) => {
    e.stopPropagation();
    // value can either be true/false, to hide/show the gallery popup modal
    this.setState({
      isGalleryOpen,
    });
  };

  toggleFilterRooms: StandardEventFunction = (
    e: SyntheticEvent<HTMLElement>,
    filterType: EFilterRoomOptions,
  ) => {
    e.stopPropagation();
    const { roomFilter } = this.state;
    const { router, combinedQueryParams, hotelDetail } = this.props;
    const { hotelData } = hotelDetail;
    let isBreakfastSelected = false;
    let isCancellationtSelected = false;
    if (filterType === 'breakfast') {
      const filter = {
        isBreakfast: !roomFilter.isBreakfast,
        isCancellation: roomFilter.isCancellation,
      };
      isBreakfastSelected = e.target.checked;
      this.setState({
        roomFilter: filter,
      });
    } else if (filterType === 'cancellation') {
      const filter = {
        isBreakfast: roomFilter.isBreakfast,
        isCancellation: !roomFilter.isCancellation,
      };
      isCancellationtSelected = e.target.checked;
      this.setState({
        roomFilter: filter,
      });
    }
    track.event(
      router.pathname,
      `FILTER Selected ${filterType} filter`,
      hotelData.name,
      {
        HotelName: hotelData.name,
        Destination: combinedQueryParams.cityCode,
        isBreakfastSelected,
        isCancellationtSelected,
      },
    );
  };

  handleFilterRooms = (rooms) => {
    const { roomFilter } = this.state;
    let filteredRooms = [];

    if (rooms && rooms.length > 0) {
      if (roomFilter.isBreakfast && !roomFilter.isCancellation) {
        for (let i = 0; i < rooms.length; i++) {
          const filteredOptions = rooms[i].options.filter(option => option.boardType > 1);
          if (filteredOptions.length > 0) {
            filteredRooms.push({
              name: rooms[i].name,
              image: rooms[i].image,
              size: rooms[i].size,
              description: rooms[i].description,
              options: filteredOptions,
            });
          }
        }
        return filteredRooms;
      }

      if (roomFilter.isCancellation && !roomFilter.isBreakfast) {
        for (let i = 0; i < rooms.length; i++) {
          const filteredOptions = rooms[i].options.filter(option => option.freeCancellationBefore);
          if (filteredOptions.length > 0) {
            filteredRooms.push({
              name: rooms[i].name,
              image: rooms[i].image,
              size: rooms[i].size,
              description: rooms[i].description,
              options: filteredOptions,
            });
          }
        }
        return filteredRooms;
      }

      if (roomFilter.isCancellation && roomFilter.isBreakfast) {
        for (let i = 0; i < rooms.length; i++) {
          const filteredOptions = rooms[i].options.filter(
            option => option.boardType > 1 && option.freeCancellationBefore,
          );
          if (filteredOptions.length > 0) {
            filteredRooms.push({
              name: rooms[i].name,
              image: rooms[i].image,
              size: rooms[i].size,
              description: rooms[i].description,
              options: filteredOptions,
            });
          }
        }
        return filteredRooms;
      }
      filteredRooms = rooms;
      return filteredRooms;
    }

    return filteredRooms;
  };

  props: HotelDetailProps;

  render() {
    const {
      hotelData,
      packageDetails,
      config,
      hotelId,
      roomData,
      isRoomDataFetching,
      isClientSide,
      router,
      intl,
      destinationCity,
      packageId,
    } = this.props;

    const siteName: string = config.general.name;
    const { formatMessage } = intl;
    const { isGalleryOpen, roomFilter } = this.state;
    const nightsCount: ?number = packageDetails
      ? differenceInDays(packageDetails.returnDate, packageDetails.departureDate)
      : null;

    let summaryTotalPrice: number = 0;
    if (Object.keys(roomData).length > 0 && roomData.rooms.length > 0) {
      const cheapestPrice: HotelRoomPriceItem = roomData.rooms[0].options[0].price;
      summaryTotalPrice = config.features.useTotalPrice
        ? cheapestPrice.perPackage.price
        : cheapestPrice.perPerson.price;
    }

    if (!isRoomDataFetching) {
      router.prefetch('/Flight');
    }
    return (
      <React.Fragment>
        <Helmet>
          <title>
            {formatMessage(
              defaultMessages.HotelPageTitle,
              { hotelName: hotelData.name, cityName: destinationCity, siteName },
            )}
          </title>
        </Helmet>
        <div className="hotel-detail">
          <ModifySearch searchQuery={packageDetails} isClientSide={isClientSide} router={router} />

          <div className="hotel-detail-container">
            <main className="hotel-detail-wrap hotel-detail-wrap--hotel">
              <div className="first-container">
                <HotelDetailsTitle
                  name={hotelData.name}
                  stars={hotelData.stars}
                  address={hotelData.address}
                  lon={hotelData.lon}
                  lat={hotelData.lat}
                />
                <HotelPackagePrice
                  isLoading={isRoomDataFetching}
                  roomData={roomData}
                  onSelectHotelRoom={HotelDetail.onSelectHotelRoom}
                />
                <div
                  className="hotel-img"
                  style={{ backgroundImage: getImageUrlsString(hotelData.image, 'HOTEL') }}
                  onClick={
                    e => (hotelData.imageCount > 1 ? this.handleToggleGallery(e, true) : null)
                  }
                  role="presentation"
                >
                  {hotelData.imageCount > 1 && (
                    <div className="img-gallery-btn">
                      <IconCamera />
                      <span className="img-gallery-total">
                        {hotelData.imageCount}
                      </span>
                    </div>
                  )}
                </div>
                {isGalleryOpen && (
                  <Gallery
                    isGalleryOpen
                    handleToggleGallery={this.handleToggleGallery}
                    hotelId={hotelId}
                  />
                )}
                <HotelTrustYouSummary
                  review={hotelData.review}
                  description={hotelData.description}
                />
              </div>
            </main>
            <div className="container visible-md">
              <PackageSummary
                summary={{
                  total: summaryTotalPrice,
                  isLoading: isRoomDataFetching,
                  roomData,
                  returnDate: packageDetails.returnDate,
                  nightsCount,
                }}
                MainView={PackageSummary}
                isHotelDetail
                isLoading={isRoomDataFetching}
              />
            </div>
            <ScrollableAnchor id="roomOption">
              <HotelRoomResultContainer
                hotelName={hotelData.name}
                router={router}
                isLoading={isRoomDataFetching}
                roomData={roomData}
                hotelStayDates={{
                  departureDate: packageDetails.departureDate,
                  returnDate: packageDetails.returnDate,
                }}
                packageDetails={packageDetails}
                popOverInfo={{
                  roomCount: roomData.roomCount,
                  paxCount: roomData.paxCount,
                  nightsCount,
                  destination: packageDetails.destination,
                  origin: packageDetails.origin,
                  departureDate: packageDetails.departureDate,
                  returnDate: packageDetails.returnDate,
                }}
                toggleFilterRooms={this.toggleFilterRooms}
                roomFilter={roomFilter}
                filteredRooms={this.handleFilterRooms(roomData.rooms)}
                packageId={packageId}
              />
            </ScrollableAnchor>
            {hotelData.review && hotelData.review.score > 0 && (
              <ScrollableAnchor id="hotelReviews">
                <HotelReviewList
                  review={hotelData.review}
                  hotelName={hotelData.name}
                  noOfPax={roomData.paxCount}
                  router={router}
                />
              </ScrollableAnchor>
            )}
            <ScrollableAnchor id="aboutHotel">
              <HotelDetailInfo
                name={hotelData.name}
                description={hotelData.description}
                lon={hotelData.lon}
                lat={hotelData.lat}
                amenities={hotelData.amenities}
                checkInTime={hotelData.checkInTime}
                checkOutTime={hotelData.checkOutTime}
                info={hotelData.info}
                router={router}
              />
            </ScrollableAnchor>
          </div>
          <DockedFooter
            summary={{
              total: summaryTotalPrice,
              isLoading: isRoomDataFetching,
              roomData,
              returnDate: packageDetails.returnDate,
              currency: packageDetails.currency,
              nightsCount,
            }}
            MainView={PackageSummary}
            isHotelDetail
            isLoading={isRoomDataFetching}
          />
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  isRoomDataFetching: getIsRoomDataFetching(state),
  hotelData: getHotelData(state),
  packageDetails: getPackageQueryDetails(state),
  roomData: getRoomData(state),
  destinationCity: getSearchDestinationCityName(state),
});

export default PageBase(HotelDetail, {
  mapStateToProps,
  hasCurrencySwitcher: false,
});
