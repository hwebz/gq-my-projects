import React from 'react';
import { FormattedMessage } from 'react-intl';
import './HotelRoomResultFilter.scss';
// import { injectIntl, intlShape } from 'react-intl';

// @flow
import { type HotelRoomResultFilterProps } from './types';

function HotelRoomResultFilter({
  isLoading, rooms,
  toggleFilterRooms, roomFilter,
}: HotelRoomResultFilterProps) {
  let hasBreakfast: boolean = false;
  let hasFreeCancellation: boolean = false;

  rooms.forEach((room) => {
    room.options.forEach((option) => {
      if (option.boardType > 1) {
        hasBreakfast = true;
      }
      if (option.freeCancellationBefore) {
        hasFreeCancellation = true;
      }
    });
  });

  return (
    !isLoading && (hasBreakfast || hasFreeCancellation) ? (
      <div className="checkbox room-filter-checkbox">
        <div className="checkbox__title">
          <FormattedMessage
            id="HotelRoomResultFilter.filter"
            defaultMessage="Filter"
          />
        </div>
        <div className="checkbox__group">
          {hasBreakfast && (
            <label
              className={`checkbox__wrapper pills ${roomFilter.isBreakfast ? 'active' : ''}`}
              htmlFor="breakfastIncluded"
              role="presentation"
            >
              <span className="checkbox__label">
                <FormattedMessage
                  id="HotelRoomResultFilter.breakfastIncluded"
                  defaultMessage="Breakfast Included"
                />
              </span>
              <input
                className="checkbox__input"
                type="checkbox"
                id="breakfastIncluded"
                name="breakfastIncluded"
                value="breakfastIncluded"
                onChange={e => toggleFilterRooms(e, 'breakfast')}
              />
            </label>
          )}
          {hasFreeCancellation && (
            <label
              className={`checkbox__wrapper pills ${roomFilter.isCancellation ? 'active' : ''}`}
              htmlFor="freeCancellation"
              role="presentation"
            >
              <span className="checkbox__label">
                <FormattedMessage
                  id="HotelRoomResultFilter.freeCancellation"
                  defaultMessage="Free cancellation"
                />
              </span>
              <input
                className="checkbox__input"
                type="checkbox"
                id="freeCancellation"
                name="freeCancellation"
                value="freeCancellation"
                onChange={e => toggleFilterRooms(e, 'cancellation')}
              />
            </label>
          )}
        </div>
      </div>
    ) : null
  );
}

export default HotelRoomResultFilter;
