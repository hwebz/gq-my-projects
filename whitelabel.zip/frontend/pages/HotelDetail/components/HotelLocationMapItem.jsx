import React from 'react';
import MapGL, { Marker } from 'react-map-gl';
// @flow
import { type GetStaticHotelInfoResponse } from './types';

const accessToken = 'pk.eyJ1IjoiZ29xdW8td2hpdGVsYWJlbCIsImEiOiJjams3MTljMGIxNTB3M3BvNHUyNWRza2JrIn0.tkmROUS49HhH-xVfHn3RPA';

class HotelLocationMapItem extends React.Component <GetStaticHotelInfoResponse> {
  constructor(props: GetStaticHotelInfoResponse) {
    super(props);
    const centerLat = Number(props.lat);
    const centerLong = Number(props.lon);
    this.state = {
      viewport: {
        latitude: centerLat,
        longitude: centerLong,
        zoom: 10,
        bearing: 0,
        pitch: 0,
      },
    };
  }

  _updateViewport: UpdateViewport = (viewport: MapViewport) => {
    this.setState({ viewport });
  }

  render() {
    const {
      lon, lat,
    } = this.props;
    const { viewport } = this.state;
    return (
      lon && lat && (
      <React.Fragment>
        <MapGL
          {...viewport}
          width="100%"
          height="310px"
          mapStyle="mapbox://styles/mapbox/streets-v9"
          /* eslint-disable */
          onViewportChange={this._updateViewport}
          /* eslint-enable */
          mapboxApiAccessToken={accessToken}
        >
          <Marker
            latitude={Number(lat)}
            longitude={Number(lon)}
            offsetLeft={-30}
            offsetTop={-10}
          >
            <svg width="42" height="42" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="21" cy="18" r="16" fill="#fff" />
              <path fillRule="evenodd" clipRule="evenodd" d="M30.852 5.44c.476.376.932.791 1.37 1.249 3.155 3.135 4.732 6.913 4.732 11.337 0 4.403-1.577 8.16-4.732 11.275-.051.071-.102.167-.152.289a1.171 1.171 0 0 0-.335.304l-9.04 9.51c-1.166 1.328-2.317 1.328-3.453 0l-9.358-9.892c-.05-.07-.1-.142-.152-.213C6.577 26.185 5 22.427 5 18.024 5 13.6 6.578 9.822 9.732 6.687a11.63 11.63 0 0 1 1.4-1.248C13.923 3.145 17.213 2 21.009 2c3.752.002 7.034 1.147 9.844 3.44zm3.986 12.538c0-3.804-1.36-7.065-4.077-9.784-2.72-2.718-5.991-4.078-9.815-4.078-3.804 0-7.065 1.36-9.785 4.078-2.717 2.717-4.077 5.979-4.077 9.784 0 3.805 1.36 7.067 4.078 9.784 2.717 2.718 5.978 4.08 9.784 4.08 3.824 0 7.095-1.36 9.815-4.08 2.717-2.717 4.077-5.979 4.077-9.784zm-12.765 3.013h2.541v-2.57h-2.541v2.57zm0-9.402v2.57h2.541v-2.57h-2.541zm5.295 13.344v2.45H14.555v-2.45h1.096V8.547h10.696v16.386h1.02zm-7.273-3.942v-2.57h-2.542v2.57h2.542zm0-6.832v-2.57h-2.542v2.57h2.542z" fill="#429FAA" />
            </svg>
          </Marker>

        </MapGL>
      </React.Fragment>
      )
    );
  }
}

export default HotelLocationMapItem;
