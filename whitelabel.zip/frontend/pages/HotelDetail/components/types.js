// @flow
import { type IntlShape } from 'react-intl';
import {
  type Review, type GetRoomDetailsResponse, type SearchParameterQuery,
  type Rooms, type Options, type StandardEventFunction,
} from '../../../flow-types';

export * from '../../../flow-types';

export type HotelReviewListProps = {
  review: Review,
};

export type HotelReviewListState = {
  seeMoreIndex: number,
  selectedCategory: string,
};

export type HotelDetailInfoState = {
  isAmenitiesMore: boolean,
  isDetailMore: boolean,
}

export type HotelRoomResultContainerProps = {
  isLoading: boolean,
  roomData: GetRoomDetailsResponse,
  hotelStayDates: {
    departureDate: SearchParameterQuery,
    returnDate: SearchParameterQuery,
  },
  toggleFilterRooms: StandardEventFunction,
  roomFilter: {
    isBreakfast: boolean,
    isCancellation: boolean,
  },
  HotelRoomItemProps: GetRoomDetailsResponse,
};

export type HotelRoomResultHeaderProps = {
  hotelNights: GetRoomDetailsResponse,
  hotelStayDates: SearchParameterQuery,
  cultureCode: string,
};

export type HotelRoomResultFilterProps = {
  isLoading: boolean,
  rooms: GetRoomDetailsResponse,
  toggleFilterRooms: StandardEventFunction,
  roomFilter: {
    isBreakfast: boolean,
    isCancellation: boolean,
  },
};

export type HotelPackagePriceProps = {
  isLoading: boolean,
  roomData: GetRoomDetailsResponse,
  featuresConfig: Object, // TODO to be replaced with common flow-types
  cultureCode: string,
};

export type HotelRoomAmenitiesProps = {
  option: Options,
  isBestDeal: boolean,
  featuresConfig: Object, // TODO to be replaced with common flow-types
  cultureCode: string,
  currency: string,
};

export type HotelRoomAmenitiesState = {
  selectedRoomTooltip: string,
};

export type HotelRoomItemState = {
  isOptionsMore: boolean,
  isDescriptionMore: boolean,
};

export type HotelRoomItemProps = {
  room: Rooms,
  roomCount: GetRoomDetailsResponse,
  intl: IntlShape,
  isFirstRoom: boolean,
};

export type PackageSummaryProps = {
  summary: {
    isLoading: boolean,
    roomData: GetRoomDetailsResponse,
    returnDate: string,
    nightsCount: number,
  },
  cultureCode: string,
};
