import React from 'react';
// @flow
import { type GetStaticHotelInfoResponse } from './types';
import Map from './HotelLocationMapItem';


function HotelLocationMap({
  lon,
  lat,
}: GetStaticHotelInfoResponse) {
  return (
    <Map
      lon={lon}
      lat={lat}
    />
  );
}
export default HotelLocationMap;
