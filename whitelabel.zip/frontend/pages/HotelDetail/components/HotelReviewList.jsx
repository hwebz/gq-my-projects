import React from 'react';
import { FormattedMessage } from 'react-intl';
import ScrollableAnchor from 'react-scrollable-anchor';

import {
  MdCheck as IconCheck,
  MdClear as IconClear,
  MdKeyboardArrowDown as IconArrowDown,
  MdKeyboardArrowUp as IconArrowUp,
} from 'react-icons/md';
import './HotelReviewList.scss';
// import { injectIntl, intlShape } from 'react-intl';
import ReviewRating from 'components/ReviewRating';
import ValidationUtils from 'react-next/utils/validation-utils';
// @flow
import { type HotelReviewListProps, type HotelReviewListState } from './types';

const track = require('../../../react-next/utils/track-utils');

class HotelReviewList extends React.Component<
  HotelReviewListProps,
  HotelReviewListState
> {
  constructor(props: HotelReviewListProps) {
    super(props);
    this.state = {
      seeMoreIndex: -1,
      selectedCategory: 'all',
    };
  }

  eventTracking = (props) => {
    const { router } = this.props;
    track.event(
      router.pathname,
      `REVIEW Selected to view ${props.category} reviews`,
      props.label,
      {
        ...props.trackProps,
      },
    );
  }

  toggleSeeMore = (index: number, category: object, selectedCategory: string) => {
    const {
      noOfPax,
      hotelName,
    } = this.props;
    const trackProps = {
      HotelName: hotelName,
      NumberOfPassenger: noOfPax,
      ReviewLabel: category.categoryName,
      ReviewLabelScore: category.score,
      ReviewerGroup: selectedCategory,
    };
    this.eventTracking({ label: selectedCategory, trackProps, category: category.categoryName });
    this.setState({
      seeMoreIndex: index,
    });
  };

  handleSelectedCategory = (category: string) => {
    const {
      noOfPax,
      hotelName,
    } = this.props;
    this.setState({
      selectedCategory: category,
      seeMoreIndex: -1,
    });
    const trackProps = {
      HotelName: hotelName,
      NumberOfPassenger: noOfPax,
    };
    this.eventTracking({ label: hotelName, trackProps, category });
  };

  render() {
    const { review } = this.props;
    const reviewData: {
      score: number,
      text: string,
      review: number
    } = {
      score: review.score,
      text: review.text,
      reviews: review.reviewCount,
    };
    const { seeMoreIndex, selectedCategory } = this.state;
    return (
      <section
        className="product-review full-width-container"
        id="readAllReviews"
      >
        <div className="product-review__header flex-wrapper flex-wrapper--half">
          <h2 className="heading heading--h2">
            <FormattedMessage
              id="HotelReviewList.reviewTitle"
              defaultMessage="Reviews"
            />
          </h2>
          <img
            className="product-review__header-logo"
            src="https://d2va1pbm8mz6cn.cloudfront.net/static/assets/verified-reviews-logo.png"
            alt="TrustYou verified reviews logo"
          />
        </div>

        <div className="product-review__overall">
          <ReviewRating
            {...{
              position: 'left',
              ...reviewData,
            }}
          />
          {review.badgeList
            && review.badgeList.slice(0, 2).map((badge, badgeIndex) => (
              <div
                className="product-review__badges product-review__badges--wellness"
                key={`hotelDetail_badges_${badgeIndex.toString()}`}
              >
                <div className="product-review__badges-icon">
                  <span className="icon icon-badge icon-badge--large" />
                </div>
                <div className="product-review__badges-text">
                  <span className="product-review__text-secondary">
                    {badge.text}
                  </span>
                  <span className="product-review__text-subtitle">
                    {badge.subtext}
                  </span>
                </div>
              </div>
            ))}
        </div>

        {review.summary.text && (
          <div className="product-review__highlight">
            <blockquote className="blockquote" cite="https://quote.link">
              <div>{review.summary.text}</div>
            </blockquote>
          </div>
        )}

        {review.reviews && (
          <React.Fragment>
            <div className="nav-tab nav-tab--pills">
              <div className="nav-tab__wrapper">
                <ul className="nav-tab__list">
                  {Object.keys(review.reviews)
                    .filter(reviewKey => ValidationUtils.isPropertyValid(
                      review.reviews[reviewKey],
                      'reviewsPercent',
                    ))
                    .map(reviewCategory => (
                      <ScrollableAnchor id={`${reviewCategory}`} key={reviewCategory}>
                        <li className="nav-tab__item">
                          <a
                            className={`nav-tab__link btn-theme-secondary-outline ${
                              selectedCategory === reviewCategory ? 'is-active' : ''
                            }`}
                            href={`#${reviewCategory}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              this.handleSelectedCategory(reviewCategory);
                            }}
                          >
                            <strong>{reviewCategory}</strong>
                            <span className="nav-tab__link-count">
                              {`(${review.reviews[reviewCategory].reviewsPercent}%)`}
                            </span>
                          </a>
                        </li>
                      </ScrollableAnchor>
                    ))}
                </ul>
              </div>
            </div>

            <div className="product-review__tab-content">
              {review.reviews[selectedCategory].category.map(
                (category, categoryIndex) => (
                  <div
                    className="product-review__summary"
                    key={`hotelDetail_reviewCategory_${categoryIndex.toString()}`}
                  >
                    <div className="product-review__level">
                      <div className="product-review__label">
                        <strong>{category.categoryName}</strong>
                      </div>
                      <div
                        className="product-review__bar product-review__bar--high"
                        style={{ width: `${category.score}%` }}
                      />
                    </div>
                    <div className="product-review__comment js-parent is-open">
                      <p className="product-review__comment-item">
                        {category.summarySentenceList.map(
                          (summary, summaryIndex) => (
                            <React.Fragment
                              key={`hotelDetail_reviewCategory_summary_${summaryIndex.toString()}`}
                            >
                              {summary}
                              <br />
                            </React.Fragment>
                          ),
                        )}
                      </p>
                      {seeMoreIndex === categoryIndex ? (
                        <a
                          className="product-review__comment-toggle link-theme-color"
                          href="#toggle"
                          title="Close"
                          onClick={(e) => {
                            e.stopPropagation();
                            this.toggleSeeMore(-1, category, selectedCategory);
                          }}
                        >
                          <span className="link--text">
                            <FormattedMessage
                              id="HotelReviewList.seeLess"
                              defaultMessage="See Less"
                            />
                          </span>
                          <i>
                            <IconArrowUp />
                          </i>
                        </a>
                      ) : (
                        <a
                          className="product-review__comment-toggle link-theme-color"
                          href="#toggle"
                          title="Open"
                          onClick={(e) => {
                            e.stopPropagation();
                            this.toggleSeeMore(categoryIndex, category, selectedCategory);
                          }}
                        >
                          <span className="link--text">
                            <FormattedMessage
                              id="HotelReviewList.seeMore"
                              defaultMessage="See More"
                            />
                          </span>
                          <i>
                            <IconArrowDown />
                          </i>
                        </a>
                      )}
                      {seeMoreIndex === categoryIndex && (
                        <ul className="product-review__comment-list animated slide-down">
                          {category.highlightList.map(
                            (highlight, highlightIndex) => (
                              <li
                                className="product-review__comment-list-item"
                                key={`hotelDetail_reviewCategory_highlight_${highlightIndex.toString()}`}
                              >
                                {`"${highlight}"`}
                              </li>
                            ),
                          )}
                        </ul>
                      )}
                    </div>
                  </div>
                ),
              )}

              {review.reviews[selectedCategory].goodToKnow && (
                <div className="product-review__footer">
                  <div className="product-review__footer-header">
                    <p className="heading heading--h4">
                      <FormattedMessage
                        id="HotelReviewList.goodToKnow"
                        defaultMessage="Good to know"
                      />
                    </p>
                  </div>
                  <ul className="product-review__footer-list">
                    {review.reviews[selectedCategory].goodToKnow
                      .slice(0, 4)
                      .map((goodToKnow, goodToKnowIndex) => (
                        <li
                          className="product-review__footer-item"
                          key={`hotelDetail_reviewCategory_goodToKnow_${goodToKnowIndex.toString()}`}
                        >
                          {goodToKnow.sentiment === 'pos' ? (
                            <i className="icon icon-check">
                              <IconCheck />
                            </i>
                          ) : (
                            <i className="icon icon-close">
                              <IconClear />
                            </i>
                          )}
                          <div className="product-review__footer-text">
                            <span className="text--primary">{goodToKnow.text}</span>
                            {goodToKnow.highlightList.map(
                              (goodTokKnowHighlight, goodTokKnowHighlightIndex) => (
                                <span
                                  className="text--secondary"
                                  id={`hotelDetail_reviewCategory_goodToKnow_${goodToKnowIndex}_goodToKnowHighlight_${goodTokKnowHighlightIndex}`}
                                  key={`hotelDetail_reviewCategory_goodToKnowHighlight_${goodTokKnowHighlightIndex.toString()}`}
                                >
                                  {`"${goodTokKnowHighlight}" `}
                                </span>
                              ),
                            )}
                          </div>
                        </li>
                      ))}
                  </ul>
                </div>
              )}
            </div>
          </React.Fragment>
        )}
      </section>
    );
  }
}

export default HotelReviewList;
