import React from 'react';
import { FormattedMessage } from 'react-intl';
import { formatDateString } from 'react-next/intl/date-locale';
import ComponentBase, { type GenericComponent } from 'components/ComponentBase';
// import { injectIntl, intlShape } from 'react-intl';

// @flow
import { type HotelRoomResultHeaderProps } from './types';

class HotelRoomResultHeader extends React.Component<HotelRoomResultHeaderProps> {
  constructor(props: HotelRoomResultHeaderProps) {
    super(props);
    this.state = {};
  }

  render() {
    const {
      hotelNights,
      hotelStayDates,
      cultureCode,
    } = this.props;
    return (
      <div className="product-list__title">
        <h2 className="heading heading--h2">
          <FormattedMessage
            id="HotelRoomResultHeader.pickYourRoom"
            defaultMessage="Pick Your Room"
          />
        </h2>
        <span className="text-fade alt-subheader">
          <FormattedMessage
            id="HotelRoomResultHeader.priceTaxFees"
            defaultMessage="Price includes all taxes &amp; fees"
          />
        </span>
        <span className="product-list__total-stay">
          <FormattedMessage
            id="HotelRoomResultHeader.hotelNights"
            defaultMessage="{hotelNights, number} {hotelNights, plural, one {night} other {nights}} stay"
            values={{ hotelNights: hotelNights || 0 }}
          />
        </span>
        <span className="product-list__total-stay icon-dot">
          {/* eslint-disable */}
          •
          {/* eslint-enable */}
        </span>
        <FormattedMessage
          id="HotelRoomResultHeader.dates"
          defaultMessage="{departureDate} to {returnDate}"
          values={{
            departureDate: formatDateString(hotelStayDates.departureDate, 'MEDIUM', cultureCode),
            returnDate: formatDateString(hotelStayDates.returnDate, 'MEDIUM', cultureCode),
          }}
        >
          {() => (
            <React.Fragment>
              <strong className="product-list__total-stay">
                {formatDateString(hotelStayDates.departureDate, 'MEDIUM', cultureCode)}
                <span>
                  {' to '}
                </span>
                {formatDateString(hotelStayDates.returnDate, 'MEDIUM', cultureCode)}
              </strong>
            </React.Fragment>
          )}
        </FormattedMessage>
      </div>
    );
  }
}
const injection: GenericComponent<HotelRoomResultHeaderProps> = ComponentBase;
export default injection(HotelRoomResultHeader, {
  hasCultureCode: true,
});
