import React, { Component } from 'react';
import Router from 'next/router';
import { FormattedMessage } from 'react-intl';
import { formatDateString } from 'react-next/intl/date-locale';
import ComponentBase, { type GenericComponent } from 'components/ComponentBase';
import { MdCheck as IconCheck, MdInfoOutline as IconInfo, MdThumbUp as IconThumbsUp } from 'react-icons/md';
import { FaSpinner as IconLoadingSpinner } from 'react-icons/fa';
import NumberFormat from '../../../components/NumberFormat';
import HotelBoardText from '../../../components/HotelBoardText';
import PricePopover from '../../../components/PricePopover';
// import './HotelAvailableRoomList.scss';
// import { injectIntl, intlShape } from 'react-intl';

// @flow
import {
  type HotelRoomAmenitiesProps,
  type HotelRoomAmenitiesState,
} from './types';

import { getGeneralConfig } from '../../../store-app/modules/config/selectors';
import { getRoomData } from '../../../store-app/modules/hotel-details/selectors';
import Backdrop from '../../../components/Common/Backdrop';

const track = require('../../../react-next/utils/track-utils');

class HotelRoomAmenitiesComponent extends Component<
  HotelRoomAmenitiesProps,
  HotelRoomAmenitiesState,
> {
  constructor(props: HotelRoomAmenitiesProps) {
    super(props);
    this.state = {
      selectedRoomTooltip: '',
      isPageChanging: false,
      showPopover: false,
    };
  }

  state: HotelRoomAmenitiesState;

  handleButtonOnclik = (e: SyntheticEvent<HTMLButtonElement>, url: string) => {
    const {
      packageId,
      option,
      urlLocale,
      router,
      hotelName,
    } = this.props;
    e.stopPropagation();
    this.setState({
      isPageChanging: true,
    });
    const { price } = option;
    track.event(
      router.pathname,
      'ROOM Selected a room',
      option.type,
      {
        HotelName: hotelName,
        RoomType: option.type,
        PerPaxPrice: price.perPerson.price,
        PackagePrice: price.perPackage.price,
      },
    );
    Router.push(
      `/Flight?packageId=${packageId}&room=${option.id}`,
      `${urlLocale}${url}`,
    ).then(() => window.scrollTo(0, 0));
  };

  handleToolTip = (e: SyntheticEvent<HTMLElement>, roomId: string) => {
    e.stopPropagation();
    this.setState({
      selectedRoomTooltip: roomId,
    });
  };

  togglePopover = (status) => {
    this.setState({
      showPopover: status,
    });
  };

  props: HotelRoomAmenitiesProps;

  render() {
    const {
      option, isBestDeal, featuresConfig, cultureCode, currency,
      popOverInfo,
    } = this.props;
    const { selectedRoomTooltip, isPageChanging, showPopover } = this.state;
    const { useTotalPrice } = featuresConfig;
    const price: number = useTotalPrice
      ? option.price.perPackage.price
      : option.price.perPerson.price;
    return (
      (option.boardType >= 1 && option.boardType <= 6) && (
      <React.Fragment>
        <Backdrop isOpen={isPageChanging} isTransparent />
        <div
          className={`product-card__option ${isBestDeal ? 'product-card__option__best-deals' : ''}`}
        >
          <div>
            <h3 className="heading heading--h3">{option.type}</h3>
            {(option.boardType === 1
              && !option.freeCancellationBefore && (
                <div className="room-only">
                  <FormattedMessage id="HotelRoomAmenities.roomOnly" defaultMessage="Room Only" />
                </div>
            )) || (
              <div className="product-card__advantage">
                <ul className="list-icon list-icon--one-line">
                  <li className="list-icon__item">
                    <i className="icon icon-check">
                      <IconCheck size="16" />
                    </i>
                    <span className="list-icon__text amenities-text">
                      <HotelBoardText boardType={option.boardType} />
                    </span>
                  </li>
                  {option.freeCancellationBefore && (
                    <li className="list-icon__item">
                      <i className="icon icon-check">
                        <IconCheck size="16" />
                      </i>
                      <span className="list-icon__text amenities-text">
                        <FormattedMessage
                          id="HotelRoomAmenities.cancellationPolicy"
                          defaultMessage="Cancellation policy"
                        />
                        <i
                          className="tooltip link-theme-primary"
                          onClick={
                            (e: SyntheticEvent<HTMLElement>) => this.handleToolTip(e, option.id)
                          }
                          onMouseEnter={
                            (e: SyntheticEvent<HTMLElement>) => this.handleToolTip(e, option.id)
                          }
                          onMouseLeave={(e: SyntheticEvent<HTMLElement>) => this.handleToolTip(e, '')}
                          role="presentation"
                        >
                          <IconInfo />
                          {selectedRoomTooltip === option.id && (
                            <div className="tooltiptext">
                              <span
                                className="tooltiptext__close"
                                onClick={(e: SyntheticEvent<HTMLElement>) => this.handleToolTip(e, '')
                                }
                                role="presentation"
                              >
                                {/* eslint-disable */}
                                &times;
                                {/* eslint-enable */}
                              </span>
                              <FormattedMessage
                                id="HotelRoomAmenities.freeCancellation"
                                defaultMessage="Free cancellation before {cancellationBeforeDate}"
                                values={{
                                  cancellationBeforeDate: formatDateString(
                                    option.freeCancellationBefore,
                                    'MEDIUM',
                                    cultureCode,
                                  ),
                                }}
                              />
                            </div>
                          )}
                        </i>
                      </span>
                    </li>
                  )}
                </ul>

                {/* <div className="product-card__promo is-hidden">
                  <p className="pill">
                    <FormattedMessage
                      id="HotelRoomAmenities.bookEarlier"
                      defaultMessage="Book earlier and save up to 50%"
                    />
                  </p>
                </div> */}
              </div>
            )}
          </div>

          <div className="flex-wrapper flex-wrapper--half">
            {isBestDeal && (
              <div className="best-deal theme-primary-text">
                <i>
                  <IconThumbsUp size={16} />
                </i>
                <FormattedMessage id="HotelRoomAmenities.bestDeal" defaultMessage="Best deal" />
              </div>
            )}
            <div className="room-button-price">
              { showPopover && (
                <PricePopover
                  FlightInfo={
                    {
                      origin: popOverInfo.origin,
                      destination: popOverInfo.destination,
                      departDate: popOverInfo.departureDate,
                      returnDate: popOverInfo.returnDate,
                      paxCount: popOverInfo.paxCount,
                    }
                  }
                  RoomInfo={{
                    roomtype: popOverInfo.roomType,
                    nightsCount: popOverInfo.nightsCount,
                    noOfRoom: popOverInfo.roomCount,
                    boardType: option.boardType,
                    freeCancellationBefore: option.freeCancellationBefore,
                  }}
                  PriceInfo={{
                    cultureCode,
                    currency,
                    totalRoomPrice: option.price.perPackage.price,
                  }}
                />
              )}
              <div className="flex-wrapper__left">
                <strong
                  className="price-2 theme-primary-text product-card__price"
                  onMouseEnter={() => this.togglePopover(true)}
                  onMouseLeave={() => this.togglePopover(false)}
                >
                  <label>
                    <NumberFormat
                      value={price}
                      locale={cultureCode}
                      currency={currency}
                      withSmall
                      className="amenities-price"
                    />
                  </label>
                  <span className="text-fade sub">
                    {useTotalPrice ? (
                      <FormattedMessage
                        id="HotelRoomAmenities.perPackagePriceText"
                        defaultMessage="per package"
                      />
                    ) : (
                      <FormattedMessage
                        id="HotelRoomAmenities.perPersonPriceText"
                        defaultMessage="per person"
                      />
                    )}
                  </span>
                </strong>
              </div>
              <div className="flex-wrapper__right">
                <button
                  type="button"
                  className={`button no-margin btn-theme-primary ${isPageChanging ? 'page-change' : ''}`}
                  onClick={e => this.handleButtonOnclik(e, option.url)}
                >
                  <FormattedMessage
                    id="HotelRoomAmenities.select"
                    defaultMessage="Select"
                  />
                  {isPageChanging && (
                    <i className={`infinite-spin ${isPageChanging ? 'page-change-loader' : ''}`}>
                      <IconLoadingSpinner size={16} />
                    </i>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
      ) || null);
  }
}

const mapStateToProps = state => ({
  currency:
    (getRoomData(state) && getRoomData(state).currency)
    || getGeneralConfig(state).defaultCurrency,
});

const injection: GenericComponent<HotelRoomAmenitiesProps> = ComponentBase;

export default injection(HotelRoomAmenitiesComponent, {
  mapStateToProps,
  hasFeaturesConfig: true,
  hasCultureCode: true,
  hasUrlLocale: true,
});
