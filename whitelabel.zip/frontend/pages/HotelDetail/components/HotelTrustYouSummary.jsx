import React from 'react';
import { FormattedMessage } from 'react-intl';
import { AllHtmlEntities } from 'html-entities';
import ReviewRating from 'components/ReviewRating';
import './HotelTrustYouSummary.scss';
import { MdChatBubble as IconChatBubble } from 'react-icons/md';

// import { injectIntl, intlShape } from 'react-intl';

// @flow
import { type GetStaticHotelInfoResponse } from './types';

function HotelTrustYouSummary({
  review,
  description,
}: GetStaticHotelInfoResponse) {
  const reviewData: ?{
    score: number,
    text: string,
    reviews: number,
  } = {};
  let highlightCount: number = 3;
  let isBadgeHighlightAvailable: boolean = false;
  if (review && review.score > 0) {
    reviewData.score = review.score;
    reviewData.text = review.text;
    reviewData.reviews = review.reviewCount;
    if (review.badgeList && review.badgeList.length > 0) {
      highlightCount = 2;
    }
    if ((review.badgeList && review.badgeList.length > 0 || review.summary.highlightList)) {
      isBadgeHighlightAvailable = true;
    }
  }
  return (
    <div className="card rating">
      {review && review.score > 0 && (
        <React.Fragment>
          {!!review.score && (
            <div className="card-header">
              <ReviewRating
                {...{
                  position: 'left',
                  ...reviewData,
                }}
              />
            </div>
          )}
          {isBadgeHighlightAvailable && (
            <div className={!review.summary.text ? 'flex-grow' : ''}>
              <ul className={`card-body list-icon ${!review.summary.text ? 'no-border' : ''}`}>
                {(review.badgeList && review.badgeList.length > 0) && (
                  <li className="list-icon__item">
                    <span className="icon icon-badge" />
                    <span className="list-icon__text">
                      {review.badgeList[0].text}
                    </span>
                  </li>
                )}
                {review.summary.highlightList
                && review.summary.highlightList.slice(0, highlightCount).map((highlight, index) => (
                  <li className="list-icon__item" key={`hotelDetail_summary_highlight_${index.toString()}`}>
                    <IconChatBubble className="icon icon-check" size={16} />
                    <span className="list-icon__text">
                      {highlight}
                    </span>
                  </li>
                ))
                }
              </ul>
            </div>
          )}
          {review.summary.text && (
            <div className="flex-grow summary-text">
              <blockquote
                className="card-footer blockquote"
                cite=""
                style={{
                  marginTop: !isBadgeHighlightAvailable ? '15px' : '',
                }}
              >
                <div>
                  {review.summary.text}
                </div>
              </blockquote>
            </div>
          )}
          <div className="gradient-bg-text">
            <a className="link link-theme-color" href="#hotelReviews" title="Read all reviews">
              <FormattedMessage
                id="HotelTrustYouSummary.readAllReviews"
                defaultMessage="Read all reviews"
              />
            </a>
          </div>
        </React.Fragment>
      ) || (
        <React.Fragment>
          <div className="no-review-title">
            <FormattedMessage
              id="HotelTrustYouSummary.aboutHotel"
              defaultMessage="About the hotel"
            />
          </div>
          <div className="card-footer no-review blockquote summary-review">
            <div
              /* eslint-disable react/no-danger */
              dangerouslySetInnerHTML={{
                __html: AllHtmlEntities.decode(description),
              }}
              /* eslint-enable react/no-danger */
            />
          </div>
          <div className="gradient-bg-text">
            <a className="link link-theme-color" href="#aboutHotel" title="Read more">
              <FormattedMessage
                id="HotelTrustYouSummary.readMore"
                defaultMessage="Read more"
              />
            </a>
          </div>
        </React.Fragment>
      )}
    </div>
  );
}

export default HotelTrustYouSummary;
