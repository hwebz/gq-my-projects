import React from 'react';
import { FormattedMessage } from 'react-intl';
import { AllHtmlEntities } from 'html-entities';
import ScrollableAnchor from 'react-scrollable-anchor';
import './HotelDetailInfo.scss';
import HotelLocationMap from './HotelLocationMap';

// import { injectIntl, intlShape } from 'react-intl';
// @flow
import { type GetStaticHotelInfoResponse, type HotelDetailInfoState } from './types';

const track = require('../../../react-next/utils/track-utils');

class HotelDetailInfo extends React.Component<
  GetStaticHotelInfoResponse,
  HotelDetailInfoState
> {
  constructor(props: GetStaticHotelInfoResponse) {
    super(props);
    this.state = {
      isAmenitiesMore: false,
      isDetailMore: false,
    };
  }

  handleAmenitiesMore = () => {
    const { isAmenitiesMore } = this.state;
    console.log(this.props);
    this.setState({
      isAmenitiesMore: !isAmenitiesMore,
    });
    this.eventTracking('amenities');
  };

  eventTracking = (category) => {
    const { router, name } = this.props;
    track.event(
      router.pathname,
      `HOTEL Selected to view more ${category}`,
      name,
      { HotelName: name },
    );
  }

  handleDetailMore = () => {
    const { isDetailMore } = this.state;
    this.setState({
      isDetailMore: !isDetailMore,
    });
    this.eventTracking('hotel information');
  };


  render() {
    const {
      name, description, lon, lat, amenities, checkInTime, checkOutTime, info,
    } = this.props;
    const { isAmenitiesMore, isDetailMore } = this.state;

    const infoTitles = {
      rooms: (
        <FormattedMessage
          id="HotelDetailInfo.numOfRooms"
          defaultMessage="Number of Rooms"
        />),
      floors: (
        <FormattedMessage
          id="HotelDetailInfo.numOfFloors"
          defaultMessage="Number of Floors"
        />),
      propertyInformation: (
        <FormattedMessage
          id="HotelDetailInfo.propertyInformation"
          defaultMessage="Property Information"
        />),
      areaInformation: (
        <FormattedMessage
          id="HotelDetailInfo.areaInformation"
          defaultMessage="Area Information"
        />),
      locationDescription: (
        <FormattedMessage
          id="HotelDetailInfo.locationDescription"
          defaultMessage="Location Description"
        />),
      roomDetailDescription: (
        <FormattedMessage
          id="HotelDetailInfo.roomDetailDescription"
          defaultMessage="Room Detail Description"
        />),
      amenitiesDescription: (
        <FormattedMessage
          id="HotelDetailInfo.amenitiesDescription"
          defaultMessage="Amenities Description"
        />),
      diningDescription: (
        <FormattedMessage
          id="HotelDetailInfo.diningDescription"
          defaultMessage="Dining Description"
        />),
      businessAmenitiesDescription: (
        <FormattedMessage
          id="HotelDetailInfo.businessAmenitiesDescription"
          defaultMessage="Business Amenities Description"
        />),
      hotelPolicy: (
        <FormattedMessage
          id="HotelDetailInfo.hotelPolicy"
          defaultMessage="Hotel Policy"
        />),
      knowBeforeYouGoDescription: (
        <FormattedMessage
          id="HotelDetailInfo.knowBeforeYouGoDescription"
          defaultMessage="We Should Mention"
        />),
      roomFeesDescription: (
        <FormattedMessage
          id="HotelDetailInfo.roomFeesDescription"
          defaultMessage="Fees and Operation Extras"
        />),
      checkInInstructions: (
        <FormattedMessage
          id="HotelDetailInfo.checkInInstructions"
          defaultMessage="Check-in Instruction"
        />),
      specialCheckInInstructions: (
        <FormattedMessage
          id="HotelDetailInfo.specialCheckInInstructions"
          defaultMessage="Special Check-in Instruction"
        />),
    };

    // To filter only the objects that have values, so in the return can just slice to 5
    let filteredInfo = [];
    let filteredAmenities = [];
    if (info) {
      filteredInfo = Object.keys(info).filter(key => info[key]);
      filteredAmenities = amenities.filter(amenity => amenity);
    }
    return (
      <section className="product-details full-width-container">
        <div className="product-details__header">
          <h2 className="heading heading--h2">
            <FormattedMessage
              id="HotelDetailInfo.aboutTitle"
              defaultMessage="About {name}"
              values={{ name }}
            />
          </h2>
        </div>
        {description && (
          <div className="product-details__row">
            <div className="product-details__title">
              <span className="product-details__title-text">
                <FormattedMessage
                  id="HotelDetailInfo.descriptionTitle"
                  defaultMessage="Description"
                />
              </span>
            </div>

            <div className="product-details__desc hotel-description">
              <div
                className="product-details__text"
                /* eslint-disable react/no-danger */
                dangerouslySetInnerHTML={{
                  __html: description,
                }}
                /* eslint-enable react/no-danger */
              />
            </div>
          </div>
        )}
        {(lon && lat) && (
          <ScrollableAnchor id="map">
            <div className="product-details__row">
              <div className="product-details__title">
                <span className="product-details__title-text">
                  <FormattedMessage
                    id="HotelDetailInfo.locationMapTitle"
                    defaultMessage="Location Map"
                  />
                </span>
              </div>

              <div className="product-details__desc">
                <HotelLocationMap
                  lon={lon}
                  lat={lat}
                />
              </div>
            </div>
          </ScrollableAnchor>
        )}
        {filteredAmenities.length > 0 && (
          <div className="product-details__row">
            <div className="product-details__title">
              <span className="product-details__title-text">
                <FormattedMessage
                  id="HotelDetailInfo.amenitiesTitle"
                  defaultMessage="Hotel &amp; Room Facilities"
                />
              </span>
            </div>

            <div className="product-details__desc">
              <ul className="product-details__desc-list">
                {filteredAmenities.slice(0, 10).map((amenity, amenityIndex) => (
                  <li className="product-details__desc-list-item" key={`hotelDetail_amenity_${amenityIndex.toString()}`}>
                    {amenity}
                  </li>
                ))}

                {isAmenitiesMore
                  && filteredAmenities
                    .slice(10, filteredAmenities.length)
                    .map((amenity, amenityIndex) => (
                      <li className="product-details__desc-list-item" key={`hotelDetail_amenity_${(amenityIndex + 10).toString()}`}>
                        {amenity}
                      </li>
                    ))}
              </ul>
              {(filteredAmenities.length >= 10) && (
                <a
                  className={`link link--fade link-theme-color ${isAmenitiesMore ? 'link--fade--less' : ''}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    this.handleAmenitiesMore();
                  }}
                  href="#toggle"
                  title="Show more"
                >
                  { !isAmenitiesMore ? (
                    <FormattedMessage
                      id="HotelDetailInfo.showMore"
                      defaultMessage="Show more"
                    />
                  ) : (
                    <FormattedMessage
                      id="HotelDetailInfo.showLess"
                      defaultMessage="Show less"
                    />
                  )}
                </a>
              )}
            </div>
          </div>
        )}
        {(filteredInfo.length > 0 || checkInTime || checkOutTime) && (
          <div className="product-details__row additional-hotel-info">
            <div className="product-details__title">
              <span className="product-details__title-text">
                <FormattedMessage
                  id="HotelDetailInfo.hotelInfoTitle"
                  defaultMessage="Hotel Information"
                />
              </span>
            </div>

            <div className="product-details__desc">
              {checkInTime && (
                <React.Fragment>
                  <strong>
                    <FormattedMessage
                      id="HotelDetailInfo.checkInTime"
                      defaultMessage="Check-in Time"
                    />
                  </strong>
                  <div className="product-details__text">
                    {checkInTime}
                  </div>
                </React.Fragment>
              )}
              {checkOutTime && (
                <React.Fragment>
                  <strong>
                    <FormattedMessage
                      id="HotelDetailInfo.checkOutTime"
                      defaultMessage="Check-out Time"
                    />
                  </strong>
                  <div className="product-details__text">
                    {checkOutTime}
                  </div>
                </React.Fragment>
              )}
              {filteredInfo.length > 0 && filteredInfo.slice(0, 5).map(infoKey => (
                <React.Fragment key={infoKey}>
                  <strong>
                    {infoTitles[infoKey]}
                  </strong>
                  <div
                    className="product-details__text"
                    /* eslint-disable react/no-danger */
                    dangerouslySetInnerHTML={{
                      __html: AllHtmlEntities.decode(info[infoKey]),
                    }}
                    /* eslint-enable react/no-danger */
                  />
                </React.Fragment>
              ))}

              {filteredInfo.length > 0
              && isDetailMore
              && filteredInfo
                .slice(5, filteredInfo.length)
                .map(infoKey => (
                  <React.Fragment key={infoKey}>
                    <strong>
                      {infoTitles[infoKey]}
                    </strong>
                    <div
                      className="product-details__text"
                      /* eslint-disable react/no-danger */
                      dangerouslySetInnerHTML={{
                        __html: AllHtmlEntities.decode(info[infoKey]),
                      }}
                      /* eslint-enable react/no-danger */
                    />
                  </React.Fragment>
                ))}

              {filteredInfo.length > 0 && (filteredInfo.length >= 5) && (
                <a
                  className={`link link--fade link-theme-color ${isDetailMore ? 'link--fade--less' : ''}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    this.handleDetailMore();
                  }}
                  href="#a"
                  title="Show more"
                >
                  { !isDetailMore ? (
                    <FormattedMessage
                      id="HotelDetailInfo.showMore"
                      defaultMessage="Show more"
                    />
                  ) : (
                    <FormattedMessage
                      id="HotelDetailInfo.showLess"
                      defaultMessage="Show less"
                    />
                  )}
                </a>
              )}
            </div>
          </div>
        )}
      </section>
    );
  }
}

export default HotelDetailInfo;
