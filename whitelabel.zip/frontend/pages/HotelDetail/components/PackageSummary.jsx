import React from 'react';
import { subDays } from 'date-fns';
import { FormattedMessage } from 'react-intl';
import ComponentBase, { type GenericComponent } from 'components/ComponentBase';
import './PackageSummary.scss';
import { MdFlight as IconFlight, MdHotel as IconHotel } from 'react-icons/md';
import { FaExclamationTriangle as IconWarning } from 'react-icons/fa';
import { formatDateString } from 'react-next/intl/date-locale';
// @flow
import { type PackageSummaryProps } from './types';
import ArrivalNotice from '../../../components/Common/ArrivalNotice';

function PackageSummary({
  summary, cultureCode,
}: PackageSummaryProps) {
  const {
    isLoading, roomData,
    returnDate, nightsCount,
  } = summary;
  const loadingClassName: string = isLoading ? 'content-placeholder' : '';
  const { paxCount, hotelNights, roomCount } = roomData;
  const arrivalDate = subDays(returnDate, hotelNights);
  return (
    <div className="package-summary">
      <div className="card card--with-border package-summary-item hotel-container">
        <div className="flex package-summary-header">
          <span className="package-summary-title large-text">
            <FormattedMessage
              id="PackageSummary.yourPackage"
              defaultMessage="Your Package"
            />
          </span>
          {!isLoading && (!!(nightsCount && nightsCount !== hotelNights)) && (
            <span className="small-text danger-text plus-notice">
              <i>
                <IconWarning />
              </i>
              <ArrivalNotice
                arrivalDate={formatDateString(arrivalDate, 'SHORT', cultureCode)}
                hotelNights={hotelNights}
                nightsCount={nightsCount}
              />
            </span>
          )}
        </div>
        <div className="package-summary-item__group">
          <div className="flex card-body large-text package-summary-item__flight">
            <div className="wrapper package-summary__item-wrapper">
              <i>
                <IconFlight className="icon icon-flight" />
              </i>
              <div className="package-summary__text-info">
                <span>
                  <FormattedMessage
                    id="PackageSummary.flights"
                    defaultMessage="Flights"
                  />
                </span>
              </div>
            </div>
            <strong className={`large-text package-summary__value ${loadingClassName}`}>
              <FormattedMessage
                id="PackageSummary.returnTicket"
                defaultMessage="{paxCount, number} Return {paxCount, plural, one {Ticket} other {Tickets}}"
                values={{ paxCount }}
              />
            </strong>
          </div>

          <div className="flex card-body large-text package-summary-item__room">
            <div className="wrapper package-summary__item-wrapper">
              <i>
                <IconHotel className="icon icon-local_hotel" />
              </i>
              <div className="package-summary__text-info">
                <span>
                  <FormattedMessage
                    id="PackageSummary.rooms"
                    defaultMessage="Rooms"
                  />
                </span>
              </div>
            </div>
            <strong className={`large-text package-summary__value ${loadingClassName}`}>
              <FormattedMessage
                id="PackageSummary.nightRoom"
                defaultMessage={'{hotelNights, number} {hotelNights, plural, one {Night} other {Nights}}, {roomCount, number} {roomCount, plural, one {Room} other {Rooms}}'}
                values={{ hotelNights, roomCount }}
              />
            </strong>
          </div>
        </div>
      </div>
    </div>
  );
}

const injection: GenericComponent<PackageSummaryProps> = ComponentBase;
export default injection(PackageSummary, {
  hasCultureCode: true,
});
