import React, { Component } from 'react';
// import Router from 'next/router';
import { FormattedMessage } from 'react-intl';
import ComponentBase, { type GenericComponent } from 'components/ComponentBase';
import './HotelPackagePrice.scss';
import NumberFormat from '../../../components/NumberFormat';
// import { injectIntl, intlShape } from 'react-intl';

// @flow
import { type HotelPackagePriceProps, type HotelRoomPrice } from './types';

class HotelPackagePriceComponent extends Component<HotelPackagePriceProps> {
  constructor(props: HotelPackagePriceProps) {
    super(props);
    this.state = {};
  }

  // handleButtonOnclick = (e: SyntheticEvent<HTMLButtonElement>, url: string) => {
  //   e.stopPropagation();
  //   Router.push(url);
  // };

  render() {
    const {
      roomData, featuresConfig, isLoading, cultureCode, onSelectHotelRoom,
    } = this.props;

    // To check why there is cheapestPriceLink at here
    // let cheapestPriceLink: string = '';
    let price: number = 0;
    const { useTotalPrice } = featuresConfig;

    if (!isLoading && Object.keys(roomData).length > 0 && roomData.rooms.length > 0) {
      const cheapestPrice: HotelRoomPrice = roomData.rooms[0].options[0].price;
      // cheapestPriceLink = roomData.rooms[0].options[0].url;
      price = cheapestPrice && useTotalPrice
        ? cheapestPrice.perPackage.price
        : cheapestPrice.perPerson.price;
    }
    const loadingClassName: string = isLoading ? 'btn-disabled' : '';
    return (
      <div className="product-card__price">
        <strong className="price-1 theme-primary-text">
          {!isLoading && price > 0 && (
            <React.Fragment>
              <NumberFormat
                value={price}
                locale={cultureCode}
                currency={roomData.currency}
                withSmall
                className="amenities-price"
              />

              <span className="text-fade sub">
                {useTotalPrice ? (
                  <FormattedMessage
                    id="HotelPackagePrice.perPackagePriceText"
                    defaultMessage="per package"
                  />
                ) : (
                  <FormattedMessage
                    id="HotelPackagePrice.perPersonPriceText"
                    defaultMessage="per person"
                  />
                )}
              </span>
            </React.Fragment>
          )}
        </strong>

        <button
          className={`button btn-lg btn-theme-primary ${loadingClassName}`}
          onClick={() => onSelectHotelRoom()}
          role="presentation"
          type="button"
        >
          <FormattedMessage id="HotelPackagePrice.selectRoom" defaultMessage="Select Room" />
        </button>
      </div>
    );
  }
}

const injection: GenericComponent<HotelPackagePriceProps> = ComponentBase;

export default injection(HotelPackagePriceComponent, {
  hasFeaturesConfig: true,
  hasCultureCode: true,
});
