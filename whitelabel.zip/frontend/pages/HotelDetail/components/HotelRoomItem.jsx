import React, { Component } from 'react';
import { FormattedMessage, defineMessages } from 'react-intl';
import { CSSTransition } from 'react-transition-group';
import ComponentBase, { type GenericComponent } from '../../../components/ComponentBase';
import HotelRoomAmenities from './HotelRoomAmenities';
// import './HotelAvailableRoomList.scss';
// import { injectIntl, intlShape } from 'react-intl';
import { getImageUrlsString } from '../../../utils/image-utils';

// @flow
import { type HotelRoomItemProps, type HotelRoomItemState } from './types';

const track = require('../../../react-next/utils/track-utils');

const defaultMessages = defineMessages({
  roomCount: { id: 'HotelRoomItem.roomCount', defaultMessage: '{roomCount} rooms' },
});


class HotelRoomItem extends Component<HotelRoomItemProps, HotelRoomItemState> {
  constructor(props: HotelRoomItemProps) {
    super(props);
    this.state = {
      isOptionsMore: false,
      isDescriptionMore: false,
    };
  }

  state: HotelRoomItemState;

  handleOptionsMore = () => {
    const { isOptionsMore } = this.state;
    if (!isOptionsMore) {
      this.eventTracking('ROOM Selected more room options');
    }
    this.setState({
      isOptionsMore: !isOptionsMore,
    });
  };

  eventTracking = (action) => {
    const { router, hotelName, room } = this.props;
    track.event(
      router.pathname,
      action,
      room.name,
      {
        HotelName: hotelName,
        roomType: room.name,
      },
    );
  }

  handleDescriptionMore = () => {
    // Hotel description is shown at on 130 characters at first,
    // clicking on description more will show all characters
    const { isDescriptionMore } = this.state;
    if (!isDescriptionMore) {
      this.eventTracking('ROOM Selected to read more about room info');
    }
    this.setState({
      isDescriptionMore: !isDescriptionMore,
    });
  };

  props: HotelRoomItemProps;

  render() {
    const {
      room, roomCount,
      intl, isFirstRoom, packageId,
      router, hotelName, popOverInfo,
    } = this.props;
    const { isOptionsMore, isDescriptionMore } = this.state;
    const {
      image,
      name,
      size,
      description,
      options,
    } = room;
    const { formatMessage } = intl;
    return (
      <section className="card product-card product-card--hotel">
        <div
          className="figure-img"
          style={{ backgroundImage: getImageUrlsString(image, 'ROOM') }}
        />
        <div className="product-card__desc">
          <div className="product-card__title">
            <h2 className="heading heading--h2">
              {`${name} ${(roomCount > 1) ? (`(${formatMessage(defaultMessages.roomCount, { roomCount })})`) : ''}`}
            </h2>
            {!!size && (
              <p className="product-card__title-info show-on-desktop">
                <span>
                  <FormattedMessage
                    id="HotelRoomItem.roomSize"
                    defaultMessage="Room size: {size} m²"
                    values={{ size }}
                  />
                </span>
              </p>
            )}
            {description && (
              <React.Fragment>
                <div
                  className={`product-card__title-desc ${isDescriptionMore ? 'is-open' : ''}`}
                /* eslint-disable react/no-danger */
                  dangerouslySetInnerHTML={{
                    __html: description,
                  }}
                /* eslint-enable react/no-danger */
                />
                {description.length > 150 && (
                  <a
                    className="link link-theme-color isDescriptionMoreLink"
                    href="#toggle"
                    onClick={this.handleDescriptionMore}
                  >
                    {!isDescriptionMore && (
                      <FormattedMessage
                        id="HotelRoomItem.readMore"
                        defaultMessage="Read more"
                      />
                    ) || (
                      <FormattedMessage
                        id="HotelRoomItem.readLess"
                        defaultMessage="Read less"
                      />
                    )}
                  </a>
                )}
              </React.Fragment>
            )}
          </div>

          {options.slice(0, 3).map((option, index) => (
            <HotelRoomAmenities
              router={router}
              hotelName={hotelName}
              option={option}
              isBestDeal={isFirstRoom && (index === 0)}
              key={`hotelRoomItem_option_${index.toString()}`}
              packageId={packageId}
              popOverInfo={{
                ...popOverInfo,
                roomType: name,
              }}
            />
          ))}
          { isOptionsMore && (
            <CSSTransition
              in={isOptionsMore}
              classNames="toggle-slide"
              unmountOnExit
            >
              <div>
                {isOptionsMore && options.slice(3, options.length).map((option, index) => (
                  <HotelRoomAmenities
                    option={option}
                    key={`hotelRoomItem_option_${index.toString()}`}
                    popOverInfo={popOverInfo}
                  />
                ))}
              </div>
            </CSSTransition>
          )}
          {(options.length > 3) && (
            <div className="product-card__option product-card__option--more text-center">
              <a
                className="link link--fade link-theme-color link-theme-primary isOptionsMoreLink"
                href="#toggle"
                title="Toggle room options"
                onClick={(e) => {
                  e.stopPropagation();
                  this.handleOptionsMore();
                }}
              >
                {!isOptionsMore && (
                  <span className="link__text">
                    <FormattedMessage
                      id="HotelRoomItem.moreRoom"
                      defaultMessage="More Room Options"
                    />
                  </span>
                ) || (
                  <span className="link__text link__text--less">
                    <FormattedMessage
                      id="HotelRoomItem.lessRoom"
                      defaultMessage="Less Room Options"
                    />
                  </span>
                )}
              </a>
            </div>
          )}
        </div>
      </section>
    );
  }
}

const injection: GenericComponent<HotelRoomItemProps> = ComponentBase;

export default injection(HotelRoomItem);
