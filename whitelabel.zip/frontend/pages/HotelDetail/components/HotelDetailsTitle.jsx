import React from 'react';
import { FormattedMessage } from 'react-intl';

import {
  MdLocationOn as IconLocation,
} from 'react-icons/md';
import StarsRatingSingle from '../../../components/StarsRating/StarsRatingSingle';
import './HotelDetailsTitle.scss';

// @flow
import { type GetStaticHotelInfoResponse } from './types';

function HotelDetailsTitle({
  name,
  stars,
  address,
  lon,
  lat,
}: GetStaticHotelInfoResponse) {
  return (
    <div className="hotel-detail-wrap__desc">
      <div className="wrapper">
        <h1 className="hotel-detail-wrap__title">
          {name}
        </h1>
        {stars > 0 && (
          <div className="stars large-text">
            <StarsRatingSingle stars={stars} />
          </div>
        )}
      </div>

      {address && (
        <div className="hotel-detail-wrap__location">
          <div className="hotel-detail-wrap__location-link">
            <IconLocation />
            <address
              className="hotel-detail-wrap__address"
              itemProp="address"
              itemScope=""
              itemType="http://schema.org/PostalAddress"
            >
              <span itemProp="streetAddress">
                {address}
              </span>
            </address>
          </div>
          {lon && lat && (
            <a
              href="#map"
              className="link link-theme-color view-on-map"
              title="Scroll to map"
            >
              <FormattedMessage
                id="HotelDetailsTitle.viewOnMap"
                defaultMessage="View on map"
              />
            </a>
          )}
        </div>
      )}
    </div>
  );
}

export default HotelDetailsTitle;
