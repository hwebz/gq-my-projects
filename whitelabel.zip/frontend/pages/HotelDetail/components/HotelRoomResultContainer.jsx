import React from 'react';
import { FormattedMessage } from 'react-intl';
import './HotelRoomResultContainer.scss';
import HotelRoomResultHeader from './HotelRoomResultHeader';
import HotelRoomResultFilter from './HotelRoomResultFilter';
import HotelRoomItem from './HotelRoomItem';
// import { injectIntl, intlShape } from 'react-intl';

// @flow
import { type HotelRoomResultContainerProps } from './types';
import AlertMsg from '../../../components/Common/AlertMsg';

class HotelRoomResultContainer extends React.Component<HotelRoomResultContainerProps> {
  constructor(props: HotelRoomResultContainerProps) {
    super(props);
    this.state = {};
  }

  render() {
    const {
      isLoading,
      roomData,
      hotelStayDates,
      popOverInfo,
      toggleFilterRooms,
      roomFilter,
      filteredRooms,
      packageId,
      hotelName,
      router,
    } = this.props;

    const {
      hotelNights,
      roomCount,
      rooms,
    } = roomData;
    const roomUnavailableMessage = (
      <FormattedMessage
        id="HotelRoomResultContainer.roomUnavailable"
        defaultMessage={'There\'s been an error loading the rooms! Please {link} or select another hotel.'}
        values={{
          /* eslint-disable */
          link: <a href="javascript:window.location.reload(true)">refresh the page</a>
          /* eslint-enable */
        }}
      />
    );

    return (
      <div className="product-list">
        <div className="product-list__sort container">
          <div className="flex-wrapper flex-wrapper--half">
            <HotelRoomResultHeader
              hotelNights={hotelNights}
              hotelStayDates={hotelStayDates}
            />
            {rooms && rooms.length > 0 && (
              <HotelRoomResultFilter
                isLoading={isLoading}
                rooms={rooms}
                toggleFilterRooms={toggleFilterRooms}
                roomFilter={roomFilter}
              />
            )}
          </div>
        </div>
        {isLoading && <div className="loader" />}
        {(!isLoading && filteredRooms.length > 0 && filteredRooms.map((room, index) => (
          <HotelRoomItem
            hotelName={hotelName}
            router={router}
            room={room}
            roomCount={roomCount}
            isFirstRoom={(index === 0) || false}
            key={`hotelRoomResultContainer_room_${index.toString()}`}
            packageId={packageId}
            popOverInfo={popOverInfo}
          />
        )))
        // TODO Check in back end on rooms is undefined
        || !isLoading && (
          <AlertMsg msgType="danger" msg={roomUnavailableMessage} />
        )}
      </div>
    );
  }
}

export default HotelRoomResultContainer;
