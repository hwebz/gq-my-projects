declare module 'invariant' {
  declare module.exports: any;
}