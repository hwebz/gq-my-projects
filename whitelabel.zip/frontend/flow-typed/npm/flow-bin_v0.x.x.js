// flow-typed signature: 67b0c3a16b2d6f8ef0a31a5745a0b3e1
// flow-typed version: 3817bc6980/flow-bin_v0.x.x/flow_>=v0.25.x

declare module "flow-bin" {
  declare module.exports: string;
}
