// @flow
// Important Note: Change here to test staging api and local mock
module.exports = {
  'process.env.NODE_ENV': process.env.NODE_ENV,
  'process.env.API_ENV': process.env.API_ENV,
};
