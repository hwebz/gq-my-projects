// Note: it is important to seperate Client and Server Errors
// @flow
import ip from 'ip';
import ErrorHandlerBrowser from 'react-next/error/sentry-browser';
import ClientData from './client-data';

// TODO: Setting Error Mapping, haven't decide on the mapping object structure
const errorMap: Map<string, Object> = new Map();

// Refer to sentry options here
// https://docs.sentry.io/clients/node/config/

export class ClientErrorHandler extends ErrorHandlerBrowser {
  static _INSTANCE: ClientErrorHandler;

  constructor() {
    super(
      ClientData.SENTRY_DSN,
      ClientData.BUILD_ENVIRONMENT,
      ClientData.RELEASE_VERSION,
      errorMap,
      {},
      { ip_address: ip.address() },
    );
    this.isOn = (ClientData.BUILD_ENVIRONMENT !== 'development' && ClientData.BUILD_ENVIRONMENT !== 'test');
  }

  static getInstance(): ClientErrorHandler {
    if (!ClientErrorHandler._INSTANCE) {
      ClientErrorHandler._INSTANCE = new ClientErrorHandler();
    }
    return ClientErrorHandler._INSTANCE;
  }
}

export default ClientErrorHandler.getInstance();
