const withCSS = require('@zeit/next-css');
const withSass = require('@zeit/next-sass');
const commonsChunkConfig = require('@zeit/next-css/commons-chunk-config');

/* eslint-disable */
module.exports = withCSS(
  withSass({
    webpack: (config, { isServer }) => {
      config.resolve = {
        extensions: ['.mjs', '.js', '.jsx'],
      };

      if (!isServer) {
        return commonsChunkConfig(config, /\.(sass|scss|css)$/);
      }
      return config;
    },
  }),
);
