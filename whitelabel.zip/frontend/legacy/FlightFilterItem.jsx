import React from 'react';

// import './FlightFilters.scss';

// icon imports
import { MdArrowDropDown, MdCancel } from 'react-icons/md';

export default function () {
  return (
    <div className="flight-filter-item">
      {/* Airports */}
      <div className="flight-filter-item__wrapper">
        <div className="pills text-overflow ">
          <MdCancel size={24} className="pills__close" />
          Airports
          <MdArrowDropDown size={16} className="icon" />
        </div>
        <div className="flight-filter-item__list">
          <div className="flight-filter-item__title">
Origin airport
          </div>
          <label className="flight-filter-item__item" htmlFor="origin-1">
            <input type="checkbox" className="filter-check" id="origin-1" />
            <span className="flight-filter-item__item__label">
              <span className="text-overflow">
Subang Airport
              </span>
              <small>
(SBZ)
              </small>
            </span>
          </label>
          <label className="flight-filter-item__item" htmlFor="origin-2">
            <input type="checkbox" className="filter-check" id="origin-2" />
            <span className="flight-filter-item__item__label">
              <span className="text-overflow">
                Very lengthy airport name will appear here and the text will ellipsis
              </span>
              <small>
(ABC)
              </small>
            </span>
          </label>
          <label className="flight-filter-item__item" htmlFor="origin-3">
            <input type="checkbox" className="filter-check" id="origin-3" />
            <span className="flight-filter-item__item__label">
              <span className="text-overflow">
                Very lengthy airport name will appear here and the text will ellipsis
              </span>
              <small>
(ABC)
              </small>
            </span>
          </label>
          <div className="flight-filter-item__title">
Destination airport
          </div>
          <label className="flight-filter-item__item" htmlFor="dest-1">
            <input type="checkbox" className="filter-check" id="dest-1" />
            <span className="flight-filter-item__item__label">
              <span className="text-overflow">
Subang Airport
              </span>
              <small>
(SBZ)
              </small>
            </span>
          </label>
          <label className="flight-filter-item__item" htmlFor="dest-2">
            <input type="checkbox" className="filter-check" id="dest-2" />
            <span className="flight-filter-item__item__label">
              <span className="text-overflow">
                Very lengthy airport name will appear here and the text will ellipsis
              </span>
              <small>
(ABC)
              </small>
            </span>
          </label>
          <label className="flight-filter-item__item" htmlFor="dest-3">
            <input type="checkbox" className="filter-check" id="dest-3" />
            <span className="flight-filter-item__item__label">
              <span className="text-overflow">
                Very lengthy airport name will appear here and the text will ellipsis
              </span>
              <small>
(ABC)
              </small>
            </span>
          </label>
        </div>
      </div>
      {/* Times */}
      <div className="flight-filter-item__wrapper">
        <div className="pills text-overflow ">
          <MdCancel size={24} className="pills__close" />
          Times
          <MdArrowDropDown size={16} className="icon" />
        </div>
        <div className="flight-filter-item__list">
          <div className="flight-filter-item__title">
            <span>
              From
              <strong>
KUL
              </strong>
              to
              <strong>
SIN
              </strong>
            </span>
            <span className="float-right">
Departure flight
            </span>
          </div>
          <div className="flight-filter-item__item">
Range slider will be placed here
          </div>
          <div className="flight-filter-item__item">
Range slider will be placed here
          </div>
          <div className="flight-filter-item__title">
            <span>
              From
              <strong>
SIN
              </strong>
              to
              <strong>
KUL
              </strong>
            </span>
            <span className="float-right">
Departure flight
            </span>
          </div>
          <div className="flight-filter-item__item">
Range slider will be placed here
          </div>
          <div className="flight-filter-item__item">
Range slider will be placed here
          </div>
        </div>
      </div>
      {/* Price */}
      <div className="flight-filter-item__wrapper">
        <div className="pills pills--active text-overflow ">
          <MdCancel size={24} className="pills__close" />
          Price
          <MdArrowDropDown size={16} className="icon" />
        </div>
        <div className="flight-filter-item__list">
          <div className="flight-filter-item__title">
            <span>
Maximum flight price
            </span>
          </div>
          <div className="flight-filter-item__item">
Range slider will be placed here
          </div>
        </div>
      </div>
      {/* Duration & Stops */}
      <div className="flight-filter-item__wrapper">
        <div className="pills text-overflow ">
          <MdCancel size={24} className="pills__close" />
          Duration & Stops
          <MdArrowDropDown size={16} className="icon" />
        </div>
        <div className="flight-filter-item__list">
          <div className="flight-filter-item__title">
            <span>
Stops
            </span>
          </div>
          <label className="flight-filter-item__item" htmlFor="non-stop">
            <input type="radio" id="non-stop" className="filter-radio" />
            Non-stop
          </label>
          <label className="flight-filter-item__item" htmlFor="1stop">
            <input type="radio" className="filter-radio" id="1stop" />
1 stop
          </label>
          <label className="flight-filter-item__item" htmlFor="+2stop">
            <input type="radio" className="filter-radio" id="+2stop" />
2 or more stops
          </label>

          <div className="flight-filter-item__title">
            <span>
Maximum duration
            </span>
          </div>
          <div className="flight-filter-item__item">
Range slider will be placed here
          </div>
        </div>
      </div>
    </div>
  );
}
