import React, { Component } from 'react';

// unused

export default function PassengerAdult() {
  return (
    <div className="form__default">
      <div className="form__row">
        <div className="form__group form__group__collect">
          <div className="form__group__item form__size__title">
            <div className="form__label">
              <label>
Title
              </label>
            </div>
            <div className="form__input">
              <select className="form__input__control">
                <option value="1">
Mr
                </option>
                <option value="2">
Mrs
                </option>
                <option value="3">
Mr.s
                </option>
              </select>
            </div>
          </div>
          <div className="form__group__item">
            <div className="form__label">
              <label>
First name
              </label>
              <span className="form-message color-danger">
Required
              </span>
            </div>
            <div className="form__input">
              <input type="text" placeholder="" className="form__input__control" />
            </div>
          </div>
        </div>
        <div className="form__group">
          <div className="form__label">
            <label>
Last name
            </label>
            <span className="form-message color-danger">
Required
            </span>
          </div>
          <div className="form__input">
            <input type="text" placeholder="" className="form__input__control" />
          </div>
        </div>
      </div>
      <div className="form__row">
        <div className="form__group">
          <div className="form__label">
            <label>
Nationality
            </label>
            <span className="form-message color-danger">
Required
            </span>
          </div>
          <div className="form__input">
            <input type="text" placeholder="" className="form__input__control" />
          </div>
        </div>
        <div className="form__group form__group__collect">
          <div className="form__label">
            <label>
Date of Birth
            </label>
          </div>
          <div className="form__group__item">
            <div className="form__input">
              <select className="form__input__control">
                <option value="1">
1
                </option>
                <option value="2">
2
                </option>
                <option value="3">
3
                </option>
              </select>
            </div>
          </div>
          <div className="form__group__item">
            <div className="form__input">
              <select className="form__input__control">
                <option value="1">
1
                </option>
                <option value="2">
2
                </option>
                <option value="3">
3
                </option>
              </select>
            </div>
          </div>
          <div className="form__group__item">
            <div className="form__input">
              <select className="form__input__control">
                <option value="1">
1
                </option>
                <option value="2">
2
                </option>
                <option value="3">
3
                </option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
