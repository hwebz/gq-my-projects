import React, { Component } from 'react';

import './Booking.scss';

export default class BookingPage extends Component {
  render() {
    return (
      <div>
        <span>
Booking page
        </span>
      </div>
    );
  }
}
