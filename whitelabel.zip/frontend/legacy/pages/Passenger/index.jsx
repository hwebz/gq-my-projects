import React from 'react';

import PageBase from '../PageBase';

import BreadCrumbs from '../../components/BreadCrumbs';
// import PassengerContainer from './components/PassengerContainer';

// import './Passenger.scss';

const Passenger = () => (
  <div>
    <BreadCrumbs currentPage={5} />
    <PassengerContainer />
  </div>
);

export default PageBase(Passenger, { hasCurrencySwitcher: false });
