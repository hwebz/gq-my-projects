import React, { Component } from 'react';
// import './PaymentCard.scss';

export default class PaymentCard extends Component {
  render() {
    return (
      <div className="summary__panel__content">
        <div className="summary__panel__caption">
          <h3>
            Secure Payment Process
          </h3>
        </div>
        <div className="summary__panel__caption">
          <div className="paymentCard__header">
            <div className="paymentCard__title">
              <span>
                Select your payment method
              </span>
            </div>
            <div className="paymentCard__nav">
              <div className="paymentCard__nav__item active">
                <strong>
                  Credit Card
                </strong>
              </div>
              <div className="paymentCard__nav__item">
                <strong>
                  Debit Card
                </strong>
              </div>
              <div className="paymentCard__nav__item">
                <strong>
                  Online Banking
                </strong>
              </div>
            </div>
          </div>
        </div>
        <div className="summary__panel__wrap">
          <div className="PaymentCard__content">
            <div className="form__default">
              <div className="form__row">
                <div className="form__group">
                  <div className="form__label">
                    <label>
                      Card number
                    </label>
                    <span className="form-message color-danger">
                      Required
                    </span>
                    {/* <div className="payment-card__icons">
                      <span className="sprite-icon icon-cc-empty" />
                      <span className="sprite-icon icon-mastercard" />
                      <span className="sprite-icon icon-visa" />
                    </div> */}
                  </div>
                  <div className="form__input">
                    <input type="text" placeholder="" className="form__input__control" />
                  </div>
                </div>
                <div className="form__group form__group__collect">
                  <div className="form__label">
                    <label>
                      Expiry date
                    </label>
                  </div>
                  <div className="form__group__item">
                    <div className="form__input">
                      <select className="form__input__control">
                        <option value="1">
                          Mr
                        </option>
                        <option value="2">
                          Mrs
                        </option>
                        <option value="3">
                          Mr.s
                        </option>
                      </select>
                    </div>
                  </div>
                  <div className="form__group__item">
                    <div className="form__input">
                      <select className="form__input__control">
                        <option value="1">
                          Mr
                        </option>
                        <option value="2">
                          Mrs
                        </option>
                        <option value="3">
                          Mr.s
                        </option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
              <div className="form__row">
                <div className="form__group form__group__collect">
                  <div className="form__group__item">
                    <div className="form__label">
                      <label>
                        Name on card
                      </label>
                      <span className="form-message color-danger">
                        Required
                      </span>
                    </div>
                    <div className="form__input">
                      <input type="text" placeholder="" className="form__input__control" />
                    </div>
                  </div>
                  <div className="form__group__item form__size__small">
                    <div className="form__label">
                      <label>
                        CCV
                      </label>
                      <span className="form-message color-danger">
                        Required
                      </span>
                    </div>
                    <div className="form__input">
                      <input type="text" placeholder="" className="form__input__control" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
