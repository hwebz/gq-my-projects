const airports = {
  data: [
    {
      'airportCode': 'WUX',
      'airportName': 'Wuxi Airport',
      'type': 'Airport',
      'cityCode': 'WUX',
      'cityName': 'Wuxi',
      'countryCode': 'CN',
      'countryName': 'China'
    },
    {
      'airportCode': 'TYO',
      'airportName': 'Tokyo',
      'type': 'Airport',
      'cityCode': 'TYO',
      'cityName': 'Tokyo',
      'countryCode': 'JP',
      'countryName': 'Japan'
    },
    {
      'airportCode': 'TAK',
      'airportName': 'Takamatsu Airport',
      'type': 'Airport',
      'cityCode': 'TAK',
      'cityName': 'Takamatsu',
      'countryCode': 'JP',
      'countryName': 'Japan'
    },
    {
      'airportCode': 'RMQ',
      'airportName': 'Taichung',
      'type': 'Airport',
      'cityCode': 'TXG',
      'cityName': 'Taichung',
      'countryCode': 'TW',
      'countryName': 'Taiwan'
    },
    {
      'airportCode': 'RGN',
      'airportName': 'Mingaladon Airport',
      'type': 'Airport',
      'cityCode': 'RGN',
      'cityName': 'Yangon',
      'countryCode': 'MM',
      'countryName': 'Myanmar'
    },
    {
      'airportCode': 'REP',
      'airportName': 'Siem Reap International Airport',
      'type': 'Airport',
      'cityCode': 'REP',
      'cityName': 'Siem Reap',
      'countryCode': 'KH',
      'countryName': 'Cambodia'
    },
    {
      'airportCode': 'PUS',
      'airportName': 'Gimhae International Airport',
      'type': 'Airport',
      'cityCode': 'PUS',
      'cityName': 'Pusan',
      'countryCode': 'KR',
      'countryName': 'South Korea'
    },
    {
      'airportCode': 'NRT',
      'airportName': 'Narita International Airport',
      'type': 'Airport',
      'cityCode': 'NRT',
      'cityName': 'Tokyo',
      'countryCode': 'JP',
      'countryName': 'Japan'
    },
    {
      'airportCode': 'NGO',
      'airportName': 'Nagoya Chubu Cnt Intl Airport',
      'type': 'Airport',
      'cityCode': 'NGO',
      'cityName': 'Nagoya',
      'countryCode': 'JP',
      'countryName': 'Japan'
    },
    {
      'airportCode': 'NGB',
      'airportName': 'Ningbo Airport',
      'type': 'Airport',
      'cityCode': 'NGB',
      'cityName': 'Ningbo',
      'countryCode': 'CN',
      'countryName': 'China'
    },
    {
      'airportCode': 'MDL',
      'airportName': 'Annisaton Airport',
      'type': 'Airport',
      'cityCode': 'MDL',
      'cityName': 'Mandalay',
      'countryCode': 'MM',
      'countryName': 'Myanmar'
    },
    {
      'airportCode': 'LHW',
      'airportName': 'Lanzhou Airport',
      'type': 'Airport',
      'cityCode': 'LHW',
      'cityName': 'Lanzhou',
      'countryCode': 'CN',
      'countryName': 'China'
    },
    {
      'airportCode': 'KOJ',
      'airportName': 'Kagoshima Airport',
      'type': 'Airport',
      'cityCode': 'KOJ',
      'cityName': 'Kagoshima',
      'countryCode': 'JP',
      'countryName': 'Japan'
    },
    {
      'airportCode': 'KMG',
      'airportName': 'Kunming Airport',
      'type': 'Airport',
      'cityCode': 'KMG',
      'cityName': 'Kunming',
      'countryCode': 'CN',
      'countryName': 'China'
    },
    {
      'airportCode': 'KIX',
      'airportName': 'Kansai International Airport',
      'type': 'Airport',
      'cityCode': 'OSA',
      'cityName': 'Osaka',
      'countryCode': 'JP',
      'countryName': 'Japan'
    },
    {
      'airportCode': 'ISG',
      'airportName': 'Ishigaki Airport',
      'type': 'Airport',
      'cityCode': 'ISG',
      'cityName': 'Ishigaki',
      'countryCode': 'JP',
      'countryName': 'Japan'
    },
    {
      'airportCode': 'ICN',
      'airportName': 'Incheion International Airport',
      'type': 'Airport',
      'cityCode': 'SEL',
      'cityName': 'Seoul',
      'countryCode': 'KR',
      'countryName': 'South Korea'
    },
    {
      'airportCode': 'HND',
      'airportName': 'Haneda Airport',
      'type': 'Airport',
      'cityCode': 'HND',
      'cityName': 'Tokyo',
      'countryCode': 'JP',
      'countryName': 'Japan'
    },
    {
      'airportCode': 'HKT',
      'airportName': 'Phuket Airport',
      'type': 'Airport',
      'cityCode': 'HKT',
      'cityName': 'Phuket',
      'countryCode': 'TH',
      'countryName': 'Thailand'
    },
    {
      'airportCode': 'HKG',
      'airportName': 'Hong Kong International Airport',
      'type': 'Airport',
      'cityCode': 'HKG',
      'cityName': 'Hong Kong',
      'countryCode': 'HK',
      'countryName': 'Hong Kong'
    },
    {
      'airportCode': 'HIJ',
      'airportName': 'Hiroshima Airport',
      'type': 'Airport',
      'cityCode': 'HIJ',
      'cityName': 'Hiroshima',
      'countryCode': 'JP',
      'countryName': 'Japan'
    },
    {
      'airportCode': 'FUK',
      'airportName': 'Fukuoka Airport',
      'type': 'Airport',
      'cityCode': 'FUK',
      'cityName': 'Fukuoka',
      'countryCode': 'JP',
      'countryName': 'Japan'
    },
    {
      'airportCode': 'DAN',
      'airportName': 'Da Nang International Airport',
      'type': 'Airport',
      'cityCode': 'DAD',
      'cityName': 'Danville',
      'countryCode': 'VN',
      'countryName': 'Vietnam'
    },
    {
      'airportCode': 'CNX',
      'airportName': 'Chiang Mai International Airport',
      'type': 'Airport',
      'cityCode': 'CNX',
      'cityName': 'Chiang Mai',
      'countryCode': 'TH',
      'countryName': 'Thailand'
    },
    {
      'airportCode': 'CJU',
      'airportName': 'Jeju International Airport',
      'type': 'Airport',
      'cityCode': 'CJU',
      'cityName': 'Jeju',
      'countryCode': 'KR',
      'countryName': 'South Korea'
    },
    {
      'airportCode': 'CEI',
      'airportName': 'Chiang Rai International Airport',
      'type': 'Airport',
      'cityCode': 'CEI',
      'cityName': 'Chiang Rai',
      'countryCode': 'TH',
      'countryName': 'Thailand'
    }
  ],
  'isSuccess': true,
  'message': null,
  'errorCode': null
}
export default airports;
