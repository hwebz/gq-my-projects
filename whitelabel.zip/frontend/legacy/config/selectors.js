export const getDefaultCurrencies = state => state.defaultConfig.general.currencies;
export const getDefaultCurrency = state => state.defaultConfig.general.defaultCurrency;
export const getLanguages = state => state.defaultConfig.general.languages;
export const getDefaultLanguage = state => state.defaultConfig.general.defaultLanguage;
export const getGeneralConfig = state => state.defaultConfig.general;
