import {
  all,
  fork,
  put,
  takeLatest,
} from 'redux-saga/effects';

// @flow
import ComponentUtils from 'react-next/utils/component-utils';

import {
  actionTypes,
  submitConfig,
} from './actions';

import ErrorHandler from '../../client-error';

const Sentry = ErrorHandler.getInstance();

function* getConfig() {
  try {
    const { config } = ComponentUtils.getWindowInitialPageProps().pageProps;
    yield put(submitConfig(config));
  } catch (err) {
    Sentry.captureException(err);
  }
}

function* submitConfigRequest({ payload }) {
  try {
    const { config } = payload;
    yield put(submitConfig(config));
  } catch (err) {
    yield getConfig();
  }
}

export default function* configSaga() {
  yield all([
    fork(takeLatest, actionTypes.GET_CONFIG_REQUEST, getConfig),
    fork(takeLatest, actionTypes.SUBMIT_CONFIG_REQUEST, submitConfigRequest),
  ]);
}
