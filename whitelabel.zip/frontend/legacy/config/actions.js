export const actionTypes = {
  GET_CONFIG_REQUEST: 'config/GET_CONFIG_REQUEST',
  SUBMIT_CONFIG_REQUEST: 'config/SUBMIT_CONFIG_REQUEST',
  SUBMIT_CONFIG: 'config/SUBMIT_CONFIG',
};

export const submitConfig = config => ({
  type: actionTypes.SUBMIT_CONFIG,
  config,
});
