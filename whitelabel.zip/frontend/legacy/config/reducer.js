import {
  actionTypes,
} from './actions';

export const initialState = {
  general: {},
  feature: {},
  environment: {},
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.SUBMIT_CONFIG:
      return {
        ...state,
        ...action.config,
      };
    default:
      return state;
  }
};

export default reducer;
