module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./client-data.js":
/***/ (function(module, exports, __webpack_require__) {

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

// Note: Server Config is for API Path that should be hidden from client
var prod = "development" === 'production'; // TODO: Some variables here will be set by published environment variable
// This is created for easy access for environment variables with less human error

var ClientData =
/*#__PURE__*/
function () {
  function ClientData() {
    _classCallCheck(this, ClientData);
  }

  _createClass(ClientData, null, [{
    key: "IS_PRODUCTION",
    get: function get() {
      return "development" === 'production';
    }
  }, {
    key: "SENTRY_DSN",
    get: function get() {
      return 'https://22c5e2d624584ca1aa56dcb20b2de87a@sentry.io/1237747';
    }
  }, {
    key: "ENVIRONMENT",
    get: function get() {
      return "development";
    } // TODO: release version retrieved from a file overriden by auto-deployment

  }, {
    key: "RELEASE_VERSION",
    get: function get() {
      return '0.0.1';
    }
  }, {
    key: "API_PATH",
    get: function get() {
      // TODO Change to real api
      return process.env.API_ENV === 'development' ? 'http://white-label-server.s3.amazonaws.com' : 'http://white-label-server.s3.amazonaws.com';
    }
  }]);

  return ClientData;
}();

Object.defineProperty(ClientData, "SELECTED_CURRENCY", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: ''
});
module.exports = ClientData;

/***/ }),

/***/ "./client-error.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ClientErrorHandler; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ip__ = __webpack_require__("ip");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ip___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_ip__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__react_next_error__ = __webpack_require__("./react-next/error/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__react_next_error___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__react_next_error__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__client_data__ = __webpack_require__("./client-data.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__client_data___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__client_data__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return _get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// Note: it is important to seperate Client and Server Errors


 // TODO: Setting Error Mapping, haven't decide on the mapping object structure

var errorMap = new Map(); // Refer to sentry options here
// https://docs.sentry.io/clients/node/config/

var ClientErrorHandler =
/*#__PURE__*/
function (_ErrorHandler) {
  _inherits(ClientErrorHandler, _ErrorHandler);

  function ClientErrorHandler() {
    var _this;

    _classCallCheck(this, ClientErrorHandler);

    _this = _possibleConstructorReturn(this, (ClientErrorHandler.__proto__ || Object.getPrototypeOf(ClientErrorHandler)).call(this, __WEBPACK_IMPORTED_MODULE_2__client_data___default.a.SENTRY_DSN, __WEBPACK_IMPORTED_MODULE_2__client_data___default.a.ENVIRONMENT, __WEBPACK_IMPORTED_MODULE_2__client_data___default.a.RELEASE_VERSION, errorMap));
    _this.isOn = false;
    return _this;
  }

  _createClass(ClientErrorHandler, [{
    key: "install",
    value: function install() {
      _get(ClientErrorHandler.prototype.__proto__ || Object.getPrototypeOf(ClientErrorHandler.prototype), "install", this).call(this);

      if (this.dsn && this.isOn) {
        this.getRaven().setUserContext({
          ip_address: __WEBPACK_IMPORTED_MODULE_0_ip___default.a.address()
        });
      }
    }
  }], [{
    key: "getInstance",
    value: function getInstance() {
      if (!ClientErrorHandler._INSTANCE) {
        ClientErrorHandler._INSTANCE = new ClientErrorHandler();
      }

      return ClientErrorHandler._INSTANCE;
    }
  }]);

  return ClientErrorHandler;
}(__WEBPACK_IMPORTED_MODULE_1__react_next_error___default.a);



/***/ }),

/***/ "./components/SearchForm/actions.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return actionTypes; });
/* harmony export (immutable) */ __webpack_exports__["b"] = failure;
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return setFetching; });
/* unused harmony export getLocationRequest */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return getLocationSuccess; });
/* unused harmony export startSearch */
/* unused harmony export startSearchSuccess */
var actionTypes = {
  FAILURE: 'FAILURE',
  SET_FETCHING: 'SET_FETCHING',
  GET_LOCATION_REQUEST: 'GET_LOCATION_REQUEST',
  GET_LOCATION_SUCCESS: 'GET_LOCATION_SUCCESS',
  START_SEARCH_REQUEST: 'START_SEARCH_REQUEST',
  START_SEARCH_SUCCESS: 'START_SEARCH_SUCCESS'
};
function failure(error) {
  return {
    type: actionTypes.FAILURE,
    error: error
  };
}
var setFetching = function setFetching(value) {
  return {
    type: actionTypes.SET_FETCHING,
    value: value
  };
};
var getLocationRequest = function getLocationRequest() {
  return {
    type: actionTypes.GET_LOCATION_REQUEST
  };
};
var getLocationSuccess = function getLocationSuccess(data) {
  return {
    type: actionTypes.GET_LOCATION_SUCCESS,
    data: data
  };
};
var startSearch = function startSearch() {
  return {
    type: actionTypes.START_SEARCH_REQUEST
  };
};
var startSearchSuccess = function startSearchSuccess() {
  return {
    type: actionTypes.START_SEARCH_SUCCESS
  };
};

/***/ }),

/***/ "./components/SearchForm/reducers.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return initialState; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__actions__ = __webpack_require__("./components/SearchForm/actions.js");
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


var initialState = {
  errors: [],
  messages: [],
  success: false,
  isFetching: false,
  isLoading: false,
  airportData: [],
  airportResult: []
};

function reducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;
  var action = arguments.length > 1 ? arguments[1] : undefined;

  switch (action.type) {
    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].FAILURE:
      return _objectSpread({}, state, {
        error: action.error
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].SET_FETCHING:
      return _objectSpread({}, state, {
        isFetching: action.value
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].GET_LOCATION_SUCCESS:
      {
        return _objectSpread({}, state, {
          airportData: action.data,
          isFetching: false
        });
      }

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].START_SEARCH_REQUEST:
      return _objectSpread({}, state, {
        isFetching: true
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].START_SEARCH_SUCCESS:
      return {};

    default:
      return state;
  }
}

/* harmony default export */ __webpack_exports__["a"] = (reducer);

/***/ }),

/***/ "./components/SearchForm/searchFormSaga.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = searchFormSaga;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_axios__ = __webpack_require__("axios");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_axios___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_axios__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__ = __webpack_require__("redux-saga/effects");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_redux_saga_effects___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_es6_promise__ = __webpack_require__("es6-promise");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_es6_promise___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_es6_promise__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__actions__ = __webpack_require__("./components/SearchForm/actions.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__store_modules_locale_selection_selectors__ = __webpack_require__("./store/modules/locale-selection/selectors.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_services__ = __webpack_require__("./services/services.js");


var _marked =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(getLocationRequest),
    _marked2 =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(searchFormSaga);






 // all api services can be accessed

__WEBPACK_IMPORTED_MODULE_3_es6_promise___default.a.polyfill();

var delay = function delay(ms) {
  return new Promise(function (res) {
    return setTimeout(res, ms);
  });
};

function getLocationRequest(payload) {
  var airportRequestURL, locale, requestURL, data, dataAPI, _requestURL, _data, _dataAPI;

  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function getLocationRequest$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          _context.prev = 0;
          _context.next = 3;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_4__actions__["d" /* setFetching */])(true));

        case 3:
          airportRequestURL = __WEBPACK_IMPORTED_MODULE_6__services_services__["a" /* default */].getAirports;
          _context.next = 6;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["select"])(__WEBPACK_IMPORTED_MODULE_5__store_modules_locale_selection_selectors__["a" /* getCultureCode */]);

        case 6:
          locale = _context.sent;

          if (!(payload.location === undefined)) {
            _context.next = 19;
            break;
          }

          requestURL = "".concat(airportRequestURL, "?lang=").concat(locale, "&search=");
          _context.next = 11;
          return __WEBPACK_IMPORTED_MODULE_1_axios___default()(requestURL);

        case 11:
          data = _context.sent;
          dataAPI = data.data.slice(0, 10);
          _context.next = 15;
          return delay(200);

        case 15:
          _context.next = 17;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_4__actions__["c" /* getLocationSuccess */])(dataAPI));

        case 17:
          _context.next = 28;
          break;

        case 19:
          _requestURL = "".concat(airportRequestURL, "?lang=").concat(locale, "&search=").concat(payload.location);
          _context.next = 22;
          return __WEBPACK_IMPORTED_MODULE_1_axios___default()(_requestURL);

        case 22:
          _data = _context.sent;
          _dataAPI = _data.data;
          _context.next = 26;
          return delay(200);

        case 26:
          _context.next = 28;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_4__actions__["c" /* getLocationSuccess */])(_dataAPI));

        case 28:
          _context.next = 34;
          break;

        case 30:
          _context.prev = 30;
          _context.t0 = _context["catch"](0);
          _context.next = 34;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_4__actions__["b" /* failure */])(_context.t0));

        case 34:
        case "end":
          return _context.stop();
      }
    }
  }, _marked, this, [[0, 30]]);
}

function searchFormSaga() {
  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function searchFormSaga$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          _context2.next = 2;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["all"])([Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["takeLatest"], __WEBPACK_IMPORTED_MODULE_4__actions__["a" /* actionTypes */].GET_LOCATION_REQUEST, getLocationRequest)]);

        case 2:
        case "end":
          return _context2.stop();
      }
    }
  }, _marked2, this);
}

/***/ }),

/***/ "./env-config.js":
/***/ (function(module, exports) {

// Important Note: Change here to test staging api and local mock
function getApiDomain() {
  switch (process.env.API_ENV) {
    case 'production':
      return 'https://api.example.com/';

    case 'staging':
      return 'http://white-label-staging.goquo.vn/';

    default:
      return 'http://white-label-staging.goquo.vn/';
  }
}

module.exports = {
  getApiDomain: getApiDomain()
};

/***/ }),

/***/ "./pages/Home/actions.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return actionTypes; });
/* harmony export (immutable) */ __webpack_exports__["b"] = failure;
/* unused harmony export getClientConfigData */
/* harmony export (immutable) */ __webpack_exports__["c"] = getClientConfigDataSuccess;
var actionTypes = {
  FAILURE: 'FAILURE',
  GET_CLIENT_CONFIG: 'GET_CLIENT_CONFIG',
  GET_CLIENT_CONFIG_SUCCESS: 'GET_CLIENT_CONFIG_SUCCESS'
};
function failure(error) {
  return {
    type: actionTypes.FAILURE,
    error: error
  };
}
function getClientConfigData() {
  return {
    type: actionTypes.GET_CLIENT_CONFIG
  };
}
function getClientConfigDataSuccess(data) {
  console.log('Home: GetClientConfig: Success');
  return {
    type: actionTypes.GET_CLIENT_CONFIG_SUCCESS,
    data: data
  };
}

/***/ }),

/***/ "./pages/Home/homeSaga.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = homeSaga;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_axios__ = __webpack_require__("axios");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_axios___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_axios__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__ = __webpack_require__("redux-saga/effects");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_redux_saga_effects___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_es6_promise__ = __webpack_require__("es6-promise");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_es6_promise___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_es6_promise__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__actions__ = __webpack_require__("./pages/Home/actions.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_services__ = __webpack_require__("./services/services.js");


var _marked =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(getClientConfigSaga),
    _marked2 =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(homeSaga);





 // all api services can be accessed

__WEBPACK_IMPORTED_MODULE_3_es6_promise___default.a.polyfill();

function getClientConfigSaga() {
  var _ref, data;

  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function getClientConfigSaga$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          _context.prev = 0;
          _context.next = 3;
          return __WEBPACK_IMPORTED_MODULE_1_axios___default()(__WEBPACK_IMPORTED_MODULE_5__services_services__["a" /* default */].getConfig);

        case 3:
          _ref = _context.sent;
          data = _ref.data;
          _context.next = 7;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_4__actions__["c" /* getClientConfigDataSuccess */])(data));

        case 7:
          _context.next = 13;
          break;

        case 9:
          _context.prev = 9;
          _context.t0 = _context["catch"](0);
          _context.next = 13;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_4__actions__["b" /* failure */])(_context.t0));

        case 13:
        case "end":
          return _context.stop();
      }
    }
  }, _marked, this, [[0, 9]]);
}

function homeSaga() {
  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function homeSaga$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          _context2.next = 2;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["all"])([Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["takeLatest"], __WEBPACK_IMPORTED_MODULE_4__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG, getClientConfigSaga)]);

        case 2:
        case "end":
          return _context2.stop();
      }
    }
  }, _marked2, this);
}

/***/ }),

/***/ "./pages/Home/initial-state.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var state = {
  departureDate: '',
  returnDate: '',
  from: '',
  to: ''
};
/* harmony default export */ __webpack_exports__["a"] = (state);

/***/ }),

/***/ "./pages/Home/reducers.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__actions__ = __webpack_require__("./pages/Home/actions.js");
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // import type { HomeProps } from './types';

function reducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var action = arguments.length > 1 ? arguments[1] : undefined;

  switch (action.type) {
    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].FAILURE:
      return _objectSpread({}, state, {
        error: action.error,
        isFetching: false
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG:
      return _objectSpread({}, state, {
        isFetching: true
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG_SUCCESS:
      return _objectSpread({}, state, {
        response: action.data,
        isFetching: false
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG_FAILED:
      return _objectSpread({}, state, {
        response: null
      });

    default:
      return state;
  }
}

/* harmony default export */ __webpack_exports__["a"] = (reducer);

/***/ }),

/***/ "./pages/HotelDetail/actions.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return actionTypes; });
/* harmony export (immutable) */ __webpack_exports__["b"] = failure;
/* unused harmony export getClientConfigData */
/* harmony export (immutable) */ __webpack_exports__["c"] = getClientConfigDataSuccess;
/* unused harmony export toggleGallery */
/* unused harmony export getHotelGallery */
/* harmony export (immutable) */ __webpack_exports__["d"] = getHotelGallerySuccess;
var actionTypes = {
  FAILURE: 'FAILURE',
  GET_CLIENT_CONFIG: 'GET_CLIENT_CONFIG',
  GET_CLIENT_CONFIG_SUCCESS: 'GET_CLIENT_CONFIG_SUCCESS',
  TOGGLE_GALLERY: 'TOGGLE_GALLERY',
  GET_HOTEL_GALLERY: 'GET_HOTEL_GALLERY',
  GET_HOTEL_GALLERY_SUCCESS: 'GET_HOTEL_GALLERY_SUCCESS'
};
function failure(error) {
  return {
    type: actionTypes.FAILURE,
    error: error
  };
}
function getClientConfigData() {
  return {
    type: actionTypes.GET_CLIENT_CONFIG
  };
}
function getClientConfigDataSuccess(data) {
  return {
    type: actionTypes.GET_CLIENT_CONFIG_SUCCESS,
    data: data
  };
}
function toggleGallery(data) {
  return {
    type: actionTypes.TOGGLE_GALLERY,
    data: data
  };
}
function getHotelGallery(hotelId) {
  return {
    type: actionTypes.GET_HOTEL_GALLERY,
    hotelId: hotelId
  };
}
function getHotelGallerySuccess(data) {
  return {
    type: actionTypes.GET_HOTEL_GALLERY_SUCCESS,
    data: data
  };
}

/***/ }),

/***/ "./pages/HotelDetail/hotelDetailSaga.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = hotelDetailSaga;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_axios__ = __webpack_require__("axios");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_axios___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_axios__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__ = __webpack_require__("redux-saga/effects");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_redux_saga_effects___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_es6_promise__ = __webpack_require__("es6-promise");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_es6_promise___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_es6_promise__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__actions__ = __webpack_require__("./pages/HotelDetail/actions.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_services__ = __webpack_require__("./services/services.js");


var _marked =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(getClientConfigSaga),
    _marked2 =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(getHotelGallerySaga),
    _marked3 =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(hotelDetailSaga);





 // all api services can be accessed

__WEBPACK_IMPORTED_MODULE_3_es6_promise___default.a.polyfill();

function getClientConfigSaga() {
  var _ref, data;

  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function getClientConfigSaga$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          _context.prev = 0;
          _context.next = 3;
          return __WEBPACK_IMPORTED_MODULE_1_axios___default()(__WEBPACK_IMPORTED_MODULE_5__services_services__["a" /* default */].getConfig);

        case 3:
          _ref = _context.sent;
          data = _ref.data;
          _context.next = 7;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_4__actions__["c" /* getClientConfigDataSuccess */])(data));

        case 7:
          _context.next = 13;
          break;

        case 9:
          _context.prev = 9;
          _context.t0 = _context["catch"](0);
          _context.next = 13;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_4__actions__["b" /* failure */])(_context.t0));

        case 13:
        case "end":
          return _context.stop();
      }
    }
  }, _marked, this, [[0, 9]]);
}

function getHotelGallerySaga(hotelId) {
  var _ref2, data;

  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function getHotelGallerySaga$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          _context2.prev = 0;
          _context2.next = 3;
          return __WEBPACK_IMPORTED_MODULE_1_axios___default()(__WEBPACK_IMPORTED_MODULE_5__services_services__["a" /* default */].getHotelGallery);

        case 3:
          _ref2 = _context2.sent;
          data = _ref2.data;
          _context2.next = 7;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_4__actions__["d" /* getHotelGallerySuccess */])(data));

        case 7:
          _context2.next = 13;
          break;

        case 9:
          _context2.prev = 9;
          _context2.t0 = _context2["catch"](0);
          _context2.next = 13;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_4__actions__["b" /* failure */])(_context2.t0));

        case 13:
        case "end":
          return _context2.stop();
      }
    }
  }, _marked2, this, [[0, 9]]);
}

function hotelDetailSaga() {
  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function hotelDetailSaga$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          _context3.next = 2;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["all"])([Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["takeLatest"], __WEBPACK_IMPORTED_MODULE_4__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG, getClientConfigSaga), Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["takeLatest"], __WEBPACK_IMPORTED_MODULE_4__actions__["a" /* actionTypes */].GET_HOTEL_GALLERY, getHotelGallerySaga)]);

        case 2:
        case "end":
          return _context3.stop();
      }
    }
  }, _marked3, this);
}

/***/ }),

/***/ "./pages/HotelDetail/initial-state.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var state = {
  isGalleryOpen: false,
  hotelImages: []
};
/* harmony default export */ __webpack_exports__["a"] = (state);

/***/ }),

/***/ "./pages/HotelDetail/reducers.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__actions__ = __webpack_require__("./pages/HotelDetail/actions.js");
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



function reducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var action = arguments.length > 1 ? arguments[1] : undefined;

  switch (action.type) {
    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].FAILURE:
      return _objectSpread({}, state, {
        error: action.error,
        isFetching: false
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG:
      return _objectSpread({}, state, {
        isFetching: true
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG_SUCCESS:
      return _objectSpread({}, state, {
        response: action.data,
        isFetching: false
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG_FAILED:
      return _objectSpread({}, state, {
        response: null
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].TOGGLE_GALLERY:
      return _objectSpread({}, state, {
        isGalleryOpen: action.data
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].GET_HOTEL_GALLERY:
      return _objectSpread({}, state, {
        isFetching: true
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].GET_HOTEL_GALLERY_SUCCESS:
      return _objectSpread({}, state, {
        hotelImages: action.data.data,
        isFetching: false
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].GET_HOTEL_GALLERY_FAILED:
      return _objectSpread({}, state, {
        response: null
      });

    default:
      return state;
  }
}

/* harmony default export */ __webpack_exports__["a"] = (reducer);

/***/ }),

/***/ "./pages/HotelResults/actions.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return actionTypes; });
/* harmony export (immutable) */ __webpack_exports__["e"] = failure;
/* unused harmony export getClientConfigData */
/* unused harmony export getClientConfigDataSuccess */
/* unused harmony export createPackage */
/* harmony export (immutable) */ __webpack_exports__["d"] = createPackageSuccess;
/* harmony export (immutable) */ __webpack_exports__["c"] = createPackageFailed;
/* harmony export (immutable) */ __webpack_exports__["f"] = getFilteredHotels;
/* harmony export (immutable) */ __webpack_exports__["k"] = getMapHotel;
/* harmony export (immutable) */ __webpack_exports__["m"] = getMapHotelsSuccess;
/* harmony export (immutable) */ __webpack_exports__["l"] = getMapHotelsFailed;
/* harmony export (immutable) */ __webpack_exports__["n"] = pollStartAction;
/* harmony export (immutable) */ __webpack_exports__["o"] = pollStopAction;
/* harmony export (immutable) */ __webpack_exports__["j"] = getHotelsSuccess;
/* harmony export (immutable) */ __webpack_exports__["i"] = getHotelsFailed;
/* harmony export (immutable) */ __webpack_exports__["b"] = changeFilter;
/* harmony export (immutable) */ __webpack_exports__["p"] = resetFilter;
/* harmony export (immutable) */ __webpack_exports__["r"] = toggleGallery;
/* harmony export (immutable) */ __webpack_exports__["g"] = getHotelGallery;
/* harmony export (immutable) */ __webpack_exports__["h"] = getHotelGallerySuccess;
/* harmony export (immutable) */ __webpack_exports__["q"] = setPage;
var actionTypes = {
  FAILURE: 'FAILURE',
  GET_CLIENT_CONFIG: 'GET_CLIENT_CONFIG',
  GET_CLIENT_CONFIG_SUCCESS: 'GET_CLIENT_CONFIG_SUCCESS',
  CREATE_PACKAGE: 'CREATE_PACKAGE',
  CREATE_PACKAGE_SUCCESS: 'CREATE_PACKAGE_SUCCESS',
  CREATE_PACKAGE_FAILED: 'CREATE_PACKAGE_FAILED',
  GET_FILTERED_HOTELS: 'GET_FILTERED_HOTELS',
  HOTEL_RESULT_POLL_START: 'HOTEL_RESULT_POLL_START',
  HOTEL_RESULT_POLL_STOP: 'HOTEL_RESULT_POLL_STOP',
  GET_HOTELS_SUCCESS: 'GET_HOTELS_SUCCESS',
  GET_HOTELS_FAILED: 'GET_HOTELS_FAILED',
  CHANGE_FILTER: 'CHANGE_FILTER',
  RESET_FILTER: 'RESET_FILTER',
  SET_PAGE: 'SET_PAGE',
  TOGGLE_GALLERY_HL: 'TOGGLE_GALLERY_HL',
  GET_HOTEL_GALLERY_HL: 'GET_HOTEL_GALLERY_HL',
  GET_HOTEL_GALLERY_SUCCESS_HL: 'GET_HOTEL_GALLERY_SUCCESS_HL',
  GET_MAP_HOTEL: 'GET_MAP_HOTEL',
  GET_MAP_HOTEL_SUCCESS: 'GET_MAP_HOTEL_SUCCESS',
  GET_MAP_HOTEL_FAILED: 'GET_MAP_HOTEL_FAILED'
};
function failure(error) {
  return {
    type: actionTypes.FAILURE,
    error: error
  };
}
function getClientConfigData() {
  return {
    type: actionTypes.GET_CLIENT_CONFIG
  };
}
function getClientConfigDataSuccess(data) {
  return {
    type: actionTypes.GET_CLIENT_CONFIG_SUCCESS,
    data: data
  };
}
function createPackage(query) {
  return {
    type: actionTypes.CREATE_PACKAGE,
    query: query
  };
}
function createPackageSuccess(packageId, percent) {
  return {
    type: actionTypes.CREATE_PACKAGE_SUCCESS,
    data: packageId,
    percent: percent
  };
}
function createPackageFailed(callbacks) {
  return {
    type: actionTypes.CREATE_PACKAGE_FAILED,
    data: callbacks
  };
}
function getFilteredHotels(packageId, hotelApiQuery, percent) {
  return {
    type: actionTypes.GET_FILTERED_HOTELS,
    data: {
      packageId: packageId,
      hotelApiQuery: hotelApiQuery,
      percent: percent
    }
  };
}
function getMapHotel(coordinates) {
  return {
    type: actionTypes.GET_MAP_HOTEL,
    data: coordinates
  };
}
function getMapHotelsSuccess(hotels) {
  return {
    type: actionTypes.GET_MAP_HOTEL_SUCCESS,
    data: hotels
  };
}
function getMapHotelsFailed(callbacks) {
  return {
    type: actionTypes.GET_MAP_HOTEL_FAILED,
    data: callbacks
  };
}
function pollStartAction(_ref) {
  var payload = _ref.payload;
  return {
    type: actionTypes.HOTEL_RESULT_POLL_START,
    payload: payload
  };
}
function pollStopAction(percent, total) {
  var totalHotels = parseInt(total, 10);
  return {
    type: actionTypes.HOTEL_RESULT_POLL_STOP,
    percent: percent,
    totalHotels: totalHotels
  };
}
function getHotelsSuccess(hotels, percent) {
  return {
    type: actionTypes.GET_HOTELS_SUCCESS,
    data: hotels,
    percent: percent
  };
}
function getHotelsFailed(callbacks) {
  return {
    type: actionTypes.GET_HOTELS_FAILED,
    data: callbacks
  };
}
function changeFilter(filters) {
  return {
    type: actionTypes.CHANGE_FILTER,
    data: filters
  };
}
function resetFilter(filters) {
  return {
    type: actionTypes.RESET_FILTER,
    data: filters
  };
}
function toggleGallery(data) {
  return {
    type: actionTypes.TOGGLE_GALLERY_HL,
    data: data
  };
}
function getHotelGallery(hotelId) {
  return {
    type: actionTypes.GET_HOTEL_GALLERY_HL,
    hotelId: hotelId
  };
}
function getHotelGallerySuccess(data) {
  return {
    type: actionTypes.GET_HOTEL_GALLERY_SUCCESS_HL,
    data: data
  };
}
function setPage(currentPage) {
  return {
    type: actionTypes.SET_PAGE,
    currentPage: currentPage
  };
}

/***/ }),

/***/ "./pages/HotelResults/hotelResultSaga.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = hotelResultsSaga;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_axios__ = __webpack_require__("axios");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_axios___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_axios__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__ = __webpack_require__("redux-saga/effects");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_redux_saga_effects___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_redux_saga__ = __webpack_require__("redux-saga");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_redux_saga___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_redux_saga__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_es6_promise__ = __webpack_require__("es6-promise");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_es6_promise___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_es6_promise__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_services__ = __webpack_require__("./services/services.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__actions__ = __webpack_require__("./pages/HotelResults/actions.js");


var _marked =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(pollHotelResults),
    _marked2 =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(getFilteredHotelResults),
    _marked3 =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(getHotelGallerySaga),
    _marked4 =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(getMapHotelSaga),
    _marked5 =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(hotelResultsSaga);





 // all api services can be accessed


__WEBPACK_IMPORTED_MODULE_4_es6_promise___default.a.polyfill(); // get the action payload from HOTEL_RESULT_POLL_START,
// passing directly to the method cause infinity loop

var globlePayload;

function pollHotelResults() {
  var _globlePayload$payloa, cultureCode, currency, pageSize, currentPage, packageData, count, isCompleted, progressAmount, packageId, pidObj, res, data, successData;

  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function pollHotelResults$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          _globlePayload$payloa = globlePayload.payload, cultureCode = _globlePayload$payloa.cultureCode, currency = _globlePayload$payloa.currency, pageSize = _globlePayload$payloa.pageSize, currentPage = _globlePayload$payloa.currentPage, packageData = _globlePayload$payloa.packageData;
          count = 0;
          isCompleted = false;
          progressAmount = 0;
          packageId = '';
          _context.prev = 5;
          _context.next = 8;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["call"])(function () {
            return __WEBPACK_IMPORTED_MODULE_1_axios___default()({
              method: 'post',
              url: __WEBPACK_IMPORTED_MODULE_5__services_services__["a" /* default */].createPackage,
              data: packageData
            });
          });

        case 8:
          pidObj = _context.sent;
          _context.next = 11;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["d" /* createPackageSuccess */])(pidObj.data.packageId, progressAmount));

        case 11:
          packageId = _context.sent;
          console.log('%c Hotel package ID created!! ', 'background: #29bc7a; color: #fff');
          _context.next = 20;
          break;

        case 15:
          _context.prev = 15;
          _context.t0 = _context["catch"](5);
          console.log('%c Package ID not created!! ', 'background: #f00; color: #fff');
          _context.next = 20;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["c" /* createPackageFailed */])(_context.t0));

        case 20:
          if (!packageId) {
            _context.next = 55;
            break;
          }

        case 21:
          if (false) {
            _context.next = 55;
            break;
          }

          count++;
          progressAmount = count * 20;
          _context.prev = 24;
          _context.next = 27;
          return __WEBPACK_IMPORTED_MODULE_1_axios___default()("".concat(__WEBPACK_IMPORTED_MODULE_5__services_services__["a" /* default */].getHotels, "?packageId=").concat(packageId.data, "&lang=").concat(cultureCode, "&currency=").concat(currency, "&pageSize=").concat(pageSize, "&page=").concat(currentPage));

        case 27:
          res = _context.sent;
          _context.next = 30;
          return res.data;

        case 30:
          data = _context.sent;
          _context.next = 33;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["j" /* getHotelsSuccess */])(data, progressAmount, count));

        case 33:
          successData = _context.sent;
          isCompleted = successData.data.isComplete;
          _context.next = 37;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["call"])(__WEBPACK_IMPORTED_MODULE_3_redux_saga__["delay"], 2000);

        case 37:
          if (!isCompleted) {
            _context.next = 42;
            break;
          }

          _context.next = 40;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["o" /* pollStopAction */])(100, successData.data.totalHotels));

        case 40:
          _context.next = 46;
          break;

        case 42:
          if (!(count >= 5)) {
            _context.next = 46;
            break;
          }

          isCompleted = true;
          _context.next = 46;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["o" /* pollStopAction */])(100, successData.data.totalHotels));

        case 46:
          _context.next = 53;
          break;

        case 48:
          _context.prev = 48;
          _context.t1 = _context["catch"](24);
          console.log("error");
          _context.next = 53;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["i" /* getHotelsFailed */])(_context.t1));

        case 53:
          _context.next = 21;
          break;

        case 55:
        case "end":
          return _context.stop();
      }
    }
  }, _marked, this, [[5, 15], [24, 48]]);
}

function getFilteredHotelResults(payload) {
  var _payload$data, packageId, hotelApiQuery, page, pageSize, maxPriceType, filters, lang, currency, _ref, data;

  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function getFilteredHotelResults$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          _payload$data = payload.data, packageId = _payload$data.packageId, hotelApiQuery = _payload$data.hotelApiQuery;
          page = hotelApiQuery.page, pageSize = hotelApiQuery.pageSize, maxPriceType = hotelApiQuery.maxPriceType, filters = hotelApiQuery.filters, lang = hotelApiQuery.lang, currency = hotelApiQuery.currency;
          _context2.prev = 2;
          _context2.next = 5;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["call"])(function () {
            return __WEBPACK_IMPORTED_MODULE_1_axios___default()({
              method: 'get',
              url: "".concat(__WEBPACK_IMPORTED_MODULE_5__services_services__["a" /* default */].getHotels, "?packageId=").concat(packageId, "&page=").concat(page, "&pageSize=").concat(pageSize, "&name=").concat(filters.name, "&minStars=").concat(filters.minStars, "&maxPrice=").concat(filters.maxPrice, "&maxPriceType=").concat(maxPriceType, "&minReview=").concat(filters.minReview, "&sortBy=").concat(filters.sortBy, "&lang=").concat(lang, "&currency=").concat(currency)
            });
          });

        case 5:
          _ref = _context2.sent;
          data = _ref.data;
          _context2.next = 9;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["j" /* getHotelsSuccess */])(data));

        case 9:
          _context2.next = 15;
          break;

        case 11:
          _context2.prev = 11;
          _context2.t0 = _context2["catch"](2);
          _context2.next = 15;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["i" /* getHotelsFailed */])(_context2.t0));

        case 15:
        case "end":
          return _context2.stop();
      }
    }
  }, _marked2, this, [[2, 11]]);
}

function ImageExist(url) {
  var img = new Image();
  img.src = url;

  if (img.height !== 0) {
    return false;
  }

  return true;
}

function getHotelGallerySaga(payload) {
  var hotelId, images, _ref2, data;

  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function getHotelGallerySaga$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          // later we will use hotelId to get data
          hotelId = payload.hotelId;
          images = [];
          _context3.prev = 2;
          _context3.next = 5;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["call"])(function () {
            return __WEBPACK_IMPORTED_MODULE_1_axios___default()({
              method: 'get',
              url: "".concat(__WEBPACK_IMPORTED_MODULE_5__services_services__["a" /* default */].getHotelGallery, "?hotelId=").concat(hotelId)
            });
          });

        case 5:
          _ref2 = _context3.sent;
          data = _ref2.data;
          data.data.map(function (url) {
            if (ImageExist(url)) {
              images.push(url);
            }
          });
          _context3.next = 10;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["h" /* getHotelGallerySuccess */])(images));

        case 10:
          _context3.next = 16;
          break;

        case 12:
          _context3.prev = 12;
          _context3.t0 = _context3["catch"](2);
          _context3.next = 16;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["e" /* failure */])(_context3.t0));

        case 16:
        case "end":
          return _context3.stop();
      }
    }
  }, _marked3, this, [[2, 12]]);
}

function getMapHotelSaga(payload) {
  var _ref3, data;

  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function getMapHotelSaga$(_context4) {
    while (1) {
      switch (_context4.prev = _context4.next) {
        case 0:
          _context4.prev = 0;
          _context4.next = 3;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["call"])(function () {
            return __WEBPACK_IMPORTED_MODULE_1_axios___default()({
              method: 'get',
              url: "".concat(__WEBPACK_IMPORTED_MODULE_5__services_services__["a" /* default */].getMapHotels, "?").concat(payload.data)
            });
          });

        case 3:
          _ref3 = _context4.sent;
          data = _ref3.data;
          _context4.next = 7;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["m" /* getMapHotelsSuccess */])(data));

        case 7:
          _context4.next = 13;
          break;

        case 9:
          _context4.prev = 9;
          _context4.t0 = _context4["catch"](0);
          _context4.next = 13;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["l" /* getMapHotelsFailed */])(_context4.t0));

        case 13:
        case "end":
          return _context4.stop();
      }
    }
  }, _marked4, this, [[0, 9]]);
}

function hotelResultsSaga() {
  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function hotelResultsSaga$(_context5) {
    while (1) {
      switch (_context5.prev = _context5.next) {
        case 0:
          _context5.next = 2;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["takeLatest"], 'GET_FILTERED_HOTELS', getFilteredHotelResults);

        case 2:
          _context5.next = 4;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["takeLatest"], 'GET_MAP_HOTEL', getMapHotelSaga);

        case 4:
          _context5.next = 6;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["takeLatest"], 'GET_HOTEL_GALLERY_HL', getHotelGallerySaga);

        case 6:
          if (false) {
            _context5.next = 14;
            break;
          }

          _context5.next = 9;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["take"])(__WEBPACK_IMPORTED_MODULE_6__actions__["a" /* actionTypes */].HOTEL_RESULT_POLL_START);

        case 9:
          globlePayload = _context5.sent;
          _context5.next = 12;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["race"])([Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["call"])(pollHotelResults), Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["take"])(__WEBPACK_IMPORTED_MODULE_6__actions__["a" /* actionTypes */].HOTEL_RESULT_POLL_STOP)]);

        case 12:
          _context5.next = 6;
          break;

        case 14:
        case "end":
          return _context5.stop();
      }
    }
  }, _marked5, this);
}

/***/ }),

/***/ "./pages/HotelResults/initial-state.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var state = {
  callbacks: {},
  packageId: '',
  hotels: {},
  config: {
    minBookingPeriod: 1,
    maxBookingPeriod: 30,
    minBookingDays: 3,
    maxBookingDays: 365,
    maxRooms: 3,
    maxPax: 9
  },
  isPolling: true,
  progressStatus: {},
  currentPage: 1,
  pageSize: 10,
  filters: {
    maxPrice: 0,
    minStars: 1,
    minReview: 0,
    name: '',
    sortBy: 'recommended'
  },
  isGalleryOpen: false,
  hotelImages: []
};
/* harmony default export */ __webpack_exports__["a"] = (state);

/***/ }),

/***/ "./pages/HotelResults/reducers.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react_addons_update__ = __webpack_require__("react-addons-update");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react_addons_update___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react_addons_update__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__actions__ = __webpack_require__("./pages/HotelResults/actions.js");
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


 // import type { HomeProps } from './types';

function reducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var action = arguments.length > 1 ? arguments[1] : undefined;

  switch (action.type) {
    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].FAILURE:
      return _objectSpread({}, state, {
        error: action.error,
        isFetching: false
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG:
      return _objectSpread({}, state, {
        isFetching: true
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG_SUCCESS:
      return _objectSpread({}, state, {
        response: action.data,
        isFetching: false
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG_FAILED:
      return _objectSpread({}, state, {
        response: null
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].CREATE_PACKAGE:
      return _objectSpread({}, state, {
        isFetching: true
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].CREATE_PACKAGE_SUCCESS:
      return _objectSpread({}, state, {
        packageId: action.data,
        isFetching: false
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].CREATE_PACKAGE_FAILED:
      return _objectSpread({}, state, {
        response: null,
        apiCallbacks: action.data
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_FILTERED_HOTELS:
      return _objectSpread({}, state, {
        isUpdating: true
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_MAP_HOTEL:
      return _objectSpread({}, state);

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_MAP_HOTEL_SUCCESS:
      {
        return __WEBPACK_IMPORTED_MODULE_0_react_addons_update___default()(state, {
          hotels: {
            map: {
              $set: action.data
            }
          }
        });
      }

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_MAP_HOTEL_FAILED:
      return _objectSpread({}, state, {
        response: null,
        callbacks: action.data
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].HOTEL_RESULT_POLL_START:
      return _objectSpread({}, state, {
        isPolling: true,
        progressStatus: {
          percent: action.percent,
          loadingMsg: 'Loading hotels...' // TODO replace message id of the text

        }
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].HOTEL_RESULT_POLL_STOP:
      {
        var inComplete = action.totalHotels > 0 ? true : false;
        var isComplete = action.totalHotels > 0 ? true : false;
        var initialState = action.totalHotels <= 0 ? true : false;
        return _objectSpread({}, state, {
          isPolling: false,
          progressStatus: {
            percent: action.percent,
            loadingMsg: "".concat(action.totalHotels, " Hotels Loaded.") // TODO replace message id of the text

          },
          inComplete: inComplete,
          isComplete: isComplete
        });
      }

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_HOTELS_SUCCESS:
      {
        var _inComplete = parseInt(action.data.totalHotels, 10) > 0 && state.isPolling ? true : false;

        var _isComplete = parseInt(action.data.totalHotels, 10) > 0 && !state.isPolling ? true : false;

        return _objectSpread({}, state, {
          hotels: action.data,
          isUpdating: false,
          progressStatus: {
            percent: action.percent,
            loadingMsg: 'Finding the best deals' // TODO replace message id of the text

          },
          inComplete: _inComplete,
          isComplete: _isComplete
        });
      }

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_HOTELS_FAILED:
      return _objectSpread({}, state, {
        response: null,
        callbacks: action.data
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].CHANGE_FILTER:
      {
        var _action$data = action.data,
            key = _action$data.key,
            value = _action$data.value;
        return __WEBPACK_IMPORTED_MODULE_0_react_addons_update___default()(state, {
          filters: _defineProperty({}, key, {
            $set: value
          })
        });
      }

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].RESET_FILTER:
      {
        var data = action.data;
        return __WEBPACK_IMPORTED_MODULE_0_react_addons_update___default()(state, {
          filters: {
            maxPrice: {
              $set: data.maxPrice
            },
            minStars: {
              $set: data.minStars
            },
            minReview: {
              $set: data.minReview
            },
            name: {
              $set: data.name
            },
            sortBy: {
              $set: data.sortBy
            }
          }
        });
      }

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].TOGGLE_GALLERY_HL:
      return _objectSpread({}, state, {
        isGalleryOpen: action.data
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_HOTEL_GALLERY_HL:
      return _objectSpread({}, state, {
        isFetching: true
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_HOTEL_GALLERY_SUCCESS_HL:
      return _objectSpread({}, state, {
        hotelImages: action.data,
        isFetching: false
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_HOTEL_GALLERY_FAILED_HL:
      return _objectSpread({}, state, {
        response: null
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].SET_PAGE:
      {
        var currentPage = action.currentPage;
        return _objectSpread({}, state, {
          currentPage: currentPage
        });
      }

    default:
      return state;
  }
}

/* harmony default export */ __webpack_exports__["a"] = (reducer);

/***/ }),

/***/ "./pages/_app.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_next_app__ = __webpack_require__("next/app");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_next_app___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_next_app__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_redux__ = __webpack_require__("react-redux");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_redux___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_redux__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_next_redux_wrapper__ = __webpack_require__("next-redux-wrapper");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_next_redux_wrapper___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_next_redux_wrapper__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_next_redux_saga__ = __webpack_require__("next-redux-saga");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_next_redux_saga___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_next_redux_saga__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__store__ = __webpack_require__("./store/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__client_error__ = __webpack_require__("./client-error.js");

var _jsxFileName = "C:\\Projects\\frontend\\pages\\_app.jsx";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }









var AppDriver =
/*#__PURE__*/
function (_App) {
  _inherits(AppDriver, _App);

  _createClass(AppDriver, null, [{
    key: "getInitialProps",
    value: function () {
      var _getInitialProps = _asyncToGenerator(
      /*#__PURE__*/
      __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee(_ref) {
        var Component, ctx, pageProps;
        return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                Component = _ref.Component, ctx = _ref.ctx;
                pageProps = {};

                if (!Component.getInitialProps) {
                  _context.next = 6;
                  break;
                }

                _context.next = 5;
                return Component.getInitialProps({
                  ctx: ctx
                });

              case 5:
                pageProps = _context.sent;

              case 6:
                return _context.abrupt("return", {
                  pageProps: pageProps
                });

              case 7:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      return function getInitialProps(_x) {
        return _getInitialProps.apply(this, arguments);
      };
    }()
  }]);

  function AppDriver(props) {
    var _this;

    _classCallCheck(this, AppDriver);

    _this = _possibleConstructorReturn(this, (AppDriver.__proto__ || Object.getPrototypeOf(AppDriver)).call(this, props));
    _this.state = {
      error: null
    };
    __WEBPACK_IMPORTED_MODULE_7__client_error__["a" /* default */].getInstance().install();
    return _this;
  }

  _createClass(AppDriver, [{
    key: "componentDidCatch",
    value: function componentDidCatch(error, errorInfo) {
      this.setState({
        error: error
      });
      __WEBPACK_IMPORTED_MODULE_7__client_error__["a" /* default */].getInstance().captureException(error, errorInfo);
    }
  }, {
    key: "render",
    value: function render() {
      var _props = this.props,
          Component = _props.Component,
          pageProps = _props.pageProps,
          store = _props.store;
      return __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_next_app__["Container"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 43
        }
      }, __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_redux__["Provider"], {
        store: store,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 44
        }
      }, __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(Component, _extends({}, pageProps, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 45
        }
      }))));
    }
  }]);

  return AppDriver;
}(__WEBPACK_IMPORTED_MODULE_1_next_app___default.a);

/* harmony default export */ __webpack_exports__["default"] = (__WEBPACK_IMPORTED_MODULE_4_next_redux_wrapper___default()(__WEBPACK_IMPORTED_MODULE_6__store__["a" /* default */])(__WEBPACK_IMPORTED_MODULE_5_next_redux_saga___default()({
  async: true
})(AppDriver)));

/***/ }),

/***/ "./pages/sample/actions.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return actionTypes; });
/* unused harmony export failure */
/* unused harmony export getClientConfigData */
/* unused harmony export getClientConfigDataSuccess */
var actionTypes = {
  FAILURE: 'FAILURE',
  GET_CLIENT_CONFIG: 'GET_CLIENT_CONFIG',
  GET_CLIENT_CONFIG_SUCCESS: 'GET_CLIENT_CONFIG_SUCCESS'
};
function failure(error) {
  return {
    type: actionTypes.FAILURE,
    error: error
  };
}
function getClientConfigData() {
  return {
    type: actionTypes.GET_CLIENT_CONFIG
  };
}
function getClientConfigDataSuccess(data) {
  return {
    type: actionTypes.GET_CLIENT_CONFIG_SUCCESS,
    data: data
  };
}

/***/ }),

/***/ "./pages/sample/initial-state.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var state = {
  departureDate: '',
  returnDate: '',
  from: '',
  to: ''
};
/* harmony default export */ __webpack_exports__["a"] = (state);

/***/ }),

/***/ "./pages/sample/reducers.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__actions__ = __webpack_require__("./pages/sample/actions.js");
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // import type { HomeProps } from './types';

function reducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var action = arguments.length > 1 ? arguments[1] : undefined;

  switch (action.type) {
    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].FAILURE:
      return _objectSpread({}, state, {
        error: action.error,
        isFetching: false
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG:
      return _objectSpread({}, state, {
        isFetching: true
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG_SUCCESS:
      return _objectSpread({}, state, {
        placeholderData: action.data,
        isFetching: false
      });

    case __WEBPACK_IMPORTED_MODULE_0__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG_FAILED:
      return _objectSpread({}, state, {
        response: null
      });

    default:
      return state;
  }
}

/* harmony default export */ __webpack_exports__["a"] = (reducer);

/***/ }),

/***/ "./pages/sample3/actions.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return actionTypes; });
/* harmony export (immutable) */ __webpack_exports__["b"] = failure;
/* unused harmony export loadAirport */
/* harmony export (immutable) */ __webpack_exports__["c"] = loadDataSuccess;
var actionTypes = {
  FAILURE: 'FAILURE',
  LOAD_DATA: 'LOAD_DATA',
  LOAD_DATA_SUCCESS: 'LOAD_DATA_SUCCESS'
};
function failure(error) {
  return {
    type: actionTypes.FAILURE,
    error: error
  };
}
function loadAirport() {
  return {
    type: actionTypes.LOAD_DATA
  };
}
function loadDataSuccess(data) {
  return {
    type: actionTypes.LOAD_DATA_SUCCESS,
    data: data
  };
}

/***/ }),

/***/ "./pages/sample3/saga.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = exSaga;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__ = __webpack_require__("redux-saga/effects");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_redux_saga_effects___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_es6_promise__ = __webpack_require__("es6-promise");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_es6_promise___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_es6_promise__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_axios__ = __webpack_require__("axios");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_axios___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_axios__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_services__ = __webpack_require__("./services/services.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__actions__ = __webpack_require__("./pages/sample3/actions.js");


var _marked =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(loadDataSaga),
    _marked2 =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(exSaga);

/* global fetch */



 // all api services can be accessed


__WEBPACK_IMPORTED_MODULE_2_es6_promise___default.a.polyfill();

function loadDataSaga() {
  var res, data;
  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function loadDataSaga$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          _context.prev = 0;
          _context.next = 3;
          return __WEBPACK_IMPORTED_MODULE_3_axios___default()(__WEBPACK_IMPORTED_MODULE_4__services_services__["a" /* default */].getAirports);

        case 3:
          res = _context.sent;
          _context.next = 6;
          return res.data;

        case 6:
          data = _context.sent;
          console.log(data);
          _context.next = 10;
          return Object(__WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_5__actions__["c" /* loadDataSuccess */])(data));

        case 10:
          _context.next = 16;
          break;

        case 12:
          _context.prev = 12;
          _context.t0 = _context["catch"](0);
          _context.next = 16;
          return Object(__WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_5__actions__["b" /* failure */])(_context.t0));

        case 16:
        case "end":
          return _context.stop();
      }
    }
  }, _marked, this, [[0, 12]]);
}

function exSaga() {
  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function exSaga$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          _context2.next = 2;
          return Object(__WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__["all"])([Object(__WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__["takeLatest"], __WEBPACK_IMPORTED_MODULE_5__actions__["a" /* actionTypes */].LOAD_DATA, loadDataSaga)]);

        case 2:
        case "end":
          return _context2.stop();
      }
    }
  }, _marked2, this);
}

/***/ }),

/***/ "./react-next/error/index.js":
/***/ (function(module, exports, __webpack_require__) {

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

// Future: Interface different Error Handlers, now this purely handle Sentry Errors
var Raven = __webpack_require__("raven-js");

var ErrorHandler =
/*#__PURE__*/
function () {
  function ErrorHandler(dsn, environment, release, errorMap) {
    var options = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {};

    _classCallCheck(this, ErrorHandler);

    this.dsn = dsn;
    this.environment = environment;
    this.release = release;
    this.errorMap = errorMap;
    this.options = options;
    this.isOn = true;
    this.isInstalled = false; // Set Sentry Variables

    this.options.release = release;
    this.options.environment = environment;
  }

  _createClass(ErrorHandler, [{
    key: "install",
    value: function install() {
      // Just In Case
      if (this.dsn && this.isOn) {
        this.installed = true;
        Raven.config(this.dsn, this.options).install();
      }
    }
  }, {
    key: "logIssue",
    value: function logIssue(message) {
      var tag = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      if (this.isOn && this.dsn) {
        if (!this.isInstalled) {
          this.install();
        }

        var tagParams = _objectSpread({
          environment: this.environment
        }, tag);

        Raven.captureMessage(message, {
          tag: tagParams
        });
      }
    }
  }, {
    key: "captureException",
    value: function captureException(error, extra) {
      if (this.isOn && this.dsn) {
        if (!this.isInstalled) {
          this.install();
        }

        Raven.captureException(error, extra);
      }
    }
  }, {
    key: "getRaven",
    value: function getRaven() {
      return Raven;
    }
  }]);

  return ErrorHandler;
}();

module.exports = ErrorHandler;

/***/ }),

/***/ "./react-next/utils/cookie-utils.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return parseCookieStr; });
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/* eslint-disable */
var parseCookieStr = function parseCookieStr(str) {
  var rtnObj = str.split('; ').reduce(function (prev, current) {
    var _current$split = current.split('='),
        _current$split2 = _slicedToArray(_current$split, 2),
        name = _current$split2[0],
        value = _current$split2[1];

    prev[name] = value;
    return prev;
  }, {});
  return rtnObj;
};



/***/ }),

/***/ "./services/services.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__env_config__ = __webpack_require__("./env-config.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__env_config___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__env_config__);

var livePath = {
  getAirports: 'v1/form/airport',
  createPackage: 'v1/package'
}; // All mocks

var mockPath = {
  getConfig: 'https://white-label-server.s3.amazonaws.com/mocks/config/config.json',
  getAirports: 'https://white-label-server.s3.amazonaws.com/mocks/getAirports/airports.json',
  createPackage: 'https://white-label-server.s3.amazonaws.com/mocks/package/createPackageId.json',
  getHotels: 'https://white-label-server.s3.amazonaws.com/mocks/package/index.json',
  getMapHotels: 'https://white-label-server.s3.amazonaws.com/mocks/package/getMapHotels.json',
  getHotelDetails: 'https://white-label-server.s3.amazonaws.com/hotel/{hotelId}',
  getHotelGallery: 'https://white-label-server.s3.amazonaws.com/getHotelGallery/index.json',
  getRooms: 'https://white-label-server.s3.amazonaws.com/package/{packageId}/{hotelid}',
  getDepartFlights: 'https://white-label-server.s3.amazonaws.com/package/{packageId}/{hotelid}/{roomid}',
  getReturnFlights: 'https://white-label-server.s3.amazonaws.com/package/{packageId}/{hotelid}/{roomid}/{flightid}',
  getSummaryDetails: 'https://white-label-server.s3.amazonaws.com/summary/{packageId}/{roomId}/{depatureFlightId}/{returnFlightId}',
  getTransfers: 'https://white-label-server.s3.amazonaws.com/transfers/{packageId}',
  getAddons: 'https://white-label-server.s3.amazonaws.com/addons/{packageId}',
  getBookingDetails: 'https://white-label-server.s3.amazonaws.com/booking/{packageId}',
  getPaymentDetails: 'https://white-label-server.s3.amazonaws.com/booking/{packageId}/gateways',
  makePayment: 'https://white-label-server.s3.amazonaws.com/booking/{packageId}/gateways',
  getBookingStatus: 'https://white-label-server.s3.amazonaws.com/confirmation/{bookingId}/status',
  getBookingConfirmationDetails: 'https://white-label-server.s3.amazonaws.com/confirmation/{bookingId}',
  updateTrackingStatus: 'https://white-label-server.s3.amazonaws.com/confirmation/{bookingId}/track'
}; // Temp solution because not all api is available yet

function getPath(key) {
  if (typeof livePath[key] !== 'undefined') {
    return __WEBPACK_IMPORTED_MODULE_0__env_config___default.a.getApiDomain + livePath[key];
  }

  return mockPath[key];
}

/* harmony default export */ __webpack_exports__["a"] = ({
  getConfig: "".concat(getPath('getConfig')),
  getAirports: "".concat(getPath('getAirports')),
  createPackage: "".concat(getPath('createPackage')),
  getHotels: "".concat(getPath('getHotels')),
  getMapHotels: "".concat(getPath('getMapHotels')),
  getHotelDetails: "".concat(getPath('getHotelDetails')),
  getHotelGallery: "".concat(getPath('getHotelGallery')),
  getRooms: "".concat(getPath('getRooms')),
  getDepartFlights: "".concat(getPath('getDepartFlights')),
  getReturnFlights: "".concat(getPath('getReturnFlights')),
  getSummaryDetails: "".concat(getPath('getSummaryDetails')),
  getTransfers: "".concat(getPath('getTransfers')),
  getAddons: "".concat(getPath('getAddons')),
  getBookingDetails: "".concat(getPath('getBookingDetails')),
  getPaymentDetails: "".concat(getPath('getPaymentDetails')),
  makePayment: "".concat(getPath('makePayment')),
  getBookingStatus: "".concat(getPath('getBookingStatus')),
  getBookingConfirmationDetails: "".concat(getPath('getBookingConfirmationDetails')),
  updateTrackingStatus: "".concat(getPath('updateTrackingStatus'))
});

/***/ }),

/***/ "./store/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export configureStore */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_redux__ = __webpack_require__("redux");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_redux___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_redux__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_redux_saga__ = __webpack_require__("redux-saga");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_redux_saga___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_redux_saga__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__reducers__ = __webpack_require__("./store/reducers.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__states__ = __webpack_require__("./store/states.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__saga__ = __webpack_require__("./store/saga.js");
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }






var sagaMiddleware = __WEBPACK_IMPORTED_MODULE_1_redux_saga___default()(); // After tested results:
// If reducer keys exist and no state keys it will have error
// If state keys exist and no reducer keys it will not have error
// Hence the following compare keys and set default state to {}

var stateKeys = Object.keys(__WEBPACK_IMPORTED_MODULE_3__states__);
var reducerKeys = Object.keys(__WEBPACK_IMPORTED_MODULE_2__reducers__);
reducerKeys.forEach(function (element) {
  if (!stateKeys.includes(element)) {
    __WEBPACK_IMPORTED_MODULE_3__states__[element] = {};
  }
});

var bindMiddleware = function bindMiddleware(middleware) {
  if (true) {
    // TODO: Check on unexpected require
    // Already check for development env
    // eslint-disable-next-line
    var _require = __webpack_require__("redux-devtools-extension"),
        composeWithDevTools = _require.composeWithDevTools;

    return composeWithDevTools(__WEBPACK_IMPORTED_MODULE_0_redux__["applyMiddleware"].apply(void 0, _toConsumableArray(middleware)));
  }

  return __WEBPACK_IMPORTED_MODULE_0_redux__["applyMiddleware"].apply(void 0, _toConsumableArray(middleware));
};

function configureStore() {
  var initialState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _objectSpread({}, __WEBPACK_IMPORTED_MODULE_3__states__);
  var store = Object(__WEBPACK_IMPORTED_MODULE_0_redux__["createStore"])(Object(__WEBPACK_IMPORTED_MODULE_0_redux__["combineReducers"])(_objectSpread({}, __WEBPACK_IMPORTED_MODULE_2__reducers__)), initialState, bindMiddleware([sagaMiddleware]));

  store.runSagaTask = function () {
    store.sagaTask = sagaMiddleware.run(__WEBPACK_IMPORTED_MODULE_4__saga__["a" /* default */]);
  };

  store.runSagaTask();
  return store;
}
/* harmony default export */ __webpack_exports__["a"] = (configureStore);

/***/ }),

/***/ "./store/modules/common/config/action-types.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
  SET_CONFIG: 'module/common/config/SET_CONFIG_REQUEST'
});

/***/ }),

/***/ "./store/modules/common/config/initial-state.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var state = {
  general: {
    name: 'Millennium Hotels',
    logo: 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/logo-default.png',
    favicon: '',
    primaryColor: '#429FAA',
    primaryColorHover: '#3B97A2',
    primaryColorText: '#fff',
    secondaryColor: '#B62234',
    secondaryColorHover: '#AF1C2E',
    secondaryColorText: '#fff',
    linkColor: '#B62234',
    linkColorHover: '#AF1C2E',
    currencies: ['MYR', 'USD', 'SGD', 'JPY'],
    defaultCurrency: 'MYR',
    languages: ['en-US', 'zh-HK'],
    defaultLanguage: 'en-US',
    backgroundImage: 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg',
    footerText: 'Copyright (c) 2018. <strong>bold text</strong> <a href="https://google.com">test link</a>',
    minBookingPeriod: 2,
    maxBookingPeriod: 30,
    minBookingDays: 2,
    maxBookingDays: 365,
    maxRooms: 3,
    maxPax: 9
  },
  features: {
    isFlightList: true,
    useTotalPrice: false
  },
  environment: {
    segmentId: '',
    hotelsApi: '',
    flightsApi: ''
  }
};
/* harmony default export */ __webpack_exports__["a"] = (state);

/***/ }),

/***/ "./store/modules/common/config/reducer.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__action_types__ = __webpack_require__("./store/modules/common/config/action-types.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__initial_state__ = __webpack_require__("./store/modules/common/config/initial-state.js");
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var reducer = function reducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : __WEBPACK_IMPORTED_MODULE_1__initial_state__["a" /* default */];
  var action = arguments.length > 1 ? arguments[1] : undefined;

  switch (action.type) {
    case __WEBPACK_IMPORTED_MODULE_0__action_types__["a" /* default */].SET_CONFIG:
      return _objectSpread({}, state, action.payload.config);

    default:
      return state;
  }
};

/* harmony default export */ __webpack_exports__["a"] = (reducer);

/***/ }),

/***/ "./store/modules/common/config/selectors.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getDefaultCurrencies; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return getDefaultCurrency; });
/* unused harmony export getLanguages */
/* unused harmony export getDefaultLanguage */
/* unused harmony export getGeneralConfig */
/* unused harmony export getConfig */
var getDefaultCurrencies = function getDefaultCurrencies(state) {
  return state.defaultConfig.general.currencies;
};
var getDefaultCurrency = function getDefaultCurrency(state) {
  return state.defaultConfig.general.defaultCurrency;
};
var getLanguages = function getLanguages(state) {
  return state.defaultConfig.general.languages;
};
var getDefaultLanguage = function getDefaultLanguage(state) {
  return state.defaultConfig.general.defaultLanguage;
};
var getGeneralConfig = function getGeneralConfig(state) {
  return state.defaultConfig.general;
};
var getConfig = function getConfig(state) {
  return state.defaultConfig;
};

/***/ }),

/***/ "./store/modules/currency-selection/action-types.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var actionTypes = {
  GET_SELECTED_CURRENCY_REQUEST: 'module/currency/GET_SELECTED_CURRENCY_REQUEST',
  GET_SELECTED_CURRENCY_SUCCESS: 'module/currency/GET_SELECTED_CURRENCY_SUCCESS',
  SELECT_CURRENCY: 'module/currency/SELECT_CURRENCY',
  SELECT_CURRENCY_FROM_URL_REQUEST: 'module/currency/SELECT_CURRENCY_FROM_URL_REQUEST',
  SELECT_CURRENCY_FROM_URL: 'module/currency/SELECT_CURRENCY_FROM_URL'
};
/* harmony default export */ __webpack_exports__["a"] = (actionTypes);

/***/ }),

/***/ "./store/modules/currency-selection/actions.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getClientSelectedCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return submitSelectedCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return submitSelectedCurrencyFromUrl; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__action_types__ = __webpack_require__("./store/modules/currency-selection/action-types.js");

var getClientSelectedCurrency = function getClientSelectedCurrency() {
  return {
    type: __WEBPACK_IMPORTED_MODULE_0__action_types__["a" /* default */].GET_SELECTED_CURRENCY_REQUEST
  };
};
var submitSelectedCurrency = function submitSelectedCurrency(currency) {
  return {
    type: __WEBPACK_IMPORTED_MODULE_0__action_types__["a" /* default */].GET_SELECTED_CURRENCY_SUCCESS,
    currency: currency
  };
};
var submitSelectedCurrencyFromUrl = function submitSelectedCurrencyFromUrl(currency) {
  return {
    type: __WEBPACK_IMPORTED_MODULE_0__action_types__["a" /* default */].SELECT_CURRENCY_FROM_URL,
    currency: currency
  };
};

/***/ }),

/***/ "./store/modules/currency-selection/initial-state.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var state = {
  selectedCurrency: ''
};
/* harmony default export */ __webpack_exports__["a"] = (state);

/***/ }),

/***/ "./store/modules/currency-selection/reducers.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_js_cookie__ = __webpack_require__("js-cookie");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_js_cookie___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_js_cookie__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__action_types__ = __webpack_require__("./store/modules/currency-selection/action-types.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__types__ = __webpack_require__("./store/modules/currency-selection/types.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__initial_state__ = __webpack_require__("./store/modules/currency-selection/initial-state.js");
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






var reducer = function reducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : __WEBPACK_IMPORTED_MODULE_3__initial_state__["a" /* default */];
  var action = arguments.length > 1 ? arguments[1] : undefined;

  switch (action.type) {
    case __WEBPACK_IMPORTED_MODULE_1__action_types__["a" /* default */].GET_SELECTED_CURRENCY_SUCCESS:
      try {
        __WEBPACK_IMPORTED_MODULE_0_js_cookie___default.a.set(__WEBPACK_IMPORTED_MODULE_2__types__["a" /* CK_SELECTED_CURRENCY */], action.currency);
      } catch (err) {
        console.log(err);
      }

      return _objectSpread({}, state, {
        selectedCurrency: action.currency
      });

    case __WEBPACK_IMPORTED_MODULE_1__action_types__["a" /* default */].SELECT_CURRENCY:
    case __WEBPACK_IMPORTED_MODULE_1__action_types__["a" /* default */].SELECT_CURRENCY_FROM_URL:
      try {
        __WEBPACK_IMPORTED_MODULE_0_js_cookie___default.a.set(__WEBPACK_IMPORTED_MODULE_2__types__["a" /* CK_SELECTED_CURRENCY */], action.currency);
      } catch (err) {
        console.log(err);
      }

      return _objectSpread({}, state, {
        selectedCurrency: action.currency
      });

    default:
      return state;
  }
};

/* harmony default export */ __webpack_exports__["a"] = (reducer);

/***/ }),

/***/ "./store/modules/currency-selection/saga.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = saga;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_js_cookie__ = __webpack_require__("js-cookie");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_js_cookie___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_js_cookie__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__ = __webpack_require__("redux-saga/effects");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_redux_saga_effects___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__react_next_utils_cookie_utils__ = __webpack_require__("./react-next/utils/cookie-utils.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__action_types__ = __webpack_require__("./store/modules/currency-selection/action-types.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__types__ = __webpack_require__("./store/modules/currency-selection/types.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__actions__ = __webpack_require__("./store/modules/currency-selection/actions.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__common_config_selectors__ = __webpack_require__("./store/modules/common/config/selectors.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__client_error__ = __webpack_require__("./client-error.js");


var _marked =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(getSelectedCurrency),
    _marked2 =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(selectCurrencyFromUrl),
    _marked3 =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(saga);









var Sentry = __WEBPACK_IMPORTED_MODULE_8__client_error__["a" /* default */].getInstance();

function getSelectedCurrency(_ref) {
  var payload, currency, cookie, parsedCookie, defaultCurrencies;
  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function getSelectedCurrency$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          payload = _ref.payload;
          _context.prev = 1;
          cookie = payload.cookie;

          if (cookie) {
            parsedCookie = Object(__WEBPACK_IMPORTED_MODULE_3__react_next_utils_cookie_utils__["a" /* parseCookieStr */])(cookie);
            currency = parsedCookie[__WEBPACK_IMPORTED_MODULE_5__types__["a" /* CK_SELECTED_CURRENCY */]] || '';
          } else {
            currency = __WEBPACK_IMPORTED_MODULE_1_js_cookie___default.a.get(__WEBPACK_IMPORTED_MODULE_5__types__["a" /* CK_SELECTED_CURRENCY */]) || '';
          }

          _context.next = 6;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["select"])(__WEBPACK_IMPORTED_MODULE_7__common_config_selectors__["a" /* getDefaultCurrencies */]);

        case 6:
          defaultCurrencies = _context.sent;

          if (!(defaultCurrencies.indexOf(currency) === -1)) {
            _context.next = 11;
            break;
          }

          _context.next = 10;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["select"])(__WEBPACK_IMPORTED_MODULE_7__common_config_selectors__["b" /* getDefaultCurrency */]);

        case 10:
          currency = _context.sent;

        case 11:
          _context.next = 13;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["b" /* submitSelectedCurrency */])(currency));

        case 13:
          _context.next = 18;
          break;

        case 15:
          _context.prev = 15;
          _context.t0 = _context["catch"](1);
          Sentry.captureException(_context.t0);

        case 18:
        case "end":
          return _context.stop();
      }
    }
  }, _marked, this, [[1, 15]]);
}

function selectCurrencyFromUrl(_ref2) {
  var payload, _currency, defaultCurrencies;

  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function selectCurrencyFromUrl$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          payload = _ref2.payload;
          _context2.prev = 1;
          _currency = payload.currency;
          _context2.next = 5;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["select"])(__WEBPACK_IMPORTED_MODULE_7__common_config_selectors__["a" /* getDefaultCurrencies */]);

        case 5:
          defaultCurrencies = _context2.sent;

          if (!(defaultCurrencies.indexOf(_currency) === -1)) {
            _context2.next = 11;
            break;
          }

          _context2.next = 9;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["a" /* getClientSelectedCurrency */])());

        case 9:
          _context2.next = 13;
          break;

        case 11:
          _context2.next = 13;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["put"])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["c" /* submitSelectedCurrencyFromUrl */])(_currency));

        case 13:
          _context2.next = 18;
          break;

        case 15:
          _context2.prev = 15;
          _context2.t0 = _context2["catch"](1);
          Sentry.captureException(_context2.t0);

        case 18:
        case "end":
          return _context2.stop();
      }
    }
  }, _marked2, this, [[1, 15]]);
}

function saga() {
  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function saga$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          _context3.next = 2;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["all"])([Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["takeLatest"], __WEBPACK_IMPORTED_MODULE_4__action_types__["a" /* default */].GET_SELECTED_CURRENCY_REQUEST, getSelectedCurrency), Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["takeLatest"], __WEBPACK_IMPORTED_MODULE_4__action_types__["a" /* default */].SELECT_CURRENCY_FROM_URL_REQUEST, selectCurrencyFromUrl)]);

        case 2:
        case "end":
          return _context3.stop();
      }
    }
  }, _marked3, this);
}

/***/ }),

/***/ "./store/modules/currency-selection/types.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CK_SELECTED_CURRENCY; });
var CK_SELECTED_CURRENCY = 'SELECTED_CURRENCY';

/***/ }),

/***/ "./store/modules/locale-selection/action-types.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var SET_CULTURE_CODE = 'modules/locale-selection/SET_CULTURE_CODE';
var GET_SELECTED_CULTURE_CODE = 'modules/locale-selection/GET_SELECTED_CULTURE_CODE';
/* harmony default export */ __webpack_exports__["a"] = ({
  SET_CULTURE_CODE: SET_CULTURE_CODE,
  GET_SELECTED_CULTURE_CODE: GET_SELECTED_CULTURE_CODE
});

/***/ }),

/***/ "./store/modules/locale-selection/initial-state.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var state = {
  cultureCode: 'en-US',
  urlLocale: ''
};
/* harmony default export */ __webpack_exports__["a"] = (state);

/***/ }),

/***/ "./store/modules/locale-selection/operations.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = getUrlLocale;
// eslint-disable-next-line
function getUrlLocale(locale, config) {
  // Note Second Condition is because locale en is a fallback for failed translation
  return (locale === config.general.defaultLanguage ? '' : "/".concat(locale)).toLowerCase();
}

/***/ }),

/***/ "./store/modules/locale-selection/reducers.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__action_types__ = __webpack_require__("./store/modules/locale-selection/action-types.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__initial_state__ = __webpack_require__("./store/modules/locale-selection/initial-state.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__operations__ = __webpack_require__("./store/modules/locale-selection/operations.js");
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// import { LSKEY_SELECTED_CULTURE_CODE } from './types';




var reducer = function reducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : __WEBPACK_IMPORTED_MODULE_1__initial_state__["a" /* default */];
  var action = arguments.length > 1 ? arguments[1] : undefined;

  switch (action.type) {
    case __WEBPACK_IMPORTED_MODULE_0__action_types__["a" /* default */].SET_CULTURE_CODE:
      // TODO: need a last selected culture handling
      return _objectSpread({}, state, {
        cultureCode: action.payload.locale,
        urlLocale: Object(__WEBPACK_IMPORTED_MODULE_2__operations__["a" /* getUrlLocale */])(action.payload.locale, action.payload.config)
      });

    default:
      return state;
  }
};

/* harmony default export */ __webpack_exports__["a"] = (reducer);

/***/ }),

/***/ "./store/modules/locale-selection/selectors.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getCultureCode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return getUrlLocale; });
var getCultureCode = function getCultureCode(state) {
  return state.moduleLocaleSelection.cultureCode;
};
var getUrlLocale = function getUrlLocale(state) {
  return state.moduleLocaleSelection.urlLocale;
};

/***/ }),

/***/ "./store/reducers.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__pages_Home_reducers__ = __webpack_require__("./pages/Home/reducers.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "home", function() { return __WEBPACK_IMPORTED_MODULE_0__pages_Home_reducers__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__pages_HotelDetail_reducers__ = __webpack_require__("./pages/HotelDetail/reducers.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "hotelDetail", function() { return __WEBPACK_IMPORTED_MODULE_1__pages_HotelDetail_reducers__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__pages_HotelResults_reducers__ = __webpack_require__("./pages/HotelResults/reducers.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "hotelResults", function() { return __WEBPACK_IMPORTED_MODULE_2__pages_HotelResults_reducers__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__pages_sample_reducers__ = __webpack_require__("./pages/sample/reducers.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "sample", function() { return __WEBPACK_IMPORTED_MODULE_3__pages_sample_reducers__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__modules_common_config_reducer__ = __webpack_require__("./store/modules/common/config/reducer.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "defaultConfig", function() { return __WEBPACK_IMPORTED_MODULE_4__modules_common_config_reducer__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__components_SearchForm_reducers__ = __webpack_require__("./components/SearchForm/reducers.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "searchForm", function() { return __WEBPACK_IMPORTED_MODULE_5__components_SearchForm_reducers__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__modules_currency_selection_reducers__ = __webpack_require__("./store/modules/currency-selection/reducers.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "moduleCurrencySelection", function() { return __WEBPACK_IMPORTED_MODULE_6__modules_currency_selection_reducers__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__modules_locale_selection_reducers__ = __webpack_require__("./store/modules/locale-selection/reducers.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "moduleLocaleSelection", function() { return __WEBPACK_IMPORTED_MODULE_7__modules_locale_selection_reducers__["a"]; });
// TODO: A Tool to detect all reducers and generate this file







 // Add Other Reducers Here

/***/ }),

/***/ "./store/saga.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__ = __webpack_require__("redux-saga/effects");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_redux_saga_effects___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_es6_promise__ = __webpack_require__("es6-promise");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_es6_promise___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_es6_promise__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__pages_Home_homeSaga__ = __webpack_require__("./pages/Home/homeSaga.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__pages_HotelDetail_hotelDetailSaga__ = __webpack_require__("./pages/HotelDetail/hotelDetailSaga.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__pages_sample3_saga__ = __webpack_require__("./pages/sample3/saga.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__pages_HotelResults_hotelResultSaga__ = __webpack_require__("./pages/HotelResults/hotelResultSaga.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_SearchForm_searchFormSaga__ = __webpack_require__("./components/SearchForm/searchFormSaga.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__modules_currency_selection_saga__ = __webpack_require__("./store/modules/currency-selection/saga.js");


var _marked =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(rootSaga);

/**
 * global fetch from all components' saga
 */

 // TODO: Research on Auto Import







__WEBPACK_IMPORTED_MODULE_2_es6_promise___default.a.polyfill();

function rootSaga() {
  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function rootSaga$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          _context.next = 2;
          return Object(__WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__["all"])([Object(__WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_3__pages_Home_homeSaga__["a" /* default */]), Object(__WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_8__modules_currency_selection_saga__["a" /* default */]), Object(__WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_5__pages_sample3_saga__["a" /* default */]), Object(__WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_4__pages_HotelDetail_hotelDetailSaga__["a" /* default */]), Object(__WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_7__components_SearchForm_searchFormSaga__["a" /* default */]), Object(__WEBPACK_IMPORTED_MODULE_1_redux_saga_effects__["fork"])(__WEBPACK_IMPORTED_MODULE_6__pages_HotelResults_hotelResultSaga__["a" /* default */])]);

        case 2:
        case "end":
          return _context.stop();
      }
    }
  }, _marked, this);
}

/* harmony default export */ __webpack_exports__["a"] = (rootSaga);

/***/ }),

/***/ "./store/states.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__pages_Home_initial_state__ = __webpack_require__("./pages/Home/initial-state.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "home", function() { return __WEBPACK_IMPORTED_MODULE_0__pages_Home_initial_state__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__pages_HotelDetail_initial_state__ = __webpack_require__("./pages/HotelDetail/initial-state.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "hotelDetail", function() { return __WEBPACK_IMPORTED_MODULE_1__pages_HotelDetail_initial_state__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__pages_HotelResults_initial_state__ = __webpack_require__("./pages/HotelResults/initial-state.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "hotelResults", function() { return __WEBPACK_IMPORTED_MODULE_2__pages_HotelResults_initial_state__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__pages_sample_initial_state__ = __webpack_require__("./pages/sample/initial-state.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "sample", function() { return __WEBPACK_IMPORTED_MODULE_3__pages_sample_initial_state__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components_SearchForm_reducers__ = __webpack_require__("./components/SearchForm/reducers.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "searchForm", function() { return __WEBPACK_IMPORTED_MODULE_4__components_SearchForm_reducers__["b"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__modules_common_config_initial_state__ = __webpack_require__("./store/modules/common/config/initial-state.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "defaultConfig", function() { return __WEBPACK_IMPORTED_MODULE_5__modules_common_config_initial_state__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__modules_currency_selection_initial_state__ = __webpack_require__("./store/modules/currency-selection/initial-state.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "moduleCurrencySelection", function() { return __WEBPACK_IMPORTED_MODULE_6__modules_currency_selection_initial_state__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__modules_locale_selection_initial_state__ = __webpack_require__("./store/modules/locale-selection/initial-state.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "moduleLocaleSelection", function() { return __WEBPACK_IMPORTED_MODULE_7__modules_locale_selection_initial_state__["a"]; });
// This will be the standard format all states will be  using through reducers









/***/ }),

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("./pages/_app.jsx");


/***/ }),

/***/ "@babel/runtime/regenerator":
/***/ (function(module, exports) {

module.exports = require("@babel/runtime/regenerator");

/***/ }),

/***/ "axios":
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ }),

/***/ "es6-promise":
/***/ (function(module, exports) {

module.exports = require("es6-promise");

/***/ }),

/***/ "ip":
/***/ (function(module, exports) {

module.exports = require("ip");

/***/ }),

/***/ "js-cookie":
/***/ (function(module, exports) {

module.exports = require("js-cookie");

/***/ }),

/***/ "next-redux-saga":
/***/ (function(module, exports) {

module.exports = require("next-redux-saga");

/***/ }),

/***/ "next-redux-wrapper":
/***/ (function(module, exports) {

module.exports = require("next-redux-wrapper");

/***/ }),

/***/ "next/app":
/***/ (function(module, exports) {

module.exports = require("next/app");

/***/ }),

/***/ "raven-js":
/***/ (function(module, exports) {

module.exports = require("raven-js");

/***/ }),

/***/ "react":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-addons-update":
/***/ (function(module, exports) {

module.exports = require("react-addons-update");

/***/ }),

/***/ "react-redux":
/***/ (function(module, exports) {

module.exports = require("react-redux");

/***/ }),

/***/ "redux":
/***/ (function(module, exports) {

module.exports = require("redux");

/***/ }),

/***/ "redux-devtools-extension":
/***/ (function(module, exports) {

module.exports = require("redux-devtools-extension");

/***/ }),

/***/ "redux-saga":
/***/ (function(module, exports) {

module.exports = require("redux-saga");

/***/ }),

/***/ "redux-saga/effects":
/***/ (function(module, exports) {

module.exports = require("redux-saga/effects");

/***/ })

/******/ });
//# sourceMappingURL=_app.js.map