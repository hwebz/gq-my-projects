module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./pages/_document.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return WhiteLabel; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_document__ = __webpack_require__("next/document");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_document___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_next_document__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_jsx_server__ = __webpack_require__("styled-jsx/server");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_jsx_server___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_styled_jsx_server__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_helmet__ = __webpack_require__("react-helmet");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_helmet___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_helmet__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_react_intl_locale_data_en__ = __webpack_require__("react-intl/locale-data/en");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_react_intl_locale_data_en___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_react_intl_locale_data_en__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__react_next_utils_intl_utils__ = __webpack_require__("./react-next/utils/intl-utils.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__react_next_utils_intl_utils___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6__react_next_utils_intl_utils__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__scss_main_scss__ = __webpack_require__("./scss/main.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__scss_main_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__scss_main_scss__);

var _jsxFileName = "C:\\Projects\\frontend\\pages\\_document.jsx";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return _get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }


/*
In production the stylesheet is compiled to .next/static/style.css.
The file will be served from /_next/static/style.css
You could include it into the page using either next/head or a custom _document.js.
*/








var WhiteLabel =
/*#__PURE__*/
function (_Document) {
  _inherits(WhiteLabel, _Document);

  function WhiteLabel() {
    _classCallCheck(this, WhiteLabel);

    return _possibleConstructorReturn(this, (WhiteLabel.__proto__ || Object.getPrototypeOf(WhiteLabel)).apply(this, arguments));
  }

  _createClass(WhiteLabel, [{
    key: "render",
    value: function render() {
      var _props = this.props,
          locale = _props.locale,
          localeDataScript = _props.localeDataScript;
      var polyfill = "https://cdn.polyfill.io/v2/polyfill.min.js?features=Intl.~locale.".concat(__WEBPACK_IMPORTED_MODULE_6__react_next_utils_intl_utils___default.a.cultureCodeToISO(locale));
      var style = __WEBPACK_IMPORTED_MODULE_3_styled_jsx_server___default()(); // SSR styles

      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("html", _extends({
        lang: locale
      }, this.helmetHtmlAttrComponents, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 66
        }
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_next_document__["Head"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 67
        }
      }, this.helmetJsx, this.helmetHeadComponents, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("meta", {
        name: "viewport",
        content: "width=device-width, initial-scale=1",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 70
        }
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("link", {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css?family=Lato:300,400,700,900",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 71
        }
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("link", {
        rel: "stylesheet",
        href: "/_next/static/style.css",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 72
        }
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("link", {
        href: "https://api.tiles.mapbox.com/mapbox-gl-js/v0.48.0/mapbox-gl.css",
        rel: "stylesheet",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 73
        }
      }), style), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("body", _extends({}, this.helmetBodyAttrComponents, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 77
        }
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_next_document__["Main"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 78
        }
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("script", {
        src: polyfill,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 79
        }
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("script", {
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML: {
          __html: localeDataScript
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 80
        }
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_next_document__["NextScript"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 86
        }
      })));
    }
  }, {
    key: "helmetHtmlAttrComponents",
    // should render on <html>
    get: function get() {
      return this.props.helmet.htmlAttributes.toComponent();
    } // should render on <body>

  }, {
    key: "helmetBodyAttrComponents",
    get: function get() {
      return this.props.helmet.bodyAttributes.toComponent();
    } // should render on <head>

  }, {
    key: "helmetHeadComponents",
    get: function get() {
      var _this = this;

      return Object.keys(this.props.helmet).filter(function (el) {
        return el !== 'htmlAttributes' && el !== 'bodyAttributes';
      }).map(function (el) {
        return _this.props.helmet[el].toComponent();
      });
    } // eslint-disable-next-line class-methods-use-this

  }, {
    key: "helmetJsx",
    get: function get() {
      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_helmet___default.a, {
        title: "Welcome",
        meta: [{
          name: 'description',
          content: 'Book a package'
        }],
        __source: {
          fileName: _jsxFileName,
          lineNumber: 52
        }
      });
    }
  }], [{
    key: "getInitialProps",
    value: function () {
      var _getInitialProps = _asyncToGenerator(
      /*#__PURE__*/
      __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee(context) {
        var props, _context$req, locale, localeDataScript;

        return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _get(WhiteLabel.__proto__ || Object.getPrototypeOf(WhiteLabel), "getInitialProps", this).call(this, context);

              case 2:
                props = _context.sent;
                _context$req = context.req, locale = _context$req.locale, localeDataScript = _context$req.localeDataScript;

                if (!locale || !localeDataScript) {
                  locale = 'en-US';
                  localeDataScript = __WEBPACK_IMPORTED_MODULE_5_react_intl_locale_data_en___default.a;
                }

                return _context.abrupt("return", _objectSpread({}, props, {
                  locale: locale,
                  localeDataScript: localeDataScript,
                  helmet: __WEBPACK_IMPORTED_MODULE_4_react_helmet___default.a.renderStatic()
                }));

              case 6:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      return function getInitialProps(_x) {
        return _getInitialProps.apply(this, arguments);
      };
    }()
  }]);

  return WhiteLabel;
}(__WEBPACK_IMPORTED_MODULE_2_next_document___default.a);



/***/ }),

/***/ "./react-next/utils/intl-utils.js":
/***/ (function(module, exports) {

var IntlUtils = {};

IntlUtils.getUrlLocale = function (locales, path) {
  // TODO: change to baseurl + /locale path check
  var url = path.toLowerCase();

  for (var i = 0; i < locales.length; i++) {
    if (url.indexOf(locales[i].toLowerCase()) === 1) {
      return locales[i];
    }
  }

  return '';
};

IntlUtils.cultureCodeToISO = function (cultureCode) {
  var culture = cultureCode.split('-')[1];

  if (['zh-tw', 'zh-hk', 'zh-mo'].includes(cultureCode.toLowerCase())) {
    return "zh-Hant-".concat(culture);
  } // other chinese


  if (cultureCode.split('-')[0] === 'zh') {
    return "zh-Hans-".concat(culture);
  }

  return cultureCode;
}; // Important Note: react-intl/locale-data/zh does not contain Hant-TW or Hans-CN
// So it is different from intl.js


IntlUtils.cultureCodeToReactLocale = function (cultureCode) {
  var culture = cultureCode.split('-')[1];

  if (['zh-hk', 'zh-mo'].includes(cultureCode.toLowerCase())) {
    return "zh-Hant-".concat(culture);
  }

  if (cultureCode.toLowerCase() === 'zh-SG') {
    return "zh-Hans-".concat(culture);
  }

  if (cultureCode.toLowerCase() === 'zh-TW') {
    return 'zh-Hant';
  }

  if (cultureCode.toLowerCase() === 'zh-CN') {
    return 'zh-Hans';
  }

  return cultureCode;
};

module.exports = IntlUtils;

/***/ }),

/***/ "./scss/main.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ 1:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("./pages/_document.jsx");


/***/ }),

/***/ "@babel/runtime/regenerator":
/***/ (function(module, exports) {

module.exports = require("@babel/runtime/regenerator");

/***/ }),

/***/ "next/document":
/***/ (function(module, exports) {

module.exports = require("next/document");

/***/ }),

/***/ "react":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-helmet":
/***/ (function(module, exports) {

module.exports = require("react-helmet");

/***/ }),

/***/ "react-intl/locale-data/en":
/***/ (function(module, exports) {

module.exports = require("react-intl/locale-data/en");

/***/ }),

/***/ "styled-jsx/server":
/***/ (function(module, exports) {

module.exports = require("styled-jsx/server");

/***/ })

/******/ });
//# sourceMappingURL=_document.js.map