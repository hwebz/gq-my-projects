module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded chunks
/******/ 	// "0" means "already loaded"
/******/ 	var installedChunks = {
/******/ 		7: 0
/******/ 	};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/ 	// This file contains only the entry chunk.
/******/ 	// The chunk loading function for additional chunks
/******/ 	__webpack_require__.e = function requireEnsure(chunkId) {
/******/ 		// "0" is the signal for "already loaded"
/******/ 		if(installedChunks[chunkId] !== 0) {
/******/ 			var chunk = require("../../" + ({"5":"chunks/pages_HotelResults_components_HotelResultMapItem_8f5b1a572c60660ba1a9a6cc7d217790","6":"chunks/pages_HotelResults_components_HotelResultMapItem_scss_22cff17f161923bf622b017b1d9e28fb"}[chunkId]||chunkId) + ".js");
/******/ 			var moreModules = chunk.modules, chunkIds = chunk.ids;
/******/ 			for(var moduleId in moreModules) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 			for(var i = 0; i < chunkIds.length; i++)
/******/ 				installedChunks[chunkIds[i]] = 0;
/******/ 		}
/******/ 		return require('next/dynamic').SameLoopPromise.resolve();
/******/ 	};
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// uncatched error handler for webpack runtime
/******/ 	__webpack_require__.oe = function(err) {
/******/ 		process.nextTick(function() {
/******/ 			throw err; // catch this error by using System.import().catch()
/******/ 		});
/******/ 	};
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./client-data.js":
/***/ (function(module, exports, __webpack_require__) {

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

// Note: Server Config is for API Path that should be hidden from client
var prod = "development" === 'production'; // TODO: Some variables here will be set by published environment variable
// This is created for easy access for environment variables with less human error

var ClientData =
/*#__PURE__*/
function () {
  function ClientData() {
    _classCallCheck(this, ClientData);
  }

  _createClass(ClientData, null, [{
    key: "IS_PRODUCTION",
    get: function get() {
      return "development" === 'production';
    }
  }, {
    key: "SENTRY_DSN",
    get: function get() {
      return 'https://22c5e2d624584ca1aa56dcb20b2de87a@sentry.io/1237747';
    }
  }, {
    key: "ENVIRONMENT",
    get: function get() {
      return "development";
    } // TODO: release version retrieved from a file overriden by auto-deployment

  }, {
    key: "RELEASE_VERSION",
    get: function get() {
      return '0.0.1';
    }
  }, {
    key: "API_PATH",
    get: function get() {
      // TODO Change to real api
      return process.env.API_ENV === 'development' ? 'http://white-label-server.s3.amazonaws.com' : 'http://white-label-server.s3.amazonaws.com';
    }
  }]);

  return ClientData;
}();

Object.defineProperty(ClientData, "SELECTED_CURRENCY", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: ''
});
module.exports = ClientData;

/***/ }),

/***/ "./client-error.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ClientErrorHandler; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ip__ = __webpack_require__("ip");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ip___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_ip__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__react_next_error__ = __webpack_require__("./react-next/error/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__react_next_error___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__react_next_error__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__client_data__ = __webpack_require__("./client-data.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__client_data___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__client_data__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return _get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// Note: it is important to seperate Client and Server Errors


 // TODO: Setting Error Mapping, haven't decide on the mapping object structure

var errorMap = new Map(); // Refer to sentry options here
// https://docs.sentry.io/clients/node/config/

var ClientErrorHandler =
/*#__PURE__*/
function (_ErrorHandler) {
  _inherits(ClientErrorHandler, _ErrorHandler);

  function ClientErrorHandler() {
    var _this;

    _classCallCheck(this, ClientErrorHandler);

    _this = _possibleConstructorReturn(this, (ClientErrorHandler.__proto__ || Object.getPrototypeOf(ClientErrorHandler)).call(this, __WEBPACK_IMPORTED_MODULE_2__client_data___default.a.SENTRY_DSN, __WEBPACK_IMPORTED_MODULE_2__client_data___default.a.ENVIRONMENT, __WEBPACK_IMPORTED_MODULE_2__client_data___default.a.RELEASE_VERSION, errorMap));
    _this.isOn = false;
    return _this;
  }

  _createClass(ClientErrorHandler, [{
    key: "install",
    value: function install() {
      _get(ClientErrorHandler.prototype.__proto__ || Object.getPrototypeOf(ClientErrorHandler.prototype), "install", this).call(this);

      if (this.dsn && this.isOn) {
        this.getRaven().setUserContext({
          ip_address: __WEBPACK_IMPORTED_MODULE_0_ip___default.a.address()
        });
      }
    }
  }], [{
    key: "getInstance",
    value: function getInstance() {
      if (!ClientErrorHandler._INSTANCE) {
        ClientErrorHandler._INSTANCE = new ClientErrorHandler();
      }

      return ClientErrorHandler._INSTANCE;
    }
  }]);

  return ClientErrorHandler;
}(__WEBPACK_IMPORTED_MODULE_1__react_next_error___default.a);



/***/ }),

/***/ "./components/Common/AlertMsgs/AlertMsg.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/Common/AlertMsgs/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__AlertMsg_scss__ = __webpack_require__("./components/Common/AlertMsgs/AlertMsg.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__AlertMsg_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__AlertMsg_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\Common\\AlertMsgs\\index.jsx";



var AlertMsg = function AlertMsg(_ref) {
  var msgType = _ref.msgType,
      msg = _ref.msg;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "alert alert__".concat(msgType),
    role: "alert",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 7
    }
  }, msg);
};

/* harmony default export */ __webpack_exports__["a"] = (AlertMsg);

/***/ }),

/***/ "./components/Common/Backdrop/Backdrop.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__backdrop_scss__ = __webpack_require__("./components/Common/Backdrop/backdrop.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__backdrop_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__backdrop_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\Common\\Backdrop\\Backdrop.jsx";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }




var Backdrop = function Backdrop(props) {
  var isOpen = props.isOpen,
      onClick = props.onClick,
      rest = _objectWithoutProperties(props, ["isOpen", "onClick"]);

  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", _extends({
    className: "popup-backdrop ".concat(isOpen ? 'open' : ''),
    onClick: onClick,
    role: "presentation"
  }, rest, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11
    }
  }));
};

/* harmony default export */ __webpack_exports__["a"] = (Backdrop);

/***/ }),

/***/ "./components/Common/Backdrop/backdrop.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/Common/Backdrop/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__Backdrop__ = __webpack_require__("./components/Common/Backdrop/Backdrop.jsx");

/* harmony default export */ __webpack_exports__["a"] = (__WEBPACK_IMPORTED_MODULE_0__Backdrop__["a" /* default */]);

/***/ }),

/***/ "./components/Common/DatePicker/_datepicker.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/Common/DatePicker/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux__ = __webpack_require__("react-redux");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_redux__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_day_picker__ = __webpack_require__("react-day-picker");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_day_picker___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_day_picker__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__store_modules_locale_selection_selectors__ = __webpack_require__("./store/modules/locale-selection/selectors.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__react_next_intl_date_locale__ = __webpack_require__("./react-next/intl/date-locale.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__datepicker_scss__ = __webpack_require__("./components/Common/DatePicker/_datepicker.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__datepicker_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__datepicker_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\Common\\DatePicker\\index.jsx";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }



 // TODO: use index.js to wrap as one module with selectors actionTypes and etc.
// import actionTypes from '../../../modules/locale-selection/action-types';





var DatePicker =
/*#__PURE__*/
function (_React$Component) {
  _inherits(DatePicker, _React$Component);

  function DatePicker() {
    _classCallCheck(this, DatePicker);

    return _possibleConstructorReturn(this, (DatePicker.__proto__ || Object.getPrototypeOf(DatePicker)).apply(this, arguments));
  }

  _createClass(DatePicker, [{
    key: "componentWillMount",
    value: function componentWillMount() {// const { dispatch } = this.props;
      // dispatch({ type: actionTypes.GET_SELECTED_CULTURE_CODE });
    }
  }, {
    key: "render",
    value: function render() {
      var _props = this.props,
          selectedCultureCode = _props.selectedCultureCode,
          changeYear = _props.changeYear,
          changedMonth = _props.changedMonth,
          changed = _props.changed,
          selected = _props.selected,
          minStartDay = _props.minStartDay,
          maxStartDay = _props.maxStartDay;
      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_day_picker___default.a, {
        locale: selectedCultureCode ? selectedCultureCode : 'en-US',
        localeUtils: __WEBPACK_IMPORTED_MODULE_4__react_next_intl_date_locale__["a" /* dayPickerLocaleUtils */],
        month: new Date(changeYear, changedMonth),
        onDayClick: changed,
        selectedDays: [new Date(selected)],
        disabledDays: [{
          before: new Date(minStartDay),
          after: new Date(maxStartDay)
        }],
        __source: {
          fileName: _jsxFileName,
          lineNumber: 29
        }
      });
    }
  }]);

  return DatePicker;
}(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Component);

;

var mapStateToProps = function mapStateToProps(state) {
  return {
    selectedCultureCode: Object(__WEBPACK_IMPORTED_MODULE_3__store_modules_locale_selection_selectors__["a" /* getCultureCode */])(state)
  };
};

/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_1_react_redux__["connect"])(mapStateToProps)(DatePicker));

/***/ }),

/***/ "./components/Common/Gallery/gallery.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/Common/Gallery/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_overlays_lib_Modal__ = __webpack_require__("react-overlays/lib/Modal");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_overlays_lib_Modal___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_overlays_lib_Modal__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_image_gallery__ = __webpack_require__("react-image-gallery");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_image_gallery___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_image_gallery__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_image_gallery_styles_css_image_gallery_css__ = __webpack_require__("./node_modules/react-image-gallery/styles/css/image-gallery.css");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_image_gallery_styles_css_image_gallery_css___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_image_gallery_styles_css_image_gallery_css__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_md__ = __webpack_require__("react-icons/md");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_md___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_icons_md__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__gallery_scss__ = __webpack_require__("./components/Common/Gallery/gallery.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__gallery_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__gallery_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\Common\\Gallery\\index.jsx";






/* harmony default export */ __webpack_exports__["a"] = (function (_ref) {
  var galleryItems = _ref.galleryItems,
      handleToggleGallery = _ref.handleToggleGallery,
      isGalleryOpen = _ref.isGalleryOpen;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_overlays_lib_Modal___default.a, {
    className: "gallery",
    show: isGalleryOpen,
    onBackdropClick: function onBackdropClick(e) {
      handleToggleGallery(e, true);
    },
    onEscapeKeyDown: function onEscapeKeyDown(e) {
      handleToggleGallery(e, false);
    },
    backdropClassName: "gallery__backdrop",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 17
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "gallery__container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    className: "gallery__close",
    onClick: function onClick(e) {
      handleToggleGallery(e, false);
    },
    onKeyPress: function onKeyPress(e) {
      handleToggleGallery(e, false);
    },
    role: "button",
    tabIndex: 0,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_icons_md__["MdClose"], {
    size: 30,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    }
  })), galleryItems.length > 0 && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_image_gallery___default.a, {
    items: galleryItems,
    showPlayButton: false,
    showIndex: true,
    showFullscreenButton: false,
    additionalClass: "gallery__item",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    }
  }) || __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("p", {
    className: "gallery__loading",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    }
  }, "Loading...")));
});

/***/ }),

/***/ "./components/Common/Spinner/Spinner.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/Common/Spinner/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Spinner_scss__ = __webpack_require__("./components/Common/Spinner/Spinner.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Spinner_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__Spinner_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\Common\\Spinner\\index.jsx";



var Spinner = function Spinner() {
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "spinnerContainer",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 7
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "spinner",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 8
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 9
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 10
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11
    }
  })));
};

/* harmony default export */ __webpack_exports__["a"] = (Spinner);

/***/ }),

/***/ "./components/CurrenciesSwitcher/CurrenciesSwitcher.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/CurrenciesSwitcher/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux__ = __webpack_require__("react-redux");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_redux__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_query_string__ = __webpack_require__("query-string");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_query_string___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_query_string__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__CurrenciesSwitcher_scss__ = __webpack_require__("./components/CurrenciesSwitcher/CurrenciesSwitcher.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__CurrenciesSwitcher_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__CurrenciesSwitcher_scss__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_fa___ = __webpack_require__("react-icons/fa/");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_fa____default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_icons_fa___);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__Common_Backdrop__ = __webpack_require__("./components/Common/Backdrop/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__react_next_intl_currency_names__ = __webpack_require__("./react-next/intl/currency-names.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__react_next_intl_currency_symbols__ = __webpack_require__("./react-next/intl/currency-symbols.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__store_modules_currency_selection_action_types__ = __webpack_require__("./store/modules/currency-selection/action-types.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__store_modules_currency_selection_selectors__ = __webpack_require__("./store/modules/currency-selection/selectors.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__store_modules_locale_selection_selectors__ = __webpack_require__("./store/modules/locale-selection/selectors.js");
var _jsxFileName = "C:\\Projects\\frontend\\components\\CurrenciesSwitcher\\index.jsx";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }













var CurrenciesSwitcher =
/*#__PURE__*/
function (_React$Component) {
  _inherits(CurrenciesSwitcher, _React$Component);

  function CurrenciesSwitcher(props) {
    var _this;

    _classCallCheck(this, CurrenciesSwitcher);

    _this = _possibleConstructorReturn(this, (CurrenciesSwitcher.__proto__ || Object.getPrototypeOf(CurrenciesSwitcher)).call(this, props));
    _this.state = {
      isCurrencyOpen: false
    };
    _this.triggerCurrencyDropdown = _this.triggerCurrencyDropdown.bind(_assertThisInitialized(_this));
    _this.selectCurrency = _this.selectCurrency.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(CurrenciesSwitcher, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      /*// No Longer Needed
      const { dispatch } = this.props;
      if (typeof window !== 'undefined') {
        const parsed = queryString.parse(window.location.search);
        const { currency } = parsed;
        if (currency) {
          dispatch({ type: actionTypes.SELECT_CURRENCY_FROM_URL_REQUEST, payload: { currency } });
        }
      }
      /*/
    }
  }, {
    key: "triggerCurrencyDropdown",
    value: function triggerCurrencyDropdown() {
      var isCurrencyOpen = this.state.isCurrencyOpen;
      this.setState({
        isCurrencyOpen: !isCurrencyOpen
      });
    }
  }, {
    key: "selectCurrency",
    value: function selectCurrency(currency) {
      var dispatch = this.props.dispatch;
      dispatch({
        type: __WEBPACK_IMPORTED_MODULE_8__store_modules_currency_selection_action_types__["a" /* default */].SELECT_CURRENCY,
        currency: currency
      });
      this.setState({
        isCurrencyOpen: false
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var isCurrencyOpen = this.state.isCurrencyOpen;
      var _props = this.props,
          currencies = _props.currencies,
          selectedCurrency = _props.selectedCurrency,
          selectedLanguage = _props.selectedLanguage;
      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "dropdown-list dropdown-list--currency ".concat(isCurrencyOpen ? 'is-open' : ''),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 64
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "dropdown-list__button",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 65
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("button", {
        type: "button",
        className: "link",
        title: "Change currency",
        onClick: this.triggerCurrencyDropdown,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 66
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("strong", {
        className: "link__text",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 67
        }
      }, selectedCurrency), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_icons_fa___["FaCaretDown"], {
        className: "link__fa-icon",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 70
        }
      }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "dropdown-list__popup",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 73
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("ul", {
        className: "dropdown-list__listing",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 74
        }
      }, currencies.map(function (cr) {
        return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("li", {
          className: "dropdown-list__item ".concat(cr === selectedCurrency ? 'is-active' : ''),
          key: cr,
          onClick: function onClick() {
            return _this2.selectCurrency(cr);
          },
          role: "presentation",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 76
          }
        }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
          className: "dropdown-list__currency dropdown-list__currency--text",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 77
          }
        }, cr), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
          className: "dropdown-list__currency dropdown-list__currency--desc",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 80
          }
        }, Object(__WEBPACK_IMPORTED_MODULE_6__react_next_intl_currency_names__["a" /* default */])(selectedLanguage, cr)), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
          className: "dropdown-list__currency dropdown-list__currency--sign",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 83
          }
        }, Object(__WEBPACK_IMPORTED_MODULE_7__react_next_intl_currency_symbols__["a" /* getCurrencySymbol */])(cr)));
      }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__Common_Backdrop__["a" /* default */], {
        isOpen: isCurrencyOpen,
        onClick: this.triggerCurrencyDropdown,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 90
        }
      }));
    }
  }]);

  return CurrenciesSwitcher;
}(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Component);

var mapStateToProps = function mapStateToProps(state) {
  return {
    selectedLanguage: Object(__WEBPACK_IMPORTED_MODULE_10__store_modules_locale_selection_selectors__["a" /* getCultureCode */])(state),
    selectedCurrency: Object(__WEBPACK_IMPORTED_MODULE_9__store_modules_currency_selection_selectors__["a" /* getSelectedCurrency */])(state)
  };
};

/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_1_react_redux__["connect"])(mapStateToProps)(CurrenciesSwitcher));

/***/ }),

/***/ "./components/DateFormat/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = DateFormat;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_date_fns__ = __webpack_require__("date-fns");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_date_fns___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_date_fns__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__react_next_intl_date_locale__ = __webpack_require__("./react-next/intl/date-locale.js");
var _jsxFileName = "C:\\Projects\\frontend\\components\\DateFormat\\index.jsx";



function DateFormat(props) {
  // dddd
  // value format is always so YYYY-MM-DD
  var value = props.value,
      format = props.format,
      locale = props.locale;
  var values = value.split('-');

  if (values.length !== 3) {
    return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 18
      }
    }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("b", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 19
      }
    }, "Invalid Date Value"));
  }

  var year = parseInt(values[0], 10);
  var month = parseInt(values[1], 10) - 1;
  var day = parseInt(values[2], 10);
  var date = new Date(year, month, day);
  var dateString = Object(__WEBPACK_IMPORTED_MODULE_2__react_next_intl_date_locale__["b" /* formatDateString */])(date, format, locale); // If no date format then use default Intl

  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    }
  }, "".concat(dateString));
}

/***/ }),

/***/ "./components/FilterBars/FilterBars.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_md__ = __webpack_require__("react-icons/md");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_md___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_icons_md__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_input_range__ = __webpack_require__("react-input-range");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_input_range___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_input_range__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__FilterStar__ = __webpack_require__("./components/FilterBars/FilterStar.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__FilterRating__ = __webpack_require__("./components/FilterBars/FilterRating.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__FilterSearch__ = __webpack_require__("./components/FilterBars/FilterSearch.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__Common_Backdrop__ = __webpack_require__("./components/Common/Backdrop/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__FilterBars_scss__ = __webpack_require__("./components/FilterBars/FilterBars.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__FilterBars_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__FilterBars_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\FilterBars\\FilterBars.jsx";


 // import FilterPrice from './FilterPrice';







var FilterBars = function FilterBars(_ref) {
  var currency = _ref.currency,
      isDisabled = _ref.isDisabled,
      handleOpenDropdown = _ref.handleOpenDropdown,
      openDropdownClass = _ref.openDropdownClass,
      maxPrice = _ref.maxPrice,
      filters = _ref.filters,
      handleChangeFilter = _ref.handleChangeFilter,
      handleInputRangeOnChange = _ref.handleInputRangeOnChange,
      handleOpenMobileItem = _ref.handleOpenMobileItem,
      openMobileItemClass = _ref.openMobileItemClass;
  var rating = filters ? filters.minReview : 0;
  var disableClass = isDisabled ? 'disable-filters' : '';
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar panelMobile FilterBar--main ".concat(openMobileItemClass === 'navbar-filter' ? 'is-open' : ''),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "panelMobile__title",
    onClick: function onClick(e) {
      handleOpenMobileItem(e, '');
    },
    onKeyDown: function onKeyDown(e) {
      handleOpenMobileItem(e, '');
    },
    role: "menuitem",
    tabIndex: "0",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_icons_md__["MdArrowBack"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("strong", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    }
  }, "Filter")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__title",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    }
  }, "Filter")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__wrap FilterBar__wrap--filter",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "".concat(disableClass, " FilterBar__box FilterBar__box--price"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__name",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    }
  }, "Price")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__content",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 57
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_input_range___default.a, {
    formatLabel: function formatLabel(value) {
      return "".concat(currency || '', " ").concat(value);
    },
    maxValue: maxPrice || 11,
    minValue: 0,
    value: filters ? filters.maxPrice : 0,
    disabled: !(filters && !isDisabled),
    onChange: function onChange(value) {
      handleChangeFilter({
        key: 'maxPrice',
        value: value
      });
    },
    onChangeComplete: function onChangeComplete(value) {
      handleInputRangeOnChange(value);
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58
    }
  }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "".concat(disableClass, " FilterBar__box FilterBar__box--star"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 69
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__name",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 70
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 71
    }
  }, "Stars")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__content",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 75
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__FilterStar__["a" /* default */], {
    isDisabled: isDisabled,
    filters: filters,
    handleChangeFilter: handleChangeFilter,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 76
    }
  }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "".concat(disableClass, " FilterBar__box FilterBar__box--rating"),
    onClick: function onClick(e) {
      handleOpenDropdown(e, 'is-open', isDisabled);
    },
    onKeyDown: function onKeyDown(e) {
      handleOpenDropdown(e, 'is-open', isDisabled);
    },
    role: "button",
    tabIndex: "0",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 83
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__name",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 90
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 91
    }
  }, "User Rating")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__content",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 95
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__FilterRating__["a" /* default */], {
    isDisabled: isDisabled,
    filters: filters,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 96
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__dropdown ".concat(openDropdownClass),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 97
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__list",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 98
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__list__item  ".concat(rating === 86 ? 'FilterBar__list__item--current' : ''),
    onClick: function onClick() {
      handleChangeFilter({
        key: 'minReview',
        value: 86
      });
    },
    onKeyDown: function onKeyDown() {
      handleChangeFilter({
        key: 'minReview',
        value: 86
      });
    },
    role: "menuitem",
    tabIndex: "0",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 99
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("label", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 106
    }
  }, "8.6+"), "Excellent"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__list__item  ".concat(rating === 80 ? 'FilterBar__list__item--current' : ''),
    onClick: function onClick() {
      handleChangeFilter({
        key: 'minReview',
        value: 80
      });
    },
    onKeyDown: function onKeyDown() {
      handleChangeFilter({
        key: 'minReview',
        value: 80
      });
    },
    role: "menuitem",
    tabIndex: "0",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 111
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("label", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 118
    }
  }, "8.0+"), "Very Good"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__list__item  ".concat(rating === 75 ? 'FilterBar__list__item--current' : ''),
    onClick: function onClick() {
      handleChangeFilter({
        key: 'minReview',
        value: 75
      });
    },
    onKeyDown: function onKeyDown() {
      handleChangeFilter({
        key: 'minReview',
        value: 75
      });
    },
    role: "menuitem",
    tabIndex: "0",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 123
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("label", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 130
    }
  }, "7.5+"), "Good"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__list__item  ".concat(rating === 68 ? 'FilterBar__list__item--current' : ''),
    onClick: function onClick() {
      handleChangeFilter({
        key: 'minReview',
        value: 68
      });
    },
    onKeyDown: function onKeyDown() {
      handleChangeFilter({
        key: 'minReview',
        value: 68
      });
    },
    role: "menuitem",
    tabIndex: "0",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 135
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("label", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 142
    }
  }, "6.8+"), "Fair"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__list__item  ".concat(rating === 0 ? 'FilterBar__list__item--current' : ''),
    onClick: function onClick() {
      handleChangeFilter({
        key: 'minReview',
        value: 0
      });
    },
    onKeyDown: function onKeyDown() {
      handleChangeFilter({
        key: 'minReview',
        value: 0
      });
    },
    role: "menuitem",
    tabIndex: "0",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 147
    }
  }, "Show All"))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__Common_Backdrop__["a" /* default */], {
    isOpen: openDropdownClass ? true : false,
    onClick: function onClick(e) {
      handleOpenDropdown(e, '');
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 158
    }
  }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "".concat(disableClass, " FilterBar__box FilterBar__box--search"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 161
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__content",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 162
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__FilterSearch__["a" /* default */], {
    isDisabled: isDisabled,
    filters: filters,
    handleChangeFilter: handleChangeFilter,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 163
    }
  })))))));
};

/* harmony default export */ __webpack_exports__["a"] = (FilterBars);

/***/ }),

/***/ "./components/FilterBars/FilterBars.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/FilterBars/FilterRating.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__FilterRating_scss__ = __webpack_require__("./components/FilterBars/FilterRating.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__FilterRating_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__FilterRating_scss__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_icons_io__ = __webpack_require__("react-icons/io");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_icons_io___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_icons_io__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\FilterBars\\FilterRating.jsx";




var FilterRating = function FilterRating(_ref) {
  var filters = _ref.filters;
  var rating = filters ? filters.minReview : '';
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterRating",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 10
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterRating__selected",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterRating__item",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 12
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "reviewRating",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "reviewRating__detail",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14
    }
  }, rating > 0 && "".concat(parseFloat(rating / 10).toFixed(1), "+") || 'All'))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterRating__caret",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_icons_io__["IoMdArrowDropdown"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    }
  })))));
};

/* harmony default export */ __webpack_exports__["a"] = (FilterRating);

/***/ }),

/***/ "./components/FilterBars/FilterRating.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/FilterBars/FilterSearch.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_io__ = __webpack_require__("react-icons/io");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_io___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_icons_io__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__FilterSearch_scss__ = __webpack_require__("./components/FilterBars/FilterSearch.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__FilterSearch_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__FilterSearch_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\FilterBars\\FilterSearch.jsx";




var FilterSearch = function FilterSearch(_ref) {
  var isDisabled = _ref.isDisabled,
      handleChangeFilter = _ref.handleChangeFilter;
  var disableClass = isDisabled ? 'disable-filters' : '';
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterSearch",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 12
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("input", {
    type: "text",
    className: "".concat(disableClass, " FilterSearch__input"),
    onChange: function onChange(e) {
      handleChangeFilter({
        key: 'name',
        value: e.target.value
      });
    },
    placeholder: "Search by Hotel name",
    disabled: "".concat(isDisabled ? 'disabled' : ''),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("button", {
    type: "button",
    className: "".concat(disableClass, " FilterSearch__button"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 20
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 21
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_icons_io__["IoIosSearch"], {
    size: 16,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 22
    }
  }))));
};

/* harmony default export */ __webpack_exports__["a"] = (FilterSearch);

/***/ }),

/***/ "./components/FilterBars/FilterSearch.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/FilterBars/FilterStar.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_star_rating_component__ = __webpack_require__("react-star-rating-component");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_star_rating_component___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_star_rating_component__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__FilterStar_scss__ = __webpack_require__("./components/FilterBars/FilterStar.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__FilterStar_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__FilterStar_scss__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_icons_md__ = __webpack_require__("react-icons/md");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_icons_md___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_icons_md__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\FilterBars\\FilterStar.jsx";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }






var FilterStar =
/*#__PURE__*/
function (_React$Component) {
  _inherits(FilterStar, _React$Component);

  function FilterStar(props) {
    var _this;

    _classCallCheck(this, FilterStar);

    _this = _possibleConstructorReturn(this, (FilterStar.__proto__ || Object.getPrototypeOf(FilterStar)).call(this, props));
    _this.state = {
      hoverStars: 0
    };
    _this.changeRating = _this.changeRating.bind(_assertThisInitialized(_this));
    _this.onHover = _this.onHover.bind(_assertThisInitialized(_this));
    _this.onHoverOut = _this.onHoverOut.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(FilterStar, [{
    key: "onHover",
    value: function onHover(nextValue) {
      this.setState({
        hoverStars: nextValue
      });
    }
  }, {
    key: "onHoverOut",
    value: function onHoverOut() {
      this.setState({
        hoverStars: 0
      });
    }
  }, {
    key: "changeRating",
    value: function changeRating(nextValue) {
      var handleChangeFilter = this.props.handleChangeFilter;

      var change = function change() {
        handleChangeFilter({
          key: 'minStars',
          value: nextValue
        });
      };

      return change();
    }
  }, {
    key: "render",
    value: function render() {
      var _props = this.props,
          isDisabled = _props.isDisabled,
          filters = _props.filters;
      var hoverStars = this.state.hoverStars;
      var ratingValue = 0;

      if (filters) {
        if (hoverStars > 0) {
          ratingValue = hoverStars;
        } else {
          ratingValue = filters.minStars;
        }
      }

      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "FilterStar",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 58
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "FilterStar__wrap",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 59
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_star_rating_component___default.a, {
        name: "rating",
        value: ratingValue,
        starColor: "#f2c94c",
        emptyStarColor: "#dcdcdc",
        onStarClick: this.changeRating,
        onStarHover: this.onHover,
        onStarHoverOut: this.onHoverOut,
        editing: !(filters && isDisabled),
        renderStarIcon: function renderStarIcon() {
          return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_icons_md__["MdStar"], {
            __source: {
              fileName: _jsxFileName,
              lineNumber: 71
            }
          });
        },
        renderStarIconHalf: function renderStarIconHalf() {
          return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_icons_md__["MdStarHalf"], {
            className: "star",
            __source: {
              fileName: _jsxFileName,
              lineNumber: 76
            }
          });
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 60
        }
      })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "FilterStar__status",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 81
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 82
        }
      }, '& up')));
    }
  }]);

  return FilterStar;
}(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Component);

/* harmony default export */ __webpack_exports__["a"] = (FilterStar);

/***/ }),

/***/ "./components/FilterBars/FilterStar.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/NumberFormat/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = NumberFormat;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__react_next_intl_currency_symbols__ = __webpack_require__("./react-next/intl/currency-symbols.js");
var _jsxFileName = "C:\\Projects\\frontend\\components\\NumberFormat\\index.jsx";


function NumberFormat(props) {
  var value = props.value,
      locale = props.locale,
      currency = props.currency,
      withSmall = props.withSmall;
  var strValue = value.toString();
  /* Make sure it's string before using indexOf,
  because flow doesn't force strong typed where component is used */

  var decimalLocation = strValue.indexOf('.'); // Just in case, not affects the flow

  if (decimalLocation === -1) {
    decimalLocation = strValue.indexOf(',');
  }

  var decimalSpace = value.length - decimalLocation - 1;
  var options = {
    maximumFractionDigits: decimalSpace
  };
  var symbol = Object(__WEBPACK_IMPORTED_MODULE_1__react_next_intl_currency_symbols__["a" /* getCurrencySymbol */])(currency); // GetCurrencySymbol is falling back symbol to blank

  var isSymbolAfter = Object(__WEBPACK_IMPORTED_MODULE_1__react_next_intl_currency_symbols__["b" /* isCurrencySymbolAfter */])(currency);

  var _Symbol = function _Symbol() {
    if (currency) {
      return withSmall ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("small", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 29
        }
      }, symbol) : __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 33
        }
      }, symbol);
    }

    return null;
  };

  var numberFormat = new Intl.NumberFormat(locale, options).format(value);
  return isSymbolAfter ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    }
  }, "".concat(numberFormat), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(_Symbol, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  })) : __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(_Symbol, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    }
  }), "".concat(numberFormat));
}

/***/ }),

/***/ "./components/Price/HotelDetailPrice.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__HotelDetailPrice_scss__ = __webpack_require__("./components/Price/HotelDetailPrice.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__HotelDetailPrice_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__HotelDetailPrice_scss__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_intl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__NumberFormat__ = __webpack_require__("./components/NumberFormat/index.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_fa__ = __webpack_require__("react-icons/fa");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_fa___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_icons_fa__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\Price\\HotelDetailPrice.jsx";






var HotelDetailPrice = function HotelDetailPrice(_ref) {
  var initialLoadingStyles = _ref.initialLoadingStyles,
      prices = _ref.prices,
      config = _ref.config,
      cultureCode = _ref.cultureCode,
      isDisabled = _ref.isDisabled,
      paxCount = _ref.paxCount,
      nightCount = _ref.nightCount;
  var general = config.general,
      features = config.features;
  var useTotalPrice = features.useTotalPrice;
  var contentLoading = initialLoadingStyles.contentLoading,
      textLoading = initialLoadingStyles.textLoading;
  var disableIntraction = isDisabled ? 'price__disable' : '';
  var oldPrice = useTotalPrice ? prices.perPackage.originalPrice : prices.perPerson.originalPrice;
  var newPrice = useTotalPrice ? prices.perPackage.price : prices.perPerson.price;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "price ".concat(disableIntraction),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "".concat(contentLoading),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "HotelResultPrice",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    }
  }, oldPrice > 0 && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "price__old",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__NumberFormat__["a" /* default */], {
    value: "".concat(oldPrice),
    currency: "".concat(general.defaultCurrency),
    locale: "".concat(cultureCode),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "price__now theme-primary-text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__NumberFormat__["a" /* default */], {
    value: "".concat(newPrice),
    currency: "".concat(general.defaultCurrency),
    locale: "".concat(cultureCode),
    withSmall: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  }), isDisabled && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    className: "infinite-spin",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_icons_fa__["FaSpinner"], {
    size: 16,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    }
  }))))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "price__note",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 56
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    className: "".concat(textLoading),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 57
    }
  }, useTotalPrice && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_intl__["FormattedMessage"], {
    id: "hotelDetailPrice.totalPriceForPeople",
    defaultMessage: 'total  price for {count} people',
    values: {
      count: paxCount
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    }
  }) || __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_intl__["FormattedMessage"], {
    id: "hotelDetailPrice.perPerson",
    defaultMessage: 'per person for {count, number} {count, plural, one {night} other {nights}}' // TODO pluralize night & no of nights from gethotels api
    ,
    values: {
      count: nightCount
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    className: "".concat(textLoading),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 73
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_intl__["FormattedMessage"], {
    id: "hotelDetailPrice.includingTaxesAndFees",
    defaultMessage: "including taxes & fees",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 74
    }
  }))));
};

/* harmony default export */ __webpack_exports__["a"] = (HotelDetailPrice);

/***/ }),

/***/ "./components/Price/HotelDetailPrice.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/Progress/ProgressBar.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__ProgressBar_scss__ = __webpack_require__("./components/Progress/ProgressBar.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__ProgressBar_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__ProgressBar_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\Progress\\ProgressBar.jsx";



var ProgressBar = function ProgressBar(_ref) {
  var progressStatus = _ref.progressStatus;
  var barPercent = 0;
  var progressMsg = 'Loading...';

  if (progressStatus) {
    if (progressStatus.percent) {
      barPercent = "".concat(progressStatus.percent, "%");
      progressMsg = "".concat(progressStatus.loadingMsg);
    }
  }

  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "ProgressBar ProgressBar--primary",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 16
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "ProgressBar__line",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 17
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "ProgressBar__value",
    style: {
      width: barPercent,
      transition: 'all 2s'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 18
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "ProgressBar__count",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }, progressMsg));
};

/* harmony default export */ __webpack_exports__["a"] = (ProgressBar);

/***/ }),

/***/ "./components/Progress/ProgressBar.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/ReviewRating/ReviewRating.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__ReviewRating_scss__ = __webpack_require__("./components/ReviewRating/ReviewRating.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__ReviewRating_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__ReviewRating_scss__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_intl__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\ReviewRating\\ReviewRating.jsx";




function getColor(score) {
  var color = '';

  if (score >= 86 && score <= 100) {
    color = 'excellent';
  } else if (score >= 80 && score <= 85) {
    color = 'very-good';
  } else if (score >= 75 && score <= 79) {
    color = 'good';
  } else if (score >= 68 && score <= 74) {
    color = 'fair';
  } else if (score >= 0 && score <= 67) {
    color = 'poor';
  }

  return color;
}

var ReviewRating = function ReviewRating(rating) {
  var _rating$data = rating.data,
      score = _rating$data.score,
      text = _rating$data.text,
      reviews = _rating$data.reviews;
  var color = getColor(score);
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "reviewRating reviewRating--".concat(rating.position, " ").concat(rating.size || ''),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    className: "trust-you-logo__score trust-you-logo--".concat(color),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    }
  }, parseFloat(score / 10).toFixed(1)), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "reviewRating__detail reviewRating__detail--".concat(color),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("strong", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    }
  }, text), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_intl__["FormattedMessage"], {
    id: "ReviewRating.reviewCount",
    defaultMessage: 'from {reviews} reviews',
    values: {
      reviews: reviews
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    }
  }))));
};

/* harmony default export */ __webpack_exports__["a"] = (ReviewRating);

/***/ }),

/***/ "./components/ReviewRating/ReviewRating.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/SearchForm/SearchForm.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/SearchForm/actions.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return actionTypes; });
/* harmony export (immutable) */ __webpack_exports__["b"] = failure;
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return setFetching; });
/* unused harmony export getLocationRequest */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return getLocationSuccess; });
/* unused harmony export startSearch */
/* unused harmony export startSearchSuccess */
var actionTypes = {
  FAILURE: 'FAILURE',
  SET_FETCHING: 'SET_FETCHING',
  GET_LOCATION_REQUEST: 'GET_LOCATION_REQUEST',
  GET_LOCATION_SUCCESS: 'GET_LOCATION_SUCCESS',
  START_SEARCH_REQUEST: 'START_SEARCH_REQUEST',
  START_SEARCH_SUCCESS: 'START_SEARCH_SUCCESS'
};
function failure(error) {
  return {
    type: actionTypes.FAILURE,
    error: error
  };
}
var setFetching = function setFetching(value) {
  return {
    type: actionTypes.SET_FETCHING,
    value: value
  };
};
var getLocationRequest = function getLocationRequest() {
  return {
    type: actionTypes.GET_LOCATION_REQUEST
  };
};
var getLocationSuccess = function getLocationSuccess(data) {
  return {
    type: actionTypes.GET_LOCATION_SUCCESS,
    data: data
  };
};
var startSearch = function startSearch() {
  return {
    type: actionTypes.START_SEARCH_REQUEST
  };
};
var startSearchSuccess = function startSearchSuccess() {
  return {
    type: actionTypes.START_SEARCH_SUCCESS
  };
};

/***/ }),

/***/ "./components/SearchForm/components/DropdownList.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export AIRPORT_TYPE */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_md__ = __webpack_require__("react-icons/md");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_md___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_icons_md__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__DropdownMessage__ = __webpack_require__("./components/SearchForm/components/DropdownMessage.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\DropdownList.jsx";



var AIRPORT_TYPE = {
  AIRPORT: 'airport',
  CITY: 'city',
  COUNTPAGE: 20
};

var DropdownList = function DropdownList(props) {
  var resultLocation = props.resultLocation,
      handleLocation = props.handleLocation,
      cursorLocation = props.cursorLocation,
      typeLocation = props.typeLocation,
      fetching = props.fetching,
      selected = props.selected;
  return !fetching && resultLocation.length > 0 ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__dropdown__list",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    }
  }, resultLocation.length > 0 && resultLocation.slice(0, AIRPORT_TYPE.COUNTPAGE).map(function (item, i) {
    if ("".concat(item.airportName, " - (").concat(item.airportCode, ")") !== selected) {
      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        role: "presentation",
        className: "searchForm__dropdown__item ".concat(cursorLocation - 1 === i ? 'searchForm__dropdown__item--active' : null),
        "data-name": item.airportName,
        "data-code": item.airportCode,
        key: item.airportCode,
        onClick: function onClick() {
          return handleLocation(item);
        },
        "data-type": typeLocation,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 40
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "icon",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 49
        }
      }, item.type.toString() === AIRPORT_TYPE.AIRPORT ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_icons_md__["MdMyLocation"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 52
        }
      }) : __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_icons_md__["MdLocationCity"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 53
        }
      })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "detail",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 56
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "name",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 57
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("b", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 58
        }
      }, item.airportName), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 61
        }
      }, "(", item.airportCode, ")")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "origin",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 67
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 68
        }
      }, item.cityName), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("b", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 71
        }
      }, "-", item.countryName))));
    }
  }), ")") : __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__DropdownMessage__["a" /* default */], {
    message: " No results found",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 86
    }
  });
};

/* harmony default export */ __webpack_exports__["a"] = (DropdownList);

/***/ }),

/***/ "./components/SearchForm/components/DropdownMessage.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\DropdownMessage.jsx";


var DropdownMessage = function DropdownMessage(props) {
  var message = props.message;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    className: "searchForm__dropdown__error",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }, message);
};

/* harmony default export */ __webpack_exports__["a"] = (DropdownMessage);

/***/ }),

/***/ "./components/SearchForm/components/DropdownPax.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PAX_TYPE; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_md__ = __webpack_require__("react-icons/md");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_md___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_icons_md__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_intl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__InputCounter__ = __webpack_require__("./components/SearchForm/components/InputCounter.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__DropdownSelect__ = __webpack_require__("./components/SearchForm/components/DropdownSelect.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\DropdownPax.jsx";





var PAX_TYPE = {
  ADULT: 1,
  CHILDREN: 2,
  CHILDREN_RANGE_FROM: 2,
  CHILDREN_RANGE_TO: 11
};

var DropdownPax = function DropdownPax(props) {
  var openDropDown = props.openDropDown,
      rooms = props.rooms,
      addRoom = props.addRoom,
      removeRoom = props.removeRoom,
      maxRoom = props.maxRoom,
      maxAdults = props.maxAdults,
      maxChild = props.maxChild,
      maxTotalofRoom = props.maxTotalofRoom,
      countTotalOfPax = props.countTotalOfPax,
      calculatePassenger = props.calculatePassenger,
      message = props.message,
      selectChildAge = props.selectChildAge,
      onBlur = props.onBlur;

  var RoomBox = function RoomBox() {
    return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
      className: "modifyPax__wrap",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 50
      }
    }, rooms.map(function (item, index) {
      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__room",
        key: index,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 53
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__box",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 54
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__box__title",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 55
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__room__icon",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 56
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_icons_md__["MdHotel"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 57
        }
      })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("b", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 59
        }
      }, 'ROOM ', index + 1)), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__persons",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 64
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__InputCounter__["a" /* default */], {
        title: "Adult",
        min: 1,
        count: item.adults,
        max: maxAdults,
        maxTotal: maxTotalofRoom,
        countTotal: item.adults + item.children.length,
        countTotalOfPax: countTotalOfPax,
        addCount: function addCount() {
          return calculatePassenger(index, PAX_TYPE.ADULT, 1);
        },
        removeCount: function removeCount() {
          return calculatePassenger(index, PAX_TYPE.ADULT, -1);
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 65
        }
      }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__InputCounter__["a" /* default */], {
        title: "Children",
        count: item.children.length,
        min: 0,
        max: maxChild // maxOfAdults={item.adults}
        ,
        maxTotal: maxTotalofRoom,
        countTotal: item.adults + item.children.length,
        countTotalOfPax: countTotalOfPax,
        addCount: function addCount() {
          return calculatePassenger(index, PAX_TYPE.CHILDREN, 1);
        },
        removeCount: function removeCount() {
          return calculatePassenger(index, PAX_TYPE.CHILDREN, -1);
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 76
        }
      }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__age",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 90
        }
      }, item.children.length ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__age__title",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 94
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 95
        }
      }, "Child Age")) : '', __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__age__box",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 102
        }
      }, item.children ? item.children.map(function (child, childIndex) {
        return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__DropdownSelect__["a" /* default */], {
          key: "select_".concat(childIndex),
          value: child,
          isInfantDisabled: item.children.filter(function (c) {
            return c < 2;
          }).length === item.adults,
          onChange: function onChange(e) {
            return selectChildAge(e, index, childIndex);
          },
          __source: {
            fileName: _jsxFileName,
            lineNumber: 104
          }
        });
      }) : null)));
    }));
  };

  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__dropdown searchForm__dropdown--pax ".concat(openDropDown ? 'is-open' : ''),
    onBlur: onBlur,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 119
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "modifyPax",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 120
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "modifyPax__nav",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 121
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__InputCounter__["a" /* default */], {
    title: "Room",
    count: rooms.length,
    min: 1,
    max: maxRoom,
    addCount: addRoom,
    maxTotal: maxTotalofRoom,
    countTotalOfPax: countTotalOfPax,
    removeCount: removeRoom,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 122
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "modifyPax__title",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 132
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 133
    }
  }, "ADULTS"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 136
    }
  }, "CHILDREN 0-12"))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(RoomBox, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 141
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "modifyPax__notify",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 142
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 143
    }
  }, message))));
};

/* harmony default export */ __webpack_exports__["b"] = (DropdownPax);

/***/ }),

/***/ "./components/SearchForm/components/DropdownResult.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__DropdownMessage__ = __webpack_require__("./components/SearchForm/components/DropdownMessage.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__DropdownList__ = __webpack_require__("./components/SearchForm/components/DropdownList.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\DropdownResult.jsx";




// eslint-disable-next-line prefer-stateless-function
var DropdownResult = function DropdownResult(props) {
  var resultLocation = props.resultLocation,
      handleLocation = props.handleLocation,
      fetching = props.fetching,
      isOpen = props.isOpen,
      selected = props.selected,
      cursorLocation = props.cursorLocation,
      typeLocation = props.typeLocation;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__dropdown ".concat(isOpen ? 'is-open' : ''),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, fetching ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__DropdownMessage__["a" /* default */], {
    message: "Loading...",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    }
  }) : __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__DropdownList__["a" /* default */], {
    resultLocation: resultLocation,
    handleLocation: handleLocation,
    cursorLocation: cursorLocation,
    typeLocation: typeLocation,
    fetchin: fetching,
    selected: selected,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    }
  }));
};

/* harmony default export */ __webpack_exports__["a"] = (DropdownResult);

/***/ }),

/***/ "./components/SearchForm/components/DropdownSelect.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_lodash__ = __webpack_require__("lodash");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_lodash___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_lodash__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__DropdownPax__ = __webpack_require__("./components/SearchForm/components/DropdownPax.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\DropdownSelect.jsx";




var DropdownSelect = function DropdownSelect(props) {
  var onChange = props.onChange,
      value = props.value,
      isInfantDisabled = props.isInfantDisabled;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("select", {
    className: "modifyPax__age__select",
    value: value,
    onChange: onChange,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("option", {
    value: "1",
    disabled: isInfantDisabled && value !== 1,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 16
    }
  }, "Below 2 years"), __WEBPACK_IMPORTED_MODULE_1_lodash___default.a.range(__WEBPACK_IMPORTED_MODULE_2__DropdownPax__["a" /* PAX_TYPE */].CHILDREN_RANGE_FROM, __WEBPACK_IMPORTED_MODULE_2__DropdownPax__["a" /* PAX_TYPE */].CHILDREN_RANGE_TO + 1).map(function (childAge) {
    return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("option", {
      key: childAge,
      value: childAge,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 20
      }
    }, childAge, ' years old');
  }));
};

/* harmony default export */ __webpack_exports__["a"] = (DropdownSelect);

/***/ }),

/***/ "./components/SearchForm/components/InputCounter.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_intl__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\InputCounter.jsx";



var InputCounter = function InputCounter(props) {
  var title = props.title,
      count = props.count,
      min = props.min,
      max = props.max,
      maxTotal = props.maxTotal,
      countTotal = props.countTotal,
      addCount = props.addCount,
      removeCount = props.removeCount,
      maxOfAdults = props.maxOfAdults,
      countTotalOfPax = props.countTotalOfPax;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "modifyPax__count",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("button", {
    type: "button",
    className: "modifyPax__add ".concat(count === min ? 'modifyPax__add--disable' : ''),
    onClick: removeCount,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    }
  }, "-"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "modifyPax__text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "inputCounter.{titles}",
    defaultMessage: "\n              {counts, plural,\n                  =0 {{counts} {titles}}\n                  one {{counts} {titles}}\n                  other {{counts} {titles}s}\n              }\n          ",
    values: {
      counts: count,
      titles: title
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("button", {
    type: "button",
    className: "modifyPax__add ".concat(count === max || countTotal === maxTotal || countTotalOfPax === maxTotal || count === maxOfAdults ? 'modifyPax__add--disable' : ''),
    onClick: addCount,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 56
    }
  }, "+"));
};

/* harmony default export */ __webpack_exports__["a"] = (InputCounter);

/***/ }),

/***/ "./components/SearchForm/components/InputDatePicker.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux__ = __webpack_require__("react-redux");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_redux__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_date_fns_get_month__ = __webpack_require__("date-fns/get_month");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_date_fns_get_month___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_date_fns_get_month__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_date_fns_get_year__ = __webpack_require__("date-fns/get_year");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_date_fns_get_year___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_date_fns_get_year__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_io__ = __webpack_require__("react-icons/io");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_io___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_icons_io__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__react_next_intl_date_locale__ = __webpack_require__("./react-next/intl/date-locale.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__store_modules_locale_selection_selectors__ = __webpack_require__("./store/modules/locale-selection/selectors.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__Common_DatePicker__ = __webpack_require__("./components/Common/DatePicker/index.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\InputDatePicker.jsx";









var InputDatePicker = function InputDatePicker(props) {
  var selectedCultureCode = props.selectedCultureCode,
      initDate = props.initDate,
      title = props.title,
      placeHolder = props.placeHolder,
      openHandle = props.openHandle,
      name = props.name,
      inputRef = props.inputRef,
      setDate = props.setDate,
      minStartDay = props.minStartDay,
      maxStartDay = props.maxStartDay,
      openDropDown = props.openDropDown;
  var dateSelected = Object(__WEBPACK_IMPORTED_MODULE_5__react_next_intl_date_locale__["b" /* formatDateString */])(initDate, 'MEDIUM', selectedCultureCode);
  var monthSelected = __WEBPACK_IMPORTED_MODULE_2_date_fns_get_month___default()(initDate);
  var yearSelected = __WEBPACK_IMPORTED_MODULE_3_date_fns_get_year___default()(initDate);
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("strong", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    }
  }, title), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input__group",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input__icon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_icons_io__["IoIosCalendar"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("input", {
    readOnly: true,
    className: "searchForm__input__value datepicker",
    autoComplete: "off",
    type: "text",
    placeholder: placeHolder,
    onClick: openHandle,
    id: name,
    value: dateSelected,
    ref: inputRef,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__dropdown searchForm__dropdown--date ".concat(openDropDown ? 'is-open' : ''),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__Common_DatePicker__["a" /* default */], {
    changedMonth: monthSelected,
    changeYear: yearSelected,
    selected: initDate,
    changed: setDate,
    minStartDay: minStartDay,
    maxStartDay: maxStartDay,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 66
    }
  }))));
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    selectedCultureCode: Object(__WEBPACK_IMPORTED_MODULE_6__store_modules_locale_selection_selectors__["a" /* getCultureCode */])(state)
  };
};

/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_1_react_redux__["connect"])(mapStateToProps)(InputDatePicker));

/***/ }),

/***/ "./components/SearchForm/components/InputPax.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_io__ = __webpack_require__("react-icons/io");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_io___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_icons_io__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\InputPax.jsx";



var InputPax = function InputPax(props) {
  var title = props.title,
      openHandle = props.openHandle,
      name = props.name,
      value = props.value,
      inputRef = props.inputRef;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("strong", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    }
  }, title), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input__group",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input__icon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_icons_io__["IoMdPerson"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("input", {
    className: "searchForm__input__value",
    autoComplete: "off",
    onClick: openHandle,
    type: "text",
    id: name,
    defaultValue: value,
    ref: inputRef,
    readOnly: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    }
  })));
};

/* harmony default export */ __webpack_exports__["a"] = (InputPax);

/***/ }),

/***/ "./components/SearchForm/components/InputText.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\InputText.jsx";


var InputText = function InputText(props) {
  var onChange = props.onChange,
      value = props.value,
      name = props.name,
      onClick = props.onClick,
      inputRef = props.inputRef,
      icon = props.icon,
      onBlur = props.onBlur,
      onKeyDown = props.onKeyDown;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input__group",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input__icon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, icon)), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("input", {
    className: "searchForm__input__value",
    autoComplete: "off",
    type: "text",
    id: name,
    onChange: onChange,
    value: value,
    onClick: onClick,
    ref: inputRef,
    onBlur: onBlur,
    onKeyDown: onKeyDown,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  }));
};

/* harmony default export */ __webpack_exports__["a"] = (InputText);

/***/ }),

/***/ "./components/SearchForm/components/InputTextGroup.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__InputText__ = __webpack_require__("./components/SearchForm/components/InputText.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__DropdownResult__ = __webpack_require__("./components/SearchForm/components/DropdownResult.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\InputTextGroup.jsx";




var InputTextGroup = function InputTextGroup(props) {
  var title = props.title,
      name = props.name,
      openHandle = props.openHandle,
      getLocations = props.getLocations,
      value = props.value,
      resultLocation = props.resultLocation,
      openDropDown = props.openDropDown,
      fetching = props.fetching,
      setLocation = props.setLocation,
      inputRef = props.inputRef,
      selected = props.selected,
      icon = props.icon,
      errorText = props.errorText,
      onBlur = props.onBlur,
      onKeyDown = props.onKeyDown,
      cursorLocation = props.cursorLocation;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("strong", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    }
  }, title), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__InputText__["a" /* default */], {
    name: name,
    onClick: openHandle,
    onChange: getLocations,
    value: value,
    icon: icon,
    inputRef: inputRef,
    onBlur: onBlur,
    onKeyDown: onKeyDown,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    }
  }), errorText.length ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__error",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    }
  }, errorText) : '', __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__DropdownResult__["a" /* default */], {
    resultLocation: resultLocation,
    isOpen: openDropDown,
    handleLocation: setLocation,
    fetching: fetching,
    cursorLocation: cursorLocation,
    typeLocation: name,
    selected: selected,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 67
    }
  }));
};

/* harmony default export */ __webpack_exports__["a"] = (InputTextGroup);

/***/ }),

/***/ "./components/SearchForm/components/Overlay.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\Overlay.jsx";


var Overlay = function Overlay(props) {
  var isOverlay = props.isOverlay,
      clicked = props.clicked;
  return isOverlay && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    role: "presentation",
    className: "searchForm__overlay",
    onClick: clicked,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15
    }
  });
};

/* harmony default export */ __webpack_exports__["a"] = (Overlay);

/***/ }),

/***/ "./components/SearchForm/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_dom__ = __webpack_require__("react-dom");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_dom___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_dom__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_router__ = __webpack_require__("next/router");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_router___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_next_router__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_redux__ = __webpack_require__("react-redux");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_redux___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_redux__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_date_fns_format__ = __webpack_require__("date-fns/format");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_date_fns_format___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_date_fns_format__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days__ = __webpack_require__("date-fns/add_days");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_date_fns_add_days__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_date_fns_difference_in_calendar_days__ = __webpack_require__("date-fns/difference_in_calendar_days");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_date_fns_difference_in_calendar_days___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_date_fns_difference_in_calendar_days__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__actions__ = __webpack_require__("./components/SearchForm/actions.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_InputTextGroup__ = __webpack_require__("./components/SearchForm/components/InputTextGroup.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__components_DropdownPax__ = __webpack_require__("./components/SearchForm/components/DropdownPax.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__components_InputDatePicker__ = __webpack_require__("./components/SearchForm/components/InputDatePicker.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__components_InputPax__ = __webpack_require__("./components/SearchForm/components/InputPax.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__components_Overlay__ = __webpack_require__("./components/SearchForm/components/Overlay.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__store_modules_locale_selection_selectors__ = __webpack_require__("./store/modules/locale-selection/selectors.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__SearchForm_scss__ = __webpack_require__("./components/SearchForm/SearchForm.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__SearchForm_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_14__SearchForm_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\index.jsx";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }















var IconArrival = function IconArrival(props) {
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("svg", props, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("path", {
    d: "M193.617 303.697l117.086 31.394 143.225 38.4c21.558 5.794 43.655-7.006 49.448-28.564 5.794-21.558-7.006-43.655-28.564-49.448l-143.225-38.4-74.24-243.065L205.204 0v223.124L71.41 187.284l-25.061-62.518-39.073-10.509V253.71l43.25 11.587 143.091 38.4zM0 458.105h512V512H0z"
  }));
};

IconArrival.defaultProps = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 512 512"
};

var IconDeparture = function IconDeparture(props) {
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("svg", props, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("path", {
    d: "M16.539 425.626h479.767v50.502H16.539zM510.7 189.151c-5.429-20.201-26.135-32.195-46.335-26.766l-134.209 35.982L155.924 35.878l-48.734 13.13 104.539 181.175-125.497 33.584-49.618-39.013L0 234.603l45.957 79.667 19.317 33.457 40.528-10.858 134.209-35.983 109.715-29.417 134.209-35.983c20.199-5.429 32.194-26.134 26.765-46.335z"
  }));
};

IconDeparture.defaultProps = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 512.005 512.005"
};



var SearchForm =
/*#__PURE__*/
function (_Component) {
  _inherits(SearchForm, _Component);

  function SearchForm(props) {
    var _this;

    _classCallCheck(this, SearchForm);

    _this = _possibleConstructorReturn(this, (SearchForm.__proto__ || Object.getPrototypeOf(SearchForm)).call(this, props));
    Object.defineProperty(_assertThisInitialized(_this), "getLocations", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(e) {
        var location = e.target.value;
        var dispatch = _this.props.dispatch;

        _this.setState(_defineProperty({}, e.target.id, e.target.value));

        if (location.length > 0) {
          dispatch({
            type: __WEBPACK_IMPORTED_MODULE_7__actions__["a" /* actionTypes */].GET_LOCATION_REQUEST,
            location: location
          });
        }
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "getLocationOnKey", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(e) {
        var airportData = _this.props.airportData;
        var airportResultCursor = _this.state.airportResultCursor;

        if (e.keyCode === 40 || e.keyCode === 38 || e.keyCode === 13 || e.keyCode === 27 || e.keyCode === 9) {
          if (e.keyCode === 38 && airportResultCursor > 0) {
            _this.setState(function (prevState) {
              return {
                airportResultCursor: prevState.airportResultCursor - 1
              };
            });
          } else if (e.keyCode === 40 && airportResultCursor < airportData.length) {
            _this.setState(function (prevState) {
              return {
                airportResultCursor: prevState.airportResultCursor + 1
              };
            });
          } else if (e.keyCode === 13 && airportResultCursor > 0) {
            if (e.target.id === 'SearchNameFrom') {
              var selected = __WEBPACK_IMPORTED_MODULE_1_react_dom___default.a.findDOMNode(_assertThisInitialized(_this)).getElementsByClassName('searchForm__dropdown__item--active');

              _this.setState({
                SearchNameFrom: "".concat(selected[0].getAttribute('data-name'), " - (").concat(selected[0].getAttribute('data-code'), ")"),
                SearchNameFromCode: selected[0].getAttribute('data-code'),
                SearchNameFromError: '',
                SearchNameFromSelected: "".concat(selected[0].getAttribute('data-name'), " - (").concat(selected[0].getAttribute('data-code'), ")")
              });

              _this.inputToRef.current.click();
            } else if (e.target.id === 'SearchNameTo') {
              var _selected = __WEBPACK_IMPORTED_MODULE_1_react_dom___default.a.findDOMNode(_assertThisInitialized(_this)).getElementsByClassName('searchForm__dropdown__item--active');

              _this.setState({
                SearchNameTo: "".concat(_selected[0].getAttribute('data-name'), " - (").concat(_selected[0].getAttribute('data-code'), ")"),
                SearchNameToCode: _selected[0].getAttribute('data-code'),
                SearchNameToError: '',
                SearchNameToSelected: "".concat(_selected[0].getAttribute('data-name'), " - (").concat(_selected[0].getAttribute('data-code'), ")")
              });

              _this.inputDepartureRef.current.click();
            }
          } else if (e.keyCode === 27) {
            _this.setState({
              isDropdownOpen: {},
              isOverlay: false
            });
          } else if (airportData.length >= 1 && e.keyCode === 9) {
            var formTarget = e.target.id;

            if (formTarget === 'SearchNameFrom') {
              _this.setState({
                SearchNameFrom: airportData[0].airportName,
                SearchNameFromCode: airportData[0].airportCode,
                SearchNameFromSelected: airportData[0].airportName
              });
            } else if (formTarget === 'SearchNameTo') {
              _this.setState({
                SearchNameTo: airportData[0].airportName,
                SearchNameToCode: airportData[0].airportCode,
                SearchNameToSelected: airportData[0].airportName
              });
            }
          }
        }
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "setLocationFrom", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(item) {
        _this.setState({
          SearchNameFrom: "".concat(item.airportName, " - (").concat(item.airportCode, ")"),
          SearchNameFromCode: item.airportCode,
          SearchNameFromError: '',
          SearchNameFromSelected: "".concat(item.airportName, " - (").concat(item.airportCode, ")")
        });

        _this.inputToRef.current.click();
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "setLocationTo", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(item) {
        _this.setState({
          SearchNameTo: "".concat(item.airportName, " - (").concat(item.airportCode, ")"),
          SearchNameToCode: item.airportCode,
          SearchNameToError: '',
          SearchNameToSelected: "".concat(item.airportName, " - (").concat(item.airportCode, ")")
        });

        _this.inputDepartureRef.current.click();
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "addPassengerRoom", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        var configSearchForm = _this.props.configSearchForm;
        var rooms = _this.state.rooms;

        var sum = function sum(a) {
          return a.reduce(function (x, y) {
            return x + y;
          });
        };

        var totalAllPeople = sum(rooms.map(function (x) {
          return Number(x.adults);
        })) + sum(rooms.map(function (h) {
          return Number(h.children.length);
        }));

        if (rooms.length >= configSearchForm.maxRooms && totalAllPeople < configSearchForm.maxPax) {
          return;
        }

        var initRoom = {
          adults: 1,
          children: []
        };
        rooms.push(initRoom);

        _this.setState({
          rooms: rooms
        });
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "removePassengerRoom", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        var rooms = _this.state.rooms;

        if (rooms.length === 1) {
          return;
        }

        rooms.pop(rooms);

        _this.setState({
          rooms: rooms
        });
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleChangeDateFrom", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(date) {
        var configSearchForm = _this.props.configSearchForm;
        var returnDate = _this.state.returnDate;

        if (__WEBPACK_IMPORTED_MODULE_6_date_fns_difference_in_calendar_days___default()(returnDate, date) >= configSearchForm.minBookingDays) {
          _this.setState({
            departureDate: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(date, 0),
            returnDate: returnDate
          });
        } else {
          _this.setState({
            departureDate: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(date, 0),
            returnDate: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(date, configSearchForm.minBookingDays)
          });
        }

        _this.inputReturnRef.current.click();
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleChangeDateTo", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(date) {
        _this.setState({
          returnDate: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(date, 0),
          isDropdownOpen: {},
          isOverlay: false
        }); // this.inputPaxRef.current.click();

      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleChangeSearch", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(e) {
        var idOfDOM = e.target.id;

        if (idOfDOM === 'SearchNameTo' || idOfDOM === 'SearchNameFrom') {
          var _dispatch = _this.props.dispatch;

          _dispatch({
            type: __WEBPACK_IMPORTED_MODULE_7__actions__["a" /* actionTypes */].GET_LOCATION_REQUEST
          });
        }

        e.target.select();

        _this.setState({
          isDropdownOpen: {},
          isOverlay: true
        });

        _this.setState({
          isDropdownOpen: _defineProperty({}, idOfDOM, true),
          SearchNameFromError: '',
          SearchNameToError: ''
        });
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "validate", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        var isError = false;
        var errors = {
          SearchNameFromError: '',
          SearchNameToError: ''
        };
        var _this$state = _this.state,
            SearchNameFrom = _this$state.SearchNameFrom,
            SearchNameTo = _this$state.SearchNameTo,
            SearchNameFromCode = _this$state.SearchNameFromCode,
            SearchNameToCode = _this$state.SearchNameToCode;

        if (SearchNameFrom.length === 0 || SearchNameFromCode.length < 3) {
          isError = true;
          errors.SearchNameFromError = 'Please choose somewhere to depart';
        }

        if (SearchNameTo.length === 0 || SearchNameToCode.length < 3) {
          isError = true;
          errors.SearchNameToError = 'Please choose somewhere to go';
        }

        _this.setState(_objectSpread({}, errors));

        return isError;
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleSubmitSearch", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(e) {
        var err = _this.validate();

        _this.setState({
          isDropdownOpen: false
        });

        if (!err) {
          var stateParams = _this.state;
          var _urlLocale = _this.props.urlLocale;
          var fromLocation = stateParams.SearchNameFromCode;
          var toLocation = stateParams.SearchNameToCode;
          var departureDate = __WEBPACK_IMPORTED_MODULE_4_date_fns_format___default()(stateParams.departureDate, 'YYYY-MM-DD');
          var returnDate = __WEBPACK_IMPORTED_MODULE_4_date_fns_format___default()(stateParams.returnDate, 'YYYY-MM-DD');
          var roomsParams = stateParams.rooms;
          var roomString = '';

          for (var i = 0; i < roomsParams.length; i++) {
            var room = roomsParams[i];
            roomString += "&room[".concat(i, "]=").concat(room.adults, ",").concat(room.children.length);

            if (Object.prototype.hasOwnProperty.call(room, 'children') && room.children.length > 1) {
              var childrenPax = room.children;
              roomString += "&childAges[".concat(i, "]=");

              for (var j = 0; j < childrenPax.length; j++) {
                roomString += childrenPax[j] + (j + 1 < childrenPax.length ? ',' : '');
              }
            }
          }

          __WEBPACK_IMPORTED_MODULE_2_next_router___default.a.push("".concat(_urlLocale, "/search/").concat(fromLocation, "/").concat(toLocation, "?depart=").concat(departureDate, "&return=").concat(returnDate).concat(roomString));
          console.log("/search/".concat(fromLocation, "/").concat(toLocation, "?depart=").concat(departureDate, "&return=").concat(returnDate).concat(roomString));
        } else {
          e.preventDefault();
        }
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "closeAllDropdown", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(e) {
        var airportData = _this.props.airportData;
        var formTarget = e.target.id;

        if (airportData.length === 1) {
          if (formTarget === 'SearchNameFrom') {
            _this.setState({
              SearchNameFrom: airportData[0].airportName,
              SearchNameFromCode: airportData[0].airportCode,
              SearchNameFromSelected: airportData[0].airportName
            });
          } else if (formTarget === 'SearchNameTo') {
            _this.setState({
              SearchNameTo: airportData[0].airportName,
              SearchNameToCode: airportData[0].airportCode,
              SearchNameToSelected: airportData[0].airportName
            });
          }
        }
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "overlayHandle", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        var airportData = _this.props.airportData;
        var _this$state2 = _this.state,
            SearchNameFromCode = _this$state2.SearchNameFromCode,
            SearchNameToCode = _this$state2.SearchNameToCode,
            SearchNameFrom = _this$state2.SearchNameFrom,
            SearchNameTo = _this$state2.SearchNameTo,
            SearchNameToSelected = _this$state2.SearchNameToSelected,
            SearchNameFromSelected = _this$state2.SearchNameFromSelected;

        if (airportData.length !== 1) {
          if (SearchNameFrom !== '' && SearchNameFromCode === '') {
            _this.setState({
              SearchNameFrom: ''
            });
          } else if (SearchNameTo !== '' && SearchNameToCode === '') {
            _this.setState({
              SearchNameTo: ''
            });
          } else if (SearchNameFrom !== SearchNameFromSelected && SearchNameFromCode !== '') {
            _this.setState({
              SearchNameFrom: SearchNameFromSelected
            });
          } else if (SearchNameTo !== SearchNameToSelected && SearchNameToCode !== '') {
            _this.setState({
              SearchNameTo: SearchNameToSelected
            });
          }
        }

        _this.setState({
          isOverlay: false,
          isDropdownOpen: false
        });
      }
    });
    _this.state = {
      isDropdownOpen: {},
      departureDate: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(new Date(), props.configSearchForm.minBookingDays),
      returnDate: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(new Date(), props.configSearchForm.minBookingDays + props.configSearchForm.minBookingPeriod),
      SearchNameFrom: '',
      SearchNameFromSelected: '',
      SearchNameTo: '',
      SearchNameToSelected: '',
      SearchNameFromCode: '',
      SearchNameToCode: '',
      SearchNameFromError: '',
      SearchNameToError: '',
      airportResultCursor: 0,
      isOverlay: false,
      rooms: [{
        adults: 2,
        children: []
      }]
    };
    _this.timer = null;
    _this.inputToRef = __WEBPACK_IMPORTED_MODULE_0_react___default.a.createRef();
    _this.inputDepartureRef = __WEBPACK_IMPORTED_MODULE_0_react___default.a.createRef();
    _this.inputReturnRef = __WEBPACK_IMPORTED_MODULE_0_react___default.a.createRef();
    _this.inputPaxRef = __WEBPACK_IMPORTED_MODULE_0_react___default.a.createRef();
    _this.calculatePassenger = _this.calculatePassenger.bind(_assertThisInitialized(_this));
    _this.selectChildAge = _this.selectChildAge.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(SearchForm, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var _props = this.props,
          validateQueryString = _props.validateQueryString,
          packageDetails = _props.packageDetails;

      if (validateQueryString && packageDetails !== undefined) {
        this.setState({
          departureDate: validateQueryString.validDepartDate.value,
          returnDate: validateQueryString.validReturnDate.value,
          SearchNameFrom: packageDetails.originCityName,
          SearchNameTo: packageDetails.destinationCityName,
          SearchNameFromCode: validateQueryString.validOrigin.value,
          SearchNameToCode: validateQueryString.validDestination.value,
          rooms: validateQueryString.validPax.value
        });
      }
    }
  }, {
    key: "calculatePassenger",
    value: function calculatePassenger(index, type, amount) {
      var configSearchForm = this.props.configSearchForm;
      var rooms = this.state.rooms;

      var sum = function sum(a) {
        return a.reduce(function (x, y) {
          return x + y;
        });
      };

      var totalAllPeople = sum(rooms.map(function (x) {
        return Number(x.adults);
      })) + sum(rooms.map(function (h) {
        return Number(h.children.length);
      }));
      var room = rooms[index]; // const totalAdults = room.adults + room.children.length;

      switch (type) {
        case __WEBPACK_IMPORTED_MODULE_9__components_DropdownPax__["a" /* PAX_TYPE */].ADULT:
          if (amount === 1 && totalAllPeople < configSearchForm.maxPax) {
            room.adults += amount;
          } else if (amount === -1 && room.children.length >= room.adults && room.adults > 1) {
            if (room.children.filter(function (c) {
              return c < 2;
            }).length === room.adults) {
              var arrInfant = room.children.lastIndexOf(0);
              room.children.splice(arrInfant, 1);
              console.log(arrInfant);
            }

            room.adults--;
          } else if (amount === -1 && room.adults === 1) {
            return;
          } else if (amount === -1 && room.adults > 0) {
            room.adults--;
          }

          rooms[index] = room;
          this.setState({
            rooms: rooms
          });
          break;

        case __WEBPACK_IMPORTED_MODULE_9__components_DropdownPax__["a" /* PAX_TYPE */].CHILDREN:
          if (amount === 1 && totalAllPeople < configSearchForm.maxPax) {
            if (room.children.length < 3 && room.children.length >= 0) {
              room.children.push(2);
            } else {
              return;
            }
          } else if (amount === -1 && room.children.length > 0) {
            room.children.pop();
          } else {
            return;
          }

          rooms[index] = room;
          this.setState({
            rooms: rooms
          });
          break;

        default:
          break;
      }
    }
  }, {
    key: "selectChildAge",
    value: function selectChildAge(e, index, childIndex) {
      var rooms = this.state.rooms;

      try {
        rooms[index].children[childIndex] = parseInt(e.target.value, 10);
      } catch (err) {
        console.log(err);
      }

      this.setState({
        rooms: rooms
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _props2 = this.props,
          isFetching = _props2.isFetching,
          configSearchForm = _props2.configSearchForm,
          airportData = _props2.airportData;
      var _state = this.state,
          isDropdownOpen = _state.isDropdownOpen,
          SearchNameFrom = _state.SearchNameFrom,
          SearchNameTo = _state.SearchNameTo,
          departureDate = _state.departureDate,
          returnDate = _state.returnDate,
          SearchNameFromSelected = _state.SearchNameFromSelected,
          SearchNameToSelected = _state.SearchNameToSelected,
          rooms = _state.rooms,
          SearchNameFromError = _state.SearchNameFromError,
          SearchNameToError = _state.SearchNameToError,
          airportResultCursor = _state.airportResultCursor,
          isOverlay = _state.isOverlay;

      var sum = function sum(a) {
        return a.reduce(function (x, y) {
          return x + y;
        });
      };

      var AllAdults = sum(rooms.map(function (x) {
        return Number(x.adults);
      })) + sum(rooms.map(function (h) {
        return Number(h.children.length);
      }));
      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "searchForm",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 456
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__components_Overlay__["a" /* default */], {
        isOverlay: isOverlay,
        clicked: this.overlayHandle,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 457
        }
      }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "searchForm__panel",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 461
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("form", {
        className: "searchForm__form",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 462
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "searchForm__content",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 463
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "searchForm__box searchForm__address",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 464
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_InputTextGroup__["a" /* default */], {
        title: "From",
        name: "SearchNameFrom",
        icon: __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(IconDeparture, {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 468
          }
        }),
        value: SearchNameFrom,
        fetching: isFetching,
        openHandle: this.handleChangeSearch,
        openDropDown: isDropdownOpen.SearchNameFrom,
        getLocations: this.getLocations,
        resultLocation: airportData,
        setLocation: this.setLocationFrom,
        selected: SearchNameToSelected,
        errorText: SearchNameFromError,
        onBlur: this.closeAllDropdown,
        onKeyDown: this.getLocationOnKey,
        cursorLocation: airportResultCursor,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 465
        }
      }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_InputTextGroup__["a" /* default */], {
        title: "To",
        name: "SearchNameTo",
        icon: __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(IconArrival, {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 485
          }
        }),
        value: SearchNameTo,
        fetching: isFetching,
        openHandle: this.handleChangeSearch,
        openDropDown: isDropdownOpen.SearchNameTo,
        getLocations: this.getLocations,
        resultLocation: airportData,
        selected: SearchNameFromSelected,
        setLocation: this.setLocationTo,
        inputRef: this.inputToRef,
        errorText: SearchNameToError,
        onBlur: this.closeAllDropdown,
        onKeyDown: this.getLocationOnKey,
        cursorLocation: airportResultCursor,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 482
        }
      })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "searchForm__box searchForm__date",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 501
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__components_InputDatePicker__["a" /* default */], {
        title: "Departure",
        name: "SearchNameDeparture",
        placeHolder: "DD/MM/YYYY",
        minStartDay: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(new Date(), configSearchForm.minBookingDays),
        maxStartDay: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(new Date(), configSearchForm.maxBookingDays),
        openHandle: this.handleChangeSearch,
        openDropDown: isDropdownOpen.SearchNameDeparture,
        initDate: departureDate,
        setDate: this.handleChangeDateFrom,
        inputRef: this.inputDepartureRef,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 502
        }
      }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__components_InputDatePicker__["a" /* default */], {
        title: "Return",
        placeHolder: "DD/MM/YYYY",
        name: "SearchNameReturn",
        minStartDay: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(departureDate, configSearchForm.minBookingPeriod),
        maxStartDay: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(departureDate, configSearchForm.maxBookingPeriod),
        openHandle: this.handleChangeSearch,
        openDropDown: isDropdownOpen.SearchNameReturn,
        initDate: returnDate,
        setDate: this.handleChangeDateTo,
        inputRef: this.inputReturnRef,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 514
        }
      })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "searchForm__box searchForm__pax",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 528
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__components_InputPax__["a" /* default */], {
        title: "ROOMS & PASSENGERS",
        name: "SearchNamePax",
        openHandle: this.handleChangeSearch,
        setPassengers: this.setPassengers,
        inputRef: this.inputPaxRef,
        value: "".concat(rooms.length, " Rooms, ").concat(AllAdults, " Peoples"),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 529
        }
      })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__components_DropdownPax__["b" /* default */], {
        openDropDown: isDropdownOpen.SearchNamePax,
        rooms: rooms,
        addRoom: this.addPassengerRoom,
        maxRoom: configSearchForm.maxRooms,
        maxAdults: 3,
        maxChild: 3,
        countTotalOfPax: AllAdults,
        maxTotalofRoom: configSearchForm.maxPax,
        removeRoom: this.removePassengerRoom,
        calculatePassenger: this.calculatePassenger,
        selectChildAge: this.selectChildAge,
        message: "Maximum ".concat(configSearchForm.maxPax, "  guests are allowed per booking"),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 538
        }
      })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "searchForm__control",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 553
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("button", {
        type: "button",
        className: "searchForm__button btn-theme-primary btn-effect",
        onClick: this.handleSubmitSearch,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 554
        }
      }, "Search")))));
    }
  }]);

  return SearchForm;
}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);

var mapStateToProps = function mapStateToProps(state) {
  return {
    airportData: state.searchForm.airportData,
    isFetching: state.searchForm.isFetching,
    cultureCode: Object(__WEBPACK_IMPORTED_MODULE_13__store_modules_locale_selection_selectors__["a" /* getCultureCode */])(state),
    urlLocale: Object(__WEBPACK_IMPORTED_MODULE_13__store_modules_locale_selection_selectors__["b" /* getUrlLocale */])(state)
  };
};

/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_3_react_redux__["connect"])(mapStateToProps)(SearchForm));

/***/ }),

/***/ "./components/StarsRaing/StarsRatingSingle.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_io__ = __webpack_require__("react-icons/io");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_io___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_icons_io__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__StarsRatingSingle_scss__ = __webpack_require__("./components/StarsRaing/StarsRatingSingle.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__StarsRatingSingle_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__StarsRatingSingle_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\StarsRaing\\StarsRatingSingle.jsx";




var StarsRatingSingle = function StarsRatingSingle(_ref) {
  var stars = _ref.stars,
      size = _ref.size;

  function getStars() {
    var totalStars = [];

    for (var i = 0; i < stars; i++) {
      totalStars.push(__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
        className: "starsRating__single__item ".concat(size || ''),
        key: i,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 16
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_icons_io__["IoMdStar"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 17
        }
      })));
    }

    return totalStars;
  }

  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "starsRating__single",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    }
  }, getStars());
};

/* harmony default export */ __webpack_exports__["a"] = (StarsRatingSingle);

/***/ }),

/***/ "./components/StarsRaing/StarsRatingSingle.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./node_modules/react-image-gallery/styles/css/image-gallery.css":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/HotelResults/HotelResultTemplate.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hotelResultTemplate", function() { return hotelResultTemplate; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_FilterBars_FilterBars__ = __webpack_require__("./components/FilterBars/FilterBars.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_date_fns__ = __webpack_require__("date-fns");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_date_fns___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_date_fns__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__components_Common_AlertMsgs__ = __webpack_require__("./components/Common/AlertMsgs/index.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components_Pagination__ = __webpack_require__("./pages/HotelResults/components/Pagination.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__components_HotelResultModify__ = __webpack_require__("./pages/HotelResults/components/HotelResultModify.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_HotelResultHeader__ = __webpack_require__("./pages/HotelResults/components/HotelResultHeader.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_HotelResultSortbar__ = __webpack_require__("./pages/HotelResults/components/HotelResultSortbar.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_HotelResultContainer__ = __webpack_require__("./pages/HotelResults/components/HotelResultContainer.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__components_HotelResultMap__ = __webpack_require__("./pages/HotelResults/components/HotelResultMap.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__components_NoHotelFilterResults__ = __webpack_require__("./pages/HotelResults/components/NoHotelFilterResults.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__components_MobileNavBar__ = __webpack_require__("./pages/HotelResults/components/MobileNavBar.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__components_apiError__ = __webpack_require__("./pages/HotelResults/components/apiError.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\pages\\HotelResults\\HotelResultTemplate.jsx";
 // eslint disable-next-line import/no-unresolved


 // eslint disable-next-line import/no-unresolved











/* harmony default export */ __webpack_exports__["default"] = (function (_ref) {
  var config = _ref.config,
      cultureCode = _ref.cultureCode,
      urlLocale = _ref.urlLocale,
      queryParams = _ref.queryParams,
      initialLoadingStyles = _ref.initialLoadingStyles,
      isPolling = _ref.isPolling,
      validateQueryString = _ref.validateQueryString,
      hotelResults = _ref.hotelResults,
      handleOpenDropdown = _ref.handleOpenDropdown,
      openDropdownClass = _ref.openDropdownClass,
      filters = _ref.filters,
      handleChangeFilter = _ref.handleChangeFilter,
      handleInputRangeOnChange = _ref.handleInputRangeOnChange,
      handleResetFilter = _ref.handleResetFilter,
      handleOpenMobileItem = _ref.handleOpenMobileItem,
      openMobileItemClass = _ref.openMobileItemClass,
      filterChanged = _ref.filterChanged,
      progressStatus = _ref.progressStatus,
      handleSetPage = _ref.handleSetPage,
      handleToggleGallery = _ref.handleToggleGallery,
      handleToggleMapView = _ref.handleToggleMapView,
      toggleMapView = _ref.toggleMapView,
      hasError = _ref.hasError,
      getTotalPages = _ref.getTotalPages,
      handlGetMapHotel = _ref.handlGetMapHotel,
      apiCallbacks = _ref.apiCallbacks;

  // Displaying errors for query strings
  function generateErrors() {
    return Object.values(validateQueryString).map(function (value, index) {
      if (!value.status) {
        return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__components_Common_AlertMsgs__["a" /* default */], {
          key: index,
          msgType: "danger",
          msg: value.message,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 54
          }
        });
      }
    });
  }

  var totalPage = getTotalPages(hotelResults.hotels.totalHotels, hotelResults.pageSize); // Get maxPrice for filter price input range

  var maxPrice = 0;
  var isDisabled = true;
  var nightCount = 0;
  var packageDetails = hotelResults.hotels.package;

  if (hotelResults.isComplete) {
    // Settibg the maxPrice for filters, based on features
    maxPrice = config.features.useTotalPrice ? hotelResults.hotels.filter.maxPricePackage : hotelResults.hotels.filter.maxPricePerson; // To disable the components blocked during polling

    isDisabled = false; // To calculate the number of nights

    var _hotelResults$hotels$ = hotelResults.hotels.package,
        checkInDate = _hotelResults$hotels$.checkInDate,
        checkOutDate = _hotelResults$hotels$.checkOutDate;
    nightCount = Object(__WEBPACK_IMPORTED_MODULE_2_date_fns__["differenceInDays"])(checkOutDate, checkInDate);
  }

  var callbackText = '';
  var errorType = '';

  if (apiCallbacks) {
    // Assigning texts based on api callback error status
    if (apiCallbacks.response.status >= 400 && apiCallbacks.response.status < 500) {
      callbackText = 'Wrong search input have been entered. Please search again.';
      errorType = 'client';
    } else if (apiCallbacks.response.status >= 500 && apiCallbacks.response.status < 600) {
      callbackText = 'There must be something wrong with the server. Sorry for the inconvenience caused.';
      errorType = 'server';
    }
  }

  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 94
    }
  }, !(errorType === 'server') && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__components_HotelResultModify__["a" /* default */], {
    config: config.general,
    handleOpenMobileItem: handleOpenMobileItem,
    packageDetails: packageDetails,
    isDisabled: isDisabled,
    toggleMapView: toggleMapView,
    validateQueryString: validateQueryString,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 96
    }
  }), !hasError && !apiCallbacks && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Fragment, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 107
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__components_MobileNavBar__["a" /* default */], {
    handleOpenMobileItem: handleOpenMobileItem,
    isDisabled: isDisabled,
    toggleMapView: toggleMapView,
    handleToggleMapView: handleToggleMapView,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 108
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__components_HotelResultHeader__["a" /* default */], {
    progressStatus: progressStatus,
    queryParams: queryParams,
    initialLoadingStyles: initialLoadingStyles,
    isComplete: hotelResults.isComplete,
    handleOpenMobileItem: handleOpenMobileItem,
    isPolling: isPolling,
    packageDetails: packageDetails,
    handleToggleMapView: handleToggleMapView,
    toggleMapView: toggleMapView,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 114
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components_FilterBars_FilterBars__["a" /* default */], {
    currency: config.general.defaultCurrency,
    isDisabled: isDisabled,
    isPolling: isPolling,
    handleOpenDropdown: handleOpenDropdown,
    openDropdownClass: openDropdownClass,
    filters: filters,
    handleChangeFilter: handleChangeFilter,
    handleInputRangeOnChange: handleInputRangeOnChange,
    maxPrice: maxPrice,
    handleOpenMobileItem: handleOpenMobileItem,
    openMobileItemClass: openMobileItemClass,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 125
    }
  }), !toggleMapView && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_HotelResultSortbar__["a" /* default */], {
    isDisabled: isDisabled,
    isPolling: isPolling,
    sort: filters.sortBy,
    handleChangeFilter: handleChangeFilter,
    handleOpenMobileItem: handleOpenMobileItem,
    openMobileItemClass: openMobileItemClass,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 139
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 151
    }
  }, generateErrors()), !hasError && !apiCallbacks && (!toggleMapView && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Fragment, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 156
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_HotelResultContainer__["a" /* default */], {
    initialLoadingStyles: initialLoadingStyles,
    validateQueryString: validateQueryString,
    hotelResults: hotelResults,
    config: config,
    nightCount: nightCount,
    cultureCode: cultureCode,
    urlLocale: urlLocale,
    filterChanged: filterChanged,
    handleResetFilter: handleResetFilter,
    isDisabled: isDisabled,
    handleToggleGallery: handleToggleGallery,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 157
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__components_Pagination__["a" /* default */], {
    handleSetPage: handleSetPage,
    totalPages: totalPage,
    currentPage: hotelResults.currentPage,
    isDisabled: isDisabled,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 170
    }
  })) || __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__components_HotelResultMap__["a" /* default */], {
    hotelResults: hotelResults,
    handlGetMapHotel: handlGetMapHotel,
    useTotalPrice: config.features.useTotalPrice,
    nightCount: nightCount,
    cultureCode: cultureCode,
    defaultCurrency: config.general.defaultCurrency,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 178
    }
  })) || __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__components_apiError__["a" /* default */], {
    callbackText: callbackText,
    errorType: errorType,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 187
    }
  }));
});
var hotelResultTemplate = __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
  __source: {
    fileName: _jsxFileName,
    lineNumber: 198
  }
}, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__components_MobileNavBar__["a" /* default */], {
  handleOpenMobileItem: {},
  isDisabled: true,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 200
  }
}), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__components_HotelResultHeader__["a" /* default */], {
  initialLoadingStyles: {},
  __source: {
    fileName: _jsxFileName,
    lineNumber: 201
  }
}), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components_FilterBars_FilterBars__["a" /* default */], {
  __source: {
    fileName: _jsxFileName,
    lineNumber: 202
  }
}), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_HotelResultSortbar__["a" /* default */], {
  __source: {
    fileName: _jsxFileName,
    lineNumber: 203
  }
}), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_HotelResultContainer__["a" /* default */], {
  initialLoadingStyles: {},
  hotelLists: {},
  __source: {
    fileName: _jsxFileName,
    lineNumber: 204
  }
}));

/***/ }),

/***/ "./pages/HotelResults/HotelResults.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/HotelResults/actions.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return actionTypes; });
/* harmony export (immutable) */ __webpack_exports__["e"] = failure;
/* unused harmony export getClientConfigData */
/* unused harmony export getClientConfigDataSuccess */
/* unused harmony export createPackage */
/* harmony export (immutable) */ __webpack_exports__["d"] = createPackageSuccess;
/* harmony export (immutable) */ __webpack_exports__["c"] = createPackageFailed;
/* harmony export (immutable) */ __webpack_exports__["f"] = getFilteredHotels;
/* harmony export (immutable) */ __webpack_exports__["k"] = getMapHotel;
/* harmony export (immutable) */ __webpack_exports__["m"] = getMapHotelsSuccess;
/* harmony export (immutable) */ __webpack_exports__["l"] = getMapHotelsFailed;
/* harmony export (immutable) */ __webpack_exports__["n"] = pollStartAction;
/* harmony export (immutable) */ __webpack_exports__["o"] = pollStopAction;
/* harmony export (immutable) */ __webpack_exports__["j"] = getHotelsSuccess;
/* harmony export (immutable) */ __webpack_exports__["i"] = getHotelsFailed;
/* harmony export (immutable) */ __webpack_exports__["b"] = changeFilter;
/* harmony export (immutable) */ __webpack_exports__["p"] = resetFilter;
/* harmony export (immutable) */ __webpack_exports__["r"] = toggleGallery;
/* harmony export (immutable) */ __webpack_exports__["g"] = getHotelGallery;
/* harmony export (immutable) */ __webpack_exports__["h"] = getHotelGallerySuccess;
/* harmony export (immutable) */ __webpack_exports__["q"] = setPage;
var actionTypes = {
  FAILURE: 'FAILURE',
  GET_CLIENT_CONFIG: 'GET_CLIENT_CONFIG',
  GET_CLIENT_CONFIG_SUCCESS: 'GET_CLIENT_CONFIG_SUCCESS',
  CREATE_PACKAGE: 'CREATE_PACKAGE',
  CREATE_PACKAGE_SUCCESS: 'CREATE_PACKAGE_SUCCESS',
  CREATE_PACKAGE_FAILED: 'CREATE_PACKAGE_FAILED',
  GET_FILTERED_HOTELS: 'GET_FILTERED_HOTELS',
  HOTEL_RESULT_POLL_START: 'HOTEL_RESULT_POLL_START',
  HOTEL_RESULT_POLL_STOP: 'HOTEL_RESULT_POLL_STOP',
  GET_HOTELS_SUCCESS: 'GET_HOTELS_SUCCESS',
  GET_HOTELS_FAILED: 'GET_HOTELS_FAILED',
  CHANGE_FILTER: 'CHANGE_FILTER',
  RESET_FILTER: 'RESET_FILTER',
  SET_PAGE: 'SET_PAGE',
  TOGGLE_GALLERY_HL: 'TOGGLE_GALLERY_HL',
  GET_HOTEL_GALLERY_HL: 'GET_HOTEL_GALLERY_HL',
  GET_HOTEL_GALLERY_SUCCESS_HL: 'GET_HOTEL_GALLERY_SUCCESS_HL',
  GET_MAP_HOTEL: 'GET_MAP_HOTEL',
  GET_MAP_HOTEL_SUCCESS: 'GET_MAP_HOTEL_SUCCESS',
  GET_MAP_HOTEL_FAILED: 'GET_MAP_HOTEL_FAILED'
};
function failure(error) {
  return {
    type: actionTypes.FAILURE,
    error: error
  };
}
function getClientConfigData() {
  return {
    type: actionTypes.GET_CLIENT_CONFIG
  };
}
function getClientConfigDataSuccess(data) {
  return {
    type: actionTypes.GET_CLIENT_CONFIG_SUCCESS,
    data: data
  };
}
function createPackage(query) {
  return {
    type: actionTypes.CREATE_PACKAGE,
    query: query
  };
}
function createPackageSuccess(packageId, percent) {
  return {
    type: actionTypes.CREATE_PACKAGE_SUCCESS,
    data: packageId,
    percent: percent
  };
}
function createPackageFailed(callbacks) {
  return {
    type: actionTypes.CREATE_PACKAGE_FAILED,
    data: callbacks
  };
}
function getFilteredHotels(packageId, hotelApiQuery, percent) {
  return {
    type: actionTypes.GET_FILTERED_HOTELS,
    data: {
      packageId: packageId,
      hotelApiQuery: hotelApiQuery,
      percent: percent
    }
  };
}
function getMapHotel(coordinates) {
  return {
    type: actionTypes.GET_MAP_HOTEL,
    data: coordinates
  };
}
function getMapHotelsSuccess(hotels) {
  return {
    type: actionTypes.GET_MAP_HOTEL_SUCCESS,
    data: hotels
  };
}
function getMapHotelsFailed(callbacks) {
  return {
    type: actionTypes.GET_MAP_HOTEL_FAILED,
    data: callbacks
  };
}
function pollStartAction(_ref) {
  var payload = _ref.payload;
  return {
    type: actionTypes.HOTEL_RESULT_POLL_START,
    payload: payload
  };
}
function pollStopAction(percent, total) {
  var totalHotels = parseInt(total, 10);
  return {
    type: actionTypes.HOTEL_RESULT_POLL_STOP,
    percent: percent,
    totalHotels: totalHotels
  };
}
function getHotelsSuccess(hotels, percent) {
  return {
    type: actionTypes.GET_HOTELS_SUCCESS,
    data: hotels,
    percent: percent
  };
}
function getHotelsFailed(callbacks) {
  return {
    type: actionTypes.GET_HOTELS_FAILED,
    data: callbacks
  };
}
function changeFilter(filters) {
  return {
    type: actionTypes.CHANGE_FILTER,
    data: filters
  };
}
function resetFilter(filters) {
  return {
    type: actionTypes.RESET_FILTER,
    data: filters
  };
}
function toggleGallery(data) {
  return {
    type: actionTypes.TOGGLE_GALLERY_HL,
    data: data
  };
}
function getHotelGallery(hotelId) {
  return {
    type: actionTypes.GET_HOTEL_GALLERY_HL,
    hotelId: hotelId
  };
}
function getHotelGallerySuccess(data) {
  return {
    type: actionTypes.GET_HOTEL_GALLERY_SUCCESS_HL,
    data: data
  };
}
function setPage(currentPage) {
  return {
    type: actionTypes.SET_PAGE,
    currentPage: currentPage
  };
}

/***/ }),

/***/ "./pages/HotelResults/components/HotelResultContainer.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__HotelResultList__ = __webpack_require__("./pages/HotelResults/components/HotelResultList.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__HotelResultContainer_scss__ = __webpack_require__("./pages/HotelResults/components/HotelResultContainer.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__HotelResultContainer_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__HotelResultContainer_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\pages\\HotelResults\\components\\HotelResultContainer.jsx";
 // eslint disable-next-line import/no-unresolved




var HotelResultContainer = function HotelResultContainer(_ref) {
  var initialLoadingStyles = _ref.initialLoadingStyles,
      hotelResults = _ref.hotelResults,
      config = _ref.config,
      cultureCode = _ref.cultureCode,
      urlLocale = _ref.urlLocale,
      filterChanged = _ref.filterChanged,
      handleResetFilter = _ref.handleResetFilter,
      isDisabled = _ref.isDisabled,
      handleToggleGallery = _ref.handleToggleGallery,
      nightCount = _ref.nightCount;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 20
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__HotelResultList__["a" /* default */], {
    initialLoadingStyles: initialLoadingStyles,
    hotelResults: hotelResults,
    config: config,
    cultureCode: cultureCode,
    urlLocale: urlLocale,
    filterChanged: filterChanged,
    handleResetFilter: handleResetFilter,
    isDisabled: isDisabled,
    handleToggleGallery: handleToggleGallery,
    nightCount: nightCount,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 21
    }
  }));
};

/* harmony default export */ __webpack_exports__["a"] = (HotelResultContainer);

/***/ }),

/***/ "./pages/HotelResults/components/HotelResultContainer.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/HotelResults/components/HotelResultHeader.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_intl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__components_Progress_ProgressBar__ = __webpack_require__("./components/Progress/ProgressBar.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_icons_io__ = __webpack_require__("react-icons/io");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_icons_io___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_icons_io__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_md__ = __webpack_require__("react-icons/md");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_md___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_icons_md__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__HotelResultHeader_scss__ = __webpack_require__("./pages/HotelResults/components/HotelResultHeader.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__HotelResultHeader_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__HotelResultHeader_scss__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__utils_initialLoading__ = __webpack_require__("./utils/initialLoading.js");
var _jsxFileName = "C:\\Projects\\frontend\\pages\\HotelResults\\components\\HotelResultHeader.jsx";








var HotelResultHeader = function HotelResultHeader(_ref) {
  var initialLoadingStyles = _ref.initialLoadingStyles,
      progressStatus = _ref.progressStatus,
      isPolling = _ref.isPolling,
      packageDetails = _ref.packageDetails,
      isComplete = _ref.isComplete,
      handleToggleMapView = _ref.handleToggleMapView,
      toggleMapView = _ref.toggleMapView;

  if (Object.keys(initialLoadingStyles).length === 0) {
    initialLoadingStyles = Object(__WEBPACK_IMPORTED_MODULE_6__utils_initialLoading__["a" /* default */])(true);
  }

  var disableBtn = !isComplete ? 'btn-disabled' : '';
  var _initialLoadingStyles = initialLoadingStyles,
      textLoading = _initialLoadingStyles.textLoading,
      loadingState = _initialLoadingStyles.loadingState;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "headerNav__caption",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "headerNav__title",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("h1", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "hotelResultHeader.availablePackages",
    defaultMessage: "Available Packages",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    className: "headerNav__title__sub ".concat(!packageDetails ? textLoading : ''),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    }
  }, packageDetails && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "hotelResultHeader.From",
    defaultMessage: "From",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  }), "\xA0", packageDetails.originCityName, "\xA0", __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "hotelResultHeader.to",
    defaultMessage: "to",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    }
  }), "\xA0", packageDetails.destinationCityName, "\xA0") || loadingState && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 57
    }
  }, '-----------------------'))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "headerNav__progress",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64
    }
  }, progressStatus && isPolling && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__components_Progress_ProgressBar__["a" /* default */], {
    progressStatus: progressStatus,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 66
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "headerNav__button ".concat(disableBtn ? 'headerNav--overlay' : '', " "),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 69
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("button", {
    type: "button",
    className: "".concat(disableBtn, " btn-icon-right button btn-theme-secondary btn-secondary-outline"),
    onClick: function onClick() {
      handleToggleMapView();
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 70
    }
  }, toggleMapView && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Fragment, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 76
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 77
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "hotelResultHeader.listView",
    defaultMessage: "List View",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 78
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 83
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_icons_md__["MdFormatListBulleted"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 84
    }
  }))) || __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Fragment, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 88
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 89
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "hotelResultHeader.mapView",
    defaultMessage: "Map View",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 90
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 95
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_icons_io__["IoIosMap"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 96
    }
  })))))));
};

/* harmony default export */ __webpack_exports__["a"] = (HotelResultHeader);

/***/ }),

/***/ "./pages/HotelResults/components/HotelResultHeader.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/HotelResults/components/HotelResultList.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_next_link__ = __webpack_require__("next/link");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_next_link___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_next_link__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__HotelResultListItem__ = __webpack_require__("./pages/HotelResults/components/HotelResultListItem.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__NoHotelFilterResults__ = __webpack_require__("./pages/HotelResults/components/NoHotelFilterResults.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__HotelResultList_scss__ = __webpack_require__("./pages/HotelResults/components/HotelResultList.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__HotelResultList_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4__HotelResultList_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\pages\\HotelResults\\components\\HotelResultList.jsx";






var HotelResultList = function HotelResultList(_ref) {
  var initialLoadingStyles = _ref.initialLoadingStyles,
      hotelResults = _ref.hotelResults,
      handleResetFilter = _ref.handleResetFilter,
      filterChanged = _ref.filterChanged,
      config = _ref.config,
      cultureCode = _ref.cultureCode,
      urlLocale = _ref.urlLocale,
      isDisabled = _ref.isDisabled,
      handleToggleGallery = _ref.handleToggleGallery,
      nightCount = _ref.nightCount;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "hotelResult",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    }
  }, hotelResults && ((hotelResults.hotels.inComplete || hotelResults.hotels.isComplete) && hotelResults.hotels.hotels.map(function (hotel) {
    var languageCode = urlLocale ? "".concat(urlLocale) : '';
    return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("a", {
      href: "".concat(languageCode).concat(hotel.url),
      key: hotel.hotelId,
      target: "blank",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 32
      }
    }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__HotelResultListItem__["a" /* default */], {
      config: config,
      cultureCode: cultureCode,
      initialLoadingStyles: initialLoadingStyles,
      hotel: hotel,
      isDisabled: isDisabled,
      handleToggleGallery: handleToggleGallery,
      isGalleryOpen: hotelResults.isGalleryOpen,
      hotelImages: hotelResults.hotelImages,
      paxCount: hotelResults.hotels.package.paxCount,
      nightCount: nightCount,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 33
      }
    }));
  }) || filterChanged && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__NoHotelFilterResults__["a" /* default */], {
    handleResetFilter: handleResetFilter,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    }
  })) || __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__HotelResultListItem__["a" /* default */], {
    initialLoadingStyles: {},
    config: {},
    __source: {
      fileName: _jsxFileName,
      lineNumber: 56
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__HotelResultListItem__["a" /* default */], {
    initialLoadingStyles: {},
    config: {},
    __source: {
      fileName: _jsxFileName,
      lineNumber: 57
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__HotelResultListItem__["a" /* default */], {
    initialLoadingStyles: {},
    config: {},
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__HotelResultListItem__["a" /* default */], {
    initialLoadingStyles: {},
    config: {},
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__HotelResultListItem__["a" /* default */], {
    initialLoadingStyles: {},
    config: {},
    __source: {
      fileName: _jsxFileName,
      lineNumber: 60
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__HotelResultListItem__["a" /* default */], {
    initialLoadingStyles: {},
    config: {},
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__HotelResultListItem__["a" /* default */], {
    initialLoadingStyles: {},
    config: {},
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__HotelResultListItem__["a" /* default */], {
    initialLoadingStyles: {},
    config: {},
    __source: {
      fileName: _jsxFileName,
      lineNumber: 63
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__HotelResultListItem__["a" /* default */], {
    initialLoadingStyles: {},
    config: {},
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64
    }
  }))));
};

/* harmony default export */ __webpack_exports__["a"] = (HotelResultList);

/***/ }),

/***/ "./pages/HotelResults/components/HotelResultList.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/HotelResults/components/HotelResultListItem.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_intl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__HotelResultListItem_scss__ = __webpack_require__("./pages/HotelResults/components/HotelResultListItem.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__HotelResultListItem_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__HotelResultListItem_scss__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_icons_fa__ = __webpack_require__("react-icons/fa");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_icons_fa___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_icons_fa__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_md__ = __webpack_require__("react-icons/md");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_md___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_icons_md__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_react_icons_io__ = __webpack_require__("react-icons/io");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_react_icons_io___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_react_icons_io__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_Price_HotelDetailPrice__ = __webpack_require__("./components/Price/HotelDetailPrice.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_ReviewRating_ReviewRating__ = __webpack_require__("./components/ReviewRating/ReviewRating.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_Common_Gallery__ = __webpack_require__("./components/Common/Gallery/index.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__components_StarsRaing_StarsRatingSingle__ = __webpack_require__("./components/StarsRaing/StarsRatingSingle.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__components_Common_Spinner__ = __webpack_require__("./components/Common/Spinner/index.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__utils_initialLoading__ = __webpack_require__("./utils/initialLoading.js");
var _jsxFileName = "C:\\Projects\\frontend\\pages\\HotelResults\\components\\HotelResultListItem.jsx";













var HotelResultListItem = function HotelResultListItem(_ref) {
  var initialLoadingStyles = _ref.initialLoadingStyles,
      hotel = _ref.hotel,
      config = _ref.config,
      cultureCode = _ref.cultureCode,
      isDisabled = _ref.isDisabled,
      handleToggleGallery = _ref.handleToggleGallery,
      isGalleryOpen = _ref.isGalleryOpen,
      hotelImages = _ref.hotelImages,
      paxCount = _ref.paxCount,
      nightCount = _ref.nightCount;
  var savings = false;

  if (Object.keys(initialLoadingStyles).length === 0) {
    initialLoadingStyles = Object(__WEBPACK_IMPORTED_MODULE_11__utils_initialLoading__["a" /* default */])(true);
  }

  var _initialLoadingStyles = initialLoadingStyles,
      contentLoading = _initialLoadingStyles.contentLoading,
      loadingState = _initialLoadingStyles.loadingState,
      textLoading = _initialLoadingStyles.textLoading;
  var disableBtn = isDisabled ? 'btn-disabled' : '';
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "hotelResult__item",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "hotelResult__picture",
    onClick: function onClick(e) {
      handleToggleGallery(e, true, hotel.hotelId);
    },
    onKeyPress: function onKeyPress(e) {
      handleToggleGallery(e, true, hotel.hotelId);
    },
    role: "button",
    tabIndex: 0,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  }, hotelImages && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_Common_Gallery__["a" /* default */], {
    isGalleryOpen: isGalleryOpen,
    handleToggleGallery: handleToggleGallery,
    galleryItems: hotelImages,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "hotelResult__picture__image",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    }
  }, loadingState && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__components_Common_Spinner__["a" /* default */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    }
  }) || // to be replaced with a new image not available
  __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("img", {
    className: "",
    src: hotel.image ? hotel.image : 'https://www.toadandco.com/c.1311986/sca-dev-elbrus/img/no_image_available.jpeg',
    onError: function onError(e) {
      e.target.src = 'https://www.toadandco.com/c.1311986/sca-dev-elbrus/img/no_image_available.jpeg';
    },
    alt: hotel.name || '',
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    }
  }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "hotelResult__detail",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 74
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 75
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "hotelResult__title",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 76
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("h2", {
    className: "title ".concat(textLoading),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 77
    }
  }, hotel ? hotel.name : 'Hotel the Celestine Tokyo Shiba'), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 81
    }
  }, !loadingState && hotel.stars > 0 && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__components_StarsRaing_StarsRatingSingle__["a" /* default */], {
    stars: hotel.stars,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 83
    }
  }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "hotelResult__location ".concat(textLoading),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 87
    }
  }, loadingState && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 89
    }
  }, '-------------------------------------------') || hotel && hotel.location.area && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Fragment, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 94
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 95
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_icons_fa__["FaMapMarkerAlt"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 96
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "hotelResult__location__text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 98
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 99
    }
  }, hotel.location.area)))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "hotelResult__location ".concat(textLoading),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 115
    }
  }, loadingState && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 117
    }
  }, '-------------------------------------------') || hotel && hotel.location.distanceAirport && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Fragment, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 122
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 123
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_icons_md__["MdBusiness"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 124
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "hotelResult__location__text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 126
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 127
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "hotelResultListItem.distanceCity",
    defaultMessage: '{distance}km from city center',
    values: {
      distance: hotel.location.distanceCity
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 128
    }
  })))))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "locationRating ".concat(textLoading),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 140
    }
  }, hotel && hotel.rating.locationText && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "locationRating__wrapper",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 142
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    className: "icon-badge--small",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 143
    }
  }), hotel.rating.locationText && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Fragment, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 146
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "hotelResultListItem.locationText",
    defaultMessage: '{rating}',
    values: {
      rating: hotel ? hotel.rating.locationText : '&nbsp;'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 147
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 152
    }
  }))), hotel && hotel.rating.locationNearby && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "locationRating__wrapper",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 158
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    className: "icon-badge--small",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 159
    }
  }), hotel.rating.locationNearby && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "hotelResultListItem.locationNearby",
    defaultMessage: '{rating}',
    values: {
      rating: hotel ? hotel.rating.locationNearby : '&nbsp;'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 162
    }
  })))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "hotelResult__control",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 173
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "hotelResult__control__row",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 174
    }
  }, !loadingState && hotel.rating.score > 0 && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_ReviewRating_ReviewRating__["a" /* default */], {
    data: hotel.rating,
    position: "right",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 176
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "hotelResult__control__row",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 180
    }
  }, hotel && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__components_Price_HotelDetailPrice__["a" /* default */], {
    initialLoadingStyles: initialLoadingStyles,
    config: config,
    cultureCode: cultureCode,
    isDisabled: isDisabled,
    prices: hotel ? hotel.price : '',
    paxCount: paxCount,
    nightCount: nightCount,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 182
    }
  }) || __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "price",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 193
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "".concat(contentLoading),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 194
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "HotelResultPrice",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 195
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "price__old",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 196
    }
  }, "--------------"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "price__now theme-primary-text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 199
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("small", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 200
    }
  }, "-----"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("b", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 203
    }
  }, "----------------")))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "".concat(textLoading, " price__note"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 209
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 210
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "hotelResultListItem.totalPriceForPeople",
    defaultMessage: 'total  price for {count} people',
    values: {
      count: '4'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 211
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 217
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "hotelResultListItem.includingTaxesAndFees",
    defaultMessage: "including taxes & fees",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 218
    }
  })))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "hotelResult__button",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 229
    }
  }, hotel && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("button", {
    className: "btn btn-lg btn-primary btn-theme-primary btn-uppercase btn-block ".concat(disableBtn),
    type: "button",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 231
    }
  }, "Select")))));
};

/* harmony default export */ __webpack_exports__["a"] = (HotelResultListItem);

/***/ }),

/***/ "./pages/HotelResults/components/HotelResultListItem.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/HotelResults/components/HotelResultMap.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_next_dynamic__ = __webpack_require__("next/dynamic");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_next_dynamic___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_next_dynamic__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__HotelResultMap_scss__ = __webpack_require__("./pages/HotelResults/components/HotelResultMap.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__HotelResultMap_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__HotelResultMap_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\pages\\HotelResults\\components\\HotelResultMap.jsx";



var Map = __WEBPACK_IMPORTED_MODULE_1_next_dynamic___default()( false ? new (require('next/dynamic').SameLoopPromise)(function (resolve, reject) {
  eval('require.ensure = function (deps, callback) { callback(require) }');

  require.ensure([], function (require) {
    var m = require("./HotelResultMapItem");

    m.__webpackChunkName = 'pages_HotelResults_components_HotelResultMapItem_8f5b1a572c60660ba1a9a6cc7d217790.js';
    resolve(m);
  }, 'chunks/pages_HotelResults_components_HotelResultMapItem_8f5b1a572c60660ba1a9a6cc7d217790.js');
}) : new (__webpack_require__("next/dynamic").SameLoopPromise)(function (resolve, reject) {
  var weakId = /*require.resolve*/("./pages/HotelResults/components/HotelResultMapItem.jsx");

  try {
    var weakModule = __webpack_require__(weakId);

    return resolve(weakModule);
  } catch (err) {}

  __webpack_require__.e/* require.ensure */(5).then((function (require) {
    try {
      var m = __webpack_require__("./pages/HotelResults/components/HotelResultMapItem.jsx");

      m.__webpackChunkName = 'pages_HotelResults_components_HotelResultMapItem_8f5b1a572c60660ba1a9a6cc7d217790';
      resolve(m);
    } catch (error) {
      reject(error);
    }
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
}),  false ? new (require('next/dynamic').SameLoopPromise)(function (resolve, reject) {
  eval('require.ensure = function (deps, callback) { callback(require) }');

  require.ensure([], function (require) {
    var m = require("./HotelResultMapItem.scss");

    m.__webpackChunkName = 'pages_HotelResults_components_HotelResultMapItem_scss_22cff17f161923bf622b017b1d9e28fb.js';
    resolve(m);
  }, 'chunks/pages_HotelResults_components_HotelResultMapItem_scss_22cff17f161923bf622b017b1d9e28fb.js');
}) : new (__webpack_require__("next/dynamic").SameLoopPromise)(function (resolve, reject) {
  var weakId = /*require.resolve*/("./pages/HotelResults/components/HotelResultMapItem.scss");

  try {
    var weakModule = __webpack_require__(weakId);

    return resolve(weakModule);
  } catch (err) {}

  __webpack_require__.e/* require.ensure */(6).then((function (require) {
    try {
      var m = __webpack_require__("./pages/HotelResults/components/HotelResultMapItem.scss");

      m.__webpackChunkName = 'pages_HotelResults_components_HotelResultMapItem_scss_22cff17f161923bf622b017b1d9e28fb';
      resolve(m);
    } catch (error) {
      reject(error);
    }
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
}), {
  ssr: false
}); // let Map = null;

var HotelResultMap = function HotelResultMap(_ref) {
  var defaultCurrency = _ref.defaultCurrency,
      cultureCode = _ref.cultureCode,
      hotelResults = _ref.hotelResults,
      handlGetMapHotel = _ref.handlGetMapHotel,
      useTotalPrice = _ref.useTotalPrice,
      nightCount = _ref.nightCount;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "container no-padding-on-small",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "hotel-result-map",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    }
  }, hotelResults && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Map, {
    hotels: hotelResults.hotels,
    handlGetMapHotel: handlGetMapHotel,
    useTotalPrice: useTotalPrice,
    nightCount: nightCount,
    cultureCode: cultureCode,
    defaultCurrency: defaultCurrency,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  })));
};

/* harmony default export */ __webpack_exports__["a"] = (HotelResultMap);

/***/ }),

/***/ "./pages/HotelResults/components/HotelResultMap.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/HotelResults/components/HotelResultModify.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_io__ = __webpack_require__("react-icons/io");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_io___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_icons_io__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_icons_md__ = __webpack_require__("react-icons/md");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_icons_md___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_icons_md__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_icons_ti__ = __webpack_require__("react-icons/ti");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_icons_ti___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_icons_ti__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_intl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__components_DateFormat__ = __webpack_require__("./components/DateFormat/index.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_SearchForm__ = __webpack_require__("./components/SearchForm/index.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__HotelResultModify_scss__ = __webpack_require__("./pages/HotelResults/components/HotelResultModify.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__HotelResultModify_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__HotelResultModify_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\pages\\HotelResults\\components\\HotelResultModify.jsx";









var HotelResultModify = function HotelResultModify(_ref) {
  var config = _ref.config,
      cultureCode = _ref.cultureCode,
      packageDetails = _ref.packageDetails,
      validateQueryString = _ref.validateQueryString;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "headerNav",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 20
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "headerNav__mobile",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 21
    }
  }, packageDetails && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "headerNav__mobile__text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("strong", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_intl__["FormattedMessage"], {
    id: "hotelResultListItem.From",
    defaultMessage: "From",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    }
  }), "\xA0", packageDetails.originCityName, "\xA0", __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_intl__["FormattedMessage"], {
    id: "hotelResultListItem.to",
    defaultMessage: "to",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    }
  }), "\xA0", packageDetails.destinationCityName, "\xA0"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__components_DateFormat__["a" /* default */], {
    value: packageDetails.departureDate,
    format: 'SHORT',
    locale: "".concat(cultureCode),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  }), "\xA0", __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_intl__["FormattedMessage"], {
    id: "hotelResultListItem.to",
    defaultMessage: "to",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    }
  }), "\xA0", __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__components_DateFormat__["a" /* default */], {
    value: packageDetails.returnDate,
    format: 'SHORT',
    locale: "".concat(cultureCode),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    }
  }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "headerNav__mobile__button",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 63
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_icons_io__["IoIosSearch"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64
    }
  })))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "headerNav__modify panelMobile",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 68
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "panelMobile__title",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 69
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 70
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_icons_md__["MdArrowBack"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 71
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("strong", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 73
    }
  }, "Modify Search")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 77
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__components_SearchForm__["a" /* default */], {
    configSearchForm: config,
    validateQueryString: validateQueryString,
    packageDetails: packageDetails,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 78
    }
  }))));
};

/* harmony default export */ __webpack_exports__["a"] = (HotelResultModify);

/***/ }),

/***/ "./pages/HotelResults/components/HotelResultModify.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/HotelResults/components/HotelResultSortbar.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__HotelResultSortbar_scss__ = __webpack_require__("./pages/HotelResults/components/HotelResultSortbar.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__HotelResultSortbar_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__HotelResultSortbar_scss__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_icons_md__ = __webpack_require__("react-icons/md");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_icons_md___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_icons_md__);
var _jsxFileName = "C:\\Projects\\frontend\\pages\\HotelResults\\components\\HotelResultSortbar.jsx";




var HotelResultSortbar = function HotelResultSortbar(_ref) {
  var sort = _ref.sort,
      handleChangeFilter = _ref.handleChangeFilter,
      isDisabled = _ref.isDisabled,
      handleOpenMobileItem = _ref.handleOpenMobileItem,
      openMobileItemClass = _ref.openMobileItemClass;
  var disableClass = isDisabled ? 'disable-filters' : '';
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar panelMobile ".concat(openMobileItemClass === 'navbar-sort' ? 'is-open' : ''),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "panelMobile__title",
    onClick: function onClick(e) {
      handleOpenMobileItem(e, '');
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 19
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_icons_md__["MdArrowBack"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 20
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("strong", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 22
    }
  }, "Sort by")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__title",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, "Sort by")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "FilterBar__wrap",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "".concat(disableClass, " sortBar__list ").concat(isDisabled ? 'sortBar--overlay' : ''),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("a", {
    href: "#rcmd",
    className: "sortBar__item ".concat(sort === 'recommended' ? 'sortBar__item--active' : ''),
    onClick: function onClick() {
      handleChangeFilter({
        key: 'sortBy',
        value: 'recommended'
      });
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    }
  }, "Recommended", __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_icons_md__["MdDone"], {
    size: 16,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    }
  }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("a", {
    href: "#lth",
    className: "sortBar__item ".concat(sort === 'price' ? 'sortBar__item--active' : ''),
    onClick: function onClick() {
      handleChangeFilter({
        key: 'sortBy',
        value: 'price'
      });
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  }, "Low to high price", __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_icons_md__["MdDone"], {
    size: 16,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    }
  }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("a", {
    href: "#ncc",
    className: "sortBar__item ".concat(sort === 'cityCenter' ? 'sortBar__item--active' : ''),
    onClick: function onClick() {
      handleChangeFilter({
        key: 'sortBy',
        value: 'cityCenter'
      });
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    }
  }, "Nearest to city center", __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_icons_md__["MdDone"], {
    size: 16,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    }
  }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("a", {
    href: "#nta",
    className: "sortBar__item ".concat(sort === 'airport' ? 'link-theme-primary sortBar__item--active' : ''),
    onClick: function onClick() {
      handleChangeFilter({
        key: 'sortBy',
        value: 'airport'
      });
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    }
  }, "Nearest to airport", __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 71
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_icons_md__["MdDone"], {
    size: 16,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 72
    }
  }))))))));
};

/* harmony default export */ __webpack_exports__["a"] = (HotelResultSortbar);

/***/ }),

/***/ "./pages/HotelResults/components/HotelResultSortbar.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/HotelResults/components/MobileNavBar.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_intl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_icons_ti__ = __webpack_require__("react-icons/ti");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_icons_ti___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_icons_ti__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_icons_io__ = __webpack_require__("react-icons/io");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_icons_io___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_icons_io__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_md__ = __webpack_require__("react-icons/md");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_md___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_icons_md__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__MobileNavBar_scss__ = __webpack_require__("./pages/HotelResults/components/MobileNavBar.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__MobileNavBar_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__MobileNavBar_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\pages\\HotelResults\\components\\MobileNavBar.jsx";







var MobileNavBar = function MobileNavBar(_ref) {
  var handleOpenMobileItem = _ref.handleOpenMobileItem,
      isDisabled = _ref.isDisabled,
      toggleMapView = _ref.toggleMapView,
      handleToggleMapView = _ref.handleToggleMapView;
  var disableBar = isDisabled ? 'bar-disabled' : '';
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "mobile-nav-bar ".concat(disableBar),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 18
    }
  }, !toggleMapView && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("a", {
    className: "mobile-nav-bar__button btn-theme-secondary",
    href: "#sort",
    onClick: function onClick(e) {
      handleOpenMobileItem(e, 'navbar-sort', isDisabled);
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 20
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_icons_md__["MdSort"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }, "Sort")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("a", {
    className: "mobile-nav-bar__button btn-theme-secondary",
    href: "#filter",
    onClick: function onClick(e) {
      handleOpenMobileItem(e, 'navbar-filter', isDisabled);
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_icons_ti__["TiFilter"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  }, "Filter")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("a", {
    className: "mobile-nav-bar__button btn-theme-secondary",
    href: "#mapView",
    onClick: function onClick() {
      handleToggleMapView();
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  }, toggleMapView && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Fragment, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_icons_md__["MdFormatListBulleted"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "mobileNavBar.listView",
    defaultMessage: "List View",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 56
    }
  }))) || __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Fragment, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 63
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_icons_io__["IoIosMap"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 67
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "mobileNavBar.mapView",
    defaultMessage: "Map View",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 68
    }
  })))));
};

/* harmony default export */ __webpack_exports__["a"] = (MobileNavBar);

/***/ }),

/***/ "./pages/HotelResults/components/MobileNavBar.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/HotelResults/components/NoHotelFilterResults.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__NoHotelFilterResults_scss__ = __webpack_require__("./pages/HotelResults/components/NoHotelFilterResults.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__NoHotelFilterResults_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__NoHotelFilterResults_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\pages\\HotelResults\\components\\NoHotelFilterResults.jsx";



var NoHotelFilterResults = function NoHotelFilterResults(_ref) {
  var handleResetFilter = _ref.handleResetFilter;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "no-hotel-filters",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 9
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("p", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 10
    }
  }, "No Results found", __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 12
    }
  }), "We could find any packages matching your filters. Reset applied filters to see all results."), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("button", {
    type: "button",
    className: "button btn-theme-primary",
    onClick: function onClick() {
      handleResetFilter();
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 16
    }
  }, "RESET FILTERS"));
};

/* harmony default export */ __webpack_exports__["a"] = (NoHotelFilterResults);

/***/ }),

/***/ "./pages/HotelResults/components/NoHotelFilterResults.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/HotelResults/components/Pagination.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_io__ = __webpack_require__("react-icons/io");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_io___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_icons_io__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Pagination_scss__ = __webpack_require__("./pages/HotelResults/components/Pagination.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Pagination_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__Pagination_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\pages\\HotelResults\\components\\Pagination.jsx";




var Pagination = function Pagination(_ref) {
  var handleSetPage = _ref.handleSetPage,
      totalPages = _ref.totalPages,
      currentPage = _ref.currentPage,
      isDisabled = _ref.isDisabled;
  var disablePreviousBtn = currentPage <= 1 || isDisabled ? 'btn-disabled' : '';
  var disableNextBtn = currentPage >= totalPages || isDisabled ? 'btn-disabled' : '';
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "Pagination ".concat(isDisabled ? 'Pagination--overlay' : ''),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 16
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("button", {
    className: "".concat(disablePreviousBtn, " Pagination__button"),
    type: "button",
    onClick: function onClick() {
      handleSetPage('PREVIOUS');
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 17
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 18
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_icons_io__["IoMdArrowDropleft"], {
    size: 24,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 19
    }
  }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "Pagination__count",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 22
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    }
  }, "Page ".concat(currentPage, " of ").concat(totalPages))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("button", {
    className: "".concat(disableNextBtn, " Pagination__button"),
    type: "button",
    onClick: function onClick() {
      handleSetPage('NEXT');
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_icons_io__["IoMdArrowDropright"], {
    size: 24,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    }
  }))));
};

/* harmony default export */ __webpack_exports__["a"] = (Pagination);

/***/ }),

/***/ "./pages/HotelResults/components/Pagination.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/HotelResults/components/apiError.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__apiError_scss__ = __webpack_require__("./pages/HotelResults/components/apiError.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__apiError_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__apiError_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\pages\\HotelResults\\components\\apiError.jsx";



function ApiError(_ref) {
  var callbackText = _ref.callbackText;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 10
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("p", {
    className: "text-center",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11
    }
  }, callbackText));
}

/* harmony default export */ __webpack_exports__["a"] = (ApiError);

/***/ }),

/***/ "./pages/HotelResults/components/apiError.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/HotelResults/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_dynamic__ = __webpack_require__("next/dynamic");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_dynamic___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_next_dynamic__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_helmet__ = __webpack_require__("react-helmet");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_helmet___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_helmet__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_intl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__utils_initialLoading__ = __webpack_require__("./utils/initialLoading.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__utils_qsValidation__ = __webpack_require__("./utils/qsValidation.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__PageBase__ = __webpack_require__("./pages/PageBase/index.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__HotelResults_scss__ = __webpack_require__("./pages/HotelResults/HotelResults.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__HotelResults_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__HotelResults_scss__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__HotelResultTemplate__ = __webpack_require__("./pages/HotelResults/HotelResultTemplate.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__actions__ = __webpack_require__("./pages/HotelResults/actions.js");

var _jsxFileName = "C:\\Projects\\frontend\\pages\\HotelResults\\index.jsx";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }



 // import queryString from 'query-string';
// import querystring from 'querystring';

 // eslint disable-next-line import/no-unresolved







var HotelResultPage = __WEBPACK_IMPORTED_MODULE_2_next_dynamic___default()( false ? new (require('next/dynamic').SameLoopPromise)(function (resolve, reject) {
  eval('require.ensure = function (deps, callback) { callback(require) }');

  require.ensure([], function (require) {
    var m = require("./HotelResultTemplate");

    m.__webpackChunkName = 'pages_HotelResults_HotelResultTemplate_d509901e340a1e69d4d976526e4da1c5.js';
    resolve(m);
  }, 'chunks/pages_HotelResults_HotelResultTemplate_d509901e340a1e69d4d976526e4da1c5.js');
}) : new (__webpack_require__("next/dynamic").SameLoopPromise)(function (resolve, reject) {
  var weakId = /*require.resolve*/("./pages/HotelResults/HotelResultTemplate.jsx");

  try {
    var weakModule = __webpack_require__(weakId);

    return resolve(weakModule);
  } catch (err) {}

  new Promise(function(resolve) { resolve(); }).then((function (require) {
    try {
      var m = __webpack_require__("./pages/HotelResults/HotelResultTemplate.jsx");

      m.__webpackChunkName = 'pages_HotelResults_HotelResultTemplate_d509901e340a1e69d4d976526e4da1c5';
      resolve(m);
    } catch (error) {
      reject(error);
    }
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
}), {
  loading: function loading() {
    return __WEBPACK_IMPORTED_MODULE_9__HotelResultTemplate__["hotelResultTemplate"];
  },
  ssr: false
});

var HotelResults =
/*#__PURE__*/
function (_Component) {
  _inherits(HotelResults, _Component);

  function HotelResults(props) {
    var _this;

    _classCallCheck(this, HotelResults);

    _this = _possibleConstructorReturn(this, (HotelResults.__proto__ || Object.getPrototypeOf(HotelResults)).call(this, props));
    Object.defineProperty(_assertThisInitialized(_this), "getTotalPages", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(totalHotels, pageSize) {
        var totalPages = 0;

        if (totalHotels) {
          totalPages = Math.ceil(parseInt(totalHotels, 10) / pageSize);
        }

        return totalPages;
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleOpenMobileItem", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(e, _value, isDisabled) {
        e.stopPropagation();

        if (!isDisabled) {
          _this.setState({
            openMobileItemClass: _value
          });

          if (_value === 'navbar-mapView') {
            _this.setState({
              toggleMapView: true
            });
          }
        } else {
          _this.setState({
            openMobileItemClass: ''
          });
        }
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleChangeFilter", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(_value2) {
        var dispatch = _this.props.dispatch;

        if (_value2.key !== 'maxPrice') {
          _this.setState({
            inputRangeChangeDone: true
          });
        }

        dispatch(Object(__WEBPACK_IMPORTED_MODULE_10__actions__["b" /* changeFilter */])(_value2));
        return false;
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleInputRangeOnChange", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(_value3) {
        var dispatch = _this.props.dispatch;

        _this.setState({
          inputRangeChangeDone: true
        });

        _this.onUpdate({
          maxPrice: _value3
        });

        dispatch(Object(__WEBPACK_IMPORTED_MODULE_10__actions__["b" /* changeFilter */])(_value3));
        return false;
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleToggleMapView", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        var toggleMapView = _this.state.toggleMapView;

        _this.setState({
          toggleMapView: !toggleMapView
        });
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleResetFilter", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        var _this$props = _this.props,
            dispatch = _this$props.dispatch,
            hotelResults = _this$props.hotelResults,
            config = _this$props.config;
        var filter = {
          maxPrice: config.features.useTotalPrice ? hotelResults.hotels.filter.maxPricePackage : hotelResults.hotels.filter.maxPricePerson,
          minStars: 1,
          minReview: 0,
          name: '',
          sortBy: 'recommended'
        };
        dispatch(Object(__WEBPACK_IMPORTED_MODULE_10__actions__["p" /* resetFilter */])(filter));
        return false;
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleOpenDropdown", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(e, _value4, isDisabled) {
        var openDropdownClass = _this.state.openDropdownClass;
        e.stopPropagation();

        if (!isDisabled && _value4) {
          _this.setState({
            openDropdownClass: _value4
          });
        } else if (!isDisabled && openDropdownClass) {
          _this.setState({
            openDropdownClass: ''
          });
        }
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleSetPage", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(page) {
        var _this$props2 = _this.props,
            dispatch = _this$props2.dispatch,
            hotelResults = _this$props2.hotelResults;
        var currentPage = hotelResults.currentPage,
            pageSize = hotelResults.pageSize;
        var totalHotels = hotelResults.hotels.totalHotels;

        var totalPages = _this.getTotalPages(totalHotels, pageSize);

        if (page === 'NEXT') {
          if (currentPage < totalPages) {
            dispatch(Object(__WEBPACK_IMPORTED_MODULE_10__actions__["q" /* setPage */])(currentPage + 1));
          }
        } else if (page === 'PREVIOUS') {
          if (currentPage > 1) {
            dispatch(Object(__WEBPACK_IMPORTED_MODULE_10__actions__["q" /* setPage */])(currentPage - 1));
          }
        }
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "checkErrors", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(validateQueryString) {
        var isError = false;
        Object.values(validateQueryString).forEach(function (value) {
          // checks if there is any errors
          if (parseInt(value.status, 10) === 0) {
            isError = true;
          }
        });

        _this.setState({
          hasError: isError
        });

        return isError;
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleToggleGallery", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(e, _value5, hotelId) {
        e.stopPropagation();
        e.preventDefault();
        var dispatch = _this.props.dispatch; // value can either be true/false, to hide/show the gallery popup modal

        dispatch(Object(__WEBPACK_IMPORTED_MODULE_10__actions__["r" /* toggleGallery */])(_value5)); // to dispatch the action that retrieve the images, thumbnails and caption

        dispatch(Object(__WEBPACK_IMPORTED_MODULE_10__actions__["g" /* getHotelGallery */])(hotelId));
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleCreatePackage", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        var _this$props3 = _this.props,
            dispatch = _this$props3.dispatch,
            cultureCode = _this$props3.cultureCode,
            hotelResults = _this$props3.hotelResults,
            selectedCurrency = _this$props3.selectedCurrency,
            config = _this$props3.config,
            validatedQS = _this$props3.validatedQS;
        var defaultCurrency = config.general.defaultCurrency;
        var pageSize = hotelResults.pageSize,
            currentPage = hotelResults.currentPage;
        var currency = selectedCurrency || defaultCurrency; // Gets the validated query string
        // From getInitialProps

        var validOrigin = validatedQS.validOrigin,
            validDestination = validatedQS.validDestination,
            validDepartDate = validatedQS.validDepartDate,
            validReturnDate = validatedQS.validReturnDate,
            validPax = validatedQS.validPax;
        var roomsArray = []; // Array is needed for rooms in request body

        validPax.value.map(function (pax) {
          var room = {
            adults: pax.adults,
            // Children & childAge fallback to default value if not available
            children: pax.children.length || 0,
            childAge1: pax.children[0] || 0,
            childAge2: pax.children[1] || 0,
            childAge3: pax.children[2] || 0
          };
          roomsArray.push(room);
        }); // Collect all request body to create package

        var packageData = {
          from: validOrigin.value,
          to: validDestination.value,
          depart: validDepartDate.value,
          return: validReturnDate.value,
          rooms: roomsArray,
          currency: currency,
          lang: cultureCode
        }; // TODO get currency code from HOC

        dispatch(Object(__WEBPACK_IMPORTED_MODULE_10__actions__["n" /* pollStartAction */])({
          payload: {
            cultureCode: cultureCode,
            pageSize: pageSize,
            currentPage: currentPage,
            currency: currency,
            packageData: packageData
          }
        })); // To disable loading state

        _this.onUpdate({
          isLoading: false
        });
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleHotelApiQuery", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(queryType) {
        var _this$props4 = _this.props,
            hotelResults = _this$props4.hotelResults,
            config = _this$props4.config,
            dispatch = _this$props4.dispatch,
            selectedCurrency = _this$props4.selectedCurrency,
            cultureCode = _this$props4.cultureCode;
        var _config$general = config.general,
            defaultCurrency = _config$general.defaultCurrency,
            defaultLanguage = _config$general.defaultLanguage;
        var maxPriceType = config.features.useTotalPrice ? 'package' : 'person';
        var hotelApiQuery = {};
        hotelApiQuery.page = queryType === 'filters' ? 1 : hotelResults.currentPage;
        hotelApiQuery.pageSize = hotelResults.pageSize; // TODO get from config

        hotelApiQuery.maxPriceType = maxPriceType;
        hotelApiQuery.lang = cultureCode || defaultLanguage;
        hotelApiQuery.currency = selectedCurrency || defaultCurrency;
        hotelApiQuery.filters = hotelResults.filters;
        dispatch(Object(__WEBPACK_IMPORTED_MODULE_10__actions__["f" /* getFilteredHotels */])(hotelResults.packageId, hotelApiQuery));
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handlGetMapHotel", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(coordinates) {
        var _this$props5 = _this.props,
            config = _this$props5.config,
            hotelResults = _this$props5.hotelResults,
            dispatch = _this$props5.dispatch,
            selectedCurrency = _this$props5.selectedCurrency;
        var maxPriceType = config.features.useTotalPrice ? 'package' : 'person';
        var nwLon = coordinates.nwLon,
            nwLat = coordinates.nwLat,
            seLon = coordinates.seLon,
            seLat = coordinates.seLat;
        var _hotelResults$filters = hotelResults.filters,
            name = _hotelResults$filters.name,
            minStars = _hotelResults$filters.minStars,
            maxPrice = _hotelResults$filters.maxPrice,
            minReview = _hotelResults$filters.minReview;
        var _config$general2 = config.general,
            defaultCurrency = _config$general2.defaultCurrency,
            defaultLanguage = _config$general2.defaultLanguage;

        _this.setState({
          currentCoordinates: coordinates
        });

        var stringUrl = "nwLon=".concat(nwLon, "&nwLat=").concat(nwLat, "&seLon=").concat(seLon, "&seLat=").concat(seLat, "&name=").concat(name, "&minStars=").concat(minStars, "&maxPrice=").concat(maxPrice, "&maxPriceType=").concat(maxPriceType, "&minReview=").concat(minReview, "&lang=").concat(defaultLanguage, "&currency=").concat(selectedCurrency || defaultCurrency);
        dispatch(Object(__WEBPACK_IMPORTED_MODULE_10__actions__["k" /* getMapHotel */])(stringUrl));
      }
    });
    _this.state = {
      isLoading: true,
      validateQueryString: {},
      openDropdownClass: '',
      openMobileItemClass: '',
      maxPrice: 0,
      filterChanged: false,
      toggleMapView: false,
      hasError: false,
      currentCoordinates: {},
      inputRangeChangeDone: false
    };
    return _this;
  }

  _createClass(HotelResults, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _props = this.props,
          searchProps = _props.searchProps,
          validatedQS = _props.validatedQS;
      this.setState({
        validateQueryString: validatedQS
      });
      var error = this.checkErrors(validatedQS);

      if (!error) {
        this.handleCreatePackage(searchProps);
      }
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      var _state = this.state,
          maxPrice = _state.maxPrice,
          toggleMapView = _state.toggleMapView,
          currentCoordinates = _state.currentCoordinates,
          inputRangeChangeDone = _state.inputRangeChangeDone;
      var _props2 = this.props,
          config = _props2.config,
          hotelResults = _props2.hotelResults,
          selectedCurrency = _props2.selectedCurrency;

      if (hotelResults.isComplete && hotelResults.packageId && maxPrice === 0) {
        var price = config.features.useTotalPrice ? hotelResults.hotels.filter.maxPricePackage : hotelResults.hotels.filter.maxPricePerson;
        this.onUpdate({
          maxPrice: price
        });
        this.handleChangeFilter({
          key: 'maxPrice',
          value: price
        });
      }

      if (prevProps.hotelResults.filters !== hotelResults.filters && inputRangeChangeDone) {
        this.onUpdate({
          openDropdownClass: '',
          filterChanged: true
        });

        if (toggleMapView) {
          this.handlGetMapHotel(currentCoordinates);
        } else {
          this.handleHotelApiQuery('filters');
        }

        this.onUpdate({
          inputRangeChangeDone: false
        });
      }

      if (prevProps.hotelResults.currentPage !== hotelResults.currentPage) {
        this.handleHotelApiQuery();
      } // when user changes currency


      if (prevProps.selectedCurrency !== selectedCurrency && prevProps.selectedCurrency) {
        if (toggleMapView) {
          this.handlGetMapHotel(currentCoordinates);
        } else {
          this.handleHotelApiQuery();
        }
      }
    }
  }, {
    key: "onUpdate",
    value: function onUpdate(values) {
      this.setState(values);
    }
  }, {
    key: "render",
    value: function render() {
      // TODO: Check out on props validation, and best way to handle props
      var _props3 = this.props,
          config = _props3.config,
          searchProps = _props3.searchProps,
          hotelResults = _props3.hotelResults,
          cultureCode = _props3.cultureCode,
          urlLocale = _props3.urlLocale;
      var _state2 = this.state,
          isLoading = _state2.isLoading,
          validateQueryString = _state2.validateQueryString,
          openDropdownClass = _state2.openDropdownClass,
          openMobileItemClass = _state2.openMobileItemClass,
          filterChanged = _state2.filterChanged,
          toggleMapView = _state2.toggleMapView,
          hasError = _state2.hasError; // when SSR the hotelResults will not be avalialble

      var _ref = hotelResults.hotels.package || '',
          destinationCityName = _ref.destinationCityName;

      var destination = destinationCityName ? "in ".concat(destinationCityName) : '';
      var name = config.general.name;
      var apiCallbacks = hotelResults.apiCallbacks;
      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 406
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_intl__["FormattedMessage"], {
        id: "hotelResult.title",
        defaultMessage: "Flight + Hotel Packages",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 407
        }
      }, function (title) {
        return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_helmet__["Helmet"], {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 409
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("title", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 410
          }
        }, "".concat(title, " ").concat(destination, " | ").concat(name)));
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 416
        }
      }, config && (__WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(HotelResultPage, {
        config: config,
        cultureCode: cultureCode,
        urlLocale: urlLocale,
        queryParams: searchProps,
        initialLoadingStyles: Object(__WEBPACK_IMPORTED_MODULE_5__utils_initialLoading__["a" /* default */])(hotelResults.isUpdating ? hotelResults.isUpdating : isLoading),
        isPolling: hotelResults.isPolling,
        progressStatus: hotelResults.progressStatus,
        validateQueryString: validateQueryString,
        hotelResults: hotelResults,
        handleOpenDropdown: this.handleOpenDropdown,
        openDropdownClass: openDropdownClass,
        filters: hotelResults.filters,
        filterChanged: filterChanged,
        handleChangeFilter: this.handleChangeFilter,
        handleInputRangeOnChange: this.handleInputRangeOnChange,
        handleResetFilter: this.handleResetFilter,
        handleOpenMobileItem: this.handleOpenMobileItem,
        openMobileItemClass: openMobileItemClass,
        handleSetPage: this.handleSetPage,
        handleToggleGallery: this.handleToggleGallery,
        hasError: hasError,
        getTotalPages: this.getTotalPages,
        handleToggleMapView: this.handleToggleMapView,
        toggleMapView: toggleMapView,
        handlGetMapHotel: this.handlGetMapHotel,
        apiCallbacks: apiCallbacks,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 418
        }
      }) || __WEBPACK_IMPORTED_MODULE_9__HotelResultTemplate__["hotelResultTemplate"])));
    }
  }], [{
    key: "getInitialProps",
    value: function () {
      var _getInitialProps = _asyncToGenerator(
      /*#__PURE__*/
      __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee(_ref2) {
        var ctx, query, req, config, searchConfig, defaultConfig, checkConfig, check, searchProps, validatedQS;
        return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                ctx = _ref2.ctx;
                // Gets query params from url
                query = ctx.query, req = ctx.req;
                config = req.config; // const { query } = queryString.parseUrl(asPath);
                // const qs = asPath.split('?');
                // const queryPar = querystring.parse(qs[1]);
                // console.log(queryPar);
                // let { validateQueryString } = this.state;

                searchConfig = {
                  minBookingPeriod: config.general.minBookingPeriod,
                  maxBookingPeriod: config.general.maxBookingPeriod,
                  minBookingDays: config.general.minBookingDays,
                  maxBookingDays: config.general.maxBookingDays,
                  maxRooms: config.general.maxRooms,
                  maxPax: config.general.maxPax
                };
                defaultConfig = config;

                checkConfig = function checkConfig() {
                  var checkedConfig = {};

                  if (!searchConfig) {
                    console.log('No config file available, using default initial state', 'background: red; color: #fff');
                    checkedConfig = defaultConfig;
                    return checkedConfig;
                  }

                  Object.keys(defaultConfig.general).forEach(function (key) {
                    if (Number.isNaN(defaultConfig[key])) {
                      checkedConfig[key] = defaultConfig[key];
                    } else {
                      checkedConfig[key] = searchConfig[key];
                    }
                  });
                  return checkedConfig;
                };

                check = checkConfig(searchConfig, defaultConfig); // validate query parameter from the url

                searchProps = _objectSpread({}, query, req.params);
                validatedQS = Object(__WEBPACK_IMPORTED_MODULE_6__utils_qsValidation__["a" /* default */])(searchProps, check);
                return _context.abrupt("return", {
                  searchProps: searchProps,
                  validatedQS: validatedQS
                });

              case 10:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      return function getInitialProps(_x) {
        return _getInitialProps.apply(this, arguments);
      };
    }()
  }]);

  return HotelResults;
}(__WEBPACK_IMPORTED_MODULE_1_react__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (Object(__WEBPACK_IMPORTED_MODULE_7__PageBase__["a" /* default */])(HotelResults));

/***/ }),

/***/ "./pages/PageBase/component/Footer/Footer.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/PageBase/component/Footer/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Footer_scss__ = __webpack_require__("./pages/PageBase/component/Footer/Footer.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Footer_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__Footer_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\pages\\PageBase\\component\\Footer\\index.jsx";



var Footer = function Footer(_ref) {
  var generalConfig = _ref.generalConfig;
  var date = new Date();
  var year = date.getFullYear();

  var _ref2 = generalConfig || "Copyright (c) ".concat(year),
      footerText = _ref2.footerText;

  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("footer", {
    className: "footer",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("p", {
    className: "footer__text",
    dangerouslySetInnerHTML: {
      __html: footerText
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15
    }
  })));
};

/* harmony default export */ __webpack_exports__["a"] = (Footer);

/***/ }),

/***/ "./pages/PageBase/component/Header/Header.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/PageBase/component/Header/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_CurrenciesSwitcher__ = __webpack_require__("./components/CurrenciesSwitcher/index.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Header_scss__ = __webpack_require__("./pages/PageBase/component/Header/Header.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Header_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__Header_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\pages\\PageBase\\component\\Header\\index.jsx";
 // import { connect } from 'react-redux';




var sortAlphabetically = function sortAlphabetically(name1, name2) {
  if (name1 < name2) return -1;
  if (name1 > name2) return 1;
  return 0;
};

var Header = function Header(props) {
  var generalConfig = props.generalConfig,
      currenciesSwitcherDisabled = props.currenciesSwitcherDisabled;
  var currencies = generalConfig.currencies;
  currencies.sort(function (cr1, cr2) {
    return sortAlphabetically(cr1, cr2);
  });
  var logo = generalConfig.logo || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/logo-default.png';
  var name = generalConfig.name || 'GoQuo';
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("header", {
    className: "header",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "container container--header",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "header__logo",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("a", {
    href: "/",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("img", {
    className: "img-responsive",
    src: logo,
    alt: name,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "header__lang",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    }
  }), !currenciesSwitcherDisabled && currencies && currencies.length > 1 ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components_CurrenciesSwitcher__["a" /* default */], {
    currencies: currencies,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  }) : null));
};

/* harmony default export */ __webpack_exports__["a"] = (Header);

/***/ }),

/***/ "./pages/PageBase/component/Layout/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = Layout;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Header__ = __webpack_require__("./pages/PageBase/component/Header/index.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Footer__ = __webpack_require__("./pages/PageBase/component/Footer/index.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\pages\\PageBase\\component\\Layout\\index.jsx";



function Layout(_ref) {
  var children = _ref.children,
      generalConfig = _ref.generalConfig;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 10
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__Header__["a" /* default */], {
    generalConfig: generalConfig,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11
    }
  }), children, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__Footer__["a" /* default */], {
    generalConfig: generalConfig,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }));
}

/***/ }),

/***/ "./pages/PageBase/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_jsx_style__ = __webpack_require__("styled-jsx/style");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_jsx_style___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_styled_jsx_style__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_redux__ = __webpack_require__("react-redux");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_redux___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_redux__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_helmet__ = __webpack_require__("react-helmet");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_helmet___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_helmet__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__paralleldrive_react_feature_toggles__ = __webpack_require__("@paralleldrive/react-feature-toggles");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__paralleldrive_react_feature_toggles___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__paralleldrive_react_feature_toggles__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__react_next_components_PageWithIntl__ = __webpack_require__("./react-next/components/PageWithIntl.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__react_next_utils_component_utils__ = __webpack_require__("./react-next/utils/component-utils.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__react_next_utils_component_utils___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__react_next_utils_component_utils__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__store_modules_common_config_action_types__ = __webpack_require__("./store/modules/common/config/action-types.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__store_modules_locale_selection_action_types__ = __webpack_require__("./store/modules/locale-selection/action-types.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__store_modules_locale_selection_selectors__ = __webpack_require__("./store/modules/locale-selection/selectors.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__store_modules_currency_selection_action_types__ = __webpack_require__("./store/modules/currency-selection/action-types.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__store_modules_currency_selection_selectors__ = __webpack_require__("./store/modules/currency-selection/selectors.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__react_next_utils_json_utils__ = __webpack_require__("./react-next/utils/json-utils.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__react_next_utils_json_utils___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_13__react_next_utils_json_utils__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__component_Layout__ = __webpack_require__("./pages/PageBase/component/Layout/index.jsx");

var _jsxFileName = "C:\\Projects\\frontend\\pages\\PageBase\\index.jsx";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// This will be the HOC to do most of the wrapping so pages.
// Intention:
// 1. Reduce Import Codes at Child Pages and Plugins Dependencies
// 2. Handle Common Functionalities across pages
// 3. Child Pages will only need to concern on compositing the components














function getPageBase(Page) {
  var isFeatured = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
  var isLayouted = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
  return (
    /*#__PURE__*/
    function (_React$Component) {
      _inherits(PageBase, _React$Component);

      function PageBase() {
        _classCallCheck(this, PageBase);

        return _possibleConstructorReturn(this, (PageBase.__proto__ || Object.getPrototypeOf(PageBase)).apply(this, arguments));
      }

      _createClass(PageBase, [{
        key: "render",
        value: function render() {
          var _props = this.props,
              config = _props.config,
              cultureCode = _props.cultureCode,
              urlLocale = _props.urlLocale,
              selectedCurrency = _props.selectedCurrency,
              props = _objectWithoutProperties(_props, ["config", "cultureCode", "urlLocale", "selectedCurrency"]);

          var pageProps = _objectSpread({
            config: config,
            cultureCode: cultureCode,
            urlLocale: urlLocale,
            selectedCurrency: selectedCurrency
          }, props);

          var pageSetup = PageBase.baseRender(config, pageProps);

          if (isFeatured) {
            pageSetup = PageBase.withFeatured(config, pageSetup);
          }

          return pageSetup;
        }
      }], [{
        key: "baseRender",
        value: function baseRender(config, pageProps) {
          return __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement("div", {
            __source: {
              fileName: _jsxFileName,
              lineNumber: 36
            },
            className: __WEBPACK_IMPORTED_MODULE_1_styled_jsx_style___default.a.dynamic([["1991745385", [config.general.primaryColor || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#17b36e', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.linkColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4']]]) + " " + (__WEBPACK_IMPORTED_MODULE_1_styled_jsx_style___default.a.dynamic([["1991745385", [config.general.primaryColor || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#17b36e', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.linkColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4']]]) || "")
          }, __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_helmet__["Helmet"], {
            __source: {
              fileName: _jsxFileName,
              lineNumber: 37
            }
          }, __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement("link", {
            rel: "icon",
            type: "image/png",
            href: config.general.favicon || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/favicon-default.png',
            __source: {
              fileName: _jsxFileName,
              lineNumber: 38
            },
            className: __WEBPACK_IMPORTED_MODULE_1_styled_jsx_style___default.a.dynamic([["1991745385", [config.general.primaryColor || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#17b36e', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.linkColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4']]]) + " " + (__WEBPACK_IMPORTED_MODULE_1_styled_jsx_style___default.a.dynamic([["1991745385", [config.general.primaryColor || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#17b36e', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.linkColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4']]]) || "")
          })), __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_styled_jsx_style___default.a, {
            styleId: "1991745385",
            css: ".theme-primary-text{color:".concat(config.general.primaryColor || '#4583c4', ";}.theme-secondary-text{color:").concat(config.general.secondaryColor || '#17b36e', ";}.btn-theme-primary{background:").concat(config.general.primaryColor || '#4583c4', ";color:").concat(config.general.primaryColorText || '#fff', ";border-color:").concat(config.general.primaryColor || '#4583c4', ";}.btn-theme-primary:hover{background:").concat(config.general.primaryColorHover || '#3f78b3', ";color:").concat(config.general.primaryColorText || '#fff', ";}.btn-theme-primary:focus{background:").concat(config.general.primaryColorHover || '#3f78b3', ";color:").concat(config.general.primaryColorText || '#fff', ";}.btn-theme-primary-outline{background:").concat(config.general.primaryColorText || '#fff', ";border-color:").concat(config.general.primaryColor || '#4583c4', ";color:").concat(config.general.primaryColor || '#4583c4', ";}.btn-theme-primary-outline:hover{background:").concat(config.general.primaryColor || '#fff', ";border-color:").concat(config.general.primaryColor || '#4583c4', ";color:").concat(config.general.primaryColorText || '#4583c4', ";}.btn-theme-primary-outline:focus{background:").concat(config.general.primaryColor || '#fff', ";border-color:").concat(config.general.primaryColor || '#4583c4', ";color:").concat(config.general.primaryColorText || '#4583c4', ";}.btn-theme-secondary{background:").concat(config.general.secondaryColor || '#17b36e', ";color:").concat(config.general.secondaryColorText || '#fff', ";border:").concat(config.general.secondaryColor || '#17b36e', ";}.btn-theme-secondary:hover{background:").concat(config.general.secondaryColorHover || '#15a364', ";color:").concat(config.general.secondaryColorText || '#fff', ";}.btn-theme-secondary:focus{background:").concat(config.general.secondaryColorHover || '#15a364', ";color:").concat(config.general.secondaryColorText || '#fff', ";}.btn-theme-secondary-outline{background:").concat(config.general.secondaryColorText || '#fff', ";border-color:").concat(config.general.secondaryColor || '#4583c4', ";color:").concat(config.general.secondaryColor || '#4583c4', ";}.btn-theme-secondary-outline:hover{background:").concat(config.general.secondaryColor || '#fff', ";border-color:").concat(config.general.secondaryColor || '#4583c4', ";color:").concat(config.general.secondaryColorText || '#4583c4', ";}.btn-theme-secondary-outline:focus{background:").concat(config.general.secondaryColor || '#fff', ";border-color:").concat(config.general.secondaryColor || '#4583c4', ";color:").concat(config.general.secondaryColorText || '#4583c4', ";}.link-theme-primary{color:").concat(config.general.linkColor || '#4583c4', ";}.sortBar__item--active{color:").concat(config.general.secondaryColor || '#4583c4', ";}.sortBar__item:hover{color:").concat(config.general.secondaryColor || '#4583c4', ";}.sortBar__item--active:before{background-color:").concat(config.general.secondaryColor || '#4583c4', ";}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2VzXFxQYWdlQmFzZVxcaW5kZXguanN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQXdDYSxBQUdzRCxBQUdBLEFBR0csQUFNQSxBQUlBLEFBSUEsQUFNQyxBQUtBLEFBS0EsQUFLQSxBQUlBLEFBSUEsQUFNQSxBQUtBLEFBS0wsQUFHRCxBQUdBLEFBR1csbUNBekU5QyxBQUdBLENBOERGLEFBR0EsQUFHQSxJQWpFcUMsQUFNQSxBQUlBLEFBSVEsQ0FNQSxBQUtBLEFBS1AsQUFLQSxBQUlBLEFBSU8sQUFNQSxBQUtBLE1BYzdDLDRCQW5FNEMsQUFNNUMsQUFJQSxFQW9CdUMsQUFLdkMsQUFJQSxNQXpCc0MsQ0FNQSxBQUtBLEFBa0JBLEFBTUEsQUFLQSw4QkF2QnRDLEdBN0JBLEVBY0EsQ0FLQSxBQUtBLEFBbUJBLEFBS0EsQUFLQSIsImZpbGUiOiJwYWdlc1xcUGFnZUJhc2VcXGluZGV4LmpzeCIsInNvdXJjZVJvb3QiOiJDOlxcUHJvamVjdHNcXGZyb250ZW5kIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQGZsb3dcclxuXHJcbi8vIFRoaXMgd2lsbCBiZSB0aGUgSE9DIHRvIGRvIG1vc3Qgb2YgdGhlIHdyYXBwaW5nIHNvIHBhZ2VzLlxyXG4vLyBJbnRlbnRpb246XHJcbi8vIDEuIFJlZHVjZSBJbXBvcnQgQ29kZXMgYXQgQ2hpbGQgUGFnZXMgYW5kIFBsdWdpbnMgRGVwZW5kZW5jaWVzXHJcbi8vIDIuIEhhbmRsZSBDb21tb24gRnVuY3Rpb25hbGl0aWVzIGFjcm9zcyBwYWdlc1xyXG4vLyAzLiBDaGlsZCBQYWdlcyB3aWxsIG9ubHkgbmVlZCB0byBjb25jZXJuIG9uIGNvbXBvc2l0aW5nIHRoZSBjb21wb25lbnRzXHJcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50VHlwZSB9IGZyb20gJ3JlYWN0JztcclxuXHJcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tICdyZWFjdC1yZWR1eCc7XHJcbmltcG9ydCB7IEhlbG1ldCB9IGZyb20gJ3JlYWN0LWhlbG1ldCc7XHJcbmltcG9ydCB7IEZlYXR1cmVUb2dnbGVzIH0gZnJvbSAnQHBhcmFsbGVsZHJpdmUvcmVhY3QtZmVhdHVyZS10b2dnbGVzJztcclxuaW1wb3J0IFBhZ2VXaXRoSW50bCBmcm9tICcuLi8uLi9yZWFjdC1uZXh0L2NvbXBvbmVudHMvUGFnZVdpdGhJbnRsJztcclxuaW1wb3J0IENvbXBvbmVudFV0aWxzIGZyb20gJy4uLy4uL3JlYWN0LW5leHQvdXRpbHMvY29tcG9uZW50LXV0aWxzJztcclxuXHJcbmltcG9ydCBjb25maWdBY3Rpb25UeXBlcyBmcm9tICcuLi8uLi9zdG9yZS9tb2R1bGVzL2NvbW1vbi9jb25maWcvYWN0aW9uLXR5cGVzJztcclxuXHJcbmltcG9ydCBpbnRsQWN0aW9uVHlwZXMgZnJvbSAnLi4vLi4vc3RvcmUvbW9kdWxlcy9sb2NhbGUtc2VsZWN0aW9uL2FjdGlvbi10eXBlcyc7XHJcbmltcG9ydCB7IGdldEN1bHR1cmVDb2RlLCBnZXRVcmxMb2NhbGUgfSBmcm9tICcuLi8uLi9zdG9yZS9tb2R1bGVzL2xvY2FsZS1zZWxlY3Rpb24vc2VsZWN0b3JzJztcclxuaW1wb3J0IGN1cnJlbmN5QWN0aW9uVHlwZXMgZnJvbSAnLi4vLi4vc3RvcmUvbW9kdWxlcy9jdXJyZW5jeS1zZWxlY3Rpb24vYWN0aW9uLXR5cGVzJztcclxuaW1wb3J0IHsgZ2V0U2VsZWN0ZWRDdXJyZW5jeSB9IGZyb20gJy4uLy4uL3N0b3JlL21vZHVsZXMvY3VycmVuY3ktc2VsZWN0aW9uL3NlbGVjdG9ycyc7XHJcbmltcG9ydCBKc29uVXRpbHMgZnJvbSAnLi4vLi4vcmVhY3QtbmV4dC91dGlscy9qc29uLXV0aWxzJztcclxuXHJcbmltcG9ydCB0eXBlIHsgT3B0aW9uc09iamVjdCwgUGFnZUJhc2VQcm9wcywgQ29uZmlnIH0gZnJvbSAnLi90eXBlcyc7XHJcbmltcG9ydCBMYXlvdXQgZnJvbSAnLi9jb21wb25lbnQvTGF5b3V0JztcclxuXHJcbmZ1bmN0aW9uIGdldFBhZ2VCYXNlKFxyXG4gIFBhZ2U6IENvbXBvbmVudFR5cGU8Kj4sXHJcbiAgaXNGZWF0dXJlZDogYm9vbGVhbiA9IGZhbHNlLFxyXG4gIGlzTGF5b3V0ZWQ6IGJvb2xlYW4gPSB0cnVlLFxyXG4pIHtcclxuICByZXR1cm4gY2xhc3MgUGFnZUJhc2UgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQ8UGFnZUJhc2VQcm9wcz4ge1xyXG4gICAgc3RhdGljIGJhc2VSZW5kZXIoY29uZmlnLCBwYWdlUHJvcHMpIHtcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPEhlbG1ldD5cclxuICAgICAgICAgICAgPGxpbmsgcmVsPVwiaWNvblwiIHR5cGU9XCJpbWFnZS9wbmdcIiBocmVmPXtjb25maWcuZ2VuZXJhbC5mYXZpY29uIHx8ICdodHRwczovL2QydmExcGJtOG16NmNuLmNsb3VkZnJvbnQubmV0L2ZhbGxiYWNrcy9mYXZpY29uLWRlZmF1bHQucG5nJ30gLz5cclxuICAgICAgICAgIDwvSGVsbWV0PlxyXG4gICAgICAgICAgPHN0eWxlIGpzeCBnbG9iYWw+XHJcbiAgICAgICAgICAgIHtgXHJcbiAgICAgICAgICAgICAgICAudGhlbWUtcHJpbWFyeS10ZXh0IHtcclxuICAgICAgICAgICAgICAgICAgY29sb3I6ICR7Y29uZmlnLmdlbmVyYWwucHJpbWFyeUNvbG9yIHx8ICcjNDU4M2M0J307XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAudGhlbWUtc2Vjb25kYXJ5LXRleHQge1xyXG4gICAgICAgICAgICAgICAgICBjb2xvcjogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvciB8fCAnIzE3YjM2ZSd9O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC5idG4tdGhlbWUtcHJpbWFyeSB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAke2NvbmZpZy5nZW5lcmFsLnByaW1hcnlDb2xvciB8fCAnIzQ1ODNjNCd9O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICR7Y29uZmlnLmdlbmVyYWwucHJpbWFyeUNvbG9yVGV4dCB8fCAnI2ZmZid9O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLnByaW1hcnlDb2xvciB8fCAnIzQ1ODNjNCd9O1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC5idG4tdGhlbWUtcHJpbWFyeTpob3ZlciB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAke2NvbmZpZy5nZW5lcmFsLnByaW1hcnlDb2xvckhvdmVyIHx8ICcjM2Y3OGIzJ307XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJHtjb25maWcuZ2VuZXJhbC5wcmltYXJ5Q29sb3JUZXh0IHx8ICcjZmZmJ307XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC5idG4tdGhlbWUtcHJpbWFyeTpmb2N1cyB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAke2NvbmZpZy5nZW5lcmFsLnByaW1hcnlDb2xvckhvdmVyIHx8ICcjM2Y3OGIzJ307XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJHtjb25maWcuZ2VuZXJhbC5wcmltYXJ5Q29sb3JUZXh0IHx8ICcjZmZmJ307XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC5idG4tdGhlbWUtcHJpbWFyeS1vdXRsaW5lIHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICR7Y29uZmlnLmdlbmVyYWwucHJpbWFyeUNvbG9yVGV4dCB8fCAnI2ZmZid9O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLnByaW1hcnlDb2xvciB8fCAnIzQ1ODNjNCd9O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICR7Y29uZmlnLmdlbmVyYWwucHJpbWFyeUNvbG9yIHx8ICcjNDU4M2M0J307XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLmJ0bi10aGVtZS1wcmltYXJ5LW91dGxpbmU6aG92ZXIge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJHtjb25maWcuZ2VuZXJhbC5wcmltYXJ5Q29sb3IgfHwgJyNmZmYnfTtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1jb2xvcjogJHtjb25maWcuZ2VuZXJhbC5wcmltYXJ5Q29sb3IgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLnByaW1hcnlDb2xvclRleHQgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLmJ0bi10aGVtZS1wcmltYXJ5LW91dGxpbmU6Zm9jdXMge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJHtjb25maWcuZ2VuZXJhbC5wcmltYXJ5Q29sb3IgfHwgJyNmZmYnfTtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1jb2xvcjogJHtjb25maWcuZ2VuZXJhbC5wcmltYXJ5Q29sb3IgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLnByaW1hcnlDb2xvclRleHQgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLmJ0bi10aGVtZS1zZWNvbmRhcnkge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvciB8fCAnIzE3YjM2ZSd9O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICR7Y29uZmlnLmdlbmVyYWwuc2Vjb25kYXJ5Q29sb3JUZXh0IHx8ICcjZmZmJ307XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6ICR7Y29uZmlnLmdlbmVyYWwuc2Vjb25kYXJ5Q29sb3IgfHwgJyMxN2IzNmUnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLmJ0bi10aGVtZS1zZWNvbmRhcnk6aG92ZXIge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvckhvdmVyIHx8ICcjMTVhMzY0J307XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvclRleHQgfHwgJyNmZmYnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLmJ0bi10aGVtZS1zZWNvbmRhcnk6Zm9jdXMge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvckhvdmVyIHx8ICcjMTVhMzY0J307XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvclRleHQgfHwgJyNmZmYnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLmJ0bi10aGVtZS1zZWNvbmRhcnktb3V0bGluZSB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAke2NvbmZpZy5nZW5lcmFsLnNlY29uZGFyeUNvbG9yVGV4dCB8fCAnI2ZmZid9O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLnNlY29uZGFyeUNvbG9yIHx8ICcjNDU4M2M0J307XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvciB8fCAnIzQ1ODNjNCd9O1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC5idG4tdGhlbWUtc2Vjb25kYXJ5LW91dGxpbmU6aG92ZXIge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvciB8fCAnI2ZmZid9O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLnNlY29uZGFyeUNvbG9yIHx8ICcjNDU4M2M0J307XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvclRleHQgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLmJ0bi10aGVtZS1zZWNvbmRhcnktb3V0bGluZTpmb2N1cyB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAke2NvbmZpZy5nZW5lcmFsLnNlY29uZGFyeUNvbG9yIHx8ICcjZmZmJ307XHJcbiAgICAgICAgICAgICAgICBib3JkZXItY29sb3I6ICR7Y29uZmlnLmdlbmVyYWwuc2Vjb25kYXJ5Q29sb3IgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLnNlY29uZGFyeUNvbG9yVGV4dCB8fCAnIzQ1ODNjNCd9O1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAubGluay10aGVtZS1wcmltYXJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLmxpbmtDb2xvciB8fCAnIzQ1ODNjNCd9O1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAuc29ydEJhcl9faXRlbS0tYWN0aXZlIHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiR7Y29uZmlnLmdlbmVyYWwuc2Vjb25kYXJ5Q29sb3IgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLnNvcnRCYXJfX2l0ZW06aG92ZXIge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6JHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvciB8fCAnIzQ1ODNjNCd9O1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAuc29ydEJhcl9faXRlbS0tYWN0aXZlOmJlZm9yZSB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiR7Y29uZmlnLmdlbmVyYWwuc2Vjb25kYXJ5Q29sb3IgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICBgfVxyXG4gICAgICAgICAgPC9zdHlsZT5cclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgKGlzTGF5b3V0ZWQpXHJcbiAgICAgICAgICAgICAgPyBQYWdlQmFzZS53aXRoTGF5b3V0KGNvbmZpZywgUGFnZUJhc2UuZ2V0UGFnZShwYWdlUHJvcHMpKVxyXG4gICAgICAgICAgICAgIDogUGFnZUJhc2UuZ2V0UGFnZShwYWdlUHJvcHMpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgc3RhdGljIHdpdGhMYXlvdXQoY29uZmlnOiBDb25maWcsIHBhZ2UpIHtcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8TGF5b3V0IGdlbmVyYWxDb25maWc9e2NvbmZpZy5nZW5lcmFsfT5cclxuICAgICAgICAgIHtwYWdlfVxyXG4gICAgICAgIDwvTGF5b3V0PlxyXG4gICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIEltcG9ydGFudCBOb3RlOiBUaGlzIHNob3VsZCBiZSB0aGUgd2F5IHRvIHdyYXAgYW55IHByb3ZpZGVyXHJcbiAgICAvLyBPbmx5IGlmIHRoZSBwcm92aWRlciBpcyBub3QgaHVnZSBsaWtlIFBhZ2VXaXRoSW50bFxyXG4gICAgc3RhdGljIHdpdGhGZWF0dXJlZChjb25maWc6IENvbmZpZywgcGFnZSkge1xyXG4gICAgICBjb25zdCBmZWF0dXJlcyA9IFtdO1xyXG4gICAgICBjb25zdCBmZWF0dXJlS2V5cyA9IE9iamVjdC5rZXlzKGNvbmZpZy5mZWF0dXJlcyk7XHJcblxyXG4gICAgICBmZWF0dXJlS2V5cy5mb3JFYWNoKChlbGVtZW50KSA9PiB7XHJcbiAgICAgICAgaWYgKGNvbmZpZy5mZWF0dXJlc1tlbGVtZW50XSkge1xyXG4gICAgICAgICAgZmVhdHVyZXMucHVzaChlbGVtZW50KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8RmVhdHVyZVRvZ2dsZXMgZmVhdHVyZXM9e2ZlYXR1cmVzfT5cclxuICAgICAgICAgIHsgcGFnZSB9XHJcbiAgICAgICAgPC9GZWF0dXJlVG9nZ2xlcz5cclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBzdGF0aWMgZ2V0UGFnZShwYWdlUHJvcHMpIHtcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8UGFnZSB7Li4ucGFnZVByb3BzfSAvPlxyXG4gICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIHN0YXRpYyBhc3luYyBnZXRJbml0aWFsUHJvcHMoY29udGV4dCkge1xyXG4gICAgICBjb25zdCB7IGN0eDogeyByZXEsIHN0b3JlLCBxdWVyeSB9IH0gPSBjb250ZXh0O1xyXG5cclxuICAgICAgY29uc3QgeyBjb25maWcsIGxvY2FsZSB9ID0gcmVxIHx8IENvbXBvbmVudFV0aWxzLmdldFdpbmRvd0luaXRpYWxQYWdlUHJvcHMoKS5wYWdlUHJvcHM7XHJcblxyXG4gICAgICAvKlxyXG4gICAgICAqIENoYW5nZSBjdWx0dXJlQ29kZSB0byBnZXR0aW5nIGZyb20gc3RhdGUgYW5kIHJlLXJlbmRlciBwYWdlIGZvciBjdWx0dXJlIGNvZGUgY2hhbmdlLFxyXG4gICAgICAqIERvbid0IG5lZWQgdG8gbWFrZSBhIHVybCBjYWxsIHRvIGhpdCBub2RlIHNlcnZlclxyXG4gICAgICAqL1xyXG4gICAgICBzdG9yZS5kaXNwYXRjaCh7IHR5cGU6IGNvbmZpZ0FjdGlvblR5cGVzLlNFVF9DT05GSUcsIHBheWxvYWQ6IHsgY29uZmlnIH0gfSk7XHJcbiAgICAgIHN0b3JlLmRpc3BhdGNoKHsgdHlwZTogaW50bEFjdGlvblR5cGVzLlNFVF9DVUxUVVJFX0NPREUsIHBheWxvYWQ6IHsgbG9jYWxlLCBjb25maWcgfSB9KTtcclxuICAgICAgaWYgKHR5cGVvZiBxdWVyeS5jdXJyZW5jeSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICBzdG9yZS5kaXNwYXRjaCh7XHJcbiAgICAgICAgICB0eXBlOiBjdXJyZW5jeUFjdGlvblR5cGVzLlNFTEVDVF9DVVJSRU5DWV9GUk9NX1VSTF9SRVFVRVNULFxyXG4gICAgICAgICAgcGF5bG9hZDogeyBjdXJyZW5jeTogcXVlcnkuY3VycmVuY3kgfSxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzdG9yZS5kaXNwYXRjaCh7XHJcbiAgICAgICAgICB0eXBlOiBjdXJyZW5jeUFjdGlvblR5cGVzLkdFVF9TRUxFQ1RFRF9DVVJSRU5DWV9SRVFVRVNULFxyXG4gICAgICAgICAgLyogQWRkIHRoaXMgY29uZGl0aW9uIHRvIGF2b2lkIHNpbGx5IHJlYWN0LW5leHQgcmVsb2FkaW5nIGVycm9yLFxyXG4gICAgICAgICAgYnV0IGFwcGFyZW50bHkgcmVxIHNob3VsZCBub3QgYmUgdW5kZWZpbmVkICovXHJcbiAgICAgICAgICBwYXlsb2FkOiB7IGNvb2tpZTogcmVxID8gcmVxLmhlYWRlcnMuY29va2llIDogbnVsbCB9LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgIGxldCBwcm9wcztcclxuICAgICAgaWYgKHR5cGVvZiBQYWdlLmdldEluaXRpYWxQcm9wcyA9PT0gJ2Z1bmN0aW9uJykge1xyXG4gICAgICAgIHByb3BzID0gYXdhaXQgUGFnZS5nZXRJbml0aWFsUHJvcHMoY29udGV4dCk7IC8vIFRoaXMgd2lsbCBjYWxsIHBhZ2VzIGdldEluaXRpYWxQcm9wc1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGNvbmZpZyxcclxuICAgICAgICAuLi5wcm9wcyxcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICByZW5kZXIoKSB7XHJcbiAgICAgIGNvbnN0IHtcclxuICAgICAgICBjb25maWcsXHJcbiAgICAgICAgY3VsdHVyZUNvZGUsXHJcbiAgICAgICAgdXJsTG9jYWxlLFxyXG4gICAgICAgIHNlbGVjdGVkQ3VycmVuY3ksXHJcbiAgICAgICAgLi4ucHJvcHNcclxuICAgICAgfSA9IHRoaXMucHJvcHM7XHJcblxyXG4gICAgICBjb25zdCBwYWdlUHJvcHMgPSB7XHJcbiAgICAgICAgY29uZmlnLFxyXG4gICAgICAgIGN1bHR1cmVDb2RlLFxyXG4gICAgICAgIHVybExvY2FsZSxcclxuICAgICAgICBzZWxlY3RlZEN1cnJlbmN5LFxyXG4gICAgICAgIC4uLnByb3BzLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgbGV0IHBhZ2VTZXR1cCA9IFBhZ2VCYXNlLmJhc2VSZW5kZXIoY29uZmlnLCBwYWdlUHJvcHMpO1xyXG5cclxuICAgICAgaWYgKGlzRmVhdHVyZWQpIHtcclxuICAgICAgICBwYWdlU2V0dXAgPSBQYWdlQmFzZS53aXRoRmVhdHVyZWQoY29uZmlnLCBwYWdlU2V0dXApO1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIHBhZ2VTZXR1cFxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH07XHJcbn1cclxuXHJcbi8vIFdoZW4gUHJvdmlkZXIgR3Jvd3MsIFByZXBhcmUgYSBzZXQgb2YgUHJvdmlkZXJzIFRydWUgRmFsc2VcclxuY29uc3QgcGJNYXBTdGF0ZVRvUHJvcHM6IEZ1bmN0aW9uID0gc3RhdGUgPT4gKHtcclxuICBzZWxlY3RlZEN1cnJlbmN5OiBnZXRTZWxlY3RlZEN1cnJlbmN5KHN0YXRlKSxcclxuICBjdWx0dXJlQ29kZTogZ2V0Q3VsdHVyZUNvZGUoc3RhdGUpLFxyXG4gIHVybExvY2FsZTogZ2V0VXJsTG9jYWxlKHN0YXRlKSxcclxufSk7XHJcblxyXG5jb25zdCBwYWdlT3B0aW9uczogT3B0aW9uc09iamVjdCA9IHtcclxuICBtYXBTdGF0ZVRvUHJvcHM6IHVuZGVmaW5lZCxcclxuICBpc0ZlYXR1cmVkOiBmYWxzZSxcclxuICBpc0xheW91dGVkOiB0cnVlLFxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKFxyXG4gIFBhZ2U6IENvbXBvbmVudFR5cGU8Kj4sXHJcbiAgb3B0aW9uczogT3B0aW9uc09iamVjdCA9IHBhZ2VPcHRpb25zLFxyXG4pIHtcclxuICBpZiAob3B0aW9ucyAhPT0gcGFnZU9wdGlvbnMpIHtcclxuICAgIEpzb25VdGlscy5vdmVycmlkZVZhbHVlcyhwYWdlT3B0aW9ucywgb3B0aW9ucyk7XHJcbiAgfVxyXG5cclxuICBjb25zdCBjb21iaW5lZE1hcFN0YXRlVG9Qcm9wcyA9IHN0YXRlID0+ICh7XHJcbiAgICAuLi5zdGF0ZSxcclxuICAgIC4uLnBiTWFwU3RhdGVUb1Byb3BzKHN0YXRlKSxcclxuICAgIC4uLigocGFnZU9wdGlvbnMubWFwU3RhdGVUb1Byb3BzKSA/IHBhZ2VPcHRpb25zLm1hcFN0YXRlVG9Qcm9wcyhzdGF0ZSkgOiB7fSksXHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiBjb25uZWN0KGNvbWJpbmVkTWFwU3RhdGVUb1Byb3BzKShcclxuICAgIFBhZ2VXaXRoSW50bChnZXRQYWdlQmFzZShQYWdlLCBwYWdlT3B0aW9ucy5pc0ZlYXR1cmVkLCBwYWdlT3B0aW9ucy5pc0xheW91dGVkKSksXHJcbiAgKTtcclxufVxyXG5cclxuLyovXHJcbmV4cG9ydCBkZWZhdWx0IChQYWdlLCBpc0ZlYXR1cmVkOiBib29sZWFuID0gZmFsc2UpID0+IGNvbm5lY3Qoc3RhdGUgPT4gKHtcclxuICAuLi5zdGF0ZSxcclxuICBzZWxlY3RlZEN1cnJlbmN5OiBnZXRTZWxlY3RlZEN1cnJlbmN5KHN0YXRlKSxcclxuICBjdWx0dXJlQ29kZTogZ2V0Q3VsdHVyZUNvZGUoc3RhdGUpLFxyXG4gIHVybExvY2FsZTogZ2V0VXJsTG9jYWxlKHN0YXRlKSxcclxufSkpKFBhZ2VXaXRoSW50bChnZXRQYWdlQmFzZShQYWdlLCBpc0ZlYXR1cmVkKSkpO1xyXG4vKi9cclxuIl19 */\n/*@ sourceURL=pages\\PageBase\\index.jsx */"),
            dynamic: [config.general.primaryColor || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#17b36e', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.linkColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4']
          }), isLayouted ? PageBase.withLayout(config, PageBase.getPage(pageProps)) : PageBase.getPage(pageProps));
        }
      }, {
        key: "withLayout",
        value: function withLayout(config, page) {
          return __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_14__component_Layout__["a" /* default */], {
            generalConfig: config.general,
            __source: {
              fileName: _jsxFileName,
              lineNumber: 132
            }
          }, page);
        } // Important Note: This should be the way to wrap any provider
        // Only if the provider is not huge like PageWithIntl

      }, {
        key: "withFeatured",
        value: function withFeatured(config, page) {
          var features = [];
          var featureKeys = Object.keys(config.features);
          featureKeys.forEach(function (element) {
            if (config.features[element]) {
              features.push(element);
            }
          });
          return __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__paralleldrive_react_feature_toggles__["FeatureToggles"], {
            features: features,
            __source: {
              fileName: _jsxFileName,
              lineNumber: 151
            }
          }, page);
        }
      }, {
        key: "getPage",
        value: function getPage(pageProps) {
          return __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(Page, _extends({}, pageProps, {
            __source: {
              fileName: _jsxFileName,
              lineNumber: 159
            }
          }));
        }
      }, {
        key: "getInitialProps",
        value: function () {
          var _getInitialProps = _asyncToGenerator(
          /*#__PURE__*/
          __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee(context) {
            var _context$ctx, req, store, query, _ref, config, locale, props;

            return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context$ctx = context.ctx, req = _context$ctx.req, store = _context$ctx.store, query = _context$ctx.query;
                    _ref = req || __WEBPACK_IMPORTED_MODULE_7__react_next_utils_component_utils___default.a.getWindowInitialPageProps().pageProps, config = _ref.config, locale = _ref.locale;
                    /*
                    * Change cultureCode to getting from state and re-render page for culture code change,
                    * Don't need to make a url call to hit node server
                    */

                    store.dispatch({
                      type: __WEBPACK_IMPORTED_MODULE_8__store_modules_common_config_action_types__["a" /* default */].SET_CONFIG,
                      payload: {
                        config: config
                      }
                    });
                    store.dispatch({
                      type: __WEBPACK_IMPORTED_MODULE_9__store_modules_locale_selection_action_types__["a" /* default */].SET_CULTURE_CODE,
                      payload: {
                        locale: locale,
                        config: config
                      }
                    });

                    if (typeof query.currency !== 'undefined') {
                      store.dispatch({
                        type: __WEBPACK_IMPORTED_MODULE_11__store_modules_currency_selection_action_types__["a" /* default */].SELECT_CURRENCY_FROM_URL_REQUEST,
                        payload: {
                          currency: query.currency
                        }
                      });
                    } else {
                      store.dispatch({
                        type: __WEBPACK_IMPORTED_MODULE_11__store_modules_currency_selection_action_types__["a" /* default */].GET_SELECTED_CURRENCY_REQUEST,

                        /* Add this condition to avoid silly react-next reloading error,
                        but apparently req should not be undefined */
                        payload: {
                          cookie: req ? req.headers.cookie : null
                        }
                      });
                    }

                    if (!(typeof Page.getInitialProps === 'function')) {
                      _context.next = 9;
                      break;
                    }

                    _context.next = 8;
                    return Page.getInitialProps(context);

                  case 8:
                    props = _context.sent;

                  case 9:
                    return _context.abrupt("return", _objectSpread({
                      config: config
                    }, props));

                  case 10:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));

          return function getInitialProps(_x) {
            return _getInitialProps.apply(this, arguments);
          };
        }()
      }]);

      return PageBase;
    }(__WEBPACK_IMPORTED_MODULE_2_react___default.a.Component)
  );
} // When Provider Grows, Prepare a set of Providers True False


var pbMapStateToProps = function pbMapStateToProps(state) {
  return {
    selectedCurrency: Object(__WEBPACK_IMPORTED_MODULE_12__store_modules_currency_selection_selectors__["a" /* getSelectedCurrency */])(state),
    cultureCode: Object(__WEBPACK_IMPORTED_MODULE_10__store_modules_locale_selection_selectors__["a" /* getCultureCode */])(state),
    urlLocale: Object(__WEBPACK_IMPORTED_MODULE_10__store_modules_locale_selection_selectors__["b" /* getUrlLocale */])(state)
  };
};

var pageOptions = {
  mapStateToProps: undefined,
  isFeatured: false,
  isLayouted: true
};
/* harmony default export */ __webpack_exports__["a"] = (function (Page) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : pageOptions;

  if (options !== pageOptions) {
    __WEBPACK_IMPORTED_MODULE_13__react_next_utils_json_utils___default.a.overrideValues(pageOptions, options);
  }

  var combinedMapStateToProps = function combinedMapStateToProps(state) {
    return _objectSpread({}, state, pbMapStateToProps(state), pageOptions.mapStateToProps ? pageOptions.mapStateToProps(state) : {});
  };

  return Object(__WEBPACK_IMPORTED_MODULE_3_react_redux__["connect"])(combinedMapStateToProps)(Object(__WEBPACK_IMPORTED_MODULE_6__react_next_components_PageWithIntl__["a" /* default */])(getPageBase(Page, pageOptions.isFeatured, pageOptions.isLayouted)));
});
/*/
export default (Page, isFeatured: boolean = false) => connect(state => ({
  ...state,
  selectedCurrency: getSelectedCurrency(state),
  cultureCode: getCultureCode(state),
  urlLocale: getUrlLocale(state),
}))(PageWithIntl(getPageBase(Page, isFeatured)));
/*/

/***/ }),

/***/ "./react-next/components/PageWithIntl.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_intl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utils_component_utils__ = __webpack_require__("./react-next/utils/component-utils.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utils_component_utils___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__utils_component_utils__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__utils_intl_utils__ = __webpack_require__("./react-next/utils/intl-utils.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__utils_intl_utils___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4__utils_intl_utils__);

var _jsxFileName = "C:\\Projects\\frontend\\react-next\\components\\PageWithIntl.jsx";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }




 // Register React Intl's locale data for the user's locale in the browser. This
// locale data was added to the page by `pages/_document.js`. This only happens
// once, on initial page load in the browser.

if (typeof window !== 'undefined' && window.ReactIntlLocaleData) {
  Object.keys(window.ReactIntlLocaleData).forEach(function (lang) {
    Object(__WEBPACK_IMPORTED_MODULE_2_react_intl__["addLocaleData"])(window.ReactIntlLocaleData[lang]);
  });
}

/* harmony default export */ __webpack_exports__["a"] = (function (Page) {
  var IntlPage = Object(__WEBPACK_IMPORTED_MODULE_2_react_intl__["injectIntl"])(Page);
  return (
    /*#__PURE__*/
    function (_React$Component) {
      _inherits(PageWithIntl, _React$Component);

      function PageWithIntl() {
        _classCallCheck(this, PageWithIntl);

        return _possibleConstructorReturn(this, (PageWithIntl.__proto__ || Object.getPrototypeOf(PageWithIntl)).apply(this, arguments));
      }

      _createClass(PageWithIntl, [{
        key: "render",
        value: function render() {
          var _props = this.props,
              locale = _props.locale,
              localeDataScript = _props.localeDataScript,
              messages = _props.messages,
              now = _props.now,
              props = _objectWithoutProperties(_props, ["locale", "localeDataScript", "messages", "now"]);

          return (// React Locale Data Script Slightly Different
            __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_intl__["IntlProvider"], {
              locale: __WEBPACK_IMPORTED_MODULE_4__utils_intl_utils___default.a.cultureCodeToReactLocale(locale),
              messages: messages,
              initialNow: now,
              defaultLocale: "en-US",
              __source: {
                fileName: _jsxFileName,
                lineNumber: 56
              }
            }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(IntlPage, _extends({}, props, {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 57
              }
            })))
          );
        }
      }], [{
        key: "getInitialProps",
        value: function () {
          var _getInitialProps = _asyncToGenerator(
          /*#__PURE__*/
          __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee(context) {
            var props, req, _ref, locale, messages, localeDataScript, now;

            return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    if (!(typeof Page.getInitialProps === 'function')) {
                      _context.next = 4;
                      break;
                    }

                    _context.next = 3;
                    return Page.getInitialProps(context);

                  case 3:
                    props = _context.sent;

                  case 4:
                    // Get the `locale` and `messages` from the request object on the server.
                    // In the browser, use the same values that the server serialized.
                    req = context.ctx.req;
                    _ref = req || __WEBPACK_IMPORTED_MODULE_3__utils_component_utils___default.a.getWindowInitialPageProps().pageProps, locale = _ref.locale, messages = _ref.messages, localeDataScript = _ref.localeDataScript; // Always update the current time on page load/transition because the
                    // <IntlProvider> will be a new instance even with pushState routing.

                    now = Date.now();
                    return _context.abrupt("return", _objectSpread({
                      locale: locale,
                      localeDataScript: localeDataScript,
                      messages: messages,
                      now: now
                    }, props));

                  case 8:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));

          return function getInitialProps(_x) {
            return _getInitialProps.apply(this, arguments);
          };
        }()
      }]);

      return PageWithIntl;
    }(__WEBPACK_IMPORTED_MODULE_1_react___default.a.Component)
  );
});

/***/ }),

/***/ "./react-next/error/index.js":
/***/ (function(module, exports, __webpack_require__) {

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

// Future: Interface different Error Handlers, now this purely handle Sentry Errors
var Raven = __webpack_require__("raven-js");

var ErrorHandler =
/*#__PURE__*/
function () {
  function ErrorHandler(dsn, environment, release, errorMap) {
    var options = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {};

    _classCallCheck(this, ErrorHandler);

    this.dsn = dsn;
    this.environment = environment;
    this.release = release;
    this.errorMap = errorMap;
    this.options = options;
    this.isOn = true;
    this.isInstalled = false; // Set Sentry Variables

    this.options.release = release;
    this.options.environment = environment;
  }

  _createClass(ErrorHandler, [{
    key: "install",
    value: function install() {
      // Just In Case
      if (this.dsn && this.isOn) {
        this.installed = true;
        Raven.config(this.dsn, this.options).install();
      }
    }
  }, {
    key: "logIssue",
    value: function logIssue(message) {
      var tag = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      if (this.isOn && this.dsn) {
        if (!this.isInstalled) {
          this.install();
        }

        var tagParams = _objectSpread({
          environment: this.environment
        }, tag);

        Raven.captureMessage(message, {
          tag: tagParams
        });
      }
    }
  }, {
    key: "captureException",
    value: function captureException(error, extra) {
      if (this.isOn && this.dsn) {
        if (!this.isInstalled) {
          this.install();
        }

        Raven.captureException(error, extra);
      }
    }
  }, {
    key: "getRaven",
    value: function getRaven() {
      return Raven;
    }
  }]);

  return ErrorHandler;
}();

module.exports = ErrorHandler;

/***/ }),

/***/ "./react-next/intl/currency-names.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = GetCurrencyName;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__client_error__ = __webpack_require__("./client-error.js");

var Sentry = __WEBPACK_IMPORTED_MODULE_0__client_error__["a" /* default */].getInstance();
var currenciesName = {
  'en-US': {
    MYR: 'Malaysian Ringgit',
    USD: 'US Dollar',
    SGD: 'Singapore Dollar',
    JPY: 'Japanese Yen'
  },
  'zh-HK': {
    MYR: '馬幣',
    USD: '美金'
  }
};
function GetCurrencyName(locale, currency) {
  var currencyLocales = Object.keys(currenciesName);
  var currentLocale = 'en-US';

  if (!locale || currencyLocales.indexOf(locale) === -1) {
    Sentry.captureException("Locale ".concat(locale, " is not found, fallback to en-US"));
  } else {
    currentLocale = locale;
  }

  if (currenciesName[currentLocale][currency]) {
    return currenciesName[currentLocale][currency];
  }

  if (currenciesName['en-US'][currency]) {
    Sentry.captureException("Translation for locale ".concat(currentLocale, " and currency ").concat(currency, " is not found, fallback to its translation in en-US"));
    return currenciesName['en-US'][currency];
  }

  Sentry.captureException("Translation for locale en-US and currency ".concat(currency, " is not found, fallback to blank"));
  return '';
}

/***/ }),

/***/ "./react-next/intl/currency-symbols.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = getCurrencySymbol;
/* harmony export (immutable) */ __webpack_exports__["b"] = isCurrencySymbolAfter;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__client_error__ = __webpack_require__("./client-error.js");

var currencySymbols = {
  MYR: {
    symbol: 'RM',
    isSymbolAfter: false
  },
  USD: {
    symbol: '$',
    isSymbolAfter: false
  },
  SGD: {
    symbol: 'SGD',
    isSymbolAfter: false
  },
  JPY: {
    symbol: '¥',
    isSymbolAfter: true
  }
};
function getCurrencySymbol(currency) {
  if (currencySymbols[currency]) {
    return currencySymbols[currency].symbol;
  }

  __WEBPACK_IMPORTED_MODULE_0__client_error__["a" /* default */].captureException("Symbol for currency ".concat(currency, " is not found, fallback to blank."));
  return ''; // Fall back to blank to avoid user's misunderstanding
}
function isCurrencySymbolAfter(currency) {
  if (currencySymbols[currency]) {
    return currencySymbols[currency].isSymbolAfter;
  }

  return false; // default is false
}

/***/ }),

/***/ "./react-next/intl/date-locale.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export getDateFormat */
/* harmony export (immutable) */ __webpack_exports__["b"] = formatDateString;
/* unused harmony export formatDay */
/* unused harmony export formatMonthTitle */
/* unused harmony export formatWeekdayShort */
/* unused harmony export formatWeekdayLong */
/* unused harmony export getFirstDayOfWeek */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return dayPickerLocaleUtils; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_date_fns__ = __webpack_require__("date-fns");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_date_fns___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_date_fns__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_date_fns_locale_en__ = __webpack_require__("date-fns/locale/en");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_date_fns_locale_en___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_date_fns_locale_en__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_date_fns_locale_zh_tw__ = __webpack_require__("date-fns/locale/zh_tw");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_date_fns_locale_zh_tw___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_date_fns_locale_zh_tw__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_date_fns_locale_zh_cn__ = __webpack_require__("date-fns/locale/zh_cn");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_date_fns_locale_zh_cn___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_date_fns_locale_zh_cn__);




var enFormat = {
  fnsLocale: __WEBPACK_IMPORTED_MODULE_1_date_fns_locale_en___default.a,
  short: 'DD MMM',
  medium: 'DD MMM YYYY',
  long: 'dddd, DD MMM YYYY'
};
var zhHantFormat = {
  fnsLocale: __WEBPACK_IMPORTED_MODULE_2_date_fns_locale_zh_tw___default.a,
  short: 'MMM DD',
  medium: 'YYYY MMM DD',
  long: 'dddd, YYYY MMM DD'
};
var zhHansFormat = {
  fnsLocale: __WEBPACK_IMPORTED_MODULE_3_date_fns_locale_zh_cn___default.a,
  short: 'MMM DD',
  medium: 'YYYY MMM DD',
  long: 'dddd, YYYY MMM DD'
};
var format = {
  'en-US': enFormat,
  'zh-HK': zhHantFormat,
  'zh-TW': zhHantFormat,
  'zh-MO': zhHantFormat,
  'zh-CN': zhHansFormat,
  'zh-SG': zhHansFormat
}; // locale later use Enum

function getDateFormat(locale) {
  if (format[locale]) {
    return format[locale];
  }

  return format['en-US'];
}
function formatDateString(date, lengthFormat, locale) {
  var dateFormat = getDateFormat(locale);
  var dateString = '';

  if (lengthFormat === 'LONG') {
    dateString = Object(__WEBPACK_IMPORTED_MODULE_0_date_fns__["format"])(date, dateFormat.long, {
      locale: dateFormat.fnsLocale
    });
  } else if (lengthFormat === 'MEDIUM') {
    dateString = Object(__WEBPACK_IMPORTED_MODULE_0_date_fns__["format"])(date, dateFormat.medium, {
      locale: dateFormat.fnsLocale
    });
  } else if (lengthFormat === 'SHORT') {
    dateString = Object(__WEBPACK_IMPORTED_MODULE_0_date_fns__["format"])(date, dateFormat.short, {
      locale: dateFormat.fnsLocale
    });
  }

  return dateString;
}
var dayDates = [new Date(2018, 3, 1), // This is Sunday
new Date(2018, 3, 2), new Date(2018, 3, 3), new Date(2018, 3, 4), new Date(2018, 3, 5), new Date(2018, 3, 6), new Date(2018, 3, 7)];
function formatDay(d) {
  var locale = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'en-US';
  // Using Medium Format
  var dateString = formatDateString(d, 'MEDIUM', locale);
  return dateString;
}
function formatMonthTitle(d) {
  var locale = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'en-US';
  var dateFormat = getDateFormat(locale);
  return Object(__WEBPACK_IMPORTED_MODULE_0_date_fns__["format"])(d, 'MMMM', {
    locale: dateFormat.fnsLocale
  });
}
function formatWeekdayShort(i) {
  var locale = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'en-US';
  var dateFormat = getDateFormat(locale);
  return Object(__WEBPACK_IMPORTED_MODULE_0_date_fns__["format"])(dayDates[i], 'dd', {
    locale: dateFormat.fnsLocale
  });
}
function formatWeekdayLong(i) {
  var locale = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'en-US';
  var dateFormat = getDateFormat(locale);
  return Object(__WEBPACK_IMPORTED_MODULE_0_date_fns__["format"])(dayDates[i], 'dddd', {
    locale: dateFormat.fnsLocale
  });
}
function getFirstDayOfWeek() {
  var locale = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'en-US';
  // Not Supported By date-fns, waiting version 2
  return 0;
}
var dayPickerLocaleUtils = {
  formatDay: formatDay,
  formatMonthTitle: formatMonthTitle,
  formatWeekdayShort: formatWeekdayShort,
  formatWeekdayLong: formatWeekdayLong,
  getFirstDayOfWeek: getFirstDayOfWeek
};

/***/ }),

/***/ "./react-next/utils/component-utils.js":
/***/ (function(module, exports) {

var ComponentUtils = {};

ComponentUtils.getWindowInitialPageProps = function () {
  if (typeof window !== 'undefined') {
    return window.__NEXT_DATA__.props.initialProps;
  }

  return {};
};

module.exports = ComponentUtils;

/***/ }),

/***/ "./react-next/utils/intl-utils.js":
/***/ (function(module, exports) {

var IntlUtils = {};

IntlUtils.getUrlLocale = function (locales, path) {
  // TODO: change to baseurl + /locale path check
  var url = path.toLowerCase();

  for (var i = 0; i < locales.length; i++) {
    if (url.indexOf(locales[i].toLowerCase()) === 1) {
      return locales[i];
    }
  }

  return '';
};

IntlUtils.cultureCodeToISO = function (cultureCode) {
  var culture = cultureCode.split('-')[1];

  if (['zh-tw', 'zh-hk', 'zh-mo'].includes(cultureCode.toLowerCase())) {
    return "zh-Hant-".concat(culture);
  } // other chinese


  if (cultureCode.split('-')[0] === 'zh') {
    return "zh-Hans-".concat(culture);
  }

  return cultureCode;
}; // Important Note: react-intl/locale-data/zh does not contain Hant-TW or Hans-CN
// So it is different from intl.js


IntlUtils.cultureCodeToReactLocale = function (cultureCode) {
  var culture = cultureCode.split('-')[1];

  if (['zh-hk', 'zh-mo'].includes(cultureCode.toLowerCase())) {
    return "zh-Hant-".concat(culture);
  }

  if (cultureCode.toLowerCase() === 'zh-SG') {
    return "zh-Hans-".concat(culture);
  }

  if (cultureCode.toLowerCase() === 'zh-TW') {
    return 'zh-Hant';
  }

  if (cultureCode.toLowerCase() === 'zh-CN') {
    return 'zh-Hans';
  }

  return cultureCode;
};

module.exports = IntlUtils;

/***/ }),

/***/ "./react-next/utils/json-utils.js":
/***/ (function(module, exports) {

var JsonUtils = {};

JsonUtils.addValuesTo = function (targetObject, sourceObject) {
  var logWarning = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;

  for (var key in sourceObject) {
    // Copy Value to Target or Overrides
    if (targetObject.hasOwnProperty(key) && logWarning) {
      console.log('Warning: target key existed');
    }

    targetObject[key] = sourceObject[key];
  }
};

JsonUtils.overrideValues = function (targetObject, sourceObject) {
  for (var key in sourceObject) {
    if (targetObject.hasOwnProperty(key)) {
      targetObject[key] = sourceObject[key];
    }
  }
};

module.exports = JsonUtils;

/***/ }),

/***/ "./store/modules/common/config/action-types.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
  SET_CONFIG: 'module/common/config/SET_CONFIG_REQUEST'
});

/***/ }),

/***/ "./store/modules/currency-selection/action-types.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var actionTypes = {
  GET_SELECTED_CURRENCY_REQUEST: 'module/currency/GET_SELECTED_CURRENCY_REQUEST',
  GET_SELECTED_CURRENCY_SUCCESS: 'module/currency/GET_SELECTED_CURRENCY_SUCCESS',
  SELECT_CURRENCY: 'module/currency/SELECT_CURRENCY',
  SELECT_CURRENCY_FROM_URL_REQUEST: 'module/currency/SELECT_CURRENCY_FROM_URL_REQUEST',
  SELECT_CURRENCY_FROM_URL: 'module/currency/SELECT_CURRENCY_FROM_URL'
};
/* harmony default export */ __webpack_exports__["a"] = (actionTypes);

/***/ }),

/***/ "./store/modules/currency-selection/selectors.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getSelectedCurrency; });
// eslint-disable-next-line
var getSelectedCurrency = function getSelectedCurrency(state) {
  return state.moduleCurrencySelection.selectedCurrency;
};

/***/ }),

/***/ "./store/modules/locale-selection/action-types.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var SET_CULTURE_CODE = 'modules/locale-selection/SET_CULTURE_CODE';
var GET_SELECTED_CULTURE_CODE = 'modules/locale-selection/GET_SELECTED_CULTURE_CODE';
/* harmony default export */ __webpack_exports__["a"] = ({
  SET_CULTURE_CODE: SET_CULTURE_CODE,
  GET_SELECTED_CULTURE_CODE: GET_SELECTED_CULTURE_CODE
});

/***/ }),

/***/ "./store/modules/locale-selection/selectors.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getCultureCode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return getUrlLocale; });
var getCultureCode = function getCultureCode(state) {
  return state.moduleLocaleSelection.cultureCode;
};
var getUrlLocale = function getUrlLocale(state) {
  return state.moduleLocaleSelection.urlLocale;
};

/***/ }),

/***/ "./utils/initialLoading.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = InitialLoadingStyle;
function InitialLoadingStyle(loadingState) {
  var textLoading = loadingState ? 'content-placeholder content-text' : ''; // to show loading state for the text contents

  var contentLoading = loadingState ? 'content-placeholder' : ''; // to show loading state for the content blocks

  var btnDisabled = loadingState ? 'btn-disabled' : ''; // disables buttons if page is still on loading state

  return {
    loadingState: loadingState,
    textLoading: textLoading,
    contentLoading: contentLoading,
    btnDisabled: btnDisabled
  };
}

/***/ }),

/***/ "./utils/qsValidation.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export cityValidation */
/* unused harmony export originCityValidation */
/* unused harmony export destinationCityValidation */
/* unused harmony export validateDate */
/* unused harmony export departDateValidation */
/* unused harmony export returnDateValidation */
/* unused harmony export roomValidation */
/* unused harmony export paxValidation */
/* unused harmony export validateChildAge */
/* harmony export (immutable) */ __webpack_exports__["a"] = ValidateQuery;
/* unused harmony export FormattedMessages */
/* unused harmony export getFormattedMessage */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_intl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_date_fns__ = __webpack_require__("date-fns");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_date_fns___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_date_fns__);
var _jsxFileName = "C:\\Projects\\frontend\\utils\\qsValidation.js";




function formatDate(givenDate) {
  var year = givenDate.getFullYear();
  var month = givenDate.getMonth();
  var day = givenDate.getDate();
  var supportedFormat = Object(__WEBPACK_IMPORTED_MODULE_2_date_fns__["format"])(new Date(year, month, day), 'YYYY-MM-DD');
  return supportedFormat;
} // validates city code


function cityValidation(cityCode) {
  var validation = {
    status: 0,
    message: 'Invalid city code',
    value: cityCode
  };

  if (cityCode && cityCode.length === 3) {
    validation.status = 1;
    validation.message = 'utils.qs.success';
    validation.value = cityCode;
  }

  return validation;
} // Merge destinationCityValidation & originCityValidation if no different api

function originCityValidation(origin) {
  var validation = {
    status: 0,
    message: 'Invalid origin',
    value: origin
  };
  var validCity = cityValidation(origin);

  if (validCity.status) {
    validation.status = 1;
    validation.message = 'utils.qs.success';
    validation.value = origin; // TODO
    // Search city code from getairports data and match
    // if no match return false with error message "No flights from this airport"
  }

  return validation;
}
function destinationCityValidation(origin, destination) {
  var validation = {
    status: 0,
    message: 'Invalid destination',
    value: destination
  };
  var validCity = cityValidation(destination);

  if (originCityValidation(origin).status && validCity) {
    if (validCity.status && origin !== destination) {
      validation.status = 1;
      validation.message = 'utils.qs.success';
      validation.value = destination; // Search city code from getairports data and match
      // if no match return false with error message "No flights from this airport"
      // departure and arrival should not be equal
    } else if (validCity && origin === destination) {
      validation.message = 'Origin & Destination shouldn\'t be same!';
    }
  } else if (validCity) {
    validation.status = 1;
    validation.message = 'utils.qs.success';
    validation.value = destination;
  }

  return validation;
}
function validateDate(givenDate) {
  var isValidDate = false;

  if (givenDate) {
    var splitDate = givenDate.split('-');
    var travelDate = new Date(splitDate[0], splitDate[1], splitDate[2]); // TODO isValid is not validating the dates properly needs to improve the validation

    if (Object(__WEBPACK_IMPORTED_MODULE_2_date_fns__["isValid"])(travelDate) && splitDate[0].length === 4 && splitDate[1].length >= 1 && splitDate[1] >= 1 && splitDate[1] <= 12 && splitDate[2].length >= 1 && splitDate[2] >= 1 && splitDate[2] <= 31) {
      isValidDate = true;
    }
  }

  return isValidDate;
}
function departDateValidation(givenDate, config) {
  var validation = {
    status: 0,
    message: 'Please select a depart date',
    value: givenDate
  };
  var validDate = validateDate(givenDate); // minimum number of days to book the package, eg: 2 days

  var minBookDays = config.minBookingDays; // max time period to book the package, eg: package can be booked within 1 year(356 days)

  var maxBookDays = config.maxBookingDays; // days between today and depart date

  var daysUntilDepart = Object(__WEBPACK_IMPORTED_MODULE_2_date_fns__["differenceInCalendarDays"])(givenDate, new Date());

  if (!givenDate) {
    // TODO comment
    validation.status = 0;
    validation.message = 'Missing Departure Date';
    var fallbackDate = formatDate(Object(__WEBPACK_IMPORTED_MODULE_2_date_fns__["addDays"])(new Date(), minBookDays));
    validation.value = fallbackDate;
  } else if (validDate && daysUntilDepart >= minBookDays && daysUntilDepart <= maxBookDays) {
    // TODO comment
    validation.status = 1;
    validation.message = 'utils.qs.success';
    validation.value = givenDate;
  } else if (validDate && daysUntilDepart >= maxBookDays) {
    // TODO comment
    validation.status = 0;
    validation.message = 'Please depart earlier';

    var _fallbackDate = formatDate(Object(__WEBPACK_IMPORTED_MODULE_2_date_fns__["addDays"])(new Date(), minBookDays));

    validation.value = _fallbackDate;
  } else if (validDate && daysUntilDepart <= minBookDays) {
    // TODO comment
    validation.status = 0;
    validation.message = 'Please depart later';

    var _fallbackDate2 = formatDate(Object(__WEBPACK_IMPORTED_MODULE_2_date_fns__["addDays"])(new Date(), minBookDays));

    validation.value = _fallbackDate2;
  }

  return validation;
}
function returnDateValidation(departDate, returnDate, config) {
  var validation = {
    status: 0,
    message: 'Please select a return date',
    value: returnDate
  }; // to check the depart date is validate or gets the fallback value

  var departureDate = departDateValidation(departDate, config); // minimum number of days to book the package, eg: 2 days

  var minBookPeriod = config.minBookingPeriod; // maximum number of days to book the package, eg: 30 days

  var maxBookPeriod = config.maxBookingPeriod; // max time period to book the package, eg: package can be booked within 1 year(356 days)

  var maxBookDays = config.maxBookingDays; // Is return date valid

  var validReturnDate = validateDate(returnDate); // Return failed state

  if (!validReturnDate || !returnDate) {
    validation.status = 0;
    validation.message = 'Missing Return date';
    validation.value = formatDate(Object(__WEBPACK_IMPORTED_MODULE_2_date_fns__["addDays"])(departureDate.value, Math.max(minBookPeriod, 2)));
    return validation;
  } // Now return date is always valid - do more checksa
  // to compare return date is not before depart date


  var isDepartBeforeReturn = Object(__WEBPACK_IMPORTED_MODULE_2_date_fns__["isBefore"])(departureDate.value, returnDate); // Return failed state

  if (!isDepartBeforeReturn) {
    validation.status = 0;
    validation.message = 'Return date cannot be before departure date';
    validation.value = formatDate(Object(__WEBPACK_IMPORTED_MODULE_2_date_fns__["addDays"])(departureDate.value, Math.max(minBookPeriod, 2)));
    return validation;
  } // min travel days difference are 2 days & max travel days difference are 30 days


  var TravelDateDiff = Object(__WEBPACK_IMPORTED_MODULE_2_date_fns__["differenceInCalendarDays"])(returnDate, departureDate.value);

  if (TravelDateDiff >= minBookPeriod && TravelDateDiff <= maxBookPeriod && TravelDateDiff <= maxBookDays) {
    // TODO comments
    validation.status = 1;
    validation.message = 'utils.qs.success'; // fallbacks to departDate + minBookPeriod

    var fallbackDate = formatDate(Object(__WEBPACK_IMPORTED_MODULE_2_date_fns__["addDays"])(departureDate.value, Math.max(minBookPeriod, 2)));
    validation.value = fallbackDate;
  } else if (TravelDateDiff > maxBookPeriod) {
    validation.status = 0;
    validation.message = 'Please return earlier'; // fallbacks to departDate + minBookPeriod

    var _fallbackDate3 = formatDate(Object(__WEBPACK_IMPORTED_MODULE_2_date_fns__["addDays"])(departureDate.value, Math.max(minBookPeriod, 2)));

    validation.value = _fallbackDate3;
  } else if (TravelDateDiff < minBookPeriod) {
    // Check if return is before min booking period
    validation.status = 0;
    validation.message = 'Please return later'; // fallbacks to departDate + minBookPeriod

    var _fallbackDate4 = formatDate(Object(__WEBPACK_IMPORTED_MODULE_2_date_fns__["addDays"])(departureDate.value, Math.max(minBookPeriod, 2)));

    validation.value = _fallbackDate4;
  } else {
    validation.status = 1;
    validation.message = 'utils.qs.success';
    validation.value = validReturnDate.value;
  }

  return validation;
}
function roomValidation(totalRooms, maxRooms) {
  var validation = {
    status: 0,
    message: "Maximum of ".concat(maxRooms, " rooms per booking"),
    value: totalRooms
  };

  if (totalRooms <= maxRooms && totalRooms > 0) {
    validation.status = 1;
    validation.message = 'utils.qs.success';
    validation.value = totalRooms;
  } else if (totalRooms <= 0) {
    validation.status = 0;
    validation.message = 'Room should not be empty';
    validation.value = 0;
  }

  return validation;
} // Validate pax and return fixed pax room array for modify search

function paxValidation(roomPax, config, childAges) {
  console.log(childAges);

  var _roomValidation = roomValidation(roomPax.length, config.maxRooms),
      status = _roomValidation.status,
      message = _roomValidation.message,
      value = _roomValidation.value;

  var validation = {
    status: status,
    message: message,
    value: value
  };
  var roomPaxInfo = [];
  var totalPax = 0;

  if (status) {
    // If room not empty
    // check room pax split room pax as adult, child and infant
    for (var i = 0; i < roomPax.length; i++) {
      var splitPax = roomPax[i].split(',');
      var adult = parseInt(splitPax[0], 10);
      var child = parseInt(splitPax[1], 10);
      var noOfAdult = 0;
      var noOfChild = 0; // Number of total children in room, including infants

      var noOfInfant = 0;
      roomPaxInfo[i] = {
        adults: 0,
        children: []
      }; // validating  adults

      if (adult === '' || adult <= 0) {
        validation.status = 0;
        validation.message = 'Minimum 1 adult required per room';
        noOfAdult = 1;
        roomPaxInfo[i].adults = 1;
      } else if (adult > 3) {
        validation.status = 0;
        validation.message = 'Max 3 adults per room';
        noOfAdult = 3;
        roomPaxInfo[i].adults = 3;
      } else {
        // Correct adult
        noOfAdult = adult;
        roomPaxInfo[i].adults = adult;
      } // validate children - <= 3


      if (child && child > 3) {
        noOfChild = 3;
        validation.status = 0;
        validation.message = 'Max 3 children per room'; // roomPaxInfo[i].child = 3;
      } else if (child) {
        noOfChild = child; // roomPaxInfo[i].child = child;
      } // Validate Child Ages


      if (noOfChild > 0) {
        var originalNoOfChild = noOfChild; // If no childAges given, just set empty array

        var splitChildAge = childAges.length > 0 ? childAges[i].split(',') : [];

        for (var j = 0; j < originalNoOfChild; j++) {
          // If empty array, means no childAges given, then just send empty variable (consider incorrect results)
          var childAge = splitChildAge ? parseInt(splitChildAge[j], 10) : ''; // Validate incorrect results

          if (childAge === '' || Number.isNaN(childAge)) {
            roomPaxInfo[i].children.push(11);
          } // Valiate older children


          if (childAge > 1 && childAge <= 11) {
            roomPaxInfo[i].children.push(childAge);
          } else if (childAge > 11) {
            roomPaxInfo[i].children.push(11);
          } // Validate infants, cannot be more than adults


          if (childAge === 1) {
            noOfInfant += 1;

            if (noOfInfant > noOfAdult) {
              // If this infant is not allowed as there is not enough adults, remove the infant.
              validation.status = 0;
              validation.message = 'Cannot have more infants than adults in a room';
              noOfChild -= 1; // roomPaxInfo[i].child = noOfChild;
            } else {
              // Everything is ok
              roomPaxInfo[i].children.push(1);
            }
          }
        }
      } // Running count of total (Infants aren't counted towards total pax limitations)


      totalPax += noOfAdult + noOfChild - noOfInfant;
    }
  }

  validation.value = roomPaxInfo;

  if (totalPax > config.maxPax) {
    validation.status = 0;
    validation.message = "Maximum of ".concat(config.maxPax, " passengers only"); // send 2 adults & 1 room as default

    validation.value = [{
      adult: 2
    }];
  }

  console.log(roomPaxInfo);
  return validation;
}
function validateChildAge(roomPax, childAges) {
  var validation = {
    status: 1,
    message: 'utils.qs.success',
    value: []
  };
  var childAgeInfo = [];

  for (var i = 0; i < roomPax.length; i++) {
    // TODO compare number of children per room & comapare relavent child age
    var splitPax = roomPax[i].split(',');
    var noOfChild = parseInt(splitPax[1], 10);

    if (noOfChild) {
      var splitChildAge = childAges[i].split(',');
      var childAgePerRoom = [];
      var maxChild = noOfChild <= 3 ? noOfChild : 3; // max number of child per room

      for (var j = 0; j < maxChild; j++) {
        var childAge = parseInt(splitChildAge[j], 10); // exist or not or given age is more than 11

        if (Number.isNaN(childAge) || childAge > 11) {
          // compare with number of child, add missing age as 11
          childAgePerRoom.push(11);
        } else {
          childAgePerRoom.push(childAge);
        }
      }

      childAgeInfo.push(childAgePerRoom);
    } else {
      // add empty value if no child in a room
      childAgeInfo.push([]);
    }

    validation.value = childAgeInfo;
  }

  return validation;
}
function ValidateQuery(query, config) {
  // Gets the number of rooms in an array
  function getRoomsParams() {
    var rooms = [];
    Object.keys(query).forEach(function (key) {
      if (key.startsWith('room[')) {
        // check duplicate room parameters
        var isArray = Array.isArray(query[key]);

        if (isArray) {
          for (var i = 0; i < query[key].length; i++) {
            if (query[key][i]) {
              rooms.push(query[key][i]);
              break;
            }
          }
        } else if (query[key]) {
          rooms.push(query[key]);
        }
      }
    });
    return rooms;
  }

  function getChildAgeParams() {
    var childAges = [];
    Object.keys(query).forEach(function (key, index) {
      if (key.startsWith('childAges[')) {
        // TODO refactor, order of room and childAges not correct
        if (!query[key]) {
          // if childage value is empty
          var isArray = Array.isArray(query[key]);

          if (isArray) {
            for (var i = 0; i < query[key].length; i++) {
              if (query[key][i]) {
                childAges.push(query[key][i]);
                break;
              }
            }
          } else if (query[key]) {
            childAges.push(query[key]);
          }
        } else {
          childAges.push(query[key]);
        }
      }
    });
    return childAges;
  }

  var qs = {
    originCity: query.origin || '',
    destinationCity: query.destination || '',
    departDate: query.depart || '',
    returnDate: query.return || ''
  };
  var results = {
    validOrigin: originCityValidation(qs.originCity.toUpperCase()),
    validDestination: destinationCityValidation(qs.originCity.toUpperCase(), qs.destinationCity.toUpperCase()),
    validDepartDate: departDateValidation(qs.departDate, config),
    validReturnDate: returnDateValidation(qs.departDate, qs.returnDate, config),
    validPax: paxValidation(getRoomsParams(), config, getChildAgeParams()) // validChildAge: validateChildAge(getRoomsParams(), getChildAgeParams()),

  };
  return results;
} // Formatted Messages

var FormattedMessages = {
  'utils.qs.invalid_date': function utilsQsInvalid_date() {
    return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
      id: "utils.qs.invalid_date",
      defaultMessage: "Given return date doesnt suit our search criteria, Please try different return date",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 417
      }
    });
  },
  'utils.qs.empty_room': function utilsQsEmpty_room() {
    return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
      id: "utils.qs.empty_room",
      defaultMessage: "Please check rooms pax, It should be empty",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 418
      }
    });
  },
  'utils.qs.success': function utilsQsSuccess() {
    return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
      id: "utils.qs.success",
      defaultMessage: "Success",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 419
      }
    });
  }
};
function getFormattedMessage(messageId) {
  if (FormattedMessages[messageId]) {
    return FormattedMessages[messageId]();
  }

  return '';
}

/***/ }),

/***/ 5:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("./pages/HotelResults/index.jsx");


/***/ }),

/***/ "@babel/runtime/regenerator":
/***/ (function(module, exports) {

module.exports = require("@babel/runtime/regenerator");

/***/ }),

/***/ "@paralleldrive/react-feature-toggles":
/***/ (function(module, exports) {

module.exports = require("@paralleldrive/react-feature-toggles");

/***/ }),

/***/ "date-fns":
/***/ (function(module, exports) {

module.exports = require("date-fns");

/***/ }),

/***/ "date-fns/add_days":
/***/ (function(module, exports) {

module.exports = require("date-fns/add_days");

/***/ }),

/***/ "date-fns/difference_in_calendar_days":
/***/ (function(module, exports) {

module.exports = require("date-fns/difference_in_calendar_days");

/***/ }),

/***/ "date-fns/format":
/***/ (function(module, exports) {

module.exports = require("date-fns/format");

/***/ }),

/***/ "date-fns/get_month":
/***/ (function(module, exports) {

module.exports = require("date-fns/get_month");

/***/ }),

/***/ "date-fns/get_year":
/***/ (function(module, exports) {

module.exports = require("date-fns/get_year");

/***/ }),

/***/ "date-fns/locale/en":
/***/ (function(module, exports) {

module.exports = require("date-fns/locale/en");

/***/ }),

/***/ "date-fns/locale/zh_cn":
/***/ (function(module, exports) {

module.exports = require("date-fns/locale/zh_cn");

/***/ }),

/***/ "date-fns/locale/zh_tw":
/***/ (function(module, exports) {

module.exports = require("date-fns/locale/zh_tw");

/***/ }),

/***/ "ip":
/***/ (function(module, exports) {

module.exports = require("ip");

/***/ }),

/***/ "lodash":
/***/ (function(module, exports) {

module.exports = require("lodash");

/***/ }),

/***/ "next/dynamic":
/***/ (function(module, exports) {

module.exports = require("next/dynamic");

/***/ }),

/***/ "next/link":
/***/ (function(module, exports) {

module.exports = require("next/link");

/***/ }),

/***/ "next/router":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "query-string":
/***/ (function(module, exports) {

module.exports = require("query-string");

/***/ }),

/***/ "raven-js":
/***/ (function(module, exports) {

module.exports = require("raven-js");

/***/ }),

/***/ "react":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-day-picker":
/***/ (function(module, exports) {

module.exports = require("react-day-picker");

/***/ }),

/***/ "react-dom":
/***/ (function(module, exports) {

module.exports = require("react-dom");

/***/ }),

/***/ "react-helmet":
/***/ (function(module, exports) {

module.exports = require("react-helmet");

/***/ }),

/***/ "react-icons/fa":
/***/ (function(module, exports) {

module.exports = require("react-icons/fa");

/***/ }),

/***/ "react-icons/fa/":
/***/ (function(module, exports) {

module.exports = require("react-icons/fa/");

/***/ }),

/***/ "react-icons/io":
/***/ (function(module, exports) {

module.exports = require("react-icons/io");

/***/ }),

/***/ "react-icons/md":
/***/ (function(module, exports) {

module.exports = require("react-icons/md");

/***/ }),

/***/ "react-icons/ti":
/***/ (function(module, exports) {

module.exports = require("react-icons/ti");

/***/ }),

/***/ "react-image-gallery":
/***/ (function(module, exports) {

module.exports = require("react-image-gallery");

/***/ }),

/***/ "react-input-range":
/***/ (function(module, exports) {

module.exports = require("react-input-range");

/***/ }),

/***/ "react-intl":
/***/ (function(module, exports) {

module.exports = require("react-intl");

/***/ }),

/***/ "react-mapbox-gl":
/***/ (function(module, exports) {

module.exports = require("react-mapbox-gl");

/***/ }),

/***/ "react-overlays/lib/Modal":
/***/ (function(module, exports) {

module.exports = require("react-overlays/lib/Modal");

/***/ }),

/***/ "react-redux":
/***/ (function(module, exports) {

module.exports = require("react-redux");

/***/ }),

/***/ "react-star-rating-component":
/***/ (function(module, exports) {

module.exports = require("react-star-rating-component");

/***/ }),

/***/ "styled-jsx/style":
/***/ (function(module, exports) {

module.exports = require("styled-jsx/style");

/***/ })

/******/ });
//# sourceMappingURL=HotelResults.js.map