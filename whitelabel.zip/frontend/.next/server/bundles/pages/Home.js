module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 3);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./client-data.js":
/***/ (function(module, exports, __webpack_require__) {

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

// Note: Server Config is for API Path that should be hidden from client
var prod = "development" === 'production'; // TODO: Some variables here will be set by published environment variable
// This is created for easy access for environment variables with less human error

var ClientData =
/*#__PURE__*/
function () {
  function ClientData() {
    _classCallCheck(this, ClientData);
  }

  _createClass(ClientData, null, [{
    key: "IS_PRODUCTION",
    get: function get() {
      return "development" === 'production';
    }
  }, {
    key: "SENTRY_DSN",
    get: function get() {
      return 'https://22c5e2d624584ca1aa56dcb20b2de87a@sentry.io/1237747';
    }
  }, {
    key: "ENVIRONMENT",
    get: function get() {
      return "development";
    } // TODO: release version retrieved from a file overriden by auto-deployment

  }, {
    key: "RELEASE_VERSION",
    get: function get() {
      return '0.0.1';
    }
  }, {
    key: "API_PATH",
    get: function get() {
      // TODO Change to real api
      return process.env.API_ENV === 'development' ? 'http://white-label-server.s3.amazonaws.com' : 'http://white-label-server.s3.amazonaws.com';
    }
  }]);

  return ClientData;
}();

Object.defineProperty(ClientData, "SELECTED_CURRENCY", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: ''
});
module.exports = ClientData;

/***/ }),

/***/ "./client-error.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ClientErrorHandler; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ip__ = __webpack_require__("ip");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ip___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_ip__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__react_next_error__ = __webpack_require__("./react-next/error/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__react_next_error___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__react_next_error__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__client_data__ = __webpack_require__("./client-data.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__client_data___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__client_data__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return _get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// Note: it is important to seperate Client and Server Errors


 // TODO: Setting Error Mapping, haven't decide on the mapping object structure

var errorMap = new Map(); // Refer to sentry options here
// https://docs.sentry.io/clients/node/config/

var ClientErrorHandler =
/*#__PURE__*/
function (_ErrorHandler) {
  _inherits(ClientErrorHandler, _ErrorHandler);

  function ClientErrorHandler() {
    var _this;

    _classCallCheck(this, ClientErrorHandler);

    _this = _possibleConstructorReturn(this, (ClientErrorHandler.__proto__ || Object.getPrototypeOf(ClientErrorHandler)).call(this, __WEBPACK_IMPORTED_MODULE_2__client_data___default.a.SENTRY_DSN, __WEBPACK_IMPORTED_MODULE_2__client_data___default.a.ENVIRONMENT, __WEBPACK_IMPORTED_MODULE_2__client_data___default.a.RELEASE_VERSION, errorMap));
    _this.isOn = false;
    return _this;
  }

  _createClass(ClientErrorHandler, [{
    key: "install",
    value: function install() {
      _get(ClientErrorHandler.prototype.__proto__ || Object.getPrototypeOf(ClientErrorHandler.prototype), "install", this).call(this);

      if (this.dsn && this.isOn) {
        this.getRaven().setUserContext({
          ip_address: __WEBPACK_IMPORTED_MODULE_0_ip___default.a.address()
        });
      }
    }
  }], [{
    key: "getInstance",
    value: function getInstance() {
      if (!ClientErrorHandler._INSTANCE) {
        ClientErrorHandler._INSTANCE = new ClientErrorHandler();
      }

      return ClientErrorHandler._INSTANCE;
    }
  }]);

  return ClientErrorHandler;
}(__WEBPACK_IMPORTED_MODULE_1__react_next_error___default.a);



/***/ }),

/***/ "./components/Common/Backdrop/Backdrop.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__backdrop_scss__ = __webpack_require__("./components/Common/Backdrop/backdrop.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__backdrop_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__backdrop_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\Common\\Backdrop\\Backdrop.jsx";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }




var Backdrop = function Backdrop(props) {
  var isOpen = props.isOpen,
      onClick = props.onClick,
      rest = _objectWithoutProperties(props, ["isOpen", "onClick"]);

  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", _extends({
    className: "popup-backdrop ".concat(isOpen ? 'open' : ''),
    onClick: onClick,
    role: "presentation"
  }, rest, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11
    }
  }));
};

/* harmony default export */ __webpack_exports__["a"] = (Backdrop);

/***/ }),

/***/ "./components/Common/Backdrop/backdrop.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/Common/Backdrop/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__Backdrop__ = __webpack_require__("./components/Common/Backdrop/Backdrop.jsx");

/* harmony default export */ __webpack_exports__["a"] = (__WEBPACK_IMPORTED_MODULE_0__Backdrop__["a" /* default */]);

/***/ }),

/***/ "./components/Common/DatePicker/_datepicker.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/Common/DatePicker/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux__ = __webpack_require__("react-redux");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_redux__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_day_picker__ = __webpack_require__("react-day-picker");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_day_picker___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_day_picker__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__store_modules_locale_selection_selectors__ = __webpack_require__("./store/modules/locale-selection/selectors.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__react_next_intl_date_locale__ = __webpack_require__("./react-next/intl/date-locale.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__datepicker_scss__ = __webpack_require__("./components/Common/DatePicker/_datepicker.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__datepicker_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__datepicker_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\Common\\DatePicker\\index.jsx";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }



 // TODO: use index.js to wrap as one module with selectors actionTypes and etc.
// import actionTypes from '../../../modules/locale-selection/action-types';





var DatePicker =
/*#__PURE__*/
function (_React$Component) {
  _inherits(DatePicker, _React$Component);

  function DatePicker() {
    _classCallCheck(this, DatePicker);

    return _possibleConstructorReturn(this, (DatePicker.__proto__ || Object.getPrototypeOf(DatePicker)).apply(this, arguments));
  }

  _createClass(DatePicker, [{
    key: "componentWillMount",
    value: function componentWillMount() {// const { dispatch } = this.props;
      // dispatch({ type: actionTypes.GET_SELECTED_CULTURE_CODE });
    }
  }, {
    key: "render",
    value: function render() {
      var _props = this.props,
          selectedCultureCode = _props.selectedCultureCode,
          changeYear = _props.changeYear,
          changedMonth = _props.changedMonth,
          changed = _props.changed,
          selected = _props.selected,
          minStartDay = _props.minStartDay,
          maxStartDay = _props.maxStartDay;
      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_day_picker___default.a, {
        locale: selectedCultureCode ? selectedCultureCode : 'en-US',
        localeUtils: __WEBPACK_IMPORTED_MODULE_4__react_next_intl_date_locale__["a" /* dayPickerLocaleUtils */],
        month: new Date(changeYear, changedMonth),
        onDayClick: changed,
        selectedDays: [new Date(selected)],
        disabledDays: [{
          before: new Date(minStartDay),
          after: new Date(maxStartDay)
        }],
        __source: {
          fileName: _jsxFileName,
          lineNumber: 29
        }
      });
    }
  }]);

  return DatePicker;
}(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Component);

;

var mapStateToProps = function mapStateToProps(state) {
  return {
    selectedCultureCode: Object(__WEBPACK_IMPORTED_MODULE_3__store_modules_locale_selection_selectors__["a" /* getCultureCode */])(state)
  };
};

/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_1_react_redux__["connect"])(mapStateToProps)(DatePicker));

/***/ }),

/***/ "./components/CurrenciesSwitcher/CurrenciesSwitcher.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/CurrenciesSwitcher/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux__ = __webpack_require__("react-redux");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_redux__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_query_string__ = __webpack_require__("query-string");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_query_string___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_query_string__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__CurrenciesSwitcher_scss__ = __webpack_require__("./components/CurrenciesSwitcher/CurrenciesSwitcher.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__CurrenciesSwitcher_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__CurrenciesSwitcher_scss__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_fa___ = __webpack_require__("react-icons/fa/");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_fa____default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_icons_fa___);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__Common_Backdrop__ = __webpack_require__("./components/Common/Backdrop/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__react_next_intl_currency_names__ = __webpack_require__("./react-next/intl/currency-names.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__react_next_intl_currency_symbols__ = __webpack_require__("./react-next/intl/currency-symbols.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__store_modules_currency_selection_action_types__ = __webpack_require__("./store/modules/currency-selection/action-types.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__store_modules_currency_selection_selectors__ = __webpack_require__("./store/modules/currency-selection/selectors.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__store_modules_locale_selection_selectors__ = __webpack_require__("./store/modules/locale-selection/selectors.js");
var _jsxFileName = "C:\\Projects\\frontend\\components\\CurrenciesSwitcher\\index.jsx";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }













var CurrenciesSwitcher =
/*#__PURE__*/
function (_React$Component) {
  _inherits(CurrenciesSwitcher, _React$Component);

  function CurrenciesSwitcher(props) {
    var _this;

    _classCallCheck(this, CurrenciesSwitcher);

    _this = _possibleConstructorReturn(this, (CurrenciesSwitcher.__proto__ || Object.getPrototypeOf(CurrenciesSwitcher)).call(this, props));
    _this.state = {
      isCurrencyOpen: false
    };
    _this.triggerCurrencyDropdown = _this.triggerCurrencyDropdown.bind(_assertThisInitialized(_this));
    _this.selectCurrency = _this.selectCurrency.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(CurrenciesSwitcher, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      /*// No Longer Needed
      const { dispatch } = this.props;
      if (typeof window !== 'undefined') {
        const parsed = queryString.parse(window.location.search);
        const { currency } = parsed;
        if (currency) {
          dispatch({ type: actionTypes.SELECT_CURRENCY_FROM_URL_REQUEST, payload: { currency } });
        }
      }
      /*/
    }
  }, {
    key: "triggerCurrencyDropdown",
    value: function triggerCurrencyDropdown() {
      var isCurrencyOpen = this.state.isCurrencyOpen;
      this.setState({
        isCurrencyOpen: !isCurrencyOpen
      });
    }
  }, {
    key: "selectCurrency",
    value: function selectCurrency(currency) {
      var dispatch = this.props.dispatch;
      dispatch({
        type: __WEBPACK_IMPORTED_MODULE_8__store_modules_currency_selection_action_types__["a" /* default */].SELECT_CURRENCY,
        currency: currency
      });
      this.setState({
        isCurrencyOpen: false
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var isCurrencyOpen = this.state.isCurrencyOpen;
      var _props = this.props,
          currencies = _props.currencies,
          selectedCurrency = _props.selectedCurrency,
          selectedLanguage = _props.selectedLanguage;
      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "dropdown-list dropdown-list--currency ".concat(isCurrencyOpen ? 'is-open' : ''),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 64
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "dropdown-list__button",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 65
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("button", {
        type: "button",
        className: "link",
        title: "Change currency",
        onClick: this.triggerCurrencyDropdown,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 66
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("strong", {
        className: "link__text",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 67
        }
      }, selectedCurrency), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_icons_fa___["FaCaretDown"], {
        className: "link__fa-icon",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 70
        }
      }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "dropdown-list__popup",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 73
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("ul", {
        className: "dropdown-list__listing",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 74
        }
      }, currencies.map(function (cr) {
        return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("li", {
          className: "dropdown-list__item ".concat(cr === selectedCurrency ? 'is-active' : ''),
          key: cr,
          onClick: function onClick() {
            return _this2.selectCurrency(cr);
          },
          role: "presentation",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 76
          }
        }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
          className: "dropdown-list__currency dropdown-list__currency--text",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 77
          }
        }, cr), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
          className: "dropdown-list__currency dropdown-list__currency--desc",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 80
          }
        }, Object(__WEBPACK_IMPORTED_MODULE_6__react_next_intl_currency_names__["a" /* default */])(selectedLanguage, cr)), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
          className: "dropdown-list__currency dropdown-list__currency--sign",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 83
          }
        }, Object(__WEBPACK_IMPORTED_MODULE_7__react_next_intl_currency_symbols__["a" /* getCurrencySymbol */])(cr)));
      }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__Common_Backdrop__["a" /* default */], {
        isOpen: isCurrencyOpen,
        onClick: this.triggerCurrencyDropdown,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 90
        }
      }));
    }
  }]);

  return CurrenciesSwitcher;
}(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Component);

var mapStateToProps = function mapStateToProps(state) {
  return {
    selectedLanguage: Object(__WEBPACK_IMPORTED_MODULE_10__store_modules_locale_selection_selectors__["a" /* getCultureCode */])(state),
    selectedCurrency: Object(__WEBPACK_IMPORTED_MODULE_9__store_modules_currency_selection_selectors__["a" /* getSelectedCurrency */])(state)
  };
};

/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_1_react_redux__["connect"])(mapStateToProps)(CurrenciesSwitcher));

/***/ }),

/***/ "./components/SearchForm/SearchForm.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/SearchForm/actions.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return actionTypes; });
/* harmony export (immutable) */ __webpack_exports__["b"] = failure;
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return setFetching; });
/* unused harmony export getLocationRequest */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return getLocationSuccess; });
/* unused harmony export startSearch */
/* unused harmony export startSearchSuccess */
var actionTypes = {
  FAILURE: 'FAILURE',
  SET_FETCHING: 'SET_FETCHING',
  GET_LOCATION_REQUEST: 'GET_LOCATION_REQUEST',
  GET_LOCATION_SUCCESS: 'GET_LOCATION_SUCCESS',
  START_SEARCH_REQUEST: 'START_SEARCH_REQUEST',
  START_SEARCH_SUCCESS: 'START_SEARCH_SUCCESS'
};
function failure(error) {
  return {
    type: actionTypes.FAILURE,
    error: error
  };
}
var setFetching = function setFetching(value) {
  return {
    type: actionTypes.SET_FETCHING,
    value: value
  };
};
var getLocationRequest = function getLocationRequest() {
  return {
    type: actionTypes.GET_LOCATION_REQUEST
  };
};
var getLocationSuccess = function getLocationSuccess(data) {
  return {
    type: actionTypes.GET_LOCATION_SUCCESS,
    data: data
  };
};
var startSearch = function startSearch() {
  return {
    type: actionTypes.START_SEARCH_REQUEST
  };
};
var startSearchSuccess = function startSearchSuccess() {
  return {
    type: actionTypes.START_SEARCH_SUCCESS
  };
};

/***/ }),

/***/ "./components/SearchForm/components/DropdownList.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export AIRPORT_TYPE */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_md__ = __webpack_require__("react-icons/md");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_md___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_icons_md__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__DropdownMessage__ = __webpack_require__("./components/SearchForm/components/DropdownMessage.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\DropdownList.jsx";



var AIRPORT_TYPE = {
  AIRPORT: 'airport',
  CITY: 'city',
  COUNTPAGE: 20
};

var DropdownList = function DropdownList(props) {
  var resultLocation = props.resultLocation,
      handleLocation = props.handleLocation,
      cursorLocation = props.cursorLocation,
      typeLocation = props.typeLocation,
      fetching = props.fetching,
      selected = props.selected;
  return !fetching && resultLocation.length > 0 ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__dropdown__list",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    }
  }, resultLocation.length > 0 && resultLocation.slice(0, AIRPORT_TYPE.COUNTPAGE).map(function (item, i) {
    if ("".concat(item.airportName, " - (").concat(item.airportCode, ")") !== selected) {
      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        role: "presentation",
        className: "searchForm__dropdown__item ".concat(cursorLocation - 1 === i ? 'searchForm__dropdown__item--active' : null),
        "data-name": item.airportName,
        "data-code": item.airportCode,
        key: item.airportCode,
        onClick: function onClick() {
          return handleLocation(item);
        },
        "data-type": typeLocation,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 40
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "icon",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 49
        }
      }, item.type.toString() === AIRPORT_TYPE.AIRPORT ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_icons_md__["MdMyLocation"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 52
        }
      }) : __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_icons_md__["MdLocationCity"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 53
        }
      })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "detail",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 56
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "name",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 57
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("b", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 58
        }
      }, item.airportName), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 61
        }
      }, "(", item.airportCode, ")")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "origin",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 67
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 68
        }
      }, item.cityName), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("b", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 71
        }
      }, "-", item.countryName))));
    }
  }), ")") : __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__DropdownMessage__["a" /* default */], {
    message: " No results found",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 86
    }
  });
};

/* harmony default export */ __webpack_exports__["a"] = (DropdownList);

/***/ }),

/***/ "./components/SearchForm/components/DropdownMessage.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\DropdownMessage.jsx";


var DropdownMessage = function DropdownMessage(props) {
  var message = props.message;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    className: "searchForm__dropdown__error",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }, message);
};

/* harmony default export */ __webpack_exports__["a"] = (DropdownMessage);

/***/ }),

/***/ "./components/SearchForm/components/DropdownPax.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PAX_TYPE; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_md__ = __webpack_require__("react-icons/md");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_md___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_icons_md__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_intl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__InputCounter__ = __webpack_require__("./components/SearchForm/components/InputCounter.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__DropdownSelect__ = __webpack_require__("./components/SearchForm/components/DropdownSelect.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\DropdownPax.jsx";





var PAX_TYPE = {
  ADULT: 1,
  CHILDREN: 2,
  CHILDREN_RANGE_FROM: 2,
  CHILDREN_RANGE_TO: 11
};

var DropdownPax = function DropdownPax(props) {
  var openDropDown = props.openDropDown,
      rooms = props.rooms,
      addRoom = props.addRoom,
      removeRoom = props.removeRoom,
      maxRoom = props.maxRoom,
      maxAdults = props.maxAdults,
      maxChild = props.maxChild,
      maxTotalofRoom = props.maxTotalofRoom,
      countTotalOfPax = props.countTotalOfPax,
      calculatePassenger = props.calculatePassenger,
      message = props.message,
      selectChildAge = props.selectChildAge,
      onBlur = props.onBlur;

  var RoomBox = function RoomBox() {
    return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
      className: "modifyPax__wrap",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 50
      }
    }, rooms.map(function (item, index) {
      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__room",
        key: index,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 53
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__box",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 54
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__box__title",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 55
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__room__icon",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 56
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_icons_md__["MdHotel"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 57
        }
      })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("b", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 59
        }
      }, 'ROOM ', index + 1)), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__persons",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 64
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__InputCounter__["a" /* default */], {
        title: "Adult",
        min: 1,
        count: item.adults,
        max: maxAdults,
        maxTotal: maxTotalofRoom,
        countTotal: item.adults + item.children.length,
        countTotalOfPax: countTotalOfPax,
        addCount: function addCount() {
          return calculatePassenger(index, PAX_TYPE.ADULT, 1);
        },
        removeCount: function removeCount() {
          return calculatePassenger(index, PAX_TYPE.ADULT, -1);
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 65
        }
      }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__InputCounter__["a" /* default */], {
        title: "Children",
        count: item.children.length,
        min: 0,
        max: maxChild // maxOfAdults={item.adults}
        ,
        maxTotal: maxTotalofRoom,
        countTotal: item.adults + item.children.length,
        countTotalOfPax: countTotalOfPax,
        addCount: function addCount() {
          return calculatePassenger(index, PAX_TYPE.CHILDREN, 1);
        },
        removeCount: function removeCount() {
          return calculatePassenger(index, PAX_TYPE.CHILDREN, -1);
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 76
        }
      }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__age",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 90
        }
      }, item.children.length ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__age__title",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 94
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 95
        }
      }, "Child Age")) : '', __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "modifyPax__age__box",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 102
        }
      }, item.children ? item.children.map(function (child, childIndex) {
        return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__DropdownSelect__["a" /* default */], {
          key: "select_".concat(childIndex),
          value: child,
          isInfantDisabled: item.children.filter(function (c) {
            return c < 2;
          }).length === item.adults,
          onChange: function onChange(e) {
            return selectChildAge(e, index, childIndex);
          },
          __source: {
            fileName: _jsxFileName,
            lineNumber: 104
          }
        });
      }) : null)));
    }));
  };

  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__dropdown searchForm__dropdown--pax ".concat(openDropDown ? 'is-open' : ''),
    onBlur: onBlur,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 119
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "modifyPax",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 120
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "modifyPax__nav",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 121
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__InputCounter__["a" /* default */], {
    title: "Room",
    count: rooms.length,
    min: 1,
    max: maxRoom,
    addCount: addRoom,
    maxTotal: maxTotalofRoom,
    countTotalOfPax: countTotalOfPax,
    removeCount: removeRoom,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 122
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "modifyPax__title",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 132
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 133
    }
  }, "ADULTS"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 136
    }
  }, "CHILDREN 0-12"))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(RoomBox, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 141
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "modifyPax__notify",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 142
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 143
    }
  }, message))));
};

/* harmony default export */ __webpack_exports__["b"] = (DropdownPax);

/***/ }),

/***/ "./components/SearchForm/components/DropdownResult.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__DropdownMessage__ = __webpack_require__("./components/SearchForm/components/DropdownMessage.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__DropdownList__ = __webpack_require__("./components/SearchForm/components/DropdownList.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\DropdownResult.jsx";




// eslint-disable-next-line prefer-stateless-function
var DropdownResult = function DropdownResult(props) {
  var resultLocation = props.resultLocation,
      handleLocation = props.handleLocation,
      fetching = props.fetching,
      isOpen = props.isOpen,
      selected = props.selected,
      cursorLocation = props.cursorLocation,
      typeLocation = props.typeLocation;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__dropdown ".concat(isOpen ? 'is-open' : ''),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, fetching ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__DropdownMessage__["a" /* default */], {
    message: "Loading...",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    }
  }) : __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__DropdownList__["a" /* default */], {
    resultLocation: resultLocation,
    handleLocation: handleLocation,
    cursorLocation: cursorLocation,
    typeLocation: typeLocation,
    fetchin: fetching,
    selected: selected,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    }
  }));
};

/* harmony default export */ __webpack_exports__["a"] = (DropdownResult);

/***/ }),

/***/ "./components/SearchForm/components/DropdownSelect.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_lodash__ = __webpack_require__("lodash");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_lodash___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_lodash__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__DropdownPax__ = __webpack_require__("./components/SearchForm/components/DropdownPax.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\DropdownSelect.jsx";




var DropdownSelect = function DropdownSelect(props) {
  var onChange = props.onChange,
      value = props.value,
      isInfantDisabled = props.isInfantDisabled;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("select", {
    className: "modifyPax__age__select",
    value: value,
    onChange: onChange,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("option", {
    value: "1",
    disabled: isInfantDisabled && value !== 1,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 16
    }
  }, "Below 2 years"), __WEBPACK_IMPORTED_MODULE_1_lodash___default.a.range(__WEBPACK_IMPORTED_MODULE_2__DropdownPax__["a" /* PAX_TYPE */].CHILDREN_RANGE_FROM, __WEBPACK_IMPORTED_MODULE_2__DropdownPax__["a" /* PAX_TYPE */].CHILDREN_RANGE_TO + 1).map(function (childAge) {
    return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("option", {
      key: childAge,
      value: childAge,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 20
      }
    }, childAge, ' years old');
  }));
};

/* harmony default export */ __webpack_exports__["a"] = (DropdownSelect);

/***/ }),

/***/ "./components/SearchForm/components/InputCounter.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_intl__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\InputCounter.jsx";



var InputCounter = function InputCounter(props) {
  var title = props.title,
      count = props.count,
      min = props.min,
      max = props.max,
      maxTotal = props.maxTotal,
      countTotal = props.countTotal,
      addCount = props.addCount,
      removeCount = props.removeCount,
      maxOfAdults = props.maxOfAdults,
      countTotalOfPax = props.countTotalOfPax;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "modifyPax__count",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("button", {
    type: "button",
    className: "modifyPax__add ".concat(count === min ? 'modifyPax__add--disable' : ''),
    onClick: removeCount,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    }
  }, "-"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "modifyPax__text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "inputCounter.{titles}",
    defaultMessage: "\n              {counts, plural,\n                  =0 {{counts} {titles}}\n                  one {{counts} {titles}}\n                  other {{counts} {titles}s}\n              }\n          ",
    values: {
      counts: count,
      titles: title
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("button", {
    type: "button",
    className: "modifyPax__add ".concat(count === max || countTotal === maxTotal || countTotalOfPax === maxTotal || count === maxOfAdults ? 'modifyPax__add--disable' : ''),
    onClick: addCount,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 56
    }
  }, "+"));
};

/* harmony default export */ __webpack_exports__["a"] = (InputCounter);

/***/ }),

/***/ "./components/SearchForm/components/InputDatePicker.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux__ = __webpack_require__("react-redux");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_redux__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_date_fns_get_month__ = __webpack_require__("date-fns/get_month");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_date_fns_get_month___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_date_fns_get_month__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_date_fns_get_year__ = __webpack_require__("date-fns/get_year");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_date_fns_get_year___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_date_fns_get_year__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_io__ = __webpack_require__("react-icons/io");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_icons_io___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_icons_io__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__react_next_intl_date_locale__ = __webpack_require__("./react-next/intl/date-locale.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__store_modules_locale_selection_selectors__ = __webpack_require__("./store/modules/locale-selection/selectors.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__Common_DatePicker__ = __webpack_require__("./components/Common/DatePicker/index.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\InputDatePicker.jsx";









var InputDatePicker = function InputDatePicker(props) {
  var selectedCultureCode = props.selectedCultureCode,
      initDate = props.initDate,
      title = props.title,
      placeHolder = props.placeHolder,
      openHandle = props.openHandle,
      name = props.name,
      inputRef = props.inputRef,
      setDate = props.setDate,
      minStartDay = props.minStartDay,
      maxStartDay = props.maxStartDay,
      openDropDown = props.openDropDown;
  var dateSelected = Object(__WEBPACK_IMPORTED_MODULE_5__react_next_intl_date_locale__["b" /* formatDateString */])(initDate, 'MEDIUM', selectedCultureCode);
  var monthSelected = __WEBPACK_IMPORTED_MODULE_2_date_fns_get_month___default()(initDate);
  var yearSelected = __WEBPACK_IMPORTED_MODULE_3_date_fns_get_year___default()(initDate);
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("strong", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    }
  }, title), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input__group",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input__icon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_icons_io__["IoIosCalendar"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("input", {
    readOnly: true,
    className: "searchForm__input__value datepicker",
    autoComplete: "off",
    type: "text",
    placeholder: placeHolder,
    onClick: openHandle,
    id: name,
    value: dateSelected,
    ref: inputRef,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__dropdown searchForm__dropdown--date ".concat(openDropDown ? 'is-open' : ''),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__Common_DatePicker__["a" /* default */], {
    changedMonth: monthSelected,
    changeYear: yearSelected,
    selected: initDate,
    changed: setDate,
    minStartDay: minStartDay,
    maxStartDay: maxStartDay,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 66
    }
  }))));
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    selectedCultureCode: Object(__WEBPACK_IMPORTED_MODULE_6__store_modules_locale_selection_selectors__["a" /* getCultureCode */])(state)
  };
};

/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_1_react_redux__["connect"])(mapStateToProps)(InputDatePicker));

/***/ }),

/***/ "./components/SearchForm/components/InputPax.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_io__ = __webpack_require__("react-icons/io");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_icons_io___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_icons_io__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\InputPax.jsx";



var InputPax = function InputPax(props) {
  var title = props.title,
      openHandle = props.openHandle,
      name = props.name,
      value = props.value,
      inputRef = props.inputRef;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("strong", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    }
  }, title), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input__group",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input__icon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_icons_io__["IoMdPerson"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("input", {
    className: "searchForm__input__value",
    autoComplete: "off",
    onClick: openHandle,
    type: "text",
    id: name,
    defaultValue: value,
    ref: inputRef,
    readOnly: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    }
  })));
};

/* harmony default export */ __webpack_exports__["a"] = (InputPax);

/***/ }),

/***/ "./components/SearchForm/components/InputText.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\InputText.jsx";


var InputText = function InputText(props) {
  var onChange = props.onChange,
      value = props.value,
      name = props.name,
      onClick = props.onClick,
      inputRef = props.inputRef,
      icon = props.icon,
      onBlur = props.onBlur,
      onKeyDown = props.onKeyDown;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input__group",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input__icon",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("i", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, icon)), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("input", {
    className: "searchForm__input__value",
    autoComplete: "off",
    type: "text",
    id: name,
    onChange: onChange,
    value: value,
    onClick: onClick,
    ref: inputRef,
    onBlur: onBlur,
    onKeyDown: onKeyDown,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  }));
};

/* harmony default export */ __webpack_exports__["a"] = (InputText);

/***/ }),

/***/ "./components/SearchForm/components/InputTextGroup.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__InputText__ = __webpack_require__("./components/SearchForm/components/InputText.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__DropdownResult__ = __webpack_require__("./components/SearchForm/components/DropdownResult.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\InputTextGroup.jsx";




var InputTextGroup = function InputTextGroup(props) {
  var title = props.title,
      name = props.name,
      openHandle = props.openHandle,
      getLocations = props.getLocations,
      value = props.value,
      resultLocation = props.resultLocation,
      openDropDown = props.openDropDown,
      fetching = props.fetching,
      setLocation = props.setLocation,
      inputRef = props.inputRef,
      selected = props.selected,
      icon = props.icon,
      errorText = props.errorText,
      onBlur = props.onBlur,
      onKeyDown = props.onKeyDown,
      cursorLocation = props.cursorLocation;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__input",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("strong", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    }
  }, title), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__InputText__["a" /* default */], {
    name: name,
    onClick: openHandle,
    onChange: getLocations,
    value: value,
    icon: icon,
    inputRef: inputRef,
    onBlur: onBlur,
    onKeyDown: onKeyDown,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    }
  }), errorText.length ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "searchForm__error",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    }
  }, errorText) : '', __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__DropdownResult__["a" /* default */], {
    resultLocation: resultLocation,
    isOpen: openDropDown,
    handleLocation: setLocation,
    fetching: fetching,
    cursorLocation: cursorLocation,
    typeLocation: name,
    selected: selected,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 67
    }
  }));
};

/* harmony default export */ __webpack_exports__["a"] = (InputTextGroup);

/***/ }),

/***/ "./components/SearchForm/components/Overlay.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\components\\Overlay.jsx";


var Overlay = function Overlay(props) {
  var isOverlay = props.isOverlay,
      clicked = props.clicked;
  return isOverlay && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    role: "presentation",
    className: "searchForm__overlay",
    onClick: clicked,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15
    }
  });
};

/* harmony default export */ __webpack_exports__["a"] = (Overlay);

/***/ }),

/***/ "./components/SearchForm/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_dom__ = __webpack_require__("react-dom");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_dom___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_dom__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_router__ = __webpack_require__("next/router");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_router___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_next_router__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_redux__ = __webpack_require__("react-redux");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_redux___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_redux__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_date_fns_format__ = __webpack_require__("date-fns/format");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_date_fns_format___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_date_fns_format__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days__ = __webpack_require__("date-fns/add_days");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_date_fns_add_days__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_date_fns_difference_in_calendar_days__ = __webpack_require__("date-fns/difference_in_calendar_days");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_date_fns_difference_in_calendar_days___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_date_fns_difference_in_calendar_days__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__actions__ = __webpack_require__("./components/SearchForm/actions.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_InputTextGroup__ = __webpack_require__("./components/SearchForm/components/InputTextGroup.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__components_DropdownPax__ = __webpack_require__("./components/SearchForm/components/DropdownPax.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__components_InputDatePicker__ = __webpack_require__("./components/SearchForm/components/InputDatePicker.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__components_InputPax__ = __webpack_require__("./components/SearchForm/components/InputPax.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__components_Overlay__ = __webpack_require__("./components/SearchForm/components/Overlay.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__store_modules_locale_selection_selectors__ = __webpack_require__("./store/modules/locale-selection/selectors.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__SearchForm_scss__ = __webpack_require__("./components/SearchForm/SearchForm.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__SearchForm_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_14__SearchForm_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\components\\SearchForm\\index.jsx";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }















var IconArrival = function IconArrival(props) {
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("svg", props, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("path", {
    d: "M193.617 303.697l117.086 31.394 143.225 38.4c21.558 5.794 43.655-7.006 49.448-28.564 5.794-21.558-7.006-43.655-28.564-49.448l-143.225-38.4-74.24-243.065L205.204 0v223.124L71.41 187.284l-25.061-62.518-39.073-10.509V253.71l43.25 11.587 143.091 38.4zM0 458.105h512V512H0z"
  }));
};

IconArrival.defaultProps = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 512 512"
};

var IconDeparture = function IconDeparture(props) {
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("svg", props, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("path", {
    d: "M16.539 425.626h479.767v50.502H16.539zM510.7 189.151c-5.429-20.201-26.135-32.195-46.335-26.766l-134.209 35.982L155.924 35.878l-48.734 13.13 104.539 181.175-125.497 33.584-49.618-39.013L0 234.603l45.957 79.667 19.317 33.457 40.528-10.858 134.209-35.983 109.715-29.417 134.209-35.983c20.199-5.429 32.194-26.134 26.765-46.335z"
  }));
};

IconDeparture.defaultProps = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 512.005 512.005"
};



var SearchForm =
/*#__PURE__*/
function (_Component) {
  _inherits(SearchForm, _Component);

  function SearchForm(props) {
    var _this;

    _classCallCheck(this, SearchForm);

    _this = _possibleConstructorReturn(this, (SearchForm.__proto__ || Object.getPrototypeOf(SearchForm)).call(this, props));
    Object.defineProperty(_assertThisInitialized(_this), "getLocations", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(e) {
        var location = e.target.value;
        var dispatch = _this.props.dispatch;

        _this.setState(_defineProperty({}, e.target.id, e.target.value));

        if (location.length > 0) {
          dispatch({
            type: __WEBPACK_IMPORTED_MODULE_7__actions__["a" /* actionTypes */].GET_LOCATION_REQUEST,
            location: location
          });
        }
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "getLocationOnKey", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(e) {
        var airportData = _this.props.airportData;
        var airportResultCursor = _this.state.airportResultCursor;

        if (e.keyCode === 40 || e.keyCode === 38 || e.keyCode === 13 || e.keyCode === 27 || e.keyCode === 9) {
          if (e.keyCode === 38 && airportResultCursor > 0) {
            _this.setState(function (prevState) {
              return {
                airportResultCursor: prevState.airportResultCursor - 1
              };
            });
          } else if (e.keyCode === 40 && airportResultCursor < airportData.length) {
            _this.setState(function (prevState) {
              return {
                airportResultCursor: prevState.airportResultCursor + 1
              };
            });
          } else if (e.keyCode === 13 && airportResultCursor > 0) {
            if (e.target.id === 'SearchNameFrom') {
              var selected = __WEBPACK_IMPORTED_MODULE_1_react_dom___default.a.findDOMNode(_assertThisInitialized(_this)).getElementsByClassName('searchForm__dropdown__item--active');

              _this.setState({
                SearchNameFrom: "".concat(selected[0].getAttribute('data-name'), " - (").concat(selected[0].getAttribute('data-code'), ")"),
                SearchNameFromCode: selected[0].getAttribute('data-code'),
                SearchNameFromError: '',
                SearchNameFromSelected: "".concat(selected[0].getAttribute('data-name'), " - (").concat(selected[0].getAttribute('data-code'), ")")
              });

              _this.inputToRef.current.click();
            } else if (e.target.id === 'SearchNameTo') {
              var _selected = __WEBPACK_IMPORTED_MODULE_1_react_dom___default.a.findDOMNode(_assertThisInitialized(_this)).getElementsByClassName('searchForm__dropdown__item--active');

              _this.setState({
                SearchNameTo: "".concat(_selected[0].getAttribute('data-name'), " - (").concat(_selected[0].getAttribute('data-code'), ")"),
                SearchNameToCode: _selected[0].getAttribute('data-code'),
                SearchNameToError: '',
                SearchNameToSelected: "".concat(_selected[0].getAttribute('data-name'), " - (").concat(_selected[0].getAttribute('data-code'), ")")
              });

              _this.inputDepartureRef.current.click();
            }
          } else if (e.keyCode === 27) {
            _this.setState({
              isDropdownOpen: {},
              isOverlay: false
            });
          } else if (airportData.length >= 1 && e.keyCode === 9) {
            var formTarget = e.target.id;

            if (formTarget === 'SearchNameFrom') {
              _this.setState({
                SearchNameFrom: airportData[0].airportName,
                SearchNameFromCode: airportData[0].airportCode,
                SearchNameFromSelected: airportData[0].airportName
              });
            } else if (formTarget === 'SearchNameTo') {
              _this.setState({
                SearchNameTo: airportData[0].airportName,
                SearchNameToCode: airportData[0].airportCode,
                SearchNameToSelected: airportData[0].airportName
              });
            }
          }
        }
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "setLocationFrom", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(item) {
        _this.setState({
          SearchNameFrom: "".concat(item.airportName, " - (").concat(item.airportCode, ")"),
          SearchNameFromCode: item.airportCode,
          SearchNameFromError: '',
          SearchNameFromSelected: "".concat(item.airportName, " - (").concat(item.airportCode, ")")
        });

        _this.inputToRef.current.click();
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "setLocationTo", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(item) {
        _this.setState({
          SearchNameTo: "".concat(item.airportName, " - (").concat(item.airportCode, ")"),
          SearchNameToCode: item.airportCode,
          SearchNameToError: '',
          SearchNameToSelected: "".concat(item.airportName, " - (").concat(item.airportCode, ")")
        });

        _this.inputDepartureRef.current.click();
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "addPassengerRoom", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        var configSearchForm = _this.props.configSearchForm;
        var rooms = _this.state.rooms;

        var sum = function sum(a) {
          return a.reduce(function (x, y) {
            return x + y;
          });
        };

        var totalAllPeople = sum(rooms.map(function (x) {
          return Number(x.adults);
        })) + sum(rooms.map(function (h) {
          return Number(h.children.length);
        }));

        if (rooms.length >= configSearchForm.maxRooms && totalAllPeople < configSearchForm.maxPax) {
          return;
        }

        var initRoom = {
          adults: 1,
          children: []
        };
        rooms.push(initRoom);

        _this.setState({
          rooms: rooms
        });
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "removePassengerRoom", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        var rooms = _this.state.rooms;

        if (rooms.length === 1) {
          return;
        }

        rooms.pop(rooms);

        _this.setState({
          rooms: rooms
        });
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleChangeDateFrom", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(date) {
        var configSearchForm = _this.props.configSearchForm;
        var returnDate = _this.state.returnDate;

        if (__WEBPACK_IMPORTED_MODULE_6_date_fns_difference_in_calendar_days___default()(returnDate, date) >= configSearchForm.minBookingDays) {
          _this.setState({
            departureDate: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(date, 0),
            returnDate: returnDate
          });
        } else {
          _this.setState({
            departureDate: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(date, 0),
            returnDate: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(date, configSearchForm.minBookingDays)
          });
        }

        _this.inputReturnRef.current.click();
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleChangeDateTo", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(date) {
        _this.setState({
          returnDate: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(date, 0),
          isDropdownOpen: {},
          isOverlay: false
        }); // this.inputPaxRef.current.click();

      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleChangeSearch", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(e) {
        var idOfDOM = e.target.id;

        if (idOfDOM === 'SearchNameTo' || idOfDOM === 'SearchNameFrom') {
          var _dispatch = _this.props.dispatch;

          _dispatch({
            type: __WEBPACK_IMPORTED_MODULE_7__actions__["a" /* actionTypes */].GET_LOCATION_REQUEST
          });
        }

        e.target.select();

        _this.setState({
          isDropdownOpen: {},
          isOverlay: true
        });

        _this.setState({
          isDropdownOpen: _defineProperty({}, idOfDOM, true),
          SearchNameFromError: '',
          SearchNameToError: ''
        });
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "validate", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        var isError = false;
        var errors = {
          SearchNameFromError: '',
          SearchNameToError: ''
        };
        var _this$state = _this.state,
            SearchNameFrom = _this$state.SearchNameFrom,
            SearchNameTo = _this$state.SearchNameTo,
            SearchNameFromCode = _this$state.SearchNameFromCode,
            SearchNameToCode = _this$state.SearchNameToCode;

        if (SearchNameFrom.length === 0 || SearchNameFromCode.length < 3) {
          isError = true;
          errors.SearchNameFromError = 'Please choose somewhere to depart';
        }

        if (SearchNameTo.length === 0 || SearchNameToCode.length < 3) {
          isError = true;
          errors.SearchNameToError = 'Please choose somewhere to go';
        }

        _this.setState(_objectSpread({}, errors));

        return isError;
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleSubmitSearch", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(e) {
        var err = _this.validate();

        _this.setState({
          isDropdownOpen: false
        });

        if (!err) {
          var stateParams = _this.state;
          var _urlLocale = _this.props.urlLocale;
          var fromLocation = stateParams.SearchNameFromCode;
          var toLocation = stateParams.SearchNameToCode;
          var departureDate = __WEBPACK_IMPORTED_MODULE_4_date_fns_format___default()(stateParams.departureDate, 'YYYY-MM-DD');
          var returnDate = __WEBPACK_IMPORTED_MODULE_4_date_fns_format___default()(stateParams.returnDate, 'YYYY-MM-DD');
          var roomsParams = stateParams.rooms;
          var roomString = '';

          for (var i = 0; i < roomsParams.length; i++) {
            var room = roomsParams[i];
            roomString += "&room[".concat(i, "]=").concat(room.adults, ",").concat(room.children.length);

            if (Object.prototype.hasOwnProperty.call(room, 'children') && room.children.length > 1) {
              var childrenPax = room.children;
              roomString += "&childAges[".concat(i, "]=");

              for (var j = 0; j < childrenPax.length; j++) {
                roomString += childrenPax[j] + (j + 1 < childrenPax.length ? ',' : '');
              }
            }
          }

          __WEBPACK_IMPORTED_MODULE_2_next_router___default.a.push("".concat(_urlLocale, "/search/").concat(fromLocation, "/").concat(toLocation, "?depart=").concat(departureDate, "&return=").concat(returnDate).concat(roomString));
          console.log("/search/".concat(fromLocation, "/").concat(toLocation, "?depart=").concat(departureDate, "&return=").concat(returnDate).concat(roomString));
        } else {
          e.preventDefault();
        }
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "closeAllDropdown", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(e) {
        var airportData = _this.props.airportData;
        var formTarget = e.target.id;

        if (airportData.length === 1) {
          if (formTarget === 'SearchNameFrom') {
            _this.setState({
              SearchNameFrom: airportData[0].airportName,
              SearchNameFromCode: airportData[0].airportCode,
              SearchNameFromSelected: airportData[0].airportName
            });
          } else if (formTarget === 'SearchNameTo') {
            _this.setState({
              SearchNameTo: airportData[0].airportName,
              SearchNameToCode: airportData[0].airportCode,
              SearchNameToSelected: airportData[0].airportName
            });
          }
        }
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "overlayHandle", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        var airportData = _this.props.airportData;
        var _this$state2 = _this.state,
            SearchNameFromCode = _this$state2.SearchNameFromCode,
            SearchNameToCode = _this$state2.SearchNameToCode,
            SearchNameFrom = _this$state2.SearchNameFrom,
            SearchNameTo = _this$state2.SearchNameTo,
            SearchNameToSelected = _this$state2.SearchNameToSelected,
            SearchNameFromSelected = _this$state2.SearchNameFromSelected;

        if (airportData.length !== 1) {
          if (SearchNameFrom !== '' && SearchNameFromCode === '') {
            _this.setState({
              SearchNameFrom: ''
            });
          } else if (SearchNameTo !== '' && SearchNameToCode === '') {
            _this.setState({
              SearchNameTo: ''
            });
          } else if (SearchNameFrom !== SearchNameFromSelected && SearchNameFromCode !== '') {
            _this.setState({
              SearchNameFrom: SearchNameFromSelected
            });
          } else if (SearchNameTo !== SearchNameToSelected && SearchNameToCode !== '') {
            _this.setState({
              SearchNameTo: SearchNameToSelected
            });
          }
        }

        _this.setState({
          isOverlay: false,
          isDropdownOpen: false
        });
      }
    });
    _this.state = {
      isDropdownOpen: {},
      departureDate: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(new Date(), props.configSearchForm.minBookingDays),
      returnDate: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(new Date(), props.configSearchForm.minBookingDays + props.configSearchForm.minBookingPeriod),
      SearchNameFrom: '',
      SearchNameFromSelected: '',
      SearchNameTo: '',
      SearchNameToSelected: '',
      SearchNameFromCode: '',
      SearchNameToCode: '',
      SearchNameFromError: '',
      SearchNameToError: '',
      airportResultCursor: 0,
      isOverlay: false,
      rooms: [{
        adults: 2,
        children: []
      }]
    };
    _this.timer = null;
    _this.inputToRef = __WEBPACK_IMPORTED_MODULE_0_react___default.a.createRef();
    _this.inputDepartureRef = __WEBPACK_IMPORTED_MODULE_0_react___default.a.createRef();
    _this.inputReturnRef = __WEBPACK_IMPORTED_MODULE_0_react___default.a.createRef();
    _this.inputPaxRef = __WEBPACK_IMPORTED_MODULE_0_react___default.a.createRef();
    _this.calculatePassenger = _this.calculatePassenger.bind(_assertThisInitialized(_this));
    _this.selectChildAge = _this.selectChildAge.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(SearchForm, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var _props = this.props,
          validateQueryString = _props.validateQueryString,
          packageDetails = _props.packageDetails;

      if (validateQueryString && packageDetails !== undefined) {
        this.setState({
          departureDate: validateQueryString.validDepartDate.value,
          returnDate: validateQueryString.validReturnDate.value,
          SearchNameFrom: packageDetails.originCityName,
          SearchNameTo: packageDetails.destinationCityName,
          SearchNameFromCode: validateQueryString.validOrigin.value,
          SearchNameToCode: validateQueryString.validDestination.value,
          rooms: validateQueryString.validPax.value
        });
      }
    }
  }, {
    key: "calculatePassenger",
    value: function calculatePassenger(index, type, amount) {
      var configSearchForm = this.props.configSearchForm;
      var rooms = this.state.rooms;

      var sum = function sum(a) {
        return a.reduce(function (x, y) {
          return x + y;
        });
      };

      var totalAllPeople = sum(rooms.map(function (x) {
        return Number(x.adults);
      })) + sum(rooms.map(function (h) {
        return Number(h.children.length);
      }));
      var room = rooms[index]; // const totalAdults = room.adults + room.children.length;

      switch (type) {
        case __WEBPACK_IMPORTED_MODULE_9__components_DropdownPax__["a" /* PAX_TYPE */].ADULT:
          if (amount === 1 && totalAllPeople < configSearchForm.maxPax) {
            room.adults += amount;
          } else if (amount === -1 && room.children.length >= room.adults && room.adults > 1) {
            if (room.children.filter(function (c) {
              return c < 2;
            }).length === room.adults) {
              var arrInfant = room.children.lastIndexOf(0);
              room.children.splice(arrInfant, 1);
              console.log(arrInfant);
            }

            room.adults--;
          } else if (amount === -1 && room.adults === 1) {
            return;
          } else if (amount === -1 && room.adults > 0) {
            room.adults--;
          }

          rooms[index] = room;
          this.setState({
            rooms: rooms
          });
          break;

        case __WEBPACK_IMPORTED_MODULE_9__components_DropdownPax__["a" /* PAX_TYPE */].CHILDREN:
          if (amount === 1 && totalAllPeople < configSearchForm.maxPax) {
            if (room.children.length < 3 && room.children.length >= 0) {
              room.children.push(2);
            } else {
              return;
            }
          } else if (amount === -1 && room.children.length > 0) {
            room.children.pop();
          } else {
            return;
          }

          rooms[index] = room;
          this.setState({
            rooms: rooms
          });
          break;

        default:
          break;
      }
    }
  }, {
    key: "selectChildAge",
    value: function selectChildAge(e, index, childIndex) {
      var rooms = this.state.rooms;

      try {
        rooms[index].children[childIndex] = parseInt(e.target.value, 10);
      } catch (err) {
        console.log(err);
      }

      this.setState({
        rooms: rooms
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _props2 = this.props,
          isFetching = _props2.isFetching,
          configSearchForm = _props2.configSearchForm,
          airportData = _props2.airportData;
      var _state = this.state,
          isDropdownOpen = _state.isDropdownOpen,
          SearchNameFrom = _state.SearchNameFrom,
          SearchNameTo = _state.SearchNameTo,
          departureDate = _state.departureDate,
          returnDate = _state.returnDate,
          SearchNameFromSelected = _state.SearchNameFromSelected,
          SearchNameToSelected = _state.SearchNameToSelected,
          rooms = _state.rooms,
          SearchNameFromError = _state.SearchNameFromError,
          SearchNameToError = _state.SearchNameToError,
          airportResultCursor = _state.airportResultCursor,
          isOverlay = _state.isOverlay;

      var sum = function sum(a) {
        return a.reduce(function (x, y) {
          return x + y;
        });
      };

      var AllAdults = sum(rooms.map(function (x) {
        return Number(x.adults);
      })) + sum(rooms.map(function (h) {
        return Number(h.children.length);
      }));
      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "searchForm",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 456
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__components_Overlay__["a" /* default */], {
        isOverlay: isOverlay,
        clicked: this.overlayHandle,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 457
        }
      }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "searchForm__panel",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 461
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("form", {
        className: "searchForm__form",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 462
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "searchForm__content",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 463
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "searchForm__box searchForm__address",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 464
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_InputTextGroup__["a" /* default */], {
        title: "From",
        name: "SearchNameFrom",
        icon: __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(IconDeparture, {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 468
          }
        }),
        value: SearchNameFrom,
        fetching: isFetching,
        openHandle: this.handleChangeSearch,
        openDropDown: isDropdownOpen.SearchNameFrom,
        getLocations: this.getLocations,
        resultLocation: airportData,
        setLocation: this.setLocationFrom,
        selected: SearchNameToSelected,
        errorText: SearchNameFromError,
        onBlur: this.closeAllDropdown,
        onKeyDown: this.getLocationOnKey,
        cursorLocation: airportResultCursor,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 465
        }
      }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_InputTextGroup__["a" /* default */], {
        title: "To",
        name: "SearchNameTo",
        icon: __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(IconArrival, {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 485
          }
        }),
        value: SearchNameTo,
        fetching: isFetching,
        openHandle: this.handleChangeSearch,
        openDropDown: isDropdownOpen.SearchNameTo,
        getLocations: this.getLocations,
        resultLocation: airportData,
        selected: SearchNameFromSelected,
        setLocation: this.setLocationTo,
        inputRef: this.inputToRef,
        errorText: SearchNameToError,
        onBlur: this.closeAllDropdown,
        onKeyDown: this.getLocationOnKey,
        cursorLocation: airportResultCursor,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 482
        }
      })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "searchForm__box searchForm__date",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 501
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__components_InputDatePicker__["a" /* default */], {
        title: "Departure",
        name: "SearchNameDeparture",
        placeHolder: "DD/MM/YYYY",
        minStartDay: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(new Date(), configSearchForm.minBookingDays),
        maxStartDay: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(new Date(), configSearchForm.maxBookingDays),
        openHandle: this.handleChangeSearch,
        openDropDown: isDropdownOpen.SearchNameDeparture,
        initDate: departureDate,
        setDate: this.handleChangeDateFrom,
        inputRef: this.inputDepartureRef,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 502
        }
      }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__components_InputDatePicker__["a" /* default */], {
        title: "Return",
        placeHolder: "DD/MM/YYYY",
        name: "SearchNameReturn",
        minStartDay: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(departureDate, configSearchForm.minBookingPeriod),
        maxStartDay: __WEBPACK_IMPORTED_MODULE_5_date_fns_add_days___default()(departureDate, configSearchForm.maxBookingPeriod),
        openHandle: this.handleChangeSearch,
        openDropDown: isDropdownOpen.SearchNameReturn,
        initDate: returnDate,
        setDate: this.handleChangeDateTo,
        inputRef: this.inputReturnRef,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 514
        }
      })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "searchForm__box searchForm__pax",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 528
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__components_InputPax__["a" /* default */], {
        title: "ROOMS & PASSENGERS",
        name: "SearchNamePax",
        openHandle: this.handleChangeSearch,
        setPassengers: this.setPassengers,
        inputRef: this.inputPaxRef,
        value: "".concat(rooms.length, " Rooms, ").concat(AllAdults, " Peoples"),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 529
        }
      })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__components_DropdownPax__["b" /* default */], {
        openDropDown: isDropdownOpen.SearchNamePax,
        rooms: rooms,
        addRoom: this.addPassengerRoom,
        maxRoom: configSearchForm.maxRooms,
        maxAdults: 3,
        maxChild: 3,
        countTotalOfPax: AllAdults,
        maxTotalofRoom: configSearchForm.maxPax,
        removeRoom: this.removePassengerRoom,
        calculatePassenger: this.calculatePassenger,
        selectChildAge: this.selectChildAge,
        message: "Maximum ".concat(configSearchForm.maxPax, "  guests are allowed per booking"),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 538
        }
      })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
        className: "searchForm__control",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 553
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("button", {
        type: "button",
        className: "searchForm__button btn-theme-primary btn-effect",
        onClick: this.handleSubmitSearch,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 554
        }
      }, "Search")))));
    }
  }]);

  return SearchForm;
}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);

var mapStateToProps = function mapStateToProps(state) {
  return {
    airportData: state.searchForm.airportData,
    isFetching: state.searchForm.isFetching,
    cultureCode: Object(__WEBPACK_IMPORTED_MODULE_13__store_modules_locale_selection_selectors__["a" /* getCultureCode */])(state),
    urlLocale: Object(__WEBPACK_IMPORTED_MODULE_13__store_modules_locale_selection_selectors__["b" /* getUrlLocale */])(state)
  };
};

/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_3_react_redux__["connect"])(mapStateToProps)(SearchForm));

/***/ }),

/***/ "./pages/Home/Home.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/Home/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__ = __webpack_require__("styled-jsx/style");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_redux__ = __webpack_require__("react-redux");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_redux___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_redux__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_helmet__ = __webpack_require__("react-helmet");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_helmet___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_helmet__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_intl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__components_SearchForm__ = __webpack_require__("./components/SearchForm/index.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__PageBase__ = __webpack_require__("./pages/PageBase/index.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__Home_scss__ = __webpack_require__("./pages/Home/Home.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__Home_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__Home_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\pages\\Home\\index.jsx";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }



 // import Link from 'next/link';






var Home =
/*#__PURE__*/
function (_React$Component) {
  _inherits(Home, _React$Component);

  function Home() {
    _classCallCheck(this, Home);

    return _possibleConstructorReturn(this, (Home.__proto__ || Object.getPrototypeOf(Home)).apply(this, arguments));
  }

  _createClass(Home, [{
    key: "render",
    value: function render() {
      // TODO: Check out on props validation, and best way to handle props
      var _props = this.props,
          general = _props.config.general,
          cultureCode = _props.cultureCode; // const { messages } = intl;

      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 32
        },
        className: __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) + " " + (__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) + " " + "wrap-container background-theme-primary" || "")
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_intl__["FormattedMessage"], {
        id: "home.title",
        defaultMessage: "Book a Package",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 33
        }
      }, function (title) {
        return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_helmet__["Helmet"], {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 35
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("title", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 36
          },
          className: __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) + " " + (__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) || "")
        }, "".concat(title, " | ").concat(general.name)));
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a, {
        styleId: "1726651328",
        css: ".background-theme-primary.__jsx-style-dynamic-selector{background-image:url(".concat(general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg', ");}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2VzXFxIb21lXFxpbmRleC5qc3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBMENXLEFBSVksbURBQUMiLCJmaWxlIjoicGFnZXNcXEhvbWVcXGluZGV4LmpzeCIsInNvdXJjZVJvb3QiOiJDOlxcUHJvamVjdHNcXGZyb250ZW5kIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gJ3JlYWN0LXJlZHV4JztcclxuaW1wb3J0IHsgSGVsbWV0IH0gZnJvbSAncmVhY3QtaGVsbWV0JztcclxuLy8gaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcclxuXHJcbmltcG9ydCB7XHJcbiAgLy8gaW5qZWN0SW50bCxcclxuICAvLyBpbnRsU2hhcGUsXHJcbiAgLy8gZGVmaW5lTWVzc2FnZXMsXHJcbiAgRm9ybWF0dGVkTWVzc2FnZSxcclxufSBmcm9tICdyZWFjdC1pbnRsJztcclxuXHJcbmltcG9ydCBTZWFyY2hGb3JtIGZyb20gJ2NvbXBvbmVudHMvU2VhcmNoRm9ybS9pbmRleCc7XHJcbmltcG9ydCBQYWdlQmFzZSBmcm9tICcuLi9QYWdlQmFzZSc7XHJcblxyXG5pbXBvcnQgJy4vSG9tZS5zY3NzJztcclxuXHJcbi8vIEBmbG93XHJcbmltcG9ydCB0eXBlIHsgSG9tZVByb3BzLCBIb21lU3RhdGUgfSBmcm9tICcuL3R5cGVzJztcclxuXHJcbmNsYXNzIEhvbWUgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQ8SG9tZVByb3BzLCBIb21lU3RhdGU+IHtcclxuICBzdGF0ZTogSG9tZVN0YXRlO1xyXG5cclxuICBwcm9wczogSG9tZVByb3BzO1xyXG5cclxuICByZW5kZXIoKSB7XHJcbiAgICAvLyBUT0RPOiBDaGVjayBvdXQgb24gcHJvcHMgdmFsaWRhdGlvbiwgYW5kIGJlc3Qgd2F5IHRvIGhhbmRsZSBwcm9wc1xyXG4gICAgY29uc3QgeyBjb25maWc6IHsgZ2VuZXJhbCB9LCBjdWx0dXJlQ29kZSB9ID0gdGhpcy5wcm9wcztcclxuICAgIC8vIGNvbnN0IHsgbWVzc2FnZXMgfSA9IGludGw7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3cmFwLWNvbnRhaW5lciBiYWNrZ3JvdW5kLXRoZW1lLXByaW1hcnlcIj5cclxuICAgICAgICA8Rm9ybWF0dGVkTWVzc2FnZSBpZD1cImhvbWUudGl0bGVcIiBkZWZhdWx0TWVzc2FnZT1cIkJvb2sgYSBQYWNrYWdlXCI+XHJcbiAgICAgICAgICB7dGl0bGUgPT4gKFxyXG4gICAgICAgICAgICA8SGVsbWV0PlxyXG4gICAgICAgICAgICAgIDx0aXRsZT5cclxuICAgICAgICAgICAgICAgIHtgJHt0aXRsZX0gfCAke2dlbmVyYWwubmFtZX1gfVxyXG4gICAgICAgICAgICAgIDwvdGl0bGU+XHJcbiAgICAgICAgICAgIDwvSGVsbWV0PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L0Zvcm1hdHRlZE1lc3NhZ2U+XHJcbiAgICAgICAgPHN0eWxlIGpzeD5cclxuICAgICAgICAgIHtgXHJcbiAgICAgICAgICAgIC5iYWNrZ3JvdW5kLXRoZW1lLXByaW1hcnkge1xyXG4gICAgICAgICAgICAgIGJhY2tncm91bmQtaW1hZ2U6dXJsKCR7Z2VuZXJhbC5iYWNrZ3JvdW5kSW1hZ2UgfHwgJ2h0dHBzOi8vZDJ2YTFwYm04bXo2Y24uY2xvdWRmcm9udC5uZXQvZmFsbGJhY2tzL2xhbmRpbmctc3BsYXNoLWRlZmF1bHQtMTM2Nng3NjguanBnJ30pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIGB9XHJcbiAgICAgICAgPC9zdHlsZT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIkhvbWVcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiSG9tZV9fd3JhcFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiSG9tZV9fdGl0bGVcIj5cclxuICAgICAgICAgICAgICAgIDxoMT5cclxuICAgICAgICAgICAgICAgICAgPEZvcm1hdHRlZE1lc3NhZ2UgaWQ9XCJob21lLmNhcHRpb25cIiBkZWZhdWx0TWVzc2FnZT1cIkJvb2sgYSBQYWNrYWdlXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJIb21lX19oZWFkZXJcIj5cclxuICAgICAgICAgICAgICAgIDxzdHJvbmc+XHJcbiAgICAgICAgICAgICAgICAgIDxGb3JtYXR0ZWRNZXNzYWdlIGlkPVwiaG9tZS5mbGlnaHRob3RlbFwiIGRlZmF1bHRNZXNzYWdlPVwiRmxpZ2h0ICsgSG90ZWxcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPFNlYXJjaEZvcm1cclxuICAgICAgICAgICAgICAgIGNvbmZpZ1NlYXJjaEZvcm09e2dlbmVyYWx9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGFnZUJhc2UoSG9tZSk7XHJcbiJdfQ== */\n/*@ sourceURL=pages\\Home\\index.jsx */"),
        dynamic: [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 49
        },
        className: __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) + " " + (__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) + " " + "Home" || "")
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 50
        },
        className: __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) + " " + (__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) + " " + "container" || "")
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 51
        },
        className: __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) + " " + (__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) + " " + "Home__wrap" || "")
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 52
        },
        className: __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) + " " + (__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) + " " + "Home__title" || "")
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("h1", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 53
        },
        className: __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) + " " + (__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) || "")
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_intl__["FormattedMessage"], {
        id: "home.caption",
        defaultMessage: "Book a Package",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 54
        }
      }))), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 57
        },
        className: __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) + " " + (__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) + " " + "Home__header" || "")
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("strong", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 58
        },
        className: __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) + " " + (__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a.dynamic([["1726651328", [general.backgroundImage || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/landing-splash-default-1366x768.jpg']]]) || "")
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_intl__["FormattedMessage"], {
        id: "home.flighthotel",
        defaultMessage: "Flight + Hotel",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 59
        }
      }))), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__components_SearchForm__["a" /* default */], {
        configSearchForm: general,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 62
        }
      })))));
    }
  }]);

  return Home;
}(__WEBPACK_IMPORTED_MODULE_1_react___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (Object(__WEBPACK_IMPORTED_MODULE_6__PageBase__["a" /* default */])(Home));

/***/ }),

/***/ "./pages/PageBase/component/Footer/Footer.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/PageBase/component/Footer/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Footer_scss__ = __webpack_require__("./pages/PageBase/component/Footer/Footer.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Footer_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__Footer_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\pages\\PageBase\\component\\Footer\\index.jsx";



var Footer = function Footer(_ref) {
  var generalConfig = _ref.generalConfig;
  var date = new Date();
  var year = date.getFullYear();

  var _ref2 = generalConfig || "Copyright (c) ".concat(year),
      footerText = _ref2.footerText;

  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("footer", {
    className: "footer",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("p", {
    className: "footer__text",
    dangerouslySetInnerHTML: {
      __html: footerText
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15
    }
  })));
};

/* harmony default export */ __webpack_exports__["a"] = (Footer);

/***/ }),

/***/ "./pages/PageBase/component/Header/Header.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/PageBase/component/Header/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_CurrenciesSwitcher__ = __webpack_require__("./components/CurrenciesSwitcher/index.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Header_scss__ = __webpack_require__("./pages/PageBase/component/Header/Header.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Header_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__Header_scss__);
var _jsxFileName = "C:\\Projects\\frontend\\pages\\PageBase\\component\\Header\\index.jsx";
 // import { connect } from 'react-redux';




var sortAlphabetically = function sortAlphabetically(name1, name2) {
  if (name1 < name2) return -1;
  if (name1 > name2) return 1;
  return 0;
};

var Header = function Header(props) {
  var generalConfig = props.generalConfig,
      currenciesSwitcherDisabled = props.currenciesSwitcherDisabled;
  var currencies = generalConfig.currencies;
  currencies.sort(function (cr1, cr2) {
    return sortAlphabetically(cr1, cr2);
  });
  var logo = generalConfig.logo || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/logo-default.png';
  var name = generalConfig.name || 'GoQuo';
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("header", {
    className: "header",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "container container--header",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "header__logo",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("a", {
    href: "/",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("img", {
    className: "img-responsive",
    src: logo,
    alt: name,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "header__lang",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    }
  }), !currenciesSwitcherDisabled && currencies && currencies.length > 1 ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components_CurrenciesSwitcher__["a" /* default */], {
    currencies: currencies,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  }) : null));
};

/* harmony default export */ __webpack_exports__["a"] = (Header);

/***/ }),

/***/ "./pages/PageBase/component/Layout/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = Layout;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Header__ = __webpack_require__("./pages/PageBase/component/Header/index.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Footer__ = __webpack_require__("./pages/PageBase/component/Footer/index.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\pages\\PageBase\\component\\Layout\\index.jsx";



function Layout(_ref) {
  var children = _ref.children,
      generalConfig = _ref.generalConfig;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 10
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__Header__["a" /* default */], {
    generalConfig: generalConfig,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11
    }
  }), children, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__Footer__["a" /* default */], {
    generalConfig: generalConfig,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }));
}

/***/ }),

/***/ "./pages/PageBase/index.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_jsx_style__ = __webpack_require__("styled-jsx/style");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_jsx_style___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_styled_jsx_style__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_redux__ = __webpack_require__("react-redux");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_redux___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_redux__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_helmet__ = __webpack_require__("react-helmet");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_helmet___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_helmet__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__paralleldrive_react_feature_toggles__ = __webpack_require__("@paralleldrive/react-feature-toggles");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__paralleldrive_react_feature_toggles___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__paralleldrive_react_feature_toggles__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__react_next_components_PageWithIntl__ = __webpack_require__("./react-next/components/PageWithIntl.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__react_next_utils_component_utils__ = __webpack_require__("./react-next/utils/component-utils.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__react_next_utils_component_utils___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__react_next_utils_component_utils__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__store_modules_common_config_action_types__ = __webpack_require__("./store/modules/common/config/action-types.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__store_modules_locale_selection_action_types__ = __webpack_require__("./store/modules/locale-selection/action-types.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__store_modules_locale_selection_selectors__ = __webpack_require__("./store/modules/locale-selection/selectors.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__store_modules_currency_selection_action_types__ = __webpack_require__("./store/modules/currency-selection/action-types.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__store_modules_currency_selection_selectors__ = __webpack_require__("./store/modules/currency-selection/selectors.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__react_next_utils_json_utils__ = __webpack_require__("./react-next/utils/json-utils.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__react_next_utils_json_utils___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_13__react_next_utils_json_utils__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__component_Layout__ = __webpack_require__("./pages/PageBase/component/Layout/index.jsx");

var _jsxFileName = "C:\\Projects\\frontend\\pages\\PageBase\\index.jsx";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// This will be the HOC to do most of the wrapping so pages.
// Intention:
// 1. Reduce Import Codes at Child Pages and Plugins Dependencies
// 2. Handle Common Functionalities across pages
// 3. Child Pages will only need to concern on compositing the components














function getPageBase(Page) {
  var isFeatured = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
  var isLayouted = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
  return (
    /*#__PURE__*/
    function (_React$Component) {
      _inherits(PageBase, _React$Component);

      function PageBase() {
        _classCallCheck(this, PageBase);

        return _possibleConstructorReturn(this, (PageBase.__proto__ || Object.getPrototypeOf(PageBase)).apply(this, arguments));
      }

      _createClass(PageBase, [{
        key: "render",
        value: function render() {
          var _props = this.props,
              config = _props.config,
              cultureCode = _props.cultureCode,
              urlLocale = _props.urlLocale,
              selectedCurrency = _props.selectedCurrency,
              props = _objectWithoutProperties(_props, ["config", "cultureCode", "urlLocale", "selectedCurrency"]);

          var pageProps = _objectSpread({
            config: config,
            cultureCode: cultureCode,
            urlLocale: urlLocale,
            selectedCurrency: selectedCurrency
          }, props);

          var pageSetup = PageBase.baseRender(config, pageProps);

          if (isFeatured) {
            pageSetup = PageBase.withFeatured(config, pageSetup);
          }

          return pageSetup;
        }
      }], [{
        key: "baseRender",
        value: function baseRender(config, pageProps) {
          return __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement("div", {
            __source: {
              fileName: _jsxFileName,
              lineNumber: 36
            },
            className: __WEBPACK_IMPORTED_MODULE_1_styled_jsx_style___default.a.dynamic([["1991745385", [config.general.primaryColor || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#17b36e', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.linkColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4']]]) + " " + (__WEBPACK_IMPORTED_MODULE_1_styled_jsx_style___default.a.dynamic([["1991745385", [config.general.primaryColor || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#17b36e', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.linkColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4']]]) || "")
          }, __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_helmet__["Helmet"], {
            __source: {
              fileName: _jsxFileName,
              lineNumber: 37
            }
          }, __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement("link", {
            rel: "icon",
            type: "image/png",
            href: config.general.favicon || 'https://d2va1pbm8mz6cn.cloudfront.net/fallbacks/favicon-default.png',
            __source: {
              fileName: _jsxFileName,
              lineNumber: 38
            },
            className: __WEBPACK_IMPORTED_MODULE_1_styled_jsx_style___default.a.dynamic([["1991745385", [config.general.primaryColor || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#17b36e', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.linkColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4']]]) + " " + (__WEBPACK_IMPORTED_MODULE_1_styled_jsx_style___default.a.dynamic([["1991745385", [config.general.primaryColor || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#17b36e', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.linkColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4']]]) || "")
          })), __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_styled_jsx_style___default.a, {
            styleId: "1991745385",
            css: ".theme-primary-text{color:".concat(config.general.primaryColor || '#4583c4', ";}.theme-secondary-text{color:").concat(config.general.secondaryColor || '#17b36e', ";}.btn-theme-primary{background:").concat(config.general.primaryColor || '#4583c4', ";color:").concat(config.general.primaryColorText || '#fff', ";border-color:").concat(config.general.primaryColor || '#4583c4', ";}.btn-theme-primary:hover{background:").concat(config.general.primaryColorHover || '#3f78b3', ";color:").concat(config.general.primaryColorText || '#fff', ";}.btn-theme-primary:focus{background:").concat(config.general.primaryColorHover || '#3f78b3', ";color:").concat(config.general.primaryColorText || '#fff', ";}.btn-theme-primary-outline{background:").concat(config.general.primaryColorText || '#fff', ";border-color:").concat(config.general.primaryColor || '#4583c4', ";color:").concat(config.general.primaryColor || '#4583c4', ";}.btn-theme-primary-outline:hover{background:").concat(config.general.primaryColor || '#fff', ";border-color:").concat(config.general.primaryColor || '#4583c4', ";color:").concat(config.general.primaryColorText || '#4583c4', ";}.btn-theme-primary-outline:focus{background:").concat(config.general.primaryColor || '#fff', ";border-color:").concat(config.general.primaryColor || '#4583c4', ";color:").concat(config.general.primaryColorText || '#4583c4', ";}.btn-theme-secondary{background:").concat(config.general.secondaryColor || '#17b36e', ";color:").concat(config.general.secondaryColorText || '#fff', ";border:").concat(config.general.secondaryColor || '#17b36e', ";}.btn-theme-secondary:hover{background:").concat(config.general.secondaryColorHover || '#15a364', ";color:").concat(config.general.secondaryColorText || '#fff', ";}.btn-theme-secondary:focus{background:").concat(config.general.secondaryColorHover || '#15a364', ";color:").concat(config.general.secondaryColorText || '#fff', ";}.btn-theme-secondary-outline{background:").concat(config.general.secondaryColorText || '#fff', ";border-color:").concat(config.general.secondaryColor || '#4583c4', ";color:").concat(config.general.secondaryColor || '#4583c4', ";}.btn-theme-secondary-outline:hover{background:").concat(config.general.secondaryColor || '#fff', ";border-color:").concat(config.general.secondaryColor || '#4583c4', ";color:").concat(config.general.secondaryColorText || '#4583c4', ";}.btn-theme-secondary-outline:focus{background:").concat(config.general.secondaryColor || '#fff', ";border-color:").concat(config.general.secondaryColor || '#4583c4', ";color:").concat(config.general.secondaryColorText || '#4583c4', ";}.link-theme-primary{color:").concat(config.general.linkColor || '#4583c4', ";}.sortBar__item--active{color:").concat(config.general.secondaryColor || '#4583c4', ";}.sortBar__item:hover{color:").concat(config.general.secondaryColor || '#4583c4', ";}.sortBar__item--active:before{background-color:").concat(config.general.secondaryColor || '#4583c4', ";}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2VzXFxQYWdlQmFzZVxcaW5kZXguanN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQXdDYSxBQUdzRCxBQUdBLEFBR0csQUFNQSxBQUlBLEFBSUEsQUFNQyxBQUtBLEFBS0EsQUFLQSxBQUlBLEFBSUEsQUFNQSxBQUtBLEFBS0wsQUFHRCxBQUdBLEFBR1csbUNBekU5QyxBQUdBLENBOERGLEFBR0EsQUFHQSxJQWpFcUMsQUFNQSxBQUlBLEFBSVEsQ0FNQSxBQUtBLEFBS1AsQUFLQSxBQUlBLEFBSU8sQUFNQSxBQUtBLE1BYzdDLDRCQW5FNEMsQUFNNUMsQUFJQSxFQW9CdUMsQUFLdkMsQUFJQSxNQXpCc0MsQ0FNQSxBQUtBLEFBa0JBLEFBTUEsQUFLQSw4QkF2QnRDLEdBN0JBLEVBY0EsQ0FLQSxBQUtBLEFBbUJBLEFBS0EsQUFLQSIsImZpbGUiOiJwYWdlc1xcUGFnZUJhc2VcXGluZGV4LmpzeCIsInNvdXJjZVJvb3QiOiJDOlxcUHJvamVjdHNcXGZyb250ZW5kIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQGZsb3dcclxuXHJcbi8vIFRoaXMgd2lsbCBiZSB0aGUgSE9DIHRvIGRvIG1vc3Qgb2YgdGhlIHdyYXBwaW5nIHNvIHBhZ2VzLlxyXG4vLyBJbnRlbnRpb246XHJcbi8vIDEuIFJlZHVjZSBJbXBvcnQgQ29kZXMgYXQgQ2hpbGQgUGFnZXMgYW5kIFBsdWdpbnMgRGVwZW5kZW5jaWVzXHJcbi8vIDIuIEhhbmRsZSBDb21tb24gRnVuY3Rpb25hbGl0aWVzIGFjcm9zcyBwYWdlc1xyXG4vLyAzLiBDaGlsZCBQYWdlcyB3aWxsIG9ubHkgbmVlZCB0byBjb25jZXJuIG9uIGNvbXBvc2l0aW5nIHRoZSBjb21wb25lbnRzXHJcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50VHlwZSB9IGZyb20gJ3JlYWN0JztcclxuXHJcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tICdyZWFjdC1yZWR1eCc7XHJcbmltcG9ydCB7IEhlbG1ldCB9IGZyb20gJ3JlYWN0LWhlbG1ldCc7XHJcbmltcG9ydCB7IEZlYXR1cmVUb2dnbGVzIH0gZnJvbSAnQHBhcmFsbGVsZHJpdmUvcmVhY3QtZmVhdHVyZS10b2dnbGVzJztcclxuaW1wb3J0IFBhZ2VXaXRoSW50bCBmcm9tICcuLi8uLi9yZWFjdC1uZXh0L2NvbXBvbmVudHMvUGFnZVdpdGhJbnRsJztcclxuaW1wb3J0IENvbXBvbmVudFV0aWxzIGZyb20gJy4uLy4uL3JlYWN0LW5leHQvdXRpbHMvY29tcG9uZW50LXV0aWxzJztcclxuXHJcbmltcG9ydCBjb25maWdBY3Rpb25UeXBlcyBmcm9tICcuLi8uLi9zdG9yZS9tb2R1bGVzL2NvbW1vbi9jb25maWcvYWN0aW9uLXR5cGVzJztcclxuXHJcbmltcG9ydCBpbnRsQWN0aW9uVHlwZXMgZnJvbSAnLi4vLi4vc3RvcmUvbW9kdWxlcy9sb2NhbGUtc2VsZWN0aW9uL2FjdGlvbi10eXBlcyc7XHJcbmltcG9ydCB7IGdldEN1bHR1cmVDb2RlLCBnZXRVcmxMb2NhbGUgfSBmcm9tICcuLi8uLi9zdG9yZS9tb2R1bGVzL2xvY2FsZS1zZWxlY3Rpb24vc2VsZWN0b3JzJztcclxuaW1wb3J0IGN1cnJlbmN5QWN0aW9uVHlwZXMgZnJvbSAnLi4vLi4vc3RvcmUvbW9kdWxlcy9jdXJyZW5jeS1zZWxlY3Rpb24vYWN0aW9uLXR5cGVzJztcclxuaW1wb3J0IHsgZ2V0U2VsZWN0ZWRDdXJyZW5jeSB9IGZyb20gJy4uLy4uL3N0b3JlL21vZHVsZXMvY3VycmVuY3ktc2VsZWN0aW9uL3NlbGVjdG9ycyc7XHJcbmltcG9ydCBKc29uVXRpbHMgZnJvbSAnLi4vLi4vcmVhY3QtbmV4dC91dGlscy9qc29uLXV0aWxzJztcclxuXHJcbmltcG9ydCB0eXBlIHsgT3B0aW9uc09iamVjdCwgUGFnZUJhc2VQcm9wcywgQ29uZmlnIH0gZnJvbSAnLi90eXBlcyc7XHJcbmltcG9ydCBMYXlvdXQgZnJvbSAnLi9jb21wb25lbnQvTGF5b3V0JztcclxuXHJcbmZ1bmN0aW9uIGdldFBhZ2VCYXNlKFxyXG4gIFBhZ2U6IENvbXBvbmVudFR5cGU8Kj4sXHJcbiAgaXNGZWF0dXJlZDogYm9vbGVhbiA9IGZhbHNlLFxyXG4gIGlzTGF5b3V0ZWQ6IGJvb2xlYW4gPSB0cnVlLFxyXG4pIHtcclxuICByZXR1cm4gY2xhc3MgUGFnZUJhc2UgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQ8UGFnZUJhc2VQcm9wcz4ge1xyXG4gICAgc3RhdGljIGJhc2VSZW5kZXIoY29uZmlnLCBwYWdlUHJvcHMpIHtcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPEhlbG1ldD5cclxuICAgICAgICAgICAgPGxpbmsgcmVsPVwiaWNvblwiIHR5cGU9XCJpbWFnZS9wbmdcIiBocmVmPXtjb25maWcuZ2VuZXJhbC5mYXZpY29uIHx8ICdodHRwczovL2QydmExcGJtOG16NmNuLmNsb3VkZnJvbnQubmV0L2ZhbGxiYWNrcy9mYXZpY29uLWRlZmF1bHQucG5nJ30gLz5cclxuICAgICAgICAgIDwvSGVsbWV0PlxyXG4gICAgICAgICAgPHN0eWxlIGpzeCBnbG9iYWw+XHJcbiAgICAgICAgICAgIHtgXHJcbiAgICAgICAgICAgICAgICAudGhlbWUtcHJpbWFyeS10ZXh0IHtcclxuICAgICAgICAgICAgICAgICAgY29sb3I6ICR7Y29uZmlnLmdlbmVyYWwucHJpbWFyeUNvbG9yIHx8ICcjNDU4M2M0J307XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAudGhlbWUtc2Vjb25kYXJ5LXRleHQge1xyXG4gICAgICAgICAgICAgICAgICBjb2xvcjogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvciB8fCAnIzE3YjM2ZSd9O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC5idG4tdGhlbWUtcHJpbWFyeSB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAke2NvbmZpZy5nZW5lcmFsLnByaW1hcnlDb2xvciB8fCAnIzQ1ODNjNCd9O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICR7Y29uZmlnLmdlbmVyYWwucHJpbWFyeUNvbG9yVGV4dCB8fCAnI2ZmZid9O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLnByaW1hcnlDb2xvciB8fCAnIzQ1ODNjNCd9O1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC5idG4tdGhlbWUtcHJpbWFyeTpob3ZlciB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAke2NvbmZpZy5nZW5lcmFsLnByaW1hcnlDb2xvckhvdmVyIHx8ICcjM2Y3OGIzJ307XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJHtjb25maWcuZ2VuZXJhbC5wcmltYXJ5Q29sb3JUZXh0IHx8ICcjZmZmJ307XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC5idG4tdGhlbWUtcHJpbWFyeTpmb2N1cyB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAke2NvbmZpZy5nZW5lcmFsLnByaW1hcnlDb2xvckhvdmVyIHx8ICcjM2Y3OGIzJ307XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJHtjb25maWcuZ2VuZXJhbC5wcmltYXJ5Q29sb3JUZXh0IHx8ICcjZmZmJ307XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC5idG4tdGhlbWUtcHJpbWFyeS1vdXRsaW5lIHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICR7Y29uZmlnLmdlbmVyYWwucHJpbWFyeUNvbG9yVGV4dCB8fCAnI2ZmZid9O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLnByaW1hcnlDb2xvciB8fCAnIzQ1ODNjNCd9O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICR7Y29uZmlnLmdlbmVyYWwucHJpbWFyeUNvbG9yIHx8ICcjNDU4M2M0J307XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLmJ0bi10aGVtZS1wcmltYXJ5LW91dGxpbmU6aG92ZXIge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJHtjb25maWcuZ2VuZXJhbC5wcmltYXJ5Q29sb3IgfHwgJyNmZmYnfTtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1jb2xvcjogJHtjb25maWcuZ2VuZXJhbC5wcmltYXJ5Q29sb3IgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLnByaW1hcnlDb2xvclRleHQgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLmJ0bi10aGVtZS1wcmltYXJ5LW91dGxpbmU6Zm9jdXMge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJHtjb25maWcuZ2VuZXJhbC5wcmltYXJ5Q29sb3IgfHwgJyNmZmYnfTtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1jb2xvcjogJHtjb25maWcuZ2VuZXJhbC5wcmltYXJ5Q29sb3IgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLnByaW1hcnlDb2xvclRleHQgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLmJ0bi10aGVtZS1zZWNvbmRhcnkge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvciB8fCAnIzE3YjM2ZSd9O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICR7Y29uZmlnLmdlbmVyYWwuc2Vjb25kYXJ5Q29sb3JUZXh0IHx8ICcjZmZmJ307XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6ICR7Y29uZmlnLmdlbmVyYWwuc2Vjb25kYXJ5Q29sb3IgfHwgJyMxN2IzNmUnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLmJ0bi10aGVtZS1zZWNvbmRhcnk6aG92ZXIge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvckhvdmVyIHx8ICcjMTVhMzY0J307XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvclRleHQgfHwgJyNmZmYnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLmJ0bi10aGVtZS1zZWNvbmRhcnk6Zm9jdXMge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvckhvdmVyIHx8ICcjMTVhMzY0J307XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvclRleHQgfHwgJyNmZmYnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLmJ0bi10aGVtZS1zZWNvbmRhcnktb3V0bGluZSB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAke2NvbmZpZy5nZW5lcmFsLnNlY29uZGFyeUNvbG9yVGV4dCB8fCAnI2ZmZid9O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLnNlY29uZGFyeUNvbG9yIHx8ICcjNDU4M2M0J307XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvciB8fCAnIzQ1ODNjNCd9O1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC5idG4tdGhlbWUtc2Vjb25kYXJ5LW91dGxpbmU6aG92ZXIge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvciB8fCAnI2ZmZid9O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLnNlY29uZGFyeUNvbG9yIHx8ICcjNDU4M2M0J307XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvclRleHQgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLmJ0bi10aGVtZS1zZWNvbmRhcnktb3V0bGluZTpmb2N1cyB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAke2NvbmZpZy5nZW5lcmFsLnNlY29uZGFyeUNvbG9yIHx8ICcjZmZmJ307XHJcbiAgICAgICAgICAgICAgICBib3JkZXItY29sb3I6ICR7Y29uZmlnLmdlbmVyYWwuc2Vjb25kYXJ5Q29sb3IgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLnNlY29uZGFyeUNvbG9yVGV4dCB8fCAnIzQ1ODNjNCd9O1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAubGluay10aGVtZS1wcmltYXJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAke2NvbmZpZy5nZW5lcmFsLmxpbmtDb2xvciB8fCAnIzQ1ODNjNCd9O1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAuc29ydEJhcl9faXRlbS0tYWN0aXZlIHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiR7Y29uZmlnLmdlbmVyYWwuc2Vjb25kYXJ5Q29sb3IgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLnNvcnRCYXJfX2l0ZW06aG92ZXIge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6JHtjb25maWcuZ2VuZXJhbC5zZWNvbmRhcnlDb2xvciB8fCAnIzQ1ODNjNCd9O1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAuc29ydEJhcl9faXRlbS0tYWN0aXZlOmJlZm9yZSB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiR7Y29uZmlnLmdlbmVyYWwuc2Vjb25kYXJ5Q29sb3IgfHwgJyM0NTgzYzQnfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICBgfVxyXG4gICAgICAgICAgPC9zdHlsZT5cclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgKGlzTGF5b3V0ZWQpXHJcbiAgICAgICAgICAgICAgPyBQYWdlQmFzZS53aXRoTGF5b3V0KGNvbmZpZywgUGFnZUJhc2UuZ2V0UGFnZShwYWdlUHJvcHMpKVxyXG4gICAgICAgICAgICAgIDogUGFnZUJhc2UuZ2V0UGFnZShwYWdlUHJvcHMpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgc3RhdGljIHdpdGhMYXlvdXQoY29uZmlnOiBDb25maWcsIHBhZ2UpIHtcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8TGF5b3V0IGdlbmVyYWxDb25maWc9e2NvbmZpZy5nZW5lcmFsfT5cclxuICAgICAgICAgIHtwYWdlfVxyXG4gICAgICAgIDwvTGF5b3V0PlxyXG4gICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIEltcG9ydGFudCBOb3RlOiBUaGlzIHNob3VsZCBiZSB0aGUgd2F5IHRvIHdyYXAgYW55IHByb3ZpZGVyXHJcbiAgICAvLyBPbmx5IGlmIHRoZSBwcm92aWRlciBpcyBub3QgaHVnZSBsaWtlIFBhZ2VXaXRoSW50bFxyXG4gICAgc3RhdGljIHdpdGhGZWF0dXJlZChjb25maWc6IENvbmZpZywgcGFnZSkge1xyXG4gICAgICBjb25zdCBmZWF0dXJlcyA9IFtdO1xyXG4gICAgICBjb25zdCBmZWF0dXJlS2V5cyA9IE9iamVjdC5rZXlzKGNvbmZpZy5mZWF0dXJlcyk7XHJcblxyXG4gICAgICBmZWF0dXJlS2V5cy5mb3JFYWNoKChlbGVtZW50KSA9PiB7XHJcbiAgICAgICAgaWYgKGNvbmZpZy5mZWF0dXJlc1tlbGVtZW50XSkge1xyXG4gICAgICAgICAgZmVhdHVyZXMucHVzaChlbGVtZW50KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8RmVhdHVyZVRvZ2dsZXMgZmVhdHVyZXM9e2ZlYXR1cmVzfT5cclxuICAgICAgICAgIHsgcGFnZSB9XHJcbiAgICAgICAgPC9GZWF0dXJlVG9nZ2xlcz5cclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBzdGF0aWMgZ2V0UGFnZShwYWdlUHJvcHMpIHtcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8UGFnZSB7Li4ucGFnZVByb3BzfSAvPlxyXG4gICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIHN0YXRpYyBhc3luYyBnZXRJbml0aWFsUHJvcHMoY29udGV4dCkge1xyXG4gICAgICBjb25zdCB7IGN0eDogeyByZXEsIHN0b3JlLCBxdWVyeSB9IH0gPSBjb250ZXh0O1xyXG5cclxuICAgICAgY29uc3QgeyBjb25maWcsIGxvY2FsZSB9ID0gcmVxIHx8IENvbXBvbmVudFV0aWxzLmdldFdpbmRvd0luaXRpYWxQYWdlUHJvcHMoKS5wYWdlUHJvcHM7XHJcblxyXG4gICAgICAvKlxyXG4gICAgICAqIENoYW5nZSBjdWx0dXJlQ29kZSB0byBnZXR0aW5nIGZyb20gc3RhdGUgYW5kIHJlLXJlbmRlciBwYWdlIGZvciBjdWx0dXJlIGNvZGUgY2hhbmdlLFxyXG4gICAgICAqIERvbid0IG5lZWQgdG8gbWFrZSBhIHVybCBjYWxsIHRvIGhpdCBub2RlIHNlcnZlclxyXG4gICAgICAqL1xyXG4gICAgICBzdG9yZS5kaXNwYXRjaCh7IHR5cGU6IGNvbmZpZ0FjdGlvblR5cGVzLlNFVF9DT05GSUcsIHBheWxvYWQ6IHsgY29uZmlnIH0gfSk7XHJcbiAgICAgIHN0b3JlLmRpc3BhdGNoKHsgdHlwZTogaW50bEFjdGlvblR5cGVzLlNFVF9DVUxUVVJFX0NPREUsIHBheWxvYWQ6IHsgbG9jYWxlLCBjb25maWcgfSB9KTtcclxuICAgICAgaWYgKHR5cGVvZiBxdWVyeS5jdXJyZW5jeSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICBzdG9yZS5kaXNwYXRjaCh7XHJcbiAgICAgICAgICB0eXBlOiBjdXJyZW5jeUFjdGlvblR5cGVzLlNFTEVDVF9DVVJSRU5DWV9GUk9NX1VSTF9SRVFVRVNULFxyXG4gICAgICAgICAgcGF5bG9hZDogeyBjdXJyZW5jeTogcXVlcnkuY3VycmVuY3kgfSxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzdG9yZS5kaXNwYXRjaCh7XHJcbiAgICAgICAgICB0eXBlOiBjdXJyZW5jeUFjdGlvblR5cGVzLkdFVF9TRUxFQ1RFRF9DVVJSRU5DWV9SRVFVRVNULFxyXG4gICAgICAgICAgLyogQWRkIHRoaXMgY29uZGl0aW9uIHRvIGF2b2lkIHNpbGx5IHJlYWN0LW5leHQgcmVsb2FkaW5nIGVycm9yLFxyXG4gICAgICAgICAgYnV0IGFwcGFyZW50bHkgcmVxIHNob3VsZCBub3QgYmUgdW5kZWZpbmVkICovXHJcbiAgICAgICAgICBwYXlsb2FkOiB7IGNvb2tpZTogcmVxID8gcmVxLmhlYWRlcnMuY29va2llIDogbnVsbCB9LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgIGxldCBwcm9wcztcclxuICAgICAgaWYgKHR5cGVvZiBQYWdlLmdldEluaXRpYWxQcm9wcyA9PT0gJ2Z1bmN0aW9uJykge1xyXG4gICAgICAgIHByb3BzID0gYXdhaXQgUGFnZS5nZXRJbml0aWFsUHJvcHMoY29udGV4dCk7IC8vIFRoaXMgd2lsbCBjYWxsIHBhZ2VzIGdldEluaXRpYWxQcm9wc1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGNvbmZpZyxcclxuICAgICAgICAuLi5wcm9wcyxcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICByZW5kZXIoKSB7XHJcbiAgICAgIGNvbnN0IHtcclxuICAgICAgICBjb25maWcsXHJcbiAgICAgICAgY3VsdHVyZUNvZGUsXHJcbiAgICAgICAgdXJsTG9jYWxlLFxyXG4gICAgICAgIHNlbGVjdGVkQ3VycmVuY3ksXHJcbiAgICAgICAgLi4ucHJvcHNcclxuICAgICAgfSA9IHRoaXMucHJvcHM7XHJcblxyXG4gICAgICBjb25zdCBwYWdlUHJvcHMgPSB7XHJcbiAgICAgICAgY29uZmlnLFxyXG4gICAgICAgIGN1bHR1cmVDb2RlLFxyXG4gICAgICAgIHVybExvY2FsZSxcclxuICAgICAgICBzZWxlY3RlZEN1cnJlbmN5LFxyXG4gICAgICAgIC4uLnByb3BzLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgbGV0IHBhZ2VTZXR1cCA9IFBhZ2VCYXNlLmJhc2VSZW5kZXIoY29uZmlnLCBwYWdlUHJvcHMpO1xyXG5cclxuICAgICAgaWYgKGlzRmVhdHVyZWQpIHtcclxuICAgICAgICBwYWdlU2V0dXAgPSBQYWdlQmFzZS53aXRoRmVhdHVyZWQoY29uZmlnLCBwYWdlU2V0dXApO1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIHBhZ2VTZXR1cFxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH07XHJcbn1cclxuXHJcbi8vIFdoZW4gUHJvdmlkZXIgR3Jvd3MsIFByZXBhcmUgYSBzZXQgb2YgUHJvdmlkZXJzIFRydWUgRmFsc2VcclxuY29uc3QgcGJNYXBTdGF0ZVRvUHJvcHM6IEZ1bmN0aW9uID0gc3RhdGUgPT4gKHtcclxuICBzZWxlY3RlZEN1cnJlbmN5OiBnZXRTZWxlY3RlZEN1cnJlbmN5KHN0YXRlKSxcclxuICBjdWx0dXJlQ29kZTogZ2V0Q3VsdHVyZUNvZGUoc3RhdGUpLFxyXG4gIHVybExvY2FsZTogZ2V0VXJsTG9jYWxlKHN0YXRlKSxcclxufSk7XHJcblxyXG5jb25zdCBwYWdlT3B0aW9uczogT3B0aW9uc09iamVjdCA9IHtcclxuICBtYXBTdGF0ZVRvUHJvcHM6IHVuZGVmaW5lZCxcclxuICBpc0ZlYXR1cmVkOiBmYWxzZSxcclxuICBpc0xheW91dGVkOiB0cnVlLFxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKFxyXG4gIFBhZ2U6IENvbXBvbmVudFR5cGU8Kj4sXHJcbiAgb3B0aW9uczogT3B0aW9uc09iamVjdCA9IHBhZ2VPcHRpb25zLFxyXG4pIHtcclxuICBpZiAob3B0aW9ucyAhPT0gcGFnZU9wdGlvbnMpIHtcclxuICAgIEpzb25VdGlscy5vdmVycmlkZVZhbHVlcyhwYWdlT3B0aW9ucywgb3B0aW9ucyk7XHJcbiAgfVxyXG5cclxuICBjb25zdCBjb21iaW5lZE1hcFN0YXRlVG9Qcm9wcyA9IHN0YXRlID0+ICh7XHJcbiAgICAuLi5zdGF0ZSxcclxuICAgIC4uLnBiTWFwU3RhdGVUb1Byb3BzKHN0YXRlKSxcclxuICAgIC4uLigocGFnZU9wdGlvbnMubWFwU3RhdGVUb1Byb3BzKSA/IHBhZ2VPcHRpb25zLm1hcFN0YXRlVG9Qcm9wcyhzdGF0ZSkgOiB7fSksXHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiBjb25uZWN0KGNvbWJpbmVkTWFwU3RhdGVUb1Byb3BzKShcclxuICAgIFBhZ2VXaXRoSW50bChnZXRQYWdlQmFzZShQYWdlLCBwYWdlT3B0aW9ucy5pc0ZlYXR1cmVkLCBwYWdlT3B0aW9ucy5pc0xheW91dGVkKSksXHJcbiAgKTtcclxufVxyXG5cclxuLyovXHJcbmV4cG9ydCBkZWZhdWx0IChQYWdlLCBpc0ZlYXR1cmVkOiBib29sZWFuID0gZmFsc2UpID0+IGNvbm5lY3Qoc3RhdGUgPT4gKHtcclxuICAuLi5zdGF0ZSxcclxuICBzZWxlY3RlZEN1cnJlbmN5OiBnZXRTZWxlY3RlZEN1cnJlbmN5KHN0YXRlKSxcclxuICBjdWx0dXJlQ29kZTogZ2V0Q3VsdHVyZUNvZGUoc3RhdGUpLFxyXG4gIHVybExvY2FsZTogZ2V0VXJsTG9jYWxlKHN0YXRlKSxcclxufSkpKFBhZ2VXaXRoSW50bChnZXRQYWdlQmFzZShQYWdlLCBpc0ZlYXR1cmVkKSkpO1xyXG4vKi9cclxuIl19 */\n/*@ sourceURL=pages\\PageBase\\index.jsx */"),
            dynamic: [config.general.primaryColor || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorHover || '#3f78b3', config.general.primaryColorText || '#fff', config.general.primaryColorText || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.primaryColor || '#fff', config.general.primaryColor || '#4583c4', config.general.primaryColorText || '#4583c4', config.general.secondaryColor || '#17b36e', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#17b36e', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorHover || '#15a364', config.general.secondaryColorText || '#fff', config.general.secondaryColorText || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.secondaryColor || '#fff', config.general.secondaryColor || '#4583c4', config.general.secondaryColorText || '#4583c4', config.general.linkColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4', config.general.secondaryColor || '#4583c4']
          }), isLayouted ? PageBase.withLayout(config, PageBase.getPage(pageProps)) : PageBase.getPage(pageProps));
        }
      }, {
        key: "withLayout",
        value: function withLayout(config, page) {
          return __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_14__component_Layout__["a" /* default */], {
            generalConfig: config.general,
            __source: {
              fileName: _jsxFileName,
              lineNumber: 132
            }
          }, page);
        } // Important Note: This should be the way to wrap any provider
        // Only if the provider is not huge like PageWithIntl

      }, {
        key: "withFeatured",
        value: function withFeatured(config, page) {
          var features = [];
          var featureKeys = Object.keys(config.features);
          featureKeys.forEach(function (element) {
            if (config.features[element]) {
              features.push(element);
            }
          });
          return __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__paralleldrive_react_feature_toggles__["FeatureToggles"], {
            features: features,
            __source: {
              fileName: _jsxFileName,
              lineNumber: 151
            }
          }, page);
        }
      }, {
        key: "getPage",
        value: function getPage(pageProps) {
          return __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(Page, _extends({}, pageProps, {
            __source: {
              fileName: _jsxFileName,
              lineNumber: 159
            }
          }));
        }
      }, {
        key: "getInitialProps",
        value: function () {
          var _getInitialProps = _asyncToGenerator(
          /*#__PURE__*/
          __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee(context) {
            var _context$ctx, req, store, query, _ref, config, locale, props;

            return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context$ctx = context.ctx, req = _context$ctx.req, store = _context$ctx.store, query = _context$ctx.query;
                    _ref = req || __WEBPACK_IMPORTED_MODULE_7__react_next_utils_component_utils___default.a.getWindowInitialPageProps().pageProps, config = _ref.config, locale = _ref.locale;
                    /*
                    * Change cultureCode to getting from state and re-render page for culture code change,
                    * Don't need to make a url call to hit node server
                    */

                    store.dispatch({
                      type: __WEBPACK_IMPORTED_MODULE_8__store_modules_common_config_action_types__["a" /* default */].SET_CONFIG,
                      payload: {
                        config: config
                      }
                    });
                    store.dispatch({
                      type: __WEBPACK_IMPORTED_MODULE_9__store_modules_locale_selection_action_types__["a" /* default */].SET_CULTURE_CODE,
                      payload: {
                        locale: locale,
                        config: config
                      }
                    });

                    if (typeof query.currency !== 'undefined') {
                      store.dispatch({
                        type: __WEBPACK_IMPORTED_MODULE_11__store_modules_currency_selection_action_types__["a" /* default */].SELECT_CURRENCY_FROM_URL_REQUEST,
                        payload: {
                          currency: query.currency
                        }
                      });
                    } else {
                      store.dispatch({
                        type: __WEBPACK_IMPORTED_MODULE_11__store_modules_currency_selection_action_types__["a" /* default */].GET_SELECTED_CURRENCY_REQUEST,

                        /* Add this condition to avoid silly react-next reloading error,
                        but apparently req should not be undefined */
                        payload: {
                          cookie: req ? req.headers.cookie : null
                        }
                      });
                    }

                    if (!(typeof Page.getInitialProps === 'function')) {
                      _context.next = 9;
                      break;
                    }

                    _context.next = 8;
                    return Page.getInitialProps(context);

                  case 8:
                    props = _context.sent;

                  case 9:
                    return _context.abrupt("return", _objectSpread({
                      config: config
                    }, props));

                  case 10:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));

          return function getInitialProps(_x) {
            return _getInitialProps.apply(this, arguments);
          };
        }()
      }]);

      return PageBase;
    }(__WEBPACK_IMPORTED_MODULE_2_react___default.a.Component)
  );
} // When Provider Grows, Prepare a set of Providers True False


var pbMapStateToProps = function pbMapStateToProps(state) {
  return {
    selectedCurrency: Object(__WEBPACK_IMPORTED_MODULE_12__store_modules_currency_selection_selectors__["a" /* getSelectedCurrency */])(state),
    cultureCode: Object(__WEBPACK_IMPORTED_MODULE_10__store_modules_locale_selection_selectors__["a" /* getCultureCode */])(state),
    urlLocale: Object(__WEBPACK_IMPORTED_MODULE_10__store_modules_locale_selection_selectors__["b" /* getUrlLocale */])(state)
  };
};

var pageOptions = {
  mapStateToProps: undefined,
  isFeatured: false,
  isLayouted: true
};
/* harmony default export */ __webpack_exports__["a"] = (function (Page) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : pageOptions;

  if (options !== pageOptions) {
    __WEBPACK_IMPORTED_MODULE_13__react_next_utils_json_utils___default.a.overrideValues(pageOptions, options);
  }

  var combinedMapStateToProps = function combinedMapStateToProps(state) {
    return _objectSpread({}, state, pbMapStateToProps(state), pageOptions.mapStateToProps ? pageOptions.mapStateToProps(state) : {});
  };

  return Object(__WEBPACK_IMPORTED_MODULE_3_react_redux__["connect"])(combinedMapStateToProps)(Object(__WEBPACK_IMPORTED_MODULE_6__react_next_components_PageWithIntl__["a" /* default */])(getPageBase(Page, pageOptions.isFeatured, pageOptions.isLayouted)));
});
/*/
export default (Page, isFeatured: boolean = false) => connect(state => ({
  ...state,
  selectedCurrency: getSelectedCurrency(state),
  cultureCode: getCultureCode(state),
  urlLocale: getUrlLocale(state),
}))(PageWithIntl(getPageBase(Page, isFeatured)));
/*/

/***/ }),

/***/ "./react-next/components/PageWithIntl.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_intl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utils_component_utils__ = __webpack_require__("./react-next/utils/component-utils.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utils_component_utils___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__utils_component_utils__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__utils_intl_utils__ = __webpack_require__("./react-next/utils/intl-utils.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__utils_intl_utils___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4__utils_intl_utils__);

var _jsxFileName = "C:\\Projects\\frontend\\react-next\\components\\PageWithIntl.jsx";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }




 // Register React Intl's locale data for the user's locale in the browser. This
// locale data was added to the page by `pages/_document.js`. This only happens
// once, on initial page load in the browser.

if (typeof window !== 'undefined' && window.ReactIntlLocaleData) {
  Object.keys(window.ReactIntlLocaleData).forEach(function (lang) {
    Object(__WEBPACK_IMPORTED_MODULE_2_react_intl__["addLocaleData"])(window.ReactIntlLocaleData[lang]);
  });
}

/* harmony default export */ __webpack_exports__["a"] = (function (Page) {
  var IntlPage = Object(__WEBPACK_IMPORTED_MODULE_2_react_intl__["injectIntl"])(Page);
  return (
    /*#__PURE__*/
    function (_React$Component) {
      _inherits(PageWithIntl, _React$Component);

      function PageWithIntl() {
        _classCallCheck(this, PageWithIntl);

        return _possibleConstructorReturn(this, (PageWithIntl.__proto__ || Object.getPrototypeOf(PageWithIntl)).apply(this, arguments));
      }

      _createClass(PageWithIntl, [{
        key: "render",
        value: function render() {
          var _props = this.props,
              locale = _props.locale,
              localeDataScript = _props.localeDataScript,
              messages = _props.messages,
              now = _props.now,
              props = _objectWithoutProperties(_props, ["locale", "localeDataScript", "messages", "now"]);

          return (// React Locale Data Script Slightly Different
            __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_intl__["IntlProvider"], {
              locale: __WEBPACK_IMPORTED_MODULE_4__utils_intl_utils___default.a.cultureCodeToReactLocale(locale),
              messages: messages,
              initialNow: now,
              defaultLocale: "en-US",
              __source: {
                fileName: _jsxFileName,
                lineNumber: 56
              }
            }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(IntlPage, _extends({}, props, {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 57
              }
            })))
          );
        }
      }], [{
        key: "getInitialProps",
        value: function () {
          var _getInitialProps = _asyncToGenerator(
          /*#__PURE__*/
          __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee(context) {
            var props, req, _ref, locale, messages, localeDataScript, now;

            return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    if (!(typeof Page.getInitialProps === 'function')) {
                      _context.next = 4;
                      break;
                    }

                    _context.next = 3;
                    return Page.getInitialProps(context);

                  case 3:
                    props = _context.sent;

                  case 4:
                    // Get the `locale` and `messages` from the request object on the server.
                    // In the browser, use the same values that the server serialized.
                    req = context.ctx.req;
                    _ref = req || __WEBPACK_IMPORTED_MODULE_3__utils_component_utils___default.a.getWindowInitialPageProps().pageProps, locale = _ref.locale, messages = _ref.messages, localeDataScript = _ref.localeDataScript; // Always update the current time on page load/transition because the
                    // <IntlProvider> will be a new instance even with pushState routing.

                    now = Date.now();
                    return _context.abrupt("return", _objectSpread({
                      locale: locale,
                      localeDataScript: localeDataScript,
                      messages: messages,
                      now: now
                    }, props));

                  case 8:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));

          return function getInitialProps(_x) {
            return _getInitialProps.apply(this, arguments);
          };
        }()
      }]);

      return PageWithIntl;
    }(__WEBPACK_IMPORTED_MODULE_1_react___default.a.Component)
  );
});

/***/ }),

/***/ "./react-next/error/index.js":
/***/ (function(module, exports, __webpack_require__) {

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

// Future: Interface different Error Handlers, now this purely handle Sentry Errors
var Raven = __webpack_require__("raven-js");

var ErrorHandler =
/*#__PURE__*/
function () {
  function ErrorHandler(dsn, environment, release, errorMap) {
    var options = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {};

    _classCallCheck(this, ErrorHandler);

    this.dsn = dsn;
    this.environment = environment;
    this.release = release;
    this.errorMap = errorMap;
    this.options = options;
    this.isOn = true;
    this.isInstalled = false; // Set Sentry Variables

    this.options.release = release;
    this.options.environment = environment;
  }

  _createClass(ErrorHandler, [{
    key: "install",
    value: function install() {
      // Just In Case
      if (this.dsn && this.isOn) {
        this.installed = true;
        Raven.config(this.dsn, this.options).install();
      }
    }
  }, {
    key: "logIssue",
    value: function logIssue(message) {
      var tag = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      if (this.isOn && this.dsn) {
        if (!this.isInstalled) {
          this.install();
        }

        var tagParams = _objectSpread({
          environment: this.environment
        }, tag);

        Raven.captureMessage(message, {
          tag: tagParams
        });
      }
    }
  }, {
    key: "captureException",
    value: function captureException(error, extra) {
      if (this.isOn && this.dsn) {
        if (!this.isInstalled) {
          this.install();
        }

        Raven.captureException(error, extra);
      }
    }
  }, {
    key: "getRaven",
    value: function getRaven() {
      return Raven;
    }
  }]);

  return ErrorHandler;
}();

module.exports = ErrorHandler;

/***/ }),

/***/ "./react-next/intl/currency-names.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = GetCurrencyName;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__client_error__ = __webpack_require__("./client-error.js");

var Sentry = __WEBPACK_IMPORTED_MODULE_0__client_error__["a" /* default */].getInstance();
var currenciesName = {
  'en-US': {
    MYR: 'Malaysian Ringgit',
    USD: 'US Dollar',
    SGD: 'Singapore Dollar',
    JPY: 'Japanese Yen'
  },
  'zh-HK': {
    MYR: '馬幣',
    USD: '美金'
  }
};
function GetCurrencyName(locale, currency) {
  var currencyLocales = Object.keys(currenciesName);
  var currentLocale = 'en-US';

  if (!locale || currencyLocales.indexOf(locale) === -1) {
    Sentry.captureException("Locale ".concat(locale, " is not found, fallback to en-US"));
  } else {
    currentLocale = locale;
  }

  if (currenciesName[currentLocale][currency]) {
    return currenciesName[currentLocale][currency];
  }

  if (currenciesName['en-US'][currency]) {
    Sentry.captureException("Translation for locale ".concat(currentLocale, " and currency ").concat(currency, " is not found, fallback to its translation in en-US"));
    return currenciesName['en-US'][currency];
  }

  Sentry.captureException("Translation for locale en-US and currency ".concat(currency, " is not found, fallback to blank"));
  return '';
}

/***/ }),

/***/ "./react-next/intl/currency-symbols.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = getCurrencySymbol;
/* harmony export (immutable) */ __webpack_exports__["b"] = isCurrencySymbolAfter;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__client_error__ = __webpack_require__("./client-error.js");

var currencySymbols = {
  MYR: {
    symbol: 'RM',
    isSymbolAfter: false
  },
  USD: {
    symbol: '$',
    isSymbolAfter: false
  },
  SGD: {
    symbol: 'SGD',
    isSymbolAfter: false
  },
  JPY: {
    symbol: '¥',
    isSymbolAfter: true
  }
};
function getCurrencySymbol(currency) {
  if (currencySymbols[currency]) {
    return currencySymbols[currency].symbol;
  }

  __WEBPACK_IMPORTED_MODULE_0__client_error__["a" /* default */].captureException("Symbol for currency ".concat(currency, " is not found, fallback to blank."));
  return ''; // Fall back to blank to avoid user's misunderstanding
}
function isCurrencySymbolAfter(currency) {
  if (currencySymbols[currency]) {
    return currencySymbols[currency].isSymbolAfter;
  }

  return false; // default is false
}

/***/ }),

/***/ "./react-next/intl/date-locale.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export getDateFormat */
/* harmony export (immutable) */ __webpack_exports__["b"] = formatDateString;
/* unused harmony export formatDay */
/* unused harmony export formatMonthTitle */
/* unused harmony export formatWeekdayShort */
/* unused harmony export formatWeekdayLong */
/* unused harmony export getFirstDayOfWeek */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return dayPickerLocaleUtils; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_date_fns__ = __webpack_require__("date-fns");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_date_fns___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_date_fns__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_date_fns_locale_en__ = __webpack_require__("date-fns/locale/en");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_date_fns_locale_en___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_date_fns_locale_en__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_date_fns_locale_zh_tw__ = __webpack_require__("date-fns/locale/zh_tw");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_date_fns_locale_zh_tw___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_date_fns_locale_zh_tw__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_date_fns_locale_zh_cn__ = __webpack_require__("date-fns/locale/zh_cn");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_date_fns_locale_zh_cn___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_date_fns_locale_zh_cn__);




var enFormat = {
  fnsLocale: __WEBPACK_IMPORTED_MODULE_1_date_fns_locale_en___default.a,
  short: 'DD MMM',
  medium: 'DD MMM YYYY',
  long: 'dddd, DD MMM YYYY'
};
var zhHantFormat = {
  fnsLocale: __WEBPACK_IMPORTED_MODULE_2_date_fns_locale_zh_tw___default.a,
  short: 'MMM DD',
  medium: 'YYYY MMM DD',
  long: 'dddd, YYYY MMM DD'
};
var zhHansFormat = {
  fnsLocale: __WEBPACK_IMPORTED_MODULE_3_date_fns_locale_zh_cn___default.a,
  short: 'MMM DD',
  medium: 'YYYY MMM DD',
  long: 'dddd, YYYY MMM DD'
};
var format = {
  'en-US': enFormat,
  'zh-HK': zhHantFormat,
  'zh-TW': zhHantFormat,
  'zh-MO': zhHantFormat,
  'zh-CN': zhHansFormat,
  'zh-SG': zhHansFormat
}; // locale later use Enum

function getDateFormat(locale) {
  if (format[locale]) {
    return format[locale];
  }

  return format['en-US'];
}
function formatDateString(date, lengthFormat, locale) {
  var dateFormat = getDateFormat(locale);
  var dateString = '';

  if (lengthFormat === 'LONG') {
    dateString = Object(__WEBPACK_IMPORTED_MODULE_0_date_fns__["format"])(date, dateFormat.long, {
      locale: dateFormat.fnsLocale
    });
  } else if (lengthFormat === 'MEDIUM') {
    dateString = Object(__WEBPACK_IMPORTED_MODULE_0_date_fns__["format"])(date, dateFormat.medium, {
      locale: dateFormat.fnsLocale
    });
  } else if (lengthFormat === 'SHORT') {
    dateString = Object(__WEBPACK_IMPORTED_MODULE_0_date_fns__["format"])(date, dateFormat.short, {
      locale: dateFormat.fnsLocale
    });
  }

  return dateString;
}
var dayDates = [new Date(2018, 3, 1), // This is Sunday
new Date(2018, 3, 2), new Date(2018, 3, 3), new Date(2018, 3, 4), new Date(2018, 3, 5), new Date(2018, 3, 6), new Date(2018, 3, 7)];
function formatDay(d) {
  var locale = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'en-US';
  // Using Medium Format
  var dateString = formatDateString(d, 'MEDIUM', locale);
  return dateString;
}
function formatMonthTitle(d) {
  var locale = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'en-US';
  var dateFormat = getDateFormat(locale);
  return Object(__WEBPACK_IMPORTED_MODULE_0_date_fns__["format"])(d, 'MMMM', {
    locale: dateFormat.fnsLocale
  });
}
function formatWeekdayShort(i) {
  var locale = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'en-US';
  var dateFormat = getDateFormat(locale);
  return Object(__WEBPACK_IMPORTED_MODULE_0_date_fns__["format"])(dayDates[i], 'dd', {
    locale: dateFormat.fnsLocale
  });
}
function formatWeekdayLong(i) {
  var locale = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'en-US';
  var dateFormat = getDateFormat(locale);
  return Object(__WEBPACK_IMPORTED_MODULE_0_date_fns__["format"])(dayDates[i], 'dddd', {
    locale: dateFormat.fnsLocale
  });
}
function getFirstDayOfWeek() {
  var locale = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'en-US';
  // Not Supported By date-fns, waiting version 2
  return 0;
}
var dayPickerLocaleUtils = {
  formatDay: formatDay,
  formatMonthTitle: formatMonthTitle,
  formatWeekdayShort: formatWeekdayShort,
  formatWeekdayLong: formatWeekdayLong,
  getFirstDayOfWeek: getFirstDayOfWeek
};

/***/ }),

/***/ "./react-next/utils/component-utils.js":
/***/ (function(module, exports) {

var ComponentUtils = {};

ComponentUtils.getWindowInitialPageProps = function () {
  if (typeof window !== 'undefined') {
    return window.__NEXT_DATA__.props.initialProps;
  }

  return {};
};

module.exports = ComponentUtils;

/***/ }),

/***/ "./react-next/utils/intl-utils.js":
/***/ (function(module, exports) {

var IntlUtils = {};

IntlUtils.getUrlLocale = function (locales, path) {
  // TODO: change to baseurl + /locale path check
  var url = path.toLowerCase();

  for (var i = 0; i < locales.length; i++) {
    if (url.indexOf(locales[i].toLowerCase()) === 1) {
      return locales[i];
    }
  }

  return '';
};

IntlUtils.cultureCodeToISO = function (cultureCode) {
  var culture = cultureCode.split('-')[1];

  if (['zh-tw', 'zh-hk', 'zh-mo'].includes(cultureCode.toLowerCase())) {
    return "zh-Hant-".concat(culture);
  } // other chinese


  if (cultureCode.split('-')[0] === 'zh') {
    return "zh-Hans-".concat(culture);
  }

  return cultureCode;
}; // Important Note: react-intl/locale-data/zh does not contain Hant-TW or Hans-CN
// So it is different from intl.js


IntlUtils.cultureCodeToReactLocale = function (cultureCode) {
  var culture = cultureCode.split('-')[1];

  if (['zh-hk', 'zh-mo'].includes(cultureCode.toLowerCase())) {
    return "zh-Hant-".concat(culture);
  }

  if (cultureCode.toLowerCase() === 'zh-SG') {
    return "zh-Hans-".concat(culture);
  }

  if (cultureCode.toLowerCase() === 'zh-TW') {
    return 'zh-Hant';
  }

  if (cultureCode.toLowerCase() === 'zh-CN') {
    return 'zh-Hans';
  }

  return cultureCode;
};

module.exports = IntlUtils;

/***/ }),

/***/ "./react-next/utils/json-utils.js":
/***/ (function(module, exports) {

var JsonUtils = {};

JsonUtils.addValuesTo = function (targetObject, sourceObject) {
  var logWarning = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;

  for (var key in sourceObject) {
    // Copy Value to Target or Overrides
    if (targetObject.hasOwnProperty(key) && logWarning) {
      console.log('Warning: target key existed');
    }

    targetObject[key] = sourceObject[key];
  }
};

JsonUtils.overrideValues = function (targetObject, sourceObject) {
  for (var key in sourceObject) {
    if (targetObject.hasOwnProperty(key)) {
      targetObject[key] = sourceObject[key];
    }
  }
};

module.exports = JsonUtils;

/***/ }),

/***/ "./store/modules/common/config/action-types.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
  SET_CONFIG: 'module/common/config/SET_CONFIG_REQUEST'
});

/***/ }),

/***/ "./store/modules/currency-selection/action-types.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var actionTypes = {
  GET_SELECTED_CURRENCY_REQUEST: 'module/currency/GET_SELECTED_CURRENCY_REQUEST',
  GET_SELECTED_CURRENCY_SUCCESS: 'module/currency/GET_SELECTED_CURRENCY_SUCCESS',
  SELECT_CURRENCY: 'module/currency/SELECT_CURRENCY',
  SELECT_CURRENCY_FROM_URL_REQUEST: 'module/currency/SELECT_CURRENCY_FROM_URL_REQUEST',
  SELECT_CURRENCY_FROM_URL: 'module/currency/SELECT_CURRENCY_FROM_URL'
};
/* harmony default export */ __webpack_exports__["a"] = (actionTypes);

/***/ }),

/***/ "./store/modules/currency-selection/selectors.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getSelectedCurrency; });
// eslint-disable-next-line
var getSelectedCurrency = function getSelectedCurrency(state) {
  return state.moduleCurrencySelection.selectedCurrency;
};

/***/ }),

/***/ "./store/modules/locale-selection/action-types.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var SET_CULTURE_CODE = 'modules/locale-selection/SET_CULTURE_CODE';
var GET_SELECTED_CULTURE_CODE = 'modules/locale-selection/GET_SELECTED_CULTURE_CODE';
/* harmony default export */ __webpack_exports__["a"] = ({
  SET_CULTURE_CODE: SET_CULTURE_CODE,
  GET_SELECTED_CULTURE_CODE: GET_SELECTED_CULTURE_CODE
});

/***/ }),

/***/ "./store/modules/locale-selection/selectors.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getCultureCode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return getUrlLocale; });
var getCultureCode = function getCultureCode(state) {
  return state.moduleLocaleSelection.cultureCode;
};
var getUrlLocale = function getUrlLocale(state) {
  return state.moduleLocaleSelection.urlLocale;
};

/***/ }),

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("./pages/Home/index.jsx");


/***/ }),

/***/ "@babel/runtime/regenerator":
/***/ (function(module, exports) {

module.exports = require("@babel/runtime/regenerator");

/***/ }),

/***/ "@paralleldrive/react-feature-toggles":
/***/ (function(module, exports) {

module.exports = require("@paralleldrive/react-feature-toggles");

/***/ }),

/***/ "date-fns":
/***/ (function(module, exports) {

module.exports = require("date-fns");

/***/ }),

/***/ "date-fns/add_days":
/***/ (function(module, exports) {

module.exports = require("date-fns/add_days");

/***/ }),

/***/ "date-fns/difference_in_calendar_days":
/***/ (function(module, exports) {

module.exports = require("date-fns/difference_in_calendar_days");

/***/ }),

/***/ "date-fns/format":
/***/ (function(module, exports) {

module.exports = require("date-fns/format");

/***/ }),

/***/ "date-fns/get_month":
/***/ (function(module, exports) {

module.exports = require("date-fns/get_month");

/***/ }),

/***/ "date-fns/get_year":
/***/ (function(module, exports) {

module.exports = require("date-fns/get_year");

/***/ }),

/***/ "date-fns/locale/en":
/***/ (function(module, exports) {

module.exports = require("date-fns/locale/en");

/***/ }),

/***/ "date-fns/locale/zh_cn":
/***/ (function(module, exports) {

module.exports = require("date-fns/locale/zh_cn");

/***/ }),

/***/ "date-fns/locale/zh_tw":
/***/ (function(module, exports) {

module.exports = require("date-fns/locale/zh_tw");

/***/ }),

/***/ "ip":
/***/ (function(module, exports) {

module.exports = require("ip");

/***/ }),

/***/ "lodash":
/***/ (function(module, exports) {

module.exports = require("lodash");

/***/ }),

/***/ "next/router":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "query-string":
/***/ (function(module, exports) {

module.exports = require("query-string");

/***/ }),

/***/ "raven-js":
/***/ (function(module, exports) {

module.exports = require("raven-js");

/***/ }),

/***/ "react":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-day-picker":
/***/ (function(module, exports) {

module.exports = require("react-day-picker");

/***/ }),

/***/ "react-dom":
/***/ (function(module, exports) {

module.exports = require("react-dom");

/***/ }),

/***/ "react-helmet":
/***/ (function(module, exports) {

module.exports = require("react-helmet");

/***/ }),

/***/ "react-icons/fa/":
/***/ (function(module, exports) {

module.exports = require("react-icons/fa/");

/***/ }),

/***/ "react-icons/io":
/***/ (function(module, exports) {

module.exports = require("react-icons/io");

/***/ }),

/***/ "react-icons/md":
/***/ (function(module, exports) {

module.exports = require("react-icons/md");

/***/ }),

/***/ "react-intl":
/***/ (function(module, exports) {

module.exports = require("react-intl");

/***/ }),

/***/ "react-redux":
/***/ (function(module, exports) {

module.exports = require("react-redux");

/***/ }),

/***/ "styled-jsx/style":
/***/ (function(module, exports) {

module.exports = require("styled-jsx/style");

/***/ })

/******/ });
//# sourceMappingURL=Home.js.map