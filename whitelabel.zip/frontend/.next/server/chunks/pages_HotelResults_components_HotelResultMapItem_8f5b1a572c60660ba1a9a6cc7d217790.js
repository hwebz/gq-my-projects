exports.ids = [5,6];
exports.modules = {

/***/ "./pages/HotelResults/components/HotelResultMapItem.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__HotelResultMapItem_scss__ = __webpack_require__("./pages/HotelResults/components/HotelResultMapItem.scss");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__HotelResultMapItem_scss___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__HotelResultMapItem_scss__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_mapbox_gl__ = __webpack_require__("react-mapbox-gl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_mapbox_gl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_mapbox_gl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__HotelResultMapItemPopup__ = __webpack_require__("./pages/HotelResults/components/HotelResultMapItemPopup.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\pages\\HotelResults\\components\\HotelResultMapItem.jsx";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }





// Declaring Map with access token
var Map = __WEBPACK_IMPORTED_MODULE_2_react_mapbox_gl___default()({
  accessToken: 'pk.eyJ1IjoiZ29xdW8td2hpdGVsYWJlbCIsImEiOiJjams3MTljMGIxNTB3M3BvNHUyNWRza2JrIn0.tkmROUS49HhH-xVfHn3RPA'
});

var HotelResultMapItem =
/*#__PURE__*/
function (_React$Component) {
  _inherits(HotelResultMapItem, _React$Component);

  function HotelResultMapItem(props) {
    var _this;

    _classCallCheck(this, HotelResultMapItem);

    _this = _possibleConstructorReturn(this, (HotelResultMapItem.__proto__ || Object.getPrototypeOf(HotelResultMapItem)).call(this, props));
    Object.defineProperty(_assertThisInitialized(_this), "onToggleHover", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(cursor, _ref) {
        var map = _ref.map;
        // Assigning the pointer cursor
        map.getCanvas().style.cursor = cursor;
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "getFeatureProperties", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(hotel) {
        var useTotalPrice = _this.props.useTotalPrice;
        var properties = {};
        var price = useTotalPrice ? hotel.price.perPackage.price : hotel.price.perPerson.price;
        properties.price = price;
        return properties;
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "markerClick", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(hotel, _ref2) {
        var feature = _ref2.feature;

        _this.setState({
          center: feature.geometry.coordinates,
          hotelId: hotel.hotelId,
          selectedHotel: hotel
        });
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "handleGetMapHotels", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(map) {
        var handlGetMapHotel = _this.props.handlGetMapHotel; // To get the coordinates for North-West and South-East long lat

        var nw = map.getBounds().getNorthWest();
        var se = map.getBounds().getSouthEast();
        var coordinates = {
          nwLon: nw.lng,
          nwLat: nw.lat,
          seLon: se.lng,
          seLat: se.lat
        };

        var mapHotel = function mapHotel() {
          handlGetMapHotel(coordinates);
        };

        mapHotel();
        return false;
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "closePopOver", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        var hotelId = _this.state.hotelId;

        if (hotelId) {
          _this.setState({
            hotelId: undefined,
            selectedHotel: undefined
          });
        }
      }
    });
    _this.state = {
      center: [props.hotels.package.long, props.hotels.package.lat],
      zoom: [13],
      hotelId: undefined,
      selectedHotel: []
    };
    _this.handleGetMapHotels = _this.handleGetMapHotels.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(HotelResultMapItem, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      // Hotel location pin-point marker svg
      var marker = '<svg width="71" height="42" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill="#485361" d="M25 30.607L35.607 20l10.606 10.607-10.606 10.607z"/><rect width="71" height="31" rx="3" fill="#485361"/></svg>'; // Create an image for the Layer component

      var image = new Image();
      image.src = "data:image/svg+xml;charset=utf-8;base64,".concat(btoa(marker));
      var images = ['marker', image];
      var _props = this.props,
          hotels = _props.hotels,
          defaultCurrency = _props.defaultCurrency,
          cultureCode = _props.cultureCode,
          useTotalPrice = _props.useTotalPrice,
          nightCount = _props.nightCount;
      var _state = this.state,
          center = _state.center,
          zoom = _state.zoom,
          hotelId = _state.hotelId,
          selectedHotel = _state.selectedHotel;
      var mapHotels;

      if (hotels) {
        if (hotels.map) {
          mapHotels = hotels.map.hotels;
        }
      }

      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Fragment, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 105
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Map, {
        style: "mapbox://styles/mapbox/streets-v9",
        center: center // longitude, latitude coordinate
        ,
        zoom: zoom,
        containerStyle: {
          height: '80vh'
        },
        onClick: function onClick() {
          _this2.closePopOver();
        },
        onStyleLoad: function onStyleLoad(map) {
          _this2.handleGetMapHotels(map);
        },
        onMoveEnd: function onMoveEnd(map) {
          _this2.handleGetMapHotels(map);
        },
        movingMethod: "easeTo",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 106
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_mapbox_gl__["Layer"], {
        type: "symbol",
        id: "marker",
        images: images,
        layout: {
          'icon-image': 'marker',
          'text-field': 'RM {price}00000 000',
          'icon-text-fit': 'width',
          'icon-text-fit-padding': [-1, 10, 12, 10],
          'text-size': 12,
          'text-font': ['Open Sans Bold', 'Arial Unicode MS Bold']
        },
        paint: {
          'text-color': 'white'
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 118
        }
      }, mapHotels && mapHotels.map(function (hotel) {
        return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_mapbox_gl__["Feature"], {
          key: hotel.hotelId,
          properties: _this2.getFeatureProperties(hotel),
          coordinates: [hotel.lon, hotel.lat],
          onMouseEnter: function onMouseEnter(map) {
            _this2.onToggleHover('pointer', map);
          },
          onMouseLeave: function onMouseLeave(map) {
            _this2.onToggleHover('', map);
          } // hotel is sent to provide data for popup
          ,
          onClick: function onClick(map) {
            _this2.markerClick(hotel, map);
          },
          __source: {
            fileName: _jsxFileName,
            lineNumber: 137
          }
        });
      })), hotelId && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_mapbox_gl__["Popup"], {
        key: 123,
        coordinates: [selectedHotel.lon, selectedHotel.lat],
        className: "map-popup",
        anchor: "bottom",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 152
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("a", {
        href: selectedHotel.url,
        target: "_blank",
        rel: "noopener noreferrer",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 158
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__HotelResultMapItemPopup__["a" /* default */], {
        hotel: selectedHotel,
        useTotalPrice: useTotalPrice,
        nightCount: nightCount,
        paxCount: hotels.package.paxCount,
        cultureCode: cultureCode,
        defaultCurrency: defaultCurrency,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 159
        }
      })))));
    }
  }]);

  return HotelResultMapItem;
}(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (HotelResultMapItem);

/***/ }),

/***/ "./pages/HotelResults/components/HotelResultMapItem.scss":
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/HotelResults/components/HotelResultMapItemPopup.jsx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl__ = __webpack_require__("react-intl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_intl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__components_NumberFormat__ = __webpack_require__("./components/NumberFormat/index.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__components_StarsRaing_StarsRatingSingle__ = __webpack_require__("./components/StarsRaing/StarsRatingSingle.jsx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components_ReviewRating_ReviewRating__ = __webpack_require__("./components/ReviewRating/ReviewRating.jsx");
var _jsxFileName = "C:\\Projects\\frontend\\pages\\HotelResults\\components\\HotelResultMapItemPopup.jsx";






var HotelResultMapItemPopup = function HotelResultMapItemPopup(_ref) {
  var hotel = _ref.hotel,
      defaultCurrency = _ref.defaultCurrency,
      cultureCode = _ref.cultureCode,
      useTotalPrice = _ref.useTotalPrice,
      nightCount = _ref.nightCount,
      paxCount = _ref.paxCount;
  var newPrice = useTotalPrice ? hotel.price.perPackage.price : hotel.price.perPerson.price;
  var backgroundImage = {
    backgroundImage: "url(".concat(hotel.image || 'https://www.toadandco.com/c.1311986/sca-dev-elbrus/img/no_image_available.jpeg', ")")
  };
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "map-popup__container",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 22
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "map-popup__img",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    style: backgroundImage,
    className: "img",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "map-popup__wrapper",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "map-popup__name text-overflow",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    }
  }, hotel ? hotel.name : '----------------------------------------'), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "map-popup__item map-popup__rating",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  }, hotel.stars > 0 && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__components_StarsRaing_StarsRatingSingle__["a" /* default */], {
    stars: hotel.stars,
    size: "map-popup-rating",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    }
  }), hotel.rating.score > 0 && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__components_ReviewRating_ReviewRating__["a" /* default */], {
    data: hotel.rating,
    position: "right",
    size: "map-popup-rating",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "map-popup__item map-popup__price",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: " theme-primary-text",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__components_NumberFormat__["a" /* default */], {
    value: "".concat(newPrice),
    currency: "".concat(defaultCurrency),
    locale: "".concat(cultureCode),
    withSmall: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "map-popup__price__note",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 56
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 57
    }
  }, useTotalPrice && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "hotelDeta ilPrice.totalPriceForPeople",
    defaultMessage: 'total  price for {count} people',
    values: {
      count: paxCount
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    }
  }) || __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "hotelDetailPrice.perPerson",
    defaultMessage: 'per person for {count, number} {count, plural, one {night} other {nights}}' // TODO pluralize night & no of nights from gethotels api
    ,
    values: {
      count: nightCount
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("span", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 73
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["FormattedMessage"], {
    id: "hotelDetailPrice.includingTaxesAndFees",
    defaultMessage: "including taxes & fees",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 74
    }
  }))))));
};

/* harmony default export */ __webpack_exports__["a"] = (HotelResultMapItemPopup);

/***/ })

};;
//# sourceMappingURL=pages_HotelResults_components_HotelResultMapItem_8f5b1a572c60660ba1a9a6cc7d217790.js.map