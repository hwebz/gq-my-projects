webpackHotUpdate(1,{

/***/ "./pages/HotelResults/actions.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return actionTypes; });
/* harmony export (immutable) */ __webpack_exports__["e"] = failure;
/* unused harmony export getClientConfigData */
/* unused harmony export getClientConfigDataSuccess */
/* unused harmony export createPackage */
/* harmony export (immutable) */ __webpack_exports__["d"] = createPackageSuccess;
/* harmony export (immutable) */ __webpack_exports__["c"] = createPackageFailed;
/* harmony export (immutable) */ __webpack_exports__["f"] = getFilteredHotels;
/* harmony export (immutable) */ __webpack_exports__["k"] = getMapHotel;
/* harmony export (immutable) */ __webpack_exports__["m"] = getMapHotelsSuccess;
/* harmony export (immutable) */ __webpack_exports__["l"] = getMapHotelsFailed;
/* harmony export (immutable) */ __webpack_exports__["n"] = pollStartAction;
/* harmony export (immutable) */ __webpack_exports__["o"] = pollStopAction;
/* harmony export (immutable) */ __webpack_exports__["j"] = getHotelsSuccess;
/* harmony export (immutable) */ __webpack_exports__["i"] = getHotelsFailed;
/* harmony export (immutable) */ __webpack_exports__["b"] = changeFilter;
/* harmony export (immutable) */ __webpack_exports__["p"] = resetFilter;
/* harmony export (immutable) */ __webpack_exports__["r"] = toggleGallery;
/* harmony export (immutable) */ __webpack_exports__["g"] = getHotelGallery;
/* harmony export (immutable) */ __webpack_exports__["h"] = getHotelGallerySuccess;
/* harmony export (immutable) */ __webpack_exports__["q"] = setPage;
var actionTypes = {
  FAILURE: 'FAILURE',
  GET_CLIENT_CONFIG: 'GET_CLIENT_CONFIG',
  GET_CLIENT_CONFIG_SUCCESS: 'GET_CLIENT_CONFIG_SUCCESS',
  CREATE_PACKAGE: 'CREATE_PACKAGE',
  CREATE_PACKAGE_SUCCESS: 'CREATE_PACKAGE_SUCCESS',
  CREATE_PACKAGE_FAILED: 'CREATE_PACKAGE_FAILED',
  GET_FILTERED_HOTELS: 'GET_FILTERED_HOTELS',
  HOTEL_RESULT_POLL_START: 'HOTEL_RESULT_POLL_START',
  HOTEL_RESULT_POLL_STOP: 'HOTEL_RESULT_POLL_STOP',
  GET_HOTELS_SUCCESS: 'GET_HOTELS_SUCCESS',
  GET_HOTELS_FAILED: 'GET_HOTELS_FAILED',
  CHANGE_FILTER: 'CHANGE_FILTER',
  RESET_FILTER: 'RESET_FILTER',
  SET_PAGE: 'SET_PAGE',
  TOGGLE_GALLERY_HL: 'TOGGLE_GALLERY_HL',
  GET_HOTEL_GALLERY_HL: 'GET_HOTEL_GALLERY_HL',
  GET_HOTEL_GALLERY_SUCCESS_HL: 'GET_HOTEL_GALLERY_SUCCESS_HL',
  GET_MAP_HOTEL: 'GET_MAP_HOTEL',
  GET_MAP_HOTEL_SUCCESS: 'GET_MAP_HOTEL_SUCCESS',
  GET_MAP_HOTEL_FAILED: 'GET_MAP_HOTEL_FAILED'
};
function failure(error) {
  return {
    type: actionTypes.FAILURE,
    error: error
  };
}
function getClientConfigData() {
  return {
    type: actionTypes.GET_CLIENT_CONFIG
  };
}
function getClientConfigDataSuccess(data) {
  return {
    type: actionTypes.GET_CLIENT_CONFIG_SUCCESS,
    data: data
  };
}
function createPackage(query) {
  return {
    type: actionTypes.CREATE_PACKAGE,
    query: query
  };
}
function createPackageSuccess(packageId, percent) {
  return {
    type: actionTypes.CREATE_PACKAGE_SUCCESS,
    data: packageId,
    percent: percent
  };
}
function createPackageFailed(callbacks) {
  return {
    type: actionTypes.CREATE_PACKAGE_FAILED,
    data: callbacks
  };
}
function getFilteredHotels(packageId, hotelApiQuery, percent) {
  return {
    type: actionTypes.GET_FILTERED_HOTELS,
    data: {
      packageId: packageId,
      hotelApiQuery: hotelApiQuery,
      percent: percent
    }
  };
}
function getMapHotel(coordinates) {
  return {
    type: actionTypes.GET_MAP_HOTEL,
    data: coordinates
  };
}
function getMapHotelsSuccess(hotels) {
  return {
    type: actionTypes.GET_MAP_HOTEL_SUCCESS,
    data: hotels
  };
}
function getMapHotelsFailed(callbacks) {
  return {
    type: actionTypes.GET_MAP_HOTEL_FAILED,
    data: callbacks
  };
}
function pollStartAction(_ref) {
  var payload = _ref.payload;
  return {
    type: actionTypes.HOTEL_RESULT_POLL_START,
    payload: payload
  };
}
function pollStopAction(percent, total) {
  var totalHotels = parseInt(total, 10);
  return {
    type: actionTypes.HOTEL_RESULT_POLL_STOP,
    percent: percent,
    totalHotels: totalHotels
  };
}
function getHotelsSuccess(hotels, percent) {
  return {
    type: actionTypes.GET_HOTELS_SUCCESS,
    data: hotels,
    percent: percent
  };
}
function getHotelsFailed(callbacks) {
  return {
    type: actionTypes.GET_HOTELS_FAILED,
    data: callbacks
  };
}
function changeFilter(filters) {
  return {
    type: actionTypes.CHANGE_FILTER,
    data: filters
  };
}
function resetFilter(filters) {
  return {
    type: actionTypes.RESET_FILTER,
    data: filters
  };
}
function toggleGallery(data) {
  return {
    type: actionTypes.TOGGLE_GALLERY_HL,
    data: data
  };
}
function getHotelGallery(hotelId) {
  return {
    type: actionTypes.GET_HOTEL_GALLERY_HL,
    hotelId: hotelId
  };
}
function getHotelGallerySuccess(data) {
  return {
    type: actionTypes.GET_HOTEL_GALLERY_SUCCESS_HL,
    data: data
  };
}
function setPage(currentPage) {
  return {
    type: actionTypes.SET_PAGE,
    currentPage: currentPage
  };
}
    (function (Component, route) {
      if(!Component) return
      if (false) return
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/HotelResults\\actions")
  
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ }),

/***/ "./pages/HotelResults/hotelResultSaga.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (immutable) */ __webpack_exports__["a"] = hotelResultsSaga;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_axios__ = __webpack_require__("./node_modules/axios/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_axios___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_axios__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__ = __webpack_require__("./node_modules/redux-saga/es/effects.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_redux_saga__ = __webpack_require__("./node_modules/redux-saga/es/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_es6_promise__ = __webpack_require__("./node_modules/es6-promise/dist/es6-promise.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_es6_promise___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_es6_promise__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_services__ = __webpack_require__("./services/services.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__actions__ = __webpack_require__("./pages/HotelResults/actions.js");


var _marked =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(pollHotelResults),
    _marked2 =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(getFilteredHotelResults),
    _marked3 =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(getHotelGallerySaga),
    _marked4 =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(getMapHotelSaga),
    _marked5 =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(hotelResultsSaga);





 // all api services can be accessed


__WEBPACK_IMPORTED_MODULE_4_es6_promise___default.a.polyfill(); // get the action payload from HOTEL_RESULT_POLL_START,
// passing directly to the method cause infinity loop

var globlePayload;

function pollHotelResults() {
  var _globlePayload$payloa, cultureCode, currency, pageSize, currentPage, packageData, count, isCompleted, progressAmount, packageId, pidObj, res, data, successData;

  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function pollHotelResults$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          _globlePayload$payloa = globlePayload.payload, cultureCode = _globlePayload$payloa.cultureCode, currency = _globlePayload$payloa.currency, pageSize = _globlePayload$payloa.pageSize, currentPage = _globlePayload$payloa.currentPage, packageData = _globlePayload$payloa.packageData;
          count = 0;
          isCompleted = false;
          progressAmount = 0;
          packageId = '';
          _context.prev = 5;
          _context.next = 8;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["b" /* call */])(function () {
            return __WEBPACK_IMPORTED_MODULE_1_axios___default()({
              method: 'post',
              url: __WEBPACK_IMPORTED_MODULE_5__services_services__["a" /* default */].createPackage,
              data: packageData
            });
          });

        case 8:
          pidObj = _context.sent;
          _context.next = 11;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["d" /* put */])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["d" /* createPackageSuccess */])(pidObj.data.packageId, progressAmount));

        case 11:
          packageId = _context.sent;
          console.log('%c Hotel package ID created!! ', 'background: #29bc7a; color: #fff');
          _context.next = 20;
          break;

        case 15:
          _context.prev = 15;
          _context.t0 = _context["catch"](5);
          console.log('%c Package ID not created!! ', 'background: #f00; color: #fff');
          _context.next = 20;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["d" /* put */])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["c" /* createPackageFailed */])(_context.t0));

        case 20:
          if (!packageId) {
            _context.next = 55;
            break;
          }

        case 21:
          if (false) {
            _context.next = 55;
            break;
          }

          count++;
          progressAmount = count * 20;
          _context.prev = 24;
          _context.next = 27;
          return __WEBPACK_IMPORTED_MODULE_1_axios___default()("".concat(__WEBPACK_IMPORTED_MODULE_5__services_services__["a" /* default */].getHotels, "?packageId=").concat(packageId.data, "&lang=").concat(cultureCode, "&currency=").concat(currency, "&pageSize=").concat(pageSize, "&page=").concat(currentPage));

        case 27:
          res = _context.sent;
          _context.next = 30;
          return res.data;

        case 30:
          data = _context.sent;
          _context.next = 33;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["d" /* put */])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["j" /* getHotelsSuccess */])(data, progressAmount, count));

        case 33:
          successData = _context.sent;
          isCompleted = successData.data.isComplete;
          _context.next = 37;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["b" /* call */])(__WEBPACK_IMPORTED_MODULE_3_redux_saga__["c" /* delay */], 2000);

        case 37:
          if (!isCompleted) {
            _context.next = 42;
            break;
          }

          _context.next = 40;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["d" /* put */])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["o" /* pollStopAction */])(100, successData.data.totalHotels));

        case 40:
          _context.next = 46;
          break;

        case 42:
          if (!(count >= 5)) {
            _context.next = 46;
            break;
          }

          isCompleted = true;
          _context.next = 46;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["d" /* put */])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["o" /* pollStopAction */])(100, successData.data.totalHotels));

        case 46:
          _context.next = 53;
          break;

        case 48:
          _context.prev = 48;
          _context.t1 = _context["catch"](24);
          console.log("error");
          _context.next = 53;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["d" /* put */])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["i" /* getHotelsFailed */])(_context.t1));

        case 53:
          _context.next = 21;
          break;

        case 55:
        case "end":
          return _context.stop();
      }
    }
  }, _marked, this, [[5, 15], [24, 48]]);
}

function getFilteredHotelResults(payload) {
  var _payload$data, packageId, hotelApiQuery, page, pageSize, maxPriceType, filters, lang, currency, _ref, data;

  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function getFilteredHotelResults$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          _payload$data = payload.data, packageId = _payload$data.packageId, hotelApiQuery = _payload$data.hotelApiQuery;
          page = hotelApiQuery.page, pageSize = hotelApiQuery.pageSize, maxPriceType = hotelApiQuery.maxPriceType, filters = hotelApiQuery.filters, lang = hotelApiQuery.lang, currency = hotelApiQuery.currency;
          _context2.prev = 2;
          _context2.next = 5;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["b" /* call */])(function () {
            return __WEBPACK_IMPORTED_MODULE_1_axios___default()({
              method: 'get',
              url: "".concat(__WEBPACK_IMPORTED_MODULE_5__services_services__["a" /* default */].getHotels, "?packageId=").concat(packageId, "&page=").concat(page, "&pageSize=").concat(pageSize, "&name=").concat(filters.name, "&minStars=").concat(filters.minStars, "&maxPrice=").concat(filters.maxPrice, "&maxPriceType=").concat(maxPriceType, "&minReview=").concat(filters.minReview, "&sortBy=").concat(filters.sortBy, "&lang=").concat(lang, "&currency=").concat(currency)
            });
          });

        case 5:
          _ref = _context2.sent;
          data = _ref.data;
          _context2.next = 9;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["d" /* put */])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["j" /* getHotelsSuccess */])(data));

        case 9:
          _context2.next = 15;
          break;

        case 11:
          _context2.prev = 11;
          _context2.t0 = _context2["catch"](2);
          _context2.next = 15;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["d" /* put */])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["i" /* getHotelsFailed */])(_context2.t0));

        case 15:
        case "end":
          return _context2.stop();
      }
    }
  }, _marked2, this, [[2, 11]]);
}

function ImageExist(url) {
  var img = new Image();
  img.src = url;

  if (img.height !== 0) {
    return false;
  }

  return true;
}

function getHotelGallerySaga(payload) {
  var hotelId, images, _ref2, data;

  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function getHotelGallerySaga$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          // later we will use hotelId to get data
          hotelId = payload.hotelId;
          images = [];
          _context3.prev = 2;
          _context3.next = 5;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["b" /* call */])(function () {
            return __WEBPACK_IMPORTED_MODULE_1_axios___default()({
              method: 'get',
              url: "".concat(__WEBPACK_IMPORTED_MODULE_5__services_services__["a" /* default */].getHotelGallery, "?hotelId=").concat(hotelId)
            });
          });

        case 5:
          _ref2 = _context3.sent;
          data = _ref2.data;
          data.data.map(function (url) {
            if (ImageExist(url)) {
              images.push(url);
            }
          });
          _context3.next = 10;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["d" /* put */])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["h" /* getHotelGallerySuccess */])(images));

        case 10:
          _context3.next = 16;
          break;

        case 12:
          _context3.prev = 12;
          _context3.t0 = _context3["catch"](2);
          _context3.next = 16;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["d" /* put */])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["e" /* failure */])(_context3.t0));

        case 16:
        case "end":
          return _context3.stop();
      }
    }
  }, _marked3, this, [[2, 12]]);
}

function getMapHotelSaga(payload) {
  var _ref3, data;

  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function getMapHotelSaga$(_context4) {
    while (1) {
      switch (_context4.prev = _context4.next) {
        case 0:
          _context4.prev = 0;
          _context4.next = 3;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["b" /* call */])(function () {
            return __WEBPACK_IMPORTED_MODULE_1_axios___default()({
              method: 'get',
              url: "".concat(__WEBPACK_IMPORTED_MODULE_5__services_services__["a" /* default */].getMapHotels, "?").concat(payload.data)
            });
          });

        case 3:
          _ref3 = _context4.sent;
          data = _ref3.data;
          _context4.next = 7;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["d" /* put */])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["m" /* getMapHotelsSuccess */])(data));

        case 7:
          _context4.next = 13;
          break;

        case 9:
          _context4.prev = 9;
          _context4.t0 = _context4["catch"](0);
          _context4.next = 13;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["d" /* put */])(Object(__WEBPACK_IMPORTED_MODULE_6__actions__["l" /* getMapHotelsFailed */])(_context4.t0));

        case 13:
        case "end":
          return _context4.stop();
      }
    }
  }, _marked4, this, [[0, 9]]);
}

function hotelResultsSaga() {
  return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function hotelResultsSaga$(_context5) {
    while (1) {
      switch (_context5.prev = _context5.next) {
        case 0:
          _context5.next = 2;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["c" /* fork */])(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["h" /* takeLatest */], 'GET_FILTERED_HOTELS', getFilteredHotelResults);

        case 2:
          _context5.next = 4;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["c" /* fork */])(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["h" /* takeLatest */], 'GET_MAP_HOTEL', getMapHotelSaga);

        case 4:
          _context5.next = 6;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["c" /* fork */])(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["h" /* takeLatest */], 'GET_HOTEL_GALLERY_HL', getHotelGallerySaga);

        case 6:
          if (false) {
            _context5.next = 14;
            break;
          }

          _context5.next = 9;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["g" /* take */])(__WEBPACK_IMPORTED_MODULE_6__actions__["a" /* actionTypes */].HOTEL_RESULT_POLL_START);

        case 9:
          globlePayload = _context5.sent;
          _context5.next = 12;
          return Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["e" /* race */])([Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["b" /* call */])(pollHotelResults), Object(__WEBPACK_IMPORTED_MODULE_2_redux_saga_effects__["g" /* take */])(__WEBPACK_IMPORTED_MODULE_6__actions__["a" /* actionTypes */].HOTEL_RESULT_POLL_STOP)]);

        case 12:
          _context5.next = 6;
          break;

        case 14:
        case "end":
          return _context5.stop();
      }
    }
  }, _marked5, this);
}
    (function (Component, route) {
      if(!Component) return
      if (false) return
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/HotelResults\\hotelResultSaga")
  
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ }),

/***/ "./pages/HotelResults/reducers.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react_addons_update__ = __webpack_require__("./node_modules/react-addons-update/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react_addons_update___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react_addons_update__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__actions__ = __webpack_require__("./pages/HotelResults/actions.js");
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


 // import type { HomeProps } from './types';

function reducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var action = arguments.length > 1 ? arguments[1] : undefined;

  switch (action.type) {
    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].FAILURE:
      return _objectSpread({}, state, {
        error: action.error,
        isFetching: false
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG:
      return _objectSpread({}, state, {
        isFetching: true
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG_SUCCESS:
      return _objectSpread({}, state, {
        response: action.data,
        isFetching: false
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_CLIENT_CONFIG_FAILED:
      return _objectSpread({}, state, {
        response: null
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].CREATE_PACKAGE:
      return _objectSpread({}, state, {
        isFetching: true
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].CREATE_PACKAGE_SUCCESS:
      return _objectSpread({}, state, {
        packageId: action.data,
        isFetching: false
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].CREATE_PACKAGE_FAILED:
      return _objectSpread({}, state, {
        response: null,
        apiCallbacks: action.data
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_FILTERED_HOTELS:
      return _objectSpread({}, state, {
        isUpdating: true
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_MAP_HOTEL:
      return _objectSpread({}, state);

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_MAP_HOTEL_SUCCESS:
      {
        return __WEBPACK_IMPORTED_MODULE_0_react_addons_update___default()(state, {
          hotels: {
            map: {
              $set: action.data
            }
          }
        });
      }

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_MAP_HOTEL_FAILED:
      return _objectSpread({}, state, {
        response: null,
        callbacks: action.data
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].HOTEL_RESULT_POLL_START:
      return _objectSpread({}, state, {
        isPolling: true,
        progressStatus: {
          percent: action.percent,
          loadingMsg: 'Loading hotels...' // TODO replace message id of the text

        }
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].HOTEL_RESULT_POLL_STOP:
      {
        var inComplete = action.totalHotels > 0 ? true : false;
        var isComplete = action.totalHotels > 0 ? true : false;
        var initialState = action.totalHotels <= 0 ? true : false;
        return _objectSpread({}, state, {
          isPolling: false,
          progressStatus: {
            percent: action.percent,
            loadingMsg: "".concat(action.totalHotels, " Hotels Loaded.") // TODO replace message id of the text

          },
          inComplete: inComplete,
          isComplete: isComplete
        });
      }

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_HOTELS_SUCCESS:
      {
        var _inComplete = parseInt(action.data.totalHotels, 10) > 0 && state.isPolling ? true : false;

        var _isComplete = parseInt(action.data.totalHotels, 10) > 0 && !state.isPolling ? true : false;

        return _objectSpread({}, state, {
          hotels: action.data,
          isUpdating: false,
          progressStatus: {
            percent: action.percent,
            loadingMsg: 'Finding the best deals' // TODO replace message id of the text

          },
          inComplete: _inComplete,
          isComplete: _isComplete
        });
      }

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_HOTELS_FAILED:
      return _objectSpread({}, state, {
        response: null,
        callbacks: action.data
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].CHANGE_FILTER:
      {
        var _action$data = action.data,
            key = _action$data.key,
            value = _action$data.value;
        return __WEBPACK_IMPORTED_MODULE_0_react_addons_update___default()(state, {
          filters: _defineProperty({}, key, {
            $set: value
          })
        });
      }

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].RESET_FILTER:
      {
        var data = action.data;
        return __WEBPACK_IMPORTED_MODULE_0_react_addons_update___default()(state, {
          filters: {
            maxPrice: {
              $set: data.maxPrice
            },
            minStars: {
              $set: data.minStars
            },
            minReview: {
              $set: data.minReview
            },
            name: {
              $set: data.name
            },
            sortBy: {
              $set: data.sortBy
            }
          }
        });
      }

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].TOGGLE_GALLERY_HL:
      return _objectSpread({}, state, {
        isGalleryOpen: action.data
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_HOTEL_GALLERY_HL:
      return _objectSpread({}, state, {
        isFetching: true
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_HOTEL_GALLERY_SUCCESS_HL:
      return _objectSpread({}, state, {
        hotelImages: action.data,
        isFetching: false
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].GET_HOTEL_GALLERY_FAILED_HL:
      return _objectSpread({}, state, {
        response: null
      });

    case __WEBPACK_IMPORTED_MODULE_1__actions__["a" /* actionTypes */].SET_PAGE:
      {
        var currentPage = action.currentPage;
        return _objectSpread({}, state, {
          currentPage: currentPage
        });
      }

    default:
      return state;
  }
}

/* harmony default export */ __webpack_exports__["a"] = (reducer);
    (function (Component, route) {
      if(!Component) return
      if (false) return
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/HotelResults\\reducers")
  
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=1.1e05e96962a60fa5fc88.hot-update.js.map