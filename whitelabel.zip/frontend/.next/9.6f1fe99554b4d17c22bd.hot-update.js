webpackHotUpdate(9,{

/***/ "./node_modules/next/link.js":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("./node_modules/next/dist/lib/link.js")


/***/ })

})
//# sourceMappingURL=9.6f1fe99554b4d17c22bd.hot-update.js.map