// Note: Server Config is for API Path that should be hidden from client
// const prod = process.env.NODE_ENV === 'production';

// TODO: Some variables here will be set by published environment variable
// This is created for easy access for environment variables with less human error
class ClientData {
  static get IS_PRODUCTION() {
    return process.env.API_ENV === 'production';
  }

  // static get SENTRY_DSN() { return 'https://91084423adc94e6794f6635184c18307@sentry.io/1237748'; }

  static get SENTRY_DSN() { return 'https://22c5e2d624584ca1aa56dcb20b2de87a@sentry.io/1237747'; }

  static get API_ENVIRONMENT() { return process.env.API_ENV; }

  static get BUILD_ENVIRONMENT() { return process.env.NODE_ENV; }

  // TODO: release version retrieved from a file overriden by auto-deployment
  static get RELEASE_VERSION() { return '0.0.1'; }

  static get API_PATH() {
    // TODO Change to real api
    return (process.env.API_ENV === 'development') ? 'http://white-label-server.s3.amazonaws.com' : 'http://white-label-server.s3.amazonaws.com';
  }
}

module.exports = ClientData;
