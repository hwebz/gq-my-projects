// @flow
// fs is server only module, not acessible by at react
const { readFileSync } = require('fs');

class IntlUtils {
  static localeDataCache: Map<string, string>;

  /**
   * Get react-intl data script for support of polyfill,
   * only works for server node codes hence polyfilled has to be sent from server
   * and has to be Server Side Rendered
   * @param  {string} locale
   */
  static getLocaleDataScript(locale: string) {
    if (!IntlUtils.localeDataCache) {
      IntlUtils.localeDataCache = new Map();
    }

    const lang = locale.split('-')[0];
    if (!IntlUtils.localeDataCache.has(lang)) {
      const localeDataFile = require.resolve(`react-intl/locale-data/${lang}`);
      const localeDataScript = readFileSync(localeDataFile, 'utf8');
      IntlUtils.localeDataCache.set(lang, localeDataScript);
    }
    return IntlUtils.localeDataCache.get(lang);
  }
}

module.exports = IntlUtils;
