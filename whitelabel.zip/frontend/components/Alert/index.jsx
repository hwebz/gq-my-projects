import React from 'react';
import { FormattedMessage, defineMessages } from 'react-intl';
import Modal from 'react-overlays/lib/Modal';
import Link from 'next/link';
// import { MdClose } from 'react-icons/md';

// @flow
import {
  getUrl,
  getFormattedMessages,
  getIsShow,
  getAlertType,
} from 'store-app/modules/alert/selectors';
import { closePopup } from 'store-app/modules/alert/actions';
import ComponentBase, { type GenericComponent } from '../ComponentBase';
import { type AlertProps } from './types';
import './Alert.scss';

const modalStyle = {
  position: 'fixed',
  zIndex: 1040,
  top: 0,
  bottom: 0,
  left: 0,
  right: 0,
};

const backdropStyle = {
  ...modalStyle,
  zIndex: 'auto',
  backgroundColor: '#000',
  opacity: 0.5,
};

const defaultMessages = defineMessages({
  buttonText: {
    id: 'Alert.buttonText',
    defaultMessage: 'OK',
  },
});

// Alert need urlLocale
function Alert(props: AlertProps) {
  const {
    isAlertOpen, message, redirectionUrl, alertType, urlLocale, dispatch,
  } = props;
  return (
    <Modal
      aria-labelledby="modal-label"
      style={modalStyle}
      backdropStyle={backdropStyle}
      show={isAlertOpen}
    >
      <div className="alert-popup">
        <div className="alert-popup__message">
          {message}
        </div>
        <div className="alert-popup__footer">
          {(alertType === 0 && (
            <Link
              href={{ pathname: `${redirectionUrl || '/'}` }}
              as={`${urlLocale}${redirectionUrl || ''}`}
            >
              <button type="button" className="button btn-theme-primary button--sm">
                <FormattedMessage {...defaultMessages.buttonText} />
              </button>
            </Link>
          ))
            || (alertType === 1 && (
              <Link
                href={{ pathname: `${redirectionUrl || '/'}` }}
                as={`${urlLocale}${redirectionUrl || ''}`}
              >
                <button type="button" className="button button--warning button--sm">
                  <FormattedMessage {...defaultMessages.buttonText} />
                </button>
              </Link>
            ))
            || (alertType === 2 && (
              <Link
                href={{ pathname: `${redirectionUrl || '/'}` }}
                as={`${urlLocale}${redirectionUrl || ''}`}
              >
                <button
                  type="button"
                  className="button button--bordered btn-theme-primary-outline button--sm"
                >
                  <FormattedMessage {...defaultMessages.buttonText} />
                </button>
              </Link>
            ))
            || (alertType === 3 && (
              <button
                type="button"
                className="button btn-theme-primary button--sm"
                onClick={(e) => {
                  e.stopPropagation();
                  dispatch(closePopup());
                }}
              >
                <FormattedMessage {...defaultMessages.buttonText} />
              </button>
            ))}
        </div>
      </div>
    </Modal>
  );
}

const mapStateToProps = state => ({
  isAlertOpen: getIsShow(state),
  message: getFormattedMessages(state),
  redirectionUrl: getUrl(state),
  alertType: getAlertType(state),
});

const injection: GenericComponent<AlertProps> = ComponentBase;

export default injection(Alert, { hasIntl: false, mapStateToProps });
