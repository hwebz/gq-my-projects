// @flow
import { type ComponentType } from 'react';

export type AlertProps = {
  isAlertOpen: boolean,
  message: string | ComponentType<*>,
  redirectionUrl: string,
  alertType: number, // Will use enum
  urlLocale: string,
};
