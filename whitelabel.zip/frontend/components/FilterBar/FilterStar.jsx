import React from 'react';
import { FormattedMessage } from 'react-intl';
import './FilterStar.scss';
// $FlowIgnore
import { MdStar as IconStar } from 'react-icons/md';

// @flow
import { type FilterStarProps, type FilterStarState } from './types';

class FilterStar extends React.Component<FilterStarProps, FilterStarState> {
  constructor(props: FilterStarProps) {
    super(props);
    this.state = {
      hoveredStar: -1,
    };
  }

  handleHoverStars = (e, value: number): Function => {
    e.stopPropagation();
    this.setState({
      hoveredStar: value,
    });
  };

  handleChangeStars = (e, value: number): Function => {
    e.stopPropagation();
    const { handleChangeFilter, filterOption } = this.props;
    const { stars } = filterOption;

    const isAdding = e.target.checked;

    const starArray = stars;

    if (isAdding) {
      starArray.push(value);
    } else {
      const index = stars.indexOf(value);
      // if (!selectedAirports.arrival || selectedAirports.arrival.length <= 1) {
      //   e.preventDefault();
      //   return;
      // }
      if (index !== -1) {
        starArray.splice(index, 1);
      }
    }
    this.setState({
      hoveredStar: -1,
    });
    handleChangeFilter({ key: 'stars', value: starArray });
  }

  render() {
    const { filterOption } = this.props;
    const { hoveredStar } = this.state;
    return (
      <div className="filter-star">
        <div className="filter-star__wrap">
          {/* <StarRatingComponent
              name="rating"
              value={ratingValue}
              starColor="#f2c94c"
              emptyStarColor="#dcdcdc"
              onStarClick={this.changeRating}
              onStarHover={this.onHover}
              onStarHoverOut={this.onHoverOut}
              editing={!(filterOption && isDisabled)}
              renderStarIcon={() => <IconStar />}
              renderStarIconHalf={() => <IconStarHalf className="star" />}
            />
          </div>
          <div className="filter-star__status">
            <FormattedMessage
              id="FilterStar.andUp"
              defaultMessage="& up"
            /> */}

          <label
            htmlFor="1"
            className={`filter-star__item ${filterOption && (filterOption.stars.indexOf(1) !== -1 || hoveredStar === 1) ? 'filter-star__item--active' : ''}`}
            onMouseEnter={e => this.handleHoverStars(e, 1)}
            onMouseLeave={e => this.handleHoverStars(e, -1)}
          >
            <input
              type="checkbox"
              className="filter-star__check"
              id="1"
              onChange={e => this.handleChangeStars(e, 1)}
            />
            <FormattedMessage
              id="FilterStar.one"
              defaultMessage="1"
            />
            <i className="star"><IconStar /></i>
          </label>
          <label
            htmlFor="2"
            className={`filter-star__item ${filterOption && (filterOption.stars.indexOf(2) !== -1 || hoveredStar === 2) ? 'filter-star__item--active' : ''}`}
            onMouseEnter={e => this.handleHoverStars(e, 2)}
            onMouseLeave={e => this.handleHoverStars(e, -1)}
          >
            <input
              type="checkbox"
              className="filter-star__check"
              id="2"
              onChange={e => this.handleChangeStars(e, 2)}
            />
            <FormattedMessage
              id="FilterStar.two"
              defaultMessage="2"
            />
            <i className="star"><IconStar /></i>
          </label>
          <label
            htmlFor="3"
            className={`filter-star__item ${filterOption && (filterOption.stars.indexOf(3) !== -1 || hoveredStar === 3) ? 'filter-star__item--active' : ''}`}
            onMouseEnter={e => this.handleHoverStars(e, 3)}
            onMouseLeave={e => this.handleHoverStars(e, -1)}
          >
            <input
              type="checkbox"
              className="filter-star__check"
              id="3"
              onChange={e => this.handleChangeStars(e, 3)}
            />
            <FormattedMessage
              id="FilterStar.three"
              defaultMessage="3"
            />
            <i className="star"><IconStar /></i>
          </label>
          <label
            htmlFor="4"
            className={`filter-star__item ${filterOption && (filterOption.stars.indexOf(4) !== -1 || hoveredStar === 4) ? 'filter-star__item--active' : ''}`}
            onMouseEnter={e => this.handleHoverStars(e, 4)}
            onMouseLeave={e => this.handleHoverStars(e, -1)}
          >
            <input
              type="checkbox"
              className="filter-star__check"
              id="4"
              onChange={e => this.handleChangeStars(e, 4)}
            />
            <FormattedMessage
              id="FilterStar.four"
              defaultMessage="4"
            />
            <i className="star"><IconStar /></i>
          </label>
          <label
            htmlFor="5"
            className={`filter-star__item ${filterOption && (filterOption.stars.indexOf(5) !== -1 || hoveredStar === 5) ? 'filter-star__item--active' : ''}`}
            onMouseEnter={e => this.handleHoverStars(e, 5)}
            onMouseLeave={e => this.handleHoverStars(e, -1)}
          >
            <input
              type="checkbox"
              className="filter-star__check"
              id="5"
              onChange={e => this.handleChangeStars(e, 5)}
            />
            <FormattedMessage
              id="FilterStar.five"
              defaultMessage="5"
            />
            <i className="star"><IconStar /></i>
          </label>
        </div>
      </div>
    );
  }
}
export default FilterStar;
