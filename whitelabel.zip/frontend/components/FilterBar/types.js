// @flow
import {
  type HotelFilterOption,
  type HandleChangeFilterFunction,
  type StandardEventFunction,
  type PriceValue,
} from '../../flow-types';


export type FilterBarProps = {
  cultureCode: string,
  currency: string,
  isDisabled: boolean,
  openMobileItemClass: string,
  openDropdownClass: string,
  maxPrice: number,
  filterOption: HotelFilterOption,
  handlePriceRangeChange: (
    currentValue: PriceValue,
    value: PriceValue,
  ) => void,
  handleOpenDropdown: (
    e: SyntheticEvent<HTMLDivElement>,
    styleClass: string,
    isDisabled?: boolean,
  ) => void,
  handleChangeFilter: HandleChangeFilterFunction,
  handleInputRangeOnChange: (value: number) => void,
  handleOpenMobileItem: StandardEventFunction,
  handleResetFilter: () => void,
};

export type FilterSearchProps = {
  isDisabled: boolean,
  handleChangeFilter: HandleChangeFilterFunction,
};

export type FilterRatingProps = {
  filterOption: HotelFilterOption,
};

export type FilterStarProps = {
  isDisabled: boolean,
  filterOption: HotelFilterOption,
  handleChangeFilter: HandleChangeFilterFunction,
};

export type FilterStarState = {
  hoverStars: number,
};
