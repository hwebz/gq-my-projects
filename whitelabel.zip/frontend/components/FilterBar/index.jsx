import React from 'react';
import { FormattedMessage } from 'react-intl';
// $FlowIgnore
import { MdArrowBack as IconArrowLeft } from 'react-icons/md';
import InputRange from 'react-input-range';

// @flow
import { getCurrencyText, getCurrencySymbol, shortenLargePrice } from 'react-next/intl/currency-symbols';
import { type PriceValue } from 'flow-types';
import { type FilterBarProps } from './types';

import ComponentBase, { type GenericComponent } from '../ComponentBase';
// import FilterPrice from './FilterPrice';
import FilterStar from './FilterStar';
import FilterRating from './FilterRating';
import FilterSearch from './FilterSearch';
import Backdrop from '../Common/Backdrop';
import './FilterBar.scss';
import ValidationUtils from '../../react-next/utils/validation-utils';


function FilterBar({
  cultureCode,
  currency,
  isDisabled,
  isPolling,
  openDropdownClass,
  maxPrice,
  filterOption,
  handleOpenDropdown,
  handleChangeFilter,
  handlePriceRangeChange,
  handleInputRangeOnChange,
  handleOpenMobileItem,
  openMobileItemClass,
  hotelFilterConfig,
}: FilterBarProps) {
  const rating: number = filterOption ? filterOption.minReview : 0;
  const disableClass: string = isDisabled ? 'disable-filters' : '';
  const currentValue: PriceValue = {
    min: 0,
    max: maxPrice || 0,
  };
  if (filterOption
    && !ValidationUtils.isEmptyOrZero(filterOption.minPrice)) {
    currentValue.min = filterOption.minPrice;
  }
  if (filterOption
    && !ValidationUtils.isEmptyOrZero(filterOption.maxPrice)) {
    currentValue.max = filterOption.maxPrice;
  }
  const hasConfigFilter = hotelFilterConfig && hotelFilterConfig.maxPricePackage > 0
    && hotelFilterConfig.maxPricePerson > 0;

  // Check if filters are active
  // const isFiltersActive = filterOption
  //   && (
  //     !ValidationUtils.isEmptyOrZero(filterOption.minPrice)
  //     || !( // Check if maxPrice is 0 or default maxPrice
  //       ValidationUtils.isEmptyOrZero(filterOption.maxPrice)
  //       || (Math.round(filterOption.maxPrice) >= Math.round(maxPrice))
  //     )
  //     || !ValidationUtils.isEmptyOrZero(filterOption.minReview)
  //     || !ValidationUtils.isEmptyOrZero(filterOption.name)
  //     || !ValidationUtils.isEmptyOrZero(filterOption.stars)
  //   );

  return (
    <div
      className={`filter-bar panel-mobile filter-bar--main ${
        openMobileItemClass === 'navbar-filter' ? 'is-open' : ''
      }`}
    >
      <div
        className="panel-mobile__title"
        onClick={(e: SyntheticEvent<HTMLDivElement>) => {
          handleOpenMobileItem(e, '');
        }}
        role="presentation"
      >
        <i>
          <IconArrowLeft />
        </i>
        <strong>
          <FormattedMessage id="FilterBar.filter" defaultMessage="Filter" />
        </strong>
      </div>
      <div className="panel-mobile__content container">
        <div className="filter-bar__container">
          <div className="filter-bar__title">
            <span>
              <FormattedMessage id="FilterBar.filter" defaultMessage="Filter" />
            </span>
          </div>
          <div className="filter-bar__wrap filter-bar__wrap--filter">
            <div className={`${(!hasConfigFilter || isPolling) ? 'disable-filters' : ''} ${disableClass} filter-bar__box filter-bar__box--price`}>
              <div className="filter-bar__name">
                <span className="filter-bar__name__title">
                  <FormattedMessage id="FilterBar.price" defaultMessage="Price" />
                  {' '}
                  { currency && (
                    <FormattedMessage
                      id="FilterBar.in"
                      defaultMessage={'(in {currency})'}
                      values={{ currency: getCurrencySymbol(currency) }}
                    />
                  )}
                </span>
              </div>
              <div className="filter-bar__content">
                <InputRange
                  formatLabel={(
                    value: number,
                  ) => getCurrencyText(cultureCode, currency, Math.round(value))}
                  maxValue={maxPrice || 10}
                  minValue={0}
                  value={currentValue}
                  disabled={!(filterOption && !isPolling && hasConfigFilter)}
                  onChange={(value: PriceValue) => {
                    handlePriceRangeChange(value, currentValue);
                  }}
                  onChangeComplete={(value: number) => {
                    handleInputRangeOnChange(value);
                  }}
                />
              </div>
              <div className="filter-bar__price">
                <span className="filter-bar__price-range filter-bar__min_price">
                  { shortenLargePrice(Math.round(currentValue.min)) }
                </span>
                <span className="filter-bar__price-range filter-bar__max_price">
                  {
                    shortenLargePrice(Math.round(currentValue.max))
                    || shortenLargePrice(Math.round(maxPrice || 10))
                  }
                </span>
              </div>
            </div>
            <div className={`${disableClass} filter-bar__box filter-bar__box--star`}>
              <div className="filter-bar__name">
                <span>
                  <FormattedMessage id="FilterBar.stars" defaultMessage="Stars" />
                </span>
              </div>
              <div className="filter-bar__content">
                <FilterStar
                  isDisabled={isDisabled}
                  filterOption={filterOption}
                  handleChangeFilter={handleChangeFilter}
                />
              </div>
            </div>
            <div
              className={`${disableClass} filter-bar__box filter-bar__box--rating`}
              onClick={(e: SyntheticEvent<HTMLDivElement>) => {
                handleOpenDropdown(e, 'is-open', isDisabled);
              }}
              role="presentation"
            >
              <div className="filter-bar__name">
                <span>
                  <FormattedMessage id="FilterBar.user_rating" defaultMessage="User Rating" />
                </span>
              </div>
              <div className="filter-bar__content">
                <FilterRating isDisabled={isDisabled} filterOption={filterOption} />
                <div className={`filter-bar__dropdown ${openDropdownClass}`}>
                  <div className="filter-bar__list">
                    <div
                      className={`filter-bar__list__item  ${
                        rating === 86 ? 'filter-bar__list__item--current' : ''
                      }`}
                      onClick={() => {
                        handleChangeFilter({ key: 'minReview', value: 86 });
                      }}
                      role="presentation"
                    >
                      <label>
                        <FormattedMessage id="FilterBar.more_than_8.6" defaultMessage="8.6+" />
                      </label>
                      <FormattedMessage id="FilterBar.excellent" defaultMessage="Excellent" />
                    </div>
                    <div
                      className={`filter-bar__list__item  ${
                        rating === 80 ? 'filter-bar__list__item--current' : ''
                      }`}
                      onClick={() => {
                        handleChangeFilter({ key: 'minReview', value: 80 });
                      }}
                      role="presentation"
                    >
                      <label>
                        <FormattedMessage id="FilterBar.more_than_8.0" defaultMessage="8.0+" />
                      </label>
                      <FormattedMessage id="FilterBar.veryGood" defaultMessage="Very Good" />
                    </div>
                    <div
                      className={`filter-bar__list__item  ${
                        rating === 75 ? 'filter-bar__list__item--current' : ''
                      }`}
                      onClick={() => {
                        handleChangeFilter({ key: 'minReview', value: 75 });
                      }}
                      role="presentation"
                    >
                      <label>
                        <FormattedMessage id="FilterBar.more_than_7.5" defaultMessage="7.5+" />
                      </label>
                      <FormattedMessage id="FilterBar.good" defaultMessage="Good" />
                    </div>
                    <div
                      className={`filter-bar__list__item  ${
                        rating === 68 ? 'filter-bar__list__item--current' : ''
                      }`}
                      onClick={() => {
                        handleChangeFilter({ key: 'minReview', value: 68 });
                      }}
                      role="presentation"
                    >
                      <label>
                        <FormattedMessage id="FilterBar.more_than_6.8" defaultMessage="6.8+" />
                      </label>
                      <FormattedMessage id="FilterBar.fair" defaultMessage="Fair" />
                    </div>
                    <div
                      className={`filter-bar__list__item  ${
                        rating === 0 ? 'filter-bar__list__item--current' : ''
                      }`}
                      onClick={() => {
                        handleChangeFilter({ key: 'minReview', value: 0 });
                      }}
                      role="presentation"
                    >
                      <FormattedMessage id="FilterBar.showAll" defaultMessage="Show All" />
                    </div>
                  </div>
                </div>
                <Backdrop
                  isOpen={openDropdownClass || false}
                  onClick={(e: SyntheticEvent<HTMLDivElement>) => {
                    handleOpenDropdown(e, '');
                  }}
                />
              </div>
            </div>
            <div className={`${disableClass} filter-bar__box filter-bar__box--search`}>
              <div className="filter-bar__content">
                <FilterSearch
                  isDisabled={isDisabled}
                  filterOption={filterOption}
                  handleChangeFilter={handleChangeFilter}
                />
              </div>
            </div>
            {/* <div className={`${disableClass} filter-bar__box filter-bar__box--reset`}>
              <div className="filter-bar__content">
                <button
                  onClick={() => { handleResetFilter(); }}
                  type="button"
                  className={`btn btn-primary btn-theme-primary-outline btn-uppercase ${
                    openMobileItemClass === 'navbar-filter' ? 'btn-block' : ''
                  } ${isFiltersActive ? '' : 'btn-disabled'}`}
                  disabled={`${!isFiltersActive || isDisabled ? 'disabled' : ''}`}
                >
                  <FormattedMessage id="FilterBar.reset" defaultMessage="Reset" />
                </button>
              </div>
            </div> */}
          </div>
        </div>
      </div>
    </div>
  );
}

const injection: GenericComponent<FilterBarProps> = ComponentBase;

export default injection(FilterBar, {
  hasCultureCode: true,
});
