import React from 'react';
import { FormattedMessage } from 'react-intl';
import { IoAndroidArrowDropdown as IconArrowDown } from 'react-icons/io';

// @flow
import './FilterRating.scss';
import { type FilterRatingProps } from './types';

const FilterRating: Function = ({ filterOption }: FilterRatingProps) => {
  const rating: number = filterOption ? filterOption.minReview : 0;
  return (
    <div className="filter-rating">
      <div className="filter-rating__selected">
        <div className="filter-rating__item">
          <div className="review-rating">
            <div className="review-rating__detail">
              {(
                rating > 0 && (
                  <FormattedMessage
                    id="FilterRating.rating"
                    defaultMessage="{rating}+"
                    values={{ rating: parseFloat(rating / 10).toFixed(1) }}
                  />
                ))
                || (
                  <FormattedMessage
                    id="FilterRating.all"
                    defaultMessage="All"
                  />
                )
              }
            </div>
          </div>
        </div>
        <div className="filter-rating__caret">
          <i>
            <IconArrowDown />
          </i>
        </div>
      </div>
    </div>
  );
};

export default FilterRating;
