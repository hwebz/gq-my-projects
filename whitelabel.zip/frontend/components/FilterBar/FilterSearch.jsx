import React from 'react';
import { IoIosSearch as IconSearch } from 'react-icons/io';
import ValidationUtils from '../../react-next/utils/validation-utils';
import './FilterSearch.scss';

// @flow
import { type FilterSearchProps } from './types';

class FilterSearch extends React.Component<FilterSearchProps> {
  constructor(props) {
    super(props);

    this.timer = null;
    this.handleOnChange = this.handleOnChange.bind(this);
  }

  handleOnChange(e) {
    const { target: { value } } = e;
    const { handleChangeFilter } = this.props;
    if (this.timer) {
      clearTimeout(this.timer);
    }

    this.timer = setTimeout(() => handleChangeFilter({ key: 'name', value }), 300);
  }

  resetInput(filterOption) {
    if (this.inputRef && filterOption && ValidationUtils.isEmptyOrZero(filterOption.name)) {
      this.inputRef.value = '';
    }
  }

  render() {
    const { isDisabled, filterOption } = this.props;
    this.resetInput(filterOption);
    const disableClass = isDisabled ? 'disable-filters' : '';
    return (
      <div className="filter-search">
        <input
          type="text"
          className={`${disableClass} filter-search__input`}
          onChange={this.handleOnChange}
          placeholder="Search by Hotel name"
          disabled={`${isDisabled ? 'disabled' : ''}`}
          ref={(node) => { this.inputRef = node; }}
        />
        <button type="button" className={`${disableClass} filter-search__button`}>
          <i>
            <IconSearch size={16} />
          </i>
        </button>
      </div>
    );
  }
}

export default FilterSearch;
