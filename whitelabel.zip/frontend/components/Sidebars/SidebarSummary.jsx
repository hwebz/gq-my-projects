import React from 'react';
import { IoAndroidAlert as IconAlert } from 'react-icons/io';
// @flow
import { FormattedMessage, defineMessages } from 'react-intl';
import { type PriceSummary } from '../../flow-types';
import SidebarSummaryItem from './SidebarSummaryItem';
import './SidebarSummary.scss';
import NumberFormat from '../NumberFormat';
import ComponentBase, { type GenericComponent } from '../ComponentBase';
import InitialLoadingStyle from '../../utils/initialLoading';

type SidebarSummaryProps = {
  canAddTransfer: boolean,
  summary: PriceSummary,
  cultureCode: string,
  isSummary: boolean,
  handleContinue: Function,
  scrollToTransfers: Function,
};

const defaultMessages = defineMessages({
  adult: {
    id: 'SidebarSummary.adult',
    defaultMessage: '{counts, plural, one {# Adult} other {# Adults}}',
  },
  child: {
    id: 'SidebarSummary.child',
    defaultMessage: '{counts, plural, one {# Child} other {# Children}}',
  },
  infant: {
    id: 'SidebarSummary.infant',
    defaultMessage: '{counts, plural, one {# Infant} other {# Infants}}',
  },
  taxesFees: {
    id: 'SidebarSummary.taxesFees',
    defaultMessage: 'Taxes & Fees',
  },
});

const isShow = (element: number) => element != null && element > 0;

const SidebarSummary = ({
  canAddTransfer,
  summary,
  cultureCode,
  isSummary,
  handleContinue,
  scrollToTransfers,
}: SidebarSummaryProps) => {
  const {
    currency, addons, savings, taxesFees, total, paxCounts,
  } = summary;
  // const loadingStyles: LoadingStyles = !initialLoadingStyles
  //   || Object.keys(initialLoadingStyles).length === 0
  //   ? InitialLoadingStyle(!summary || isUpdating)
  //   : initialLoadingStyles;
  let loadingStyles = InitialLoadingStyle(true);
  if (paxCounts) {
    loadingStyles = InitialLoadingStyle(false);
  }
  const { btnDisabled, loadingState, textLoading } = loadingStyles;
  return (
    <div className="sidebar-summary">
      <div className="sidebar-summary__box">
        <div className="sidebar-summary__title">
          <h3 className="title">
            <FormattedMessage
              id="sidebarSummary.hotelsFlightsTitle"
              defaultMessage="Hotels + Flights"
            />
          </h3>
        </div>
        <div className="sidebar-summary__content">
          <div className="sidebar-summary__table">
            { paxCounts && (
              Object.keys(paxCounts).map((item) => {
                if (summary[item] && paxCounts[item]) {
                  return (
                    <SidebarSummaryItem
                      price={summary[item]}
                      counts={paxCounts[item]}
                      title={defaultMessages[item]}
                      currency={currency}
                      cultureCode={cultureCode}
                      key={item}
                    />
                  );
                }
                return null;
              })) || (
                <div className={`${textLoading}`}>
                  {'---------------'}
                </div>)
            }
            {isShow(taxesFees) && (
              <SidebarSummaryItem
                price={taxesFees}
                title={defaultMessages.taxesFees}
                currency={currency}
                cultureCode={cultureCode}
              />
            ) || (
              <div className={`${textLoading}`}>
                {'---------------'}
              </div>)
            }
          </div>
        </div>
      </div>
      {(addons && addons.transfer && (
        <div className="sidebar-summary__box">
          <div className={`${textLoading} sidebar-summary__title`}>
            <h3 className="title">
              <FormattedMessage id="sidebarSummary.addOnsTitle" defaultMessage="Add-ons" />
            </h3>
          </div>
          <div className="sidebar-summary__content bgr-gray">
            <div className="sidebar-summary__table">
              <div className="sidebar-summary__table__item">
                <div className="title">
                  <span>
                    <FormattedMessage
                      id="sidebarSummary.airportTransferTitle"
                      defaultMessage="Airport Transfer"
                    />
                  </span>
                  {!isSummary && (
                    <i className="icon icon-right">
                      <IconAlert />
                    </i>
                  )}
                </div>
                <div className="value">
                  <NumberFormat
                    value={`${addons.transfer}`}
                    currency={`${currency}`}
                    locale={`${cultureCode}`}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )) || ((canAddTransfer) && (
        <div className="sidebar-summary__box">
          <button
            onClick={scrollToTransfers}
            className={`btn-theme-secondary-outline sidebar-summary__content sidebar-summary__addOns link-theme-color ${btnDisabled}`}
            type="button"
            disabled={`${loadingState ? 'disabled' : ''}`}
          >
            <div className="sidebar-summary__addOns__text">
              <FormattedMessage id="sidebarSummary.addTransfers" defaultMessage="Add Transfers" />
              <br />
              <small>
                <FormattedMessage
                  id="sidebarSummary.toFromHotel"
                  defaultMessage="To and from your hotel"
                />
              </small>
            </div>
            <div className="sidebar-summary__addOns__icon">
              <svg width="30" height="27" xmlns="http://www.w3.org/2000/svg">
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M16.094 4.92c0-2.57 2.099-4.67 4.699-4.67 2.573 0 4.7 2.07 4.7 4.67s-2.099 4.7-4.7 4.7c-2.6 0-4.7-2.128-4.7-4.7zm5.202.503h1.3a.518.518 0 0 0 .503-.502.518.518 0 0 0-.502-.503h-1.3v-1.3a.518.518 0 0 0-.503-.502.518.518 0 0 0-.502.502v1.3h-1.3a.518.518 0 0 0-.502.503c0 .265.236.502.502.502h1.3v1.3c0 .266.237.502.502.502a.518.518 0 0 0 .502-.502v-1.3zm7.094 6.77s.532.148.68.798c.148.68.325 1.773-1.122 2.158l-.68.059c.945 1.921 1.832 5.232-.947 7.98a2.054 2.054 0 0 1-1.035.681v1.626c0 .621-.502 1.123-1.123 1.123h-1.509a1.122 1.122 0 0 1-1.123-1.123v-1.508H8.407v1.537c0 .62-.502 1.123-1.123 1.123H5.806a1.123 1.123 0 0 1-1.124-1.123v-1.626c-.354-.09-1.035-.621-1.094-.68-2.719-2.808-1.684-6.119-.708-7.981l-.798-.09C.604 14.764.782 13.64.929 12.99c.148-.65.68-.798.68-.798l2.335.236 2.159-5.142c.206-.592.916-1.537 2.364-1.685h6.061c.09.65.265 1.271.502 1.832H8.616c-.546.087-.7.397-.736.468l-.003.006-.03.059L5.69 12.96l18.445.03-.946-2.247a5.692 5.692 0 0 0 1.626-.976l1.152 2.69 2.424-.265zM5.305 17.779a1.62 1.62 0 0 0 1.625 1.626 1.64 1.64 0 0 0 1.626-1.626 1.62 1.62 0 0 0-1.626-1.626 1.62 1.62 0 0 0-1.625 1.626zm15.814 0a1.62 1.62 0 0 0 1.626 1.626c.917 0 1.656-.74 1.626-1.626a1.62 1.62 0 0 0-1.626-1.626 1.62 1.62 0 0 0-1.626 1.626z"
                />
              </svg>
            </div>
          </button>
        </div>
      ))}

      <div className="sidebar-summary__box">
        <div className="sidebar-summary__content sidebar-summary__price">
          <div className="sidebar-summary__table">
            <div className={`${textLoading} sidebar-summary__table__item`}>
              <div className="title">
                <b>
                  <FormattedMessage id="sidebarSummary.totalPrice" defaultMessage="Total Price" />
                </b>
              </div>
              <div className="value">
                <NumberFormat
                  value={`${total}`}
                  currency={`${currency}`}
                  locale={`${cultureCode}`}
                />
              </div>
            </div>
          </div>
        </div>
        {savings > 0 && (
          <div className="sidebar-summary__content sidebar-summary__gift">
            <div className="sidebar-summary__table">
              <div className="sidebar-summary__table__item">
                <div className="title">
                  <i className="icon icon-left">
                    <svg width="12" height="16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M6.464 11.017a.521.521 0 0 1 0 .712.521.521 0 0 1-.712 0 .521.521 0 0 1 0-.712.521.521 0 0 1 .712 0zM3.279 8.993a.521.521 0 0 0-.712 0 .521.521 0 0 0 0 .712.521.521 0 0 0 .712 0 .488.488 0 0 0 0-.712zM7.699 16H1.387A1.383 1.383 0 0 1 0 14.614V5.115c0-.525.225-1.05.6-1.405L3.483.9a1.504 1.504 0 0 1 2.118 0c.187-.094.355-.169.543-.244C7.175.225 8.225 0 9.105 0h.037c1.425.019 1.911.637 2.061 1.011.15.375.262 1.144-.75 2.174A6.827 6.827 0 0 1 8.9 4.328c.112.244.168.506.168.787v9.499A1.355 1.355 0 0 1 7.7 16zm-4.758-5.452c.656 0 1.2-.543 1.2-1.199 0-.655-.544-1.198-1.2-1.198-.655 0-1.198.543-1.198 1.198 0 .655.524 1.2 1.198 1.2zm.225 1.911l3.148-3.803c.113-.131.094-.3-.037-.412-.131-.113-.3-.094-.413.037l-3.147 3.803c-.113.131-.094.3.037.412.131.094.3.075.412-.037zm4.141-1.087c0-.655-.543-1.198-1.199-1.198s-1.199.543-1.199 1.198c0 .656.543 1.199 1.2 1.199.654 0 1.198-.543 1.198-1.199zm.131-7.625c2.061-.843 2.83-1.986 2.698-2.286-.038-.093-.3-.28-.994-.3h-.037c-.712 0-1.63.207-2.51.562-.037.02-.056.02-.094.038l1.162 1.124c-.169.094-.356.168-.562.262a8.754 8.754 0 0 1-1.668.487 1.144 1.144 0 0 0-.917-.468c-.637 0-1.143.506-1.143 1.143s.505 1.143 1.143 1.143c.636 0 1.143-.505 1.143-1.143v-.075a6.051 6.051 0 0 0 1.779-.487z"
                        fill="#fff"
                      />
                    </svg>
                  </i>
                  <span>
                    <FormattedMessage
                      id="sidebarSummary.packageSavings"
                      defaultMessage="Package Savings"
                    />
                  </span>
                </div>
                <div className="value">
                  <NumberFormat
                    value={`${savings}`}
                    currency={`${currency}`}
                    locale={`${cultureCode}`}
                  />
                </div>
              </div>
            </div>
          </div>
        )}
        {isSummary && (
          <div className="sidebar-summary__content sidebar-summary__button-wrapper">
            <button
              type="button"
              className="button btn-lg btn-theme-primary"
              onClick={() => { handleContinue(); }}
            >
              <FormattedMessage
                id="sidebarSummary.proceedToPassenger"
                defaultMessage="Continue"
              />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

const injection: GenericComponent<SidebarSummaryProps> = ComponentBase;

export default injection(SidebarSummary, {
  hasCultureCode: true,
});
