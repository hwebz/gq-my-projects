import React from 'react';
import { FormattedMessage } from 'react-intl';

import { MdChevronRight, MdInfo } from 'react-icons/md';
import { getLogoUrlString } from '../../utils/image-utils';
import InitialLoadingStyle from '../../utils/initialLoading';
import SidebarFlightLegInfo from './SidebarFlightLegInfo';
import './SidebarFlightItem.scss';
// @flow
import type { FlightItem } from '../../flow-types';

const SidebarFlightItem: Function = ({
  flightDetails,
  flightBound,
  toggleLegInfo,
  showLegInfo,
}: FlightItem) => {
  const {
    departure, legDetails,
    arrival, airlineCodes,
  } = flightDetails;
  let loadingStyles = InitialLoadingStyle(true);
  if (flightDetails) {
    loadingStyles = InitialLoadingStyle(false);
  }
  const { loadingState, smRndImg, textLoading } = loadingStyles;
  const showLegInfoClass: string = showLegInfo ? `show-leg-info-${flightBound}` : '';
  return (
    <div className="sidebar-flight-item">
      <div className="sidebar-flight-item__wrapper">
        { loadingState && (
          <div className={`${smRndImg}`} />
        ) || (
          <img
            className="sidebar-flight-item__logo"
            alt="airline logo"
            src={getLogoUrlString(airlineCodes)}
          />
        )}
        <div className="sidebar-flight-item__container">
          <div className="sidebar-flight-item__group">
            <div className={`${textLoading} flight-item`}>
              <strong className="flight-item__loc">
                { departure && (
                  departure.airportCode
                ) || ('----------')}
              </strong>
              <span className="flight-item__hr">
                { departure && (
                  departure.time
                ) || ('----------')}
              </span>
            </div>
            <MdChevronRight className="duration-icon" />
            <div className={`${textLoading} flight-item`}>
              <strong className="flight-item__loc">
                { arrival && (
                  arrival.airportCode
                )}
              </strong>
              <span className="flight-item__hr">
                { arrival && (
                  arrival.time
                ) || ('----------')}
              </span>
            </div>
          </div>
          <div className={`link-theme-color ${textLoading}`}>
            <a
              href="#a"
              className="link"
              onClick={(e) => { toggleLegInfo(e, flightBound); }}
              role="presentation"
            >
              <MdInfo size={16} className="icon show-details" />
              <FormattedMessage
                id="SidebarFlightItem.showDetails"
                defaultMessage="Show Details"
              />
            </a>
            { legDetails && (
              <div>
                <div
                  className={`overlay ${showLegInfoClass}`}
                  onClick={(e) => { toggleLegInfo(e, ''); }}
                  role="presentation"
                />
                <SidebarFlightLegInfo
                  isDetailOpen
                  toggleDetails={false}
                  legDetails={legDetails}
                  isConfirmation={false}
                  cultureCode="en-US"
                  flightBound={flightBound}
                  showLegInfo={showLegInfo}
                />
              </div>
            )}
          </div>
        </div>
      </div>
      <div className="sidebar-flight-item__wrapper additional-flight-info">
        <div className={`${textLoading} additional-flight-info__table`}>
          <div className="additional-flight-info__table__title">
            <span>
              <FormattedMessage
                id="SidebarFlightItem.numOfStops"
                defaultMessage="No. of stops"
              />
            </span>
            {/* TODO get number of stops */}
          </div>
          <div className="additional-flight-info__table__value">
            <span>
              <FormattedMessage
                id="SidebarFlightItem.directFlight"
                defaultMessage="Direct Flight"
              />
            </span>
            {/* TODO must get from api */}
          </div>
        </div>
        <div className={`${textLoading} additional-flight-info__table`}>
          <div className="additional-flight-info__table__title">
            <span>
              <FormattedMessage
                id="SidebarFlightItem.date"
                defaultMessage="Date"
              />
            </span>
          </div>
          <div className="additional-flight-info__table__value">
            <span>
              { departure && (
                departure.date
              ) || ('----------')}
            </span>
          </div>
        </div>
        <div className={`${textLoading} additional-flight-info__table`}>
          <div className="additional-flight-info__table__title">
            <span>
              <FormattedMessage
                id="SidebarFlightItem.class"
                defaultMessage="Class"
              />
            </span>
          </div>
          <div className="additional-flight-info__table__value">
            <span>
              { legDetails && (
                legDetails[0].cabinClassName
              )}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
export default SidebarFlightItem;
