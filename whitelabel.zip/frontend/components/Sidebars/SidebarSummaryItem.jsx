// @flow
import React from 'react';
import { FormattedMessage } from 'react-intl';
import { type Message } from 'react-next/flow-types';
import NumberFormat from '../NumberFormat';
import ComponentBase, { type GenericComponent } from '../ComponentBase';

type SidebarSummaryItemProps = {
  title: Message,
  counts: ?number,
  currency: string,
  price: ?number,
  cultureCode: string,
};

const SidebarSummaryItem = (props: SidebarSummaryItemProps) => {
  const {
    title, counts, currency, price, cultureCode,
  } = props;

  let totalPrice = price;
  if (counts && price) {
    totalPrice = counts * price;
  }
  return (
    <div className="sidebar-summary__table__item">
      <div className="title">
        <span>
          <FormattedMessage
            {...title}
            values={{ counts }}
          />
        </span>
      </div>
      <div className="value">
        <NumberFormat value={`${totalPrice || 0}`} currency={`${currency}`} locale={`${cultureCode}`} />
      </div>
    </div>
  );
};

const injection: GenericComponent<SidebarSummaryItemProps> = ComponentBase;

export default injection(SidebarSummaryItem, {
  hasCultureCode: true,
});
