import React from 'react';
import { FormattedMessage } from 'react-intl';
import { differenceInCalendarDays } from 'date-fns';
import './SidebarHotel.scss';
// @flow
import { type HotelSummary } from '../../flow-types';
import HotelBoardText from '../HotelBoardText';
import InitialLoadingStyle from '../../utils/initialLoading';
import { getPlaceHolderUrl } from '../../utils/image-utils';

const SidebarHotel = ({ hotelSummary }: HotelSummary) => {
  const {
    name,
    image,
    checkin,
    checkout,
    freeCancellation,
    room,
    roomCount,
    boardType,
  } = hotelSummary;
  let loadingStyles = InitialLoadingStyle(true);
  if (hotelSummary) {
    loadingStyles = InitialLoadingStyle(false);
  }
  const { textLoading } = loadingStyles;
  return (
    <div className="sidebar-hotel">
      <div className="sidebar-hotel__picture">
        <img alt={name} src={image || getPlaceHolderUrl('HOTEL')} className={image || 'sidebar-hotel__picture--error'} onError={(e) => { e.target.onerror = null; e.target.src = getPlaceHolderUrl('HOTEL'); }} />
      </div>
      <div className="sidebar-hotel__detail">
        <h2 className={`${textLoading} title`}>
          { name && (name) || ('--------------------------')}
        </h2>
        <ul className="info">
          <li className={`${textLoading}`}>
            <span>
              {room}
            </span>
            <strong>
              <FormattedMessage
                id="SidebarHotel.roomCount"
                defaultMessage="{roomCount, number} {roomCount, plural, one {Room} other {Rooms}}"
                values={{
                  roomCount,
                }}
              />
            </strong>
          </li>
          <li className={`${textLoading}`}>
            <FormattedMessage
              id="SidebarHotel.date"
              defaultMessage="From {checkin} to {checkout}"
              values={{
                checkin,
                checkout,
              }}
            />
            <strong>
              <FormattedMessage
                id="SidebarHotel.hotelNights"
                defaultMessage="{hotelNight, number} {hotelNight, plural, one {Night} other {Nights}}"
                values={{
                  hotelNight: checkin
                    && checkout && differenceInCalendarDays(checkout, checkin),
                }}
              />
            </strong>
          </li>
          <li className={`${textLoading}`}>
            <HotelBoardText boardType={boardType} />
          </li>
          {freeCancellation && (
            <li>
              <b>
                {freeCancellation}
              </b>
            </li>
          )}
        </ul>
      </div>
    </div>
  );
};

export default SidebarHotel;
