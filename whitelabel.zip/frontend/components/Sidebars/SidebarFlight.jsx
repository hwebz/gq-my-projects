import React from 'react';
import { FormattedMessage } from 'react-intl';
import './SidebarFlight.scss';
import SidebarFlightItem from './SidebarFlightItem';

// @flow
import { type SidebarFlightProps } from '../../flow-types';

const SidebarFlight = ({ flightSummary, toggleLegInfo, selectedLegInfo }: SidebarFlightProps) => {
  const { departFlight, returnFlight } = flightSummary;
  return (
    <div className="sidebar-summary">
      <div className="sidebar-summary__box">
        <div className="sidebar-summary__title">
          <h3 className="title">
            <FormattedMessage
              id="SidebarFlight.departureFlight"
              defaultMessage="Departure Flight"
            />
          </h3>
        </div>
        <div className="sidebar-summary__content">
          <SidebarFlightItem flightDetails={departFlight || ''} flightBound="out" toggleLegInfo={toggleLegInfo} showLegInfo={selectedLegInfo === 'out'} />
        </div>
      </div>
      <div className="sidebar-summary__box">
        <div className="sidebar-summary__title">
          <h3 className="title">
            <FormattedMessage
              id="SidebarFlight.returnFlight"
              defaultMessage="Return Flight"
            />
          </h3>
        </div>
        <div className="sidebar-summary__content">
          <SidebarFlightItem flightDetails={returnFlight || ''} flightBound="in" toggleLegInfo={toggleLegInfo} showLegInfo={selectedLegInfo === 'in'} />
        </div>
      </div>
    </div>
  );
};
export default SidebarFlight;
