import React from 'react';

import { formatDateString } from 'react-next/intl/date-locale';
import { FormattedMessage } from 'react-intl';
import FormattedDuration from '../DurationFormat';
import './SidebarFlightLegInfo.scss';

// @flow
import { type FlightLegInfo } from '../../flow-types';

const SidebarFlightLegInfo = (props: FlightLegInfo) => {
  const {
    isDetailOpen, legDetails, isConfirmation, cultureCode, flightBound, showLegInfo,
  } = props;
  const isOpen = isDetailOpen || isConfirmation || false;
  const showLegInfoClass: string = showLegInfo ? `show-leg-info-${flightBound}` : '';
  return (
    isOpen && (
      <div className={`sidebar-flight-leg-info ${showLegInfoClass}`}>
        <div className="sidebar-flight-leg-info__title">
          { flightBound === 'out' && (
            <FormattedMessage
              id="SidebarFlightLegInfo.departureFlight"
              defaultMessage="Departure Flight"
            />)
            || (
              <FormattedMessage
                id="SidebarFlightLegInfo.returnFlight"
                defaultMessage="Return Flight"
              />
            )}
        </div>
        <div className="sidebar-flight-leg-info__container">
          {legDetails.map((legDetail, index) => (
            <div key={`leg_${legDetail.arrival.time}`}>
              <div className="sidebar-flight-leg-info__wrapper">
                <div className="sidebar-flight-leg-info__box flight-details">
                  <div className="flight-timeline">
                    <span className="flight-timeline__time flight-timeline__time--departure">
                      {legDetail.departure.time}
                    </span>
                    <small className="flight-timeline__duration">
                      <FormattedDuration minutes={legDetail.duration} />
                    </small>
                    <span className="flight-timeline__time arrival">
                      {legDetail.arrival.time}
                    </span>
                  </div>
                  <div className="flight-route">
                    <div className="flight-route__info">
                      <strong>
                        {legDetail.departure.airportCode}
                      </strong>
                      <div>
                        {legDetail.departure.airportName}
                        <label className="flight-date">
                          {formatDateString(legDetail.departure.date, 'MEDIUM', cultureCode)}
                        </label>
                      </div>
                    </div>
                    <div className="flight-route__info">
                      <strong>
                        {legDetail.arrival.airportCode}
                      </strong>
                      <div>
                        {legDetail.arrival.airportName}
                        <label className="flight-date">
                          {formatDateString(legDetail.arrival.date, 'MEDIUM', cultureCode)}
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="sidebar-flight-leg-info__box additional-details">
                  <div className="additional-details__container">
                    { legDetail.aircraftModel && (
                      <div className="additional-details__group">
                        <span className="additional-details__label">
                          <FormattedMessage id="SidebarFlightLegInfoLegInfo.flight" defaultMessage="Flight" />
                        </span>
                        <div>
                          {legDetail.aircraftModel}
                        </div>
                      </div>
                    )}
                    <div className="additional-details__group">
                      <span className="additional-details__label">
                        <FormattedMessage
                          id="SidebarFlightLegInfoLegInfo.cabinClass"
                          defaultMessage="Cabin Class"
                        />
                      </span>
                      {legDetail.cabinClassName}
                    </div>
                    { legDetail.baggageWeight > 0 && (
                      <div className="additional-details__group">
                        <span className="additional-details__label">
                          <FormattedMessage
                            id="SidebarFlightLegInfoLegInfo.baggage"
                            defaultMessage="Baggage"
                          />
                        </span>
                        {`${legDetail.baggageWeight}kg`}
                      </div>
                    )}
                  </div>
                </div>
                {/* {legDetail.transitDuration > 0 && (
                  <div className="flight-transit">
                    <div className="flight-timeline">
                      <small className="flight-timeline__duration">
                        <FormattedDuration minutes={legDetail.transitDuration} />
                      </small>
                    </div>
                  </div>
                )} */}
              </div>
              { (legDetails.length > 1 && index === 0) && (
                <div className="sidebar-flight-leg-info__connecting-flight">
                  <label>
                    <FormattedMessage
                      id="SidebarFlightLegInfo.transitDuration"
                      defaultMessage="Transit duration"
                    />
                    &nbsp;&nbsp;
                    <FormattedDuration minutes={legDetail.transitDuration} />
                  </label>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    )
  );
};

export default SidebarFlightLegInfo;
