import React from 'react';
import Link from 'next/link';
import { differenceInDays } from 'date-fns';
import { type HotelSummary } from 'flow-types';
import { FormattedMessage, defineMessages, type IntlShape } from 'react-intl';
import DateFormat from '../DateFormat';
import type { Format } from '../DateFormat';
import HotelBoardText from '../HotelBoardText';
import { getImageUrlsString } from '../../utils/image-utils';
import InitialLoadingStyle from '../../utils/initialLoading';
import ComponentBase, { type GenericComponent, type ComponentBaseProps } from '../ComponentBase';
import './HotelDetailSummary.scss';

const track = require('../../react-next/utils/track-utils');

// @flow
type HotelDetailSummaryProps = ComponentBaseProps & {
  summary: HotelSummary,
  roomCount: number,
  isConfirmation: boolean,
  cultureCode: string,
  isFetching: boolean,
  urlLocale: string,
  intl: IntlShape,
};

const defaultMessages = defineMessages({
  changeRoom: {
    id: 'hotelDetailSummary.changeRoom',
    defaultMessage: 'Change Room',
  },
});
function handleChangeRoom(SummaryProps) {
  const { router, summary, price } = SummaryProps;
  track.event(
    router.pathname,
    'CHANGE Selected to change room',
    summary.name,
    {
      HotelName: summary.name,
      RoomName: summary.room,
      Price: price.total,
    },
  );
}
function HotelDetailSummary(props: HotelDetailSummaryProps) {
  const {
    summary,
    isConfirmation,
    roomCount,
    cultureCode,
    isFetching,
    intl: { formatMessage },
    urlLocale,
  } = props;
  // To calculate the number of nights
  const { checkin, checkout, changeUrl } = summary;
  const nightCount = differenceInDays(checkout, checkin);
  const isFetchingData = Object.keys(summary).length === 0 && summary.constructor === Object;
  const { textLoading } = InitialLoadingStyle(isFetchingData);
  let packageId;
  let cityCode;
  let indexOfID;
  let hotel;
  if (Object.keys(summary).length > 0 && !isConfirmation) {
    cityCode = changeUrl.substring(7, 10);
    indexOfID = changeUrl.indexOf('?id=');
    hotel = changeUrl.substring(11, indexOfID);
    packageId = changeUrl.substring((indexOfID + 4), changeUrl.length);
  }
  return (
    <div className="card card--with-border hotel-detail-summary">
      <div className="card__body card__body--small-padding hotel-detail-summary__box">
        <div
          className="hotel-detail-summary__picture"
          style={{ backgroundImage: getImageUrlsString(summary.image, 'HOTEL') }}
        />
        <div className="hotel-detail-summary__container">
          <div className={`hotel-detail-summary__name ${textLoading}`}>
            <strong className={textLoading}>
              {summary.name}
            </strong>
          </div>
          <p className={`hotel-detail-summary__item dark-grey ${textLoading}`}>
            {summary.room}
            {roomCount > 1 && (
              <FormattedMessage
                id="hotelDetailSummary.roomCount"
                defaultMessage={'{roomCount, plural, other { # rooms}}'}
                values={{ roomCount }}
              />
            )}
            <br />
            <strong className="green">
              <HotelBoardText boardType={summary.boardType} />
            </strong>
            <br />
            <strong className="light-grey">
              <DateFormat
                value={summary.checkin}
                format={('MEDIUM': Format)}
                locale={`${cultureCode}`}
              />
              {' - '}
              <DateFormat
                value={summary.checkout}
                format={('MEDIUM': Format)}
                locale={`${cultureCode}`}
              />
            </strong>
            <span className="light-grey">
              &nbsp;
              <FormattedMessage
                id="hotelDetailSummary.nightCount"
                defaultMessage={'({count, plural, one {# night} other {# nights}})'}
                values={{ count: nightCount }}
              />
            </span>
          </p>
          {!isConfirmation && (
            !isFetching && (
              <Link
                href={{
                  pathname: '/HotelDetail',
                  query: {
                    cityCode,
                    hotel,
                    id: packageId,
                  },
                }}
                as={`${urlLocale}${summary.changeUrl}`}
              >
                {/* eslint-disable-next-line */}
                <a className={textLoading} onClick={() =>{ handleChangeRoom(props)}} >
                  {formatMessage(defaultMessages.changeRoom)}
                </a>
              </Link>
            )
          )}
        </div>
      </div>
    </div>
  );
}

const injection: GenericComponent<HotelDetailSummaryProps> = ComponentBase;

export default injection(HotelDetailSummary, { hasUrlLocale: true });
