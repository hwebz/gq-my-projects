import React from 'react';
import { connect } from 'react-redux';
// @flow
import { FormattedMessage } from 'react-intl';
import {
  type PriceSummary,
  type SearchQuery,
} from 'flow-types';
import NumberFormat from '../NumberFormat';

import './PackageTotalPriceSummary.scss';
import { getClientFlightFetchStatus } from '../../store-app/modules/flights/selectors';
import InitialLoadingStyle from '../../utils/initialLoading';

type PackageTotalPriceSummaryProps = {
  summary: PriceSummary,
  searchQuery: SearchQuery,
  isFetching: boolean,
};

function PackageTotalPriceSummary(props: PackageTotalPriceSummaryProps) {
  const { summary, searchQuery, isFetching } = props;
  const IsFetchingData = Object.keys(summary).length === 0 && summary.constructor === Object;
  const { textLoading, textBlock } = InitialLoadingStyle(IsFetchingData);
  return (
    <div className={`card card--with-border package-total-price ${!(summary.savings > 0) ? 'no-package-saving' : ''}`}>
      <div className="card__body top-item text-center">
        <h3
          className={`package-total-price__header large-text ${textBlock}`}
        >
          <FormattedMessage
            id="PackageTotalPriceSummary.totalPackagePrice"
            defaultMessage="Total package price"
          />
        </h3>
        <strong
          className={`price theme-primary-text price--1 ${textLoading}`}
        >
          <NumberFormat
            value={summary.total || 0}
            currency={summary.currency}
            withSmall
          />
        </strong>
        <p
          className={`package-total-price-summary__text package-total-price-summary__text--first ${textLoading}`}
        >
          {!!searchQuery.adultCount && (
            <React.Fragment>
              <span>
                <FormattedMessage
                  id="PackageTotalPriceSummary.for"
                  defaultMessage="For "
                />
              </span>
              <strong>
                <FormattedMessage
                  id="PackageTotalPriceSummary.passengers"
                  defaultMessage={
                    '{adultText}{childText}{infantText}'
                  }
                  values={{
                    adultText: searchQuery.adultCount ? (
                      <FormattedMessage
                        id="PackageTotalPriceSummary.adults"
                        defaultMessage={'{count, plural, one {# adult} other {# adults}}'}
                        values={{ count: searchQuery.adultCount }}
                      />
                    ) : '',
                    childText: searchQuery.childCount ? (
                      <FormattedMessage
                        id="PackageTotalPriceSummary.children"
                        defaultMessage={'{count, plural, one {, # child} other {, # children}}'}
                        values={{ count: searchQuery.childCount }}
                      />
                    ) : '',
                    infantText: searchQuery.infantCount ? (
                      <FormattedMessage
                        id="PackageTotalPriceSummary.infants"
                        defaultMessage={'{count, plural, one {, # infant} other {, # infants}}'}
                        values={{ count: searchQuery.infantCount }}
                      />
                    ) : '',
                  }}
                />
              </strong>
            </React.Fragment>
          )}
        </p>
        <p className={`package-total-price-summary__text ${textLoading}`}>
          <FormattedMessage
            id="PackageTotalPriceSummary.taxesFees"
            defaultMessage="includes taxes & fees"
          />
        </p>
      </div>
      {summary.savings > 0 && (
        <div className="card-footer bottom-item">
          <p className="success-color package-total-price-summary__saving">
            {!isFetching && (
              <i className="icon">
                <svg
                  width="19"
                  height="15"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M7.751 9.36c0 .266-.225.49-.503.504a.521.521 0 0 1-.504-.503c0-.265.225-.49.504-.504.265 0 .49.225.503.504zM6.93 5.678a.521.521 0 0 0-.504-.503.521.521 0 0 0-.503.503c0 .265.225.49.503.504a.488.488 0 0 0 .504-.504zm-1.828 8.081L.637 9.294a1.383 1.383 0 0 1 0-1.96L7.354.617A1.97 1.97 0 0 1 8.77.047L12.798.1c.822 0 1.498.675 1.498 1.497.198.066.37.132.556.212 1.033.423 1.934 1.007 2.557 1.63l.026.026c.994 1.02.901 1.801.742 2.172-.158.371-.623.994-2.067 1.007a6.827 6.827 0 0 1-1.908-.291 1.85 1.85 0 0 1-.437.675l-6.717 6.717a1.355 1.355 0 0 1-1.946.013zm.49-7.22a1.207 1.207 0 0 0 1.695 0 1.207 1.207 0 0 0 0-1.695 1.207 1.207 0 0 0-1.695 0 1.195 1.195 0 0 0 0 1.696zm-1.193 1.51l4.916-.463c.172-.013.278-.146.265-.318-.013-.172-.146-.278-.318-.265l-4.915.464c-.173.013-.279.146-.265.318.026.159.16.265.317.265zm3.697 2.16a1.207 1.207 0 0 0 0-1.695 1.207 1.207 0 0 0-1.695 0 1.207 1.207 0 0 0 0 1.695 1.207 1.207 0 0 0 1.695 0zm5.485-5.299c2.053.861 3.405.596 3.523.291.04-.092-.013-.41-.49-.914l-.026-.026c-.504-.504-1.299-1.007-2.173-1.378-.04-.013-.053-.026-.092-.04l.026 1.616c-.185-.052-.37-.132-.583-.212a8.754 8.754 0 0 1-1.523-.834 1.144 1.144 0 0 0-.318-.98 1.136 1.136 0 0 0-1.617 0c-.45.45-.45 1.166 0 1.616.45.45 1.166.451 1.617 0l.053-.052c.437.357.993.674 1.603.913z"
                    fill="#27AE60"
                  />
                </svg>
              </i>
            )}
            <strong
              className={`package-total-price-summary__saving-text ${textLoading}`}
            >
              <FormattedMessage
                id="PackageTotalPriceSummary.savings"
                defaultMessage="Package Savings"
              />
            </strong>
            <strong className={`price--2 ${textLoading}`}>
              <NumberFormat value={summary.savings || 0} currency={summary.currency} />
            </strong>
          </p>
        </div>
      )}
    </div>
  );
}

const mapStateToProps = state => ({
  isFetching: getClientFlightFetchStatus(state),
});

export default connect(mapStateToProps)(PackageTotalPriceSummary);
