// @flow
export type NumberFormatProps = {
  value: string | number, // just in case
  locale: string,
  currency: string,
  isSymbolAfter?: boolean,
  withSmall: boolean, // Wrap symbol inside <small>
  className: string,
};
