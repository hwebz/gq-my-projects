import React from 'react';

// @flow
import { isCurrencySymbolAfter, getCurrencySymbol } from 'react-next/intl/currency-symbols';
import { type NumberFormatProps } from './types';

export default function NumberFormat(props: NumberFormatProps) {
  const {
    value, locale, currency, withSmall, className,
  } = props;
  // const strValue = value.toString(); /* Make sure it's string before using indexOf,
  // because flow doesn't force strong typed where component is used */

  // let decimalLocation = strValue.indexOf('.');
  // // Just in case, not affects the flow
  // if (decimalLocation === -1) {
  //   decimalLocation = strValue.indexOf(',');
  // }
  // const decimalSpace = value.length - decimalLocation - 1;
  // const options = { maximumFractionDigits: 20 };

  const symbol = getCurrencySymbol(currency); // GetCurrencySymbol is falling back symbol to blank
  const isSymbolAfter = isCurrencySymbolAfter(currency);

  const Symbol = () => {
    if (currency) {
      return withSmall ? (
        <small>
          {symbol}
        </small>
      ) : (
        <span>
          {symbol}
        </span>
      );
    }
    return null;
  };
  const numberFormat = new Intl.NumberFormat(locale,
    { minimumFractionDigits: 2 }).format(Math.abs(value));

  return isSymbolAfter ? (
    <span className={className}>
      {`${numberFormat}`}
      <Symbol />
    </span>
  ) : (
    <span className={className}>
      <Symbol />
      {`${numberFormat}`}
    </span>
  );
}
