// @flow
type HandleResetFilter = () => boolean;

export type NoResultsMessages = {
  noFilterResultHeader: string,
  noResultHeader: string,
  noFilterResultSubheader: string,
  noResultSubheader: string,
}

export type NoResultsProps = {
  handleResetFilter?: HandleResetFilter,
  isNoFilterResults: boolean,
  messages: NoResultsMessages,
}
