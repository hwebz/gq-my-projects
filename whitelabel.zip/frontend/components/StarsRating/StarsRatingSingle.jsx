import React from 'react';

import { IoAndroidStar as IconStarFull } from 'react-icons/io';
import './StarsRatingSingle.scss';

// @flow
import { type StarsRatingSingleProps } from '../../flow-types';

const StarsRatingSingle = ({ stars, size }: StarsRatingSingleProps) => {
  function getStars() {
    const totalStars = [];
    const roundedStars = Math.round(stars);
    for (let i = 0; i < roundedStars; i++) {
      totalStars.push(
        <i className={`stars-rating__single__item ${size || ''}`} key={i}>
          <IconStarFull />
        </i>,
      );
    }
    return totalStars;
  }
  return (
    <div className="stars-rating__single">
      {getStars()}
    </div>
  );
};
export default StarsRatingSingle;
