// @flow

export type CurrenciesSwitcherProps = {
  selectedCurrency: string,
  selectedLanguage: string,
  currencies: Array<string>,
};

export type CurrencySwitcherState = {
  isCurrencyOpen: boolean,
};
