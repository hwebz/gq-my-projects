import React from 'react';
import { connect } from 'react-redux';

import './CurrenciesSwitcher.scss';


import { FaCaretDown as CaretDown } from 'react-icons/fa';

// @flow
import getCurrencyName from 'react-next/intl/currency-names';
import { getCurrencySymbol } from 'react-next/intl/currency-symbols';

import actionTypes from 'store-app/modules/currency-selection/action-types';
import { getSelectedCurrency } from 'store-app/modules/currency-selection/selectors';
import { getCultureCode } from 'store-app/modules/locale-selection/selectors';

import Backdrop from '../Common/Backdrop';

import { type CurrenciesSwitcherProps, type CurrencySwitcherState } from './types';

export class CurrenciesSwitcherComponent extends React.Component<
  CurrenciesSwitcherProps, CurrencySwitcherState,
> {
  constructor(props: CurrenciesSwitcherProps) {
    super(props);

    this.state = {
      isCurrencyOpen: false,
    };
  }

  state: CurrencySwitcherState;

  triggerCurrencyDropdown = () => {
    const { isCurrencyOpen } = this.state;
    this.setState({
      isCurrencyOpen: !isCurrencyOpen,
    });
  }

  selectCurrency = (currency: string) => {
    const { dispatch } = this.props;
    dispatch({ type: actionTypes.SELECT_CURRENCY, currency });
    this.setState({
      isCurrencyOpen: false,
    });
  }

  props: CurrenciesSwitcherProps;

  render() {
    const { isCurrencyOpen } = this.state;
    const { currencies, selectedCurrency, selectedLanguage } = this.props;
    return (
      <div className={`dropdown-list dropdown-list--currency ${isCurrencyOpen ? 'is-open' : ''}`}>
        <div className="dropdown-list__button">
          <button
            type="button"
            className="link"
            title="Change currency"
            onClick={this.triggerCurrencyDropdown}
          >
            <strong className="link__text">
              {selectedCurrency}
            </strong>
            <CaretDown className="link__fa-icon" />
          </button>
        </div>
        <div className="dropdown-list__popup">
          <ul className="dropdown-list__listing">
            {currencies.map(cr => (
              <li
                className={`dropdown-list__item ${cr === selectedCurrency ? 'is-active' : ''}`}
                key={cr}
                onClick={() => this.selectCurrency(cr)}
                role="presentation"
              >
                <div className="dropdown-list__currency dropdown-list__currency--text">
                  {cr}
                </div>
                <div className="dropdown-list__currency dropdown-list__currency--desc">
                  {getCurrencyName(selectedLanguage, cr)}
                </div>
                <div className="dropdown-list__currency dropdown-list__currency--sign">
                  {getCurrencySymbol(cr)}
                </div>
              </li>
            ))}
          </ul>
        </div>
        <Backdrop isOpen={isCurrencyOpen} onClick={this.triggerCurrencyDropdown} />
      </div>
    );
  }
}

const mapStateToProps = state => ({
  selectedLanguage: getCultureCode(state),
  selectedCurrency: getSelectedCurrency(state),
});

export default connect(mapStateToProps)(CurrenciesSwitcherComponent);
