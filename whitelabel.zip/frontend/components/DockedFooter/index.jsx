import React from 'react';
import { MdArrowBack as IconArrowLeft, MdExpandLess } from 'react-icons/md';

// @flow
import { FormattedMessage } from 'react-intl';
import ComponentBase, { type GenericComponent } from '../ComponentBase';

import NumberFormat from '../NumberFormat';

import './DockedFooter.scss';

import { type DockedFooterProps, type DockedFooterState } from './types';

class DockedFooter extends React.Component<
  DockedFooterProps,
  DockedFooterState
> {
  constructor(props: DockedFooterProps) {
    super(props);

    this.state = {
      isOpen: false,
    };
  }

  state: DockedFooterState;

  onClose = () => {
    this.setState({
      isOpen: false,
    });
  };

  onToggle = () => {
    const { isOpen } = this.state;

    this.setState({
      isOpen: !isOpen,
    });
  };

  props: DockedFooterProps;

  render() {
    const {
      summary, // Will need to be custom prop in future
      MainView,
      isLoading,
      cultureCode,
      isSummary,
      isHotelDetail,
    } = this.props;
    const { isOpen } = this.state;
    const loadingClassName = isLoading ? 'content-placeholder' : '';
    return (
      <div className="docked-footer__container container clear">
        <div
          className="mob-sticky-menu docked-footer"
          role="presentation"
          onClick={this.onToggle}
        >
          <div className="menu two docked-footer__details">
            <p>
              {(isHotelDetail && (
                <strong>
                  <FormattedMessage
                    id="DockedFooter.yourPackage"
                    defaultMessage="Your Package"
                  />
                </strong>
              )) || (
                <strong>
                  <FormattedMessage
                    id="DockedFooter.totalPackagePrice"
                    defaultMessage="Total Package Price"
                  />
                </strong>
              )}
              <sub className="sub">
                <FormattedMessage
                  id="DockedFooter.viewSummary"
                  defaultMessage="Click to view summary"
                />
              </sub>
            </p>
          </div>
          <div className="menu two docked-footer__price">
            {!isHotelDetail && (
              <div>
                <p className="price theme-primary-text">
                  {isSummary && (
                    <strong className={`price--3 ${loadingClassName}`}>
                      <NumberFormat
                        value={summary.total || 0}
                        currency={summary.currency}
                        locale={cultureCode}
                      />
                    </strong>
                  )}
                  <sub className="price__sub">
                    <FormattedMessage
                      id="DockedFooter.includesTaxesFees"
                      defaultMessage="includes taxes & fees"
                    />
                  </sub>
                </p>
              </div>
            )}
            <MdExpandLess size={16} className="icon" />
          </div>
        </div>

        <div className={`panel-mobile ${isOpen ? 'is-open' : ''}`}>
          <div
            className="panel-mobile__title"
            onClick={this.onClose}
            role="presentation"
          >
            <i>
              <IconArrowLeft />
            </i>
            <strong>
              <FormattedMessage
                id="DockedFooter.packageSummary"
                defaultMessage="Package Summary"
              />
            </strong>
          </div>
          <div className="panel-mobile__content">
            <MainView
              summary={summary}
              currency={summary.currency}
              cultureCode={cultureCode}
              isSummary
            />
            <button
              type="button"
              className="button button--close"
              onClick={this.onClose}
            >
              <FormattedMessage
                id="DockedFooter.close"
                defaultMessage="Close"
              />
            </button>
          </div>
        </div>
      </div>
    );
  }
}

const injection: GenericComponent<DockedFooterProps> = ComponentBase;

export default injection(DockedFooter, { hasCultureCode: true });
