// @flow
import { type Node } from 'react';
import { type PriceSummary } from '../../flow-types';

export type DockedFooterProps = {
  MainView: Node,
  summary: PriceSummary,
  currency?: string,
  cultureCode?: string,
  isLoading?: boolean,
  isSummary?: boolean,
  isHotelDetail?: boolean,
};

export type DockedFooterState = {
  isOpen: boolean,
};
