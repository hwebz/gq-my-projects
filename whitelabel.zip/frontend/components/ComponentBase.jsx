/*
* Important: ComponentBase shall be the mediation for all HOCs props injection through options flag
*/

// @flow
// import React from 'react';
import { type ComponentType } from 'react';
import { injectIntl, type InjectIntlOptions, type IntlShape } from 'react-intl';
import { connect } from 'react-redux';
import JsonUtils from 'react-next/utils/json-utils';
import ValidationUtils from 'react-next/utils/validation-utils';
import getCommonState, { type CommonStateOptions } from '../store-app/common-states';
import { type GeneralInfo } from '../flow-types';

export type OptionsObject = CommonStateOptions & {
  mapStateToProps?: (state: Object, props?: Object) => Object,
  intlOption?: InjectIntlOptions,
  hasIntl?: boolean,
};

export type ComponentBaseProps = {
  intl: IntlShape,
  generalConfig: GeneralInfo,
  urlLocale: string,
  cultureCode: string,
  selectedCurrency: string,
}

const defaultComponentOptions: OptionsObject = {
  hasIntl: true,
  hasGeneralConfig: false,
  hasFeaturesConfig: false,
  hasUrlLocale: false,
  hasCultureCode: false,
  hasSelectedCurrency: false,
  mapStateToProps: undefined,
  intlOption: undefined,
};

export type GenericComponent<P> = (
  Component: ComponentType<P>,
  options?: OptionsObject,
) => ComponentType<P>;

function returnIntlComponent<P: {}, Com: ComponentType<P>>(
  Component: Com,
  options?: OptionsObject = defaultComponentOptions,
): ComponentType<P> {
  if (options.hasIntl) {
    return injectIntl(Component);
  }
  return Component;
}

function getOptionsObject(options: OptionsObject): OptionsObject {
  if (options !== defaultComponentOptions) {
    return JsonUtils.overrideValues(defaultComponentOptions, options);
  }
  return options;
}

export default function<P: {}, Com: ComponentType<P>> (
  Component: Com,
  options?: OptionsObject = defaultComponentOptions,
): ComponentType<P> {
  const componentOptions: OptionsObject = getOptionsObject(options);
  const injection: GenericComponent<P> = returnIntlComponent;

  if (
    ValidationUtils.isKeysValueSame(componentOptions, defaultComponentOptions, [
      'hasGeneralConfig',
      'hasFeaturesConfig',
      'hasUrlLocale',
      'hasCultureCode',
      'hasSelectedCurrency',
      'mapStateToProps',
    ])
  ) {
    // Meaning No MapStateToProps required - all common states are not required
    return injection(Component, componentOptions);
  }

  const combinedMapStateToProps: (state: Object) => Object = state => ({
    ...getCommonState(componentOptions)(state),
    ...(componentOptions.mapStateToProps ? componentOptions.mapStateToProps(state) : {}),
  });

  return connect(combinedMapStateToProps)(injection(Component, componentOptions));
}
