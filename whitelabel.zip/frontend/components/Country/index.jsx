import React, { Component } from 'react';
import { defineMessages } from 'react-intl';
import { formatNumber, AsYouType } from 'libphonenumber-js';
import Select from '../FormFields/Select';
import ComponentBase from '../ComponentBase';
// @flow
import { type CountryProps, type CountryState, type FullCountryData } from './types';

import './Country.scss';

const defaultMessages = defineMessages({
  countryPlaceholder: {
    id: 'ContactDetails.countryPlaceholder',
    defaultMessage: 'Select country',
  },
  selectCountry: {
    id: 'ContactDetails.selectCountry',
    defaultMessage: 'Please select the country',
  },
  validPhone: {
    id: 'ContactDetails.validPhone',
    defaultMessage: 'Enter a valid mobile number',
  },
});

class Country extends Component<CountryProps, CountryState> {
  constructor(props: CountryProps) {
    super(props);
    const { value, type, fullCountryData, geolocationCountryCode } = props;
    this.state = {
      selectedDialCode: '',
      mobileNumber: '',
      mobileCountryFlag: '',
      selectedCountry: '',
      geolocationCountryCodeState: geolocationCountryCode || '',
      isFirstLoad: true,
    };
    if (type !== 'with-phonecode' && !value) {
      this.applyGeolocationState(fullCountryData);
    }
  }

  state: CountryState;

  componentWillReceiveProps(nextProps) {
    const {
      fullCountryData,
    } = this.props;
    const { isFirstLoad } = this.state;
    if (isFirstLoad && fullCountryData !== nextProps.fullCountryData) {
      this.applyGeolocationState(nextProps.fullCountryData);
      this.setState({
        isFirstLoad: false,
      });
    }
  }

  applyGeolocationState = (fullCountryData) => {
    // needed fullCOuntryData as the parameter because of componentWillReceiveProps
    const {
      geolocationCountryCode,
      type,
      handleOnChange,
      name,
    } = this.props;

    if (type === 'with-phonecode') {
      const countryInfo = this.getSelectedCountryInfo(
        geolocationCountryCode,
        fullCountryData,
      );
      this.setState({
        mobileCountryFlag: countryInfo.flag,
        selectedDialCode: countryInfo.callingCodes ? countryInfo.callingCodes[0] : '',
        mobileNumber: countryInfo.callingCodes ? countryInfo.callingCodes[0] : '',
      });
    } else {
      handleOnChange(
        {
          target:
          {
            name,
            value: geolocationCountryCode,
          },
        },
        'COUNTRY_DROPDOWN',
      );
    }

    this.setState({
      geolocationCountryCodeState: geolocationCountryCode,
    });
  }

  getCountryListOptions = (): FullCountryData => {
    const { fullCountryData } = this.props;
    // use culture code to get the
    const countries: FullCountryData = [];
    if (fullCountryData) {
      fullCountryData.map(clist => (
        countries.push({ text: clist.name, value: clist.alpha2Code, id: clist.alpha2Code })
      ));
    }
    return countries;
  }

  getPhoneWithCountryListOptions = () => {
    const { fullCountryData } = this.props;
    const countriesWithPhoneCode = [];
    if (fullCountryData) {
      for (let i = 0; i < fullCountryData.length; i++) {
        // clist.alpha2Code !== 'CX' to avoid duplicate key during render
        if (fullCountryData[i].callingCodes[0]) {
          countriesWithPhoneCode.push({
            text: fullCountryData[i].name,
            value: fullCountryData[i].alpha2Code,
            id: fullCountryData[i].alpha2Code,
          });
        }
      }
    }
    return countriesWithPhoneCode;
  }

  // countryCode can be dialing code or actual country code
  getSelectedCountryInfo = (countryCode: string, fullCountryData): FullCountryData | boolean => {
    let countryInfo: ? FullCountryData | {} = {};
    if (fullCountryData) {
      for (let i = 0; i < fullCountryData.length; i++) {
        if (countryCode === fullCountryData[i].alpha2Code) {
          countryInfo = fullCountryData[i];
          return countryInfo;
        }
      }
    }
    return countryInfo;
  }

  handleCountryChange = (
    event: SyntheticEvent<HTMLSelectElement>,
    validationType: string,
  ): void => {
    const { selectedDialCode } = this.state;
    let { value } = this.props;
    const { handleMobileNumberChange, fullCountryData } = this.props;
    const countryInfo = this.getSelectedCountryInfo(
      event.currentTarget.value,
      fullCountryData,
    );
    const dialCode = countryInfo.callingCodes ? countryInfo.callingCodes[0] : '';
    this.setState({
      selectedCountry: event.currentTarget.value,
      mobileCountryFlag: countryInfo.flag,
      selectedDialCode: dialCode,
    });
    // if the input is empty
    if (value === selectedDialCode) {
      handleMobileNumberChange(event.currentTarget.name, dialCode, validationType, event.type);
      this.setState({
        mobileNumber: dialCode,
      });
    } else {
      // if contains phone number append dial code
      const regex: Object = new RegExp(selectedDialCode);
      const phoneNumber: string = value.replace(regex, '').replace(/[^A-Z0-9]/ig, ''); // phoneNumber without dial code
      value = `${dialCode}${phoneNumber}`;
      handleMobileNumberChange(event.currentTarget.name, value, validationType, event.type);
      const formatedPhoneNumber: string = formatNumber({ country: event.currentTarget.value, phone: phoneNumber }, 'International');
      this.setState({
        mobileNumber: formatedPhoneNumber,
      });
    }
  }

  handleMobileInput = (e: SyntheticEvent<HTMLInputElement>, validationType: string): void => {
    const { selectedDialCode } = this.state;
    const { handleMobileNumberChange } = this.props;
    const phoneNumber: string = e.currentTarget.value.replace(/[^A-Z0-9]/ig, '');
    const removeDialCode: Object = new RegExp(selectedDialCode);
    const pnumWithoutDial: string = phoneNumber.replace(removeDialCode, '');
    const getDialCode: Object = new RegExp(pnumWithoutDial);
    const dialCode: string = phoneNumber.replace(getDialCode, '');
    const formatedPhoneNumber: string = new AsYouType().input(`+${dialCode}${pnumWithoutDial}`);
    // dial code is not match with api need to check
    if (pnumWithoutDial) {
      this.setState({
        mobileNumber: formatedPhoneNumber,
      });
      handleMobileNumberChange(e.currentTarget.name, pnumWithoutDial, validationType, e.type);
    } else {
      this.setState({
        mobileNumber: dialCode,
      });
      handleMobileNumberChange(e.currentTarget.name, dialCode, validationType, e.type);
    }
  }

  props: CountryProps;

  render() {
    const {
      handleOnChange,
      value,
      type,
      name,
      intl,
    } = this.props;
    const {
      selectedCountry,
      mobileCountryFlag,
      mobileNumber,
      geolocationCountryCodeState,
    } = this.state;
    const disablePhoneInput = (selectedCountry === '' && geolocationCountryCodeState === '');
    const { formatMessage } = intl;
    return (
      <div>
        {type === 'with-phonecode' && (
          <div className="multi_field">
            <Select
              name={name}
              handleOnChange={this.handleCountryChange}
              placeholder={formatMessage(defaultMessages.countryPlaceholder)}
              type="text"
              value={selectedCountry || geolocationCountryCodeState}
              validationType="COUNTRY_DROPDOWN"
              options={this.getPhoneWithCountryListOptions()}
              fieldType="DROPDOWN"
            />
            <input
              className="form__input__control"
              name={name}
              disabled={disablePhoneInput}
              onBlur={(e: SyntheticEvent<HTMLElement>) => this.handleMobileInput(e, 'NUMBER')}
              onChange={(e: SyntheticEvent<HTMLElement>) => this.handleMobileInput(e, 'NUMBER')}
              placeholder={disablePhoneInput
                ? formatMessage(defaultMessages.selectCountry)
                : formatMessage(defaultMessages.validPhone)
              }
              type="text"
              value={mobileNumber || formatNumber({ country: selectedCountry, phone: value }, 'International')}
              maxLength="16" // according to E.164 recommended 15 + extra chars
            />
            { mobileCountryFlag && (
              <span className="country-flag">
                <img src={mobileCountryFlag} alt="" />
              </span>
            )}
          </div>
        ) || (
          <Select
            name={name}
            handleOnChange={handleOnChange}
            placeholder={formatMessage(defaultMessages.countryPlaceholder)}
            type="text"
            value={value || geolocationCountryCodeState}
            validationType="COUNTRY_DROPDOWN"
            options={this.getCountryListOptions()}
            fieldType="DROPDOWN"
          />
        )}
      </div>
    );
  }
}

const mapStateToProps = state => ({
  fullCountryData: state.country.fullCountryData,
  geolocationCountryCode: state.country.geolocationCountryCode,
  isFetching: state.country.isFetching,
});

export default ComponentBase(Country, {
  hasCultureCode: true,
  mapStateToProps,
});
