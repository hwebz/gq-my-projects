// @flow
import { type Dispatch, type HandleDetailChangeEvents } from '../../flow-types';

export type CountryProps = {
  dispatch: Dispatch,
  handleOnChange: HandleDetailChangeEvents,
  fullCountryData: Object,
  cultureCode: string,
  value: string,
  type: string,
  name: string,
  handleMobileNumberChange: (name: string, phoneNum: string, validationType: string) => void,
};

export type CountryState = {
  selectedCountry: string,
  mobileCountryFlag: string,
  mobileNumber: string,
  selectedDialCode: string,
};

export type FullCountryData = Array<{
  text: string,
  value: string,
  id: string,
}>;

export type CountryMSP = {
  errors: any,
  isFetching: boolean,
  fullCountryData: FullCountryData,
};
