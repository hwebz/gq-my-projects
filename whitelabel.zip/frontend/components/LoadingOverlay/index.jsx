import React from 'react';

// @flow
import { type LoadingOverlayProps } from './types';
import './LoadingOverlay.scss';
import Spinner from '../Common/Spinner';

const LoadingOverlay = (props: LoadingOverlayProps) => {
  const { message } = props;
  return (
    <React.Fragment>
      <div role="presentation" className="loading-overlay__overlay">
        <Spinner className="spinner" />
        <div className="message">{message}</div>
      </div>
    </React.Fragment>
  );
};

export default LoadingOverlay;
