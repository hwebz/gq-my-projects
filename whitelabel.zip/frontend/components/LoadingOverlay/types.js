// @flow
export type LoadingOverlayProps = {
  message: string,
};
