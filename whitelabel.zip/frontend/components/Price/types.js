// @flow
import { type LoadingStyles, type HotelPrice, type Config } from '../../flow-types';

export type HotelDetailPriceProps = {
  initialLoadingStyles: LoadingStyles,
  prices: HotelPrice,
  config: Config,
  cultureCode: string,
  isDisabled: boolean,
  paxCount: number,
  nightCount: number,
  currency: string,
};
