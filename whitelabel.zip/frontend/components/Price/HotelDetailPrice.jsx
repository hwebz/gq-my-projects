import React from 'react';
import './HotelDetailPrice.scss';
import { FormattedMessage } from 'react-intl';
import NumberFormat from 'components/NumberFormat';
import { FaSpinner as IconLoadingSpinner } from 'react-icons/fa';

// @flow
import { type HotelDetailPriceProps } from './types';
import ComponentBase, { type GenericComponent } from '../ComponentBase';

function HotelDetailPrice(props: HotelDetailPriceProps) {
  const {
    initialLoadingStyles,
    prices,
    featuresConfig,
    cultureCode,
    isPolling,
    paxCount,
    nightCount,
    currency,
  } = props;
  const { useTotalPrice } = featuresConfig;
  const { contentLoading, textLoading } = initialLoadingStyles;
  const disableIntraction: string = isPolling ? 'price__disable' : '';
  const oldPrice: number = useTotalPrice
    ? prices.perPackage.originalPrice
    : prices.perPerson.originalPrice;
  const newPrice: number = useTotalPrice
    ? prices.perPackage.price
    : prices.perPerson.price;
  return (
    <div className={`price ${disableIntraction}`}>
      <div className={`${contentLoading}`}>
        <div className="HotelResultPrice">
          {oldPrice > 0
            && oldPrice > newPrice && (
              <div className="price__old">
                <NumberFormat
                  value={`${oldPrice}`}
                  currency={`${currency}`}
                  locale={`${cultureCode}`}
                />
              </div>
          )}
          <div className="price__now theme-primary-text">
            <NumberFormat
              value={`${newPrice}`}
              currency={`${currency}`}
              locale={`${cultureCode}`}
              withSmall
            />
            {isPolling && (
              <i className="infinite-spin">
                <IconLoadingSpinner size={16} />
              </i>
            )}
          </div>
        </div>
      </div>
      <div className="price__note">
        <span className={`${textLoading}`}>
          {(useTotalPrice && (
            <FormattedMessage
              id="hotelDetailPrice.totalPriceForPeople"
              defaultMessage={'total price for {count} people'}
              values={{ count: paxCount }}
            />
          )) || (
            <FormattedMessage
              id="hotelDetailPrice.perPerson"
              defaultMessage={
                'per person for {count, number} {count, plural, one {night} other {nights}}'
              } // TODO pluralize night & no of nights from gethotels api
              values={{ count: nightCount }}
            />
          )}
        </span>
        <span className={`${textLoading}`}>
          <FormattedMessage
            id="hotelDetailPrice.includingTaxesAndFees"
            defaultMessage="including taxes & fees"
          />
        </span>
      </div>
    </div>
  );
}

const injection: GenericComponent<HotelDetailPriceProps> = ComponentBase;

export default injection(HotelDetailPrice, {
  hasIntl: false,
  hasCultureCode: true,
  hasFeaturesConfig: true,
});
