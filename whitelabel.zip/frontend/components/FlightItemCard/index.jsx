import React from 'react';
import { connect } from 'react-redux';
import { differenceInDays } from 'date-fns';
import { MdArrowDropDown, MdCheckCircle } from 'react-icons/md';
import { FaSpinner as IconLoadingSpinner } from 'react-icons/fa';
import { FormattedMessage } from 'react-intl';
import { formatDateString } from 'react-next/intl/date-locale';
import { getLogoUrlString } from '../../utils/image-utils';

import ArrivalNotice from '../Common/ArrivalNotice';
import NumberFormat from '../NumberFormat';
import FormattedDuration from '../DurationFormat';
import FlightLegInfo from './components/FlightLegInfo';
import './FlightResultItem.scss';

// @flow
import { type FlightItemCardProps, type FlightItemCardState } from './types';
import { getUseTotalPrice } from '../../services/sagas/global-selectors';
import Backdrop from '../Common/Backdrop';
import PricePopover from '../PricePopover';

const track = require('../../react-next/utils/track-utils');

class FlightItemCard extends React.Component<FlightItemCardProps, FlightItemCardState> {
  constructor(props: FlightItemCardProps) {
    super(props);
    this.state = {
      isDetailOpen: false,
      isPageChanging: false,
      showPopover: false,
    };
  }

  state: FlightItemCardState;

  // Will be deprecated but not found other solutions yet (including getDerivedStateFromProps)
  componentWillReceiveProps() {
    const { isDetailOpen } = this.state;
    if (isDetailOpen) {
      this.setState({ isDetailOpen: false }); // Close leg Info when fetching data
    }
  }

  // onSelectFlight = (): void => {
  //   e.stopPropagation
  //   const { flightItem, onSelectFlight } = this.props;
  //   onSelectFlight(flightItem);
  // }

  toggleDetail = (e: SyntheticEvent<HTMLElement>) => {
    e.stopPropagation();
    const { isDetailOpen } = this.state;
    const {
      isFetching, router, isReturnFlight, flightItem,
    } = this.props;
    if (!isFetching) {
      this.setState({
        isDetailOpen: !isDetailOpen,
      });
      const flightType = isReturnFlight ? 'return' : 'departure';
      const properties = {
        flightId: flightItem.flightId,
        From: flightItem.departure.airportCode,
        To: flightItem.arrival.airportCode,
      };
      track.event(
        router.pathname,
        `VIEW Viewed ${flightType} flight details and baggage`,
        'value.value',
        {
          ...properties,
        },
      );
    }
  }

  togglePopover = (e: SyntheticEvent<HTMLElement>, status) => {
    e.stopPropagation();
    e.preventDefault();
    this.setState({
      showPopover: status,
    });
  };

  props: FlightItemCardProps;

  render() {
    const {
      flightItem,
      isSelected,
      isSummary,
      toggleDetails,
      isFetching,
      currency,
      isConfirmation,
      cultureCode,
      nightsCount,
      isUseTotalPrice,
      onSelectFlight,
      isReturnFlight,
      popOverInfo,
      hotelSummary,
    } = this.props;
    const { isDetailOpen, isPageChanging, showPopover } = this.state;
    const { legDetails } = flightItem;
    const fetchingClass = isFetching ? 'content-placeholder' : '';
    let newClasses: string = '';
    if (isSummary) {
      newClasses += 'summary ';
    }
    if (isSelected) {
      newClasses += 'selected ';
    }
    if (isDetailOpen || isConfirmation) {
      newClasses += 'detail-open ';
    }
    const itemFetchingClass = isFetching ? 'is-fetching' : '';
    const stopCount: number = legDetails.length - 1;
    const daysDifference: ?number = flightItem
      ? differenceInDays(flightItem.arrival.date, flightItem.departure.date)
      : null;
    const flightLogo = getLogoUrlString(flightItem.airlineCodes);
    const price = isUseTotalPrice
      ? flightItem.price.additionalPerPackage : flightItem.price.additionalPerPerson;
    const sign = price < 0 ? '−' : '+';

    return isFetching || flightItem ? (
      <li className={`flight-result-item ${newClasses || ''} ${itemFetchingClass}`}>
        <Backdrop isOpen={isPageChanging} isTransparent />
        <div
          className="flight-result-item__group"
          onClick={(e) => {
            e.stopPropagation();
            if (!isSummary) {
              this.setState({ isPageChanging: true });
              onSelectFlight(flightItem);
            }
          }}
          role="presentation"
        >
          <div className="flight-result-item__content flight-detail">
            <div className="flight-detail__container">
              <div className="flight-result-item__wrapper">
                <div className={`flight-detail__logo ${fetchingClass}`}>
                  <img
                    className="flight-detail__logo__img"
                    alt="airline logo"
                    src={flightLogo}
                  />
                </div>
                <div className={`flight-detail__time departure-info ${fetchingClass}`}>
                  <strong className="flight-detail__time--loc">
                    {flightItem.departure.airportCode}
                  </strong>
                  <span className="flight-detail__time--hr">
                    {flightItem.departure.time}
                  </span>
                </div>
              </div>
              <div
                className={`flight-result-item__wrapper flight-detail__duration ${fetchingClass}`}
              >
                <small className="flight-detail__duration__line">
                  <FormattedDuration minutes={flightItem.duration} />
                </small>
                <small>
                  <FormattedMessage
                    id="flightItemCard.stopCount"
                    defaultMessage={`{
                      stopCount, plural,
                      =0 {{zero}}
                      one {{stopCount} {one}}
                      other {{stopCount} {other}}
                    }`}
                    values={{
                      stopCount,
                      zero: 'non-stop',
                      one: 'stop',
                      other: 'stops',
                    }}
                  />
                </small>
              </div>
              <div className={`flight-result-item__wrapper arrival-info ${fetchingClass}`}>
                <div className="flight-detail__time  ">
                  <strong className="flight-detail__time--loc">
                    {flightItem.arrival.airportCode}
                  </strong>
                  <span className="flight-detail__time--hr">
                    {flightItem.arrival.time}
                  </span>
                </div>
                {!!daysDifference && (
                <strong className="flight-detail__add-days">
                  {`+${daysDifference}`}
                </strong>
                )}
              </div>
            </div>
            <div
              className={`flight-result-item__note content-placeholder--hidden ${fetchingClass}`}
            >
              <span className="icon icon-error" />
              {!isReturnFlight && !!(nightsCount && nightsCount !== flightItem.hotelNights) && (
                <ArrivalNotice
                  arrivalDate={formatDateString(flightItem.arrival.date, 'SHORT', cultureCode)}
                  hotelNights={flightItem.hotelNights}
                  nightsCount={nightsCount}
                />
              )}
            </div>
          </div>
          {!isConfirmation && (
          <div className="flight-result-item__content flight-buttons">
            <div
              className={`flight-buttons__details link-theme-color content-placeholder--hidden ${fetchingClass}`}
            >
              <span
                className="detail-text"
                onClick={e => this.toggleDetail(e)}
                role="presentation"
              >
                <FormattedMessage
                  id="flightItemCard.detailsBaggage"
                  defaultMessage="Details & Baggage"
                />
                <MdArrowDropDown size={16} className="icon" />
              </span>
            </div>
            {!isSummary
              && !isSelected && (
              <div
                className="flight-result-item__wrapper flight-buttons__price"
                role="presentation"
                onMouseEnter={(e) => { this.togglePopover(e, true); }}
                onMouseLeave={(e) => { this.togglePopover(e, false); }}
              >
                  { showPopover && popOverInfo && (
                    <PricePopover
                      FlightInfo={
                        {
                          origin: popOverInfo.origin,
                          destination: popOverInfo.destination,
                          departDate: popOverInfo.departureDate,
                          returnDate: popOverInfo.returnDate,
                          paxCount: popOverInfo.paxCount,
                        }
                      }
                      RoomInfo={{
                        roomtype: hotelSummary.room,
                        nightsCount: popOverInfo.nightsCount,
                        noOfRoom: popOverInfo.roomCount,
                        boardType: hotelSummary.boardType,
                        freeCancellationBefore: hotelSummary.freeCancellationBefore,
                      }}
                      PriceInfo={{
                        cultureCode,
                        currency,
                        totalRoomPrice: flightItem.price.totalFlightPrice,
                      }}
                      isFlight
                    />
                  )}
                <div className={`theme-primary-text price ${fetchingClass}`}>
                  <strong className="price--2">
                    <span className="price__currency">
                      {sign}
                    </span>
                    <NumberFormat
                      value={price}
                      currency={currency}
                      withSmall
                    />
                    <span className="price__sub">
                      <FormattedMessage
                        id="flightItemCard.pricePerPersonText"
                        defaultMessage="round trip per {priceConfig}"
                        values={{
                          priceConfig: isUseTotalPrice ? (
                            <span>
                              <FormattedMessage
                                id="flightItemCard.package"
                                defaultMessage="package"
                              />
                            </span>
                          ) : (
                            <span>
                              <FormattedMessage
                                id="flightItemCard.person"
                                defaultMessage="person"
                              />
                            </span>
                          ),
                        }}
                      />
                    </span>
                  </strong>
                </div>
                <button
                  type="button"
                  className={`button btn-theme-primary flight-buttons__select-button ${fetchingClass} ${isPageChanging ? 'page-change' : ''}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    this.setState({ isPageChanging: true });
                    onSelectFlight(flightItem);
                  }}
                >
                  <FormattedMessage id="flightItemCard.select" defaultMessage="select" />
                  {isPageChanging && (
                    <i className={`infinite-spin ${isPageChanging ? 'page-change-loader' : ''}`}>
                      <IconLoadingSpinner size={16} />
                    </i>
                  )}
                </button>
              </div>
            )}
            {isSelected && <MdCheckCircle size={40} className="departure-check" />}
          </div>
          )}
        </div>

        <FlightLegInfo
          isDetailOpen={isDetailOpen}
          toggleDetails={toggleDetails}
          legDetails={flightItem.legDetails}
          isConfirmation={isConfirmation}
          cultureCode={cultureCode}
        />
      </li>
    ) : null;
  }
}

const mapStateToProps = state => ({
  isUseTotalPrice: getUseTotalPrice(state),
});

export default connect(mapStateToProps)(FlightItemCard);
