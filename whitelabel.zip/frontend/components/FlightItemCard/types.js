// @flow

import { type FlightItem, type LegItem } from '../../flow-types';


export type FlightItemCardProps = {
  flightItem: FlightItem,
  isSelected: boolean,
  isSummary: boolean,
  toggleDetails: boolean,
  isFetching: boolean,
  onSelectFlight: Function,
  checkin: any,
  checkout: any,
  isUseTotalPrice: boolean,
  currency: string,
  isConfirmation: boolean,
  cultureCode: string,
  nightsCount: number,
  isReturnFlight: boolean,
};

export type FlightItemCardState = {
  isDetailOpen: boolean,
};


export type FlightLegInfoProps = {
  isDetailOpen: boolean,
  legDetails: LegItem[],
  isConfirmation: boolean,
  cultureCode: string,
};
