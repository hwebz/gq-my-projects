import React from 'react';

import { formatDateString } from 'react-next/intl/date-locale';
import { FormattedMessage } from 'react-intl';
import FormattedDuration from '../../DurationFormat';
import './FlightLegInfo.scss';

// @flow
import { type FlightLegInfoProps } from '../types';

const FlightLegInfo = (props: FlightLegInfoProps) => {
  const {
    isDetailOpen, legDetails, isConfirmation, cultureCode,
  } = props;
  const isOpen = isDetailOpen || isConfirmation || false;
  return (
    isOpen && (
      <div className="flight-leg-info">
        {/* <div className="panel-mobile__title">
          <i>
            <IconArrowLeft />
          </i>
          <strong>
            {`Flight Details: ${legDetails[0].departure.airportCode} - ${
              legDetails[legsLength - 1].arrival.airportCode
            }`}
          </strong>
        </div> */}

        {/* <div className="flight-leg-info__title">
          <small>
            {'Total Duration: '}
            <FormattedDuration minutes={legDetails.duration} />
          </small>
        </div> */}

        <div className="flight-leg-info__container">
          {legDetails.map(legDetail => (
            <div className="flight-leg-info__wrapper" key={`leg_${legDetail.arrival.time}`}>
              <div className="flight-leg-info__box flight-details">
                <div className="flight-timeline">
                  <span className="flight-timeline__time flight-timeline__time--departure">
                    {legDetail.departure.time}
                  </span>
                  <small className="flight-timeline__duration">
                    <FormattedDuration minutes={legDetail.duration} />
                  </small>
                  <span className="flight-timeline__time arrival">
                    {legDetail.arrival.time}
                  </span>
                </div>
                <div className="flight-route">
                  <div className="flight-route__info">
                    <strong>
                      {legDetail.departure.airportCode}
                    </strong>
                    <div>
                      {legDetail.departure.airportName}
                      <label className="flight-date">
                        {formatDateString(legDetail.departure.date, 'MEDIUM', cultureCode)}
                      </label>
                    </div>
                  </div>
                  <div className="flight-route__info">
                    <strong>
                      {legDetail.arrival.airportCode}
                    </strong>
                    <div>
                      {legDetail.arrival.airportName}
                      <label className="flight-date">
                        {formatDateString(legDetail.arrival.date, 'MEDIUM', cultureCode)}
                      </label>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flight-leg-info__box additional-details">
                <div className="additional-details__container">
                  {legDetail.airlineName && legDetail.airlineCode && legDetail.flightNumber && (
                    <div className="additional-details__group">
                      <span className="additional-details__label">
                        <FormattedMessage id="FlightLegInfo.flight" defaultMessage="Flight" />
                      </span>
                      <div>
                        {`${legDetail.airlineName} ${legDetail.airlineCode}${legDetail.flightNumber}${legDetail.aircraftModel ? ` (Aircraft: ${legDetail.aircraftModel})` : ''}`}
                      </div>
                    </div>
                  )}
                  <div className="additional-details__group">
                    <span className="additional-details__label">
                      <FormattedMessage
                        id="FlightLegInfo.cabinClass"
                        defaultMessage="Cabin Class"
                      />
                    </span>
                    {legDetail.cabinClassName}
                  </div>
                  {legDetail.baggageWeight > 0 && (
                    <div className="additional-details__group">
                      <span className="additional-details__label">
                        <FormattedMessage
                          id="FlightLegInfo.baggage"
                          defaultMessage="Baggage"
                        />
                      </span>
                      {`${legDetail.baggageWeight}kg`}
                    </div>
                  )}
                </div>
              </div>
              {legDetail.transitDuration > 0 && (
                <div className="flight-transit">
                  <div className="flight-timeline">
                    <small className="flight-timeline__duration">
                      <FormattedDuration minutes={legDetail.transitDuration} />
                    </small>
                  </div>
                  <div className="flight-route__info">
                    <strong>
                      {legDetail.arrival.airportCode}
                    </strong>
                    <div>
                      {legDetail.arrival.airportName}
                      <label className="flight-date">
                        {formatDateString(legDetail.arrival.date, 'MEDIUM', cultureCode)}
                      </label>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    )
  );
};

export default FlightLegInfo;
