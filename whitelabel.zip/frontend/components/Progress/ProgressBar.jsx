import React from 'react';
import './ProgressBar.scss';
// @flow
import { type ProgressBarProps } from './types';

const ProgressBar = ({ progressStatus }: ProgressBarProps) => {
  let barPercent = 0;
  let progressMsg = 'Finding the best deals';
  if (progressStatus) {
    if (progressStatus.percent) {
      barPercent = `${progressStatus.percent}%`;
      progressMsg = `${progressStatus.loadingMsg}`;
    }
  }
  return (
    <div className="polling-progress-bar polling-progress-bar--primary">
      <div className="polling-progress-bar__line">
        <div
          className="polling-progress-bar__value"
          style={{
            width: barPercent,
            transition: 'all 2s',
          }}
        />
      </div>
      <div className="polling-progress-bar__count">
        {progressMsg}
      </div>
    </div>
  );
};
export default ProgressBar;
