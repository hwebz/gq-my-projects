// @flow
import { type ProgressStatus } from '../../flow-types';

export type ProgressBarProps = {
  progressStatus: ProgressStatus,
};
