// @flow
import { type TrackingInfo } from 'flow-types';

export type EventTrackingArguments = {
  args: TrackingInfo,
};

export type EventTrackingParts = {
  gManager?: string,
  gScript?: string,
  mixPanelScript?: string,
  clevertapScript?: string,
};
