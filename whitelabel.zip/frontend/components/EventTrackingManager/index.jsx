// @flow
import React from 'react';
import buildParts from './buildParts';
import { type EventTrackingArguments } from './types';

function EventTrackingManager(args: EventTrackingArguments) {
  const {
    googleAnalyticsIdGoQuo,
    googleAnalyticsIdClient,
    clevertapId,
    mixpanelId,
  } = args;
  const parts = buildParts(
    {
      googleAnalyticsIdGoQuo,
      googleAnalyticsIdClient,
      clevertapId,
      mixpanelId,
    },
  );
  const {
    gManager, gScript, mixPanelScript, clevertapScript,
  } = parts;

  return (
    <React.Fragment>
      {gManager && gScript && (
        <React.Fragment>
          <script async src={parts.gManager} />
          <script
            type="text/javascript"
          /* eslint-disable react/no-danger */
            dangerouslySetInnerHTML={{ __html: parts.gScript }}
          />
        </React.Fragment>
      )}
      {mixPanelScript
        && (
        <script
          type="text/javascript"
          dangerouslySetInnerHTML={{ __html: parts.mixPanelScript }}
        />)}
      {clevertapScript
        && (
        <script
          type="text/javascript"
          dangerouslySetInnerHTML={{ __html: parts.clevertapScript }}
          /* eslint-enable react/no-danger */
        />)}
    </React.Fragment>
  );
}

export default EventTrackingManager;
