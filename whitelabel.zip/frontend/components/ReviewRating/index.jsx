import React from 'react';
import './ReviewRating.scss';
import { FormattedMessage } from 'react-intl';

// @flow
import { type TrustYouReviewProps } from 'flow-types';

function getColor(score) {
  let color = '';
  if (score >= 86 && score <= 100) {
    color = 'excellent';
  } else if (score >= 80 && score <= 85) {
    color = 'very-good';
  } else if (score >= 75 && score <= 79) {
    color = 'good';
  } else if (score >= 68 && score <= 74) {
    color = 'fair';
  } else if (score >= 0 && score <= 67) {
    color = 'poor';
  }
  return color;
}

function ReviewRating(props: TrustYouReviewProps) {
  const {
    score, text, reviews, position, direction,
  } = props;
  const color = getColor(score);
  return (
    <div className={`review-rating review-rating--${position} review-rating--${direction || ''}`}>
      <span className={`trust-you-logo__score trust-you-logo--${color}`}>
        {parseFloat(score / 10).toFixed(1)}
      </span>
      <div className={`review-rating__detail review-rating__detail--${color}`}>
        <strong>
          {text}
        </strong>
        <span>
          <FormattedMessage
            id="ReviewRating.reviewCount"
            defaultMessage={'from {reviews} reviews'}
            values={{ reviews }}
          />
        </span>
      </div>
    </div>
  );
}

export default ReviewRating;
