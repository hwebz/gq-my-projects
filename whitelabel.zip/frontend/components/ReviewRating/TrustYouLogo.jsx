import React from 'react';
import './TrustYouLogo.scss';

// @flow
import { type TrustYouLogoProps } from './types';

const TrustYouLogo = ({ score, color }: TrustYouLogoProps) => (
  <span className={`trust-you-logo__score trust-you-logo--${color}`}>
    {parseFloat(score / 10).toFixed(1)}
  </span>
);

export default TrustYouLogo;
