// @flow

export type TrustYouLogoProps = {
  score: number,
  text: string,
  color: string,
  reviews: number,
  direction: string,
};
