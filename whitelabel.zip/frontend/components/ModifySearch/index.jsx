import React, { Component } from 'react';
import { IoIosSearch as IconSearch } from 'react-icons/io';
import { MdArrowBack as IconArrowLeft } from 'react-icons/md';
// @flow
import { FormattedMessage } from 'react-intl';
import { type ModifySearchProps, type ModifySearchState } from './types';
import DateFormat, { type EDateFormat } from '../DateFormat';
import SearchForm from '../SearchForm';
import ComponentBase, { type GenericComponent } from '../ComponentBase';
import {
  getSearchOriginCityName, getSearchDestinationCityName,
  getSearchNameFromCode, getSearchNameToCode,
} from '../../store-app/modules/search-form/selectors';


export class ModifySearchComponent extends Component<ModifySearchProps, ModifySearchState> {
  constructor(props: ModifySearchProps) {
    super(props);
    this.state = {
      isShowMobileSearchForm: false,
    };
  }

  state: ModifySearchState;

  triggerSearchForm = () => {
    const { isShowMobileSearchForm } = this.state;
    this.setState({
      isShowMobileSearchForm: !isShowMobileSearchForm,
    });
  };

  props: ModifySearchProps;

  render() {
    const {
      generalConfig, cultureCode, searchQuery,
      isDisabled, SearchNameFromCode, SearchNameToCode,
      SearchOriginCityName, SearchDestinationCityName,
      isClientSide, router,
    } = this.props;
    const disableButton: string = isDisabled ? 'button-disabled' : '';
    const { isShowMobileSearchForm } = this.state;
    return (
      <div className={`header-nav ${isDisabled ? 'header-nav--overlay header-nav--overlay__bg' : ''}`}>
        <div className="header-nav__mobile">
          {searchQuery && (
            <div className="header-nav__mobile__text">
              <div className={SearchOriginCityName && SearchDestinationCityName ? '' : 'content-placeholder'}>
                <FormattedMessage
                  id="hotelResults.ModifySearch.cityNames"
                  defaultMessage="From {origin} to {destination}"
                  values={{
                    origin: (
                      <strong>
                        <FormattedMessage
                          id="hotelResults.ModifySearch.origin"
                          defaultMessage=" {cityName} ({cityCode})"
                          values={{
                            cityName: SearchOriginCityName,
                            cityCode: SearchNameFromCode,
                          }}
                        />
                      </strong>
                    ),
                    destination: (
                      <strong>
                        <FormattedMessage
                          id="hotelResults.ModifySearch.destination"
                          defaultMessage=" {cityName} ({cityCode})"
                          values={{
                            cityName: SearchDestinationCityName,
                            cityCode: SearchNameToCode,
                          }}
                        />
                      </strong>
                    ),
                  }}
                />
              </div>

              <div>
                <FormattedMessage
                  id="hotelResults.ModifySearch.date"
                  defaultMessage="{departure} to {return}"
                  values={{
                    departure: (
                      <DateFormat
                        value={searchQuery.departureDate}
                        format={('SHORT': EDateFormat)}
                        locale={`${cultureCode}`}
                      />
                    ),
                    return: (
                      <DateFormat
                        value={searchQuery.returnDate}
                        format={('SHORT': EDateFormat)}
                        locale={`${cultureCode}`}
                      />
                    ),
                  }}
                />
              </div>
            </div>
          )}
          <div className={`header-nav__mobile__button ${disableButton}`}>
            <i>
              <IconSearch onClick={this.triggerSearchForm} />
            </i>
          </div>
        </div>
        <div
          className={`header-nav__modify panel-mobile${isShowMobileSearchForm ? ' is-open' : ''}`}
        >
          <div className="panel-mobile__title">
            <i>
              <IconArrowLeft onClick={this.triggerSearchForm} />
            </i>
            <strong>
              <FormattedMessage
                id="hotelResults.ModifySearch.modifySearch"
                defaultMessage="Modify Search"
              />
            </strong>
          </div>
          <div className="panel-mobile__content container">
            <SearchForm
              configSearchForm={generalConfig}
              searchQuery={searchQuery}
              isSecondarySearchForm
              isClientSide={isClientSide}
              router={router}
              searchButtonClass="header-search-btn"
            />
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  SearchOriginCityName: getSearchOriginCityName(state),
  SearchDestinationCityName: getSearchDestinationCityName(state),
  SearchNameFromCode: getSearchNameFromCode(state),
  SearchNameToCode: getSearchNameToCode(state),
});

const injection: GenericComponent<ModifySearchProps> = ComponentBase;

export default injection(ModifySearchComponent, {
  mapStateToProps,
  hasCultureCode: true,
  hasGeneralConfig: true,
});
