/*
 * @flow
 */
import { type SearchParameterQuery, type GeneralInfo } from '../../flow-types';

export * from '../../flow-types';

export type ModifySearchProps = {
  generalConfig: GeneralInfo,
  isDisabled: boolean,
  cultureCode: string,
  searchQuery: SearchParameterQuery,
  searchButtonClass: string,
  isHeader: boolean,
  SearchNameFromCode: string,
  SearchNameToCode: string,
  SearchOriginCityName: string,
  SearchDestinationCityName: string,
  isClientSide: boolean,
};

export type ModifySearchState = {
  isShowMobileSearchForm: boolean,
};
