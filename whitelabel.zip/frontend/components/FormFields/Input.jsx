import React from 'react';
// @flow
import { type InputProps } from '../../flow-types';

const Input = (props: InputProps) => {
  const {
    name, type, handleOnChange, placeholder, validationType, value,
  } = props;
  return (
    <input
      className="form__input__control"
      name={name}
      type={type}
      value={value || ''}
      onBlur={(e) => {
        handleOnChange(e, validationType);
      }}
      onChange={(e) => {
        handleOnChange(e, validationType);
      }}
      placeholder={placeholder}
    />
  );
};
export default Input;
