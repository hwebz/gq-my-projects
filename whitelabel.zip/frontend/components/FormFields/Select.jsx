import React from 'react';
// @flow
import type { SelectProps } from '../../flow-types';

const Select = (props: SelectProps) => {
  const {
    name, value, handleOnChange, placeholder, validationType, options,
  } = props;
  return (
    <select
      className="form__input__control"
      name={name}
      value={value}
      onBlur={(e) => {
        handleOnChange(e, validationType);
      }}
      onChange={(e) => {
        handleOnChange(e, validationType);
      }}
    >
      {placeholder && (
      <option value="">
        {placeholder}
      </option>
      )}
      {options.map(option => (
        <option key={option.id} value={option.value} label={option.text}>
          {option.text}
        </option>
      ))}
    </select>
  );
};
export default Select;
