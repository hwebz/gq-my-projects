import React from 'react';
// @flow
import { type FormGroupProps } from '../../flow-types';
import Input from './Input';

const FormGroup = (props: FormGroupProps) => {
  const {
    validation, title, name, placeholderText, type, validationType,
  } = props;
  return (
    <div
      className={`${
        !validation.status || validation.status !== undefined ? 'error-field' : ''
      } form__group__item`}
    >
      <div className="form__label">
        <label>
          {title}
        </label>
      </div>
      <div className="form__input">
        <Input
          handleOnChange={validation.handlePaxChange}
          name={name}
          placeholder={placeholderText}
          type={type}
          validationType={validationType}
          value={validation.value}
        />
      </div>
      {!validation.status && (
      <span className="error-msg">
        {validation.message}
      </span>
      )}
    </div>
  );
};
export default FormGroup;
