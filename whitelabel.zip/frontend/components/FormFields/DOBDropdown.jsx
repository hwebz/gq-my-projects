import React, { Component } from 'react';
import { defineMessages } from 'react-intl';
import ComponentBase, {
  type GenericComponent,
} from '../ComponentBase';
// @flow
import { type DobDropdownProps, type DobDropdownState, type CalendarItem } from '../../flow-types';
import Select from './Select';
import './DOBDropdown.scss';

const defaultMessages = defineMessages({
  Jan: {
    id: 'DOBDropdown.Jan',
    defaultMessage: 'Jan',
  },
  Feb: {
    id: 'DOBDropdown.Feb',
    defaultMessage: 'Feb',
  },
  Mar: {
    id: 'DOBDropdown.Mar',
    defaultMessage: 'Mar',
  },
  Apr: {
    id: 'DOBDropdown.Apr',
    defaultMessage: 'Apr',
  },
  May: {
    id: 'DOBDropdown.May',
    defaultMessage: 'May',
  },
  Jun: {
    id: 'DOBDropdown.Jun',
    defaultMessage: 'Jun',
  },
  Jul: {
    id: 'DOBDropdown.Jul',
    defaultMessage: 'Jul',
  },
  Aug: {
    id: 'DOBDropdown.Aug',
    defaultMessage: 'Aug',
  },
  Sep: {
    id: 'DOBDropdown.Sep',
    defaultMessage: 'Sep',
  },
  Oct: {
    id: 'DOBDropdown.Oct',
    defaultMessage: 'Oct',
  },
  Nov: {
    id: 'DOBDropdown.Nov',
    defaultMessage: 'Nov',
  },
  Dec: {
    id: 'DOBDropdown.Dec',
    defaultMessage: 'Dec',
  },
  dayError: {
    id: 'DOBDropdown.dayError',
    defaultMessage: 'Please select day',
  },
  monthError: {
    id: 'DOBDropdown.monthError',
    defaultMessage: 'Please select month',
  },
  yearError: {
    id: 'DOBDropdown.yearError',
    defaultMessage: 'Please select year',
  },
  dayPlaceholder: {
    id: 'DOBDropdown.dayPlaceholder',
    defaultMessage: 'Day',
  },
  monthPlaceholder: {
    id: 'DOBDropdown.monthPlaceholder',
    defaultMessage: 'Month',
  },
  yearPlaceholder: {
    id: 'DOBDropdown.yearPlaceholder',
    defaultMessage: 'Year',
  },
});

class DOBDropdown extends Component<DobDropdownProps, DobDropdownState> {
  constructor(props) {
    super(props);
    // property name & form field name should be same
    // eg: email <input name='email'>
    this.state = {
      DOB: {
        day: { value: '', required: true, status: true },
        month: { value: '', required: true, status: true },
        year: { value: '', required: true, status: true },
      },
      daysOption: this.generateDays(31),
      errorMsg: '',
    };
  }

  state: DobDropdownState;

  componentDidMount() {
    const { DOBStatus } = this.props;
    const { DOB } = this.state;
    const { day, month, year } = DOB;
    if (DOBStatus.value) {
      const [year1, month1, day1] = DOBStatus.value.split('-');
      day.value = parseInt(day1, 10);
      month.value = parseInt(month1, 10);
      year.value = parseInt(year1, 10);
      this.setState(DOB);
    }
  }

  componentDidUpdate() {
    // const { DOBStatus } = this.props;
  }

  setDays = (m: number, y: number): void => {
    const oddMonth = m % 2;
    /* eslint-disable */
    let numOfDays = (m === '2' && this.leapYear(y)) ? 29
                    : (m === '2') ? 28
                    : (oddMonth || m === '8') ? 31 : 30;
    /* eslint-enable */
    this.setState({ daysOption: this.generateDays(numOfDays) });
  }

  generateDays = (numberOfDays: number): CalendarItem => (
    Array.from({ length: numberOfDays }, (v, k) => (
      { text: k + 1, value: k + 1, id: k + 1 }
    ))
  );

  leapYear = year => (
    ((year % 4 === 0) && (year % 100 !== 0)) || (year % 400 === 0)
  )

  generateDOB = () => {
    const { personInfo, intl } = this.props;
    const { daysOption } = this.state;
    const { formatMessage } = intl;
    let minYear: number = parseInt(personInfo.minDob.split('-')[0], 10); // date format should be YYYY-MM-DD
    let maxYear: number = parseInt(personInfo.maxDob.split('-')[0], 10); // date format should be YYYY-MM-DD
    if (maxYear > minYear || maxYear === null || minYear === null) {
      if (personInfo.type.toLowerCase() === 'adult') {
        maxYear = (new Date()).getFullYear() - 100;
        minYear = (new Date()).getFullYear() - 12;
      } else {
        maxYear = (new Date()).getFullYear() - 12; // max child age is 12
        minYear = (new Date()).getFullYear();
      }
      console.log('%c Invalid min/max year ', 'background: #f00; color: #fff', `minYear: ${minYear}`, `maxYear: ${maxYear}`);
    }
    const calendar: {
      days: CalendarItem,
      months: CalendarItem,
      year: CalendarItem,
    } = {
      days: daysOption, // generates number from 1-31
      // TODO formated msg ids
      months: [
        { text: formatMessage(defaultMessages.Jan), value: 1, id: 0 },
        { text: formatMessage(defaultMessages.Feb), value: 2, id: 1 },
        { text: formatMessage(defaultMessages.Mar), value: 3, id: 2 },
        { text: formatMessage(defaultMessages.Apr), value: 4, id: 3 },
        { text: formatMessage(defaultMessages.May), value: 5, id: 4 },
        { text: formatMessage(defaultMessages.Jun), value: 6, id: 5 },
        { text: formatMessage(defaultMessages.Jul), value: 7, id: 6 },
        { text: formatMessage(defaultMessages.Aug), value: 8, id: 7 },
        { text: formatMessage(defaultMessages.Sep), value: 9, id: 8 },
        { text: formatMessage(defaultMessages.Oct), value: 10, id: 9 },
        { text: formatMessage(defaultMessages.Nov), value: 11, id: 10 },
        { text: formatMessage(defaultMessages.Dec), value: 12, id: 11 },
      ],
      years: [],
    };
    calendar.years = Array(minYear - maxYear + 1)
      .fill().map((_, idx) => ({ text: minYear - idx, value: minYear - idx, id: minYear - idx }));
    return calendar;
  }

  handleOnSelect = (event: SyntheticEvent<HTMLElement>) => {
    const { DOB } = this.state;
    const { setDOB, intl } = this.props;
    const { formatMessage } = intl;
    const nameIndex: string = event.target.name.split('.');
    DOB[nameIndex[0]].value = event.target.value;
    if (nameIndex[0] === 'month') {
      this.setDays(event.target.value, DOB.year.value);
    } else if (nameIndex[0] === 'year') {
      this.setDays(DOB.month.value, event.target.value);
    }
    this.setState({ DOB });
    const date = `${DOB.year.value}-${DOB.month.value}-${DOB.day.value}`;
    const dayError = !DOB.day.value ? formatMessage(defaultMessages.dayError) : '';
    const monthError = !DOB.month.value ? formatMessage(defaultMessages.monthError) : '';
    const yearError = !DOB.year.value ? formatMessage(defaultMessages.yearError) : '';
    const displayError = yearError || monthError || dayError;
    this.setState({ errorMsg: displayError });
    setDOB(event, date);
  }

  props: DobDropdownProps;

  render() {
    const {
      title,
      DOBStatus,
      paxIndex,
      intl,
    } = this.props;
    const { DOB, errorMsg } = this.state;
    const { day, month, year } = DOB;
    const { formatMessage } = intl;
    return (
      <div className={`${DOBStatus.status ? '' : 'error-field'} dob-field`}>
        <div className="form__group form__group__collect">
          <div className="form__label">
            <label>
              {title}
            </label>
          </div>
          <div className={`${(day.status || day.status === undefined) ? '' : 'error-field'} form__group__item`}>
            <div className="form__input">
              <Select
                name={`day.${paxIndex}`}
                handleOnChange={this.handleOnSelect}
                placeholder={formatMessage(defaultMessages.dayPlaceholder)}
                type="text"
                value={DOB.day.value}
                validationType="NUMBER"
                options={this.generateDOB().days}
              />
            </div>
          </div>
          <div className={`${(month.status || month.status === undefined) ? '' : 'error-field'} form__group__item`}>
            <div className="form__input">
              <Select
                name={`month.${paxIndex}`}
                handleOnChange={this.handleOnSelect}
                placeholder={formatMessage(defaultMessages.monthPlaceholder)}
                type="text"
                validationType="NUMBER"
                options={this.generateDOB().months}
                value={DOB.month.value}
              />
            </div>
          </div>
          <div className={`${(year.status || year.status === undefined) ? '' : 'error-field'} form__group__item`}>
            <div className="form__input">
              <Select
                name={`year.${paxIndex}`}
                handleOnChange={this.handleOnSelect}
                placeholder={formatMessage(defaultMessages.yearPlaceholder)}
                type="text"
                value={DOB.year.value}
                validationType="NUMBER"
                options={this.generateDOB().years}
              />
            </div>
          </div>
        </div>
        {errorMsg && !DOBStatus.status && (
          <span className="error-msg">
            {errorMsg}
          </span>
        )}
      </div>
    );
  }
}

const injection: GenericComponent<DOBDropdownProp> = ComponentBase;

export default injection(DOBDropdown);
