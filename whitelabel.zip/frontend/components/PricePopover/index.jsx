import React from 'react';
import './PricePopover.scss';
import { FormattedMessage } from 'react-intl';
import { MdRemove as MdRoundTripArrow } from 'react-icons/md';
// @flow
import { type PricePopoverProps } from './types';
import NumberFormat from '../NumberFormat';
import DateFormat from '../DateFormat';

class PricePopover extends React.Component <PricePopoverProps> {
  constructor(props) {
    super(props);
    this.state = {
      popoverTop: 0,
    };
    this.popoverRef = React.createRef();
  }

  componentDidMount() {
    this.updateWindowDimensions();
    window.addEventListener('resize', this.updateWindowDimensions);
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.updateWindowDimensions);
  }

  updateWindowDimensions = () => {
    const popover = this.popoverRef.current.getBoundingClientRect();
    this.setState({
      popoverTop: popover.top,
    });
  }

  render() {
    const {
      FlightInfo,
      RoomInfo,
      PriceInfo,
      isFlight,
    } = this.props;
    const { popoverTop } = this.state;

    const bottomClass = (popoverTop < 0) ? 'popover--bottom' : '';
    const flightClass = isFlight ? 'popover--flight' : '';

    return (
      <div className={`price-popover popover ${bottomClass} ${flightClass}`} ref={this.popoverRef}>
        <div className="popover-title">
          <FormattedMessage
            id="pricePopover.pacakgeDetails"
            defaultMessage="Package details"
          />
        </div>
        <div className="popover-content">
          <div className="popover-list">
            <div className="popover-list-item">
              <strong>
                {RoomInfo.roomtype}
                <small>
                  <FormattedMessage
                    id="PricePopover.night"
                    defaultMessage={
                      '{count, number} {count, plural, one {night} other {nights}}'
                    }
                    values={{ count: RoomInfo.nightsCount }}
                  />
                </small>
              </strong>
              <strong>
                <FormattedMessage
                  id="PricePopover.rooms"
                  defaultMessage={
                    '{count, number} {count, plural, one {room} other {rooms}}'
                  }
                  values={{ count: RoomInfo.noOfRoom }}
                />
              </strong>
            </div>
            <div className="popover-list-item">
              <span>
                <strong>
                  <FormattedMessage id="PricePopover.flight" defaultMessage="Flight: " />
                  {FlightInfo.origin}
                  &nbsp;
                  <MdRoundTripArrow />
                  &nbsp;
                  {FlightInfo.destination}
                </strong>
                <small>
                  <FormattedMessage id="PricePopover.depart" defaultMessage="Depart: " />
                  {}
                  <DateFormat
                    value={FlightInfo.departDate}
                    format={('MEDIUM': Format)}
                    locale={`${PriceInfo.cultureCode}`}
                  />
                  &nbsp;
                  <br />
                  <FormattedMessage id="PricePopover.return" defaultMessage="Return: " />
                  <DateFormat
                    value={FlightInfo.returnDate}
                    format={('MEDIUM': Format)}
                    locale={`${PriceInfo.cultureCode}`}
                  />
                </small>
              </span>
              <strong>
                <FormattedMessage
                  id="PricePopover.pax"
                  defaultMessage={
                    '{count, number} {count, plural, one {person} other {pax}}'
                  }
                  values={{ count: FlightInfo.paxCount }}
                />
              </strong>
            </div>
            <div className="popover-list-item">
              <strong className="theme-primary-text">
                <FormattedMessage id="PricePopover.totalPrice" defaultMessage="Total price" />
                <small>
                  <FormattedMessage id="PricePopover.includingAllFeesandTaxes" defaultMessage="Including all fees &amp; taxes" />
                </small>
              </strong>
              <strong className="theme-primary-text">
                <NumberFormat
                  value={PriceInfo.totalRoomPrice}
                  locale={PriceInfo.cultureCode}
                  currency={PriceInfo.currency}
                  withSmall={false}
                  className=""
                />
              </strong>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default PricePopover;
