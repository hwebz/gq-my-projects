// @flow
export type PricePopoverProps = {
  FlightInfo: Object,
  RoomInfo: Object,
  PriceInfo: Object,
  showPopover: boolean,
};
