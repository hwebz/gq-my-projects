/**
 * @flow
 */
import { type IntlShape } from 'react-intl';
import {
  type GeneralInfo,
  type SearchParameterQuery,
  type AirportData,
  type PaxInfo,
  type Dispatch,
} from '../../flow-types';

export * from '../../flow-types';

export type SearchFormProps = {
  dispatch: Dispatch,
  isFetching: boolean,
  airportFromData: AirportData,
  airportToData: AirportData,
  configSearchForm: GeneralInfo,
  urlLocale: string,
  searchQuery: SearchParameterQuery,
  intl: IntlShape,
  isSecondarySearchForm: boolean,
  SearchNameFrom: string,
  SearchNameTo: string,
  SearchNameFromCode: string,
  SearchNameToCode: string,
  SearchNameToSelected: string,
  SearchNameFromSelected: string,
  isHeader: boolean,
  title: string,
};

export type SearchFormState = {
  isDropdownOpen: Object,
  departureDate: Date,
  returnDate: Date,
  SearchNameFromError: string,
  SearchNameToError: string,
  airportResultCursor: number,
  isOverlay: boolean,
  rooms: Array<PaxInfo>,
};
