import React from 'react';

// @flow
import { type OverlayProps } from './types';

const Overlay = (props: OverlayProps) => {
  const { isOverlay, clicked } = props;
  return isOverlay && <div role="presentation" className="search-form__overlay" onClick={clicked} />;
};

export default Overlay;
