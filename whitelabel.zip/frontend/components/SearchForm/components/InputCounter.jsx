import React from 'react';
// @flow
import ComponentBase, { type GenericComponent } from '../../ComponentBase';
import { type InputCounterProps } from './types';

export function InputCounterComponent(props: InputCounterProps) {
  const {
    title,
    count,
    min,
    max,
    maxTotal,
    countTotal,
    addCount,
    removeCount,
    maxOfAdults,
    countTotalOfPax,
    intl,
  } = props;

  const { formatMessage } = intl;
  let isMinusDisabled = false;
  let isAddDisabled = false;
  function checkDisabledMinus() {
    let counterDisabled = false;
    if (count === min) {
      counterDisabled = true;
    }
    isMinusDisabled = counterDisabled;
    return counterDisabled ? 'modify-pax__counter--disable' : '';
  }

  function checkDisabledAdd() {
    let counterDisabled = false;
    if (
      count === max
      || countTotal === maxTotal
      || countTotalOfPax === maxTotal
      || count === maxOfAdults
    ) {
      counterDisabled = true;
    }
    isAddDisabled = counterDisabled;
    return counterDisabled ? 'modify-pax__counter--disable' : '';
  }

  return (
    <div className="modify-pax__count">
      <button
        type="button"
        className={`modify-pax__counter modify-pax__counter--decrease ${checkDisabledMinus()}`}
        onClick={removeCount}
        tabIndex="0"
        disabled={`${isMinusDisabled ? 'disabled' : ''}`}
      >
        {/* eslint-disable */}
        -
        {/* eslint-enable */}
      </button>
      <div className="modify-pax__text">
        {formatMessage(title, { count })}
      </div>
      <button
        type="button"
        className={`modify-pax__counter modify-pax__counter--add
        ${checkDisabledAdd()}`}
        onClick={addCount}
        tabIndex="0"
        disabled={`${isAddDisabled ? 'disabled' : ''}`}
      >
        {/* eslint-disable */}
        +
        {/* eslint-enable */}
      </button>
    </div>
  );
}

const injection: GenericComponent<InputCounterProps> = ComponentBase;

export default injection(InputCounterComponent);

/*/
<FormattedMessage
  id="InputCounter.{titleSingular}"
  defaultMessage={`
      {counts, plural,
          =0 {{counts} {titleSingular}}
          one {{counts} {titleSingular}}
          other {{counts} {titlePlural}}
      }
  `}
  values={{
    counts: count,
    titleSingular: title.singular,
    titlePlural: title.plural,
  }}
/>
/*/
