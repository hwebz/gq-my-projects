// @flow
import React from 'react';
import { defineMessages } from 'react-intl';
import InputText from './InputText';
import DropdownResult from './DropdownResult';
import ComponentBase, { type GenericComponent } from '../../ComponentBase';

import { type InputTextGroupProps } from './types';

const defaultMessages = defineMessages({
  errorText: {
    id: 'InputTextGroup.errorText',
    defaultMessage: '{errorText}',
  },
});

function InputTextGroup(props: InputTextGroupProps) {
  const {
    title,
    name,
    openHandle,
    getLocations,
    value,
    resultLocation,
    openDropDown,
    fetching,
    setLocation,
    inputRef,
    selected,
    icon,
    errorText,
    onKeyDown,
    cursorLocation,
    intl,
    destinationLoading,
    placeholder,
  } = props;

  const { formatMessage } = intl;

  return (
    <div className={`search-form__input ${value ? '' : destinationLoading}`}>
      <label className="search-form__label" htmlFor={name}>
        <strong>
          {title}
        </strong>
      </label>
      <InputText
        name={name}
        onFocus={openHandle}
        onChange={getLocations}
        value={value}
        icon={icon}
        inputRef={inputRef}
        onKeyDown={onKeyDown}
        placeholder={placeholder}
      />
      {errorText.length ? (
        <div className="search-form__error">
          {formatMessage(defaultMessages.errorText, { errorText })}
        </div>
      ) : (
        ''
      )}
      {/* $FlowIgnore because intl is already available in ComponentBase of DropdownResult  */}
      <DropdownResult
        resultLocation={resultLocation}
        isOpen={openDropDown}
        handleLocation={setLocation}
        fetching={fetching}
        cursorLocation={cursorLocation}
        typeLocation={name}
        selected={selected}
      />
    </div>
  );
}

const injection: GenericComponent<InputTextGroupProps> = ComponentBase;

export default injection(InputTextGroup);
