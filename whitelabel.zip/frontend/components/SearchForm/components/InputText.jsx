import React from 'react';

// @flow
import { type InputTextProps } from './types';

const InputText = (props: InputTextProps) => {
  const {
    onChange, value, name, onFocus, inputRef, icon, onKeyDown, ...rest
  } = props;

  return (
    <div className="search-form__input-group">
      <i className="search-form__input-icon">
        {icon}
      </i>
      <input
        className="search-form__input-value"
        autoComplete="off"
        type="text"
        id={name}
        onChange={onChange}
        value={value}
        onFocus={onFocus}
        ref={inputRef}
        onKeyDown={onKeyDown}
        {...rest}
      />
    </div>
  );
};

export default InputText;
