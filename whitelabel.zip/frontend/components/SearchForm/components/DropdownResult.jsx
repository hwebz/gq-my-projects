// @flow
import React from 'react';
import { defineMessages } from 'react-intl';
import DropdownMessage from './DropdownMessage';
import DropdownList from './DropdownList';
import ComponentBase, { type GenericComponent } from '../../ComponentBase';

import { type DropdownResultProps } from './types';

const defaultMessages = defineMessages({
  loading: { id: 'DropdownResult.loading', defaultMessage: 'Loading...' },
});

// eslint-disable-next-line prefer-stateless-function
function DropdownResult(props: DropdownResultProps) {
  const {
    resultLocation,
    handleLocation,
    fetching,
    isOpen,
    selected,
    cursorLocation,
    typeLocation,
    intl,
  } = props;

  const { formatMessage } = intl;
  return (
    <div className={`search-form__dropdown ${isOpen ? 'is-open' : ''}`}>
      {fetching ? (
        <DropdownMessage message={formatMessage(defaultMessages.loading)} />
      ) : (
        <DropdownList
          resultLocation={resultLocation}
          handleLocation={handleLocation}
          cursorLocation={cursorLocation}
          typeLocation={typeLocation}
          fetching={fetching}
          selected={selected}
        />
      )}
    </div>
  );
}

const injection: GenericComponent<DropdownResultProps> = ComponentBase;

export default injection(DropdownResult);
