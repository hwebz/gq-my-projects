import React from 'react';
import { defineMessages } from 'react-intl';
import { PAX_TYPE } from './constants';
import ComponentBase, { type GenericComponent } from '../../ComponentBase';

// @flow
import { type DropdownSelectProps } from './types';

const ArrayUtils = require('../../../react-next/utils/array-utils');

const defaultMessages = defineMessages({
  infant: {
    id: 'DropdownSelect.below_2_years',
    defaultMessage: 'Below 2 years',
  },
  yearOld: {
    id: 'DropdownSelect.years_old',
    defaultMessage: '{childAge} years old',
  },
});

const DropdownSelect = (props: DropdownSelectProps) => {
  const {
    onChange, value,
    isInfantDisabled, intl,
  } = props;
  const { formatMessage } = intl;
  const childAges = ArrayUtils.range(PAX_TYPE.CHILDREN_RANGE_FROM, PAX_TYPE.CHILDREN_RANGE_TO + 1);
  return (
    <div className="select-wrapper">
      <select className="modify-pax__age__select" value={value} onChange={onChange}>
        <option value="1" disabled={isInfantDisabled && value !== 1}>
          {formatMessage(defaultMessages.infant)}
        </option>
        {childAges.map(childAge => (
          <option key={childAge} value={childAge}>
            {formatMessage(defaultMessages.yearOld, { childAge })}
          </option>
        ))}
      </select>
    </div>
  );
};

const injection: GenericComponent<DropdownSelectProps> = ComponentBase;

export default injection(DropdownSelect);
