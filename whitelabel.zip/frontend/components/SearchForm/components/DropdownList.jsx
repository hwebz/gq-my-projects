import React from 'react';
import { defineMessages } from 'react-intl';
import { MdLocationCity as IconCity, MdAirplanemodeActive as IconAirPort } from 'react-icons/md';

// @flow
import DropdownMessage from './DropdownMessage';
import ComponentBase, { type GenericComponent } from '../../ComponentBase';
// @flow
import { type DropdownListProps } from './types';

export const AIRPORT_TYPE: {
  AIRPORT: string,
  CITY: string,
  COUNTPAGE: number,
} = {
  AIRPORT: 'airport',
  CITY: 'city',
  COUNTPAGE: 6,
};

const defaultMessages = defineMessages({
  noResult: { id: 'DropdownList.noResult', defaultMessage: 'No results found.' },
});

function DropdownList<T: DropdownListProps>(props: T) {
  const {
    resultLocation,
    handleLocation,
    cursorLocation,
    typeLocation,
    fetching,
    intl,
  } = props;
  const { formatMessage } = intl;

  return (
    !fetching && (
      <div className="search-form__dropdown-list">
        {resultLocation
          && (resultLocation.length > 0 ? (
            resultLocation.slice(0, AIRPORT_TYPE.COUNTPAGE).map((item, i) => (
              <div
                role="presentation"
                className={`search-form__dropdown-item ${
                  cursorLocation === i ? 'search-form__dropdown-item--active' : null
                }`}
                data-name={item.airportName}
                data-code={item.airportCode}
                key={item.airportCode}
                onClick={() => handleLocation(item)}
                data-type={typeLocation}
              >
                <div className="search-form__dropdown-icon">
                  {item.type.toString() === AIRPORT_TYPE.AIRPORT ? <IconAirPort /> : <IconCity />}
                </div>
                <div className="detail">
                  <div className="name">
                    <b>
                      {item.airportName}
                    </b>
                    <span className="search-form__airport-code">
                      {`(${item.airportCode})`}
                    </span>
                  </div>
                  <div className="origin">
                    <span>
                      {`${item.cityName}, `}
                    </span>
                    <b>
                      {item.countryName}
                    </b>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <DropdownMessage message={formatMessage(defaultMessages.noResult)} />
          ))}
      </div>
    )
  );
}

const injection: GenericComponent<DropdownListProps> = ComponentBase;

export default injection(DropdownList);
