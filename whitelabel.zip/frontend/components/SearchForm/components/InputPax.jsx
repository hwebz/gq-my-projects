import React from 'react';
import { IoAndroidPerson as IconPerson } from 'react-icons/io';

// @flow
import { type InputPaxProps } from './types';

const InputPax = (props: InputPaxProps) => {
  const {
    title, openHandle, name, value, inputRef, onKeyDown,
  } = props;
  return (
    <div className="search-form__input">
      <label className="search-form__label" htmlFor={name}>
        <strong>
          {title}
        </strong>
      </label>

      <div className="search-form__input-group">
        <div className="search-form__input-icon">
          <IconPerson />
        </div>
        <input
          className="search-form__input-value"
          autoComplete="off"
          onFocus={openHandle}
          type="text"
          id={name}
          value={value}
          ref={inputRef}
          onKeyDown={onKeyDown}
          readOnly
        />
      </div>
    </div>
  );
};
export default InputPax;
