import React from 'react';
import { defineMessages } from 'react-intl';
import { MdHotel as IconHotel } from 'react-icons/md';

// @flow
import InputCounter from './InputCounter';
import DropdownSelect from './DropdownSelect';
import ComponentBase, { type GenericComponent } from '../../ComponentBase';

import { type DropdownPaxProps } from './types';

export const PAX_TYPE: {
  ADULT: number,
  CHILDREN: number,
  CHILDREN_RANGE_FROM: number,
  CHILDREN_RANGE_TO: number,
} = {
  ADULT: 1,
  CHILDREN: 2,
  CHILDREN_RANGE_FROM: 2,
  CHILDREN_RANGE_TO: 11,
};

const defaultMessages = defineMessages({
  room: {
    id: 'DropdownPax.room',
    defaultMessage: 'ROOM {roomNum}',
  },
  childAge: {
    id: 'DropdownPax.childAge',
    defaultMessage: 'CHILD AGE',
  },
  adult: {
    id: 'DropdownPax.adult',
    defaultMessage: 'ADULTS',
  },
  children: {
    id: 'DropdownPax.children',
    defaultMessage: 'CHILDREN 0-12',
  },
  roomPax: {
    id: 'DropdownPax.roomPax',
    defaultMessage: '{count, number} {count, plural, =0 {Rooms} one {Room} other {Rooms}}',
  },
  adultPax: {
    id: 'DropdownPax.adultPax',
    defaultMessage: '{count, number} {count, plural, =0 {Adults} one {Adult} other {Adults}}',
  },
  childrenPax: {
    id: 'DropdownPax.childrenPax',
    defaultMessage: '{count, number} {count, plural, =0 {Children} one {Child} other {Children}}',
  },
});

function DropdownPax(props: DropdownPaxProps): ComponentType<DropdownPaxProps> {
  const {
    openDropDown,
    rooms,
    addRoom,
    removeRoom,
    maxRoom,
    maxAdults,
    maxChild,
    maxTotalofRoom,
    countTotalOfPax,
    calculatePassenger,
    message,
    selectChildAge,
    onBlur,
    intl,
    title,
  } = props;

  const { formatMessage } = intl;
  const RoomBox = () => (
    <div className="modify-pax__wrap">
      {rooms.map((item, index) => (
        <div className="modify-pax__room" key={`DropdownPax_room_${index.toString()}`}>
          <div className="modify-pax__box">
            <div className="modify-pax__box__title">
              <div className="modify-pax__room-icon">
                <IconHotel size={16} />
              </div>
              <b>
                {formatMessage(defaultMessages.room, { roomNum: index + 1 })}
              </b>
            </div>
            <div className="modify-pax__persons">
              <InputCounter
                // Object is sent for title as InputCounter is used by Adult, Children and Room
                title={defaultMessages.adultPax} // Will be localized + pluralization
                                                // in the component itself
                min={1}
                count={item.adults}
                max={maxAdults}
                maxTotal={maxTotalofRoom}
                countTotal={item.adults + item.children.length}
                countTotalOfPax={countTotalOfPax}
                addCount={() => calculatePassenger(index, PAX_TYPE.ADULT, 1)}
                removeCount={() => calculatePassenger(index, PAX_TYPE.ADULT, -1)}
              />
              <InputCounter
                // Object is sent for title as InputCounter is used by Adult, Children and Room
                title={defaultMessages.childrenPax} // Will be localized + pluralization
                                                    // in the component itself
                count={item.children.length}
                min={0}
                max={maxChild}
                // maxOfAdults={item.adults}
                maxTotal={maxTotalofRoom}
                countTotal={item.adults + item.children.length}
                countTotalOfPax={countTotalOfPax}
                addCount={() => calculatePassenger(index, PAX_TYPE.CHILDREN, 1)}
                removeCount={() => calculatePassenger(index, PAX_TYPE.CHILDREN, -1)}
              />
            </div>
          </div>
          <div className="modify-pax__age">
            {item.children.length ? (
              <div className="modify-pax__age__title">
                <span>
                  {formatMessage(defaultMessages.childAge)}
                </span>
              </div>
            ) : (
              ''
            )}
            <div className="modify-pax__age__box">
              {item.children
                ? item.children.map((child, childIndex) => (
                  <DropdownSelect
                    key={`select_${childIndex.toString()}`}
                    value={child}
                    isInfantDisabled={item.children.filter(c => c < 2).length === item.adults}
                    onChange={e => selectChildAge(e, index, childIndex)}
                  />
                ))
                : null}
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div
      className={`search-form__dropdown search-form__dropdown--pax opened-pax ${
        openDropDown ? 'is-open' : ''
      }`}
      onBlur={onBlur}
    >
      <div className="modify-pax search-form__box">
        <strong className="modify-pax__title">
          {title}
        </strong>
        <div className="modify-pax__nav">
          <InputCounter
            // Object is sent for title as InputCounter is used by Adult, Children and Room
            title={defaultMessages.roomPax} // Will be localized + pluralization
                                            // in the component itself
            count={rooms.length}
            min={1}
            max={maxRoom}
            addCount={addRoom}
            maxTotal={maxTotalofRoom}
            countTotalOfPax={countTotalOfPax}
            removeCount={removeRoom}
          />
          <div className="modify-pax__title">
            <span>
              {formatMessage(defaultMessages.adult)}
            </span>
            <span>
              {formatMessage(defaultMessages.children)}
            </span>
          </div>
        </div>
        <RoomBox />
        <div className="modify-pax__notify">
          <span>
            {message}
          </span>
        </div>
      </div>
    </div>
  );
}

const injection: GenericComponent<DropdownPaxProps> = ComponentBase;

export default injection(DropdownPax);
