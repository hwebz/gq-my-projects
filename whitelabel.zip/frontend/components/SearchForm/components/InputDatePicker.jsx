import React from 'react';
import getMonth from 'date-fns/get_month';
import getYear from 'date-fns/get_year';
import { IoIosCalendar as IconCalendar } from 'react-icons/io';

// @flow
import { formatDateString, type EDateFormat } from 'react-next/intl/date-locale';
import DatePickerSearch from '../../Common/DatePicker';
import ComponentBase, { type GenericComponent } from '../../ComponentBase';
import { type InputDatePickerProps } from './types';

function InputDatePicker(props: InputDatePickerProps) {
  const {
    cultureCode,
    initDate,
    title,
    placeHolder,
    openHandle,
    name,
    inputRef,
    setDate,
    minStartDate,
    maxStartDate,
    openDropDown,
    onKeyDown,
  } = props;

  const dateSelected: string = formatDateString(initDate, ('MEDIUM': EDateFormat), cultureCode);
  const monthSelected: number = getMonth(initDate);
  const yearSelected: number = getYear(initDate);
  return (
    <div className="search-form__input">
      <label className="search-form__label" htmlFor={name}>
        <strong>
          {title}
        </strong>
      </label>

      <div className="search-form__input-group">
        <i className="search-form__input-icon">
          <IconCalendar size={18} />
        </i>
        <input
          readOnly
          className="search-form__input-value datepicker"
          autoComplete="off"
          type="text"
          placeholder={placeHolder}
          onFocus={openHandle}
          id={name}
          value={dateSelected}
          ref={inputRef}
          onKeyDown={onKeyDown}
        />
      </div>

      <div
        className={`search-form__dropdown search-form__dropdown--date ${
          openDropDown ? 'is-open' : ''
        }`}
      >
        <DatePickerSearch
          changedMonth={monthSelected}
          changeYear={yearSelected}
          selected={initDate}
          changed={setDate}
          minStartDate={minStartDate}
          maxStartDate={maxStartDate}
        />
      </div>
    </div>
  );
}

const injection: GenericComponent<InputDatePickerProps> = ComponentBase;

export default injection(InputDatePicker, { hasIntl: false, hasCultureCode: true });
