import React from 'react';

// @flow
import { type DropdownMessageProps } from './types';

const DropdownMessage = (props: DropdownMessageProps) => {
  const { message } = props;
  return (
    <span className="search-form__dropdown-error">
      {message}
    </span>
  );
};

export default DropdownMessage;
