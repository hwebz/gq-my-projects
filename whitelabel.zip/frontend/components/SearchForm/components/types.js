// @flow
import type { IntlShape } from 'react-intl';
import { type AirportData, type PaxInfo, type Message } from '../../../flow-types';

export * from 'flow-types';

export type InputTextGroupProps = {
  title: string,
  name: string,
  openHandle: boolean,
  getLocations: (e: SyntheticEvent<HTMLElement>) => void,
  resultLocation: AirportData,
  value: string,
  openDropDown: boolean,
  fetching: boolean,
  setLocation: (item: AirportData) => void,
  inputRef: {
    current: ?string,
  },
  selected: string,
  icon: any,
  errorText: string,
  onBlur: boolean,
  onKeyDown: (e: SyntheticEvent<HTMLElement>) => void,
  cursorLocation: number,
  intl: IntlShape,
  destinationLoading: string,
  placeholder: string,
  formatMessage?: IntlShape,
};

export type InputTextProps = {
  onChange: (e: SyntheticEvent<HTMLInputElement>) => void,
  value: string,
  name: string,
  onFocus: boolean,
  inputRef: {
    current: ?string,
  },
  icon: any,
  onBlur: boolean,
  onKeyDown: (e: SyntheticEvent<HTMLElement>) => void,
};

export type DropdownListProps = {
  resultLocation: AirportData,
  handleLocation: (item: AirportData) => void,
  cursorLocation: number,
  typeLocation: string,
  fetching: boolean,
  intl: IntlShape,
};

export type DropdownMessageProps = {
  message: string,
};

export type DropdownPaxProps = {
  openDropDown: boolean,
  rooms: Array<PaxInfo>,
  addRoom: () => void,
  removeRoom: () => void,
  maxRoom: number,
  maxAdults: number,
  maxChild: number,
  maxTotalofRoom: number,
  countTotalOfPax: number,
  calculatePassenger: (index: number, type: number, amount: number) => void,
  message: string,
  selectChildAge: (e: SyntheticEvent<HTMLElement>, index: number, childIndex: number) => void,
  onBlur: (e: SyntheticEvent<HTMLInputElement>) => void,
  intl: IntlShape,
  title: {
    id: string,
    defaultMessage: string,
  },
};

export type DropdownResultProps = {
  resultLocation: AirportData,
  handleLocation: (item: AirportData) => void,
  fetching: boolean,
  isOpen: boolean,
  selected: string,
  cursorLocation: number,
  typeLocation: string,
  intl: IntlShape,
  formatMessage?: IntlShape,
};

export type DropdownSelectProps = {
  onChange: (e: SyntheticEvent<HTMLInputElement>, index: number, childIndex: number) => void,
  value: string,
  isInfantDisabled: boolean,
  intl: IntlShape,
  formatMessage?: IntlShape,
};

export type InputCounterProps = {
  title: Message,
  count: number,
  min: number,
  max: number,
  countTotal: number,
  maxTotal: number,
  addCount: (index: number, type: number, amount: number) => void,
  removeCount: (e: SyntheticEvent<HTMLElement>, index: number, childIndex: number) => void,
  maxOfAdults: number,
  countTotalOfPax: number,
  intl: IntlShape,
  formatMessage?: IntlShape,
};

export type InputDatePickerProps = {
  cultureCode: string,
  initDate: Date,
  title: string,
  placeHolder: string,
  openHandle: (e: SyntheticEvent<HTMLElement>) => void,
  name: string,
  inputRef: {
    current: ?string,
  },
  setDate: (date: Date) => void,
  minStartDate: string,
  maxStartDate: string,
  openDropDown: boolean,
  onKeyDown: (e: SyntheticEvent<HTMLElement>) => void,
};

export type InputPaxProps = {
  title: string,
  name: string,
  value: string,
  openHandle: (e: SyntheticEvent<HTMLElement>) => void,
  inputRef: {
    current: ?string,
  },
  onKeyDown: (e: SyntheticEvent<HTMLElement>) => void,
};

export type OverlayProps = {
  isOverlay: boolean,
  clicked: Function,
};
