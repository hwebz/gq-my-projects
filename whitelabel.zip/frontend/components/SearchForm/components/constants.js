// disable because there might be more constants
// eslint-disable-next-line
export const PAX_TYPE = {
  ADULT: 1,
  CHILDREN: 2,
  CHILDREN_RANGE_FROM: 2,
  CHILDREN_RANGE_TO: 11,
};
