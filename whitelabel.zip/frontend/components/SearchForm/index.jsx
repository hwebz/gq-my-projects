import React, { Component } from 'react';
import Router from 'next/router';
import { defineMessages } from 'react-intl';
import format from 'date-fns/format';
import addDays from 'date-fns/add_days';
import { FaSpinner as IconLoadingSpinner } from 'react-icons/fa';
import differenceInCalendarDays from 'date-fns/difference_in_calendar_days';
import {
  getOriginListOpenOnClick,
  getDestinationListOpenOnClick,
} from '../../store-app/modules/config/selectors';

// @flow
import actionTypes from '../../store-app/modules/search-form/action-types';
import {
  updateOriginAirport, updateDestinationAirport,
} from '../../store-app/modules/search-form/actions';
import { PAX_TYPE } from './components/constants';
import InputTextGroup from './components/InputTextGroup';
import DropdownPax from './components/DropdownPax';
import InputDatePicker from './components/InputDatePicker';
import InputPax from './components/InputPax';
import Overlay from './components/Overlay';
import IconArrival from './images/arrivals.svg';
import IconDeparture from './images/departures.svg';
import './SearchForm.scss';
import ComponentBase, { type GenericComponent } from '../ComponentBase';
import KeyCodes from '../../react-next/constants/key-codes';
import {
  getIsFetching, getIsURLParameterAvailable,
  getSearchNameToSelected, getSearchNameToCode,
  getSearchNameTo, getSearchNameFromSelected,
  getSearchNameFromCode, getSearchNameFrom,
  getAirportToData, getAirportFromData,
} from '../../store-app/modules/search-form/selectors';
import { type SearchFormProps, type SearchFormState } from './types';
import Backdrop from '../Common/Backdrop';

const track = require('../../react-next/utils/track-utils');

const defaultMessages = defineMessages({
  fromTitle: {
    id: 'SearchForm.fromTitle',
    defaultMessage: 'FROM',
  },
  toTitle: {
    id: 'SearchForm.toTitle',
    defaultMessage: 'TO',
  },
  departTitle: {
    id: 'SearchForm.departTitle',
    defaultMessage: 'DEPARTURE',
  },
  returnTitle: {
    id: 'SearchForm.returnTitle',
    defaultMessage: 'RETURN',
  },
  paxTitle: {
    id: 'SearchForm.paxTitle',
    defaultMessage: 'ROOMS & PASSENGERS',
  },
  inputValue: {
    id: 'SearchForm.inputValue',
    defaultMessage:
      '{room, number} {room, plural, one {Room} other {Rooms}}, {people} {people, plural, one {Person} other {People}}',
  },
  maxPaxMessage: {
    id: 'SearchForm.maxPaxMessage',
    defaultMessage: 'Maximum {maxPax} guests per booking',
  },
  searchButton: {
    id: 'SearchForm.searchButton',
    defaultMessage: 'Search',
  },
  fromPlaceholder: {
    id: 'SearchForm.fromlaceholder',
    defaultMessage: 'Airport',
  },
  toPlaceholder: {
    id: 'SearchForm.tolaceholder',
    defaultMessage: 'Airport',
  },
  searchNameError: {
    id: 'SearchForm.searchNameError',
    defaultMessage: 'Please enter an airport',
  },
});

class SearchForm extends Component<SearchFormProps, SearchFormState> {
  constructor(props: SearchFormProps) {
    super(props);
    let selectedFromAirport = null;
    let selectedToAirport = null;

    if (props.isSecondarySearchForm) {
      selectedFromAirport = props.airportFromData ? props.airportFromData[0] : null;
      selectedToAirport = props.airportToData ? props.airportToData[0] : null;
    }

    this.state = {
      isDropdownOpen: {},
      departureDate: (props.isSecondarySearchForm && props.searchQuery)
        ? props.searchQuery.departureDate
        : addDays(new Date(), props.configSearchForm.minBookingDays),
      returnDate: (props.isSecondarySearchForm && props.searchQuery)
        ? props.searchQuery.returnDate
        : addDays(
          new Date(),
          props.configSearchForm.minBookingDays + props.configSearchForm.minBookingPeriod,
        ),
      SearchNameFromError: '',
      SearchNameToError: '',
      airportResultCursor: 0,
      isOverlay: false,
      rooms: (props.isSecondarySearchForm && props.searchQuery) ? props.searchQuery.rooms : [
        {
          adults: 2,
          children: [],
        },
      ],
      isInitSelectedAirport: props.isClientSide,
      selectedFromAirport,
      selectedToAirport,
      asPathState: (props.isSecondarySearchForm && props.router && props.router.asPath)
        ? props.router.asPath : null,
      isPageChanging: false,
    };

    this.timer = null;
    this.inputToRef = React.createRef();
    this.inputDepartureRef = React.createRef();
    this.inputReturnRef = React.createRef();
    this.inputPaxRef = React.createRef();
  }

  state: SearchFormState;

  componentDidMount() {
    const { router, dispatch, isClientSide } = this.props;
    if (isClientSide && router && router.asPath === '/') {
      dispatch(updateOriginAirport({
        airportName: '',
        airportCode: '',
      }));
      dispatch(updateDestinationAirport({
        airportName: '',
        airportCode: '',
      }));
    }
  }

  onCursorChange = (cursor, type) => {
    const { selectedFromAirport, selectedToAirport, airportResultCursor } = this.state;
    const { airportFromData, airportToData } = this.props;
    const isFrom = type === 'From';
    const airportData = isFrom ? airportFromData : airportToData;
    if (airportResultCursor >= 0 && airportData && airportData.length) {
      const nextAirport = airportData[cursor];
      if (
        !selectedToAirport
        || !selectedFromAirport
        || nextAirport.airportCode !== selectedFromAirport.airportCode
      ) {
        this.setState({
          [`selected${type}Airport`]: airportData[cursor],
        });
      }
    }
  };

  static getDerivedStateFromProps(nextProps, prevState) {
    const {
      airportFromData, airportToData,
      isSecondarySearchForm, searchQuery,
      router,
    } = nextProps;
    const {
      selectedFromAirport,
      selectedToAirport,
      isInitSelectedAirport,
      asPathState,
    } = prevState;
    if (isSecondarySearchForm && airportFromData && airportToData) {
      if (
        ((selectedFromAirport !== airportFromData[0]) || (selectedToAirport !== airportToData[0]))
        && isInitSelectedAirport
      ) {
        return {
          selectedFromAirport: airportFromData[0],
          selectedToAirport: airportToData[0],
          isInitSelectedAirport: false,
        };
      }
    }

    if (isSecondarySearchForm && router && (router.asPath !== asPathState)) {
      return {
        departureDate: searchQuery.departureDate,
        returnDate: searchQuery.returnDate,
        rooms: searchQuery.rooms,
        selectedFromAirport: airportFromData[0],
        selectedToAirport: airportToData[0],
        asPathState: router.asPath,
      };
    }

    return null;
  }

  getLocations = (e) => {
    if (this.timer) {
      clearTimeout(this.timer);
    }

    const { dispatch, originListOpenOnClick, destinationListOpenOnClick } = this.props;
    const location = e.target.value;
    const targetId = e.target.id;
    this.setState({
      airportResultCursor: 0,
    });
    if (targetId === 'SearchNameFrom') {
      dispatch(updateOriginAirport({
        airportName: location,
        isUpdateAirportNameOnly: true,
      }));

      this.timer = setTimeout(() => {
        if (location.length >= 2) {
          dispatch({ type: actionTypes.GET_FROM_LOCATION_REQUEST, location });

          // opening dropdown logic is done here
          // to avoid opening the dropdown when input text is clicked
          //  but this is based on the config file originListOpenOnClick
          if (!originListOpenOnClick) {
            const newState = {
              isDropdownOpen: {
                [targetId]: true,
              },
              SearchNameFromError: '',
              SearchNameToError: '',
            };
            this.setState(newState);
          }
        }
      }, 300);
    } else {
      dispatch(updateDestinationAirport({
        airportName: location,
        isUpdateAirportNameOnly: true,
      }));

      this.timer = setTimeout(() => {
        if (location.length >= 2) {
          dispatch({ type: actionTypes.GET_TO_LOCATION_REQUEST, location });
          // opening dropdown logic is done here
          // to avoid opening the dropdown when input text is clicked
          //  but this is based on the config file destinationListOpenOnClick
          if (!destinationListOpenOnClick) {
            const newState = {
              isDropdownOpen: {
                [targetId]: true,
              },
              SearchNameFromError: '',
              SearchNameToError: '',
            };
            this.setState(newState);
          }
        }
      }, 300);
    }
  };

  // This is to get the previous airport when user key in invalid airport
  getPreviousAirport = () => {
    const { dispatch } = this.props;
    const { selectedFromAirport, selectedToAirport } = this.state;
    if (selectedFromAirport) {
      dispatch(updateOriginAirport({
        airportName: `${selectedFromAirport.airportName} (${selectedFromAirport.airportCode})`,
        airportCode: selectedFromAirport.airportCode,
      }));
    } else {
      dispatch(updateOriginAirport({
        airportName: '',
        airportCode: '',
      }));
    }

    if (selectedToAirport) {
      dispatch(updateDestinationAirport({
        airportName: `${selectedToAirport.airportName} (${selectedToAirport.airportCode})`,
        airportCode: selectedToAirport.airportCode,
      }));
    } else {
      dispatch(updateDestinationAirport({
        airportName: '',
        airportCode: '',
      }));
    }

    this.setState({
      isOverlay: false,
      isDropdownOpen: false,
    });
  };

  getLocationOnKey = (e) => {
    const { airportFromData, airportToData, dispatch } = this.props;
    const { airportResultCursor } = this.state;
    const isFrom = e.target.id === 'SearchNameFrom';
    const airportData = isFrom ? airportFromData : airportToData;
    switch (e.keyCode) {
      case KeyCodes.UP_ARROW:
        if (airportResultCursor > 0) {
          // To move the active state upwards.
          const newCursor = airportResultCursor - 1;
          this.setState({
            airportResultCursor: newCursor,
          });
          this.onCursorChange(newCursor, isFrom ? 'From' : 'To');
        }
        break;
      case KeyCodes.DOWN_ARROW:
        // Currently display only 6 results, disallow shifting to other results
        if (
          airportResultCursor < 5
          && airportData
          && airportData.length - 1 > airportResultCursor
        ) {
          // To move the active state downwards.
          // To move the active state upwards.
          const newCursor = airportResultCursor + 1;
          this.setState({
            airportResultCursor: newCursor,
          });
          this.onCursorChange(newCursor, isFrom ? 'From' : 'To');
        }
        break;
      case KeyCodes.ENTER:
        if (airportResultCursor >= 0) {
          // To get the data when user either move cursor up and down, then press enter.
          let selectedAirport;
          // airportResultCursor is used in the index so that even when user
          // didn't move up/down, they can still get the first airport data
          if (isFrom) {
            selectedAirport = airportFromData[airportResultCursor];
          } else {
            selectedAirport = airportToData[airportResultCursor];
          }

          if (selectedAirport) {
            if (isFrom) {
              dispatch(updateOriginAirport({
                airportName: `${selectedAirport.airportName} (${selectedAirport.airportCode})`,
                airportCode: selectedAirport.airportCode,
              }));
              this.setState({
                SearchNameFromError: '',
                selectedFromAirport: selectedAirport,
              });
              this.inputToRef.current.focus();
            } else {
              dispatch(updateDestinationAirport({
                airportName: `${selectedAirport.airportName} (${selectedAirport.airportCode})`,
                airportCode: selectedAirport.airportCode,
              }));
              this.setState({
                SearchNameToError: '',
                selectedToAirport: selectedAirport,
              });
              this.inputDepartureRef.current.focus();
            }
          }
        }
        break;
      case KeyCodes.ESCAPE:
        // Close all dropdown when user pressed esc button
        this.getPreviousAirport();
        this.setState({
          isDropdownOpen: {},
          isOverlay: false,
        });
        break;
      case KeyCodes.TAB:
        if (airportData && airportData.length >= 1) {
          let selectedAirport;
          if (isFrom) {
            selectedAirport = airportFromData[airportResultCursor] || airportFromData[0];
          } else {
            selectedAirport = airportToData[airportResultCursor] || airportToData[0];
          }
          if (selectedAirport) {
            if (isFrom) {
              dispatch(updateOriginAirport({
                airportName: `${selectedAirport.airportName} (${selectedAirport.airportCode})`,
                airportCode: selectedAirport.airportCode,
              }));
              this.setState({
                SearchNameFromError: '',
                selectedFromAirport: selectedAirport,
              });
            } else {
              dispatch(updateDestinationAirport({
                airportName: `${selectedAirport.airportName} (${selectedAirport.airportCode})`,
                airportCode: selectedAirport.airportCode,
              }));
              this.setState({
                SearchNameToError: '',
                selectedToAirport: selectedAirport,
              });
            }
          }
        } else {
          this.getPreviousAirport();
        }
        break;
      default:
        break;
    }
  };

  setLocationFrom = (item) => {
    const { dispatch } = this.props;
    dispatch(updateOriginAirport({
      airportName: `${item.airportName} (${item.airportCode})`,
      airportCode: item.airportCode,
    }));
    this.setState({
      SearchNameFromError: '',
      selectedFromAirport: item,
    });
    this.inputToRef.current.focus();
  };

  setLocationTo = (item) => {
    const { dispatch } = this.props;
    dispatch(updateDestinationAirport({
      airportName: `${item.airportName} (${item.airportCode})`,
      airportCode: item.airportCode,
    }));
    this.setState({
      SearchNameToError: '',
      selectedToAirport: item,
    });
    this.inputDepartureRef.current.focus();
  };

  handleChangeDateTo = (date) => {
    this.setState({
      returnDate: addDays(date, 0),
      isDropdownOpen: {},
      isOverlay: false,
    });
    // this.inputPaxRef.current.focus();
  };

  handleChangeSearch = (e) => {
    const idOfDOM = e.target.id;
    const valOfDOm = e.target.value;
    e.target.select();
    // If there's another async setState already called at this point, prioritize it.
    setTimeout(() => {
      const { originListOpenOnClick, destinationListOpenOnClick, dispatch } = this.props;
      const { selectedFromAirport, selectedToAirport } = this.state;
      const isFrom = idOfDOM === 'SearchNameFrom';
      if (selectedFromAirport) {
        dispatch(updateOriginAirport({
          airportName: `${selectedFromAirport.airportName} (${selectedFromAirport.airportCode})`,
          airportCode: selectedFromAirport.airportCode,
        }));
      } else {
        dispatch(updateOriginAirport({
          airportName: '',
          airportCode: '',
        }));
      }

      if (selectedToAirport) {
        dispatch(updateDestinationAirport({
          airportName: `${selectedToAirport.airportName} (${selectedToAirport.airportCode})`,
          airportCode: selectedToAirport.airportCode,
        }));
      } else {
        dispatch(updateDestinationAirport({
          airportName: '',
          airportCode: '',
        }));
      }
      if (
        ((isFrom && originListOpenOnClick) || (!isFrom && destinationListOpenOnClick))
        && valOfDOm.length >= 2
      ) {
        dispatch({
          type: isFrom
            ? actionTypes.GET_FROM_LOCATION_REQUEST
            : actionTypes.GET_TO_LOCATION_REQUEST,
        });
      }
      this.setState({
        isDropdownOpen: {},
        isOverlay: true,
      });

      if ((idOfDOM !== 'SearchNameFrom') && (idOfDOM !== 'SearchNameTo')) {
        const newState = {
          isDropdownOpen: {
            [idOfDOM]: true,
          },
          SearchNameFromError: '',
          SearchNameToError: '',
        };
        this.setState(newState);
      } else if (originListOpenOnClick || destinationListOpenOnClick) {
        const newState = {
          isDropdownOpen: {
            [idOfDOM]: true,
          },
          SearchNameFromError: '',
          SearchNameToError: '',
        };
        this.setState(newState);
      }
    }, 0);
  };

  validate: () => boolean = () => {
    let isError: boolean = false;
    const errors = {
      SearchNameFromError: '',
      SearchNameToError: '',
    };
    const {
      SearchNameFrom, SearchNameTo, SearchNameFromCode, SearchNameToCode, intl,
    } = this.props;

    const { formatMessage } = intl;

    if (SearchNameFrom.length === 0 || SearchNameFromCode.length < 3) {
      isError = true;
      errors.SearchNameFromError = formatMessage(defaultMessages.searchNameError);
    }
    if (SearchNameTo.length === 0 || SearchNameToCode.length < 3) {
      isError = true;
      errors.SearchNameToError = formatMessage(defaultMessages.searchNameError);
    }
    this.setState({
      ...errors,
    });

    return isError;
  };

  handleSubmitSearch = (e: SyntheticEvent<HTMLButtonElement>) => {
    const isError: boolean = this.validate();
    this.setState({
      isDropdownOpen: false,
      isOverlay: false,
    });

    if (!isError) {
      const stateParams = this.state;
      const {
        urlLocale,
        SearchNameFromCode,
        SearchNameToCode,
        isSecondarySearchForm,
        router,
      } = this.props;
      const fromLocation = SearchNameFromCode;
      const toLocation = SearchNameToCode;
      const departureDate = format(stateParams.departureDate, 'YYYY-MM-DD');
      const returnDate = format(stateParams.returnDate, 'YYYY-MM-DD');
      const roomsParams = stateParams.rooms;
      let roomString = '';
      for (let i = 0; i < roomsParams.length; i++) {
        const room = roomsParams[i];
        roomString += `&room[${i}]=${room.adults},${room.children.length}`;
        if (Object.prototype.hasOwnProperty.call(room, 'children') && room.children.length > 0) {
          const childrenPax = room.children;
          roomString += `&childAges[${i}]=`;
          for (let j = 0; j < childrenPax.length; j++) {
            roomString += childrenPax[j] + (j + 1 < childrenPax.length ? ',' : '');
          }
        }
      }

      const commonQuery: string = `depart=${departureDate}&return=${returnDate}${roomString}`;
      if (!isSecondarySearchForm) {
        this.setState({
          isPageChanging: true,
        });
      }
      // event tracking for search submit
      track.event(
        router.pathname,
        'Submitted search',
        toLocation,
        {
          from: fromLocation,
          to: toLocation,
          depart: departureDate,
          return: returnDate,
          rooms: roomsParams.length,
        },
      );
      Router.push(
        `/HotelResults?origin=${fromLocation}&destination=${toLocation}&${commonQuery}`,
        `${urlLocale}/search/${fromLocation}/${toLocation}?${commonQuery}`,
      ).then(() => window.scrollTo(0, 0));
    } else {
      e.preventDefault();
    }
  };

  handleChangeDateFrom = (date) => {
    const { configSearchForm } = this.props;
    const { returnDate } = this.state;
    if (differenceInCalendarDays(returnDate, date) >= configSearchForm.minBookingDays) {
      this.setState({
        departureDate: addDays(date, 0),
        returnDate,
      });
    } else {
      this.setState({
        departureDate: addDays(date, 0),
        returnDate: addDays(date, configSearchForm.minBookingDays),
      });
    }
    this.inputReturnRef.current.focus();
  };

  addPassengerRoom = () => {
    const { configSearchForm } = this.props;
    const { rooms } = this.state;
    const sum = a => a.reduce((x, y) => x + y);
    const totalAllPeople = sum(rooms.map(x => Number(x.adults)))
      + sum(rooms.map(h => Number(h.children.length)));

    if (rooms.length >= configSearchForm.maxRooms || totalAllPeople >= configSearchForm.maxPax) {
      return;
    }

    const initRoom = {
      adults: 1,
      children: [],
    };
    rooms.push(initRoom);
    this.setState({ rooms });
  };

  removePassengerRoom = () => {
    const { rooms } = this.state;
    if (rooms.length === 1) {
      return;
    }
    rooms.pop(rooms);
    this.setState({ rooms });
  };

  calculatePassenger = (index, type, amount) => {
    const { configSearchForm } = this.props;
    const { rooms } = this.state;
    const sum = a => a.reduce((x, y) => x + y);
    const totalAllPeople = sum(rooms.map(x => Number(x.adults)))
      + sum(rooms.map(h => Number(h.children.length)));
    const room = rooms[index];
    // const totalAdults = room.adults + room.children.length;
    switch (type) {
      case PAX_TYPE.ADULT:
        if (amount === 1 && totalAllPeople < configSearchForm.maxPax) {
          room.adults += amount;
        } else if (amount === -1) {
          if (room.adults <= 0) {
            return;
          }
          room.adults--;
          if (room.children) {
            // Because children is optional
            if (room.children.filter(c => c < 2).length > room.adults) {
              room.children.splice(room.children.findIndex(c => c < 2), 1);
            }
          }
        }
        rooms[index] = room;
        this.setState({ rooms });
        break;
      case PAX_TYPE.CHILDREN:
        if (amount === 1 && totalAllPeople < configSearchForm.maxPax) {
          if (room.children.length < 3 && room.children.length >= 0) {
            room.children.push(2);
          } else {
            return;
          }
        } else if (amount === -1 && room.children.length > 0) {
          room.children.pop();
        } else {
          return;
        }
        rooms[index] = room;
        this.setState({ rooms });
        break;
      default:
        break;
    }
  };

  selectChildAge = (e, index, childIndex) => {
    const { rooms } = this.state;
    try {
      rooms[index].children[childIndex] = parseInt(e.target.value, 10);
    } catch (err) {
      console.log(err);
    }
    this.setState({ rooms });
  };

  props: SearchFormProps;

  render() {
    const {
      isFetching,
      configSearchForm,
      airportFromData,
      airportToData,
      intl,
      isSecondarySearchForm,
      SearchNameFromSelected,
      SearchNameToSelected,
      searchButtonClass,
      SearchNameFrom,
      SearchNameTo,
    } = this.props;
    const {
      isDropdownOpen,
      departureDate,
      returnDate,
      rooms,
      SearchNameFromError,
      SearchNameToError,
      airportResultCursor,
      isOverlay,
      isPageChanging,
    } = this.state;
    const { formatMessage } = intl;
    let totalPax = 0;
    rooms.forEach((x) => {
      totalPax += x.adults + (typeof x.children !== 'undefined' ? x.children.length : 0);
    });

    const destinationLoading = isSecondarySearchForm
      && !(SearchNameFromSelected || SearchNameToSelected)
      ? 'content-placeholder'
      : '';
    return (
      <div className="search-form">
        <Overlay isOverlay={isOverlay} clicked={this.getPreviousAirport} />
        <div className="search-form__panel">
          <form className="search-form__form">
            <div className="search-form__content">
              <div className="search-form__box search-form__address">
                <InputTextGroup
                  title={formatMessage(defaultMessages.fromTitle)}
                  name="SearchNameFrom"
                  icon={<IconDeparture size={16} />}
                  value={SearchNameFrom}
                  fetching={isFetching}
                  openHandle={this.handleChangeSearch}
                  openDropDown={isDropdownOpen.SearchNameFrom}
                  getLocations={this.getLocations}
                  resultLocation={airportFromData}
                  setLocation={this.setLocationFrom}
                  selected={SearchNameToSelected}
                  errorText={SearchNameFromError}
                  onKeyDown={this.getLocationOnKey}
                  cursorLocation={airportResultCursor}
                  destinationLoading={destinationLoading}
                  tabIndex="0"
                />
                <InputTextGroup
                  title={formatMessage(defaultMessages.toTitle)}
                  name="SearchNameTo"
                  icon={<IconArrival />}
                  value={SearchNameTo}
                  fetching={isFetching}
                  openHandle={this.handleChangeSearch}
                  openDropDown={isDropdownOpen.SearchNameTo}
                  getLocations={this.getLocations}
                  resultLocation={airportToData}
                  selected={SearchNameFromSelected}
                  setLocation={this.setLocationTo}
                  inputRef={this.inputToRef}
                  errorText={SearchNameToError}
                  onKeyDown={this.getLocationOnKey}
                  cursorLocation={airportResultCursor}
                  destinationLoading={destinationLoading}
                  tabIndex="0"
                />
              </div>
              <div className="search-form__box search-form__date">
                <InputDatePicker
                  title={formatMessage(defaultMessages.departTitle)}
                  name="SearchNameDeparture"
                  placeHolder="DD/MM/YYYY"
                  minStartDate={addDays(new Date(), configSearchForm.minBookingDays)}
                  maxStartDate={addDays(new Date(), configSearchForm.maxBookingDays)}
                  openHandle={this.handleChangeSearch}
                  openDropDown={isDropdownOpen.SearchNameDeparture}
                  initDate={departureDate}
                  setDate={this.handleChangeDateFrom}
                  inputRef={this.inputDepartureRef}
                  onKeyDown={this.getLocationOnKey}
                  tabIndex="0"
                />
                <InputDatePicker
                  title={formatMessage(defaultMessages.returnTitle)}
                  placeHolder="DD/MM/YYYY"
                  name="SearchNameReturn"
                  minStartDate={addDays(departureDate, configSearchForm.minBookingPeriod)}
                  maxStartDate={addDays(departureDate, configSearchForm.maxBookingPeriod)}
                  openHandle={this.handleChangeSearch}
                  openDropDown={isDropdownOpen.SearchNameReturn}
                  initDate={returnDate}
                  setDate={this.handleChangeDateTo}
                  inputRef={this.inputReturnRef}
                  onKeyDown={this.getLocationOnKey}
                  tabIndex="0"
                />
              </div>
              <div className="search-form__box search-form__pax">
                <InputPax
                  title={formatMessage(defaultMessages.paxTitle)}
                  name="SearchNamePax"
                  openHandle={this.handleChangeSearch}
                  onKeyDown={this.getLocationOnKey}
                  setPassengers={this.setPassengers}
                  inputRef={this.inputPaxRef}
                  value={formatMessage(defaultMessages.inputValue, {
                    room: rooms.length,
                    people: totalPax,
                  })}
                  tabIndex="0"
                />
              </div>
              <DropdownPax
                title={formatMessage(defaultMessages.paxTitle)}
                openDropDown={isDropdownOpen.SearchNamePax}
                onKeyDown={this.getLocationOnKey}
                rooms={rooms}
                addRoom={this.addPassengerRoom}
                maxRoom={configSearchForm.maxRooms}
                maxAdults={3}
                maxChild={3}
                countTotalOfPax={totalPax}
                maxTotalofRoom={configSearchForm.maxPax}
                removeRoom={this.removePassengerRoom}
                calculatePassenger={this.calculatePassenger}
                selectChildAge={this.selectChildAge}
                message={formatMessage(defaultMessages.maxPaxMessage, {
                  maxPax: configSearchForm.maxPax,
                })}
                tabIndex="0"
              />
            </div>
            <div className="search-form__control">
              <button
                tabIndex="0"
                type="button"
                className={`
                  search-form__button btn-theme-primary btn-effect
                  ${searchButtonClass || ''}
                  ${isPageChanging ? 'page-change' : ''}
                `}
                onClick={this.handleSubmitSearch}
              >
                <span>
                  {formatMessage(defaultMessages.searchButton)}
                </span>
                {isPageChanging && (
                  <i className={`infinite-spin ${isPageChanging ? 'page-change-loader' : ''}`}>
                    <IconLoadingSpinner size={16} />
                  </i>
                )}
              </button>
            </div>
          </form>
        </div>
        <Backdrop isOpen={isPageChanging} isTransparent />
      </div>
    );
  }
}

const mapStateToProps = state => ({
  airportFromData: getAirportFromData(state),
  airportToData: getAirportToData(state),
  SearchNameFrom: getSearchNameFrom(state),
  SearchNameFromCode: getSearchNameFromCode(state),
  SearchNameFromSelected: getSearchNameFromSelected(state),
  SearchNameTo: getSearchNameTo(state),
  SearchNameToCode: getSearchNameToCode(state),
  SearchNameToSelected: getSearchNameToSelected(state),
  isURLParameterAvailable: getIsURLParameterAvailable(state),
  isFetching: getIsFetching(state),
  originListOpenOnClick: getOriginListOpenOnClick(state),
  destinationListOpenOnClick: getDestinationListOpenOnClick(state),
});

// export default injectIntl < SearchFormProps > (SearchForm);

// ComponentBase not able to return jsx attribute
// export default ComponentBase < SearchFormProps > (SearchForm);

const injection: GenericComponent<SearchFormProps> = ComponentBase;

export default injection(SearchForm, {
  mapStateToProps,
  hasCultureCode: true,
  hasUrlLocale: true,
});
