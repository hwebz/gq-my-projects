// @flow
export type FormattedUnitProps = {
  value: number,
  showIfZero: boolean,
  message: string,
};

export type PaddedValueProps = {
  value: number,
};

export type FormattedDurationProps = {
  minutes: number,
  isPadded?: boolean,
};
