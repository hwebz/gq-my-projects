import React from 'react';

// @flow
import { FormattedMessage, injectIntl } from 'react-intl';
import {
  type FormattedUnitProps,
  type PaddedValueProps,
  type FormattedDurationProps,
} from './types';
import messages from './messages';

function FormattedUnit({ value, showIfZero, message }: FormattedUnitProps) {
  if (!value && !showIfZero) {
    return '';
  }

  return (
    <FormattedMessage
      {...messages.duration}
      values={{
        value,
        unit: <FormattedMessage {...message} values={{ value }} />,
      }}
    />
  );
}

function PaddedValue({ value }: PaddedValueProps) {
  return `0${value || '0'}`.substr(-2);
}

function FormattedDuration({ minutes, isPadded = false }: FormattedDurationProps) {
  const fullHours = Math.floor(minutes / 60);
  const fullMinutes = minutes % 60;
  const formattingMessage = messages.format;
  const Component = isPadded ? PaddedValue : FormattedUnit;

  return (
    <FormattedMessage
      {...formattingMessage}
      values={{
        hours: <Component {
          ...
          {
            value: fullHours,
            key: 'hours',
            showIfZero: false,
            message: messages.hoursUnit,
          }
        }
        />,
        minutes: <Component {
          ...
          {
            value: fullMinutes,
            key: 'minutes',
            showIfZero: fullHours === 0,
            message: messages.minutesUnit,
          }
        }
        />,
      }}
    />
  );
}

export default injectIntl(FormattedDuration);
