import { defineMessages } from 'react-intl';

export default defineMessages({
  duration: {
    id: 'DurationFormat.duration',
    defaultMessage: '{value}{unit}',
  },
  format: {
    id: 'DurationFormat.format',
    defaultMessage: '{hours} {minutes}',
  },
  hoursUnit: {
    id: 'DurationFormat.hoursUnit',
    defaultMessage: 'h',
  },
  minutesUnit: {
    id: 'DurationFormat.minutesUnit',
    defaultMessage: 'm',
  },
});
