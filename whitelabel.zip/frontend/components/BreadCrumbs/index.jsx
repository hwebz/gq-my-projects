import React from 'react';
import { FormattedMessage } from 'react-intl';

import './BreadCrumbs.scss';

// icon imports
import { FaBuilding as HotelIcon, FaArrowRight as ArrowIcon } from 'react-icons/fa';
import {
  MdFlight as FlightIcon,
  MdAssignmentTurnedIn as SummaryIcon,
  MdAirlineSeatReclineNormal as PassengerIcon,
  MdPayment as PaymentIcon,
  MdLocalHotel as RoomIcon,
} from 'react-icons/md';

const itemsList = [
  {
    icon: HotelIcon,
    label: <FormattedMessage id="BreadCrumbs.hotels" defaultMessage="Hotels" />,
  },
  {
    icon: RoomIcon,
    label: <FormattedMessage id="BreadCrumbs.rooms" defaultMessage="Rooms" />,
  },
  {
    icon: FlightIcon,
    label: <FormattedMessage id="BreadCrumbs.flights" defaultMessage="Flights" />,
  },
  {
    icon: SummaryIcon,
    label: <FormattedMessage id="BreadCrumbs.summary" defaultMessage="Summary" />,
  },
  {
    icon: PassengerIcon,
    label: <FormattedMessage id="BreadCrumbs.passengers" defaultMessage="Passengers" />,
  },
  {
    icon: PaymentIcon,
    label: <FormattedMessage id="BreadCrumbs.payments" defaultMessage="Payment" />,
    isNonArrow: true,
  },
];

// @flow
const BreadCrumbItem = (props: {
  Icon: React.Component,
  label: JSX.IntrinsicElements,
  currentPage: number,
  isNonArrow: boolean,
  index: number,
}) => {
  const {
    Icon, label, currentPage, isNonArrow, index,
  } = props;
  return (
    <div className="bread-crumbs__item-container">
      <div
        className={`bread-crumbs__item ${
          currentPage >= index + 1 ? 'bread-crumbs--completed' : ''
        } ${currentPage === index + 1 ? 'bread-crumbs--active' : ''}`}
      >
        <Icon size={16} className="icon" />
        <label>
          {label}
        </label>
      </div>
      {!isNonArrow ? (
        <div
          className={`bread-crumbs__arrow ${
            currentPage >= index + 2 ? 'bread-crumbs--completed' : ''
          } `}
        >
          <ArrowIcon size={14} className="icon" />
        </div>
      ) : null}
    </div>
  );
};

const BreadCrumbs = (props: { currentPage: number }) => {
  const { currentPage } = props;
  return (
    <div className="bread-crumbs full-width-container">
      <div className="container bread-crumbs__container">
        {itemsList.map((item, index) => (
          <BreadCrumbItem
            key={`bread_crumb_item_${item.icon}`}
            Icon={item.icon}
            label={item.label}
            currentPage={currentPage}
            isNonArrow={item.isNonArrow}
            index={index}
          />
        ))}
      </div>
    </div>
  );
};

export default BreadCrumbs;
