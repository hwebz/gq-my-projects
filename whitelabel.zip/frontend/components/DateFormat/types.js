// @flow
import { type EDateFormat as Format } from '../../react-next/intl/date-locale';

export type EDateFormat = Format;

export type DateFormatProps = {
  value: string,
  format: EDateFormat,
  locale: string,
};
