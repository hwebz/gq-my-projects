import React from 'react';
import { FormattedMessage } from 'react-intl';

// @flow
import { formatDateString } from 'react-next/intl/date-locale';
import { type DateFormatProps } from './types';

export * from './types';

export default function DateFormat(props: DateFormatProps) {
  // dddd
  // value format is always so YYYY-MM-DD
  const { value, format, locale } = props;
  const values = value ? value.split('-') : [];
  if (values.length !== 3) {
    return (
      <strong>
        <FormattedMessage
          id="DateFormat.invalidDate"
          defaultMessage="Invalid Date Value"
        />
      </strong>
    );
  }

  const year: number = parseInt(values[0], 10);
  const month: number = parseInt(values[1], 10) - 1;
  const day: number = parseInt(values[2], 10);
  const date = new Date(year, month, day);

  const dateString: string = formatDateString(date, format, locale);

  return (
    <span>
      {`${dateString}`}
    </span>
  );
}
