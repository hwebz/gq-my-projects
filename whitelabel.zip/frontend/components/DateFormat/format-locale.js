import enUS from 'date-fns/locale/en';
import zhTW from 'date-fns/locale/zh_tw';
import zhCN from 'date-fns/locale/zh_cn';

const zhHantFormat = {
  fnsLocale: zhTW,
  short: 'MMM DD',
  medium: 'YYYY MMM DD',
  long: 'dddd, YYYY MMM DD',
};

const zhHansFormat = {
  fnsLocale: zhCN,
  short: 'MMM DD',
  medium: 'YYYY MMM DD',
  long: 'dddd, YYYY MMM DD',
};

const format = {
  'en-US': {
    fnsLocale: enUS,
    short: 'DD MMM',
    medium: 'DD MMM YYYY',
    long: 'dddd, DD MMM YYYY',
  },
  'zh-HK': zhHantFormat,
  'zh-TW': zhHantFormat,
  'zh-MO': zhHantFormat,
  'zh-CN': zhHansFormat,
  'zh-SG': zhHansFormat,
};

export default function GetDateFormat(locale) {
  if (format[locale]) {
    return format[locale];
  }
  return format['en-US'];
}
