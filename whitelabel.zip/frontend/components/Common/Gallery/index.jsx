import React from 'react';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';

import Modal from 'react-overlays/lib/Modal';
import ImageGallery from 'react-image-gallery';
import 'react-image-gallery/styles/css/image-gallery.css';
import { MdClose } from 'react-icons/md';
// @flow
import { type GalleryProps } from './types';

import './gallery.scss';
import { getHotelGallery } from '../../../store-app/modules/hotel-gallery/actions';
import {
  getIsGalleryItemsFetching,
  getHotelGalleryItems,
  getHotelGalleryStoppedId,
} from '../../../store-app/modules/hotel-gallery/selectors';
/**
 *
 * @export
 * @param {GalleryProps} {
 *   galleryItems,
 *   handleToggleGallery,
 *   isGalleryOpen,
 * }
 * @returns
 */
class Gallery extends React.Component<GalleryProps> {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {
    const { dispatch, hotelId, hotelGalleryStoppedId } = this.props;
    if (hotelGalleryStoppedId !== hotelId) {
      dispatch(getHotelGallery(hotelId));
    }
  }

  render() {
    const {
      hotelGalleryItems,
      handleToggleGallery,
      isGalleryOpen,
      isGalleryItemsFetching,
      hotelId,
    } = this.props;
    return (
      <Modal
        className="gallery"
        show={isGalleryOpen}
        onBackdropClick={(e) => {
          handleToggleGallery(e, true, hotelId);
        }}
        onEscapeKeyDown={(e) => {
          handleToggleGallery(e, false, '');
        }}
        backdropClassName="gallery__backdrop"
      >
        <div className="gallery__container">
          <i
            className="gallery__close"
            onClick={(e) => {
              handleToggleGallery(e, false, '');
            }}
            role="presentation"
          >
            <MdClose size={30} />
          </i>
          {(isGalleryItemsFetching && (
            <p className="gallery__loading">
              <FormattedMessage id="Gallery.loadingText" defaultMessage="Loading..." />
            </p>
          ))
            || ((hotelGalleryItems.length > 0 && (
              <ImageGallery
                items={hotelGalleryItems}
                showPlayButton={false}
                showIndex
                showFullscreenButton={false}
                additionalClass="gallery__item"
              />
            )) || (
              <p className="gallery__loading">
                <FormattedMessage id="Gallery.noImageText" defaultMessage="Images not available" />
              </p>
            ))}
        </div>
      </Modal>
    );
  }
}

const mapStateToProps = state => ({
  isGalleryItemsFetching: getIsGalleryItemsFetching(state),
  hotelGalleryItems: getHotelGalleryItems(state),
  hotelGalleryStoppedId: getHotelGalleryStoppedId(state),
});

export default connect(mapStateToProps)(Gallery);
