// @flow
import { type GetHotelImageGalleryResponse, type HandleToggleGallery, type Dispatch } from '../../../flow-types';

export type GalleryProps = {
  dispatch: Dispatch,
  hotelGalleryItems: Array<GetHotelImageGalleryResponse>,
  handleToggleGallery: HandleToggleGallery,
  isGalleryOpen: boolean,
  isGalleryItemsFetching: boolean,
  hotelId: number,
};
