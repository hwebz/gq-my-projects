/*
 * @flow
 */
export * from 'flow-types';

// define all the props in Alphabetical order
export type loadingOverlay = {
  msg: string,
};
