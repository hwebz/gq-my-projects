import React from 'react';
// @flow
import { type loadingOverlay } from './types';
import './LoadingAnimation.scss';

function LoadingAnimation({ TimeoutIconSvg, msg }: loadingOverlay) {
  return (
    <div className="common-loader">
      <div className="common-loader__container">
        <div className="common-loader__top">
          <TimeoutIconSvg />
        </div>
        <div className="common-loader__bottom">
          <p>{msg}</p>
          <div className="wrapper-load">
            <div className="loader-line">
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LoadingAnimation;
