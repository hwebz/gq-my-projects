import React from 'react';
import { FormattedMessage } from 'react-intl';
import Router from 'next/router';
import { MdReportProblem, MdPriorityHigh } from 'react-icons/md';
import './CriticalMsgDisplay.scss';
// @flow
import { type criticalMsgDisplay } from './types';


/**
 * Returns alert message
 * @param {CriticalMsgDisplay} { msgType, msg }
 */
function redirect(url) {
  Router.push(url);
}

function CriticalMsgDisplay({ error, type, url }: criticalMsgDisplay) {
  const errorType1 = ['E112', 'E113', 'E222', 'E223']; // redirect to landing page
  const errorType2 = ['E214']; // redirect to 404 page
  const to404Page = errorType2.indexOf(error[0].Code) > -1 ? redirect('/404') : '';
  if (error[0].Code === 'E111' && url) {
    redirect(url);
  }
  const toLandingPage = errorType1.indexOf(error[0].Code) > -1 ? '/' : '';
  return (
    <div className={`critical-alert critical-alert__${type}`} role="alert">
      <div className="alert-msg">
        <h4 className="msg-title">
          {error[0].Code}
        </h4>
        <p className="msg-content">
          { toLandingPage && (
            <FormattedMessage
              id="CriticalMsgDisplay.msgToLanding"
              defaultMessage="{errorCode}: {errorValue}, Please {link}"
              values={{
                errorCode: error[0].Code,
                errorValue: error[0].Value,
                /* eslint-disable */
                link: <a href={toLandingPage}>search again</a>
                /* eslint-enable */
              }}
            />
          ) || to404Page && (
            <FormattedMessage
              id="CriticalMsgDisplay.msgTo404"
              defaultMessage="{errorCode}: {errorValue}, Sorry we couldn&apos;t fullfil your request."
              values={{
                errorCode: error[0].Code,
                errorValue: error[0].Value,
              }}
            />
          ) || (
            <FormattedMessage
              id="CriticalMsgDisplay.errorMsg"
              defaultMessage="{errorCode}: {errorValue}"
              values={{
                errorCode: error[0].Code,
                errorValue: error[0].Value,
              }}
            />)
          }
        </p>
      </div>
      <div className="alert-icon">
        <span>
          { error[0].Code === 'RES-0' && (
            <MdPriorityHigh className="error-icon" />
          ) || (
            <MdReportProblem className="error-icon" />
          )}
        </span>
      </div>
    </div>
  );
}

export default CriticalMsgDisplay;
