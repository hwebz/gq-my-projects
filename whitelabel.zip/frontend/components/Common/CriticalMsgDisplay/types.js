/*
 * @flow
 */
import { type Node } from 'react';

export * from 'flow-types';

// define all the props in Alphabetical order
export type criticalMsgDisplay = {
  msgType: string,
  msg: Node,
};
