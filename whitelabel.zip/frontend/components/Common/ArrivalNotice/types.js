// @flow
export type ArrivalNoticeProps = {
  arrivalDate: string,
  hotelNights: number,
  nightsCount: number,
};
