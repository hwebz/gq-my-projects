import React from 'react';

// @flow
import { FormattedMessage, injectIntl } from 'react-intl';
import { type ArrivalNoticeProps } from './types';

function ArrivalNotice({ arrivalDate, hotelNights, nightsCount }: ArrivalNoticeProps) {
  return (
    <FormattedMessage
      id="ArrivalNotice.arrivalNotice"
      defaultMessage={
        'Flight arrives {arrivalDate}; package includes {hotelNightsText} instead of {nightsCount}.'
      }
      values={{
        arrivalDate,
        nightsCount,
        hotelNightsText: <FormattedMessage
          id="ArrivalNotice.hotelNightsText"
          defaultMessage={'{hotelNights, plural, one {# hotel night} other {# hotel nights}}'}
          values={{ hotelNights }}
        />,
      }}
    />
  );
}

export default injectIntl(ArrivalNotice);
