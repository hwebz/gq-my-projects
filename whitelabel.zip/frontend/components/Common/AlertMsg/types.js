/*
 * @flow
 */
import { type Node } from 'react';

export * from 'flow-types';

// define all the props in Alphabetical order
export type AlertMsgProps = {
  msgType: string,
  msg: Node,
};
