// @flow

import React from 'react';
import './AlertMsg.scss';
import { type AlertMsgProps } from './types';

/**
 * Returns alert message
 * @param {AlertMsgProps} { msgType, msg }
 */
function AlertMsg({ msgType, msg }: AlertMsgProps) {
  return (
    <div className={`alert alert__${msgType}`} role="alert">
      {msg}
    </div>
  );
}

export default AlertMsg;
