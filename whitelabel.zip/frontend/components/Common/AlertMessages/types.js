// @flow

export type AlertMsgProps = {
  errors: Object,
  messageFormatter?: (message: string) => Object | string,
};
