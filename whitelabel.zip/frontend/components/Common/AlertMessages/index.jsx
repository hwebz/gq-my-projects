// @flow
// This will display an array of AlertMsg
import React from 'react';
import { type AlertMsgProps } from './types';
import AlertMsg from '../AlertMsg';

function defaultFormatter(message: string): string {
  return message;
}

function generateErrors(
  errors: Object,
  messageFormatter?: (message: string) => Object | string = defaultFormatter,
) {
  // Fallback Checking
  return Object.values(errors)
    .filter((value: any) => !value.status)
    .map((value: any) => <AlertMsg msgType="danger" msg={messageFormatter(value.message)} />);
}

function AlertMessages({ errors, messageFormatter }: AlertMsgProps) {
  return (
    <div className="container">
      {messageFormatter
        ? generateErrors(errors, messageFormatter)
        : generateErrors(errors)}
    </div>
  );
}

export default AlertMessages;
