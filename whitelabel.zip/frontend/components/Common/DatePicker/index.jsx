import React from 'react';
import DayPicker from 'react-day-picker';

// @flow
// TODO: use index.js to wrap as one module with selectors actionTypes and etc.
// import actionTypes from '../../../modules/locale-selection/action-types';
import { dayPickerLocaleUtils } from 'react-next/intl/date-locale';

import './_datepicker.scss';
import ComponentBase, { type GenericComponent } from '../../ComponentBase';
import { type DatePickerProps } from './types';

function DatePicker(props: DatePickerProps) {
  const {
    cultureCode,
    changeYear,
    changedMonth,
    changed,
    selected,
    minStartDate,
    maxStartDate,
  } = props;

  return (
    <DayPicker
      locale={cultureCode || 'en-US'}
      localeUtils={dayPickerLocaleUtils}
      month={new Date(changeYear, changedMonth)}
      onDayClick={changed}
      selectedDays={[new Date(selected)]}
      disabledDays={[
        {
          before: new Date(minStartDate),
          after: new Date(maxStartDate),
        },
      ]}
    />
  );
}

const injection: GenericComponent<DatePickerProps> = ComponentBase;

export default injection(DatePicker, { hasCultureCode: true });
