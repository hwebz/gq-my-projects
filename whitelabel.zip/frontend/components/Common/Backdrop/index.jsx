import React from 'react';

import './backdrop.scss';

// @flow
import { type BackdropProps } from './types';

/**
 *
 * @param {BackdropProps} props
 * @returns
 */
const Backdrop = (props: BackdropProps) => {
  const {
    isOpen,
    onClick,
    isTransparent,
    ...rest
  } = props;
  return (
    <div
      className={`popup-backdrop ${isOpen ? 'open' : ''} ${isTransparent ? 'popup-backdrop--transparent' : ''}`}
      onClick={onClick}
      role="presentation"
      {...rest}
    />
  );
};

export default Backdrop;
