// @flow
export type BackdropProps = {
  isOpen: boolean,
  onClick: (e: SyntheticEvent<HTMLDivElement>) => void,
};
