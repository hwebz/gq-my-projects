import React from 'react';

// @flow
import { FormattedMessage, injectIntl } from 'react-intl';
import {
  type HotelBoardTextProps,
} from './types';
import messages from './messages';

function HotelBoardText({ boardType }: HotelBoardTextProps) {
  const formattingMessage = messages[`text${boardType}`];
  return (
    formattingMessage && (
      <FormattedMessage
        {...formattingMessage}
      />
    ) || (
      <span />
    )
  );
}

export default injectIntl(HotelBoardText);
