import { defineMessages } from 'react-intl';

export default defineMessages({
  text1: {
    id: 'HotelBoardText.roomOnly',
    defaultMessage: 'Room only',
  },
  text2: {
    id: 'HotelBoardText.breakfast',
    defaultMessage: 'Breakfast',
  },
  text3: {
    id: 'HotelBoardText.halfBoard',
    defaultMessage: 'Half board',
  },
  text4: {
    id: 'HotelBoardText.fullBoard',
    defaultMessage: 'Full board',
  },
  text5: {
    id: 'HotelBoardText.allInclusive',
    defaultMessage: 'All Inclusive',
  },
  text6: {
    id: 'HotelBoardText.selfCatering',
    defaultMessage: 'Self-catering',
  },
});
