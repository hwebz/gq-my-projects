// @flow
export type HotelBoardTextProps = {
  boardType: number,
};
