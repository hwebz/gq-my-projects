// This is being eslint-disabled because of the path d tab issue
import React from 'react';
import './JumpingShapes.scss';

function JumpingShapes() {
  return (
    <div id="holder">
      <div id="viewport">
        <div className="subviewport expl">
          <div id="explosion">
            <div id="explosion-circle" />
          </div>
        </div>
        <div className="subviewport red">
          <div className="circles">
            <div className="circle-top" />
            <div className="circle-top" />
            <div className="circle-top" />
            <div className="circle-top" />
          </div>
        </div>
        <div className="hexagon dude">
          <div className="face" />
        </div>
        <div className="subviewport orange">
          <div className="circles">
            <div className="circle-top" />
            <div className="circle-top" />
            <div className="circle-top" />
            <div className="circle-top" />
          </div>
        </div>


        <div className="box dude">
          <div className="face" />
        </div>

        <div className="subviewport green">
          <div className="circles">
            <div className="circle-top" />
            <div className="circle-top" />
            <div className="circle-top" />
            <div className="circle-top" />
            <div className="circle-top" />
          </div>
        </div>

        <div className="rectangle dude">
          <div className="face" />
        </div>

        <div className="subviewport blue">
          <div className="circles">
            <div className="circle-top" />
            <div className="circle-top" />
            <div className="circle-top" />
            <div className="circle-top" />
            <div className="circle-top" />
            <div className="circle-top" />
            <div className="circle-top" />
            <div className="circle-top" />
          </div>
        </div>

        <div className="circle dude">
          <div className="face" />
        </div>
      </div>
    </div>
  );
}
export default JumpingShapes;
