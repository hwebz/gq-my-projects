module.exports = {
  plugins: [
    // Reason not to add at devDependencies is the concern of browserlist conflict
    // Should investigate this matter
    // 'autoprefixer' should be listed in the project's dependencies.
    // Run 'npm i -S autoprefixer' to add it
    // eslint-disable-next-line
    require('autoprefixer')({}),
  ],
};
