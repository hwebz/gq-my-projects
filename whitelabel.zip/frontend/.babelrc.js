const env = require('./env-config.js');
const kebabCase = require('kebab-case');

const transformImports = {
  'react-icons/?(((\\w*)?/?)*)': {
    transform: function(importName, matches) {
      const name = kebabCase(importName)
        .replace(matches[1], '')
        .replace('--', '');
      return `react-icons/lib/${matches[1]}/${name}`;
    },
  },
};

const prod = {
  presets: [
    [
      'next/babel',
      {
        'preset-env': {
          useBuiltIns: 'usage',
          modules: 'commonjs',
        },
      },
    ],
  ],
  plugins: [
    'transform-flow-strip-types',
    'styled-jsx/babel',
    ['react-intl', { messagesDir: './messages/.translation-dictionary/' }],
    ['transform-define', env],
    [
      'module-resolver',
      {
        root: ['./'],
        alias: {
          components: './components',
          'react-next': './react-next',
          services: './services',
          'flow-types': './flow-types',
          'store-app': './store-app',
        },
      },
    ],
    ['inline-react-svg'],
    ['transform-imports', transformImports],
    ["transform-remove-console"],
  ],
  retainLines: true,
};

const dev = {
  presets: [
    [
      'next/babel',
      {
        'preset-env': {
          useBuiltIns: 'usage',
          modules: 'commonjs',
        },
      },
    ],
  ],
  plugins: [
    'transform-flow-strip-types',
    'styled-jsx/babel',
    ['react-intl', { messagesDir: './messages/.translation-dictionary/' }],
    ['transform-define', env],
    [
      'module-resolver',
      {
        root: ['./'],
        alias: {
          components: './components',
          'react-next': './react-next',
          services: './services',
          'flow-types': './flow-types',
          'store-app': './store-app',
        },
      },
    ],
    ['inline-react-svg'],
    ['transform-imports', transformImports],
  ],
  retainLines: true,
};
module.exports = {
  env: {
    development: dev,
    production: prod,
    test: {
      presets: [
        ['next/babel', { 'preset-env': { modules: 'commonjs' } }]
      ],
      plugins: [
        'transform-flow-strip-types',
        'styled-jsx/babel',
        ['react-intl', { messagesDir: './messages/.translations/' }],
        [
          'module-resolver',
          {
            root: ['./'],
            alias: {
              components: './components',
              'react-next': './react-next',
              services: './services',
              'flow-types': './flow-types',
              'store-app': './store-app',
            },
          },
        ],
        ['inline-react-svg'],
        ['transform-imports', transformImports],
      ],
      retainLines: true,
    },
  },
};

// optimizeForSpeed  When in production* this mode is automatically enabled.
// Beware that when using this option source maps cannot be generated and styles cannot be edited via the devtools.
