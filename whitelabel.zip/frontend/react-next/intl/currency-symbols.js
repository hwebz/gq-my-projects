// @flow

import Sentry from '../../client-error';

const currencySymbols = {
  MYR: {
    symbol: 'RM',
    isSymbolAfter: false,
  },
  USD: {
    symbol: '$',
    isSymbolAfter: false,
  },
  SGD: {
    symbol: 'SGD',
    isSymbolAfter: false,
  },
  JPY: {
    symbol: '¥',
    isSymbolAfter: true,
  },
  EUR: {
    symbol: '€',
    isSymbolAfter: false,
  },
  RMB: {
    symbol: '¥',
    isSymbolAfter: false,
  },
};

export function getCurrencySymbol(currency: string): string {
  if (currencySymbols[currency]) {
    return currencySymbols[currency].symbol;
  }
  Sentry.captureException(
    new Error(`Symbol for currency ${currency} is not found, fallback to blank.`),
  );
  return ''; // Fall back to blank to avoid user's misunderstanding
}

export function isCurrencySymbolAfter(currency: string): boolean {
  if (currencySymbols[currency]) {
    return currencySymbols[currency].isSymbolAfter;
  }
  return false; // default is false
}

/**
 * getCurrencyText is being used for components needed NumberFormat Component
 * in string format.
 * @param  {string} locale
 * @param  {string} currency
 * @param  {number} value
 * @returns string
 */
export function getCurrencyText(locale: string, currency: string, value: number): string {
  const formattedNumber = new Intl.NumberFormat(locale).format(value);

  if (isCurrencySymbolAfter(currency)) {
    return `${formattedNumber} ${getCurrencySymbol(currency)}`;
  }
  return `${getCurrencySymbol(currency)} ${formattedNumber}`;
}

export function shortenLargePrice(num) {
  const units = ['k', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
  let decimal;
  for (let i = units.length - 1; i >= 0; i--) {
    /* eslint-disable no-restricted-properties */
    decimal = Math.pow(1000, i + 1);
    if (num <= -decimal || num >= decimal) {
      return +(num / decimal).toFixed(1) + units[i];
    }
  }

  return num;
}
