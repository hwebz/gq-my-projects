// @flow
import Sentry from '../../client-error';

const currenciesName = {
  'en-US': {
    MYR: 'Malaysian Ringgit',
    USD: 'US Dollar',
    SGD: 'Singapore Dollar',
    JPY: 'Japanese Yen',
    EUR: 'Euro',
    RMB: 'Ren Min Bi',
  },
  'zh-HK': {
    MYR: '馬幣',
    USD: '美金',
    SGD: '新幣',
    JPY: '日圓',
    EUR: '歐元',
    RMB: '人民幣',
  },
};

export default function GetCurrencyName(locale: string, currency: string) {
  const currencyLocales = Object.keys(currenciesName);
  let currentLocale = 'en-US';
  if (!locale || currencyLocales.indexOf(locale) === -1) {
    Sentry.captureException(new Error(`Locale ${locale} is not found, fallback to en-US`));
  } else {
    currentLocale = locale;
  }

  if (currenciesName[currentLocale][currency]) {
    return currenciesName[currentLocale][currency];
  }
  if (currenciesName['en-US'][currency]) {
    Sentry.captureException(
      new Error(`Translation for locale ${currentLocale} and currency ${currency} is not found, fallback to its translation in en-US`),
    );
    return currenciesName['en-US'][currency];
  }

  Sentry.captureException(
    new Error(`Translation for locale en-US and currency ${currency} is not found, fallback to blank`),
  );
  return '';
}
