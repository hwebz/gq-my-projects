import { format as dateFormatter } from 'date-fns';
import en from 'date-fns/locale/en';
import zhTW from 'date-fns/locale/zh_tw';
import zhCN from 'date-fns/locale/zh_cn';

// @flow
export type EDateFormat = 'SHORT' | 'MEDIUM' | 'LONG';

const enFormat = {
  fnsLocale: en,
  short: 'DD MMM',
  medium: 'DD MMM YYYY',
  long: 'dddd, DD MMM YYYY',
};

const zhHantFormat = {
  fnsLocale: zhTW,
  short: 'MMM DD',
  medium: 'YYYY MMM DD',
  long: 'dddd, YYYY MMM DD',
};

const zhHansFormat = {
  fnsLocale: zhCN,
  short: 'MMM DD',
  medium: 'YYYY MMM DD',
  long: 'dddd, YYYY MMM DD',
};

const format = {
  'en-US': enFormat,
  'zh-HK': zhHantFormat,
  'zh-TW': zhHantFormat,
  'zh-MO': zhHantFormat,
  'zh-CN': zhHansFormat,
  'zh-SG': zhHansFormat,
};

// locale later use Enum
export function getDateFormat(locale: string) {
  if (format[locale]) {
    return format[locale];
  }
  return format['en-US'];
}

export function formatDateString(date: Date, lengthFormat: EDateFormat, locale: string) {
  const dateFormat = getDateFormat(locale);
  let dateString: string = '';

  if (lengthFormat === ('LONG': Format)) {
    dateString = dateFormatter(date, dateFormat.long, { locale: dateFormat.fnsLocale });
  } else if (lengthFormat === ('MEDIUM': Format)) {
    dateString = dateFormatter(date, dateFormat.medium, { locale: dateFormat.fnsLocale });
  } else if (lengthFormat === ('SHORT': Format)) {
    dateString = dateFormatter(date, dateFormat.short, { locale: dateFormat.fnsLocale });
  }

  return dateString;
}

const dayDates = [
  new Date(2018, 3, 1), // This is Sunday
  new Date(2018, 3, 2),
  new Date(2018, 3, 3),
  new Date(2018, 3, 4),
  new Date(2018, 3, 5),
  new Date(2018, 3, 6),
  new Date(2018, 3, 7),
];

export function formatDay(d: Date, locale: string = 'en-US') {
  // Using Medium Format
  const dateString = formatDateString(d, ('MEDIUM': Format), locale);
  return dateString;
}

export function formatMonthTitle(d: Date, locale: string = 'en-US') {
  const dateFormat = getDateFormat(locale);
  return dateFormatter(d, 'MMMM YYYY', { locale: dateFormat.fnsLocale });
}

export function formatWeekdayShort(i: number, locale: string = 'en-US') {
  const dateFormat = getDateFormat(locale);
  return dateFormatter(dayDates[i], 'dd', { locale: dateFormat.fnsLocale });
}

export function formatWeekdayLong(i: number, locale: string = 'en-US') {
  const dateFormat = getDateFormat(locale);
  return dateFormatter(dayDates[i], 'dddd', { locale: dateFormat.fnsLocale });
}

// Disable because locale will still be used in future
// eslint-disable-next-line
export function getFirstDayOfWeek(locale: string = 'en-US') {
  // Not Supported By date-fns, waiting version 2
  return 0;
}

export const dayPickerLocaleUtils = {
  formatDay,
  formatMonthTitle,
  formatWeekdayShort,
  formatWeekdayLong,
  getFirstDayOfWeek,
};
