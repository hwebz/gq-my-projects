/**
 * Board type labels (for internal use, e.g.
 * Google Analytics tracking).
 * For internationalized texts, use the HotelBoardText component.
 */
const BoardType = Object.freeze({
  'Room only': 1,
  Breakfast: 2,
  'Half board': 3,
  'Full board': 4,
  'All Inclusive': 5,
  'Self-catering': 6,
});

export default BoardType;
