// @flow
/**
 * Find common elements in arrayOne and arrayTwo and
 * return the common elements in new array
 * @param  {Array<T>} arrayOne
 * @param  {Array<T>} arrayTwo
 * @returns Array
 */
function findCommonElements<T>(arrayOne: Array<T>, arrayTwo: Array<T>): Array<T> {
  if (!Array.isArray(arrayOne) || !Array.isArray(arrayTwo)) {
    return [];
  }

  const array: Array<T> = [];
  for (let i = 0; i < arrayOne.length; i++) {
    if (arrayTwo.includes(arrayOne[i])) {
      array.push(arrayOne[i]);
    }
  }
  return array;
}

/**
 * Returns a new set of array of strings which is being lower cased
 * @param  {Array<string>} array
 * @returns Array
 */
function toLowerCase(array: Array<string>): Array<string> {
  // ArrayUtils.toLowerCase = (array) => {
  if (!Array.isArray(array)) {
    return [];
  }

  const returnArray: Array<string> = [];
  for (let i = 0; i < array.length; i++) {
    if (typeof array[i] === 'string') {
      returnArray.push(array[i].toLowerCase());
    }
  }

  return returnArray;
}
/**
 * Parse an array of string to array of integer
 * @param  {Array<string>} array
 */
function parseIntArray(array: Array<string>) {
  const returnArray: Array<number> = [];
  for (let i = 0; i < array.length; i++) {
    returnArray.push(parseInt(array[i], 10));
  }
  return returnArray;
}

function clone<T>(array: Array<T>): Array<T> {
  if (typeof array === 'undefined') {
    return [];
  }

  const returnArray: Array<T> = [];
  for (let i = 0; i < array.length; i++) {
    returnArray.push(array[i]);
  }
  return returnArray;
}

/**
 * Generates sequence of numbers
 * @param {number} [start=0]
 * @param {number} end
 * @param {number} [step=1]
 * @returns {Array<number>}
 */
function range(
  start: number = 0,
  end: number,
  step: number = 1,
): Array<number> {
  const length = (end - start) / step;
  return Array.from({ length }, (_, i) => start + (i * step));
}

/**
 * Outputs list of an attribute in a collection of objects
 * @param {Array<Object>} collection
 * @param {string} attribute
 * @returns {Array<T>}
 */
function getAttributeList(
  collection: Array<Object>,
  attribute: string,
): Array<T> {
  const list = [];
  collection.forEach((item) => {
    if (item[attribute] && !list.includes(item[attribute])) {
      list.push(item[attribute]);
    }
  });
  return list;
}

module.exports = {
  toLowerCase,
  findCommonElements,
  parseIntArray,
  clone,
  range,
  getAttributeList,
};
