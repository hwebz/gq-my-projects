// @flow
import ValidationUtils from 'react-next/utils/validation-utils';
import { type ClientSentryOption, type SentryUserOption } from './types';

// $FlowIgnore ignore because module not found
const Sentry = require('@sentry/browser');

class ErrorHandlerBrowser {
  // System Variables
  isOn: boolean;
  isInit: boolean;

  // Basic Configurations
  dsn: string;
  environment: string;
  release: string;
  errorMap: Map<string, Object>;

  // Additional Options
  configOption: ClientSentryOption;
  userOption: SentryUserOption;
  tagsMap: Map<string, string>;

  constructor(
    dsn: string,
    environment: string,
    release: string,
    errorMap: Map<string, Object>,
    configOption?: ClientSentryOption = {},
    userOption: SentryUserOption = {},
    tagsMap: Map<string, string> = new Map(),
  ) {
    this.isOn = true;
    this.isInit = false;

    this.dsn = dsn;
    this.environment = environment;
    this.release = release;
    this.errorMap = errorMap;

    this.configOption = configOption;
    this.userOption = userOption;
    this.tagsMap = tagsMap;

    // Set Sentry Variables and value validation
    if (this.configOption.sampleRate) {
      if (this.configOption.sampleRate < 0) {
        this.configOption.sampleRate = 0.0;
      } else if (this.configOption.sampleRate > 1) {
        this.configOption.sampleRate = 1.0;
      }
    }
    this.configOption.release = release;
    this.configOption.environment = environment;
  }

  init() {
    // Just In Case
    if (this.dsn && this.isOn) {
      this.isInit = true;
      Sentry.init({
        dsn: this.dsn,
        ...this.configOption,
      });
      Sentry.configureScope((scope) => {
        ErrorHandlerBrowser.handleTags(scope, this.tagsMap);
        // TODO: user option Sentry has type
        if (!ValidationUtils.isEmptyOrZero(this.userOption)) {
          scope.setUser(this.userOption);
        }
      });
    }
  }

  // TODO: is Scope type
  static handleTags(scope: Object, tags: Map<string, string>) {
    tags.forEach((value, key) => {
      scope.setTag(key, value);
    });
  }

  log(message: string, level: string, tags?: Map<string, string> = new Map()) {
    if (this.isOn && this.dsn) {
      if (!this.isInit) {
        this.init();
      }
      Sentry.withScope((scope) => {
        ErrorHandlerBrowser.handleTags(scope, tags);
        scope.setLevel(level);
        Sentry.captureException(new Error(message));
      });
    }
  }

  logInfo(message: string, tags?: Map<string, string> = new Map()) {
    this.log(message, 'info', tags);
  }

  logWarning(message: string, tags?: Map<string, string> = new Map()) {
    this.log(message, 'warning', tags);
  }

  logDebug(message: string, tags?: Map<string, string> = new Map()) {
    this.log(message, 'debug', tags);
  }

  logError(message: string, tags?: Map<string, string> = new Map()) {
    this.log(message, 'error', tags);
  }

  captureException(error: Object, errorInfo?: Object = {}) {
    if (this.isOn && this.dsn) {
      if (!this.isInit) {
        this.init();
      }

      Sentry.withScope((scope) => {
        Object.keys(errorInfo).forEach((key) => {
          scope.setExtra(key, errorInfo[key]);
        });
        Sentry.captureException(error);
      });
    }
  }
}

export default ErrorHandlerBrowser;
