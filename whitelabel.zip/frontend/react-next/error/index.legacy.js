// Future: Interface different Error Handlers, now this purely handle Sentry Errors
const Raven = require('raven-js');

// @flow
class ErrorHandler {
  dsn: string;
  environment: string;
  release: string;
  errorMap: Map<string, Object>;
  isOn: boolean;
  isInstalled: boolean;

  constructor(
    dsn: string,
    environment: string,
    release: string,
    errorMap: Map<string, Object>,
    options: Object = {},
  ) {
    this.dsn = dsn;
    this.environment = environment;
    this.release = release;
    this.errorMap = errorMap;
    this.options = options;
    this.isOn = true;
    this.isInstalled = false;

    // Set Sentry Variables
    this.options.release = release;
    this.options.environment = environment;
  }

  install() {
    // Just In Case
    if (this.dsn && this.isOn) {
      this.isInstalled = true;
      Raven.config(this.dsn, this.options).install();
    }
  }


  log(message, tag = {}, options = {}) {
    if (this.isOn && this.dsn) {
      if (!this.isInstalled) {
        this.install();
      }

      const tagParams = { environment: this.environment, ...tag };
      Raven.captureMessage(message, { tag: tagParams, ...options });
    }
  }

  logInfo(message, tag = {}) {
    this.log(message, tag, { level: 'info' });
  }

  logWarning(message, tag = {}) {
    this.log(message, tag, { level: 'warning' });
  }

  logDebug(message, tag = {}) {
    this.log(message, tag, { level: 'debug' });
  }

  logError(message, tag = {}) {
    this.log(message, tag, { level: 'error' });
  }

  captureException(error, extra) {
    if (this.isOn && this.dsn) {
      if (!this.isInstalled) {
        this.install();
      }
      Raven.captureException(error, extra);
    }
  }

  // eslint-disable-next-line
  getRaven() {
    return Raven;
  }
}

module.exports = ErrorHandler;
