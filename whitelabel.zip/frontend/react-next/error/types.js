// @flow
// Provide Sentry Options
export type RequestBodiesOption = 'never' | 'small' | 'medium' | 'always';

export type SentryUserOption = {
  id?: string,
  username?: string,
  email?: string,
  ip_address?: string,
}

export type SentryConfigOption = {
  debug?: boolean,
  release?: string,
  environment?: string,
  sampleRate?: number,
  maxBreadcrumbs?: number,
  attachStacktrace?: boolean,
  sendDefaultPii?: boolean,
}

export type ClientSentryOption = SentryConfigOption & {
  blacklistUrls?: Array<string>,
  whitelistUrls?: Array<string>,
  requestBodies?: RequestBodiesOption,
  withLocals?: boolean,
}
