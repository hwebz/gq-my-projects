// @flow

export type InitialProps = {
  // Put in the props for initial props - need to
  pageProps: {
    locale: string,
    messages: Object,
    localeDataScript: string,
  },
}

export type NextWindow = {
  __NEXT_DATA__: {
    props: {
      initialProps: InitialProps,
    }
  },
  ReactIntlLocaleData: Object,
};

export type Message = {
  id: string,
  defaultMessage: string,
};
