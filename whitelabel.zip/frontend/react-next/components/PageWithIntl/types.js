// @flow

export type PageWithIntlProps = {
  locale: string,
  localeDataScript: string,
  messages: Map<string, string>, // Later Check the type
  now: Date,
};
