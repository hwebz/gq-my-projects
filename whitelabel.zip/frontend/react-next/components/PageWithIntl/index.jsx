// @flow

import React, { type ComponentType } from 'react';
import { IntlProvider, addLocaleData, injectIntl } from 'react-intl';

import IntlUtils from 'react-next/utils/intl-utils';
import ComponentUtils from 'react-next/utils/component-utils';

import { type PageWithIntlProps } from './types';
import { type NextWindow } from '../../flow-types';

// Register React Intl's locale data for the user's locale in the browser. This
// locale data was added to the page by `pages/_document.js`. This only happens
// once, on initial page load in the browser.
if (typeof window !== 'undefined' && window.ReactIntlLocaleData) {
  const windowObject: NextWindow = window;
  Object.keys(windowObject.ReactIntlLocaleData).forEach((lang) => {
    addLocaleData(windowObject.ReactIntlLocaleData[lang]);
  });
}

export default (Page: ComponentType<*>) => {
  const IntlPage = injectIntl(Page);

  return class PageWithIntl extends React.Component<PageWithIntlProps> {
    static async getInitialProps(context: any) {
      // Important Note
      let props;

      // $FlowIgnore ignore as it is to check if the property exist
      if (typeof Page.getInitialProps === 'function') {
        props = await Page.getInitialProps(context); // This will call pages getInitialProps
      }

      // Get the `locale` and `messages` from the request object on the server.
      // In the browser, use the same values that the server serialized.
      const {
        ctx: { req },
      } = context;

      const { locale, messages, localeDataScript } = req
        || ComponentUtils.getWindowInitialPageProps().pageProps;

      // Always update the current time on page load/transition because the
      // <IntlProvider> will be a new instance even with pushState routing.
      const now = Date.now();

      return {
        locale,
        localeDataScript,
        messages,
        now,
        ...props,
      };
    }

    render() {
      const {
        locale, localeDataScript, messages, now, ...props
      } = this.props;

      return (
        // React Locale Data Script Slightly Different
        <IntlProvider
          locale={IntlUtils.cultureCodeToReactLocale(locale)}
          messages={messages}
          initialNow={now}
          defaultLocale="en-US"
        >
          <IntlPage {...props} />
        </IntlProvider>
      );
    }
  };
};
