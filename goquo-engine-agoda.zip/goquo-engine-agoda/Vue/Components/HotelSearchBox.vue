<template>
    <div>
        <form method="GET" action="/package/start-search" data-val="true" @submit="onValidate">
            <div class="search-grid">
                <AjaxSelect name="To" 
                            :placeholder="translateText('CHOOSE_A_DESTINATION', 'Choose a destination, property name or address....')" 
                            :defaultValue="to" :defaultText="toCityName" 
                            type="hotel" 
                            :txtLabel="translateText('WHERE_ARE_YOU_GOING', 'Where are you going?')" 
                            icon="ico icon-map-marker"
                            :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_DESTINATION', 'Please choose a valid destination')"
                            @onValidate="onValidate"
                            :url="'/api/search-regions'" />
                <DateRangePicker v-model="defaultDate" journeyType="1" date-format="DD/MM/YYYY" />
                <PaxSelector :maxRooms="5" :isHotelOnly="true"/>
            </div>
            <div class="search-button-wrap">
                <input type="hidden" name="OrderId" :value="packageQuery && packageQuery.orderId ? packageQuery.orderId : ''">
                <input type="hidden" name="Currency" :value="packageQuery && packageQuery.currency ? packageQuery.currency : 'USD'">
                <input type="hidden" name="ProductId" :value="product.id" />
                <button type="submit" class="bt-search bt-effect">
                    <span class="text-uppercase" v-lang.SEARCH_HOTELS></span>
                </button>
            </div>
        </form>
    </div>
</template>

<script>
    import AjaxSelect from './AjaxSelect.vue'
    import DateRangePicker from './DateRangePicker.vue'
    import PaxSelector from './PaxSelector.vue'

    export default {
        data() {
            return {
                DepartureDate: null,
                ReturnDate: null,
                maxRooms: 3,
            }
        },
        computed: {
        },
        created() {
            var self = this;
        },
        methods: {
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            validateInput(context) {
                var parent = context.parents('.box-search');
                var label = parent.find(">strong");
                var labelVals = {
                    old: context.attr('data-label'),
                    new: context.attr('data-required-message')
                };

                if (!context.val()) {
                    parent.addClass('error');
                    label.text(labelVals.new);
                    return false;
                } else {
                    parent.removeClass('error');
                    label.text(labelVals.old);
                }
                return true;
            },
            onValidate(e) {
                var self = this;
                var box = $(self.$el)
                var errors = 0;
                box.find("input[name='From']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                box.find("input[name='To']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                if (errors == 0) {
                    return true;
                }
                if (e) e.preventDefault();
            },
            translateText(translateKey, defaultText, params) {
                return this.translate(this.$language, translateKey, params) || defaultText;
            }
        },
        props: ['product', 'defaultDate', 'to', 'toCityName', 'packageQuery'],
        components: {AjaxSelect, DateRangePicker, PaxSelector}
    }

</script>
