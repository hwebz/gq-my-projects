<template>
    <div class="box-search dropdown" :class="{'flight-only': isFlightOnly || isTourOnly || isTourResult}">
        <strong v-if="isFlightOnly" v-lang.MAX_PASSENGERS></strong>
        <strong v-else v-lang.GUESTS></strong>
        <div class="search-input dropdown-toggle" data-toggle="dropdown">
            <i class="ico icon-user"></i>
            <div class="ipt-show" v-if="maxRooms == 1">
                <small v-if="!isTourOnly && !isTourResult" v-lang.ONE_ROOM></small>
                <span v-if="calculatePaxCount() > 1" v-lang.X_PASSENGERS="{0: calculatePaxCount()}"></span>
                <span>{{calculatePaxCount()}} {{calculatePaxCount() > 1 ? translateText('X_PASSENGERS', 'Pax(s)') : translateText('X_PASSENGER', 'Pax')}}</span>
            </div>
            <div class="ipt-show" v-else>
                <small v-if="!isFlightOnly && (!isTourOnly && !isTourResult)">{{paxInfos.length}} {{paxInfos.length > 1 ? translateText('ROOMS', 'Rooms') : translateText('ROOM', 'Room')}}</small>
                <span>{{calculatePaxCount()}} {{calculatePaxCount() > 1 ? translateText('X_PASSENGERS', 'Pax(s)') : translateText('X_PASSENGER', 'Pax')}}</span>
            </div>
        </div>
        <div class="room-guests dropdown-menu" @click="function(e) {e.stopPropagation();}">
            <div class="room-wrapper" v-for="(paxInfo, index) in paxInfos">
                <div class="title-room" v-if="!isFlightOnly && !isTourResult && !isTourOnly">
                    <span v-lang.ROOM>Room</span> {{index + 1}}
                    <a href="javascript:void(0);" v-show="index > 0" @click="removePaxInfo(index, $event)" class="room-remove">
                        <i class="icon-remove"></i>
                    </a>
                </div>
                <div class="add-adjusts-box">
                    <div class="adjusts-box">
                        <small v-lang.ADULTS_INFO></small>
                        <div class="form-adjusts">
                            <span class="icon-minus-gross-horizontal-straight-line-symbol bt-add" @click="handlePaxSelection($event, 'adult', index, false)"></span>
                            <strong class="adjust-count">{{paxInfo.adultCount}}</strong>
                            <span class="icon-add1 bt-add" @click="handlePaxSelection($event, 'adult', index, true)"></span>
                        </div>
                        <input type="hidden" name="Adults" :value="paxInfo.adultCount" v-if="isTourResult" />
                        <input type="hidden" :name="'PaxInfos[' + index + '].AdultCount'" :value="paxInfo.adultCount" v-else />
                    </div>
                    <div class="adjusts-box">
                        <small v-lang.CHILDREN_INFO></small>
                        <div class="form-adjusts">
                            <span class="icon-minus-gross-horizontal-straight-line-symbol bt-add" @click="handlePaxSelection($event, 'child', index, false)"></span>
                            <strong class="adjust-count">{{paxInfo.childCount}}</strong>
                            <span class="icon-add1 bt-add" @click="handlePaxSelection($event, 'child', index, true)"></span>
                        </div>
                        <input type="hidden" name="Children" :value="paxInfo.childCount" v-if="isTourResult" />
                        <input type="hidden" :name="'PaxInfos[' + index + '].ChildCount'" :value="paxInfo.childCount" v-else />
                    </div>
                    <div class="adjusts-box" v-if="!isTourResult" v-show="!isTourOnly">
                        <small v-lang.INFANTS_INFO></small>
                        <div class="form-adjusts">
                            <span class="icon-minus-gross-horizontal-straight-line-symbol bt-add" @click="handlePaxSelection($event, 'infant', index, false)"></span>
                            <strong class="adjust-count">{{paxInfo.infantCount}}</strong>
                            <span class="icon-add1 bt-add" @click="handlePaxSelection($event, 'infant', index, true)"></span>
                        </div>
                        <input type="hidden" :name="'PaxInfos[' + index + '].InfantCount'" :value="paxInfo.infantCount" v-if="!isTourResult" />
                    </div>
                </div>
                <div class="adjust-type-box" v-show="paxInfo.childCount > 0 && !isTourResult && !isTransferOnly" v-if="!isTourOnly">
                    <div class="form-adjust-type" v-if="paxInfo.childCount > 0">
                        <small v-lang.CHILD_1_AGE></small>
                        <select class="select-adjust" :name="'PaxInfos[' + index + '].ChildAges[0]'" v-model="paxInfo.childAge1">
                            <option :value="n" v-for="n in childAges">{{n}}</option>
                        </select>
                    </div>
                    <div class="form-adjust-type" v-if="paxInfo.childCount > 1">
                        <small v-lang.CHILD_2_AGE></small>
                        <select class="select-adjust" :name="'PaxInfos[' + index + '].ChildAges[1]'" v-model="paxInfo.childAge2">
                            <option :value="n" v-for="n in childAges">{{n}}</option>
                        </select>
                    </div>
                    <div class="form-adjust-type" v-if="paxInfo.childCount > 2">
                        <small v-lang.CHILD_3_AGE></small>
                        <select class="select-adjust" :name="'PaxInfos[' + index + '].ChildAges[2]'" v-model="paxInfo.childAge3">
                            <option :value="n" v-for="n in childAges">{{n}}</option>
                        </select>
                    </div>
                    <div class="form-adjust-type" v-if="paxInfo.childCount > 3">
                        <small v-lang.CHILD_4_AGE></small>
                        <select class="select-adjust" :name="'PaxInfos[' + index + '].ChildAges[3]'" v-model="paxInfo.childAge4">
                            <option :value="n" v-for="n in childAges">{{n}}</option>
                        </select>
                    </div>
                    <div class="form-adjust-type" v-if="paxInfo.childCount > 4">
                        <small v-lang.CHILD_5_AGE></small>
                        <select class="select-adjust" :name="'PaxInfos[' + index + '].ChildAges[4]'" v-model="paxInfo.childAge5">
                            <option :value="n" v-for="n in childAges">{{n}}</option>
                        </select>
                    </div>
                    <div class="form-adjust-type" v-if="paxInfo.childCount > 5">
                        <small v-lang.CHILD_6_AGE></small>
                        <select class="select-adjust" :name="'PaxInfos[' + index + '].ChildAges[5]'" v-model="paxInfo.childAge6">
                            <option :value="n" v-for="n in childAges">{{n}}</option>
                        </select>
                    </div>
                </div>
                <div class="adjust-type-box" v-show="paxInfo.childCount > 0 && !isTourResult && !isTransferOnly" v-else>
                    <div class="form-adjust-type" v-if="paxInfo.childCount > 0">
                        <small v-lang.CHILD_1_AGE></small>
                        <select class="select-adjust" :name="'PaxInfos[' + index + '].ChildAges[0]'" v-model="paxInfo.childAge1">
                            <option :value="n" v-for="n in childAges">{{n}}</option>
                        </select>
                    </div>
                    <div class="form-adjust-type" v-if="paxInfo.childCount > 1">
                        <small v-lang.CHILD_2_AGE></small>
                        <select class="select-adjust" :name="'PaxInfos[' + index + '].ChildAges[1]'" v-model="paxInfo.childAge2">
                            <option :value="n" v-for="n in childAges">{{n}}</option>
                        </select>
                    </div>
                    <div class="form-adjust-type" v-if="paxInfo.childCount > 2">
                        <small v-lang.CHILD_3_AGE></small>
                        <select class="select-adjust" :name="'PaxInfos[' + index + '].ChildAges[2]'" v-model="paxInfo.childAge3">
                            <option :value="n" v-for="n in childAges">{{n}}</option>
                        </select>
                    </div>
                    <div class="form-adjust-type" v-if="paxInfo.childCount > 3">
                        <small v-lang.CHILD_4_AGE></small>
                        <select class="select-adjust" :name="'PaxInfos[' + index + '].ChildAges[3]'" v-model="paxInfo.childAge4">
                            <option :value="n" v-for="n in childAges">{{n}}</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="add-room-wrap" v-if="!isTourResult" v-show="!isTourOnly">
                <a href="javascript:void(0);" v-show="maxRooms > 1 && paxInfos.length < maxRooms && !isFlightOnly" @click="addPaxInfo()">
                    <i class="icon-add1"></i> <span style="display: inline-flex;" v-lang.ADD_ROOM></span>
                </a>
                <span v-show="maxRooms > 1 && paxInfos.length == maxRooms" v-lang.MAX_ROOMS_ALLOWED="{0: maxRooms}"> </span>
                <span v-lang.PASSENGER_AGE_NOTICE></span>
                <input type="hidden" name="RoomCount" :value="paxInfos.length" />
            </div>
        </div>
    </div>
</template>
<script>
    import {
        mapState
    } from 'vuex'
    export default {
        name: "PaxSelector",
        data() {
            return {
                paxInfos: [],
                childAges: []
            }
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            clientResources: state => state.workContext.clientResources
        }),
        methods: {
            addPaxInfo: function (event) {
                if (this.paxInfos.length >= this.maxRooms) {
                    return;
                }
                let adult = 1;
                let maxAdults = this.isTourOnly ? 9 : (this.isTourResult ? this.paxInfo.adultCount : 9);
                let maxChildren = this.isTourOnly ? 6 : (this.isTourResult ? this.paxInfo.childCount : 6);
                let maxInfant = 3;

                if (!this.isHotelOnly && this.paxsCount().adultsCount >= maxAdults ||
                    this.paxsCount().childrenCount >= maxChildren ||
                    this.infantsCount >= maxInfant) {
                    return;
                }

                var childAge = this.$store.state.workContext.siteInfo.childAge;
                this.paxInfos.push({
                    adultCount: adult,
                    childCount: 0,
                    infantCount: 0,
                    childAge1: childAge,
                    childAge2: childAge,
                    childAge3: childAge,
                    childAge4: childAge,
                    childAge5: childAge,
                    childAge6: childAge,
                    childAges: [childAge, childAge, childAge, childAge, childAge, childAge]
                });

                if (event) {
                    event.preventDefault();
                    event.stopPropagation();
                }
            },
            removePaxInfo: function (index, event) {
                this.paxInfos.splice(index, 1);
                if (event) {
                    event.preventDefault();
                    event.stopPropagation();
                }
            },
            calculatePaxCount: function () {
                var count = 0;
                for (var i = 0, len = this.paxInfos.length; i < len; i++) {
                    var paxInfo = this.paxInfos[i];
                    count += parseInt(paxInfo.adultCount + "");
                    count += parseInt((paxInfo.childCount ? paxInfo.childCount : 0) + "");
                    count += parseInt((paxInfo.infantCount ? paxInfo.infantCount : 0) + "");
                }
                return count;
            },
            handlePaxSelection: function (e, type, index, isIncrease) {
                let paxInfo = this.paxInfos[index];
                let maxAdults = this.isTourOnly ? 9 : (this.isTourResult ? this.paxInfo.adultCount : 9);
                let maxChildren = this.isTourOnly ? 6 : (this.isTourResult ? this.paxInfo.childCount : 6);
                let maxInfant = this.isHotelOnly ? 9 : 3;
                var adult = 0;
                var child = 0;
                var infant = 0;
                if (this.paxInfos.length > 0) {
                    for (var i = 0, len = this.paxInfos.length; i < len; i++) {
                        var pax = this.paxInfos[i];
                        adult += parseInt(pax.adultCount + "");
                        child += parseInt((pax.childCount ? pax.childCount : 0) + "");
                        infant += parseInt((pax.infantCount ? pax.infantCount : 0) + "");
                    }
                }
                let paxCount = adult + child;
                let paxLimitationMessage = "";
                if (this.isHotelOnly) {
                    paxLimitationMessage = this.translateText("PAX_LIMITATION_MESSAGE1")
                    if (isIncrease && paxCount + infant >= 90) {
                        this.$swal(paxLimitationMessage);
                    }
                } else {
                    if (this.isFlightOnly || this.isFlightHotel)
                        paxLimitationMessage = this.translateText("PAX_LIMITATION_MESSAGE2")
                    else {
                        paxLimitationMessage = this.translateText("PAX_LIMITATION_MESSAGE3")
                    }

                    if (isIncrease && paxCount >= 15 && type != 'infant') {
                        this.$swal(paxLimitationMessage);
                    }
                }
                var conditions = {};
                switch (type) {
                    case 'adult':
                        if (isIncrease && this.isHotelOnly && paxInfo.adultCount + paxInfo.childCount >= 9)
                            break;
                        conditions["other"] = paxInfo.adultCount < maxAdults && adult < maxAdults;
                        conditions["hotel"] = paxInfo.adultCount < maxAdults;
                        if (isIncrease && conditions[this.isHotelOnly ? "hotel" : "other"])
                            paxInfo.adultCount++;
                        else if (!isIncrease && paxInfo.adultCount > 1) {
                            paxInfo.adultCount--;
                            if (paxInfo.adultCount <= maxInfant && paxInfo.infantCount >= paxInfo.adultCount) {
                                paxInfo.infantCount = paxInfo.adultCount;
                            }
                        }
                        break;
                    case 'child':
                        if (isIncrease && this.isHotelOnly && paxInfo.adultCount + paxInfo.childCount >= 9)
                            break;
                        conditions["other"] = paxInfo.childCount < maxChildren && child < maxChildren;
                        conditions["hotel"] = paxInfo.childCount < maxChildren;
                        if (isIncrease && conditions[this.isHotelOnly ? "hotel" : "other"])
                            paxInfo.childCount++;
                        else if (!isIncrease && paxInfo.childCount > 0)
                            paxInfo.childCount--;
                        break;
                    case 'infant':
                        conditions["other"] = paxInfo.infantCount < maxInfant && (paxInfo.infantCount < paxInfo.adultCount) && infant < maxInfant;
                        conditions["hotel"] = paxInfo.infantCount < maxInfant && (paxInfo.infantCount < paxInfo.adultCount);
                        if (isIncrease && conditions[this.isHotelOnly ? "hotel" : "other"])
                            paxInfo.infantCount++;
                        else if (!isIncrease && paxInfo.infantCount > 0)
                            paxInfo.infantCount--;
                        break;
                }

                if (this.isTourResult) this.$emit('onChangePax', paxInfo);
            },
            paxsCount() {
                var paxsCount = {
                    adultsCount: 0,
                    chidrenCount: 0,
                    infantsCount: 0
                };
                for (var i = 0, len = this.paxInfos.length; i < len; i++) {
                    var paxInfo = this.paxInfos[i];
                    paxsCount.adultsCount += parseInt(paxInfo.adultCount + "");
                    paxsCount.childrenCount += parseInt(paxInfo.childCount + "");
                    paxsCount.infantsCount += parseInt(paxInfo.infantCount + "");
                }
                return paxsCount;
            },
            translateText(translateKey, defaultText, params) {
                return this.translate(this.$language, translateKey, params) || defaultText;
            }
        },
        props: ['maxRooms', 'isFlightOnly', 'isTourResult', 'tour', 'isTourOnly', 'isTransferOnly', 'paxInfo', 'isHotelOnly', 'isFlightHotel'],
        mounted: function () {
            var self = this;
            // default pax info
            var childAge = this.$store.state.workContext.siteInfo.childAge;
            var adultAge = this.$store.state.workContext.siteInfo.adultAge;
            for (var i = childAge; i <= adultAge - 1; i++) {
                this.childAges.push(i);
            }

            if (this.$store.state.workContext.packageQuery) {
                this.paxInfos = this.$store.state.workContext.packageQuery.paxInfos;
                for (var i = 0; i < this.paxInfos.length; i++) {
                    var paxInfo = this.paxInfos[i];
                    paxInfo.childAges = paxInfo.childAges && paxInfo.childAges.length > 0 ? paxInfo.childAges : [childAge, childAge, childAge, childAge, childAge, childAge];

                    if (paxInfo.childAges.length < 6) {
                        for (var i = paxInfo.childAges.length; i < 6; i++) {
                            paxInfo.childAges.push(childAge);
                        }
                    }

                    if (!paxInfo.childAge1 || paxInfo.childAge1 === 0) {
                        paxInfo.childAge1 = paxInfo.childAges[0];
                    }
                    if (!paxInfo.childAge2 || paxInfo.childAge2 === 0) {
                        paxInfo.childAge2 = paxInfo.childAges[1];
                    }
                    if (!paxInfo.childAge3 || paxInfo.childAge3 === 0) {
                        paxInfo.childAge3 = paxInfo.childAges[2];
                    }
                    if (!paxInfo.childAge4 || paxInfo.childAge4 === 0) {
                        paxInfo.childAge4 = paxInfo.childAges[3];
                    }
                    if (!paxInfo.childAge5 || paxInfo.childAge5 === 0) {
                        paxInfo.childAge5 = paxInfo.childAges[4];
                    }
                    if (!paxInfo.childAge || paxInfo.childAge6 === 0) {
                        paxInfo.childAge6 = paxInfo.childAges[5];
                    }
                }
            }
            else {
                if (this.paxInfos.length == 0) {
                    // Create default pax info
                    this.paxInfos.push({
                        adultCount: self.isTourResult ? self.paxInfo.adultCount : (self.isFlightOnly ? 1 : 2),
                        childCount: self.isTourResult ? self.paxInfo.childCount : 0,
                        infantCount: 0,
                        childAge1: childAge,
                        childAge2: childAge,
                        childAge3: childAge,
                        childAge4: childAge,
                        childAge5: childAge,
                        childAge6: childAge,
                        childAges: [childAge, childAge, childAge, childAge, childAge, childAge]
                    });
                }
            }

            if (self.isTourResult) {
                self.paxInfos = [{
                    adultCount: self.paxInfo.adultCount,
                    childCount: self.paxInfo.childCount
                }];

                if (self.tour) {
                    self.tour.adults = self.paxInfo.adultCount;
                    self.tour.children = self.paxInfo.childCount;
                }
            }
        }
    }
</script>
