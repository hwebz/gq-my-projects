﻿<template>
    <div class="rating">
        <span :class="star" v-for="star in stars"></span>
    </div>
</template>
<script>
    export default {
        data() {
            return { stars: [] };
        },
        model: {
            prop: 'rating'
        },
        props: {
            rating: {
                type: Number,
                default: 0
            }
        },
        created() {
            this.createStars();
        },
        methods: {
            createStars: function () {
                var rating = parseFloat(this.rating);
                var min = Math.floor(rating);
                var stars = [];
                for (var i = 1; i <= min; i++) {
                    stars.push('icon-star');
                }
                if (min < rating) {
                    stars.push('icon-half-star');
                }
                this.stars = stars;
            }
        },
        watch: {
            rating(val) {
                this.createStars();
            }
        }
    }
</script>