﻿<template>
    <div>
        <div class="research flex-grow" v-show="hasErrorMessage">
            <div class="container" v-if="packageQuery">
                <nav class="crumbar">
                    <ul>
                        <li v-lang.SEARCH_TRANSFERS_IN="{0: packageQuery.toCityName}"></li>
                    </ul>
                </nav>
                <div class="research__wrap">
                    <h1 v-lang.YOUR_SEARCH_TRANSFERS_IN="{0: packageQuery.toCityName}"></h1>
                </div>
                <div class="research__content">
                    <div class="research__title">
                        <h2 v-if="packageQuery.transferSearchInfo.transferType === 'Return'" v-lang.YOUR_SEARCH_DATE_FROM_TO="{0: formatDate(packageQuery.departureDate, 'DD MMMM YYYY HH:mm'), 1: formatDate(packageQuery.returnDate, 'DD MMMM YYYY HH:mm')}"></h2>
                        <h2 v-else v-lang.YOUR_SEARCH_DATE_AT="{0: formatDate(packageQuery.returnDate, 'DD MMMM YYYY HH:mm')}"></h2>
                        <p v-lang.CHECK_YOUR_SPELLING_AND_TRY_AGAIN></p>
                    </div>
                    <div class="research__form">
                        <div class="search-wrap">
                            <div class="search-tabs search-research">
                                <div class="search-content">
                                    <TransferSearchBox :product="product" type="Transfer" :defaultDate="defaultDate" :toCityName="fullToCityName" :hotelTransfer="hotelTransfer" :packageQuery="packageQuery" :to="packageQuery.to" journeyType="1" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div v-show="!hasErrorMessage">
            <div v-if="packageQuery">
                <SessionTimeout :packageId="packageQuery.id" :secondTimeout="packageQuery.ttl"></SessionTimeout>
                <div class="page-title-tabs" v-if="!loading.bookingTour">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                <div>
                                    <h1 v-lang.TRANSFERS_IN_X="{0: packageQuery.toCityName}"></h1>
                                    <h6 v-if="cheapestTransferPrice" v-lang.TRANSFER_FROM_X="{0: packageQuery.currency, 1: formatCurrency(cheapestTransferPrice)}"></h6>
                                    <h6 v-else>
                                        <div class="lda">
                                            <div class="lda__bar"></div>
                                        </div>
                                    </h6>
                                </div>
                                <div class="date-time-person">
                                    <span>
                                        <i class="icon-flight"></i>
                                        <span>
                                            {{ packageQuery.departureDate| formatDate("DD MMM HH:mm") }}
                                            <template v-if="!isOneWay">
                                                - {{ packageQuery.returnDate| formatDate("DD MMM HH:mm") }}
                                            </template>
                                        </span>
                                    </span>
                                    <span>
                                        <i class="icon-user"></i>
                                        <span>
                                            {{calculatePaxCount}} {{calculatePaxCount == 1 ? translateText('PASSENGER', 'Passenger') : translateText('PASSENGERS', 'Passengers')}}
                                        </span>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-5 text-right">
                                <a class="btn-title-tabs" href="#modalChangeDate" data-toggle="modal" data-target="#modalChangeDate">
                                    <i class="icon-search"></i><span v-lang.EDIT_SEARCH></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="page-title-tabs" v-else>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                <div class="lda">
                                    <div class="lda__bar lda__bar--h27"></div>
                                    <div class="lda__bar lda__bar--50"></div>
                                </div>
                            </div>
                            <div class="col-md-5 text-right">
                                <a class="btn-title-tabs">
                                    <div class="lda__bar"></div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <TransferSelector :arrivalTransfer="arrivalTransfer"
                                  :departureTransfer="departureTransfer"
                                  :packageQuery="packageQuery"
                                  :hotelTransfer="hotelTransfer"
                                  :nextButtonUrl="nextButtonUrl"
                                  @onShowTransferPrice="onShowTransferPrice"
                                  @onCheckBookingTransfer="obj => checkBookingTransfer(obj.event, obj.nextButtonUrl)"
                                  @onRemoveTransfer="onRemoveTransfer"
                                  @onSetCancellationTransfer="setCancellationTransfer"
                                  v-if="transferSelected.arrivalTransfer || transferSelected.departureTransfer" />
                <div class="fh-tabs__wrap" v-show="packageQuery.arrivalTransfer || packageQuery.departureTransfer" v-else>
                    <div class="container">
                        <div class="fh-tabs__overview">
                            <div class="fh-tabs__item fh-tabs__hotel fh-tabs__transfer active">
                                <div class="title-option">
                                    <div class="title-option-name text-uppercase" v-lang.ARRIVAL_TRANSFER></div>
                                </div>
                                <div class="picture">
                                    <div class="lda">
                                        <div class="lda__bar lda__bar--full"></div>
                                    </div>
                                </div>
                                <div class="detail">
                                    <div class="lda">
                                        <div class="lda__bar"></div>
                                        <div class="lda__bar lda__bar--50"></div>
                                        <div class="lda__bar lda__bar--split"></div>
                                        <div class="lda__bar lda__bar--split"></div>
                                        <div class="lda__bar"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="fh-tabs__item fh-tabs__hotel fh-tabs__transfer">
                                <div class="title-option">
                                    <div class="title-option-name text-uppercase" v-lang.DEPARTURE_TRANSFER></div>
                                </div>
                                <div class="picture">
                                    <div class="lda">
                                        <div class="lda__bar lda__bar--full"></div>
                                    </div>
                                </div>
                                <div class="detail">
                                    <div class="lda">
                                        <div class="lda__bar"></div>
                                        <div class="lda__bar lda__bar--50"></div>
                                        <div class="lda__bar lda__bar--split"></div>
                                        <div class="lda__bar lda__bar--split"></div>
                                        <div class="lda__bar"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="fh-tabs__item fh-tabs__control">
                                <div class="lda lda--fbot">
                                    <div class="lda__bar lda__bar--50"></div>
                                    <div class="lda__bar lda__bar--50"></div>
                                    <div class="lda__bar lda__bar--50"></div>
                                    <div class="lda__bar lda__bar--split"></div>
                                    <div class="lda__bar lda__bar--two"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="content-wrap">
                    <div class="content-wrap-tabs">
                        <div class="content-tabs-header">
                            <div class="container nav nav-tabs">
                                <a class="item-tabs-header nav-item"
                                   data-toggle="tab" href="#tabs-arrival"
                                   :class="{'active': !isToAirport}"
                                   v-show="!isToAirport && arrivalTransfers.length > 0" @click="syncTabs">
                                    <i class="icon-car"></i>
                                    <span v-lang.ARRIVAL_TRANSFER></span>
                                </a>
                                <a class="item-tabs-header nav-item" data-toggle="tab"
                                   href="#tabs-departure"
                                   :class="{'active': isToAirport || arrivalTransfers.length == 0}"
                                   v-show="(isToAirport && isOneWay && departureTransfers.length > 0) || (!isOneWay && departureTransfers.length > 0)" @click="syncTabs">
                                    <i class="icon-car"></i>
                                    <span v-lang.DEPARTURE_TRANSFER></span>
                                </a>
                            </div>
                        </div>
                        <div class="content-tabs-main tab-content" v-if="!loading.bookingTour && arrivalTransfers && departureTransfers && (arrivalTransfers.length > 0 || departureTransfers.length > 0)">
                            <div class="content-tabs-wrap tab-pane fade" id="tabs-arrival" :class="{'active show': !isToAirport}" v-show="arrivalTransfers.length > 0">
                                <TransferItem :flightNumberLabel="translateText('GIVE_US_YOUR_OUTBOUND_FLIGHT_NUMBER', 'Give us your outbound flight number for picking you up')"
                                              :arrivalTransfer="arrivalTransfer"
                                              :departureTransfer="departureTransfer"
                                              :transfers="arrivalTransfers"
                                              :packageQuery="packageQuery"
                                              :hotelTransfer="hotelTransfer"
                                              :isOneWay="isOneWay"
                                              :totalPax="calculatePaxCount"
                                              :isToAirport="isToAirport"
                                              :isArrivalTransfers="true"
                                              :tempTransfer="tempTransfer"
                                              @onRemoveTransfer="onRemoveTransfer"
                                              @onShowTransferPrice="onShowTransferPrice"
                                              @onChangeNoOfVehicle="onChangeNoOfVehicle"
                                              @onBookingTransfer="onBookingTransfer"
                                              @onAutoFillFlightNo="autoFillFlightNo"
                                              @onSetCancellationTransfer="setCancellationTransfer" />
                            </div>
                            <div class="content-tabs-wrap tab-pane fade" id="tabs-departure" :class="{'active show': isToAirport || arrivalTransfers.length == 0}" v-show="departureTransfers.length > 0">
                                <TransferItem :flightNumberLabel="translateText('GIVE_US_YOUR_INBOUND_FLIGHT_NUMBER', 'Give us your inbound flight number for picking you up')"
                                              :arrivalTransfer="arrivalTransfer"
                                              :departureTransfer="departureTransfer"
                                              :transfers="departureTransfers"
                                              :packageQuery="packageQuery"
                                              :hotelTransfer="hotelTransfer"
                                              :isOneWay="isOneWay"
                                              :totalPax="calculatePaxCount"
                                              :isToAirport="isToAirport"
                                              :tempTransfer="tempTransfer"
                                              @onRemoveTransfer="onRemoveTransfer"
                                              @onShowTransferPrice="onShowTransferPrice"
                                              @onChangeNoOfVehicle="onChangeNoOfVehicle"
                                              @onBookingTransfer="onBookingTransfer"
                                              @onAutoFillFlightNo="autoFillFlightNo"
                                              @onSetCancellationTransfer="setCancellationTransfer" />
                            </div>
                        </div>
                        <div class="content-tabs-main tab-content" v-else>
                            <div class="content-tabs-wrap tab-pane fade show active">
                                <div class="container">
                                    <div class="avai-findbar-transfer">
                                        <div class="row">
                                            <div class="col-sm-9">
                                                <ul>
                                                    <li>
                                                        <div class="lda">
                                                            <div class="lda__bar lda__bar--50"></div>
                                                        </div>
                                                        <div class="lda">
                                                            <div class="lda__bar lda__bar--50"></div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="col-sm-3 text-right">
                                                <div class="lda">
                                                    <div class="lda__bar"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="avai-hotel avai-transfer">
                                        <div class="fh-tabs__overview" v-for="n in [0, 1, 2, 3, 4]" :key="n">
                                            <div class="fh-tabs__item fh-tabs__hotel fh-tabs__transfer">
                                                <div class="picture">
                                                </div>
                                                <div class="detail">
                                                    <div class="lda">
                                                        <div class="lda__bar"></div>
                                                        <div class="lda__bar"></div>
                                                        <div class="lda__bar"></div>
                                                        <div class="lda__bar"></div>
                                                        <div class="lda__bar"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="fh-tabs__item fh-tabs__control">
                                                <div class="lda lda--fbot">
                                                    <div class="lda__bar lda__bar--50"></div>
                                                    <div class="lda__bar lda__bar--50"></div>
                                                    <div class="lda__bar lda__bar--50"></div>
                                                    <div class="lda__bar lda__bar--split"></div>
                                                    <div class="lda__bar lda__bar--two"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--<div class="paganition-wrap text-center">
                                        <a class="item-paganition bt-effect">
                                            <div class="lda">
                                                <div class="lda__bar lda__bar--50"></div>
                                            </div>
                                        </a>
                                    </div>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade modal-md" id="modalChangeDate" tabindex="-1" role="dialog" aria-hidden="true" v-show="hasErrorMessage">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-title ">
                                <strong v-lang.SEARCH_TRANSFER></strong>
                                <button class="modal-close" data-dismiss="modal">
                                    <i class="icon-remove"></i>
                                </button>
                            </div>
                            <form method="GET" action="/package/start-search" data-val="true" @submit="onValidate">
                                <div class="search-tabs search-popup">
                                    <div class="search-content">
                                        <div class="journey-type">
                                            <label class="radio-inline">
                                                <input type="radio" name="TransferSearchInfo.TransferType" value="Return" v-model="packageQuery.transferSearchInfo.transferType" /> <span v-lang.RETURN></span>
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="TransferSearchInfo.TransferType" value="FromAirport" v-model="packageQuery.transferSearchInfo.transferType" /> <span v-lang.ONE_WAY_FROM_AIRPORT></span>
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="TransferSearchInfo.TransferType" value="ToAirport" v-model="packageQuery.transferSearchInfo.transferType" /> <span v-lang.ONE_WAY_TO_AIRPORT></span>
                                            </label>
                                        </div>
                                        <div class="search-grid" :class="{'to-airport': packageQuery.transferSearchInfo.transferType === 'ToAirport'}">
                                            <AjaxSelect name="To"
                                                        :placeholder="translateText('CHOOSE_A_CITY', 'Choose a city...')"
                                                        :txtLabel="translateText('WHAT_AIRPORT_DO_YOU_ARRIVE_AT', 'What airport do you arrive at?')"
                                                        :txtToAirportLabel="translateText('WHAT_AIRPORT_DO_YOU_ARRIVE_AT', 'What airport do you arrive at?')"
                                                        :class="{'disabled': !packageQuery.transferSearchInfo.regionId && packageQuery.transferSearchInfo.transferType === 'ToAirport'}"
                                                        :defaultValue="packageQuery.to"
                                                        :defaultText="packageQuery.toAirportName ? packageQuery.toAirportName : fullToCityName"
                                                        :journeyType="packageQuery.transferSearchInfo.transferType"
                                                        :cityCode="airportByRegionCode"
                                                        icon="ico icon-location-arrow"
                                                        :accepted="true"
                                                        :url="packageQuery.transferSearchInfo.transferType === 'ToAirport' ? '/api/get-airports-of-city' : '/api/get-global-airports'"
                                                        @onLocationChanged="onLocationChanged"
                                                        :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_CITY', 'Please choose a valid city')"
                                                        data-selected="true" />
                                            <AjaxSelect name="TransferSearchInfo.RegionId"
                                                        :placeholder="translateText('HOTEL_NAME_LOCATION', 'Hotel name/location...')"
                                                        :txtLabel="translateText('WHERE_WOULD_YOU_LIKE_TO_BE_DROPPED_OFF', 'Where would you like to be dropped off?')"
                                                        :txtToAirportLabel="translateText('WHERE_WOULD_YOU_LIKE_TO_BE_PICKED_UP', 'Where would you like to be picked up?')"
                                                        :journeyType="packageQuery.transferSearchInfo.transferType"
                                                        :class="{'disabled': !packageQuery.to && packageQuery.transferSearchInfo.transferType !== 'ToAirport'}"
                                                        type="Transfer"
                                                        :to="packageQuery.to"
                                                        :defaultValue="packageQuery ? packageQuery.transferSearchInfo.regionId : ''"
                                                        :defaultLocation="hotelTransfer ? hotelTransfer.latitude + ',' + hotelTransfer.longitude : ''"
                                                        :defaultText="hotelTransfer ? hotelTransfer.name : ''"
                                                        icon="ico icon-map-marker"
                                                        :typeRegions="typeRegions"
                                                        :url="'/api/search-regions'"
                                                        @onCityChanged="obj => onCityChanged(obj.code, obj.airportCode)"
                                                        @accommodationGeoCoords="setAccommodationGeoCoords"
                                                        :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_DESTINATION', 'Please choose a valid destination')"
                                                        data-selected="true" />
                                            <DateRangePicker :defaultValue="defaultDate" date-format="DD/MM/YYYY" :journeyType="packageQuery.transferSearchInfo.transferType" data-selected="true" isFlight="true" type="Transfer" />
                                            <PaxSelector :maxRooms="3" data-selected="true" isTransferOnly="true" isTourOnly="true" :paxInfo="packageQuery.paxInfos[0]" />
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="hidden" name="OrderId" :value="packageQuery.orderId" />
                                    <input type="hidden" name="Currency" :value="packageQuery.currency" />
                                    <input type="hidden" name="ProductId" :value="packageQuery.productId" />
                                    <button id="btnSumitSearchFormTransfer" class="btn btn-sm btn-primary bt-effect" type="submit" v-lang.SEARCH></button>
                                    <button class="btn btn-sm btn-default bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <a class="back-to-top" href="#" @click="backTop">
                    <i class="icon icon-up-chevron"></i>
                    <span v-lang.BACK_TO_TOP></span>
                </a>
            </div>
        </div>
        <div class="modal fade" id="modalTransferPriceBreakdown" tabindex="-1" role="dialog" aria-hidden="true" v-if="tempTransfer && (tempTransfer.transfer || tempTransfer.arrivalTransfer || tempTransfer.departureTransfer)">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body modal-body-gray npd">
                        <div class="flight-detail-title">
                            <strong v-lang.PRICE_BREAKDOWN></strong>
                            <button class="modal-close" data-dismiss="modal">
                                <i class="icon-remove"></i>
                            </button>
                        </div>
                        <div class="price-summary-table">
                            <table class="responsive">
                                <thead>
                                    <tr>
                                        <th colspan="4" v-lang.TRANSFER_PRICES></th>
                                    </tr>
                                    <tr>
                                        <th scope="col" v-if="tempTransfer.isSummary" v-lang.TRANSFER_TYPE></th>
                                        <th scope="col" v-else v-lang.UNITS></th>
                                        <th scope="col" v-lang.PRICE_PER_UNIT></th>
                                        <th scope="col" v-lang.NO_OF_VEHICLES></th>
                                        <th scope="col" v-lang.TOTAL_PRICE></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <template v-if="tempTransfer.isSummary">
                                        <tr v-if="tempTransfer.arrivalTransfer">
                                            <td scope="row" :data-label="translateText('ARRIVAL_TRANSFER', 'Arrival Transfer')">{{tempTransfer.arrivalTransfer.name}}</td>
                                            <td :data-label="translateText('PRICE_PER_UNIT', 'Price/unit')">{{packageQuery.currency}} {{(tempTransfer.arrivalTransfer.selectedVehicle.totalPrice / tempTransfer.arrivalTransfer.selectedVehicle.noOfVehicle) | formatCurrency}}</td>
                                            <td :data-label="translateText('NO_OF_VEHICLES', 'No. of Vehicles')">{{tempTransfer.arrivalTransfer.selectedVehicle.noOfVehicle}}</td>
                                            <td :data-label="translateText('TOTAL_PRICE', 'Total Price')">{{packageQuery.currency}} {{tempTransfer.arrivalTransfer.selectedVehicle.totalPrice | formatCurrency}}</td>
                                        </tr>
                                        <tr v-if="tempTransfer.departureTransfer">
                                            <td scope="row" :data-label="translateText('DEPARTURE_TRANSFER', 'Departure Transfer')">{{tempTransfer.departureTransfer.name}}</td>
                                            <td :data-label="translateText('PRICE_PER_UNIT', 'Price/unit')">{{packageQuery.currency}} {{(tempTransfer.departureTransfer.selectedVehicle.totalPrice / tempTransfer.departureTransfer.selectedVehicle.noOfVehicle) | formatCurrency}}</td>
                                            <td :data-label="translateText('NO_OF_VEHICLES', 'No. of Vehicles')">{{tempTransfer.departureTransfer.selectedVehicle.noOfVehicle}}</td>
                                            <td :data-label="translateText('TOTAL_PRICE', 'Total Price')">{{packageQuery.currency}} {{tempTransfer.departureTransfer.selectedVehicle.totalPrice | formatCurrency}}</td>
                                        </tr>
                                    </template>
                                    <template v-else>
                                        <tr>
                                            <td scope="row" :data-label="translateText('PER_UNIT', 'Per unit')">{{tempTransfer.transfer.name}}</td>
                                            <td :data-label="translateText('PRICE_PER_UNIT', 'Price/unit')">{{packageQuery.currency}} {{(tempTransfer.transfer.selectedVehicle.totalPrice / tempTransfer.transfer.selectedVehicle.noOfVehicle) | formatCurrency}}</td>
                                            <td :data-label="translateText('NO_OF_VEHICLES', 'No. of Vehicles')">{{tempTransfer.transfer.selectedVehicle.noOfVehicle}}</td>
                                            <td :data-label="translateText('TOTAL_PRICE', 'Total Price')">{{packageQuery.currency}} {{tempTransfer.transfer.selectedVehicle.totalPrice | formatCurrency}}</td>
                                        </tr>
                                    </template>
                                </tbody>
                            </table>
                            <table>
                                <thead>
                                    <template v-if="tempTransfer.isSummary">
                                        <tr>
                                            <th v-lang.TOTAL_PRICE_INCLUDES_TAXES_AND_FEES></th>
                                            <th>{{packageQuery.currency}} {{((tempTransfer.arrivalTransfer ? tempTransfer.arrivalTransfer.selectedVehicle.totalPrice : 0) + (tempTransfer.departureTransfer ? tempTransfer.departureTransfer.selectedVehicle.totalPrice : 0)) | formatCurrency}}</th>
                                        </tr>
                                    </template>
                                    <template v-else>
                                        <tr>
                                            <th v-lang.TOTAL_PRICE_INCLUDES_TAXES_AND_FEES></th>
                                            <th>{{packageQuery.currency}} {{tempTransfer.transfer.selectedVehicle.totalPrice | formatCurrency}}</th>
                                        </tr>
                                    </template>
                                </thead>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-primary bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="modalCancellationTransfer" tabindex="-1" role="dialog" aria-hidden="true" v-if="transferCancellation">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body modal-body-gray npd">
                        <div class="flight-detail-title">
                            <strong v-lang.CANCELLATION_POLICY></strong>
                            <button class="modal-close" data-dismiss="modal">
                                <i class="icon-remove"></i>
                            </button>
                        </div>
                        <div class="price-summary-table">         
                            <div class="policies-transfer" v-if="transferCancellation.cancellationPolicies">
                                <div>
                                    <span v-if="transferCancellation.isDeparture">{{translateText('DEPARTURE_TRANSFER', 'Departure transfer')}}</span>
                                    <span v-else>{{translateText('ARRIVAL_TRANSFER', 'Arrival transfer')}}</span>
                                </div>
                                <strong class="transfer-name">{{transferCancellation.transferName}}</strong>                              
                                <table >
                                    <tbody>
                                        <template v-for="(cancellation, index) in transferCancellation.cancellationPolicies">
                                            <tr>
                                                <template v-if="index == 0">
                                                    <template v-if="cancellation.amount == 0">
                                                        <strong v-lang.FREE_CANCELLATION></strong>
                                                        <span v-lang.BEFORE_X="{0: setDateCancellation(cancellation.to,'DD MMM YYYY')}"></span>
                                                    </template>
                                                    <template v-else>
                                                        <strong>{{packageQuery.currency}} {{cancellation.amount | formatCurrency}} </strong>
                                                        <span v-lang.WILL_BE_CHANGED_FOR_CANCELLATION_BEFORE="{0 : setDateCancellation(cancellation.to,'DD MMM YYYY')}"></span>
                                                    </template>
                                                </template>
                                                <template v-else>
                                                    <span v-if="dateDiff(cancellation.from, cancellation.to)">
                                                        <strong>{{packageQuery.currency}} {{cancellation.amount | formatCurrency}} </strong>
                                                        <span v-lang.WILL_BE_CHANGED_FOR_CANCELLATION_FROM="{0 : setDateCancellation(cancellation.from,'DD MMM'), 1: setDateCancellation(cancellation.to,'DD MMM YYYY') }"></span>
                                                    </span>
                                                    <span v-else>
                                                        <strong>{{packageQuery.currency}} {{cancellation.amount | formatCurrency}} </strong>
                                                        <span v-lang.WILL_BE_CHANGED_FOR_CANCELLATION_ON="{0 : setDateCancellation(cancellation.from,'DD MMM YYYY') }"></span>
                                                    </span>
                                                </template>
                                            </tr>
                                            <tr>
                                                <template v-if="index == transferCancellation.cancellationPolicies.length - 1">
                                                    <span>
                                                        <strong v-lang.NONREFUNDABLE></strong> <span v-lang.AFTER="{0: setDateCancellation(cancellation.to ,'DD MMM YYYY')}"></span>
                                                    </span>
                                                </template>
                                            </tr>
                                        </template>
                                    </tbody>
                                </table>
                            </div>
                           
                            <div class="notify" v-else>
                                <div class="freecan non-refund">
                                    <span><i class="icon-remove"></i><span v-lang.NONREFUNDABLE></span></span>
                                </div>
                            </div>
                            </div> 
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-primary bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import Vue from 'vue'
    import { mapState } from 'vuex'
	import Cookie from 'js-cookie'
    import AjaxSelect from './AjaxSelect.vue'
    import DateRangePicker from './DateRangePicker.vue'
    import PaxSelector from "./PaxSelector.vue"
    import httpQueueService from './Booking/httpQueueService'
    import TransferSearchBox from './TransferSearchBox.vue'
    import TransferItem from './TransferItem.vue'
    import TransferSelector from './TransferSelector.vue'
    import SessionTimeout from './SessionTimeout.vue'  
    
    export default {
        mixins: [httpQueueService],
        components: {TransferSearchBox, AjaxSelect, DateRangePicker, PaxSelector, TransferItem, TransferSelector, SessionTimeout},
        data() {
            return {
                packageQuery: null,
                transfers: [],
                hasErrorMessage: false,
                errorMessage: "",
                isSearchCompleted: false,
                hasArrivalTransfer: false,
                hasDepartureTransfer: false,
                arrivalTransfer: null,
                departureTransfer: null,
                adults: 0,
                childs: 0,
                infants: 0,
                typeRegions: 'Hotel',
                transferFilter: {
                    sortOrderBy: "Price",
                    sortOrderByAsc: true,
                    minPriceTransfer: 0,
                    maxPriceTransfer: 0
                },
                transferSelected: {},
                departureTransfers: [],
                arrivalTransfers: [],
                categories: [],
                hotelInfo: [],
                sortOrderBy: "Price",
                sortOrderByAsc: true,
                pagination: {
                    current: 1,
                    transferPerPage: 100,
                    totalTransfers: 0,
                    totalPages: 1,
                    currentRowOnPage: 0
                },
                nextButtonUrl: null,
                skipButtonUrl: null,
                addOnSelecteds: [],
                seatSelecteds: [],
                currentSection: 1,
                transferInfo: {
                    name: '',
                    description: '',
                    meetingPoint: '',
                    conditions: [],
                },
                loading: {
                    bookingTransfer: true
                },
                product: [],
                hotelTransfer: {
                    name: '',
                    latitude: null,
                    longitude: null
                },
                regionInfo: [],
                flightNo: '',
                isChangeDateTime: true,
                hasAddArrivalTransfer: false,
                hasAddDepartureTransfer: false,
                arrivalDateSelected: null,
                departureDateSelected: null,
                defaultDate: null,
                cheapestTransferPrice: null,
                isToAirport: false,
                isOneWay: false,
                tempTransfer: null,
                airportByRegionCode: "",
                searchConditions: {
                    adultCount: 0,
                    childCount: 0,
                    infantCount: 0
                },
                transferCancellation: {
                    cancellationPolicies: null,
                    transferName: '',
                    isDeparture: false,
                },
            }
        },
        created() {
            var self = this;
            var packageId = $('#PackageId').val();
            this.nextButtonUrl = $('#NextButtonUrl').val();
            this.skipButtonUrl = $('#SkipButtonUrl').val();
            $.post('/package/work-context/' + packageId, function (data) {
                data.baseUrl = $("#baseURL").val();
                $.getJSON(data.baseUrl + '/resources.json', function (res) {
                    data.clientResources = res;
                })
                self.$store.commit('setWorkContext', data);
                data.packageQuery.departureDate = moment(data.packageQuery.departureDate);
                data.packageQuery.returnDate = moment(data.packageQuery.returnDate);
                data.packageQuery.checkIn = moment(data.packageQuery.checkIn);
                data.packageQuery.checkOut = moment(data.packageQuery.checkOut);
                self.packageQuery = data.packageQuery;

                self.searchConditions = {
                    adultCount: self.adultCount,
                    childCount: self.childCount,
                    infantCount: self.infantCount
                } 

                if (self.packageQuery.departureTransfer == undefined) {
                    Vue.set(self.packageQuery, "departureTransfer", null);
                }
                if (self.packageQuery.arrivalTransfer == undefined) {
                    Vue.set(self.packageQuery, "arrivalTransfer", null);
                }

                if (self.packageQuery.transferSearchInfo && self.packageQuery.transferSearchInfo.travelTime && self.packageQuery.transferSearchInfo.returnTime) {
                    var strArr = self.packageQuery.transferSearchInfo.travelTime.split(":");
                    if (strArr && strArr.length > 0) {
                        self.packageQuery.departureDate.set({ hour: strArr[0], minute: strArr[1] });
                    }

                    strArr = self.packageQuery.transferSearchInfo.returnTime.split(":");
                    if (strArr && strArr.length > 0) {
                        self.packageQuery.returnDate.set({ hour: strArr[0], minute: strArr[1] });
                    }
                }

                self.product = data.product;
                self.getRegionInfo(function (result) {
                    self.hotelTransfer = result;
                });
                self.createPingRequest();

                // set default date
                let startDate = Vue.moment(self.packageQuery.departureDate).format('MM/DD/YYYY HH:mm');
                let endDate = Vue.moment(self.packageQuery.returnDate).format('MM/DD/YYYY HH:mm');

                self.defaultDate = startDate + ',' + endDate;
                $(".foo-copy-right").addClass('extra-padding');
                
                self.isToAirport = data.packageQuery.transferSearchInfo.transferType === 'ToAirport';
                self.isOneWay = data.packageQuery.transferSearchInfo.transferType !== 'Return';
            });
        },
        mounted() {
            $(window).on('scroll', function() {
                let btt = $(".back-to-top");
                if ($(window).scrollTop() > 200) btt.addClass('shown');
                else  btt.removeClass('shown');
            });
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            baseUrl: state => state.workContext.baseUrl,
            calculatePaxCount() {
                return this.searchConditions.adultCount + this.searchConditions.childCount;
            },
            adultCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                }
                return count;
            },
            childCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.childCount;
                }
                return count;
            },
            infantCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.infantCount;
                }
                return count;
            },
            fullToCityName() {
                var self = this;
                return self.packageQuery.toCityName + ' (' + self.packageQuery.to + ') ,' + self.packageQuery.toCountryName;
            },
            isHavingfersSelected() {
                let self = this;
                let isArrivalExist = self.packageQuery.arrivalTransfer;
                let isDepartureExist = self.packageQuery.departureTransfer;
                return (isArrivalExist || isDepartureExist);
            }
        }),
        methods: {
            formatDate(date, format) {
                return Vue.moment(date).format(format);
            },
            syncTabs(e) {
                var $this = $(e.target);
                var href = $this.attr('href');
                href = href ? href : $this.parents(".item-tabs-header").attr('href');
                href = $('.nav-tabs .fh-tabs__item[href="' + href + '"]');
                if (typeof href !== 'undefined' && href.length > 0) {
                    href.tab('show');
                }
            },
            backTop(callback = null) {
                $('html,body').animate({
                    scrollTop: 0
                }, 'slow', function() {
                    if (typeof callback == 'function') callback();
                });
            },
            onShowTransferPrice(transfer) {
                this.tempTransfer = transfer;  
            },
            onBookingTransfer(opt) {
                this.bookingTransfer(opt.event, opt.transfer, opt.selectedVehicle, opt.transferIndex);  
            },
            onLocationChanged(code) {
                this.packageQuery.to = code;
            },
            onCityChanged(code, airportCode) {
                this.airportByRegionCode = airportCode;
                this.packageQuery.transferSearchInfo.regionId = code;
            },
            createPingRequest: function () {
                var self = this;
                this.pingCount++;

                if (this.pingCount >= 10) {
                    return;
                }

                var productTypes = [{
                    productType: 8,
                    storedKey: null
                }];

                $.post("/package/product-status/" + self.packageQuery.id, { productTypeStatuses: productTypes }, function (data) {
                    if (data.length > 0) {

                        if (data.some(x => x.status == 3)) {
                            window.location = '/package/restart-search/' + self.packageQuery.id;
                        }
                        var completed = data.every(x => x.status == 1);
                        var haveError = data.some(x => x.status == 2);

                        if (haveError) {
                            self.notifyErrorMessage(data.find(x => x.status == 2).message);
                            $('#page-loader').hide();
                            self.loading.bookingTransfer = false;
                            //self.checkBookingTransfer(self.nextButtonUrl);
                        } else {
                            if (completed) {
                                self.getResultsPage(1);
                                self.checkSearchComplete();
                            } else {
                                self.createPingRequest();
                            }
                        }
                    } else {
                        self.createPingRequest();
                    }
                });
            },
            gotoTransferPage(page) {
                $(".hotel-list div[id^='transfer']").removeClass('in');
                this.getResultsPage(page, true);
                this.backTop()
            },
            notifyErrorMessage(errorMessage) {
                let self = this;
                console.log("notifyErrorMessage: " + errorMessage);
                self.hasErrorMessage = true;
                self.errorMessage = errorMessage;
                self.hideSplashScreen();
            },
            setPickupTime: function (transfer, flightTime) {
                var flightTime = moment.duration(flightTime, "HH:mm");
                var checkinTime = moment.duration(transfer.allowForCheckInTime, "HH:mm");
                var transferTime = moment.duration(transfer.approximateTransferTime, "HH:mm");
                var totalTransfer = moment.duration(checkinTime + transferTime);

                var pickupTime = null;
                if (flightTime > totalTransfer) {
                    var time = flightTime.subtract(totalTransfer);
                    pickupTime = moment(time._data).format("HH:mm");
                    if (this.packageQuery.transferSearchInfo.transferType != 'ToAirport') {
                        transfer.selectedVehicle.pickUpDate = moment(transfer.returnDate).subtract(day).format("YYYY-MM-DD");
                    }
                }
                else {
                    var day = moment.duration(1, 'days');
                    var transferDay = (this.packageQuery.transferSearchInfo.transferType != 'ToAirport' ? moment(transfer.returnDate).subtract(day).format("YYYY-MM-DD") : moment(transfer.vehicles[0].pickUpDate).subtract(day).format("YYYY-MM-DD"));
                    transfer.selectedVehicle.pickUpDate = transferDay;
                    var time = flightTime.add(day.asMilliseconds()).subtract(totalTransfer);
                    pickupTime = moment(time._data).format("HH:mm");
                }
                transfer.selectedVehicle.pickUpTime = pickupTime;
            },
            getResultsPage(newPage, hasFilters) {
                var self = this;
                var data = {
                    packageId: self.packageQuery.id,
                    pageIndex: newPage,
                    pageSize: self.pagination.transferPerPage,
                    sortOrderBy: self.transferFilter.sortOrderBy,
                    sortOrderByAsc: self.transferFilter.sortOrderByAsc
                };

                if (hasFilters) {
                    data.minPrice = self.transferFilter.selectedMinPrice;
                    data.maxPrice = self.transferFilter.selectedMaxPrice;
                    data.hasFilters = self;

                    var categoryIndex = 0;
                    for (var i = 0; i < self.categories.length; i++) {
                        var category = self.categories[i];
                        if (category.selected) {
                            data["categories[" + categoryIndex + "].Key"] = category.key;
                            data["categories[" + categoryIndex + "].Value"] = category.value;
                            categoryIndex++;
                        }
                    }
                    this.pagination.current = newPage;
                }

                self.loading.bookingTransfer = true;

                $.ajax({
                    url: "get-transfers",
                    data: data,
                    type: "POST",
                    success: function (compressed) {
                        if (compressed.transfers && compressed.transfers.length == 0) {
                            self.notifyErrorMessage('');
                        }
                        self.transfers = compressed.transfers;
                        $.each(compressed.transfers, function (index, item) {
                            item.arrivalDate = self.packageQuery.departureDate;
                            item.returnDate = self.packageQuery.returnDate;
                            if (self.packageQuery.hasFlight && self.packageQuery.hasHotel && self.packageQuery.hotels && self.packageQuery.hotels.length > 0 && item.questions && item.questions.length > 1) {
                                item.questions[0].value = self.packageQuery.hotels[0].name;
                                item.questions[1].value = self.packageQuery.hotels[0].addressLines;
                            }
                            else if (self.hotelTransfer && item.questions && item.questions.length > 1) {
                                item.questions[0].value = self.hotelTransfer.name;
                                item.questions[1].value = self.hotelTransfer.address;
                            }

                            if (item.questions && item.questions.length > 2) {
                                item.questions[2].value = self.packageQuery.toCityName;
                            }

                            item.selectedVehicle = item.vehicles[0];
                            $.each(item.vehicles, function (i, vehicle) {
                                if (!item.selected) {
                                    if (vehicle.pickUpDate != null) {
                                        vehicle.pickUpDate = moment(String(vehicle.pickUpDate)).format('YYYY-MM-DD');
                                    }
                                    if (self.packageQuery.transferSearchInfo) {
                                        vehicle.hotelCode = self.packageQuery.transferSearchInfo.accommodationGeoCoords;
                                        if (!item.isReturnJourney) {
                                            vehicle.pickUpTime = self.packageQuery.transferSearchInfo.travelTime;
                                            vehicle.flightTime = self.packageQuery.transferSearchInfo.travelTime;
                                            vehicle.flightNo = self.packageQuery.transferSearchInfo.outboundFlightNo;
                                        }
                                        else {
                                            if (self.packageQuery.transferSearchInfo.transferType != 'ToAirport') {
                                                vehicle.flightTime = self.packageQuery.transferSearchInfo.returnTime;
                                                self.setPickupTime(item, self.packageQuery.transferSearchInfo.returnTime);
                                                vehicle.flightNo = self.packageQuery.transferSearchInfo.inboundFlightNo;
                                            }
                                            else {
                                                vehicle.flightTime = self.packageQuery.transferSearchInfo.travelTime;
                                                vehicle.pickUpTime = self.packageQuery.transferSearchInfo.travelTime;
                                                self.setPickupTime(item, self.packageQuery.transferSearchInfo.travelTime);
                                                vehicle.flightNo = self.packageQuery.transferSearchInfo.inboundFlightNo;
                                            }
                                        }
                                    }
                                }
                                else {
                                    vehicle.pickUpDate = vehicle.pickUpDate.substr(0, 10);
                                }
                                if (vehicle.selected) {
                                    item.selectedVehicle = vehicle;
                                }
                            });

                            if (item.selected) {
                                // self.hasAddTransfer = true;

                                item.isExpand = true;
                                item.selectedVehicle.pickUpDate = item.selectedVehicle.pickUpDate.substr(0, 10);

                                var pickUpTime = item.vehicles[0].pickUpTime.split(":");
                                if (item.isReturnJourney) {
                                    self.departureTransfer = item;
                                    self.transferSelected.departureTransfer = item;
                                    self.hasAddDepartureTransfer = true;

                                    self.departureDateSelected = moment(item.vehicles[0].pickUpDate);
                                    self.departureDateSelected.set({ hour: pickUpTime[0], minute: pickUpTime[1] });

                                } else {
                                    self.arrivalTransfer = item;
                                    self.transferSelected.arrivalTransfer = item;
                                    self.hasAddArrivalTransfer = true;

                                    self.arrivalDateSelected = moment(item.vehicles[0].pickUpDate);
                                    self.arrivalDateSelected.set({ hour: pickUpTime[0], minute: pickUpTime[1] });
                                }
                            }
                            else {
                                item.isExpand = false;
                            }

                        });

                        self.pagination.currentRowOnPage = compressed.transfers.length;
                        self.pagination.totalTransfers = compressed.totalTransfers;
                        self.pagination.totalPages = Math.ceil(compressed.totalTransfers / self.pagination.transferPerPage);

                        self.departureTransfers = self.transfers.filter(function (x) { return x.isReturnJourney === true });
                        self.arrivalTransfers = self.transfers.filter(function (x) { return x.isReturnJourney === false });
                        self.hasArrivalTransfer = compressed.transfers.some(x => x.isReturnJourney == false);
                        self.hasDepartureTransfer = compressed.transfers.some(x => x.isReturnJourney == true);

                        self.loading.bookingTransfer = false;

                        /*if (self.arrivalTransfers && self.arrivalTransfers.length > 0) {
                            self.arrivalTransfer = self.transferSelected.arrivalTransfer ? self.transferSelected.arrivalTransfer : self.arrivalTransfers[0];
                            if (!self.transferSelected.arrivalTransfer) {
                                self.arrivalTransfer.selected = true;
                                self.arrivalTransfer.selectedVehicle.selected = true;
                                self.transferSelected.arrivalTransfer = self.arrivalTransfer;
                            }
                            self.cheapestTransferPrice += self.arrivalTransfers[0].totalPrice;
                        }
                        if (self.departureTransfers && self.departureTransfers.length > 0) {
                            self.departureTransfer = self.transferSelected.departureTransfer ? self.transferSelected.departureTransfer : self.departureTransfers[0];
                            if (!self.transferSelected.departureTransfer) {
                                self.departureTransfer.selected = true;
                                self.departureTransfer.selectedVehicle.selected= true;
                                self.transferSelected.departureTransfer = self.departureTransfer;
                            }
                            self.cheapestTransferPrice += self.departureTransfers[0].totalPrice;
                        }*/
						if (self.arrivalTransfers && self.arrivalTransfers.length > 0) {
                            // self.arrivalTransfer = self.transferSelected.arrivalTransfer ? self.transferSelected.arrivalTransfer : self.arrivalTransfers[0];
                            // if (!self.transferSelected.arrivalTransfer) {
                            //     self.arrivalTransfer.selected = true;
                            //     self.arrivalTransfer.selectedVehicle.selected = true;
                            //     self.transferSelected.arrivalTransfer = self.arrivalTransfer;
                            // }
                            self.cheapestTransferPrice = Math.max(self.cheapestTransferPrice, self.arrivalTransfers[0].totalPrice);
                        }
                        if (self.departureTransfers && self.departureTransfers.length > 0) {
                            // self.departureTransfer = self.transferSelected.departureTransfer ? self.transferSelected.departureTransfer : self.departureTransfers[0];
                            // if (!self.transferSelected.departureTransfer) {
                            //     self.departureTransfer.selected = true;
                            //     self.departureTransfer.selectedVehicle.selected= true;
                            //     self.transferSelected.departureTransfer = self.departureTransfer;
                            // }
                            self.cheapestTransferPrice = Math.max(self.cheapestTransferPrice, self.departureTransfers[0].totalPrice);
                        }
                        self.tempTransfer = {
                            transfer: self.arrivalTransfers && self.arrivalTransfers.length > 0 ? self.arrivalTransfers[0] : self.departureTransfers[0],
                            isSummary: false
                        };
                    },
                    complete: function () {
                        $('#page-loader').hide();
                        self.loading.bookingTransfer = false;
                    }
                });
            },
            checkSearchComplete: function (callback) {
                var self = this;
                if (callback) {
                    callback();
                }

                if (!self.hasErrorMessage) {
                    $.ajax("/package/get-transfer-filters", {
                        data: {
                            packageId: self.packageQuery.id
                        },
                        type: "POST",
                        success: function (compressed) {
                            var filters = compressed;
                            self.minPriceTransfer = self.selectedMinPrice = filters.minPrice;
                            self.maxPriceTransfer = self.selectedMaxPrice = filters.maxPrice;

                            for (var property in filters.categories) {
                                if (filters.categories.hasOwnProperty(property)) {
                                    self.categories.push({
                                        key: property,
                                        value: filters.categories[property],
                                        selected: false
                                    });
                                }
                            }

                            self.isSearchCompleted = true;
                        },
                        error: function () {
                            self.isSearchCompleted = true;
                        }
                    });
                } else {
                    self.isSearchCompleted = true;
                }
                self.hideSplashScreen();
            },
            hideSplashScreen() {
                $('#loading-page').addClass('hidden');
                $('#app').removeClass('modal-open');
            },
            checkBookingTransfer: function (event, nextUrl) {
                var self = this;
                event.preventDefault();
                if (self.packageQuery.hasFlight && self.packageQuery.hasHotel) {
                    window.location.replace(nextUrl);
                }
                else if (self.transferSelected.departureTransfer || self.transferSelected.arrivalTransfer) {
                    window.location.href = nextUrl;
                }
                else {
                    bootbox.dialog({
                        message: self.translateText('PLEASE_SELECT_ANY_TRANSFER', 'Please select any transfer and then continue.'),
                        buttons: {
                            close: {
                                label: "Close",
                                className: "btn-danger",
                                callback: function () {
                                }
                            }
                        }
                    });

                    $('#page-loader').hide();
                    self.loading.bookingTransfer = false;
                }

            },
            range: function (min, max) {
                var array = [],
                    j = 0;
                for (var i = min; i <= max; i++) {
                    array[j] = i;
                    j++;
                }
                return array;
            },
            onChangeNoOfVehicle(obj) {
                obj.vehicle.noOfVehicle = obj.numVehicle;
                this.changeNoOfVehicle(obj.transfer, obj.vehicle);
            },
            changeNoOfVehicle: function (transfer, vehicle) {
                var self = this;
                $.ajax("/package/transfer-calculateprice-noofvehicle", {
                    data: {
                        packageId: self.packageQuery.id,
                        transferId: transfer.id,
                        vehicleCode: vehicle.vehicleCode,
                        noOfVehicle: vehicle.noOfVehicle
                    },
                    type: "POST",
                    success: function (response) {
                        if (response.success) {
                            if (transfer.isReturnJourney) {
                                vehicle.totalPrice = response.departureTransfer.totalPrice;
                            } else {
                                vehicle.totalPrice = response.arrivalTransfer.totalPrice;
                            }
                        } else {
                            bootbox.dialog({
                                message: response.message,
                                buttons: {
                                    close: {
                                        label: "Close",
                                        className: "btn-danger",
                                        callback: function () {
                                        }
                                    }
                                }
                            });
                        }
                    },
                    error: function (request, status, error) {
                    }
                });
            },
            getHotelName: function (transfer, vehicle, code) {
                if (transfer.accommodations != null) {
                    for (var i = 0; i < transfer.accommodations.length; i++) {
                        var hotelCode = transfer.accommodations[i].code;
                        if (hotelCode == code) {
                            vehicle.hotelName = transfer.accommodations[i].name;
                            return;
                        } else {
                            vehicle.hotelName = "";
                        }
                    }
                }
            },
            bookingTransfer: function (e, transfer, vehicle, index) {
                var self = this;
                if (e) e.preventDefault();
                var form = $(e.target);
                var datePicker = form.find('.PickupDateTime');
                var validFlightNo = self.validateFlightNo(form);
                var isArrival = $(e.target).attr('data-arrival') ? true : false;
                if (validFlightNo) {
                    if (typeof datePicker !== 'undefined' && datePicker.length > 0) {
                        var tmpPickUpTime = datePicker.find('input[name="PickUpTime"]').val();
                        var tmpPickUpDate = datePicker.find('input[name="PickUpDate"]').val();
                        if (tmpPickUpTime.toString() != tmpPickUpDate.toString()) {
                            vehicle.pickUpDate = tmpPickUpDate;
                            vehicle.pickUpTime = tmpPickUpTime;
                        }
                    }

                    let pickUpTime = vehicle.pickUpTime ? vehicle.pickUpTime.split(":") : [];
                    if (pickUpTime && pickUpTime.length > 0) {
                        if (transfer.isReturnJourney) {
                            self.departureDateSelected = moment(vehicle.pickUpDate);
                            self.departureDateSelected.set({ hour: pickUpTime[0], minute: pickUpTime[1] });
                        }
                        else {
                            self.arrivalDateSelected = moment(vehicle.pickUpDate);
                            self.arrivalDateSelected.set({ hour: pickUpTime[0], minute: pickUpTime[1] });
                        }
                    }

                    if (self.arrivalDateSelected != null && self.departureDateSelected != null && self.arrivalDateSelected > self.departureDateSelected) {
                        bootbox.dialog({
                            message: self.translateText('PLEASE_SELECT_DEPARTURE_PICKUP_TIME_AFTER_ARRIVAL_PICKUP_TIME', 'Please select departure pick-up time after arrival pick-up time'),
                            buttons: {
                                close: {
                                    label: "Close",
                                    className: "btn-danger",
                                    callback: function () {
                                    }
                                }
                            }
                        });
                    }
                    else {
                        vehicle.loading = true;
                        transfer.selectedVehicle = vehicle;

                        // if (transfer.isReturnJourney) {
                        //     for (var i = 0; i < self.departureTransfers.length; i++) {
                        //         if (self.departureTransfers[i].selected && self.departureTransfers[i].selectedVehicle.selected) {
                        //             self.removeTransfer(null, self.departureTransfers[i], self.departureTransfers[i].selectedVehicle, i);
                        //         }
                        //     }
                        //     Vue.set(self.departureTransfers, index, transfer);
                        // }
                        // else {
                        //     for (var i = 0; i < self.arrivalTransfers.length; i++) {
                        //         if (self.arrivalTransfers[i].selected && self.arrivalTransfers[i].selectedVehicle.selected) {
                        //             self.removeTransfer(null, self.arrivalTransfers[i], self.arrivalTransfers[i].selectedVehicle, i);
                        //         }
                        //     }
                        //     Vue.set(self.arrivalTransfers, index, transfer);
                        // }

                        if (transfer.isReturnJourney) {
                            Vue.set(self.departureTransfers, index, transfer);
                        }
                        else {
                            Vue.set(self.arrivalTransfers, index, transfer);
                        }

                        if (self.hotelTransfer) {
                            vehicle.hotelName = self.hotelTransfer.name;
                        }

                        self.addToQueue("/package/booking-transfer", "POST", {
                                PackageId: self.packageQuery.id,
                                TransferId: transfer.id,
                                AirportCode: self.packageQuery.to,
                                HotelCode: vehicle.hotelCode,
                                FlightNo: vehicle.flightNo,
                                NoOfVehicle: vehicle.noOfVehicle,
                                FlightTime: vehicle.flightTime,
                                PickUpTime: vehicle.pickUpTime,
                                PickUpDate: vehicle.pickUpDate,
                                HotelName: vehicle.hotelName,
                                VehicleCode: vehicle.vehicleCode,
                                Answers: transfer.questions
                            },
                            function (data, status, xhr) {
                                var response = data;
                                if (response.success) {
                                    transfer.selected = true;
                                    vehicle.selected = true;
                                    transfer.isExpand = true;

                                    if (self.transferSelected == null) {
                                        self.transferSelected = {};
                                    }
                                    if (response.arrivalTransfer != null) {
                                        self.transferSelected.arrivalTransfer = response.arrivalTransfer;
                                        self.packageQuery.arrivalTransfer = response.arrivalTransfer;

                                        var arrivalPickUpTime = response.arrivalTransfer.vehicles[0].pickUpTime.split(":");
                                        self.arrivalDateSelected = moment(response.arrivalTransfer.vehicles[0].pickUpDate);
                                        self.arrivalDateSelected.set({ hour: arrivalPickUpTime[0], minute: arrivalPickUpTime[1] });                                      
                                    }
                                    if (response.departureTransfer != null) {
                                        self.transferSelected.departureTransfer = response.departureTransfer;
                                        self.packageQuery.departureTransfer = response.departureTransfer;

                                        var departurePickUpTime = response.departureTransfer.vehicles[0].pickUpTime.split(":");
                                        self.departureDateSelected = moment(response.departureTransfer.vehicles[0].pickUpDate);
                                        self.departureDateSelected.set({ hour: departurePickUpTime[0], minute: departurePickUpTime[1] }); 
                                    }
                                    if (transfer.isReturnJourney) {
                                        self.departureTransfer = transfer;
                                        self.hasAddDepartureTransfer = true;
                                    }
                                    else {
                                        self.arrivalTransfer = transfer;
                                        self.hasAddArrivalTransfer = true;
                                    }
                                    self.getPriceSummary();
                                    self.backTop(function() {
                                        let detail = $(".avai-transfer .fh-tabs__detail");
                                        let selectorTabs = $('.fh-tabs__wrap');
                                        detail.collapse('hide');
                                        selectorTabs.find(".fh-tabs__item").removeClass('active show');
                                        if (isArrival) selectorTabs.find('.fh-tabs__item[href="#tabs-arrival"]').addClass('active show');
                                        else selectorTabs.find('.fh-tabs__item[href="#tabs-departure"]').addClass('active show');
                                    });
                                } else {
                                    bootbox.dialog({
                                        message: response.message,
                                        buttons: {
                                            close: {
                                                label: "Close",
                                                className: "btn-danger",
                                                callback: function () {
                                                }
                                            }
                                        }
                                    });
                                    //self.transferSelected = {};
                                }

                                vehicle.loading = false;
                                transfer.selectedVehicle = vehicle;

                                if (transfer.isReturnJourney) {
                                    Vue.set(self.departureTransfers, index, transfer);
                                }
                                else {
                                    Vue.set(self.arrivalTransfers, index, transfer);
                                }
                            }, function (xhr, status, error) {
                                vehicle.loading = false;
                            });
                    }
                }
            },
            onRemoveTransfer(obj) {
                let self = this;
                let transferIndex = obj.isArrival ? self.arrivalTransfers.indexOf(obj.transfer) : self.departureTransfers.indexOf(obj.transfer);
                self.removeTransfer(null, obj.transfer, obj.transfer.selectedVehicle, transferIndex, null);
            },
            removeTransfer: function (e, transfer, vehicle, index, callback) {
                var self = this;
                vehicle.loading = true;
                transfer.selectedVehicle = vehicle;
                if (transfer.isReturnJourney) {
                    $.each(self.departureTransfers, function (index, item) {
                        item.selectedVehicle.flightNo = null;
                    });
                } else {
                    $.each(self.arrivalTransfers, function (index, item) {
                        item.selectedVehicle.flightNo = null;
                    });
                }
                //transfer.selectedVehicle.flightNo = null;

                if (transfer.isReturnJourney) {
                    Vue.set(self.departureTransfers, index, transfer);
                }
                else {
                    Vue.set(self.arrivalTransfers, index, transfer);
                }
                self.addToQueue("/package/remove-transfer", "POST", { packageId: self.packageQuery.id, transferId: transfer.id },
                    function (data, status, xhr) {
                        var response = data;
                        if (response.success) {
                            transfer.selected = false;
                            vehicle.selected = false;
                            transfer.isExpand = false;

                            if (transfer.isReturnJourney) {
                                self.departureTransfer = null;
                                self.transferSelected.departureTransfer = null;
                                self.packageQuery.departureTransfer = null;
                                self.hasAddDepartureTransfer = false;
                            } else {
                                self.arrivalTransfer = null;
                                self.transferSelected.arrivalTransfer = null;
                                self.packageQuery.arrivalTransfer = null;
                                self.hasAddArrivalTransfer = false;
                            }
                            self.hasTransfer = false;
                            self.getPriceSummary();
                            if (typeof callback === "function") {
                                callback();
                            }
                        } else {
                            bootbox.dialog({
                                message: response.message,
                                buttons: {
                                    close: {
                                        label: "Close",
                                        className: "btn-danger",
                                        callback: function () {
                                        }
                                    }
                                }
                            });
                        }
                        vehicle.loading = false;
                        if (transfer.isReturnJourney) {
                            Vue.set(self.departureTransfers, index, transfer);
                        }
                        else {
                            Vue.set(self.arrivalTransfers, index, transfer);
                        }
                        // self.hasAddTransfer = false;
                    }, function (xhr, status, error) {
                        vehicle.loading = false;
                    });

            },
            sorting: function (sortOrderBy) {
                var self = this;
                if (self.sortOrderBy === sortOrderBy) {
                    self.sortOrderByAsc = !self.sortOrderByAsc;
                } else {
                    self.sortOrderBy = sortOrderBy;
                    self.sortOrderByAsc = true;
                }
                self.getResultsPage(1, true);
            },
            
            getPriceSummary: function () {
                var self = this;
                $.ajax("/booking/get-price-summary", {
                    data: {
                        packageId: self.packageQuery.id,
                        promoCode: self.packageQuery.promoCode,
                        creditCardNumber: ""
                    },
                    type: "POST",
                    success: function (response) {
                        self.packageQuery.priceSummary = response;
                    },
                    error: function () {
                    }
                });
            },
            getFormTransferPerPage: function (currentPage, pageSize) {
                var result = 0;
                var self = this;
                if (currentPage === 1) {
                    result = 1;
                }
                else {
                    result = (currentPage - 1) * pageSize + 1;
                }
                return result;
            },
            toggle: function (el, transfer, transfers) {
                var $this = $('#transfer' + transfer.id.trim());
                var transferType = $(el.target).data('transfer-type');

                if (transferType == 'Arrivaltransfer') {
                    $('.transfer-arrival .hotel-list .depart-transfers').not($this).slideUp('fast');
                } else if (transferType == 'Departuretransfer') {
                    $('.transfer-departure .hotel-list .return-transfers').not($this).slideUp('fast');
                }
                $this.slideToggle('fast');
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            showTransferInfo: function (transfer) {
                this.transferInfo.name = transfer.name;
                this.transferInfo.description = transfer.description;
                this.transferInfo.meetingPoint = transfer.meetingPoint;
                this.transferInfo.conditions = transfer.transferConditions;
                $("#transferInfor").modal('show');
            },
            getRegionInfo: function (callback) {
                var self = this;
                var regionid = self.packageQuery.transferSearchInfo.regionId;
                var firstChar = regionid.charAt(0);
                if (firstChar == "H" || firstChar == "R") {
                    var id = regionid.substr(2);
                    var url = '';
                    if (firstChar == "H") {
                        url = '/api/get-hotel-info';
                        var data = {
                            CityCode: self.packageQuery.to,
                            CultureCode: self.packageQuery.cultureCode,
                            HotelId: id,
                            PackageId: self.packageQuery.id
                        };
                        $.ajax({
                            url: url,
                            data: data,
                            type: "POST",
                            success: function (result) {
                                if (!result) self.hasErrorMessage = true;
                                if (callback) {
                                    callback(result.hotelDetail);
                                }
                            }
                        });
                    }
                    else {
                        url = '/api/search-regions';
                        var data = {
                            cultureCode: self.packageQuery.cultureCode,
                            regionIds: id
                        };
                        $.ajax({
                            url: url,
                            data: data,
                            type: "POST",
                            success: function (result) {
                                self.regionInfo = result;
                                if (callback) {
                                    callback();
                                }
                            }
                        });
                    }
                }
                else {
                    $.ajax({
                        url: "/package/get-hotel-by-expedia-code/" + regionid + "/" + self.packageQuery.cultureCode,
                        type: "POST",
                        success: function (result) {
                            self.hotelInfo = result;
                            if (callback) {
                                callback();
                            }
                        }
                    });
                }
            },
            autoFillFlightNo: function (arrival) {
                let self = this;
                self.isChangeDateTime = false;
                $.each(arrival.isArrival ? self.arrivalTransfers : self.departureTransfers, function (index, item) {
                    item.selectedVehicle.flightNo = arrival.event.target.value;
                });
            },
            clickFlightNo: function () {
                this.isChangeDateTime = false;

            },
            displaySelected: function (isExpand) {

                if (isExpand) {
                    return {
                        'display': 'block'
                    };
                }
                else {
                    return {
                        'display': 'none'
                    };
                }
            },
            calcPromoPrice(callback) {
                var self = this;
                var cardNumber = $("#txtCreditCardNumber").val();
                var promoCode = $("#txtPromoCode").val();

                $.ajax({
                    type: "POST",
                    url: "/booking/get-price-summary",
                    data: {
                        packageId: this.packageQuery.id,
                        creditCardNumber: cardNumber,
                        promoCode: promoCode,
                        applyInsurance: this.isApplyInsurance,
                        addonDetails: null
                    },
                    success: function (data) {
                        self.packageQuery.priceSummary = data;
                        if (callback) {
                            callback(data);
                        }
                    }
                });
            },
            validateFlightNo: function (form) {
                var result = false;
                var elValidate = $(form.find("input[name='FlightNo']"))[0];
                var message = "";
                if (elValidate) {
                    var pattern = new RegExp('^[a-zA-Z0-9\\s]+$');
                    if (elValidate.value === null || elValidate.value.length === 0 || elValidate.value === undefined) {
                        $(elValidate).addClass("input-validation-error");
                        $(elValidate.parentElement.nextElementSibling).addClass("message-validation-error");
                        message = this.translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.');
                        $(elValidate.parentElement.nextElementSibling).text(message);
                    }
                    else if (!pattern.test(elValidate.value)) {
                        message = this.translateText('PLEASE_ANTER_ALPHA_NUMERIC_CHARACTERS_ONLY', 'Please enter alphanumeric characters only.');
                        $(elValidate.parentElement.nextElementSibling).addClass("message-validation-error");
                        $(elValidate.parentElement.nextElementSibling).text(message);
                        $(elValidate).addClass("input-validation-error");
                    }
                    else {
                        $(elValidate.parentElement.nextElementSibling).removeClass("message-validation-error");
                        $(elValidate.parentElement.nextElementSibling).text("");
                        $(elValidate).removeClass("input-validation-error");
                        result = true;
                    }
                }
                return result;
            },
            validateInput(context) {
                var parent = context.parents('.box-search');
                var label = parent.find(">strong");
                var labelVals = {
                    old: context.attr('data-label'),
                    new: context.attr('data-required-message')
                };

                if (!context.val()) {
                    parent.addClass('error');
                    label.text(labelVals.new);
                    return false;
                } else {
                    parent.removeClass('error');
                    label.text(labelVals.old);
                }
                return true;
            },
            onValidate(e) {
                var self = this;
                var box = $(self.$el)
                var errors = 0;
                box.find("input[name='From'], input[name='To'], input[name='TransferSearchInfo.RegionId']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                if (errors == 0) {
                    return true;
                }
                if (e) e.preventDefault();
            },
            setCancellationTransfer(data) { 
                let self = this; 
                if (data.isDeparture) {
                    self.transferCancellation.cancellationPolicies = self.packageQuery.departureTransfer.cancellationPolicies;
                    self.transferCancellation.transferName = self.packageQuery.departureTransfer.name;
                    self.transferCancellation.isDeparture = true;
                    //target.modal('show');                   
                } else {
                    self.transferCancellation.cancellationPolicies = self.packageQuery.arrivalTransfer.cancellationPolicies;
                    self.transferCancellation.transferName = self.packageQuery.arrivalTransfer.name;
                    self.transferCancellation.isDeparture = false;
                }
            },
            formatDate: function (date, convertType) {
                if (!date) return moment.utc();
                else return moment.utc(String(date)).format(convertType);
            },
            setDateCancellation: function (date, convertType) {              
                return moment.utc(String(date)).add(-1, 'day').format(convertType);
            },
            dateDiff(fromDate, toDate) {
                var fDate = Vue.moment(fromDate.split('T')[0]);
                var tDate = Vue.moment(toDate.split('T')[0]);

                if (tDate.diff(fDate) > 0) return true;
                return false;
            },
            formatCurrency: function (value) {
                let curDecimals = this.$store.state.workContext.packageQuery.currencyDecimals;
                let val = value ? value.toFixed(curDecimals ? curDecimals : 0) : value;
                return (val + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            setAccommodationGeoCoords(geoCoords) {
                this.hotelTransfer.latitude = geoCoords.latitude;
                this.hotelTransfer.longitude = geoCoords.longitude;
            }
        },
        watch: {
            flightNo: {
                handler: function (val, oldVal) {
                    this.flightNo = val;
                    this.isLoadDateTime = false;
                }
            },
            cheapestTransferPrice(val) {
                let self = this;
                if (val) {
                    var previousSearches = Cookie.getJSON('recentSearches') || [];
                    if (previousSearches.length > 0) previousSearches = previousSearches.filter(pre => {
                        return pre.fromCode !== self.packageQuery.from || pre.toCode !== self.packageQuery.to || pre.departureDate !== self.packageQuery.departureDate || pre.returnDate !== self.packageQuery.returnDate || pre.passengers !== self.calculatePaxCount
                    });
                    if (previousSearches.length > 3) {
                        previousSearches.splice(0, 1);
                    }
                    previousSearches.push({
                        id: self.packageQuery.productId,
                        from: self.packageQuery.fromCityName,
                        fromCode: self.packageQuery.from,
                        to: self.packageQuery.toCityName,
                        toCode: self.packageQuery.to,
                        thumbnail: self.transfers && self.transfers.length > 0 ? self.transfers[0].images[0] : self.baseUrl + '/images/img-transfer.jpg',
                        product: self.product.type,
                        departureDate: self.packageQuery.departureDate,
                        returnDate: self.packageQuery.returnDate,
                        passengers: self.calculatePaxCount,
                        price: self.cheapestTransferPrice,
                        url: self.packageQuery.requestUrl,
                        currency: self.packageQuery.currency
                    });
                    Cookie.set('recentSearches', previousSearches, {expires: 1});
                    // console.log(Cookie.getJSON('recentSearches'));
                }
            },
            hasErrorMessage(value) {
                if (value)
                    $("#modalChangeDate").modal("hide")
            }
        }
    }
    
</script>
