﻿<template>
    <input class="ranger-price" id="js-ranger-price"/>
</template>
<script>
    export default {
        props: ['min', 'max', 'from', 'to', 'prefix', 'postfix', 'prettifySeparator', 'type', 'currencyDecimals'],
        data() {
            return {}
        },
        mounted: function () {
            var vm = this;
            var $element = $(vm.$el);
            
             $element.ionRangeSlider({
                min: vm.min,
                max: vm.max,
                type: vm.type ? vm.type : "double",
                prefix: vm.prefix,
                postfix: vm.postfix ? vm.postfix : '', 
                from: vm.min,
                to: vm.max, 
                min_interval: 1,
                grid: true,
                grid_num: 5,
                prettify: true,
                hasGrid: true,
                force_edges: true,
                prettify_separator: vm.prettifySeparator,
                value: [vm.min, vm.max],
                step: 1 / (Math.pow(10, vm.currencyDecimals ? vm.currencyDecimals : 0)),
                onFinish: function (numbers) {
                    vm.$emit('changed', numbers.from, numbers.to, vm.type);
                }
            });
        },
        watch: {
            min(minValue) {
                var $element = $(this.$el);
                var $slider = $element.data('ionRangeSlider');
                $slider.update({
                    min: minValue,
                    from: minValue
                });
            },
            max(maxValue) {
                var $element = $(this.$el);
                var $slider = $element.data('ionRangeSlider');
                $slider.update({
                    max: maxValue,
                    to: maxValue
                });
            },
            from(fromValue) {
                var $element = $(this.$el);
                var $slider = $element.data('ionRangeSlider');
                $slider.update({
                    from: fromValue
                });
            },
            to(toValue) {
                var $element = $(this.$el);
                var $slider = $element.data('ionRangeSlider');

                $slider.update({
                    to: toValue
                });
            }
        }
    }

</script>