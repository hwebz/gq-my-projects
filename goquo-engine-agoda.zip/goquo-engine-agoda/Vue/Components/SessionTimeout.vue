﻿<template>
    <div id="divSessionTime" class="relative">
        <div class='sessionTimeOut'>
            <p v-lang.EXPIRE_IN></p>
            <span class="time"></span> 
        </div>
    </div>
</template>

<script>
    export default {
        props: ['packageId', 'sessionTimeout', 'secondTimeout'],
        data() {
            return {}
        },
        mounted: function () {
            var vm = this;
            var $element = $(vm.$el);
            var n = new Date();

            var secondTimeOut = vm.secondTimeout;

            var timeout = (vm.sessionTimeout != undefined && vm.sessionTimeout != "") ? parseInt(vm.sessionTimeout) : 25;
            var seconds = secondTimeOut > 0 ? secondTimeOut : timeout * 60;

            function setTimer() {
                var x = new Date() - n;
                var remain = seconds - Math.floor(x / 1000);

                $(".sessionTimeOut .time", $element).html(parseInt(remain / 60).padLeft(2, '0') + ":" + (remain % 60).padLeft(2, '0'));

                if (remain <= 0) {
                    window.location.replace(`/package/start-over/${vm.packageId}`);
                }
            };

            setInterval(function () { setTimer(); }, 1000);
        },
        methods: {

        }
    }
</script>
