<template>
    <div class="col-lg-3">
        <div class="sidebar__togger">
            <a class="sidebar-filter" href="javascript:void(0)" @click="togglePane('.sidebar-wrap', false)">
                <i class="icon-filter"></i>
                <span v-lang.FILTER></span>
            </a>
        </div>
        <div class="sidebar-overlay" @click="togglePane('.sidebar-wrap, .avai-findbar-mobie', true)"></div>
        <div class="sidebar-wrap">
            <div class="sidebar__navi">
                <span v-lang.FILTER_BY></span>
                <div class="sidebar__navi-close" @click="togglePane('.sidebar-wrap', false)">
                    <i class="icon-remove"></i>
                </div>
            </div>
            <div class="sidebar__box">
                <div class="sidebar__title">
                    <h2 v-lang.STOPS></h2>
                </div>
                <div class="sidebar__content" v-if="flightAggreation">
                    <div class="sidebar__dropdown">
                        <ul>
                            <li class="item-dropdown">
                                <div class="style-check">
                                    <input class="ipt-check" type="checkbox" name="airlineStops" v-model="flightAggreation.nonStop" id="non-stop" @change="filterByNumberOfStops" />
                                    <label class="ipt-label" for="non-stop">
                                        <span class="box"></span>
                                        <span class="drop-text" v-lang.NONSTOP_LOWER>
                                        </span>
                                    </label>
                                </div>
                            </li>
                            <li class="item-dropdown">
                                <div class="style-check">
                                    <input class="ipt-check" type="checkbox" name="airlineStops" v-model="flightAggreation.oneStop" id="one-stop" @change="filterByNumberOfStops" />
                                    <label class="ipt-label" for="one-stop">
                                        <span class="box"></span>
                                        <span class="drop-text" v-lang.ONE_STOP_LOWER></span>
                                    </label>
                                </div>
                            </li>
                            <li class="item-dropdown">
                                <div class="style-check">
                                    <input class="ipt-check" type="checkbox" name="airlineStops" v-model="flightAggreation.hasStops" id="more-stops" @change="filterByNumberOfStops" />
                                    <label class="ipt-label" for="more-stops">
                                        <span class="box"></span>
                                        <span class="drop-text" v-lang.ONE_PLUS_STOP_LOWER></span>
                                    </label>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div v-if="getAirlinesSorted">
                    <div class="sidebar__title">
                        <h2 v-lang.AIRLINE_NAME></h2>
                    </div>
                    <div class="sidebar__content">
                        <div class="sidebar__dropdown">
                            <ul v-if="flightAggreation.airlines.length > 0">
                                <li class="item-dropdown" v-for="(airline, airlineIndex) in getAirlinesSorted" :key="airlineIndex" v-if="isAvaibleFilterAirLineName(airline.key)">
                                    <div class="style-check">
                                        <input class="ipt-check" type="checkbox" name="airlineNames" :value="airline.key" :id="airline.key + 'air'" v-model="airline.selected" @change="filterByAirlines" />
                                        <label class="ipt-label" :for="airline.key + 'air'">
                                            <span class="box"></span>
                                            <div class="drop-text">
                                                <img :src="'https://gqcdn.s3.amazonaws.com/airline-logos/svg/' + airline.key + '.svg'" alt="" class="airline-icon">
                                                <span>{{airline.value}}</span>
                                            </div>
                                        </label>
                                    </div>
                                </li>
                            </ul>
                            <ul v-else>
                                <li class="item-dropdown">
                                    <div class="lda full">
                                        <div class="lda__bar lda__bar--split lda__bar--h27"></div>
                                        <div class="lda__bar lda__bar--split lda__bar--h27"></div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div v-if="flightAggreation">
                    <div class="sidebar__title">
                        <h2><span v-lang.DEPARTURE_TIME></span> <small>- {{showOutboundFlights ? packageQuery.fromCityName : packageQuery.toCityName}}</small></h2>
                    </div>
                    <div class="sidebar__content">
                        <div class="sidebar__price">
                            <div class="result-sidebar-box">
                                <IonRangeSlider :min="0"
                                                :max="24"
                                                :from="showOutboundFlights ? calculateTime(flightStore.outboundFilters.outboundFilter.minDepartureTime) : calculateTime(flightStore.inboundFilters.inboundFilter.minDepartureTime)"
                                                :to="showOutboundFlights ? calculateTime(flightStore.outboundFilters.outboundFilter.maxDepartureTime) : calculateTime(flightStore.inboundFilters.inboundFilter.maxDepartureTime)"
                                                :postfix="':00'"
                                                :type="'departureTime'"
                                                prettifySeparator=":"
                                                @changed="setDepartureTimes" />
                            </div>
                        </div>
                    </div>
                </div>
                <div v-if="flightAggreation">
                    <div class="sidebar__title">
                        <h2><span v-lang.ARRIVAL_TIME></span> <small>- {{showOutboundFlights ? packageQuery.toCityName : packageQuery.fromCityName}}</small></h2>
                    </div>
                    <div class="sidebar__content">
                        <div class="sidebar__price">
                            <div class="result-sidebar-box">
                                <IonRangeSlider :min="0"
                                                :max="24"
                                                :from="showOutboundFlights ? calculateTime(flightStore.outboundFilters.outboundFilter.minArrivalTime) : calculateTime(flightStore.inboundFilters.inboundFilter.minArrivalTime)"
                                                :to="showOutboundFlights ? calculateTime(flightStore.outboundFilters.outboundFilter.maxArrivalTime) : calculateTime(flightStore.inboundFilters.inboundFilter.maxArrivalTime)"
                                                :postfix="':00'"
                                                :type="'arrivalTime'"
                                                prettifySeparator=":"
                                                @changed="setArrivalTimes" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import IonRangeSlider from './IonRangeSlider.vue'
    export default {
        components: { IonRangeSlider },
        props: ["packageQuery", "flightAggreation", "flightStore", "showOutboundFlights"],
        data() {
            return {
            }
        },
        computed: {
            getAirlinesSorted() {
                return this.flightAggreation.airlines.sort((a, b) => a.value ? a.value.localeCompare(b.value) : 1);
            }
        },
        methods: {
            calculateTime(time) {
                var timeInNumber = time ? parseInt(time.toString().split(":")[0]) : 0;
                return timeInNumber;
            },
            setDepartureTimes(min, max) {
                min = min + ":00";
                max = max + ":00";
                var times = {
                    min: min,
                    max: max
                };
                this.$emit('onDepartureTimesChanged', times);
            },
            setArrivalTimes(min, max) {
                min = min + ":00";
                max = max + ":00";
                var times = {
                    min: min,
                    max: max
                };
                this.$emit('onArrivalTimesChanged', times);
            },
            filterByNumberOfStops() {
                this.$emit('onFilterByNumberOfStops');
            },
            filterByAirlines() {
                this.$emit('onFilterByAirlines');
            },
            togglePane(element, isClosed) {
                this.$emit('onTogglePaneChanged', {
                    element: element,
                    isClosed: isClosed
                });
            },
            isAvaibleFilterAirLineName(key) {
                var self = this;
                if (self.showOutboundFlights) {
                    return true;
                }
                else {
                    if (self.flightStore.inboundFlights.length == 0) return false;

                    var tmpAirline = self.flightStore.inboundFlights;
                    var indexAir = tmpAirline.map(function (flight) { return flight.airlineCode; }).indexOf(key);

                    if (indexAir > -1) {
                        return true;
                    }
                }

                return false;
            }
        }
    }

</script>