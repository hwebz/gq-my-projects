<template>
    <div class="research">
        <div class="container">
            <nav class="crumbar">
                <ul>
                    <li v-if="params.productType === 'Flight_Hotel'" v-lang.SEARCH_FLIGHTS_AND_HOTELS_FROM_TO="{0: params.fromCity, 1: params.toCity}"></li>
                    <li v-else v-lang.SEARCH_HOTELS_IN="{0: params.toCity}"></li>
                </ul>
            </nav>
            <div class="research__wrap">
                <h1 v-if="params.productType === 'Flight_Hotel'" v-lang.YOUR_SEARCH_FLIGHTS_AND_HOTELS_FROM_TO="{0: params.fromCity, 1: params.toCity}"></h1>
                <h1 v-else v-lang.YOUR_SEARCH_HOTELS_IN="{0: params.toCity}"></h1>
            </div>
            <div class="research__content">
                <div class="research__title">
                    <h2 v-lang.YOUR_SEARCH_DATE_FROM_TO="{0: (params.departureDate | moment('DD MMMM YYYY')), 1: (params.returnDate | moment('DD MMMM YYYY'))}"></h2>
                    <p v-lang.CHECK_YOUR_SPELLING_AND_TRY_AGAIN></p>
                </div>
                <div class="research__form">
                    <div class="search-wrap">
                        <div class="search-tabs search-research">
                            <div class="search-content" v-for="(product, productIndex) in products" :key="productIndex" v-if="params.productType == product.type">
                                <template v-if="product.type == 'Flight_Hotel'">
                                    <FlightHotelSearchBox :product="product" :defaultDate="defaultDate" :from="params.from" :fromCity="params.fromCity" :to="params.to" :toCity="params.toCity" :cabinClass="packageQuery.cabinClass" />
                                </template>
                                <template v-if="product.type == 'Hotel'">
                                    <HotelSearchBox :product="product" :defaultDate="defaultDate" journeyType="1" />
                                </template>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Vue from 'vue';
    import FlightHotelSearchBox from './FlightHotelSearchBox.vue'
    import HotelSearchBox from './HotelSearchBox.vue'

    export default {
        name: "SearchBox",
        data() {
            return {
                products: [],
                packageQuery: null,
                defaultDate: null,
                params: {
                    productType: null, 
                    from: null, 
                    to: null, 
                    fromCity: null, 
                    toCity: null, 
                    departureDate: null, 
                    returnDate: null
                }
            };
        },
        created() {
            var self = this;
            var query = self.$route.query;
            self.params = {
                productType: query.ProductType,
                from: query.From,
                to: query.To,
                fromCity: query.FromCity,
                toCity: query.ToCity,
                departureDate: new Date(query.DepartureDate),
                returnDate: new Date(query.ReturnDate)
            }
            
            $.post('/package/work-context', function (data) {
                data.baseUrl = $("#baseURL").val();
                self.$store.commit('setWorkContext', data);
                self.products = data.products;
                self.isComplete = true;

                // hide splash screen
                $('#app').removeClass('modal-open');

                setTimeout(function () {
                    $('#loading-page').addClass('hidden');
                }, 300);
            });

            var startDate = Vue.moment().format('MM/DD/YYYY');
            var endDate = Vue.moment().add(2, 'days').format('MM/DD/YYYY');

            this.defaultDate = startDate + ',' + endDate;
        },
        methods: {
            formatDate(date, format) {
                return Vue.moment(date).format(format);
            },
        },
        mounted() {
                
        },
        components: {FlightHotelSearchBox, HotelSearchBox }
    }
</script>
