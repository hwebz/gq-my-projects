<template>
    <div class="box-search dropdown flight-only">
        <strong v-lang.CABIN_CLASS></strong>
        <div class="search-input dropdown-toggle" data-toggle="dropdown">
            <i class="ico icon-flight"></i>
            <div class="ipt-show">
                <span v-show="curCabinClass == 1" v-lang.ECONOMY_CLASS></span>
                <span v-show="curCabinClass == 2" v-lang.BUSINESS_CLASS></span>
                <span v-show="curCabinClass == 3" v-lang.FIRST_CLASS></span>
                <span v-show="curCabinClass == 4" v-lang.PREMIUM_CLASS></span>
            </div>
        </div>
        <div class="room-guests dropdown-menu">
            <div class="radio-pure-box">
                <div class="radio-pure">
                    <input :id="id + '-fh-economyClass'" type="radio" name="CabinClass" value="1" v-model="curCabinClass">
                    <label :for="id + '-fh-economyClass'" v-lang.ECONOMY_CLASS></label>
                </div>
                <div class="radio-pure" v-show="uniqueId != 5">
                    <input :id="id + '-fh-businessClass'" type="radio" name="CabinClass" value="2" v-model="curCabinClass">
                    <label :for="id + '-fh-businessClass'" v-lang.BUSINESS_CLASS></label>
                </div>
                <div class="radio-pure">
                    <input :id="id + '-fh-firstClass'" type="radio" name="CabinClass" value="3" v-model="curCabinClass">
                    <label :for="id + '-fh-firstClass'" v-lang.FIRST_CLASS></label>
                </div>
                <div class="radio-pure" v-show="uniqueId != 5">
                    <input :id="id + '-fh-premiumEconomy'" type="radio" name="CabinClass" value="4" v-model="curCabinClass">
                    <label :for="id + '-fh-premiumEconomy'" v-lang.PREMIUM_CLASS></label>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import {uuid} from 'vue-uuid'
    
    export default {
        name: 'CabinClass',
        components: { },
        props: ['cabinClass','uniqueId'],
        data() {
            return {
                curCabinClass: this.cabinClass,
                id: uuid.v1()
            }
        },
        created() {
            this.curCabinClass = this.cabinClass ? this.cabinClass : 1;
        }
    }
</script>