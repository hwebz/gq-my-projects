﻿<template>
    <div :id="id"
         class="tab-pane fade scroll-hoz"
         :class="{'show active': isActive}"
         v-if="tyCat">
        <div class="reviews-all__cat typical-list" v-for="cat in tyCat.category_list">
            <h5>{{cat.category_name}}</h5>
            <div class="reviews-bar" :class="{
                        'reviews-score__excellent' : cat.score >= 75, 
                        'reviews-score__very-good' : (cat.score <= 75 && cat.score >= 60), 
                        'reviews-score__good' : (cat.score <= 59 && cat.score >= 50), 
                        'reviews-score__fair' : (cat.score <= 49 && cat.score >= 35), 
                        'reviews-score__poor' : cat.score < 35}"></div>
            <ul class="summary-reviews typical-item">
                <li v-for="sentence in cat.summary_sentence_list">
                    <span class="ico icon-user"></span>
                    <span class="text">{{sentence}}</span>
                </li>
            </ul>
            <ul class="hightlight-reviews typical-item">
                <li v-for="highlight in cat.hightlight_list">
                    <span class="ico icon-user"></span>
                    <span class="text">{{highlight}}</span>
                </li>
            </ul>
        </div>
        <h4 class="good-to-know__title" v-lang.GOOD_TO_KNOW></h4>
        <div class="good-to-know__wrapper">
            <div class="reviews-good-to-know typical-list" :class="{'neg': gtk.sentiment == 'neg', 'pos': gtk.sentiment != 'neg'}" v-for="gtk in tyCat.good_to_know_list">
                <h5>
                    <span class="ico icon-cross" v-if="gtk.sentiment == 'neg'"></span>
                    <span class="ico icon-check-mark" v-else></span>
                    <span>{{gtk.text}}</span>
                </h5>
                <ul class="reviews-good-to-know__highglights typical-item">
                    <li v-for="highlight in gtk.highlight_list">
                        <span class="ico icon-user"></span>
                        <span class="text">{{highlight}}</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
            };
        },
        computed: {
            
        },
        props: ['tyCat', 'id', 'isActive'],
        methods: {
            
        }
    }
</script>