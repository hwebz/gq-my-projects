<template>
    <div class="maps__wrap__nav">
        <div class="maps-nav">
            <div class="maps-nav__wrap">
                <div class="maps-nav__box__big-title">
                    <h3 v-lang.MAP_VIEW></h3>
                </div>
                <div class="maps-nav__box">
                    <div class="maps-nav__box__title"><strong v-lang.TOTAL_PACKAGE_PRICE></strong></div>
                    <div class="maps-nav__box__content">
                        <div class="maps-nav__ranger">
                            <IonRangeSlider v-show="!hotelStore.maxHotelPrice"
                                            :min="calculateTotalPrice(hotelStore.minPrice)"
                                            :max="calculateTotalPrice(hotelStore.maxPrice)"
                                            :from="calculateTotalPrice(hotelsOptions.minPrice)"
                                            :to="calculateTotalPrice(hotelsOptions.maxPrice)"
                                            :prefix="packageQuery.currency + ' '" 
                                            prettifySeparator=","
                                            :currencyDecimals="packageQuery.currencyDecimals"
                                            @changed="setMinMaxPrice"
                                            :flightChangePrice="flightChangePrice" />
                        </div>
                    </div>
                </div>
                <div class="maps-nav__box">
                    <div class="maps-nav__box__title"><strong v-lang.STAR_RATING></strong></div>
                    <div class="maps-nav__box__content">
                        <div class="maps-nav__ddr">
                            <div class="rating-star-check">
                                <div class="rating-col" v-for="(star, starIndex) in hotelStore.stars" :key="starIndex">
                                    <div class="rating-check">
                                        <input class="ipt-check" type="checkbox" name="checkbox01" :id="'checkbox' + star" :checked="isSelectedStar(star)" @change="toggleStarSelection(star)">
                                        <label class="ipt-label" :for="'checkbox' + star">
                                            <span class="box"></span>
                                            <div class="rating-star">
                                                <span class="icon-star" v-for="n in parseInt(star)" :key="n"></span>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="maps-nav__ddr--more"><span class="ico-dot"></span><span class="ico-dot"></span><span class="ico-dot"></span></div>
                        </div>
                    </div>
                </div>
                <div class="maps-nav__box" v-if="hotelStore.facilities.length > 0">
                    <div class="maps-nav__box__title"><strong v-lang.FACILITIES></strong></div>
                    <div class="maps-nav__box__content">
                        <div class="maps-nav__ddr">
                            <div class="sidebar__dropdown">
                                <ul>
                                    <li class="item-dropdown" v-for="(facility, facIndex) in hotelStore.facilities" :key="facIndex" v-if="facility.value">
                                        <div class="style-check">
                                            <input class="ipt-check" type="checkbox" name="checkbox01" :id="'facility-' + facility.key" @change="toggleFacilitySelection(facility.key)" :checked="isSelectedFacility(facility.key)">
                                            <label class="ipt-label" :for="'facility-' + facility.key">
                                                <span class="box"></span>
                                                <div class="drop-text">
                                                    <span :class="'icon icon-' + setIconClassFacility(facility.key)"></span>
                                                    <span>{{facility.value}}</span>
                                                </div>
                                            </label>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="maps-nav__ddr--more"><span class="ico-dot"></span><span class="ico-dot"></span><span class="ico-dot"></span></div>
                        </div>
                    </div>
                </div>
                <div class="maps-nav__box no-overflow">
                    <div class="maps-nav__box__title"><strong v-lang.SEARCH_RESULT_FOR></strong>:</div>
                    <div class="maps-nav__box__content">
                        <AjaxTypeahead name="NameFilter"
                                       :placeholder="translateText('SEARCH_FOR_HOTEL', 'Search for hotels')"
                                       :defaultValue="hotelsOptions.hotelName"
                                       :url="'/api/find-hotels/' + packageQuery.id"
                                       @onHotelNameChange="onHotelNameChanged" />
                    </div>
                </div>
                <div class="maps-nav__box__close-btn">
                    <button class="maps-nav__close-btn close" type="button" data-dismiss="modal" aria-hidden="true"><i class="icon icon-remove"></i></button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import AjaxTypeahead from "./AjaxTypeahead.vue";
    import IonRangeSlider from './IonRangeSlider.vue'

    export default {
        components: {AjaxTypeahead, IonRangeSlider},
        props: ["packageQuery", "hotelStore", "flightStore", "hotelsOptions", "isSearchCompleted", "flightChangePrice"],
        data() {
            return {
                isOpenSidebar: false,
                isOpenSort: false,
                isActiveOverLaySidebar: false
            }
        },
        computed: {
            selectHotelText() {
                return this.translate(this.$language, 'SELECT_HOTEL') || 'Select Hotel';
            }
        },
        methods: {
            calculateTotalPrice(hotelPrice) {
                var price = 0;
                if (this.flightStore.outboundFlight) {
                    price += this.flightStore.outboundFlight.solutionPrice;
                }
                if (this.flightStore.inboundFlight) {
                    var priceChanged = this.flightStore.inboundFlight.solutionPrice - this.flightStore.outboundFlight.solutionPrice;
                    if (priceChanged != 0)
                        price += priceChanged;
                }
                return (price + hotelPrice).toFixed(this.packageQuery.currencyDecimals);
            },
            setIconClassFacility(facKey) {
                var classFac = '';
                this.hotelStore.iconClassFacilities.forEach(function (x) {
                    if (x.key === facKey) classFac = x.value;
                });
                return classFac;
            },
            isSelectedStar(star) {
                var index = this.hotelsOptions.stars.indexOf(star);
                if (index === -1)
                    return false;
                return true;
            },
            isSelectedFacility(facility) {
                var index = this.hotelsOptions.facilities.indexOf(facility);
                if (index === -1)
                    return false;
                return true;
            },
            toggleFacilitySelection(facility) {
                var idx = this.hotelsOptions.facilities.indexOf(facility);
                if (idx > -1) {
                    this.hotelsOptions.facilities.splice(idx, 1);
                } else {
                    this.hotelsOptions.facilities.push(facility);
                }
                this.$emit('changed');
            },
            setRegionId(region) {
                if (region) {
                    this.hotelsOptions.regionId = region.regionId;
                    this.hotelsOptions.latitude = region.centerLatitude;
                    this.hotelsOptions.longitude = region.centerLongitude;
                    this.hotelsOptions.regionName = region.regionName;
                } else {
                    this.hotelsOptions.regionId = null;
                    this.hotelsOptions.latitude = null;
                    this.hotelsOptions.longitude = null;
                    this.hotelsOptions.regionName = null;
                }
                this.$emit('changed');
            },
            toggleStarSelection(star) {
                this.internalToggleStarSelection(star);
                //if (star === "1") {
                //    this.internalToggleStarSelection("0");
                //}

                this.$emit('changed');
            },
            toggleFilter() {
                $("#filterPanelResult .filter-body").toggleClass('is-open');
            },
            internalToggleStarSelection(star) {
                var idx = this.hotelsOptions.stars.indexOf(star);
                if (idx > -1) {
                    this.hotelsOptions.stars.splice(idx, 1);
                    idx = this.hotelsOptions.stars.indexOf((parseFloat(star) + 0.5) + "");
                    if (idx > -1) {
                        this.hotelsOptions.stars.splice(idx, 1);
                    }
                } else {
                    this.hotelsOptions.stars.push(star);
                    this.hotelsOptions.stars.push((parseFloat(star) + 0.5) + "");
                }
            },
            onHotelNameChanged(data) {
                this.hotelsOptions.hotelName = data;
                this.$emit('changed');
            },
            clearHotelName() {
                this.hotelsOptions.hotelName = null;
                this.$refs.hotelNameFilter.clearSelection();
                this.$emit('changed');
            },
            setMinMaxPrice(min, max) {
                var minPrice = min;
                var maxPrice = max;

                //Remove flight price from values
                if (this.flightStore.outboundFlight != null) {
                    minPrice -= this.flightStore.outboundFlight.solutionPrice;
                    maxPrice -= this.flightStore.outboundFlight.solutionPrice;
                }

                this.hotelsOptions.minPrice = minPrice;
                this.hotelsOptions.maxPrice = maxPrice;
                this.$emit('changed');
            },
            setRegionDistance(min, max) {
                this.hotelsOptions.minDistance = min;
                this.hotelsOptions.maxDistance = max;
                this.hotelsOptions.radius = max;
                this.$emit('changed');
            },
            togglePane(element, isClosed) {
                this.$emit('onTogglePaneChanged', {
                    element: element,
                    isClosed: isClosed
                });
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            }
        }
    }
</script>