<template>
    <div>
        <form method="GET" action="/package/start-search" @submit="onValidate">
            <div class="search-grid flex-wrap" :class="{'to-airport': transfer.transferType === 'ToAirport'}">
                <div class="journey-type">
                    <label class="radio-inline">
                        <input type="radio" checked="checked" name="TransferSearchInfo.TransferType" value="Return" v-model="transfer.transferType" @change="onChangeJourneyType"/> <span v-lang.RETURN></span>
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="TransferSearchInfo.TransferType" value="FromAirport" v-model="transfer.transferType" @change="onChangeJourneyType"/> <span v-lang.ONE_WAY_FROM_AIRPORT></span>
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="TransferSearchInfo.TransferType" value="ToAirport" v-model="transfer.transferType" @change="onChangeJourneyType"/> <span v-lang.ONE_WAY_TO_AIRPORT></span>
                    </label>
                </div>
                <AjaxSelect name="To"
                            :placeholder="translateText('CHOOSE_A_CITY', 'Choose a city...')"
                            :txtLabel="translateText('WHAT_AIRPORT_DO_YOU_ARRIVE_AT', 'What airport do you arrive at?')"
                            :txtToAirportLabel="translateText('WHAT_AIRPORT_DO_YOU_ARRIVE_AT', 'What airport do you arrive at?')"
                            :class="{'disabled': !transfer.regionId && transfer.transferType === 'ToAirport'}"
                            :tempTransferType="tempTransferType"
                            :defaultValue="to"
                            :defaultText="transfer.transferType === 'ToAirport' && packageQuery ? packageQuery.toAirportName : toCityName"
                            :journeyType="transfer.transferType"
                            :cityCode="transfer.airportByRegionCode"
                            icon="ico icon-location-arrow"
                            :accepted="true"
                            :url="transfer.transferType === 'ToAirport' ? '/api/get-airports-of-city' : '/api/get-global-airports'"
                            @onLocationChanged="onLocationChanged"
                            :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_CITY', 'Please choose a valid city')"
                            data-selected="true" />
                <AjaxSelect name="TransferSearchInfo.RegionId"
                            :placeholder="translateText('HOTEL_NAME_LOCATION', 'Hotel name/location...')"
                            :txtLabel="translateText('WHERE_WOULD_YOU_LIKE_TO_BE_DROPPED_OFF', 'Where would you like to be dropped off?')"
                            :txtToAirportLabel="translateText('WHERE_WOULD_YOU_LIKE_TO_BE_PICKED_UP', 'Where would you like to be picked up?')"
                            :journeyType="transfer.transferType"
                            :tempTransferType="tempTransferType"
                            :class="{'disabled': !transfer.airportCode && transfer.transferType !== 'ToAirport'}"
                            type="Transfer"
                            :to="transfer.airportCode"
                            :defaultValue="packageQuery ? packageQuery.transferSearchInfo.regionId : ''"
                            :defaultLocation="hotelTransfer ? hotelTransfer.latitude + ',' + hotelTransfer.longitude : ''"
                            :defaultText="hotelTransfer ? hotelTransfer.name : ''"
                            icon="ico icon-map-marker"
                            :typeRegions="typeRegions"
                            :url="'/api/search-regions'"
                            @onCityChanged="obj => onCityChanged(obj.code, obj.airportCode)"
                            :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_DESTINATION', 'Please choose a valid destination')"
                            data-selected="true" />
                <DateRangePicker v-model="defaultDate" date-format="DD/MM/YYYY" :journeyType="transfer.transferType"  data-selected="true" isFlight="true" type="Transfer" :addedDates="addedDates" />
                <PaxSelector :maxRooms="3"  data-selected="true" isTransferOnly="true" isTourOnly="true" />
            </div>
            <div class="search-button-wrap">
                <input type="hidden" name="OrderId" :value="packageQuery && packageQuery.orderId ? packageQuery.orderId : ' '">
                <input type="hidden" name="Currency" :value="currency || defaultCurrency">
                <input type="hidden" name="ProductId" :value="product.id" />
                <button id="btnSumitSearchFormTransfer" type="submit" class="bt-search bt-effect">
                    <span class="text-uppercase" v-lang.SEARCH_TRANSFER></span>
                </button>
            </div>
        </form>
    </div>
</template>

<script>
    import { mapState } from 'vuex'
    import AjaxSelect from './AjaxSelect.vue'
    import DateRangePicker from './DateRangePicker.vue'
    import PaxSelector from "./PaxSelector.vue"
    export default {
        data() {
            return {
                maxRooms: 1,
                paxCount: 0,
                transfer: {
                    transferType: "Return",
                    airportCode: "",
                    regionId: "",
                    airportByRegionCode: ""
                },
                typeRegions: 'Hotel',
                promoCode: null,
                tempTransferType: "",
                currency: "",
                defaultCurrency: "USD"
            }
        },
        computed: mapState({
            package: state => state.workContext
        }),
        mounted() {
            let self = this;
            if (self.packageQuery) {
                self.transfer.transferType = self.packageQuery.transferSearchInfo.transferType;
                self.tempTransferType = self.packageQuery.transferSearchInfo.transferType;
                self.transfer.airportCode = self.packageQuery.to;
                self.transfer.regionId = self.packageQuery.to;
                self.currency = self.packageQuery.currency;
            }
        },
        methods: {
            onChangeJourneyType() {
                this.tempTransferType = this.transfer.transferType;
            },
            onLocationChanged(code) {
                this.transfer.airportCode = code;
            },
            onCityChanged(code, airportCode) {
                this.transfer.airportByRegionCode = airportCode;
                this.transfer.regionId = code;
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            validateInput(context) {
                var parent = context.parents('.box-search');
                var label = parent.find(">strong");
                var labelVals = {
                    old: context.attr('data-label'),
                    new: context.attr('data-required-message')
                };

                if (!context.val()) {
                    parent.addClass('error');
                    label.text(labelVals.new);
                    return false;
                } else {
                    parent.removeClass('error');
                    label.text(labelVals.old);
                }
                return true;
            },
            onValidate(e) {
                var self = this;
                var box = $(self.$el)
                var errors = 0;
                box.find("input[type='hidden']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                if (errors == 0) {
                    return true;
                }
                if (e) e.preventDefault();
            }
        },
        props: ['packageQuery', 'product', 'hotelTransfer', 'defaultDate', 'to', 'toCityName', 'addedDates'],
        components: {PaxSelector, DateRangePicker, AjaxSelect}
    }

</script>