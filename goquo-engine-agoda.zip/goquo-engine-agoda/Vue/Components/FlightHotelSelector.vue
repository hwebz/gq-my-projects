﻿<template>
    <div>
        <div class="fh-tabs__wrap fh-tabs-sticky" id="fh-tabs-scroll">
            <div class="container">
                <div class="fh-tabs__overview nav nav-tabs">
                    <a class="fh-tabs__item fh-tabs__hotel" :class="{'active': !hotelInfo}" href="#tabs-hotel" :data-toggle="!hotelInfo ? 'tab' : ''" data-sync="true" role="tab" data-product="hotel"
                       v-if="hotelSelected" @click="syncTabs">
                        <div class="picture" :class="{'no-image': hotelSelected.imageInfos.length == 0}" :title="hotelSelected.name" :style="{backgroundImage: `url('${hotelSelected.imageInfos.length > 0 ? replaceImage(hotelSelected.imageInfos[0].url) : baseUrl + '/images/images-default.jpg'}')`}">
                        </div>
                        <div class="detail">
                            <div class="title">
                                <strong>
                                    <span v-lang.HOTEL></span>
                                    <StarRating :rating="hotelSelected.stars"></StarRating>
                                </strong>
                                <a class="bt-change" :href="packageQuery.requestUrl" v-if="allowChange" v-lang.CHANGE></a>
                            </div>
                            <h2 class="name">{{hotelSelected.name}}</h2>
                            <ul class="list-detail">
                                <li>
                                    <span><i class="icon-location-arrow"></i>{{hotelSelected.addressLines}}</span>
                                    <a href="#full-hotel-info-map" @click.prevent="scrollToElement" v-if="hotelInfo">
                                        <i class="ico icon-map-marker"></i><span v-lang.VIEW></span>
                                    </a>
                                    <a href="#modalMapBox" data-toggle="modal" @click="openMapView" v-else>
                                        <i class="ico icon-map-marker"></i><span v-lang.VIEW></span>
                                    </a>
                                </li>
                                <li v-if="hotelSelected.trustyou && isSearchCompleted && !hasErrorMessage">
                                    <span :class="'reviews-score reviews-score__' + hotelSelected.trustyou.score_description.toLowerCase().replace(/ +/g, '-')">
                                        <span class="reviews-score__score">{{hotelSelected.trustyou.score_display}}</span> |
                                        <span class="reviews-score__description">{{hotelSelected.trustyou.score_description}}</span>
                                    </span>
                                    <span>
                                        <span class="reviews-score__reviews" v-if="hotelSelected.trustyou.reviews_count > 0">{{hotelSelected.trustyou.reviews_count}} {{hotelSelected.trustyou.reviews_count > 1 ? translateText('REVIEWS', 'reviews') : translateText('REVIEW', 'review')}}</span>
                                    </span>
                                </li>
                            </ul>
                            <ul class="list-ruler-check">
                                <li class="cancellation" v-if="isHotelCancellation(hotelSelected) === 'free'">
                                    <i class="icon-check"></i>
                                    <span v-lang.FREE_CANCELLATION_AVAILABLE></span>
                                </li>
                                <li class="cancellation" v-if="isHotelCancellation(hotelSelected) === 'apart'">
                                    <i class="icon-check"></i>
                                    <span v-lang.REFUNDABLE></span>
                                </li>
                                <li class="non-refund" v-if="isHotelCancellation(hotelSelected) === 'non'">
                                    <i class="icon-remove"></i>
                                    <span v-lang.NONREFUNDABLE></span>
                                </li>
                            </ul>
                            <a class="bt-link" href="#full-hotel-info" @click.prevent="scrollToElement" v-if="hotelInfo">
                                <i class="icon-down-chevron"></i><span v-lang.INFO></span>
                            </a>
                            <a class="bt-link" href="#modalHotelDetail" data-toggle="modal" @click.prevent="onHotelDetailShown($event, hotelSelected)" v-else>
                                <i class="icon-down-chevron"></i><span v-lang.INFO></span>
                            </a>
                        </div>
                    </a>
                    <a class="fh-tabs__item fh-tabs__flight" href="#tabs-flight" :data-toggle="!hotelInfo ? 'tab' : ''" data-sync="true" role="tab" data-product="flight"
                       v-show="loading.flightDetails" @click="syncTabs">
                        <div v-if="enabledFlights">
                            <div class="title">
                                <strong v-lang.FLIGHT></strong>
                                <a class="bt-change" :href="packageQuery.requestUrl" v-if="allowChange" v-lang.CHANGE></a>
                            </div>
                            <div class="flight-way__tabs" v-if="flightStore.outboundFlight != null">
                                <div class="flight-way__view">
                                    <div class="line-way">
                                        <div class="line-brand">
                                            <div class="line-brand__avartar multi-flights">
                                                <img :src="'https://gqcdn.s3.amazonaws.com/airline-logos/svg/' + flightStore.outboundFlight.legs[0].airlineCode + '.svg'" :alt="flightStore.outboundFlight.legs[0].airlineCode" />
                                                <img v-for="(leg, legIndex) in flightStore.outboundFlight.legs" :src="'https://gqcdn.s3.amazonaws.com/airline-logos/svg/' + leg.airlineCode + '.svg'" :alt="leg.airlineCode" v-if="legIndex > 0 && leg.airlineCode !== flightStore.outboundFlight.legs[0].airlineCode" />
                                            </div>
                                        </div>
                                        <div class="line-time">
                                            <div class="line-time__time">
                                                <strong>{{flightStore.outboundFlight.departureDate | moment("HH:mm")}}</strong>
                                                <span>{{flightStore.outboundFlight.departureAirportCode}}</span>
                                            </div>
                                            <div class="line-time__direction">
                                                <small>{{getDurationTime(flightStore.outboundFlight)}}</small>
                                                <div class="ico-flight flight-depart">
                                                    <i class="icon-flight"></i>
                                                </div>
                                                <small v-if="flightStore.outboundFlight.stops == 0" v-lang.NONSTOP_LOWER></small>
                                                <small v-if="flightStore.outboundFlight.stops == 1" v-lang.ONE_STOP_LOWER></small>
                                                <small v-if="flightStore.outboundFlight.stops > 1" v-lang.ONE_PLUS_STOP_LOWER></small>
                                                <small v-if="flightStore.outboundFlight.stops >= 1">
                                                    (<span v-lang.VIA></span> <template v-for="(leg, legIdx) in flightStore.outboundFlight.legs" v-if="legIdx < flightStore.outboundFlight.legs.length - 1">{{leg.arrivalAirportCode}}{{legIdx < flightStore.outboundFlight.legs.length - 2 ? ', ' : ''}}</template>)
                                                </small>
                                            </div>
                                            <div class="line-time__time">
                                                <strong>{{flightStore.outboundFlight.arrivalDate | moment("HH:mm")}}<sup v-if="isNextDay(flightStore.outboundFlight) > 0">+{{isNextDay(flightStore.outboundFlight)}}</sup></strong>
                                                <span>{{flightStore.outboundFlight.arrivalAirportCode }}</span>
                                            </div>
                                        </div>
                                        <div class="line-control">
                                            <a class="btn btn-sm btn-link" href="#modalFlightDetail" data-toggle="modal" @click.prevent="onFlightDetailShown($event, flightStore.outboundFlight)">
                                                <span v-lang.DETAIL></span>
                                                <i class="icon-information"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="flight-way__tabs" v-if="flightStore.inboundFlight != null">
                                <div class="flight-way__view">
                                    <div class="line-way">
                                        <div class="line-brand">
                                            <div class="line-brand__avartar multi-flights">
                                                <img :src="'https://gqcdn.s3.amazonaws.com/airline-logos/svg/' + flightStore.inboundFlight.legs[0].airlineCode + '.svg'" :alt="flightStore.inboundFlight.legs[0].airlineCode" />
                                                <img v-for="(leg, legIndex) in flightStore.inboundFlight.legs" :src="'https://gqcdn.s3.amazonaws.com/airline-logos/svg/' + leg.airlineCode + '.svg'" :alt="leg.airlineCode" v-if="legIndex > 0 && leg.airlineCode !== flightStore.inboundFlight.legs[0].airlineCode" />
                                            </div>
                                        </div>
                                        <div class="line-time">
                                            <div class="line-time__time">
                                                <strong>{{flightStore.inboundFlight.legs[0].departureDate | moment("HH:mm")}}</strong>
                                                <span>{{flightStore.inboundFlight.legs[0].departureAirportCode}}</span>
                                            </div>
                                            <div class="line-time__direction">
                                                <small>{{getDurationTime(flightStore.inboundFlight)}}</small>
                                                <div class="ico-flight flight-depart">
                                                    <i class="icon-flight"></i>
                                                </div>
                                                <small v-if="flightStore.inboundFlight.stops == 0" v-lang.NONSTOP_LOWER></small>
                                                <small v-if="flightStore.inboundFlight.stops == 1" v-lang.ONE_STOP_LOWER></small>
                                                <small v-if="flightStore.inboundFlight.stops > 1" v-lang.ONE_PLUS_STOP_LOWER></small>
                                                <small v-if="flightStore.inboundFlight.stops >= 1">
                                                    (<span v-lang.VIA></span> <template v-for="(leg, legIdx) in flightStore.inboundFlight.legs" v-if="legIdx < flightStore.inboundFlight.legs.length - 1">{{leg.arrivalAirportCode}}{{legIdx < flightStore.inboundFlight.legs.length - 2 ? ', ' : ''}}</template>)
                                                </small>
                                            </div>
                                            <div class="line-time__time">
                                                <strong>{{flightStore.inboundFlight.legs[flightStore.inboundFlight.stops].arrivalDate | moment("HH:mm")}}<sup v-if="isNextDay(flightStore.inboundFlight) > 0">+{{isNextDay(flightStore.inboundFlight)}}</sup></strong>
                                                <span>{{flightStore.inboundFlight.legs[flightStore.inboundFlight.stops].arrivalAirportCode }}</span>
                                            </div>
                                        </div>
                                        <div class="line-control">
                                            <a class="btn btn-sm btn-link" href="#modalFlightDetail" data-toggle="modal" @click.prevent="onFlightDetailShown($event, flightStore.inboundFlight)">
                                                <span v-lang.DETAIL></span>
                                                <i class="icon-information"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    <div class="fh-tabs__item fh-tabs__flight" v-if="!loading.flightDetails && enabledFlights">
                        <div class="title">
                            <strong v-lang.FLIGHT></strong>
                            <a class="bt-change" href="#" v-lang.CHANGE></a>
                        </div>
                        <div class="flight-way__tabs">
                            <div class="flight-way__view">
                                <div class="lda__wrap">
                                    <div class="lda">
                                        <div class="lda__bar"></div>
                                        <div class="lda__bar lda__bar--split lda__bar--50"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="flight-way__tabs">
                            <div class="flight-way__view">
                                <div class="lda__wrap">
                                    <div class="lda">
                                        <div class="lda__bar"></div>
                                        <div class="lda__bar lda__bar--split lda__bar--50"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="fh-tabs__item fh-tabs__control" v-if="hotelSelected">
                        <div class="loading-price" :class="{'loading-price--active': !(!isSearchCompleted && !hasErrorMessage) && isCanShowHotelPrice(hotelSelected)}">
                            <div class="load load__bar load__bar--active">
                                <div class="line"></div>
                                <div class="line"></div>
                                <div class="line"></div>
                            </div>
                            <span class="loading-price--first" v-lang.LOADING_PRICE></span>
                            <span class="loading-price--second" v-lang.CALCULATING_PRICE></span>
                            <span class="loading-price--third" v-lang.HOLD_ON_A_BIT></span>
                        </div>
                        <div class="title-adults">
                            <i class="icon-user"></i>
                            <span>{{calculatePaxCount}} {{calculatePaxCount == 1 ? translateText('PASSENGER', 'Passenger') : translateText('PASSENGERS', 'Passengers')}}</span>
                        </div>
                        <div class="title-class text-uppercase" v-if="enabledFlights" v-lang.FLIGHT_HOTEL></div>
                        <div class="title-class text-uppercase" v-else v-lang.HOTEL></div>
                        <div class="title-perperson" v-if="enabledFlights" v-lang.TOTAL_PACKAGE_PRICE></div>
                        <div class="title-perperson" v-else v-lang.TOTAL_HOTEL_PRICE></div>
                        <div class="price">
                            <span>{{packageQuery.currency}}</span>
                            <strong>{{getDisplayPrice(hotelSelected)}}</strong>
                        </div>
                        <a class="link-small" href="#modalPriceBreakdown" data-toggle="modal" @click="showPriceSummaryPaneHotel" v-lang.PRICE_BREAKDOWN></a>
                        <a class="btn btn-block btn-primary bt-effect bt-selected" href="javascript:void(0)" v-if="!hotelInfo" @click="gotoHotelInfoPage(hotelSelected.url)" v-lang.BOOK></a>
                        <a class="btn btn-block btn-primary bt-effect bt-selected" href="javascript:void(0)" v-else @click="onBookingNow" v-lang.BOOK></a>
                    </div>
                </div>

            </div>
        </div>
        <div class="modal fade" id="modalFlightDetail" tabindex="-1" role="dialog" aria-hidden="true" v-if="loading.flightDetails && selectedFlight">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body modal-body-gray npd">
                        <div class="flight-detail-title">
                            <strong v-lang.ITINERARY></strong>
                            <button class="modal-close" data-dismiss="modal">
                                <i class="icon-remove"></i>
                            </button>
                        </div>
                        <div class="flight-detail-main">
                            <div class="time-duration">
                                <div class="time">
                                    <strong v-lang.DEPARTURE></strong>:
                                    <span>{{selectedFlight.departureDate | moment("dddd, DD MMMM")}}</span>
                                </div>
                                <div class="duration" v-if="parseInt(getDurationTime(selectedFlight)) > 0">
                                    <strong v-lang.DURATION></strong>:
                                    <span>{{getDurationTime(selectedFlight)}}</span>
                                </div>
                            </div>
                            <div class="list-detail" v-for="(leg, legIndex) in selectedFlight.legs" :key="legIndex">
                                <div class="list-block">
                                    <div class="title">
                                        <span v-lang.DEPARTURE></span>:
                                    </div>
                                    <ul class="detail">
                                        <li>
                                            <b>{{leg.departureDate | moment('HH:mm')}}</b>
                                            <span>{{leg.departureDate | moment('dddd, DD MMM')}}</span>
                                            <span class="highlight-sv" v-if="leg.stationType == 1" v-lang.BUS_SERVICE>Bus Service</span>
                                            <span class="highlight-sv" v-if="leg.stationType == 2" v-lang.TRAIN_SERVICE>Train Service</span>
                                            <span class="highlight-sv" v-if="leg.stationType == 3" v-lang.FERRY_SERVICE>Ferry Service</span>
                                        </li>
                                        <li>
                                            <b v-if="!leg.stationType || leg.stationType == 0">{{leg.departureAirportName}}</b>
                                            <b v-else-if="leg.stationType == 1">{{leg.departureCityName}} {{leg.airlineCode}} <strong v-lang.BUS_STATION>Bus Station</strong></b>
                                            <b v-else-if="leg.stationType == 2">{{leg.departureCityName}} {{leg.airlineCode}} <strong v-lang.TRAIN_STATION>Train Station</strong></b>
                                            <b v-else>{{leg.departureCityName}} {{leg.airlineCode}} Ferry Port</b>
                                            <span>({{leg.departureAirportCode}}) {{leg.departureCityName}}</span>
                                        </li>
                                    </ul>
                                </div>
                                <div class="list-block">
                                    <div class="title">
                                        <span v-lang.ARRIVAL></span>:
                                    </div>
                                    <ul class="detail">
                                        <li>
                                            <b>{{leg.arrivalDate | moment('HH:mm')}}</b>
                                            <span>{{leg.arrivalDate | moment('dddd, DD MMM')}}</span>
                                        </li>
                                        <li>
                                            <b>{{leg.arrivalAirportName}}</b>
                                            <span>({{leg.arrivalAirportCode}}) {{leg.arrivalCityName}}</span>
                                        </li>
                                    </ul>
                                </div>
                                <div class="name-brand">
                                    <div class="title"></div>
                                    <div class="detail">
                                        <div class="avartar">
                                            <img :src="'https://gqcdn.s3.amazonaws.com/airline-logos/svg/' + leg.airlineCode + '.svg'" :alt="leg.airlineCode" />
                                        </div>
                                        <b>
                                            {{leg.airlineName}}
                                            <span>{{leg.stationType == 1 ? 'BUS' : ''}} {{leg.airlineCode}}{{leg.flightNumber}}</span>
                                            <span v-if="leg.airType">Aircraft - {{leg.airType}}</span>
                                        </b>
                                        <span v-if="leg.bookingClass">{{translateText(leg.cabinClass.toUpperCase(), leg.cabinClass)}} ({{leg.bookingClass}})</span>
                                        <span v-else><span v-lang.CLASS></span> - {{translateText(leg.cabinClass.toUpperCase(), leg.cabinClass)}}</span>
                                        <div v-if="!leg.stationType || leg.stationType == 0" class="service-name"></div>
                                        <div v-else-if="leg.stationType == 1" class="service-name">Note: This is Bus Service</div>
                                        <div v-else-if="leg.stationType == 2" class="service-name">Note: This is Train Station</div>
                                        <div v-else class="service-name">Note: This is Ferry Port</div>
                                    </div>
                                </div>
                                <div class="list-block">
                                    <div class="title" v-lang.BAG_FEES>Bag fees:</div>
                                    <div class="detail">
                                        <p v-if="selectedFlight.baggageFeeLink" v-lang.BAGGAGE_FEES_MESSAGE1="{0: selectedFlight.baggageFeeLink, 1 : leg.airlineName}"></p>
                                        <p v-else v-lang.BAGGAGE_FEES_MESSAGE2="{0: leg.airlineName, 1: leg.airlineName}"></p>
                                    </div>
                                </div>
                                <div class="duration-check" v-if="selectedFlight.stops > 0 && legIndex < selectedFlight.legs.length - 1">
                                    <div class="title"></div>
                                    <div class="detail">
                                        <i>
                                            <span v-lang.TRANSIT_DURATION></span>: {{getTransitTime(selectedFlight.legs[legIndex].arrivalDate, selectedFlight.legs[legIndex + 1].departureDate)}} in {{leg.arrivalCityName}}
                                        </i>
                                        <strong v-lang.CHECK_BOARDING_TIME></strong>
                                        <span>
                                            {{selectedFlight.legs[legIndex].arrivalDate | moment('HH:mm')}} {{selectedFlight.legs[legIndex].arrivalDate | moment('dddd, DD MMM')}} -
                                            {{selectedFlight.legs[legIndex + 1].departureDate | moment('HH:mm')}} {{selectedFlight.legs[legIndex + 1].departureDate | moment('dddd, DD MMM')}}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-primary bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade big" id="modalHotelDetail" tabindex="-1" role="dialog" aria-hidden="true" v-if="hotelSelected && !hotelInfo">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body modal-body-gray npd">
                        <div class="flight-detail-title">
                            <strong>{{hotelSelected.name}}</strong>
                            <button class="modal-close" data-dismiss="modal">
                                <i class="icon-remove"></i>
                            </button>
                        </div>
                        <div class="fh-tabs__item fh-tabs__detail">
                            <div class="tabs-cls-detail">
                                <div class="tabs-cls-header nav nav-tabs">
                                    <a class="item-tabs-cls nav-item nav-link active" data-toggle="tab" role="tab" href="#tab-item-selected-gallery" v-lang.PHOTO></a>
                                    <a class="item-tabs-cls nav-item nav-link" data-toggle="tab" data-analyst="map-popup" role="tab" href="#tab-item-selected-map" v-lang.MAPS></a>
                                    <a class="item-tabs-cls nav-item nav-link" data-toggle="tab" role="tab" href="#tab-item-selected-services" v-if="hotelSelected.facilities.length > 0" v-lang.SERVICE></a>
                                    <a class="item-tabs-cls nav-item nav-link" data-toggle="tab" role="tab" href="#tab-item-selected-reviews" v-if="hotelSelected.trustyou" v-lang.REVIEWS></a>
                                    <a class="item-tabs-cls nav-item nav-link" data-toggle="tab" role="tab" href="#tab-item-selected-description" v-lang.DESCRIPTION></a>
                                </div>
                                <div class="tabs-cls-main tab-content">
                                    <div role="tabpanel" id="tab-item-selected-gallery" class="tabs-cls-content tabs-gallery tab-pane show active" v-if="hotelSelected.imageInfos.length > 0">
                                        <div class="gallery__wrap">
                                            <div class="gallery__image">
                                                <div class="gallery__image-show" id="tab-item-selected-gallery-big-item" :style="'background-image:url('+ hotelSelected.imageInfos[0].url +')'">
                                                </div>
                                                <div class="go-left go-control" data-index="0" data-control="prev" @click="changeGalleryImage($event, '#tab-item-selected-gallery-big-item', hotelSelected.imageInfos)">
                                                    <i class="icon-left-chevron" style="pointer-events: none"></i>
                                                </div>
                                                <div class="go-right go-control" data-index="0" data-control="next" @click="changeGalleryImage($event, '#tab-item-selected-gallery-big-item', hotelSelected.imageInfos)">
                                                    <i class="icon-right-chevron" style="pointer-events: none"></i>
                                                </div>
                                            </div>
                                            <div class="gallery__thumbs">
                                                <div class="gallery__thumbs-item">
                                                    <a class="thumb-item" href="javascript:void(0);" :data-image-index="i" :class="{'active': i === 0 }" v-for="(img, i) in hotelSelected.imageInfos"
                                                       :style="'background-image:url('+ img.thumbnailUrl +')'" :key="i" @click="changeGalleryImage($event, '#tab-item-selected-gallery-big-item', img)"></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="tabpanel" id="tab-item-selected-map" class="tabs-cls-content tabs-maps tab-pane">
                                        <div id="#tab-item-selected-map-item" class="tabs-maps-detail maps-area"></div>
                                    </div>
                                    <div role="tabpanel" id="tab-item-selected-services" class="tabs-cls-content tabs-services tab-pane scroll-hoz" v-if="hotelSelected.facilities.length > 0">
                                        <div class="list-service">
                                            <div class="block-service">
                                                <div class="title">
                                                    <strong v-lang.FACILITIES></strong>
                                                </div>
                                                <div class="detail">
                                                    <ul>
                                                        <li v-for="(facility, idx) in hotelSelected.facilities" :key="idx" v-if="facility.code">
                                                            <!--<i :class="'icon icon-' + facility.code"></i>-->
                                                            {{facility.description ? facility.description : facility.name}}
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="tabpanel" id="tab-item-selected-reviews" class="tabs-cls-content tabs-services tab-pane scroll-hoz reviews-box" v-if="hotelSelected.trustyou">
                                        <TrustYou :trustyou="hotelSelected.trustyou" />
                                    </div>
                                    <div role="tabpanel" id="tab-item-selected-description" class="tabs-cls-content tabs-services tab-pane scroll-hoz">
                                        <div class="tabs-texts" v-html="hotelSelected.description"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-primary bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import Vue from 'vue';
    import {mapState} from 'vuex'
    import StarRating from './StarRating.vue'
    import TrustYou from './TrustYou.vue'

    import _ from 'lodash';
    export default {
        components: {
            StarRating,
            TrustYou
        },
        props: ["packageQuery", "isSearchCompleted", "hasErrorMessage", "loading", "flightStore", "hotelStore",
            "showFlightAggreations", "enabledFlights", "product", "totalPrice", "hotelInfo", "hotelSelected",
            "priceSummary", "allowChange"
        ],
        data() {
            return {
                flightInfoPopup: {},
                selectedFlight: null,
                infowindow: new google.maps.InfoWindow(),
                totalPassenger: 0,
                searchConditions: {
                    adultCount: 0,
                    childCount: 0,
                    infantCount: 0
                }
            };
        },
        created() {
            this.searchConditions = {
                adultCount: this.adultCount,
                childCount: this.childCount,
                infantCount: this.infantCount
            }
            this.totalPassenger = this.calculatePaxCount;
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            baseUrl: state => state.workContext.baseUrl,
            outboundFlights() {
                return this.flightStore.flights.filter(function (flight) {
                    return flight.direction === 0
                });
            },
            inboundFlights() {
                if (!this.outboundFlight) {
                    return [];
                }

                var self = this;
                var departureRoute = this.outboundFlight.departureAirportCode + this.outboundFlight.arrivalAirportCode;

                return this.flightStore.flights.filter(function (flight) {
                    if (flight.direction !== 1) {
                        return false;
                    }

                    var returnRoute = flight.arrivalAirportCode + flight.departureAirportCode;
                    return departureRoute === returnRoute;
                });
            },
            calculatePaxCount() {
                return this.searchConditions.adultCount + this.searchConditions.childCount + this.searchConditions.infantCount;
            },
            adultCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                }
                return count;
            },
            childCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.childCount;
                }
                return count;
            },
            infantCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.infantCount;
                }
                return count;
            }
        }),
        mounted() {
            this.scrollTabsSelected();
        },
        updated() {
            var self = this;
            $("a[data-analyst='map-popup']").unbind('show.bs.tab').on('show.bs.tab', function (e) {
                var target = $(e.target.hash);
                var targetMap = typeof target !== 'undefined' ? target.find('> div') : null;
                if (targetMap) {
                    var hotel = self.hotelSelected;

                    var myLatLng = { lat: parseFloat(hotel.latitude), lng: parseFloat(hotel.longitude) };

                    var map = new google.maps.Map(targetMap[0], {
                        center: myLatLng,
                        zoom: 18
                    });
                    // Create a marker and set its position.
                    var marker = new google.maps.Marker({
                        map: map,
                        position: myLatLng,
                        title: hotel.name
                    });

                    var infoWindowHTML = `<div class="infowindow__wrap">
                                        <div class="infowindow__img" style="background-image:url(${hotel.imageInfos.length > 0 ? hotel.imageInfos[0].url : self.baseUrl + '/images/images-default.jpg'});"></div>
                                        <div class="infowindow__detail">
                                            <h5 class="infowindow__title">${hotel.name}</h5>
                                            <div class="infowindow__star">
                                                ${Array(parseInt(hotel.stars)).join(0).split(0).map((item, i) => `
                                                    <span class="icon-star"></span>
                                                `).join('')}
                                            </div>
                                            <span><i class="ico icon-location-arrow"></i> ${hotel.addressLines}</span>
                                            ${typeof hotel.trustyou !== 'undefined' ? `
                                                <div class="infowindow__score">
                                                    <div class="reviews-score reviews-score__${hotel.trustyou.score_description.toLowerCase().replace(/ +/g, '-')}">${hotel.trustyou.score_display}</div>
                                                    <div class="text">
                                                        <span>${hotel.trustyou.score_description}</span>
                                                        <small>${hotel.trustyou.reviews_count} ${parseInt(hotel.trustyou.reviews_count) > 1 ? `reviews` : 'review'}</small>
                                                     </div>
                                                </div>
                                            ` : ``}
                                        </div>
                                     </div>`;

                    setTimeout(function() {
                        self.infowindow.setContent(infoWindowHTML);
                        self.infowindow.open(map, marker);
                    }, 500);
                }
            });
        },
        methods: {
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            isCanShowHotelPrice(hotel) {
                if (this.enabledFlights && !this.flightStore.outboundFlight) {
                    return false;
                }

                return hotel.cheapestPrice > 0;
            },
            scrollToElement(e) {
                let self = $(e.target).parent();
                let target = $(self.attr('href'));
                let stickyPanel = $(".fh-tabs-sticky");
                
                if (target && target.length > 0) {
                    $('html,body').animate({
                        scrollTop: target.offset() ? target.offset().top - (stickyPanel && stickyPanel.length > 0 && $(window).width() >= 1200 ? stickyPanel.height() : 0) : 0
                    }, 'slow');
                }
            },
            selectedRoomPrice() {
                let price = 0;
                if (this.hotelInfo) {
                    price = self.getRoomPriceByHotel(self.hotelInfo);
                }
                return price;
            },
            getHotelPrice() {
                let self = this;
                // hotelSelected ? hotelSelected.cheapestPrice : selectedRoomPrice
                if (self.hotelSelected) {
                    return self.getRoomPriceByHotel(self.hotelSelected);
                } else {
                    return self.selectedRoomPrice();
                }
            },
            getRoomPriceByHotel(hotel) {
                var hotelRooms = hotel.availableRooms;
                var price = 0;

                for (var i = 0; i < hotelRooms.length; i++) {
                    for (var j = 0; j < hotelRooms[i].availableRoomTypes.length; j++) {
                        var selectedHotel = hotelRooms[i].availableRoomTypes[j];

                        if (selectedHotel.selected) {
                            price += selectedHotel.totalPrice;
                        }
                    }
                }
                return price;
            },
            isNextDay(flight) {
                let dateDiff = 0;
                let departDate = Vue.moment(flight.departureDate.split('T')[0]);
                let returnDate = Vue.moment(flight.arrivalDate.split('T')[0]);
                
                dateDiff = returnDate.diff(departDate, 'days');
                return dateDiff;
            },
            syncTabs(e) {
                var $this = $(e.target);
                var href = $this.attr('href');
                href = href ? href : $this.parents(".fh-tabs__item").attr('href');
                href = $('.nav-tabs .item-tabs-header[href="' + href + '"]');
                if (typeof href !== 'undefined' && href.length > 0) {
                    href.tab('show');
                }
            },
            isHotelCancellation(hotel) {
                let isCancellation = 'non'; 
                if (hotel && hotel.availableRooms.length > 0) { 
                    let availableRoomType = hotel.availableRooms[0].availableRoomTypes[0];
                    if (!availableRoomType) return isCancellation;
                    if ( availableRoomType.freeCancellation && availableRoomType.freeCancellation !== 'undefined') isCancellation = 'free'; 
                    for (let i = 0; i < hotel.availableRooms.length; i++) {
                        for (let j = 0; j < hotel.availableRooms[i].availableRoomTypes.length; j++) {
                            if (hotel.availableRooms[i].availableRoomTypes[j].cancelFreeBeforeDate) return 'free';
                        }
                    }
                    
                    let cancelCharges = availableRoomType.roomCancelCharges != undefined && availableRoomType.roomCancelCharges ? availableRoomType.roomCancelCharges : [];
                    for (let i = 0; i < cancelCharges.length; i++) {
                        if (cancelCharges[i].amount > 0) {
                            isCancellation = 'apart';
                        }
                    }                                    
                }
                return isCancellation;
            },
            showPriceSummaryPaneHotel() {
                let self = this;
                let hotelPrice = 0;
                hotelPrice = self.getHotelPrice();
                this.$emit('onShowPriceSummaryPaneHotel', hotelPrice);
            },
            replaceImage(path) {
                var replacedPath;
                if (path.indexOf('static.goquo.com') > -1) {
                    var imagePath = path.split("/");
                    replacedPath = path.replace(imagePath[3], imagePath[3] + '-w300');
                } else {
                    replacedPath = path;
                }

                // Force https
                if (replacedPath.indexOf('http://') == 0) {
                    return "https://" + replacedPath.substr(7);
                }
                return replacedPath;
            },
            getTransitTime(arrivalDate, departureDate) {
                if (arrivalDate && departureDate) {
                    var arrival = Vue.moment(arrivalDate);
                    var departure = Vue.moment(departureDate);
                    var duration = departure.diff(arrival) / 60000; // convert to minute based

                    var hours = Math.floor(duration / 60);
                    var minutes = duration - (hours * 60);

                    return hours + 'h ' + minutes + 'm';
                }
                return '-';
            },
            getDurationTime(flight) {
                if (!flight) {
                    return " ";
                }
                if (flight.legs) {
                    var duration = 0;
                    for (var i = 0; i < flight.legs.length; i++) {
                        duration += flight.legs[i].duration;
                    }
                } else {
                    duration = flight.duration;
                }

                var hours = 0;
                var minutes = 0;

                if (duration > 0) {
                    hours = Math.floor(duration / 60);
                    minutes = duration - (hours * 60);
                    return hours != 0 ? hours + 'h ' : '' + minutes != 0 ? minutes + 'm' : '';
                }
                else {
                    // var departureDate = moment(new Date(flight.departureDate));
                    // var arrivalDate = moment(new Date(flight.arrivalDate));
                    //
                    // var flightTime = moment.duration(arrivalDate.diff(departureDate));
                    // hours = flightTime.hours();
                    // minutes = flightTime.minutes();
                    return ' ';
                }
            },
            getDisplayPrice(hotel) {
                var packagePrice = this.totalPackagePriceValue(hotel);

                if (packagePrice === 0) {
                    return "...";
                }

                var displayPrice = this.product.displayPrice;
                
                //price per night
                if (displayPrice === 0) {
                    return this.averagePricePerNight(packagePrice);
                }
                //price per person
                if (displayPrice === 1) {
                    return this.averagePricePerPerson(packagePrice);
                }
                //Price per room
                if (displayPrice === 2) {
                    return this.averagePricePerRoom(packagePrice);
                }
                return "";
            },
            averagePricePerPerson(totalPackagePrice) {
                var paxCount = this.calculatePaxCount;
                var price = totalPackagePrice;
                return (price.toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            averagePricePerNight(totalPackagePrice) {
                var nightCount = this.calculateNights();
                totalPackagePrice = totalPackagePrice;
                return (totalPackagePrice.toFixed(this.packageQuery.currencyDecimals) + "").replace(
                    /\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            calculateNights() {
                var oneDay = 24 * 60 * 60 * 1000;
                var returnDate = Date.parse(this.packageQuery.returnDate);
                var departureDate = Date.parse(this.packageQuery.departureDate);
                var nights = Math.round(Math.abs((returnDate - departureDate) / (oneDay)));
                return nights;
            },
            totalPackagePriceValue(hotel) {
                var price = 0;

                if (hotel) {
                    if (hotel.cheapestPrice === 0) return 0;

                    if (this.enabledFlights && !this.flightStore.outboundFlight) {
                        return 0;
                    }

                    if (!hotel.availableRooms) {
                        return 0;
                    }
                    for (var j = 0; j < hotel.availableRooms.length; j++) {
                        for (var k = 0; k < hotel.availableRooms[j].availableRoomTypes.length; k++) {
                            var availableRoomType = hotel.availableRooms[j].availableRoomTypes[k];
                            if (availableRoomType.selected) {
                                price += availableRoomType.totalPrice;
                                break;
                            }
                        }
                    }
                    price += this.totalFlightPrice();
                }

                return price;
            },
            totalFlightPrice() {
                var price = 0;
                if (this.flightStore.outboundFlight)
                    price += this.flightStore.outboundFlight.solutionPrice;
                if (this.flightStore.inboundFlight) {
                    var priceChanged = this.flightStore.inboundFlight.solutionPrice - this.flightStore.outboundFlight.solutionPrice;
                    if (priceChanged != 0)
                        price += priceChanged;
                }
                return price;
            },
            onBookingNow(event) {
                this.$emit('onBookingNow');
            },
            gotoHotelInfoPage(baseUrl) {
                this.$emit('onGoToHotelDetailUrl', baseUrl);
            },
            onFlightDetailShown(event, flight) {
                event.stopPropagation();
                var ele = $(event.target);

                this.selectedFlight = flight;

                setTimeout(function () {
                    $(ele.attr('href')).modal('show');
                }, 100);

                return false;

            },
            onHotelDetailShown(event, hotel) {
                event.stopPropagation();
                var ele = $(event.target).parent();
                this.loadHotelInfo(this.hotelSelected);
                setTimeout(function () {
                    $(ele.attr('href')).modal('show');
                }, 100);

                return false;
            },
            changeGalleryImage(event, element, source) {
                event.preventDefault();
                var ele = $(element);
                var self = $(event.target);

                if (typeof ele !== "undefined" && ele.length > 0 && typeof source === 'object') {
                    if (!Array.isArray(source)) {
                        ele.css({
                            backgroundImage: 'url(' + source.url + ')'
                        });

                        self.parent().find('.thumb-item').removeClass('active');
                        self.addClass('active');
                        ele.parent().find('.go-control').attr('data-index', self.attr('data-image-index'));
                    } else {
                        var imageIndex = self.attr('data-index') || null;
                        var imageControl = self.attr('data-control') || null;

                        if (imageIndex !== null && imageControl !== null) {

                            switch (imageControl) {
                                case 'next':
                                    self.parent().find('.go-control').attr('data-index', parseInt(imageIndex, 10) < (
                                        source.length - 1) ? parseInt(imageIndex, 10) + 1 : 0);
                                    break;
                                case 'prev':
                                    self.parent().find('.go-control').attr('data-index', parseInt(imageIndex, 10) > 0 ?
                                        parseInt(imageIndex, 10) - 1 : (source.length - 1));
                                    break;
                            }

                            ele.css({
                                backgroundImage: 'url(' + source[parseInt(self.attr('data-index'), 10)].url +
                                    ')'
                            });

                            var thumbItems = self.parents('.gallery__wrap').find('.thumb-item');
                            thumbItems.removeClass('active');
                            $(thumbItems.get(parseInt(self.attr('data-index')))).addClass('active');
                        }
                    }
                }

                return false;
            },
            loadHotelInfo(hotel) {
                if (hotel.description) {
                    return;
                }

                $.post('/package/get-hotel-info', {
                    packageId: this.packageQuery.id,
                    cityCode: this.packageQuery.to,
                    hotelId: hotel.hotelId
                }, function (data) {
                    Vue.set(hotel, 'description', data.description);
                    Vue.set(hotel, 'facilities', data.facilities);
                });
            },
            funcScrollTabs(windowWidth) {
                var current = $(window).scrollTop();
                var i = $(".fh-tabs-sticky");
                var h = 173;
                var w = $(".content-wrap");
                if (current > h && windowWidth >= 1200) {
                    i.addClass("sticky-active");
                    w.addClass("enable-sticky").css("padding-top", i.height() + 30);
                } else {
                    i.removeClass("sticky-active");
                    w.removeClass("enable-sticky").css("padding-top", "0");
                }
            },
            scrollTabsSelected() {
                var self = this;
                $(window).on('scroll resize', _.throttle(function () {
                    self.funcScrollTabs($(window).width());
                }, 100))
            },
            formatPrice(price) {
                return (price.toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',')
            },
            openMapView(e) {
                var targetParent = $(e.target).parent();
                var target = $(targetParent.attr('href'));

                if (typeof target !== 'undefined' && target.length > 0) {
                    target.prop('show-map', true);
                }

                var self = this;

                $("#modalHotelDetail").on('shown.bs.modal', function (e) {
                    var $this = $(e.target).parent();
                    var isMapShown = $this.prop('show-map');
                    var target = $($this.find("a[data-analyst='map-popup']").attr('href'));
                    var targetMap = typeof target !== 'undefined' ? target.find('> div') : null;

                    if (targetMap) {
                        var hotel = self.hotelSelected;

                        var myLatLng = {
                            lat: parseFloat(hotel.latitude),
                            lng: parseFloat(hotel.longitude)
                        };

                        var map = new google.maps.Map(targetMap[0], {
                            center: myLatLng,
                            zoom: 18
                        });
                        // Create a marker and set its position.
                        var marker = new google.maps.Marker({
                            map: map,
                            position: myLatLng,
                            title: hotel.name
                        });

                        var infoWindowHTML = `<div class="infowindow__wrap">
                                        <div class="infowindow__img" style="background-image:url(${hotel.imageInfos.length > 0 ? hotel.imageInfos[0].url : self.baseUrl + '/images/images-default.jpg'});"></div>
                                        <div class="infowindow__detail">
                                            <h5 class="infowindow__title">${hotel.name}</h5>
                                            <div class="infowindow__star">
                                                ${Array(parseInt(hotel.stars)).join(0).split(0).map((item, i) => `
                                                    <span class="icon-star"></span>
                                                `).join('')}
                                            </div>
                                            <span><i class="ico icon-location-arrow"></i> ${hotel.addressLines}</span>
                                            ${typeof hotel.trustyou !== 'undefined' ? `
                                                <div class="infowindow__score">
                                                    <div class="reviews-score reviews-score__${hotel.trustyou.score_description.toLowerCase().replace(/ +/g, '-')}">${hotel.trustyou.score_display}</div>
                                                    <div class="text">
                                                        <span>${hotel.trustyou.score_description}</span>
                                                        <small>${hotel.trustyou.reviews_count} ${parseInt(hotel.trustyou.reviews_count) > 1 ? `reviews` : 'review'}</small>
                                                     </div>
                                                </div>
                                            ` : ``}
                                        </div>
                                     </div>`;

                        setTimeout(function () {
                            self.infowindow.setContent(infoWindowHTML);
                            self.infowindow.open(map, marker);
                        }, 500);
                    }

                    if (isMapShown) {
                        $this.find('.nav-link[href="#tab-item-selected-map"]').trigger('click');
                    }
                }).on('hidden.bs.modal', function (e) {
                    $(e.target).parent().prop('show-map', false);
                });
                this.scrollTabsSelected();
                this.onHotelDetailShown(e, this.hotelSelected);
            },
            translateText(translateKey, defaultText, params) {
                return this.translate(this.$language, translateKey, params) || defaultText;
            }
        }
    }
</script>
