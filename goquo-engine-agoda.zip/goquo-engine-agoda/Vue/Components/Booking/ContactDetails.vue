﻿<template>
    <div>
        <div class="bk-box">
            <input type="hidden" name="PersonalDetails.City" v-model="personalDetails.city" />
            <input type="hidden" name="PersonalDetails.AddressLine1" v-model="personalDetails.addressLine1" />
            <div class="bk-box__wrap">
                <div class="form-group">
                    <span>
                        <small v-lang.TITLE></small>
                        <div class="radio-pure-box">
                            <div class="radio-pure">
                                <input type="radio" id="Mr" name="PersonalDetails.Title" value="Mr" v-model="personalDetails.title"  v-bind="{'selected': personalDetails.title === 'Mr'}">
                                <label for="Mr" v-lang.TITLE_MISTER></label>
                            </div>
                            <div class="radio-pure">
                                <input type="radio" id="Mrs" name="PersonalDetails.Title" value="Mrs" v-model="personalDetails.title" v-bind="{'selected': personalDetails.title === 'Mrs'}">
                                <label for="Mrs" v-lang.TITLE_MISSUS></label>
                            </div>
                            <div class="radio-pure">
                                <input type="radio" id="Ms" name="PersonalDetails.Title" value="Ms" v-model="personalDetails.title" v-bind="{'selected': personalDetails.title === 'Ms'}">
                                <label for="Ms" v-lang.TITLE_MS></label>
                            </div>
                        </div>
                    </span>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <div class="mtr-input">
                                <input class="mtr-ipt check-contact text-uppercase" type="text" name="PersonalDetails.FirstName" id="PersonalDetails_FirstName" v-model="personalDetails.firstName"
                                       :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')" required="required"
                                       data-val="true" :data-val-lettersonly="translateText('PLEASE_ENTER_LETTERS_ONLY', 'Please enter letters only.')"
                                       :data-val-regex="translateText('PLEASE_NOT_ALL_SPACES', 'Please not all space')"
                                       data-val-regex-pattern="(?!^ +$)^.+$"
                                       maxlength="26" autocomplete="given-name"
                                       v-on:blur="trimSpace(personalDetails.firstName, 'firstname')">
                                <span class="mtr-text" v-lang.FIRST_NAME>First Name</span>
                                <span class="mtr-bar"></span>
                                <small class="mtr-notify" data-valmsg-replace="true" data-valmsg-for="PersonalDetails.FirstName"></small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <div class="mtr-input">
                                <input class="mtr-ipt check-contact text-uppercase" type="text" name="PersonalDetails.LastName" id="PersonalDetails_LastName" :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                                       required="required" data-val="true" v-model="personalDetails.lastName" :data-val-lettersonly="translateText('PLEASE_ENTER_LETTERS_ONLY', 'Please enter letters only.')"
                                       :data-val-regex="translateText('PLEASE_NOT_ALL_SPACES', 'Please not all space')"
                                       data-val-regex-pattern="(?!^ +$)^.+$"
                                       maxlength="26" autocomplete="family-name"
                                       v-on:blur="trimSpace(personalDetails.lastName, 'lastname')">
                                <span class="mtr-text" v-lang.LAST_NAME>Last Name</span>
                                <span class="mtr-bar"></span>
                                <small class="mtr-notify" data-valmsg-replace="true" data-valmsg-for="PersonalDetails.LastName"></small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <div class="mtr-input">
                                <input class="mtr-ipt check-contact" type="text" name="PersonalDetails.EmailAddress" id="PersonalDetails_EmailAddress" v-model="personalDetails.emailAddress" minlength="3"
                                       maxlength="62" :data-val-email="translateText('ENTER_VALID_EMAIL', 'Please enter a valid email.')"
                                       :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')" required="required"
                                       :data-val-regex="translateText('ENTER_VALID_EMAIL', 'Please enter a valid email.')"
                                       data-val-regex-pattern="^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$"
                                       data-val="true" aria-required="true" autocomplete="email"
                                       v-on:keyup="trimSpace(personalDetails.emailAddress, 'email')">
                                <span class="mtr-text" v-lang.EMAIL_ADDRESS>Email address</span>
                                <span class="mtr-bar"></span>
                                <small class="mtr-notify" v-lang.ENTER_VALID_EMAIL></small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-5">
                                <div class="form-group">
                                    <div class="mtr-input">
                                        <select autocomplete="country-name" name="PersonalDetails.CountryCode" id="PersonalDetails_CountryCode" v-model="personalDetails.countryCode" data-val-required="Required"
                                            required="required" data-val="true" class="mtr-ipt selectCountry check-contact">
                                            <option value="" v-lang.SELECT_COUNTRY></option>
                                            <option :value="country.code" v-for="country in countries">{{country.name}} ({{country.phoneCode}})</option>
                                        </select>
                                        <span class="mtr-text" v-lang.PHONE_CODE></span>
                                        <span class="mtr-bar"></span>
                                        <small class="mtr-notify" data-valmsg-replace="true" data-valmsg-for="PersonalDetails.CountryCode" v-lang.YOUR_FIRSTNAME_CANT_BE_A_NUMBER></small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-7">
                                <div class="form-group">
                                    <div class="mtr-input">
                                        <input id="PersonalDetails_MobileNumber" class="mtr-ipt  check-contact" type="text" v-model="personalDetails.mobileNumber" required="required" data-val="true" :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                                               :data-val-regex="translateText('ENTER_VALID_PHONE', 'Please enter a valid phone number.')"
                                               data-val-regex-pattern="^[0-9]+" value="" data-rule-minlength="3" maxlength="26"
                                               :data-msg-minlength="translateText('FIELD_MIN_LENGTH', 'The minimum phone number length was 3.')"
                                               name="PersonalDetails.MobileNumber" autocomplete="tel" aria-required="true"
                                               v-on:keyup="trimSpace(personalDetails.mobileNumber, 'mobile')">
                                        <span class="mtr-text" v-lang.MOBILE_NUMBER>Mobile Number</span>
                                        <span class="mtr-bar"></span>
                                        <small class="mtr-notify" data-valmsg-replace="true" data-valmsg-for="PersonalDetails.MobileNumber"></small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <a href="javascript:void(0)" class="btn btn-md btn-primary bt-effect bt-continue" @click="nextSection($event)" v-lang.CONTINUE></a>
    </div>
</template>
<script>
    export default {
        props: ["personalDetails", "countries"],
        data() {
            return {}
        },
        methods: {
            nextSection(event) {
                var $this = $(event.target);
                // Number of invalid fields
                var fieldLength = 0;

                //Getting each value from contact details
                $(".bk-box input, .bk-box select").each(function () {
                    var _input = $(this);
                    if (!_input.valid()) {
                        // Add to variable if invalid
                        fieldLength++;
                    }
                });

                // If no invalid fields then proceed
                if (!fieldLength) {
                    $(".passenger-information").removeClass("hidden");
                    $this.addClass("hidden");

                    // Scroll to pax details after completion of contact details
                    $('html,body').animate({
                        scrollTop: $(".passenger-information").offset().top - 20
                    }, 500);

                    // Send contact information to server if sidesell loads correctly
                    if (typeof GQsidesell !== 'undefined' && typeof GQsidesell.saveContact == 'function') {
                        GQsidesell.saveContact();
                    }
                }
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            trimSpace(value, type) {
                let self = this;
                switch (type.toLowerCase()) {
                    case "firstname":
                        self.personalDetails.firstName = $.trim(value)
                        break;
                    case "lastname":
                        self.personalDetails.lastName = $.trim(value);
                        break;
                    case "email":
                        $("#PersonalDetails_EmailAddress").val($.trim(value));
                        self.personalDetails.emailAddress = $.trim(value);
                        break;
                    case "mobile":
                        $("#PersonalDetails_MobileNumber").val($.trim(value));
                        self.personalDetails.mobileNumber = $.trim(value);
                        break;
                }
            }
        }
    }
</script>
