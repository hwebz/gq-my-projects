﻿<template>
    <div>
        <div class="sidebar-hotel">
            <div v-if="packageQuery.outboundFlight">
                <div class="title-sidebar">
                    <strong>
                        <i class="icon-flight"></i>
                        <b v-lang.FLIGHTS></b>
                    </strong>
                </div>
                <div class="line-flight-sidebar">
                    <div class="flight-way__box" v-if="packageQuery.outboundFlight">
                        <h5><span v-lang.DEPARTURE_FLIGHT></span>: <small>{{packageQuery.outboundFlight.departureDate | formatDate('DD MMM YYYY')}}</small></h5>
                        <div class="flight-way__view">
                            <div v-for="leg in packageQuery.outboundFlight.legs">
                                <p class="aircraft" v-if="leg.airType"><small v-lang.AIRCRAFT>Aircraft</small> <small> - {{leg.airType}}</small></p>
                                <p class="aircraft" v-if="leg.stationType == 1"><small v-lang.BUS_SERVICE>Bus Service</small></p>
                                <p class="aircraft" v-if="leg.stationType == 2"><small v-lang.TRAIN_SERVICE>Train Service</small></p>
                                <p class="aircraft" v-if="leg.stationType == 3"><small v-lang.FERRY_SERVICE>Ferry Service</small></p>
                                <div class="line-way">
                                    <div class="line-logo">
                                        <img :src="'https://gqcdn.s3.amazonaws.com/airline-logos/svg/' + leg.airlineCode + '.svg'" alt="" class="airline-icon">
                                    </div>
                                    <div class="line-time">
                                        <div class="line-time__time">
                                            <strong>{{leg.departureAirportCode}}</strong>
                                            <span>{{leg.departureDate|formatDate('HH:mm')}}</span>
                                        </div>
                                        <div class="line-time__direction">
                                            <small>{{getDurationTime(leg)}}</small>
                                            <div class="ico-flight flight-depart">
                                                <i class="icon-flight"></i>
                                            </div>
                                            <small v-if="leg.cabinClass">{{translateText(leg.cabinClass.toUpperCase(), leg.cabinClass)}}</small>
                                        </div>
                                        <div class="line-time__time">
                                            <strong>{{leg.arrivalAirportCode}}</strong>
                                            <span>
                                                {{leg.arrivalDate|formatDate('HH:mm')}}
                                                <b class="ml15" v-if="leg.diffDates > 0">+{{leg.diffDates}}</b>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="line-control">
                                        <a class="bt-dropdown" :href="'#sumFlightDetail-'+leg.flightNumber + '-' + leg.departureAirportCode + leg.arrivalAirportCode" data-toggle="collapse">
                                            <i class="icon-down-chevron"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="flight-way__detail collapse" :id="'sumFlightDetail-'+leg.flightNumber + '-' + leg.departureAirportCode + leg.arrivalAirportCode">
                                    <div class="line-detail">
                                        <div class="line-infomation">
                                            <div class="item-info">
                                                <i class="icon-flight"></i>
                                                <span>{{leg.airlineName}}</span>
                                            </div>
                                            <div class="item-info">
                                                <i v-if="!leg.stationType ||leg.stationType == 0" class="icon-flight"></i>
                                                <i v-if="leg.stationType == 1" class="icon-bus-side-view"></i>
                                                <span v-if="leg.bookingClass">
                                                    <span v-if="!leg.stationType || leg.stationType == 0">{{leg.airlineCode}}{{leg.flightNumber}}, {{translateText(leg.cabinClass.toUpperCase(), leg.cabinClass)}} ({{leg.bookingClass}})</span>
                                                    <span v-else-if="leg.stationType == 1">BUS {{leg.airlineCode}}{{leg.flightNumber}}, {{leg.cabinClass}} ({{leg.bookingClass}})</span>
                                                    <span v-else-if="leg.stationType == 2">TRAIN {{leg.airlineCode}}{{leg.flightNumber}}, {{leg.cabinClass}} ({{leg.bookingClass}})</span>
                                                    <span v-else>FERRY {{leg.airlineCode}}{{leg.flightNumber}}, {{leg.cabinClass}}</span>
                                                </span>
                                                <span v-else>
                                                    <span v-if="!leg.stationType || leg.stationType == 0">{{leg.airlineCode}}{{leg.flightNumber}}, {{translateText(leg.cabinClass.toUpperCase(), leg.cabinClass)}}</span>
                                                    <span v-else-if="leg.stationType == 1">BUS {{leg.airlineCode}}{{leg.flightNumber}}, {{leg.cabinClass}}</span>
                                                    <span v-else-if="leg.stationType == 2">TRAIN {{leg.airlineCode}}{{leg.flightNumber}}, {{leg.cabinClass}}</span>
                                                    <span v-else>FERRY {{leg.airlineCode}}{{leg.flightNumber}}, {{leg.cabinClass}}</span>
                                                </span>
                                            </div>
                                            <div class="item-info" v-if="leg.arrivalTerminal">
                                                <i class="icon-meeting-room"></i>
                                                <span v-lang.ARRIVAL_AT_TERMINAL="{0: leg.arrivalTerminal.substr(leg.arrivalTerminal.length - 1, 1)}"></span>
                                            </div>
                                            <div class="item-info" v-if="leg.baggageWeight > 0">
                                                <i class="icon-briefcase"></i>
                                                <span v-lang.FREE_CHECKED_BAGGAGE_UP_TO_X_KG="{0: leg.baggageWeight}"></span>
                                            </div>
                                            <div class="item-info" v-if="leg.baggagePieces > 0">
                                                <i class="icon-briefcase"></i>
                                                <span v-lang.FREE_CHECKED_BAGGAGE_UP_TO_X_PIECES="{0: leg.baggagePieces}"></span>
                                            </div>
                                            <div class="item-info" v-if="leg.baggageWeight == 0 && leg.baggagePieces == 0">
                                                <i class="icon-briefcase"></i>
                                                <span v-if="packageQuery.outboundFlight.baggageFeeLink" v-lang.BAGGAGE_FEES_INFO1="{0: packageQuery.outboundFlight.baggageFeeLink, 1: leg.airlineName}">Baggage Information: <a target="_blank" :href="packageQuery.outboundFlight.baggageFeeLink">{{leg.airlineName}}</a></span>
                                                <span v-else v-lang.BAGGAGE_FEES_INFO2="{0: leg.airlineName}">Baggage Information: Confirm with {{leg.airlineName}}.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flight-way__box" v-if="packageQuery.inboundFlight">
                        <h5><span v-lang.ARRIVAL_FLIGHT></span>: <small>{{packageQuery.inboundFlight.departureDate | formatDate('DD MMM YYYY')}}</small></h5>
                        <div class="flight-way__view">
                            <div v-for="leg in packageQuery.inboundFlight.legs">
                                <p class="aircraft" v-if="leg.airType"><small v-lang.AIRCRAFT>Aircraft</small> <small> - {{leg.airType}}</small></p>
                                <p class="aircraft" v-if="leg.stationType == 1"><small v-lang.BUS_SERVICE>Bus Service</small></p>
                                <p class="aircraft" v-if="leg.stationType == 2"><small v-lang.TRAIN_SERVICE>Train Service</small></p>
                                <p class="aircraft" v-if="leg.stationType == 3"><small v-lang.FERRY_SERVICE>Ferry Service</small></p>
                                <div class="line-way">
                                    <div class="line-logo">
                                        <img :src="'https://gqcdn.s3.amazonaws.com/airline-logos/svg/' + leg.airlineCode + '.svg'" alt="" class="airline-icon">
                                    </div>
                                    <div class="line-time">
                                        <div class="line-time__time">
                                            <strong>{{leg.departureAirportCode}}</strong>
                                            <span>{{leg.departureDate|formatDate('HH:mm')}}</span>
                                        </div>
                                        <div class="line-time__direction">
                                            <small>{{getDurationTime(leg)}}</small>
                                            <div class="ico-flight flight-depart">
                                                <i class="icon-flight"></i>
                                            </div>
                                            <small v-if="leg.cabinClass">{{translateText(leg.cabinClass.toUpperCase(), leg.cabinClass)}}</small>
                                        </div>
                                        <div class="line-time__time">
                                            <strong>{{leg.arrivalAirportCode}}</strong>
                                            <span>
                                                {{leg.arrivalDate|formatDate('HH:mm')}}
                                                <b class="ml15" v-if="leg.diffDates > 0">+{{leg.diffDates}}</b>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="line-control">
                                        <a class="bt-dropdown" :href="'#sumFlightDetail-'+leg.flightNumber + '-' + leg.departureAirportCode + leg.arrivalAirportCode" data-toggle="collapse">
                                            <i class="icon-down-chevron"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="flight-way__detail collapse" :id="'sumFlightDetail-'+leg.flightNumber + '-' + leg.departureAirportCode + leg.arrivalAirportCode">
                                    <div class="line-detail">
                                        <div class="line-infomation">
                                            <div class="item-info">
                                                <i class="icon-flight"></i>
                                                <span>{{leg.airlineName}}</span>
                                            </div>
                                            <div class="item-info">
                                                <i v-if="!leg.stationType ||leg.stationType == 0" class="icon-flight"></i>
                                                <i v-if="leg.stationType == 1" class="icon-bus-side-view"></i>
                                                <span v-if="leg.bookingClass">
                                                    <span v-if="!leg.stationType || leg.stationType == 0">{{leg.airlineCode}}{{leg.flightNumber}}, {{translateText(leg.cabinClass.toUpperCase(), leg.cabinClass)}} ({{leg.bookingClass}})</span>
                                                    <span v-else-if="leg.stationType == 1">BUS {{leg.airlineCode}}{{leg.flightNumber}}, {{leg.cabinClass}} ({{leg.bookingClass}})</span>
                                                    <span v-else-if="leg.stationType == 2">TRAIN {{leg.airlineCode}}{{leg.flightNumber}}, {{leg.cabinClass}} ({{leg.bookingClass}})</span>
                                                    <span v-else>FERRY {{leg.airlineCode}}{{leg.flightNumber}}, {{leg.cabinClass}}</span>
                                                </span>
                                                <span v-else>
                                                    <span v-if="!leg.stationType || leg.stationType == 0">{{leg.airlineCode}}{{leg.flightNumber}}, {{translateText(leg.cabinClass.toUpperCase(), leg.cabinClass)}}</span>
                                                    <span v-else-if="leg.stationType == 1">BUS {{leg.airlineCode}}{{leg.flightNumber}}, {{leg.cabinClass}}</span>
                                                    <span v-else-if="leg.stationType == 2">TRAIN {{leg.airlineCode}}{{leg.flightNumber}}, {{leg.cabinClass}}</span>
                                                    <span v-else>FERRY {{leg.airlineCode}}{{leg.flightNumber}}, {{leg.cabinClass}}</span>
                                                </span>
                                            </div>
                                            <div class="item-info" v-if="leg.arrivalTerminal">
                                                <i class="icon-meeting-room"></i>
                                                <span v-lang.ARRIVAL_AT_TERMINAL="{0: leg.arrivalTerminal.substr(leg.arrivalTerminal.length - 1, 1)}"></span>
                                            </div>
                                            <div class="item-info" v-if="leg.baggageWeight > 0">
                                                <i class="icon-briefcase"></i>
                                                <span v-lang.FREE_CHECKED_BAGGAGE_UP_TO_X_KG="{0: leg.baggageWeight}"></span>
                                            </div>
                                            <div class="item-info" v-if="leg.baggagePieces > 0">
                                                <i class="icon-briefcase"></i>
                                                <span v-lang.FREE_CHECKED_BAGGAGE_UP_TO_X_PIECES="{0: leg.baggagePieces}"></span>
                                            </div>
                                            <div class="item-info" v-if="leg.baggageWeight == 0 && leg.baggagePieces == 0">
                                                <i class="icon-briefcase"></i>
                                                <span v-if="packageQuery.inboundFlight.baggageFeeLink" v-lang.BAGGAGE_FEES_INFO1="{0: packageQuery.inboundFlight.baggageFeeLink, 1: leg.airlineName}"></span>
                                                <span v-else v-lang.BAGGAGE_FEES_INFO2="{0: leg.airlineName}"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div v-if="packageQuery.hotels">
                <div class="title-sidebar">
                    <strong>
                        <i class="icon-hotel"></i>
                        <b v-lang.HOTEL></b>
                    </strong>
                    <span>{{packageQuery.checkIn | formatDate("DD MMM YYYY") }} - {{ packageQuery.checkOut | formatDate("DD MMM YYYY") }} (<span v-if="hotelStay == 1" v-lang.ONE_NIGHT>1 night</span><span v-else v-lang.X_NIGHTS="{0: hotelStay}"></span>)</span>
                </div>
                <div class="line-flight-sidebar" v-for="(hotel, index) in packageQuery.hotels" :key="index">
                    <div class="flight-way__box">
                        <div class="flight-way__view">
                            <div class="line-way line-way-hotel">
                                <div class="line-images-hotel" :style="`background-image:url(${hotel.imageInfos[0].thumbnailUrl || hotel.imageInfos[0].url})`">

                                </div>
                                <div class="line-time line-hotel">
                                    <div class="title-hotel">{{hotel.name}}</div>
                                    <div class="room-hotel"><i class="ico icon-location-arrow"></i>{{hotel.addressLines}}</div>
                                    <div class="room-hotel block">
                                        <i class="ico icon-user"></i>{{roomCount}} {{roomCount > 1 ? translateText("ROOMS", 'Rooms') : translateText("ROOM", 'Room')}} - {{calculatePaxCount()}} {{calculatePaxCount() == 1 ? translateText('PASSENGER', 'Passenger') : translateText('PASSENGERS', 'Passengers') }}
                                    </div>
                                </div>
                            </div>
                            <div class="line-cancellation" v-for="(roomType, indexRoom) in hotel.availableRooms" :key="indexRoom">
                                <p><i class="ico icon-hotel"></i><span v-lang.ROOM>Room</span>: {{roomType.name}}</p>
                                <div class="notify" v-if="isHotelCancellation(roomType.availableRoomTypes[0]) === 'free'">
                                    <div class="freecan">
                                        <span>
                                            <i class="icon-check"></i>
                                            <span v-lang.FREE_CANCELLATION_AVAILABLE></span>
                                            <!--<template v-if="roomType.availableRoomTypes[0].cancelFreeBeforeDate">-->
                                            <!--before {{roomType.availableRoomTypes[0].cancelFreeBeforeDate | formatDate("MM/DD/YYYY")}}-->
                                            <!--</template>-->
                                        </span>
                                        <a href="#modalCancellationPrice" data-toggle="modal" @click.prevent="getCancellationPrice(roomType.availableRoomTypes[0])"><i class="icon-information"></i></a>
                                    </div>
                                </div>
                                <div class="notify" v-if="isHotelCancellation(roomType.availableRoomTypes[0]) === 'apart'">
                                    <div class="freecan">
                                        <span><i class="icon-check"></i><span v-lang.REFUNDABLE></span></span>
                                        <a href="#modalCancellationPrice" data-toggle="modal" @click.prevent="getCancellationPrice(roomType.availableRoomTypes[0])"><i class="icon-information"></i></a>
                                    </div>
                                </div>
                                <div class="notify" v-if="isHotelCancellation(roomType.availableRoomTypes[0]) === 'non'">
                                    <div class="freecan non-refund">
                                        <span><i class="icon-remove"></i><span v-lang.NONREFUNDABLE></span></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div v-if="packageQuery.tours && packageQuery.tours.length > 0">
                <div class="title-sidebar">
                    <strong>
                        <i class="icon-camera"></i>
                        <b v-lang.TOUR></b>
                    </strong>
                    <span><span v-lang.NUMBER_OF_TOURS></span>: {{packageQuery.tours.length}}</span>
                </div>
                <div class="line-flight-sidebar" v-for="(tour, index) in packageQuery.tours" :key="index">
                    <div class="flight-way__box">
                        <div class="flight-way__view">
                            <div class="line-way line-way-hotel">
                                <div class="line-images-hotel" :style="'background-image: url(' + (tour.thumbnail ? tour.thumbnail : (tour.images && tour.images.length > 0 ? tour.images[0] : baseUrl + '/images/tour-default.png')) + ');'"> </div>
                                <div class="line-time line-hotel">
                                    <div class="title-hotel">{{tour.name}}</div>
                                    <div class="room-hotel">
                                        <i class="ico icon-clock"></i>{{tour.operatorDate | formatDate("DD MMM YYYY")}} {{tour.departureTime}}
                                    </div>
                                    <div class="room-hotel" v-if="tour.activities.length > 0" v-for="act in tour.activities">
                                        <i class="ico icon-camera"></i>{{act.name}}
                                    </div>
                                    <div class="room-hotel"><i class="ico icon-location-arrow"></i>{{packageQuery.toCityName}}, {{packageQuery.toCountryName}}</div>
                                    <div class="room-hotel block">
                                        <i class="ico icon-user"></i>
                                        <template v-if="tour.adults > 0">
                                            {{tour.adults}} {{tour.adults == 1 ? translateText('ADULT', 'Adult') : translateText('ADULTS', 'Adults')}}
                                        </template>
                                        <template v-if="tour.children > 0">
                                            , {{tour.children}} {{tour.children == 1 ? translateText('CHILD', 'Child') : translateText('CHILDREN', 'Children')}}
                                        </template>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div v-if="packageQuery.arrivalTransfer">
                <div class="title-sidebar">
                    <strong>
                        <i class="icon-car"></i>
                        <b v-lang.ARRIVAL_TRANSFER></b>
                    </strong>
                </div>
                <div class="line-flight-sidebar">
                    <div class="flight-way__box">
                        <div class="flight-way__view">
                            <div class="line-way line-way-hotel transfers">
                                <!--<div class="line-images-hotel transfers" :style="'background-image: url(' + (packageQuery.arrivalTransfer.images.length > 0 ? packageQuery.arrivalTransfer.images[0] : '/images/images-default.jpg') + ');'"> </div>-->
                                <div class="line-time line-hotel">
                                    <div class="title-hotel">{{packageQuery.arrivalTransfer.name}}</div>
                                    <div class="room-hotel">
                                        <i class="ico icon-clock"></i>
                                        <span class="highlight"><span v-lang.AT></span>: {{pickUpDate(packageQuery.arrivalTransfer)}}</span>
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-clock"></i>
                                        <span><span v-lang.RIDE_TIME></span>: {{packageQuery.arrivalTransfer.approximateTransferTime}}</span>
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-location-arrow"></i> <span v-lang.FROM></span>: {{packageQuery.toAirportName}}
                                        <template v-if="packageQuery.toCityName">
                                            , {{packageQuery.toCityName}}
                                        </template>
                                        <template v-if="packageQuery.toCountryName">
                                            , {{packageQuery.toCountryName}}
                                        </template>
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-flight"></i> <span v-lang.FLIGHT_NUMBER></span>: {{packageQuery.arrivalTransfer.vehicles[0].flightNo}}
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-clock"></i> <span v-lang.FLIGHT_TIME></span>: {{packageQuery.arrivalTransfer.vehicles[0].flightTime}}
                                    </div>
                                    <div class="room-hotel">

                                        <span v-if="packageQuery.arrivalTransfer.questions && packageQuery.arrivalTransfer.questions.length > 0">
                                            <i class="ico icon-map-marker"></i> <span v-lang.TO></span>:
                                            <template v-for="(question, idx) in packageQuery.arrivalTransfer.questions">
                                                {{question.value}}{{idx < packageQuery.arrivalTransfer.questions.length - 1 ? ', ' : ''}}
                                            </template>
                                        </span>
                                        <span v-else>
                                            <i class="ico icon-map-marker"></i> <span v-lang.TO></span>:
                                            <template v-if="packageQuery.arrivalTransfer.vehicles[0].hotelName">
                                                {{packageQuery.arrivalTransfer.vehicles[0].hotelName}}
                                            </template>
                                        </span>
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-user"></i>
                                        {{calculatePaxCount()}} {{calculatePaxCount() > 1 ? translateText('PASSENGERS', 'Passengers') : translateText('PASSENGER', 'Passenger')}}
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-car"></i>
                                        <span class="highlight"><span v-lang.NO_OF_VEHICLES></span>: {{packageQuery.arrivalTransfer.vehicles[0].noOfVehicle}}</span>
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-briefcase"></i>
                                        <span v-lang.MAX_LUGGAGE></span>: {{packageQuery.arrivalTransfer.vehicles[0].maxLuggage}}
                                    </div>
                                    <div class="room-hotel">
                                        <a href="#modalCancellationTransfer" class="bt-link" data-toggle="modal" @click.prevent="setCancellationTransfer(packageQuery.arrivalTransfer.isReturnJourney)">
                                            <i class="icon-information"></i>
                                            <span v-lang.VIEW_CANCELLATION_POLICY></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div v-if="packageQuery.departureTransfer">
                <div class="title-sidebar">
                    <strong>
                        <i class="icon-car"></i>
                        <b v-lang.DEPARTURE_TRANSFER></b>
                    </strong>
                </div>
                <div class="line-flight-sidebar">
                    <div class="flight-way__box">
                        <div class="flight-way__view">
                            <div class="line-way line-way-hotel transfers">
                                <!--<div class="line-images-hotel transfers" :style="'background-image: url(' + (packageQuery.arrivalTransfer.images.length > 0 ? packageQuery.arrivalTransfer.images[0] : '/images/images-default.jpg') + ');'"> </div>-->
                                <div class="line-time line-hotel">
                                    <div class="title-hotel">{{packageQuery.departureTransfer.name}}</div>
                                    <div class="room-hotel">
                                        <i class="ico icon-clock"></i>
                                        <span class="highlight"><span v-lang.AT></span>: {{pickUpDate(packageQuery.departureTransfer)}}</span>
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-clock"></i>
                                        <span><span v-lang.ESTIMATE_CHECKIN_TIME></span>: {{packageQuery.departureTransfer.allowForCheckInTime}}</span>
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-clock"></i>
                                        <span><span v-lang.RIDE_TIME></span>: {{packageQuery.departureTransfer.approximateTransferTime}}</span>
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-location-arrow"></i> <span v-lang.FROM></span>:
                                        <template v-for="(question, idx) in packageQuery.departureTransfer.questions">
                                            {{question.value}}{{idx < packageQuery.departureTransfer.questions.length - 1 ? ', ' : ''}}
                                        </template>
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-flight"></i> <span v-lang.FLIGHT_NUMBER></span>: {{packageQuery.departureTransfer.vehicles[0].flightNo}}
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-clock"></i> <span v-lang.FLIGHT_TIME></span>: {{packageQuery.departureTransfer.vehicles[0].flightTime}}
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-map-marker"></i> <span v-lang.TO></span>: {{packageQuery.toAirportName}}
                                        <template v-if="packageQuery.toCityName">
                                            , {{packageQuery.toCityName}}
                                        </template>
                                        <template v-if="packageQuery.toCountryName">
                                            , {{packageQuery.toCountryName}}
                                        </template>
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-user"></i>
                                        {{calculatePaxCount()}} {{calculatePaxCount() > 1 ? translateText('PASSENGERS', 'Passengers') : translateText('PASSENGER', 'Passenger')}}
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-car"></i>
                                        <span class="highlight"><span v-lang.NO_OF_VEHICLES></span>: {{packageQuery.departureTransfer.vehicles[0].noOfVehicle}}</span>
                                    </div>
                                    <div class="room-hotel">
                                        <i class="ico icon-briefcase"></i>
                                        <span v-lang.MAX_LUGGAGE></span>: {{packageQuery.departureTransfer.vehicles[0].maxLuggage}}
                                    </div>
                                    <div class="room-hotel">
                                        <a href="#modalCancellationTransfer" class="bt-link" data-toggle="modal" @click.prevent="setCancellationTransfer(packageQuery.departureTransfer.isReturnJourney)">
                                            <i class="icon-information"></i>
                                            <span v-lang.VIEW_CANCELLATION_POLICY></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="promo-sidebar">
                <div class="form-group">
                    <div class="mtr-input">
                        <input type="text" class="mtr-ipt placeH-sm no-check-error" id="txtPromoCode" :placeholder="translateText('ENTER_PROMO_CODE', 'Enter promo code...')" v-model="promoCode" name="PromoCode" />
                        <span class="mtr-text" v-lang.PROMO></span>
                        <span class="mtr-bar"></span>
                        <span v-if="promoError" class="mtr-notify" v-lang.PROMO_CODE_IS_INVALID></span>
                        <span v-if="isSuccessPromo" class="mtr-notify success" v-lang.COUPON_APPLIED></span>
                        <span class="input-group-btn" v-show="packageQuery.priceSummary.promoPrice == 0">
                            <button type="button" class="btn btn-primary bt-effect" @click="calcPromoPrice()" v-lang.APPLY></button>
                        </span>
                        <span class="input-group-btn" v-show="packageQuery.priceSummary.promoPrice != 0">
                            <button type="button" class="btn btn-danger bt-effect" @click="calcPromoPrice(true)" v-lang.CLEAR>Clear</button>
                        </span>
                    </div>
                </div>
            </div>
            <PriceSummary ref="priceSummary" :packageQuery="packageQuery" :addons="addons" :seatSelecteds="seatSelecteds" :currentSection="currentSection" @onSummaryNextSection="onSummaryNextSection"></PriceSummary>
            <div class="promo-sidebar" v-if="fareRules.length > 0">
                <div class="form-group" v-if="clientResources.uniqueId === 5">
                    <span v-lang.PACKAGES_DO_NOT_ALLOW_REFUND_OR_CANCELLATION>Packages do not allow Refund or Cancellation</span>
                </div>
                <div class="form-group" v-else>
                    <a href="#modalFareRule" data-toggle="modal" V-LANG.SEE_APPLICABLE_FARE_RULES>See applicable Fare Rules</a>                    
                </div>
            </div>
        </div>

        <div class="modal fade" id="modalCancellationPrice" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body modal-body-gray npd">
                        <div class="flight-detail-title">
                            <strong v-lang.CANCELLATION_POLICY></strong>
                            <button class="modal-close" data-dismiss="modal">
                                <i class="icon-remove"></i>
                            </button>
                        </div>
                        <div class="price-summary-table">
                            <table v-if="cancellation">
                                <tbody>
                                    <template v-for="(cancelBefore, index) in cancellation.roomCancelCharges">
                                        <tr>
                                            <template v-if="cancelBefore.dateFrom && cancelBefore.dateTo">
                                                <span v-if="dateDiff(cancelBefore.dateFrom, cancelBefore.dateTo)">
                                                    <template v-if="cancelBefore.amount > 0">
                                                        <strong>{{packageQuery.currency}} {{cancelBefore.amount | formatCurrency}}</strong>
                                                        <span v-lang.WILL_BE_CHARGED_FOR_CANCELLATION_FROM></span>
                                                        {{cancelBefore.dateFrom | formatDate("DD MMM")}} - {{cancelBefore.dateTo | formatDate("DD MMM YYYY")}}
                                                    </template>
                                                    <template v-else>
                                                        <strong v-lang.FREE_CANCELLATION></strong>
                                                        <span v-lang.BEFORE_AND_ON="{0: formatDate(cancelBefore.dateTo,'DD MMM YYYY')}"></span>:
                                                    </template>
                                                </span>
                                                <span v-else>
                                                    <span v-lang.ON></span> {{cancelBefore.dateFrom | formatDate("DD MMM YYYY")}}:
                                                    <template v-if="cancelBefore.amount > 0">
                                                        <span v-lang.CHARGE></span>
                                                        <strong>{{packageQuery.currency}} {{cancelBefore.amount | formatCurrency}}</strong>
                                                    </template>
                                                    <template v-else>
                                                        <strong v-lang.FREE_CANCELLATION></strong>
                                                    </template>
                                                </span>
                                            </template>
                                        </tr>
                                        <tr>
                                            <template v-if="cancelBefore.amount === cancellation.totalPrice">
                                                <span>
                                                    <strong v-lang.NONREFUNDABLE></strong><span v-lang.AFTER="{0:formatDate(cancelBefore.dateTo,'DD MMM YYYY')}"></span>
                                                </span>
                                            </template>
                                        </tr>
                                    </template>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-primary bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                    </div>
                </div>
            </div>
        </div>
       
        <!-- Modal fare rule -->
        <div class="modal fade" id="modalFareRule" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body modal-body-gray npd">
                        <div class="flight-detail-title farerule-title">
                            <strong v-lang.FARE_RULE>Fare rule</strong>
                            <button class="modal-close" data-dismiss="modal">
                                <i class="icon-remove"></i>
                            </button>
                        </div>
                        <div class="farerule-table">
                            <div class="bk-tabs">
                                <div class="bk-tabs__header bk-tabs__header--left" v-if="fareRules">
                                    <div class="bk-tabs__header--group nav nav-tabs">
                                        <div class="bk-tabs__header__item" v-bind:class="{'active': fareRule.cityPair == selectedFareRule.cityPair}" :href="'#' + fareRule.cityPair" data-toggle="tab" role="tab" v-for="(fareRule, fareIndex) in fareRules"
                                             :key="`header-${fareIndex}`" @click="choiceTab(fareRule.cityPair)">
                                            <strong>{{fareRule.cityPair.substring(0,3)}} - {{fareRule.cityPair.substring(3,6)}}</strong>
                                        </div>
                                    </div>
                                </div>
                                <div class="bk-tabs__content tab-content scroll-hoz farerule-content">
                                    <template>
                                        <div :id="fareRule.cityPair + fareIndex" class="tab-pane show" v-bind:class="{'active': fareRule.cityPair == selectedFareRule.cityPair}" v-for="(fareRule, fareIndex) in fareRules"
                                             :key="`content-${fareIndex}`">
                                            <div v-for="(ruleDetail, ruleIndex) in fareRule.ruleDetails">
                                                <strong>{{ruleDetail.category}}: </strong><span v-html="ruleDetail.rules.toLowerCase()"></span><br />
                                            </div>
                                        </div>
                                    </template>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-primary bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE>Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import Vue from 'vue';
    import { mapState } from 'vuex'
    import StarRating from './StarRating.vue'
    import PriceSummary from './PriceSummary.vue'
    export default {
        components: {
            StarRating,
            PriceSummary
        },
        props: ["packageQuery", "currentSection", "addons", "seatSelecteds", "outboundFlight", "clientResources"],
        data() {
            return {
                adults: [],
                childs: [],
                promoCode: null,
                promoError: null,
                cancellation: null,
                isSuccessPromo: false,
                fareRules: [],
                selectedFareRule: {},               
            }
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            baseUrl: state => state.workContext.baseUrl,
            roomCount() {
                return this.packageQuery.paxInfos.length;
            },
            hotelStay() {
                var start = moment(this.packageQuery.checkIn);
                var end = moment(this.packageQuery.checkOut);
                start.hours(0).minutes(0);
                return end.diff(start, 'days');
            }
        }),
        created() {
            let self = this;
            if (self.outboundFlight && self.outboundFlight.fareRules) {
                $.each(self.outboundFlight.fareRules, function (i, e) {
                    var matchingItems = $.grep(self.fareRules, function (item) {
                        return item.cityPair === e.cityPair && item.airline === e.airline;
                    });
                    if (matchingItems.length === 0) {
                        self.fareRules.push(e);
                    }
                });
                self.selectedFareRule = self.fareRules[0];
            }
        },
        mounted() {
            $("#btnCancellationPolicy").popover();
        },
        methods: {
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            isHotelCancellation(availableRoomType) {
                let isCancellation = 'non';
                if (!availableRoomType) return isCancellation;
                if (availableRoomType.cancelFreeBeforeDate) return 'free';
                let cancelCharges = availableRoomType && availableRoomType.roomCancelCharges != undefined && availableRoomType.roomCancelCharges ? availableRoomType.roomCancelCharges : [];
                if (cancelCharges.length > 0) {
                    for (let i = 0; i < cancelCharges.length; i++) {
                        if (cancelCharges[i].amount > 0) {
                            isCancellation = 'apart';
                        }
                    }
                }
                return isCancellation;
            },
            setCancellationTransfer(isDeparture) {               
                this.$emit('onSetCancellationTransfer', {
                    isDeparture: isDeparture,
                });
            },
            pickUpDate(transfer) {
                let pickUpDate = Vue.moment(new Date(transfer.vehicles[0].pickUpDate.split('T')[0] + " " + transfer.vehicles[0].pickUpTime));
                return pickUpDate.format("DD MMM YYYY HH:mm")
            },
            calculatePax(tour) {
                return tour ? (tour.adults + tour.children) : 0;
            },
            dateDiff(fromDate, toDate) {
                var fDate = Vue.moment(fromDate.split('T')[0]);
                var tDate = Vue.moment(toDate.split('T')[0]);

                if (tDate.diff(fDate) > 0) return true;
                return false;
            },           
            getCancellationPrice(roomType) {
                this.cancellation = roomType;
            },
            getHotelDate(x, y) {
                if (y) {
                    return y;
                }
                return x;
            },
            updatePriceSummary() {
                this.$refs.priceSummary.updatePriceSummary();
            },
            calcPromoPrice(isClear) {
                var self = this;
                this.$emit("onCalcPromoPrice", function (priceSummary) {
                    if (priceSummary.promoPrice === 0) {
                        if (!isClear)
                            self.promoError = true;
                        self.promoCode = null;
                    } else {
                        if (!isClear)
                            self.isSuccessPromo = true;

                        setTimeout(function () {
                            self.isSuccessPromo = false;
                        }, 3000);
                        self.promoError = false;
                    }
                }, isClear);
            },
            getDurationTime(flight) {
                if (!flight) {
                    return "-";
                }
                if (flight.legs) {
                    var duration = 0;
                    for (var i = 0; i < flight.legs.length; i++) {
                        duration += flight.legs[i].duration;
                    }
                } else {
                    duration = flight.duration;
                }

                var hours = 0;
                var minutes = 0;

                if (duration > 0) {
                    hours = Math.floor(duration / 60);
                    minutes = duration - (hours * 60);
                    return hours + 'h ' + minutes + 'm';
                }
                else {
                    // var departureDate = moment(new Date(flight.departureDate));
                    // var arrivalDate = moment(new Date(flight.arrivalDate));
                    //
                    // var flightTime = moment.duration(arrivalDate.diff(departureDate));
                    // hours = flightTime.hours();
                    // minutes = flightTime.minutes();
                    return ' ';
                }
            },
            calculatePaxCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                    count += paxInfo.childCount;
                }
                return count;
            },
            onSummaryNextSection() {
                this.$emit('onSummaryNextSection');
            },
            choiceTab(cityPair) {
                let self = this;
                self.selectedFareRule = $.grep(self.fareRules, function (p) {
                    return p.cityPair == cityPair;
                })[0];
            },
            formatDate(date, format) {
                return moment.utc(date).format(format);
            }
        }
    }
</script>
