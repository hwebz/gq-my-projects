﻿<template>
    <div>
        <div class="bk-box">

            <input type="hidden" :value="passenger.passengerType" :name="'Passengers[{0}].PassengerType'|stringFormat(passenger.passengerIndex)">
            <input type="hidden" :value="'Passengers[{0}].'|stringFormat(passenger.passengerIndex)" :name="'Passengers[{0}].ModelPrefix'|stringFormat(passenger.passengerIndex)">
            <input type="hidden" :value="passenger.roomIndex" :name="'Passengers[{0}].RoomIndex'|stringFormat(passenger.passengerIndex)">
            <div class="bk-box__title">
                <strong><span v-lang.PASSENGER></span> {{passenger.passengerIndex + 1}} - <span v-lang.ADULT></span></strong>
                <div class="bk-box__title__copy" v-if="passenger.passengerIndex == 0">
                    <div class="style-check">
                        <input type="checkbox" class="ipt-check" name="clone-contact-details" id="clone-contact-details" @change="cloneContactDetails($event)" v-model="isCloneContactDetails" />
                        <label class="ipt-label" for="clone-contact-details">
                            <!--<span class="box"></span>-->
                            <div class="drop-text">
                                <i class="icon-copy"></i>
                                <span v-lang.CONTACT_DETAILS_COPY></span>
                            </div>
                        </label>
                    </div>

                </div>
            </div>
            <div class="bk-box__wrap">
                <div class="form-group">
                    <span>
                        <small v-lang.TITLE></small>
                        <div class="radio-pure-box">
                            <div class="radio-pure" v-bind:class="{'active': passenger.title === 'Mr'}">
                                <input type="radio" :id="'P-Mr-' + passenger.passengerIndex" :name="'Passengers[{0}].Title'|stringFormat(passenger.passengerIndex)" value="Mr" v-model="passenger.title">
                                <label :for="'P-Mr-' + passenger.passengerIndex" v-lang.TITLE_MISTER></label>
                            </div>
                            <div class="radio-pure" v-bind:class="{'active': passenger.title === 'Mrs'}">
                                <input type="radio" :id="'P-Mrs-' + passenger.passengerIndex" :name="'Passengers[{0}].Title'|stringFormat(passenger.passengerIndex)" value="Mrs" v-model="passenger.title">
                                <label :for="'P-Mrs-' + passenger.passengerIndex" v-lang.TITLE_MISSUS></label>
                            </div>
                            <div class="radio-pure" v-bind:class="{'active': passenger.title === 'Ms'}">
                                <input type="radio" :id="'P-Ms-' + passenger.passengerIndex" :name="'Passengers[{0}].Title'|stringFormat(passenger.passengerIndex)" value="Ms" v-model="passenger.title">
                                <label :for="'P-Ms-' + passenger.passengerIndex" v-lang.TITLE_MS></label>
                            </div>
                        </div>
                    </span>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <div class="mtr-input">
                                <input autocomplete="given-name" class="mtr-ipt placeH-sm text-uppercase" type="text"
                                       :name="'Passengers[{0}].FirstName'|stringFormat(passenger.passengerIndex)"
                                       :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                                       required="required" data-val="true" v-model="passenger.firstName"
                                       :data-val-lettersonly="translateText('PLEASE_ENTER_LETTERS_ONLY', 'Please enter letters only.')"
                                       :data-val-regex="translateText('PLEASE_NOT_ALL_SPACES', 'Please not all space')"
                                       data-val-regex-pattern="(?!^ +$)^.+$"
                                       maxlength="26"
                                       v-on:blur="trimSpace(passenger.firstName, 'firstName')">
                                <span class="mtr-text" v-lang.FIRST_MIDDLE_NAMES></span>
                                <span class="mtr-bar"></span>
                                <small class="mtr-notify" data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].FirstName'|stringFormat(passenger.passengerIndex)"></small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <div class="mtr-input">
                                <input autocomplete="family-name" class="mtr-ipt placeH-sm text-uppercase" type="text" 
                                       :name="'Passengers[{0}].LastName'|stringFormat(passenger.passengerIndex)" 
                                       :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                                       required="required" data-val="true" v-model="passenger.lastName" 
                                       :data-val-lettersonly="translateText('PLEASE_ENTER_LETTERS_ONLY', 'Please enter letters only.')"
                                       :data-val-regex="translateText('PLEASE_NOT_ALL_SPACES', 'Please not all space')"
                                       data-val-regex-pattern="(?!^ +$)^.+$"
                                       maxlength="26"
                                       v-on:blur="trimSpace(passenger.lastName, 'lastName')">
                                <span class="mtr-text" v-lang.LAST_NAME></span>
                                <span class="mtr-bar"></span>
                                <small class="mtr-notify" data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].LastName'|stringFormat(passenger.passengerIndex)"></small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <div class="mtr-input">
                                <select autocomplete="given-name" class="mtr-ipt" type="text" :name="'Passengers[{0}].Nationality'|stringFormat(passenger.passengerIndex)" :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                                    data-val="true" v-model="passenger.nationality" required>
                                    <option value="" v-lang.SELECT_COUNTRY></option>
                                    <option :value="country.code" v-for="country in countries">{{country.name}}</option>
                                </select>
                                <span class="mtr-text" v-lang.NATIONALITY>Nationality</span>
                                <span class="mtr-bar"></span>
                                <small class="mtr-notify" data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].Nationality'|stringFormat(passenger.passengerIndex)"></small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6" v-if="hasFlight">
                        <div class="form-group">
                            <div class="mtr-input">
                                <input class="mtr-ipt" autocomplete="off" data-val="true" type="text" maxlength="11" minlength="11" :name="'Passengers[{0}].FrequentFlyerNumber'|stringFormat(passenger.passengerIndex)"
                                       :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                                       v-model="passenger.frequentFlyerNumber" :data-val-regex="translateText('INVALID_FORMAT', 'Invalid Format')" />
                                <span class="mtr-text"><span v-lang.MILES_FREQUENT_FLYER_NUMBER="{0: siteInfo.name}"></span> <small v-lang.OPTIONAL></small></span>
                                <span class="mtr-bar"></span>
                                <small class="mtr-notify" data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].FrequentFlyerNumber'|stringFormat(passenger.passengerIndex)"></small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <input type="hidden" :name="'Passengers[{0}].DayOfBirth'|stringFormat(passenger.passengerIndex)" value="21" />
                    <input type="hidden" :name="'Passengers[{0}].MonthOfBirth'|stringFormat(passenger.passengerIndex)" value="02" />
                    <input type="hidden" :name="'Passengers[{0}].YearOfBirth'|stringFormat(passenger.passengerIndex)" value="1966" />
                    <input type="hidden" :name="'Passengers[{0}].PassportNo'|stringFormat(passenger.passengerIndex)" :value="'G12312312' + passenger.passengerIndex">
                    <input type="hidden" :name="'Passengers[{0}].DayOfExpiryDate'|stringFormat(passenger.passengerIndex)" value="17" />
                    <input type="hidden" :name="'Passengers[{0}].MonthOfExpiryDate'|stringFormat(passenger.passengerIndex)" value="04" />
                    <input type="hidden" :name="'Passengers[{0}].YearOfExpiryDate'|stringFormat(passenger.passengerIndex)" value="2028" />
                    <input type="hidden" :name="'Passengers[{0}].PassportIssueCountry'|stringFormat(passenger.passengerIndex)" value="VN" />
                    <input type="hidden" :name="'AddonsDetails[{0}].Addons[{1}]'|stringFormat(passenger.addonIndex, index)" :value="addon" v-for="(addon, index) in parseAddonModel(passenger.passengerIndex)" />
                    <input type="hidden" :name="'AddonsDetails[{0}].Seats[{1}]'|stringFormat(passenger.addonIndex, index)" :value="seat" v-for="(seat, index) in paxSeats" />
                    <input type="hidden" :name="'AddonsDetails[{0}].PaxNo'|stringFormat(passenger.addonIndex)" :value="passenger.passengerIndex" />
                </div>
            </div>
        </div>

    </div>
</template>
<script>
    import Vue from 'vue';
    import basePassenger from './basePassenger'
    export default {
        mixins: [basePassenger],
        props: ["passenger", "hasFlight", "countries", "addOnSelecteds", "seatLegs", "personalDetails", "packageQuery", "siteInfo"],
        data() {
            return {
                isCloneContactDetails: false
            }
        },
        created() {

        },
        methods: {
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            cloneContactDetails(event) {
                var formBody = $(event.target).parents('.bk-box').find('.bk-box__wrap');
                if (typeof formBody !== 'undefined' && formBody.length > 0) {
                    this.passenger.title = this.personalDetails.title;
                    this.passenger.firstName = this.personalDetails.firstName;
                    this.passenger.lastName = this.personalDetails.lastName;
                }
            }           
        }
    }
</script>
