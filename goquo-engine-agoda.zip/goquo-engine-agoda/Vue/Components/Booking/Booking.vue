﻿<template>
    <div v-if="packageQuery">
        <SessionTimeout :packageId="packageQuery.id" :secondTimeout="packageQuery.ttl"></SessionTimeout>
        <!--breadcrumb-section start-->
        <div class="content-wrap">
            <div class="container">
                <form method="POST" action="/booking/booking-now" id="frmBooking" name="bookingform" data-val="true">
                    <div class="row">
                        <input type="hidden" name="OrderId" :value="packageQuery.orderId" />
                        <div class="col-12 col-md-7 col-lg-8">
                            <div class="bk-nav">
                                <a class="bk-nav__item" :class="{'bk-nav__item--active': currentSection > SECTION_GUEST_DETAILS, 'bk-nav__item--pending': currentSection === SECTION_GUEST_DETAILS}" @click="selectSectionPassenger(SECTION_GUEST_DETAILS)">
                                    <div class="icon">
                                        <i class="icon-user"></i>
                                    </div>
                                    <div class="title" v-lang.PASSENGER_DETAILS></div>
                                </a>
                                <a class="bk-nav__item disabled" :class="{'bk-nav__item--active': currentSection > SECTION_PAYMENT, 'bk-nav__item--pending': currentSection === SECTION_PAYMENT}">
                                    <div class="icon">
                                        <i class="icon-payment"></i>
                                    </div>
                                    <div class="title" v-lang.PAYMENT></div>
                                </a>
                            </div>

                            <div class="guest-details-tab validation" v-show="currentSection === SECTION_GUEST_DETAILS">
                                <div class="bk-title">
                                    <strong v-lang.CONTACT_DETAILS></strong>
                                    <p v-lang.WHERE_SEND_BOOKING></p>
                                </div>
                                <ContactDetails v-show="currentSection === SECTION_GUEST_DETAILS" :countries="countries" :personalDetails="personalDetails"></ContactDetails>

                            </div>
                            <div class="guest-details-tab validation passenger-information hidden" v-show="currentSection === SECTION_GUEST_DETAILS">
                                <div class="bk-box__title no-border">
                                    <strong v-lang.PASSENGER_DETAILS></strong>
                                    <p v-lang.PASSENGER_NAME_MUST_MATCH_GOVERNMENT_ISSUED></p>
                                </div>
                                <div v-for="(passengers, index) in passengersGroupByRoom">
                                    <div v-if="passengersGroupByRoom.length > 1">
                                        <div class="bk-box__title">
                                            <strong v-lang.ROOM_INDEX="{0: parseInt(index) + 1}"></strong>
                                        </div>
                                    </div>
                                    <div v-for="passenger in passengers">
                                        <MainPassenger v-if="passenger.passengerType === 'Adult'" :siteInfo="siteInfo" :passenger="passenger" :countries="countries" :hasFlight="hasFlight"
                                                       :packageQuery="packageQuery" :addOnSelecteds="addOnSelecteds" :seatLegs="seatLegs" :personalDetails="personalDetails"></MainPassenger>
                                        <ChildPassenger v-if="passenger.passengerType === 'Child'" :siteInfo="siteInfo" :passenger="passenger" :countries="countries" :hasFlight="hasFlight"
                                                        :packageQuery="packageQuery" :addOnSelecteds="addOnSelecteds" :seatLegs="seatLegs"></ChildPassenger>
                                        <InfantPassenger v-if="passenger.passengerType === 'Infant'" :siteInfo="siteInfo" :passenger="passenger" :countries="countries" :hasFlight="hasFlight"
                                                         :packageQuery="packageQuery" :addOnSelecteds="addOnSelecteds" :seatLegs="seatLegs"></InfantPassenger>
                                    </div>
                                </div>
                                <a class="btn btn-md btn-primary bt-effect bt-continue" href="javascript:void(0)" @click="summaryNextSection" v-if="currentSection !== SECTION_PAYMENT" v-lang.CONTINUE></a>
                            </div>
                            <!--Page two-->
                            <div v-show="currentSection === SECTION_SEATS">
                                <!--Main Title-->
                                <div class="bk-title">
                                    <h2 class="bk-title-head">
                                        <span class="icon icon-addon"></span>
                                        <span v-lang.ADDONS></span>
                                    </h2>
                                </div>

                                <!--Baggage Details-->
                                <Baggage :packageQuery="packageQuery" :addons="addons" :addOnSelecteds="addOnSelecteds" :passengers="passengers" v-on:onAddonsChanged="calculateAddonsPrice"></Baggage>

                                <!--Seats Details-->
                                <Seats :packageQuery="packageQuery" :seatLegs="seatLegs" :seatSelecteds="seatSelecteds" :passengers="passengers" v-on:onAddonsChanged="calculateAddonsPrice"></Seats>

                                <div id="seat-modal-confirm" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
                                    <div class="modal-dialog modal-sm">
                                        <div class="modal-content">
                                            <div class="modal-body">
                                                <h5 v-lang.CONFIRM_CONTINUE_WITHOUT_SELECTING_ALL_SEATS></h5>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="text-right">
                                                    <a title="Close" class="btn btn-secondory seat-modal-close" href="javascript:;" data-dismiss="modal" v-lang.SELECT_SEAT></a>
                                                    <button type="button" @click="nextSectionWithoutSeat()" class="btn btn-success" v-lang.CONTINUE></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div v-show="currentSection === SECTION_PAYMENT" class="guest-details-tab">
                                <!--Passenger Info-->
                                <div class="bk-title"><strong v-lang.PASSENGERS></strong></div>
                                <div class="bk-box">
                                    <div class="bk-box__wrap">
                                        <div class="bk-box__passenger" v-for="passenger in passengers">
                                            <ul>
                                                <li>
                                                    <span class="ico-title"> <i :class="'icon icon-' + passenger.passengerType.toLowerCase()"></i> {{translateText(passenger.passengerType.toUpperCase(), passenger.passengerType)}}:</span>
                                                    <span>{{passenger.title}}</span>.&nbsp;
                                                    <span class="text-uppercase">{{passenger.firstName}}</span>&nbsp;
                                                    <span class="text-uppercase">{{passenger.lastName}}</span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <template v-if="product && (product.type === 'Flight_Hotel' || product.type === 'Hotel') && !isNoDataResult">
                                    <div class="bk-title">
                                        <strong v-lang.POPULAR_TOURS></strong>
                                        <p v-lang.BELOW_ARE_SOME_POPULAR_TOURS></p>
                                    </div>
                                    <div class="popular-tours">
                                        <TourResults :tours="tours.results"
                                                     :isLoadMore="false"
                                                     :tourInfor="tourInfor"
                                                     :tempDepartures="tempDepartures"
                                                     :selectedTours="selectedTours"
                                                     :packageQuery="packageQuery"
                                                     :loading="false"
                                                     :loadingFilter="false"
                                                     @onChangeDeparture="obj => changeDeparture(obj.event, obj.tour, obj.departure, obj.index)"
                                                     @onChangeTime="obj => changeTime(obj.tour, obj.index, obj.time)"
                                                     @onFilterDepartures="obj => filterDepartures(obj.event, obj.tour, obj.index)"
                                                     @onGetFullTourInfo="obj => getFullTourInfo(obj.tour)"
                                                     @onChangeActivity="obj => changeActivity(obj.tour, obj.index, obj.option)"
                                                     @onBookingTour="obj => bookingTour(obj.event, obj.tour, obj.index)"
                                                     @onOperatorDateChanged="obj => onOperatorDateChanged(obj.operatorDate, obj.tour, obj.index)"
                                                     @onChangeDeparturePointName="obj => changeDeparturePointName(obj.event, obj.tour, obj.index)"
                                                     @onChangePax="obj => changePax(obj.event, obj.paxInfo, obj.tour, obj.index)"
                                                     @onRemoveTour="obj => removeTour(obj.tour, obj.index)" />
                                        <div class="popular-tours__pagination" v-if="pagination.totalPages > 1">
                                            <button class="btn bt-effect btn-outline-primary first" type="button" @click="gotoTourPage()" v-if="greaterThanFirstPage(pagination.current)">
                                                <i class="icon icon-left-chevron"></i>
                                                <i class="icon icon-left-chevron"></i>
                                            </button>
                                            <button class="btn bt-effect btn-outline-primary" type="button" @click="gotoTourPage(pagination.current - 1)" v-if="greaterThanFirstPage(pagination.current - 1)">
                                                <i class="icon icon-left-chevron"></i>
                                            </button>
                                            <button class="btn bt-effect bt-selected" type="button" @click="gotoTourPage(pagination.current)">{{pagination.current}}</button>
                                            <button class="btn bt-effect btn-outline-primary" type="button" @click="gotoTourPage(pagination.current + 1)" v-if="lessThanTotalPages(pagination.current + 1, pagination.totalPages)">{{pagination.current + 1}}</button>
                                            <button class="btn bt-effect btn-outline-primary" type="button" @click="gotoTourPage(pagination.current + 2)" v-if="lessThanTotalPages(pagination.current + 2, pagination.totalPages)">{{pagination.current + 2}}</button>
                                            <button class="btn bt-effect btn-outline-primary" type="button" @click="gotoTourPage(pagination.current + 1)" v-if="lessThanTotalPages(pagination.current + 1, pagination.totalPages)">
                                                <i class="icon icon-right-chevron"></i>
                                            </button>
                                            <button class="btn bt-effect btn-outline-primary last" type="button" @click="gotoTourPage(pagination.totalPages)" v-if="lessThanTotalPages(pagination.current, pagination.totalPages)">
                                                <i class="icon icon-right-chevron"></i>
                                                <i class="icon icon-right-chevron"></i>
                                            </button>
                                        </div>
                                    </div>
                                </template>

                                <template v-if="product && product.type === 'Flight_Hotel' && (arrivalTransfers.length > 0 || departureTransfers.length > 0)">
                                    <div class="bk-title">
                                        <strong v-lang.SUGGESTED_TRANSFERS></strong>
                                        <p v-lang.BELOW_ARE_SOME_SUGGESTED_TRANSFERS></p>
                                    </div>
                                    <div class="popular-transfers">
                                        <div class="container nav nav-tabs" v-if="arrivalTransfers.length > 0">
                                            <a class="item-tabs-header nav-item active"
                                               data-toggle="tab" href="#tabs-arrival">
                                                <i class="icon-car"></i>
                                                <span v-lang.ARRIVAL_TRANSFER></span>
                                            </a>
                                            <a v-if="departureTransfers.length > 0" class="item-tabs-header nav-item" data-toggle="tab"
                                               href="#tabs-departure">
                                                <i class="icon-car"></i>
                                                <span v-lang.DEPARTURE_TRANSFER></span>
                                            </a>
                                        </div>
                                        <div class="content-tabs-main tab-content">
                                            <div class="content-tabs-wrap tab-pane fade active show" id="tabs-arrival" v-if="arrivalTransfers.length > 0">
                                                <TransferItem flightNumberLabel="Outbound Flight Number"
                                                              :arrivalTransfer="arrivalTransfer"
                                                              :departureTransfer="departureTransfer"
                                                              :transfers="transferPagination.arrival.transfers"
                                                              :packageQuery="packageQuery"
                                                              :hotelTransfer="packageQuery.hotels[0]"
                                                              :totalPax="totalPax"
                                                              :isArrivalTransfers="true"
                                                              :tempTransfer="tempTransfer"
                                                              :isDisabledFlightNo="true"
                                                              @onRemoveTransfer="onRemoveTransfer"
                                                              @onShowTransferPrice="onShowTransferPrice"
                                                              @onChangeNoOfVehicle="onChangeNoOfVehicle"
                                                              @onBookingTransfer="onBookingTransfer"
                                                              @onSetCancellationTransfer="setCancellationTransfer" />
                                                <div class="popular-tours__pagination" v-if="transferPagination.arrival.totalPages > 1">
                                                    <button class="btn bt-effect btn-outline-primary first" type="button" @click="goToTransferPage('arrival')" v-if="greaterThanFirstPage(transferPagination.arrival.current)">
                                                        <i class="icon icon-left-chevron"></i>
                                                        <i class="icon icon-left-chevron"></i>
                                                    </button>
                                                    <button class="btn bt-effect btn-outline-primary" type="button" @click="goToTransferPage('arrival', transferPagination.arrival.current - 1)" v-if="greaterThanFirstPage(transferPagination.arrival.current - 1)">
                                                        <i class="icon icon-left-chevron"></i>
                                                    </button>
                                                    <button class="btn bt-effect bt-selected" type="button" @click="goToTransferPage('arrival', transferPagination.arrival.current)">{{transferPagination.arrival.current}}</button>
                                                    <button class="btn bt-effect btn-outline-primary" type="button" @click="goToTransferPage('arrival', transferPagination.arrival.current + 1)" v-if="lessThanTotalPages(transferPagination.arrival.current + 1, transferPagination.arrival.totalPages)">{{transferPagination.arrival.current + 1}}</button>
                                                    <button class="btn bt-effect btn-outline-primary" type="button" @click="goToTransferPage('arrival', transferPagination.arrival.current + 2)" v-if="lessThanTotalPages(transferPagination.arrival.current + 2, transferPagination.arrival.totalPages)">{{transferPagination.arrival.current + 2}}</button>
                                                    <button class="btn bt-effect btn-outline-primary" type="button" @click="goToTransferPage('arrival', transferPagination.arrival.current + 1)" v-if="lessThanTotalPages(transferPagination.arrival.current + 1, transferPagination.arrival.totalPages)">
                                                        <i class="icon icon-right-chevron"></i>
                                                    </button>
                                                    <button class="btn bt-effect btn-outline-primary last" type="button" @click="goToTransferPage('arrival', transferPagination.arrival.totalPages)" v-if="lessThanTotalPages(transferPagination.arrival.current, transferPagination.arrival.totalPages)">
                                                        <i class="icon icon-right-chevron"></i>
                                                        <i class="icon icon-right-chevron"></i>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="content-tabs-wrap tab-pane fade" id="tabs-departure" v-if="departureTransfers.length > 0">
                                                <TransferItem flightNumberLabel="Inbound Flight Number"
                                                              :arrivalTransfer="arrivalTransfer"
                                                              :departureTransfer="departureTransfer"
                                                              :transfers="transferPagination.departure.transfers"
                                                              :packageQuery="packageQuery"
                                                              :hotelTransfer="packageQuery.hotels[0]"
                                                              :totalPax="totalPax"
                                                              :isArrivalTransfers="false"
                                                              :tempTransfer="tempTransfer"
                                                              :isDisabledFlightNo="true"
                                                              @onRemoveTransfer="onRemoveTransfer"
                                                              @onShowTransferPrice="onShowTransferPrice"
                                                              @onChangeNoOfVehicle="onChangeNoOfVehicle"
                                                              @onBookingTransfer="onBookingTransfer"
                                                              @onSetCancellationTransfer="setCancellationTransfer"/>
                                                <div class="popular-tours__pagination" v-if="transferPagination.departure.totalPages > 1">
                                                    <button class="btn bt-effect btn-outline-primary first" type="button" @click="goToTransferPage('departure')" v-if="greaterThanFirstPage(transferPagination.departure.current)">
                                                        <i class="icon icon-left-chevron"></i>
                                                        <i class="icon icon-left-chevron"></i>
                                                    </button>
                                                    <button class="btn bt-effect btn-outline-primary" type="button" @click="goToTransferPage('departure', transferPagination.departure.current - 1)" v-if="greaterThanFirstPage(transferPagination.departure.current - 1)">
                                                        <i class="icon icon-left-chevron"></i>
                                                    </button>
                                                    <button class="btn bt-effect bt-selected" type="button" @click="goToTransferPage('departure', transferPagination.departure.current)">{{transferPagination.departure.current}}</button>
                                                    <button class="btn bt-effect btn-outline-primary" type="button" @click="goToTransferPage('departure', transferPagination.departure.current + 1)" v-if="lessThanTotalPages(transferPagination.departure.current + 1, transferPagination.departure.totalPages)">{{transferPagination.departure.current + 1}}</button>
                                                    <button class="btn bt-effect btn-outline-primary" type="button" @click="goToTransferPage('departure', transferPagination.departure.current + 2)" v-if="lessThanTotalPages(transferPagination.departure.current + 2, transferPagination.departure.totalPages)">{{transferPagination.departure.current + 2}}</button>
                                                    <button class="btn bt-effect btn-outline-primary" type="button" @click="goToTransferPage('departure', transferPagination.departure.current + 1)" v-if="lessThanTotalPages(transferPagination.departure.current + 1, transferPagination.departure.totalPages)">
                                                        <i class="icon icon-right-chevron"></i>
                                                    </button>
                                                    <button class="btn bt-effect btn-outline-primary last" type="button" @click="goToTransferPage('departure', transferPagination.departure.totalPages)" v-if="lessThanTotalPages(transferPagination.departure.current, transferPagination.departure.totalPages)">
                                                        <i class="icon icon-right-chevron"></i>
                                                        <i class="icon icon-right-chevron"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </template>

                                <!--Payment Info-->
                                <Payment :paymentGateways="paymentGateways" :packageQuery="packageQuery"></Payment>

                                <template v-if="insurance">
                                    <div class="bk-title bk-insurance">
                                        <strong v-lang.PROTECT_YOUR_TRIP></strong>
                                        <p v-lang.AVOID_CHANGE_FEES></p>
                                    </div>
                                    <div class="bk-box">
                                        <div class="bk-box__wrap insurance">
                                            <div class="ruler-payment">
                                                <div class="ruler-payment__check no-border">
                                                    <div class="style-check insurance">
                                                        <input name="ApplyInsurance" id="insuranceyes" class="ipt-check" type="radio" required="required" value="true" v-model="isApplyInsurance">
                                                        <label class="ipt-label" for="insuranceyes">
                                                            <span class="box"></span>
                                                            <span class="drop-text">
                                                                <p class="main-label" v-lang.YES_ADD_PROTECTION></p>
                                                                <p class="price">
                                                                    <strong>{{packageQuery.currency}} {{insurance.price | formatCurrency}}</strong>
                                                                    <small>{{translateText('FOR', 'for')}} {{calculatePaxCount}} {{calculatePaxCount > 1 ? translateText('PEOPLE', 'people') : translateText('PERSON', 'person')}}</small>
                                                                </p>
                                                            </span>
                                                            <div class="insurance-text">
                                                                <div class="insurance-text__column insurance-text__left">
                                                                    <p v-lang.EVERYTHING_YOU_GET_WITH_CHANGE></p>
                                                                    <ul>
                                                                        <li>
                                                                            <i class="icon icon-checked"></i> {{translateText('CANCEL_FOR_COVERED_REASONS_UP_TO', 'Cancel for covered reasons up to')}}
                                                                            <ul>
                                                                                <li v-lang.FULL_REFUND_FLIGHT></li>
                                                                                <li v-lang.FULL_REFUND_HOTEL></li>
                                                                            </ul>
                                                                        </li>
                                                                        <li>
                                                                            <i class="icon icon-checked"></i> {{translateText('PLUS_247_WORLDWIDE_EMERGENCY_ASSISTANCE', 'Plus 24/7 worldwide emergency assistance')}}
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                                <div class="insurance-text__column insurance-text__right">
                                                                    <ul>
                                                                        <li>
                                                                            <i class="icon icon-checked"></i> {{translateText('PROTECT_DURING_YOUR_TRIP_UP_TO', 'Protect during your trip, up to')}}
                                                                            <ul>
                                                                                <li v-lang.FIVE_THOUSAND_FOR_MEDICAL></li>
                                                                                <li v-lang.ONE_THOUSAND_FOR_LOST_ITEMS></li>
                                                                                <li v-lang.FIVE_HUNDRED_FOR_MEALS></li>
                                                                            </ul>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                            <p class="insurance-link"><a target="_blank" href="/terms-and-conditions" v-lang.VIEWS_TERMS_AND_CONDITIONS></a></p>
                                                        </label>
                                                    </div>
                                                    <div class="style-check insurance no">
                                                        <input name="ApplyInsurance" id="insuranceno" class="ipt-check" type="radio" required="required" value="false" v-model="isApplyInsurance">
                                                        <label class="ipt-label" for="insuranceno">
                                                            <span class="box"></span>
                                                            <span class="drop-text">
                                                                <p v-lang.NO_IM_WILLING_TO_TAKE_A_RISK></p>
                                                                <p class="insurance-message failed">
                                                                    <i class="icon icon-clock"></i> <span v-lang.DONT_MISSOUT></span>
                                                                </p>
                                                            </span>
                                                            <div class="insurance-text">
                                                                <p v-lang.INSURANCE_COMMENT></p>
                                                                <p class="quote">
                                                                    <i v-lang.INSURANCE_QUOTE></i>
                                                                </p>
                                                                <p class="quote-author"><i v-lang.INSURANCE_COMMENT_AUTHOR></i></p>
                                                            </div>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </template>

                                <div class="bk-title">
                                    <strong v-lang.TERMS_AND_CONDITIONS></strong>
                                    <p v-lang.READ_AND_ACCEPT_TERMS_AND_CONDITIONS></p>
                                </div>
                                <div class="bk-box validation">
                                    <div class="bk-box__wrap">
                                        <div class="ruler-payment">
                                            <div class="ruler-payment__content scroll-hoz">
                                                <!--terms and conditions go here-->
                                            </div>
                                            <div class="ruler-payment__check" v-if="packageQuery.packageType != 'B2C'">
                                                <div class="style-check">
                                                    <input name="isShowPriceInVoucher" id="isShowPriceInVoucher" class="ipt-check" type="checkbox" data-val="true" v-model="isShowPriceInVoucher">
                                                    <label class="ipt-label" for="isShowPriceInVoucher">
                                                        <span class="box"></span>
                                                        <span class="drop-text">
                                                            {{translateText('SHOW_PRICE_SUMMARY_IN_VOUCHER', 'Show Price Summary in voucher.')}}
                                                            <span data-valmsg-replace="true" data-valmsg-for="isShowPriceInVoucher"></span>
                                                        </span>
                                                    </label>
                                                    <input type="hidden" id="ShowPriceInVoucher" name="ShowPriceInVoucher" :value="isShowPriceInVoucher" />
                                                </div>
                                            </div>
                                            <div class="ruler-payment__check no-border">
                                                <div class="style-check">
                                                    <input name="TermsAndConditions" id="rulandreg" class="ipt-check" type="checkbox" required="required" data-val="true" :data-val-mandatory="translateText('PLEASE_READ_AND_AGREE_TO_OUR_TERMS_AND_CONDITIONS', 'Please read and agree to our terms and conditions')">
                                                    <label class="ipt-label" for="rulandreg">
                                                        <span class="box"></span>
                                                        <span class="drop-text">
                                                            <span v-lang.I_HAVE_READ_AND_ACCEPT_THE_TERMS_AND_CONDITIONS="{0: clientResources ? clientResources.name : ''}"></span>
                                                            <span data-valmsg-replace="true" data-valmsg-for="TermsAndConditions"></span>
                                                        </span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="ruler-payment__check">
                                                <div class="style-check">
                                                    <input name="CancellationPolicies" id="policies" class="ipt-check" type="checkbox" required="required" data-val="true" :data-val-mandatory="translateText('PLEASE_READ_AND_AGREE_TO_OUR_CANCELLATION_POLICY', 'Please read and agree to our cancellation policy')">
                                                    <label class="ipt-label" for="policies">
                                                        <span class="box"></span>
                                                        <span class="drop-text">
                                                            <span v-lang.I_HAVE_READ_THE_CANCELLATION_POLICY></span>
                                                            <span data-valmsg-replace="true" data-valmsg-for="CancellationPolicies"></span>
                                                        </span>
                                                    </label>
                                                </div>

                                            </div>
                                            <div class="ruler-payment__check">
                                                <em class="bk-tandc-text" v-lang.PAYMENT_WILL_BE_PROCESSED_BY="{0: clientResources ? clientResources.name : '', 1: clientResources ? clientResources.bookingOwner : ''}"></em>
                                            </div>
                                        </div>
                                        <input type="hidden" id="PackageId" name="PackageId" :value="packageQuery.id" />
                                    </div>
                                </div>

                                <a href="#" @click.prevent="prevSection">&lt; <span v-lang.BACK>Back</span></a>
                                <input type="hidden" name="Checksum" :value="packageQuery.checksum" />
                                <button type="submit" id="btnBookingNow" class="btn btn-lg btn-primary bt-effect bt-continue" v-if="currentSection === SECTION_PAYMENT" v-lang.BOOK_NOW></button>
                            </div>
                            <div class="modal fade bk-modal" id="showPriceSummary" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                            <h4 class="modal-title" id="myModalLabel" v-lang.PRICE_SUMMARY>Price Summary</h4>
                                        </div>
                                        <div class="modal-body">
                                            <PriceSummary ref="priceSummary" :packageQuery="packageQuery" :addons="addOnSelecteds" :seatSelecteds="seatSelecteds" :currentSection="currentSection"></PriceSummary>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="modalCheckSum" class="modal fade">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title" v-lang.PACKAGE_CHANGED></h4>
                                        </div>
                                        <div class="modal-body text-center">
                                            {{translateText('YOUR_PACKAGE_HAS_BEEN_CHANGED', 'Your package has been changed. Please kindly review your booking and reload this page.')}}
                                        </div>
                                        <div class="modal-footer"><button type="button" class="btn btn-primary" @click="reloadPage()" v-lang.RELOAD></button></div>
                                    </div>
                                </div>
                            </div>
                            <div id="unscribeModal" class="modal fade">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-body text-center">
                                            <p>
                                                <span class="icon-checked"></span>
                                            </p>
                                            <p v-lang.YOU_WILL_BE_UNSUBSCRIBED_ONCE_YOUR_BOOKING_IS_COMPLETED></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="sidebar__togger">
                            <a class="sidebar-filter" href="javascript:void(0)" @click="togglePane('.sidebar-wrap', false)">
                                <i class="icon-filter"></i>
                                <span v-lang.BOOKING_SUMMARY></span>
                            </a>
                        </div>
                        <div class="sidebar-overlay" @click="togglePane('.sidebar-wrap, .avai-findbar-mobie', true)"></div>
                        <div class="col-12 col-md-5 col-lg-4 sidebar-wrap">
                            <div class="sidebar__navi">
                                <span v-lang.BOOKING_SUMMARY></span>
                                <div class="sidebar__navi-close" @click="togglePane('.sidebar-wrap', false)">
                                    <i class="icon-remove"></i>
                                </div>
                            </div>
                            <div :class="{'isAddon-summary': currentSection === SECTION_SEATS}">
                                <BookingSummary :packageQuery="packageQuery" :addons="addOnSelecteds" :seatSelecteds="seatSelecteds" :currentSection="currentSection" :outboundFlight="packageQuery.outboundFlight"
                                                ref="bookingSummary" v-on:onCalcPromoPrice="calcPromoPrice" @onSummaryNextSection="onSummaryNextSection" @onSetCancellationTransfer="setCancellationTransfer" :clientResources="clientResources"></BookingSummary>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="modal fade" id="modalTransferPriceBreakdown" tabindex="-1" role="dialog" aria-hidden="true" v-if="tempTransfer && (tempTransfer.transfer || tempTransfer.arrivalTransfer || tempTransfer.departureTransfer)">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body modal-body-gray npd">
                        <div class="flight-detail-title">
                            <strong v-lang.PRICE_BREAKDOWN></strong>
                            <button class="modal-close" data-dismiss="modal">
                                <i class="icon-remove"></i>
                            </button>
                        </div>
                        <div class="price-summary-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th colspan="4" v-lang.TRANSFER_PRICE></th>
                                    </tr>
                                    <tr>
                                        <th v-if="tempTransfer.isSummary" v-lang.TRANSFER_TYPE></th>
                                        <th v-else v-lang.UNITS></th>
                                        <th v-lang.PRICE_PER_UNIT></th>
                                        <th v-lang.NO_OF_VEHICLES></th>
                                        <th v-lang.TOTAL_PRICE></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <template v-if="tempTransfer.isSummary">
                                        <tr v-if="tempTransfer.arrivalTransfer">
                                            <td v-lang.ARRIVAL_TRANSFER></td>
                                            <td>{{packageQuery.currency}} {{(tempTransfer.arrivalTransfer.selectedVehicle.totalPrice / tempTransfer.arrivalTransfer.selectedVehicle.noOfVehicle) | formatCurrency}}</td>
                                            <td>{{tempTransfer.arrivalTransfer.selectedVehicle.noOfVehicle}}</td>
                                            <td>{{packageQuery.currency}} {{tempTransfer.arrivalTransfer.selectedVehicle.totalPrice | formatCurrency}}</td>
                                        </tr>
                                        <tr v-if="tempTransfer.departureTransfer">
                                            <td v-lang.DEPARTURE_TRANSFER></td>
                                            <td>{{packageQuery.currency}} {{(tempTransfer.departureTransfer.selectedVehicle.totalPrice / tempTransfer.departureTransfer.selectedVehicle.noOfVehicle) | formatCurrency}}</td>
                                            <td>{{tempTransfer.departureTransfer.selectedVehicle.noOfVehicle}}</td>
                                            <td>{{packageQuery.currency}} {{tempTransfer.departureTransfer.selectedVehicle.totalPrice | formatCurrency}}</td>
                                        </tr>
                                    </template>
                                    <template v-else>
                                        <tr>
                                            <td v-lang.PER_UNIT></td>
                                            <td>{{packageQuery.currency}} {{(tempTransfer.transfer.selectedVehicle.totalPrice / tempTransfer.transfer.selectedVehicle.noOfVehicle) | formatCurrency}}</td>
                                            <td>{{tempTransfer.transfer.selectedVehicle.noOfVehicle}}</td>
                                            <td>{{packageQuery.currency}} {{tempTransfer.transfer.selectedVehicle.totalPrice | formatCurrency}}</td>
                                        </tr>
                                    </template>
                                </tbody>
                            </table>
                            <table>
                                <thead>
                                    <template v-if="tempTransfer.isSummary">
                                        <tr>
                                            <th v-lang.TOTAL_PRICE_INCLUDES_TAXES_AND_FEES></th>
                                            <th>{{packageQuery.currency}} {{((tempTransfer.arrivalTransfer ? tempTransfer.arrivalTransfer.selectedVehicle.totalPrice : 0) + (tempTransfer.departureTransfer ? tempTransfer.departureTransfer.selectedVehicle.totalPrice : 0)) | formatCurrency}}</th>
                                        </tr>
                                    </template>
                                    <template v-else>
                                        <tr>
                                            <th v-lang.TOTAL_PRICE_INCLUDES_TAXES_AND_FEES></th>
                                            <th>{{packageQuery.currency}} {{tempTransfer.transfer.selectedVehicle.totalPrice | formatCurrency}}</th>
                                        </tr>
                                    </template>
                                </thead>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-primary bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="modalCancellationTransfer" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body modal-body-gray npd">
                        <div class="flight-detail-title">
                            <strong v-lang.CANCELLATION_POLICY></strong>
                            <button class="modal-close" data-dismiss="modal">
                                <i class="icon-remove"></i>
                            </button>
                        </div>
                        <div class="price-summary-table">
                            <div class="policies-transfer" v-if="transferCancellation.cancellationPolicies">
                                <div>
                                    <span v-if="transferCancellation.isDeparture">{{translateText('DEPARTURE_TRANSFER', 'Departure transfer')}}</span>
                                    <span v-else>{{translateText('ARRIVAL_TRANSFER', 'Arrival transfer')}}</span>
                                </div>
                                <strong class="transfer-name">{{transferCancellation.transferName}}</strong>
                                <table>
                                    <tbody>
                                        <template v-for="(cancellation, index) in transferCancellation.cancellationPolicies">
                                            <tr>
                                                <template v-if="index == 0">
                                                    <template v-if="cancellation.amount == 0">
                                                        <strong v-lang.FREE_CANCELLATION></strong>
                                                        <span v-lang.BEFORE_X="{0: setDateCancellation(cancellation.to,'DD MMM YYYY')}"></span>
                                                    </template>
                                                    <template v-else>
                                                        <strong>{{packageQuery.currency}} {{cancellation.amount | formatCurrency}} </strong>
                                                        <span v-lang.WILL_BE_CHANGED_FOR_CANCELLATION_BEFORE="{0 : setDateCancellation(cancellation.to,'DD MMM YYYY')}"></span>
                                                    </template>
                                                </template>
                                                <template v-else>
                                                    <span v-if="dateDiff(cancellation.from, cancellation.to)">
                                                        <strong>{{packageQuery.currency}} {{cancellation.amount | formatCurrency}} </strong>
                                                        <span v-lang.WILL_BE_CHANGED_FOR_CANCELLATION_FROM="{0 : setDateCancellation(cancellation.from,'DD MMM'), 1: setDateCancellation(cancellation.to,'DD MMM YYYY') }"></span>
                                                    </span>
                                                    <span v-else>
                                                        <strong>{{packageQuery.currency}} {{cancellation.amount | formatCurrency}} </strong>
                                                        <span v-lang.WILL_BE_CHANGED_FOR_CANCELLATION_ON="{0 : setDateCancellation(cancellation.from,'DD MMM YYYY') }"></span>
                                                    </span>
                                                </template>
                                            </tr>
                                            <tr>
                                                <template v-if="index == transferCancellation.cancellationPolicies.length - 1">
                                                    <span>
                                                        <strong v-lang.NONREFUNDABLE></strong> <span v-lang.AFTER="{0: setDateCancellation(cancellation.to ,'DD MMM YYYY')}"></span>
                                                    </span>
                                                </template>
                                            </tr>
                                        </template>
                                    </tbody>
                                </table>
                            </div>

                            <div class="notify" v-else>
                                <div class="freecan non-refund">
                                    <span><i class="icon-remove"></i><span v-lang.NONREFUNDABLE></span></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-primary bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<style>
</style>

<script>
    import Vue from 'vue'
    import _ from 'lodash'
    import { mapState } from 'vuex'
    import ContactDetails from './ContactDetails.vue'
    import MainPassenger from './MainPassenger.vue'
    import ChildPassenger from './ChildPassenger.vue'
    import InfantPassenger from './InfantPassenger.vue'
    import Baggage from './Baggage.vue'
    import Seats from './Seats.vue'
    import Payment from './Payment.vue'
    import BookingSummary from './BookingSummary.vue'
    import PriceSummary from './PriceSummary.vue'
    import httpQueueService from './httpQueueService'
    import SessionTimeout from '../SessionTimeout.vue'
    import TourResults from '../TourResults.vue'
    import TransferItem from '../TransferItem.vue'
    
    export default {
        mixins: [httpQueueService],
        components: {
            ContactDetails,
            MainPassenger,
            ChildPassenger,
            InfantPassenger,
            Baggage,
            Seats,
            Payment,
            BookingSummary,
            PriceSummary,
            SessionTimeout,
            TourResults,
            TransferItem
        },
        data() {
            return {
                SECTION_GUEST_DETAILS: 1,
                SECTION_SEATS: 2,
                SECTION_PAYMENT: 3,
                currentSection: 1, // Default is SECTION_GUEST_DETAILS
                packageQuery: null,
                personalDetails: null,
                passengers: [],
                countries: [],
                hasFlight: false,
                addons: {
                    seats: [],
                    baggages: {
                        departing: null,
                        returning: null
                    },
                    meals: [],
                    sportEquipments: {
                        departing: null,
                        returning: null
                    }
                },
                seatLegs: [],
                addOnSelecteds: [],
                seatSelecteds: [],
                paymentGateways: [],
                addonsLoaded: false,
                isApplyInsurance: false,
                insurance: null,
                checkSumMessage: "",
                isNoDataResult: false,
                tours: {
                    results: []
                },
                loading: {
                    bookingTransfer: false
                },
                tempDepartures: [],
                selectedTours: [],
                tourInfor: {},
                transfers: [],
                departureTransfers: [],
                arrivalTransfers: [],
                arrivalTransfer: null,
                departureTransfer: null,
                totalPax: 0,
                tempTransfer: null,
                departureDateSelected: null,
                arrivalDateSelected: null,
                isShowPriceInVoucher: false,
                pagination: {
                    current: 1,
                    toursPerPage: 3,
                    totalTours: 0,
                    totalPages: 1,
                    currentRowOnPage: 0
                }, 
                transferPagination: {
                    transferPerPage: 3,
                    departure: {
                        transfers: [],
                        current: 1,
                        totalTransfers: 0,
                        totalPages: 1
                    },
                    arrival: {
                        transfers: [],
                        current: 1,
                        totalTransfers: 0,
                        totalPages: 1
                    }
                },
                passengersGroupByRoom: [],
                transferCancellation: {
                    cancellationPolicies: null,
                    transferName: '',
                    isDeparture: false,
                },
            }
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            clientResources: state => state.workContext.clientResources,
            product: state => state.workContext.product,
            calculatePaxCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                    count += paxInfo.childCount;
                }
                return count;
            }
        }),
        watch: {
            isApplyInsurance: function () {
                this.calculateAddonsPrice(function () { });
            },
            currentSection: function () {
                // Track virtual page change

                // Only if GTM is present
                if (typeof dataLayer != 'undefined') {
                    let dataObject = {
                        virtualPagePath: '',
                        event: 'virtualPageView'
                    };
                    if (this.currentSection === 1) { // Guest
                        dataObject.virtualPagePath = document.location.pathname;
                    }
                    if (this.currentSection === 2) { // Seat selection
                        dataObject.virtualPagePath = document.location.pathname.replace('booking/',
                            'booking/seats/');
                    }
                    if (this.currentSection === 3) { // Payment page
                        dataObject.virtualPagePath = document.location.pathname.replace('booking/',
                            'booking/payment/');
                    }

                    // If valid page path then we send data to GTM
                    if (dataObject.virtualPagePath) {
                        dataLayer.push(dataObject);
                    }
                }
            }
        },
        created() {
            var packageId = $("#PackageId").val();
            var self = this;

            $.post('/package/work-context/' + packageId, function (data) {
                if (!data.packageQuery) {
                    window.location.reload();
                }
                data.baseUrl = $("#baseURL").val();

                self.totalPax = self.adults + self.childs + self.infants;

                $.getJSON(data.baseUrl + '/resources.json', function(res) {
                    data.clientResources = res;
                }).always(function() {
                    self.$store.commit('setWorkContext', data);
                    self.getWorkContext(packageId, true);
                });
            }).fail(function () {
                window.location.reload();
                });
        },
        updated() {
            $.validator.unobtrusive.parse(document);
            this.initializeMagnificPopup();
        },
        methods: {
            goToTransferPage(type, page = 1) {
                let self = this;
                let start = (page - 1) * self.transferPagination.transferPerPage;
                  switch(type) {
                      case "arrival":
                          self.transferPagination.arrival.current = page;
                          self.transferPagination.arrival.transfers = self.arrivalTransfers.slice(start, start + self.transferPagination.transferPerPage);
                          break;
                      case "departure":
                          self.transferPagination.departure.current = page;
                          self.transferPagination.departure.transfers = self.departureTransfers.slice(start, start + self.transferPagination.transferPerPage);
                          break;
                  }
            },
            lessThanTotalPages(current, totalPages) {
                return current < totalPages;  
            },
            greaterThanFirstPage(current) {
                return current > 1;  
            },
            togglePane(element, isClosed) {
                if (!isClosed) $(element).toggleClass('is-open').promise().done(function () {
                    if ($(element).hasClass('is-open')) {
                        $('.sidebar-overlay').addClass('is-active');
                        $('body').addClass('modal-open');
                    } else {
                        $('.sidebar-overlay').removeClass('is-active');
                        $('body').removeClass('modal-open');
                    }
                });
                else {
                    $(element).removeClass('is-open').promise().done(function () {
                        $('.sidebar-overlay').removeClass('is-active');
                        $('body').removeClass('modal-open');
                    });
                }
            },
            onRemoveTransfer(obj) {
                let self = this;
                let transferIndex = obj.isArrival ? self.arrivalTransfers.indexOf(obj.transfer) : self.departureTransfers.indexOf(obj.transfer);
                self.removeTransfer(null, obj.transfer, obj.transfer.selectedVehicle, transferIndex, null);
            },
            removeTransfer: function (e, transfer, vehicle, index, callback) {
                let self = this;
                vehicle.loading = true;
                transfer.selectedVehicle = vehicle;

                if (transfer.isReturnJourney) {
                    Vue.set(self.departureTransfers, index, transfer);
                }
                else {
                    Vue.set(self.arrivalTransfers, index, transfer);
                }
                self.addToQueue("/package/remove-transfer", "POST", { packageId: self.packageQuery.id, transferId: transfer.id },
                    function (data, status, xhr) {
                        var response = data;
                        if (response.success) {
                            transfer.selected = false;
                            vehicle.selected = false;
                            transfer.isExpand = false;

                            if (transfer.isReturnJourney) {
                                self.departureTransfer = null;
                                self.packageQuery.departureTransfer = null;
                            } else {
                                self.arrivalTransfer = null;
                                self.packageQuery.arrivalTransfer = null;
                            }
                            self.getPriceSummary(self.packageQuery.id);
                            if (typeof callback === "function") {
                                callback();
                            }
                        } else {
                            bootbox.dialog({
                                message: response.message,
                                buttons: {
                                    close: {
                                        label: "Close",
                                        className: "btn-danger",
                                        callback: function () {
                                        }
                                    }
                                }
                            });
                        }
                        vehicle.loading = false;
                        if (transfer.isReturnJourney) {
                            Vue.set(self.departureTransfers, index, transfer);
                        }
                        else {
                            Vue.set(self.arrivalTransfers, index, transfer);
                        }
                        // self.hasAddTransfer = false;
                    }, function (xhr, status, error) {
                        vehicle.loading = false;
                    });

            },
            bookingTransfer: function (e, transfer, vehicle, index) {
                let self = this;
                if (e) e.preventDefault();
                let form = $(e.target);
                let datePicker = form.find('.PickupDateTime');
                let isArrival = $(e.target).attr('data-arrival') ? true : false;
                if (typeof datePicker !== 'undefined' && datePicker.length > 0) {
                    let tmpPickUpTime = datePicker.find('input[name="PickUpTime"]').val();
                    let tmpPickUpDate = datePicker.find('input[name="PickUpDate"]').val();
                    if (tmpPickUpTime.toString() != tmpPickUpDate.toString()) {
                        vehicle.pickUpDate = tmpPickUpDate;
                        vehicle.pickUpTime = tmpPickUpTime;
                    }
                }

                let pickUpTime = vehicle.pickUpTime ? vehicle.pickUpTime.split(":") : [];
                if (pickUpTime && pickUpTime.length > 0) {
                    if (transfer.isReturnJourney) {
                        self.departureDateSelected = moment(vehicle.pickUpDate);
                        self.departureDateSelected.set({ hour: pickUpTime[0], minute: pickUpTime[1] });
                    }
                    else {
                        self.arrivalDateSelected = moment(vehicle.pickUpDate);
                        self.arrivalDateSelected.set({ hour: pickUpTime[0], minute: pickUpTime[1] });
                    }
                }

                if (self.arrivalDateSelected != null && self.departureDateSelected != null && self.arrivalDateSelected > self.departureDateSelected) {
                    bootbox.dialog({
                        message: self.translateText('PLEASE_SELECT_DEPARTURE_PICKUP_TIME_AFTER_ARRIVAL_PICKUP_TIME', 'Please select departure pick-up time after arrival pick-up time'),
                        buttons: {
                            close: {
                                label: "Close",
                                className: "btn-danger",
                                callback: function () {
                                }
                            }
                        }
                    });
                }
                else {
                    vehicle.loading = true;
                    transfer.selectedVehicle = vehicle

                    if (transfer.isReturnJourney) {
                        Vue.set(self.departureTransfers, index, transfer);
                    }
                    else {
                        Vue.set(self.arrivalTransfers, index, transfer);
                    }

                    if (self.hotelTransfer) {
                        vehicle.hotelName = self.hotelTransfer.name;
                    }

                    self.addToQueue("/package/booking-transfer", "POST", {
                            PackageId: self.packageQuery.id,
                            TransferId: transfer.id,
                            AirportCode: self.packageQuery.to,
                            HotelCode: vehicle.hotelCode,
                            FlightNo: vehicle.flightNo,
                            NoOfVehicle: vehicle.noOfVehicle,
                            FlightTime: vehicle.flightTime,
                            PickUpTime: vehicle.pickUpTime,
                            PickUpDate: vehicle.pickUpDate,
                            HotelName: vehicle.hotelName,
                            VehicleCode: vehicle.vehicleCode,
                            Answers: transfer.questions
                        },
                        function (data, status, xhr) {
                            var response = data;
                            if (response.success) {
                                transfer.selected = true;
                                vehicle.selected = true;
                                transfer.isExpand = true;

                                if (self.transferSelected == null) {
                                    self.transferSelected = {};
                                }
                                if (response.arrivalTransfer != null) {
                                    self.transferSelected.arrivalTransfer = response.arrivalTransfer;
                                    self.packageQuery.arrivalTransfer = response.arrivalTransfer;

                                    var arrivalPickUpTime = response.arrivalTransfer.vehicles[0].pickUpTime.split(":");
                                    self.arrivalDateSelected = moment(response.arrivalTransfer.vehicles[0].pickUpDate);
                                    self.arrivalDateSelected.set({ hour: arrivalPickUpTime[0], minute: arrivalPickUpTime[1] });
                                }
                                if (response.departureTransfer != null) {
                                    self.transferSelected.departureTransfer = response.departureTransfer;
                                    self.packageQuery.departureTransfer = response.departureTransfer;

                                    var departurePickUpTime = response.departureTransfer.vehicles[0].pickUpTime.split(":");
                                    self.departureDateSelected = moment(response.departureTransfer.vehicles[0].pickUpDate);
                                    self.departureDateSelected.set({ hour: departurePickUpTime[0], minute: departurePickUpTime[1] });
                                }
                                self.getPriceSummary(self.packageQuery.id);
                                let detail = $(".avai-transfer .fh-tabs__detail");
                                detail.collapse('hide');
                            } else {
                                bootbox.dialog({
                                    message: response.message,
                                    buttons: {
                                        close: {
                                            label: "Close",
                                            className: "btn-danger",
                                            callback: function () {
                                            }
                                        }
                                    }
                                });
                            }

                            vehicle.loading = false;
                            transfer.selectedVehicle = vehicle;

                            if (transfer.isReturnJourney) {
                                Vue.set(self.departureTransfers, index, transfer);
                            }
                            else {
                                Vue.set(self.arrivalTransfers, index, transfer);
                            }
                        }, function (xhr, status, error) {
                            vehicle.loading = false;
                        });
                }
            },
            onBookingTransfer(opt) {
                this.bookingTransfer(opt.event, opt.transfer, opt.selectedVehicle, opt.transferIndex);
            },
            setCancellationTransfer(obj) {
                let self = this;
                if (obj.isDeparture) {
                    self.transferCancellation.cancellationPolicies = self.packageQuery.departureTransfer.cancellationPolicies;
                    self.transferCancellation.transferName = self.packageQuery.departureTransfer.name;
                    self.transferCancellation.isDeparture = true;
                } else {
                    self.transferCancellation.cancellationPolicies = self.packageQuery.arrivalTransfer.cancellationPolicies;
                    self.transferCancellation.transferName = self.packageQuery.arrivalTransfer.name;
                    self.transferCancellation.isDeparture = false;
                }
            },
            setDateCancellation: function (date, convertType) {
                return moment.utc(String(date)).add(-1, 'day').format(convertType);
            },
            dateDiff(fromDate, toDate) {
                var fDate = Vue.moment(fromDate.split('T')[0]);
                var tDate = Vue.moment(toDate.split('T')[0]);

                if (tDate.diff(fDate) > 0) return true;
                return false;
            },
            onChangeNoOfVehicle(obj) {
                obj.vehicle.noOfVehicle = obj.numVehicle;
                this.changeNoOfVehicle(obj.transfer, obj.vehicle);
            },
            changeNoOfVehicle: function (transfer, vehicle) {
                var self = this;
                $.ajax("/package/transfer-calculateprice-noofvehicle", {
                    data: {
                        packageId: self.packageQuery.id,
                        transferId: transfer.id,
                        vehicleCode: vehicle.vehicleCode,
                        noOfVehicle: vehicle.noOfVehicle
                    },
                    type: "POST",
                    success: function (response) {
                        if (response.success) {
                            if (transfer.isReturnJourney) {
                                vehicle.totalPrice = response.departureTransfer.totalPrice;
                            } else {
                                vehicle.totalPrice = response.arrivalTransfer.totalPrice;
                            }
                        } else {
                            bootbox.dialog({
                                message: response.message,
                                buttons: {
                                    close: {
                                        label: "Close",
                                        className: "btn-danger",
                                        callback: function () {
                                        }
                                    }
                                }
                            });
                        }
                    },
                    error: function (request, status, error) {
                    }
                });
            },
            onShowTransferPrice(transfer) {
                this.tempTransfer = transfer;
            },
            getTransferResultsPage() {
                var self = this;
                var data = {
                    packageId: self.packageQuery.id,
                    pageIndex: 1,
                    pageSize: 500,
                    sortOrderBy: 'Price',
                    sortOrderByAsc: true
                };
                self.loading.bookingTransfer = true;
                $.ajax({
                    url: "/package/get-transfers",
                    data: data,
                    type: "POST",
                    success: function (compressed) {
                        if (compressed.transfers && compressed.transfers.length == 0) {
                            return;
                        }
                        let outboundChosen = moment(self.packageQuery.outboundFlight.arrivalDate);
                        let inboundChosen = moment(self.packageQuery.inboundFlight.departureDate);
                        let hotelChosen = self.packageQuery.hotels && self.packageQuery.hotels.length > 0 ? self.packageQuery.hotels[0] : null;
                        let departTransferSelected = self.packageQuery.departureTransfer;
                        let arrTransferSelected = self.packageQuery.arrivalTransfer;
                        self.transfers = compressed.transfers;
                        self.transfers.map(item => {
                            if (self.packageQuery.hasFlight && self.packageQuery.hasHotel && hotelChosen && item.questions && item.questions.length > 1) {
                                item.questions[0].value = hotelChosen.name;
                                item.questions[1].value = hotelChosen.addressLines;
                            }

                            if (item.questions && item.questions.length > 2) {
                                item.questions[2].value = self.packageQuery.toCityName;
                            }
                            
                            item.selectedVehicle = item.vehicles[0];
                            
                            item.arrivalDate = outboundChosen.format('YYYY-MM-DD HH:mm');
                            item.returnDate = inboundChosen.format('YYYY-MM-DD HH:mm');

                            item.vehicles.map(vehicle => {
                                vehicle.hotelCode = hotelChosen ? hotelChosen.latitude + ',' + hotelChosen.longitude : '';
                                vehicle.HotelName = hotelChosen ? hotelChosen.name : '';
                                
                               if (item.selected) {
                                   let pickUpTime = item.vehicles[0].pickUpTime.split(":");
                                   if (item.isReturnJourney) {
                                       self.departureDateSelected = moment(item.vehicles[0].pickUpDate);
                                       self.departureDateSelected.set({ hour: pickUpTime[0], minute: pickUpTime[1] });

                                   } else {
                                       self.arrivalDateSelected = moment(item.vehicles[0].pickUpDate);
                                       self.arrivalDateSelected.set({ hour: pickUpTime[0], minute: pickUpTime[1] });
                                   }
                               }
                            });

                            if (departTransferSelected && item.id === departTransferSelected.id) {
                                item.selectedVehicle.pickUpDate = departTransferSelected.vehicles[0].pickUpDate;
                                item.selectedVehicle.pickUpTime = departTransferSelected.vehicles[0].pickUpTime;
                            }

                            if (arrTransferSelected && item.id === arrTransferSelected.id) {
                                item.selectedVehicle.pickUpDate = arrTransferSelected.vehicles[0].pickUpDate;
                                item.selectedVehicle.pickUpTime = arrTransferSelected.vehicles[0].pickUpTime;
                            }
                        });
                        
                        self.departureTransfers = self.transfers.filter(function (x) { return x.isReturnJourney === true });
                        self.arrivalTransfers = self.transfers.filter(function (x) { return x.isReturnJourney === false });
                        self.transferPagination.departure.transfers = self.departureTransfers.slice(0, self.transferPagination.transferPerPage);
                        self.transferPagination.arrival.transfers = self.arrivalTransfers.slice(0, self.transferPagination.transferPerPage);

                        self.transferPagination.departure.totalTransfers = self.departureTransfers.length;
                        self.transferPagination.departure.totalPages = Math.ceil(self.transferPagination.departure.totalTransfers / self.transferPagination.transferPerPage);

                        self.transferPagination.arrival.totalTransfers = self.arrivalTransfers.length;
                        self.transferPagination.arrival.totalPages = Math.ceil(self.transferPagination.arrival.totalTransfers / self.transferPagination.transferPerPage);
                    },
                    complete: function () {
                        self.loading.bookingTransfer = false;
                    }
                });
            },
            getWorkContext(packageId, isFirstLoad = false) {
                let self = this;
                $.post('/booking/get-work-context/' + packageId, function (data) {
                    if (!data.packageQuery) {
                        window.location.reload();
                    } else {
                        $('#loading-page').addClass('hidden');
                        $('#app').removeClass('modal-open');
                    }
                    self.packageQuery = data.packageQuery;
                    self.hasFlight = data.packageQuery.outboundFlight != null;
                    self.countries = data.countries;
                    if (!self.personalDetails) {
                        self.personalDetails = data.personalDetails || {
                            title: 'Mr',
                            countryCode: data.defaultCountry || 'MY',
                            city: 'Kuala Lumpur',
                            addressLine1: 'A-7-1, NorthPoint Offices, No.1, Medan Syed Putra Utara, Mid Valley City, 59200'
                        };
                    }

                    // Populate data
                    $.ajax({
                        url: "/api/get-agent-info",
                        type: "POST",
                        xhrFields: {
                            withCredentials: true
                        },
                        success: function (data) {
                            if (data.status) {
                                self.populateData(data);
                            }
                        }
                    });

                    if (!self.passengers || self.passengers.length == 0) {
                        for (var i = 0; i < data.passengers.length; i++) {
                            var passenger = data.passengers[i];
                            passenger.nationality = passenger.nationality || data.defaultCountry || 'MY';
                            passenger.baggageDeparting = '';
                            passenger.baggageReturning = '';
                            if (self.siteInfo) {
                                switch (passenger.passengerType) {
                                    case 'Adult':
                                        passenger.title = passenger.title || 'Mr';
                                        passenger.age = self.siteInfo.adultAge;
                                        break;
                                    case 'Child':
                                        passenger.age = self.siteInfo.childAge;
                                        break;
                                    case 'Infant':
                                        passenger.title = passenger.title || 'Mstr';
                                        passenger.age = self.siteInfo.infantAge;
                                        break;
                                }
                            }
                        }
                        self.passengers = data.passengers;
                        let passengersSortByRoom = data.passengers.sort((x, y) => {
                            return x.roomIndex - y.roomIndex;
                        });
                        self.passengersGroupByRoom = _(passengersSortByRoom).groupBy("roomIndex").map((items) => items).value();
                    }

                    if (!self.paymentGateways || self.paymentGateways.length == 0) {
                        _.forEach(data.paymentGateways.sort(function (x, y) {
                            return x.paymentOrder - y.paymentOrder;
                        }), function (paymentGateway, i) {
                            i == 0 ? paymentGateway.isActive = true : paymentGateway.isActive = false;
                        })
                        self.paymentGateways = data.paymentGateways;
                    } 

                    setTimeout(function () {
                        self.attachBookingForm();
                    }, 100);

                    if (self.product && (self.product.type == 'Flight_Hotel' || self.product.type == 'Hotel')) {
                        setTimeout(function() {
                            self.getResultsPage();

                            if (self.product.type == 'Flight_Hotel') {
                                if (self.packageQuery.departureTransfer) self.departureTransfer = self.packageQuery.departureTransfer;
                                if (self.packageQuery.arrivalTransfer) self.arrivalTransfer = self.packageQuery.arrivalTransfer;

                                if (isFirstLoad) self.getTransferResultsPage();
                            }
                        }, 1000);                        
                    }
                    self.getInsurance();

                }).fail(function () {
                    window.location.reload();
                });    
            },
            initializeMagnificPopup() {
                let pics = $(".tour-results .picture");
                if (typeof pics !== 'undefined' && pics.length > 0) {
                    pics.each(function(index, item) {
                        let $element = $(item);
                        if ($element.hasClass('magnificpopup')) return;
                        let imgs = $element.attr('data-tour-images').split('|');
                        let imgsObj = [];
                        
                        if (imgs.length > 0) {
                            imgs.map(img => {
                                if (img != '') imgsObj.push({
                                    src: img
                                }) ;
                            });
                            $element.addClass('magnificpopup');
                            if ($.fn.magnificPopup) $element.magnificPopup({
                                items: imgsObj,
                                mainClass: 'mfp-with-zoom',
                                gallery: {
                                    enabled: true
                                },
                                type: 'image'
                            });
                        }
                    });
                }
            },
            changeDeparturePoint: function (tour, index) {
                var self = this;
                if (!tour.selected) {
                    tour.departureTime = '';
                }
                var departureTimes = [];
                var dailyRates = tour.dailyRates;
                var operatorDate = tour.operatorDate;
                tour.departureTimes = null;

                if (dailyRates != null) {
                    for (var i = 0; i < dailyRates.length; i++) {
                        if (operatorDate == moment(String(dailyRates[i].date)).format('YYYY-MM-DD')) {
                            var departures = dailyRates[i].departures;
                            for (var j = 0; j < departures.length; j++) {
                                var departure = departures[j];
                                if (departure.code == tour.departurePoint) {
                                    var times = departure.times;
                                    if (times) {
                                        for (var k = 0; k < times.length; k++) {
                                            departureTimes.push(times[k]);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    tour.departureTimes = departureTimes;
                    tour.departureTime = tour.departureTimes[0];
                }
                Vue.set(self.tours.results, index, tour);
            },
            changeDeparture(e, tour, departure, index) {
                this.departureChanged(tour, departure.code, departure.name);
                this.changeDeparturePoint(tour, index);
            },
            changeTime(tour, index, time) {
                var self = this;
                if (time) {
                    tour.departureTime = time;
                }
                Vue.set(self.tours.results, index, tour);
            },
            filterDepartures: _.debounce(function(e, tour) {
                let self = this;
                let target = $(e.target);
                let deptVal = target.val();
                self.tempDepartures = [];
                for (var i = 0; i < tour.departures.length; i++) {
                    if (tour.departures[i].name.includes(deptVal)) self.tempDepartures.push(tour.departures[i]);
                }
            }, 100),
            getFullTourInfo: function (tour) {
                let vm = this;
                vm.tourInfor = tour;
            },
            changeActivity: function (tour, index, option = null) {
                var self = this;
                if (option) tour.activityCode = option.code;

                if (!tour.selected) {
                    if (tour.departures != undefined && tour.departures.length > 0) {
                        this.departureChanged(tour, '', '');
                    }

                    tour.operatorDate = '';
                    tour.departures = [];
                    tour.departureTime = '';
                    tour.departureTimes = null;
                }
                var activity = null;
                for (var i = 0; i < tour.activities.length; i++) {
                    if (tour.activities[i].code == tour.activityCode) {
                        activity = tour.activities[i];
                    }
                }

                //  tour.departures
                if (activity) {
                    tour.dailyRates = activity.dailyRates;
                }
                else {
                    tour.dailyRates = tour.activities[0].dailyRates;
                }
                Vue.set(self.tours.results, index, tour);
                self.changeDailyRate(tour, index);
            },
            doBookingTour: function (tour, indexTours) {
                var self = this;
                tour.loading = true;
                $.ajax('/package/booking-tour', {
                    type: "POST",
                    data: {
                        PackageId: self.packageQuery.id,
                        TourId: tour.id,
                        OperatorDate: tour.operatorDate,
                        DeparturePoint: tour.departurePoint,
                        DepartureTime: tour.departureTime,
                        Adults: tour.adults,
                        Children: tour.children,
                        ActivityCode: tour.activityCode
                    },
                    beforeSend: function () {
                        tour.loading = true;
                    },
                    success: function (data) {
                        tour.loading = false;
                        if (data.success) {
                            tour.selected = true;
                            tour.errorMessage = null;
                            tour.price = data.price;
                            tour.gstMarkupPrice = data.gstPrice + data.price;
                            if (tour.departurePoint && tour.departurePoint.length > 0) {
                                $.each(tour.departures, function (index, item) {
                                    if (tour.departurePoint === item.code) {
                                        tour.departurePointName = item.name;
                                        return false;
                                    }
                                });
                            }
                            self.selectedTours.push(tour);
                            self.getPriceSummary(self.packageQuery.id);
                            $(".avai-tour .fh-tabs__detail").collapse('hide');
                        }
                        else {
                            Vue.set(self.tours.results, indexTours, tour);
                            if (data.message != null) {
                                bootbox.alert(data.message);
                            }
                            else {
                                bootbox.alert(self.translateText('CANNOT_ADD_THIS_ACTIVITY', 'Unable to add this tour. Kindly try again or contact us.'));
                            }
                        }
                    },
                    complete: function () {
                        tour.loading = false;
                    }
                });
                Vue.set(self.tours.results, indexTours, tour);
            },
            calchoseAdults: function () {
                var self = this;
                var choseAdults = 0;
                if (self.selectedTours) {
                    $.each(self.selectedTours, function (index, item) {
                        choseAdults += parseInt(choseAdults) + parseInt(item.adults);
                    });
                }
                return choseAdults;
            },
            validateTours(el) {
                var valid = true;
                var tmpElements = el.currentTarget.elements;
                var elements = [];
                for (var i = 0; i < tmpElements.length; i++) {
                    var field = tmpElements[i];
                    if ((field.nodeName === "INPUT" || field.nodeName === "SELECT") && $(field).attr("data-val") === 'true') {
                        if (field.value === "" || field.value === null || field.value === undefined) {
                            $(field).addClass("input-validation-error");
                            elements.push(field);
                        } else {
                            $(field).removeClass("input-validation-error");
                        }
                    }
                }

                if (elements.length > 0) {
                    valid = false;
                    $(elements[0]).focus();
                }
                return valid;
            },
            validateInput(context) {
                let parent = context.parents('.box-search');
                let label = parent.find(">strong, >.dropdown-toggle > strong");
                let labelVals = {
                    old: context.attr('data-label'),
                    new: context.attr('data-required-message')
                };

                if (!context.val()) {
                    parent.addClass('error');
                    label.text(labelVals.new);
                    return false;
                } else {
                    parent.removeClass('error');
                    label.text(labelVals.old);
                }
                return true;
            },
            onValidate(e) {
                let self = this;
                let box = $(e.target);
                let errors = 0;
                box.find("input[name='To'], input[name='DeparturePoint']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                if (errors == 0) {
                    return true;
                }
                if (e) e.preventDefault();
            },
            bookingTour(event, tour, indexTours) {
                var self = this;
                event.preventDefault();
                if (!self.onValidate(event)) return false;
                if (self.validateTours(event)) {
                    var duplicated = false;
                    tour.loading = true;
                    var choseAdults = parseInt(self.calchoseAdults()) + parseInt(tour.adults);
                    Vue.set(self.tours.results, indexTours, tour);
                    $.each(self.selectedTours, function (index, item) {
                        var departureTime = '';
                        if (item.departureTime === null) {
                            departureTime = ''
                        }
                        else {
                            departureTime = item.departureTime
                        }

                        if (tour.operatorDate === item.operatorDate.split('T')[0]) {
                            duplicated = true;
                        }
                    });

                    if (duplicated === true) {
                        bootbox.confirm({
                            message: 'Your selected date and time for this tour has overlapped with a previously selected tour. Are you sure you want to continue?',
                            buttons: {
                                confirm: {
                                    label: 'Yes',
                                    className: 'btn-danger'
                                },
                                cancel: {
                                    label: 'No',
                                    className: 'btn-secondary'
                                }
                            },
                            callback: function (result) {
                                if (result) {
                                    self.doBookingTour(tour, indexTours);
                                } else {
                                    tour.loading = false;
                                    Vue.set(self.tours.results, indexTours, tour);
                                    return;
                                }
                            }
                        });
                    } else {
                        self.doBookingTour(tour, indexTours);
                    }
                }
            },
            departureChanged(tour, code, name) {
                var vm = this;
                var $element = $(vm.$el);
                tour.departurePoint = code;
                tour.departurePointName = name;
                $element.find("input[name='DeparturePointName']").val(name);
            },
            changeDailyRate: function (tour, index) {
                let self = this;
                var dailyRates = tour.dailyRates;
                var operatorDate = tour.operatorDate ? tour.operatorDate : moment(dailyRates[0].date).format('YYYY-MM-DD');

                if (!tour.selected) {
                    if (tour.departures != undefined && tour.departures.length > 0) {
                        self.departureChanged(tour, '', '');
                    }
                    tour.departures = [];
                    tour.departureTime = '';
                    tour.departureTimes = null;
                }

                if (dailyRates != null) {
                    for (var i = 0; i < dailyRates.length; i++) {
                        if (operatorDate == moment(String(dailyRates[i].date)).format('YYYY-MM-DD')) {
                            tour.departures = dailyRates[i].departures;
                            self.tempDepartures = dailyRates[i].departures;
                        }
                    }
                }

                if (tour.departures != undefined && tour.departures.length > 0 && !tour.selected) {
                    self.departureChanged(tour, '', '');
                }
                Vue.set(self.tours.results, index, tour);
            },
            onOperatorDateChanged(operatorDate, tour, index) {
                tour.operatorDate = operatorDate;
                this.changeDailyRate(tour, index);
            },
            changeDeparturePointName(e, tour, index) {
                let self = this;
                let target = $(e.target);
                let deptVal = target.val();
                tour.departurePoint = deptVal;
                tour.departurePointName = deptVal;
                Vue.set(self.tours.results, index, tour);
            },
            getTourBreakdown: function (tour, index) {
                var self = this;
                tour.errorMessage = null;
                var adults = tour.adults;
                var children = tour.children;
                var packageId = $('#PackageId').val();

                $.ajax("/package/get-tour-breakdown", {
                    data: {
                        packageId: packageId,
                        tourId: tour.id,
                        adults: adults,
                        children: children,
                        activityCode: tour.activityCode
                    },
                    type: "POST",
                    success: function (response) {
                        var data = response;

                        if (data.success) {
                            tour.gstMarkupPrice = data.price + data.gstPrice;
                            tour.dailyRates[0].price = data.price;
                            tour.price = data.price;
                            tour.adults = data.adults;
                            tour.children = data.children;
                            tour.errorMessage = null;
                            tour.loading = false;
                            Vue.set(self.tours.results, index, tour);
                        } else {
                            tour.errorMessage = self.translateText('GET_TOUR_BREAKDOWN_ERROR', 'Get activity breakdown error.');
                            tour.loading = false;
                            Vue.set(self.tours.results, index, tour);
                        }
                    },
                    error: function () {
                        tour.loading = false;
                        Vue.set(self.tours.results, index, tour);
                    }
                });
            },
            changePax(event, paxInfo, tour, index) {
                let self = this;
                let selectedTour = self.tours.results[self.tours.results.indexOf(tour)];
                selectedTour.adults = paxInfo.adultCount;
                selectedTour.children = paxInfo.childCount;

                self.getTourBreakdown(tour, index);
            },
            getPriceSummary(packageQueryId) {
                var self = this;

                $.ajax({
                    type: "POST",
                    url: "/booking/get-price-summary",
                    data: {
                        packageId: packageQueryId,
                        promoCode: self.packageQuery.promoCode,
                        creditCardNumber: "",
                        applyInsurance: false,
                        addonDetails: []
                    },
                    success: function (data) {
                        self.priceSummary = data;
                        self.packageQuery.priceSummary = data;
                    }
                });

                self.getWorkContext(packageQueryId);
            },
            removeTour: function (tour, indexTours) {
                var self = this;
                Vue.set(self.tours.results, indexTours, tour);
                $.ajax('/package/remove-tour', {
                    type: "POST",
                    data: {
                        packageId: self.packageQuery.id,
                        tourId: tour.id
                    },
                    beforeSend: function () {
                        tour.loading = true;
                    },
                    success: function (response) {
                        var data = response;

                        if (data.success) {
                            tour.selected = false;

                            var index = self.selectedTours.indexOf(tour);
                            if (index > -1) {
                                self.selectedTours.splice(index, 1);
                            }
                            
                            self.getPriceSummary(self.packageQuery.id);
                        }
                        else {
                            bootbox.alert(data.message);
                        }
                        tour.loading = false;
                    },
                    complete: function () {
                        tour.loading = false;
                        $("input[name='DeparturePointName']").val('');
                    }
                });
            },
            getFileName: function (image) {
                var startIndex = (image.indexOf('\\') >= 0 ? image.lastIndexOf('\\') : image.lastIndexOf('/'));
                var filename = image.substring(startIndex);
                if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
                    filename = filename.substring(1);
                }
                return filename;
            },
            removeDuplicateImages: function (tours) {
                var self = this;
                $(tours).each(function (i, tour) {
                    var tmpArrFileName = [];
                    var tmpArrImages = [];
                    if (tour.images && tour.images.length > 0) {
                        $(tour.images).each(function (k, image) {
                            if (image) {
                                var fileName = self.getFileName(image);
                                if (tmpArrFileName.indexOf(fileName, 0) == -1) {
                                    tmpArrFileName.push(fileName);
                                    tmpArrImages.push(image);
                                }
                            }
                        });
                        tour.images = tmpArrImages;
                    }
                });
            },
            setThumbnailForTour: function (tours) {
                var self = this;
                $(tours).each(function (i, tour) {
                    if (tour.images.length === 0) {
                        if (tour.thumbnail) {
                            tour.images.push(tour.thumbnail);
                        }
                    }
                });
            },
            getResultsPage(newPage = 1) {
                var self = this;
                self.pagination.current = newPage;
                var data = {
                    packageId: self.packageQuery.id,
                    pageIndex: self.pagination.current,
                    pageSize: self.pagination.toursPerPage,
                    sortOrderBy: 'Priority',
                    sortOrderByAsc: true,
                    categories: []
                };
                if (!self.hasErrorMessage) {
                    $.ajax({
                        url: '/package/get-tours',
                        data: data,
                        type: 'POST',
                        beforeSend: function () {

                        },
                        success: function (response) {
                            var data = response;

                            if (data.tours.length == 0 || data.tours == null) {
                                self.isNoDataResult = true;
                            } else {
                                self.isNoDataResult = false;
                                self.removeDuplicateImages(data.tours);
                                self.setThumbnailForTour(data.tours);

                                
                                self.tours.results = data.tours;

                                self.pagination.currentRowOnPage = data.tours.length;
                                self.pagination.totalTours = data.totalTours;

                                self.pagination.totalPages = Math.ceil(data.totalTours / self.pagination.toursPerPage);

                                let toursSelected = self.packageQuery.tours;

                                if (toursSelected && toursSelected.length > 0) {
                                    self.selectedTours = [...toursSelected];
                                }

                                $(data.tours).each(function (i, tour) {
                                    if (tour.selected) {
                                        self.changeActivity(tour, i);
                                        self.changeDailyRate(tour, i);
                                        self.changeDeparturePoint(tour, i);
                                        tour.gstMarkupPrice = tour.price + tour.gstPrice;
                                    }
                                    else {
                                        tour.activityCode = tour.activities[0].code;

                                        var activity = null;
                                        for (var i = 0; i < tour.activities.length; i++) {
                                            if (tour.activities[i].code == tour.activityCode) {
                                                activity = tour.activities[i];
                                            }
                                        }

                                        if (activity) {
                                            tour.dailyRates = activity.dailyRates;
                                        }
                                        else {
                                            tour.dailyRates = tour.activities[0].dailyRates;
                                        }

                                        tour.departures = [];

                                        tour.gstMarkupPrice = tour.activities[0].dailyRates && tour.activities[0].dailyRates.length > 0 ? (tour.activities[0].dailyRates[0].price + tour.gstPrice) : (tour.price + tour.gstPrice);
                                    }
                                    let selectedActivity = tour.activities.filter(act => {
                                        return act.code === tour.activityCode;
                                    })[0];
                                    let operDate = moment(String((tour.operatorDate && tour.selected) ? tour.operatorDate : selectedActivity.dailyRates[0].date)).format('YYYY-MM-DD');
                                    tour.operatorDate = operDate;
                                });
                            }
                        },
                        complete: function () {
                            self.initializeMagnificPopup();
                        }
                    });
                }
            },
            gotoTourPage: function (page) {
                this.getResultsPage(page);
            },
            getAddons(outboundFlightFrom, inboundFlightFrom) {
                var self = this;
                if (self.addonsLoaded) {
                    return;
                }

                $("#loading-page").removeClass('hidden');

                this.addToQueue("/package/get-baggages/" + self.packageQuery.id, "post", {}, function (response) {
                    self.availabilityBaggages(response, outboundFlightFrom, inboundFlightFrom);
                });

                this.addToQueue("/package/get-meals/" + self.packageQuery.id, "post", {}, function (response) {
                    self.availabilityMeals(response);
                });

                this.addToQueue("/package/get-sport-equipments/" + self.packageQuery.id, "post", {}, function (response) {
                    self.availabilitySportEquipment(response);
                });

                this.addToQueue("/package/get-seats/" + self.packageQuery.id, "post", {
                    isOutboundFlight: true
                }, function (response) {
                    if (response) {
                        self.setSeatLegs(response, true);
                    }
                });

                this.addToQueue("/package/get-seats/" + self.packageQuery.id, "post", {
                    isOutboundFlight: false
                }, function (response) {
                    if (response) {
                        self.setSeatLegs(response, false);
                    }
                });

                this.addToQueue("/package/get-priority-checkins/" + this.packageQuery.id, "post", {}, function (
                    response) {

                    if (self.seatLegs.length === 0) {
                        self.nextSection();
                    }

                    $("#loading-page").addClass('hidden');
                });

                this.addonsLoaded = true;
            },
            selectSectionPassenger(selected) {
                if (this.seatSelecteds && this.seatSelecteds.length > 0) {
                    $.each(this.passengers, function (index, passenger) {
                        passenger.seats = {};
                    });

                    this.seatSelecteds = [];
                    this.calculateAddonsPrice(function () { });
                }

                if (selected < this.SECTION_GUEST_DETAILS) {
                    return;
                }
                this.currentSection = this.SECTION_GUEST_DETAILS;
            },
            summaryNextSection() {
                if (this.currentSection === this.SECTION_SEATS) {
                    var numberOfPaxs = this.passengers.filter(function (x) {
                        return x.passengerType !== 'Infant';
                    }).length;

                    // Without alert user to select seat
                    // var totalSeats = numberOfPaxs * this.seatLegs.length;
                    // if (!this.seatSelecteds || this.seatSelecteds.length < totalSeats) {
                    //     $("#seat-modal-confirm").modal("show");
                    //     return;
                    // }
                }
                this.nextSection();
            },
            nextSectionWithoutSeat() {
                $("#seat-modal-confirm").modal("hide");
                this.nextSection();
            },
            nextSection() {
                var self = this;
                self.trimStr();
                var valid = this.validate();
                if (!valid) {
                    return;
                }

                // If from guest details page and no flight, skip the seat selection
                if (self.currentSection === self.SECTION_GUEST_DETAILS) {
                    if (self.packageQuery.hasFlight && !self.addonsLoaded) {
                        // If FH

                        var outboundFlightFrom = self.packageQuery.outboundFlight.from;
                        var inboundFlightFrom;
                        if (self.packageQuery.inboundFlight) {
                            inboundFlightFrom = self.packageQuery.inboundFlight.from;
                        }

                        if (!self.isSelectedAirAsiaFlights()) {
                            setTimeout(function () {
                                self.currentSection = self.SECTION_PAYMENT;
                            }, 500);

                        } else {
                            self.getAddons(outboundFlightFrom, inboundFlightFrom);
                            setTimeout(function () {
                                self.currentSection = self.SECTION_SEATS
                            }, 500);
                        }

                        self.calculateAddonsPrice();
                    } else {
                        // If HO or no flights
                        self.currentSection = self.SECTION_PAYMENT;
                    }
                }
                // From other pages
                else {
                    self.currentSection++;
                }

                $("html, body").animate({
                    scrollTop: 0
                }, "nomal");
            },
            prevSection() {
                //Dont allow back on first page
                if (this.currentSection === this.SECTION_GUEST_DETAILS) {
                    return;
                }

                // If back from payment page, skip addon section if selected product doesnt have flight
                if (this.currentSection === this.SECTION_PAYMENT && (!this.packageQuery.hasFlight || this.seatLegs.length == 0)) {
                    this.currentSection = this.SECTION_GUEST_DETAILS;
                    return;
                }

                this.currentSection--;
                $("html, body").animate({
                    scrollTop: 0
                }, "nomal");
            },
            selectSectionSeat() {
                this.currentSection = this.SECTION_SEATS;
            },
            validate() {
                var valid = true;

                var fields = $(".validation input[required], select[required]");
                var elements = [];
                for (var i = 0; i < fields.length; i++) {
                    var field = fields[i];
                    if (!$(field).valid()) {
                        elements.push(field);
                    }
                }

                if (elements.length > 0) {
                    valid = false;
                    var position = $(elements[0]).offset();
                    $("html, body").animate({
                        scrollTop: position.top - 100
                    }, "500", "swing");
                    $(elements[0]).focus();
                }
                return valid;
            },
            availabilityBaggages(baggages, outboundFlightFrom, inboundFlightFrom) {
                this.updatePaxNoToNull(baggages);

                var departingBaggages = baggages.find(function (x) {
                    return x.from === outboundFlightFrom;
                });

                this.addons.baggages.departing = departingBaggages;

                if (inboundFlightFrom) {
                    var returningBaggages = baggages.find(function (x) {
                        return x.from === inboundFlightFrom;
                    });

                    this.addons.baggages.returning = returningBaggages;
                }
            },
            availabilityMeals(meals) {

            },
            availabilitySportEquipment(sportEquipments) {

            },
            updatePaxNoToNull(addons) {
                $.each(addons, function (index, item) {
                    $.each(item.addonInfoList, function (i, addon) {
                        addon.paxNo = null;
                    });
                });
            },
            setSeatLegs(response, isOutboundFlight) {
                var self = this;
                $.each(response, function (legIndex, leg) {
                    if (leg.seats && leg.seats.length > 0) {
                        self.seatsMapping(leg);

                        if (isOutboundFlight) {
                            var obsegmentDetail = self.packageQuery.outboundFlight.legs
                                .find(function (entry) {
                                    return entry.departureAirportCode === leg.from && entry.arrivalAirportCode === leg.to;
                                });

                            leg.departureCityName = obsegmentDetail ? obsegmentDetail.departureCityName : leg.from;
                            leg.arrivalCityName = obsegmentDetail ? obsegmentDetail.arrivalCityName : leg.to;
                        } else {
                            var ibsegmentDetail = self.packageQuery.inboundFlight.legs
                                .find(function (entry) {
                                    return entry.departureAirportCode === leg.from && entry.arrivalAirportCode === leg.to;
                                });

                            leg.departureCityName = ibsegmentDetail ? ibsegmentDetail.departureCityName : leg.from;
                            leg.arrivalCityName = ibsegmentDetail ? ibsegmentDetail.arrivalCityName : leg.to;
                        }

                        var flightLeg = self.findFlightLeg("outboundFlight", leg);
                        if (!flightLeg) {
                            flightLeg = self.findFlightLeg("inboundFlight", leg);
                        }

                        if (flightLeg) {
                            leg.departureDate = flightLeg.departureDate;
                            leg.arrivalDate = flightLeg.arrivalDate;
                        }

                        self.seatLegs.push(leg);
                    }
                });
            },
            seatsMapping(leg) {
                var self = this;
                leg.seatRows = [];
                $.each(leg.rows, function (rowIndex, row) {
                    var seats = [];
                    $.each(leg.columns, function (columnIndex, column) {
                        //Join Row and Column to SeatName
                        var seatName = row + column;

                        //Check SeatName exist in list Seats response
                        var seat = self.getSeatByDesignator(leg.seats, seatName);

                        //Seat existed
                        if (seat !== null && seat !== undefined) {
                            seat.selected = false;
                            seat.paxNo = -1;
                            seat.isSeat = true;
                            seat.columnIndex = columnIndex;
                            seat.rowIndex = rowIndex;

                            seats.push(seat);
                        } else {
                            seats.push({
                                isSeat: true,
                                paxNo: -1,
                                selected: false,
                                group: 0
                            });
                        }

                        //Push Corridor to array for display
                        if (columnIndex === ((leg.columns.length / 2) - 1)) {
                            seats.push({
                                isSeat: false,
                                designator: row
                            });
                        }
                    });
                    leg.seatRows.push({
                        seats: seats
                    });
                });

                //Push Corridor to array for display
                var numberSeatBothSharp = leg.columns.length / 2;
                leg.columns.splice(numberSeatBothSharp, 0, "");
            },
            getSeatByDesignator(seats, designator) {
                return seats.find(function (x) {
                    return x.designator === designator;
                });
            },
            findFlightLeg(direction, leg) {
                if (this.packageQuery[direction]) {
                    for (var i = 0; i < this.packageQuery[direction].legs.length; i++) {
                        var flightLeg = this.packageQuery[direction].legs[i];
                        if (flightLeg.departureAirportCode === leg.from && flightLeg.arrivalAirportCode === leg.to) {
                            return flightLeg;
                        }
                    }
                }

                return null;
            },
            calculateAddonsPrice(callback) {
                $("#loading-page").removeClass('hidden');
                var self = this;

                var addons = this.convertAddonsToModel();

                this.addToQueue("/booking/get-price-summary", "post", {
                    packageId: this.packageQuery.id,
                    promoCode: this.packageQuery.promoCode,
                    creditCardNumber: "",
                    applyInsurance: this.isApplyInsurance,
                    addonDetails: addons
                }, function (data) {
                    self.packageQuery.priceSummary = data;

                    if (callback) {
                        callback(data);
                    }

                    self.$refs.bookingSummary.updatePriceSummary();
                    self.$refs.priceSummary.updatePriceSummary();
                    $("#loading-page").addClass('hidden');
                }, function () {
                    window.location.reload();
                });
            },
            convertAddonsToModel() {
                var addonDetails = [];

                if (this.addOnSelecteds) {
                    var addonGroups = this.addOnSelecteds.sort(function (a, b) {
                        if (a.paxNo < b.paxNo) {
                            return -1;
                        }
                        if (a.paxNo > b.paxNo) {
                            return 1;
                        }
                        return 0;
                    }).groupBy("paxNo");

                    $.each(addonGroups, function (i, vals) {
                        var addonDetail = {
                            seats: [],
                            addons: []
                        };

                        for (var j = 0; j <= vals.length - 1; j++) {
                            var key = vals[j].from + "/" + vals[j].to + "/" + vals[j].addonType + "/" + vals[j].code;
                            addonDetail.addons.push(key);
                        }
                        addonDetails.push(addonDetail);
                    });

                    var seatGroups = this.seatSelecteds.sort(function (a, b) {
                        if (a.paxNo < b.paxNo) {
                            return -1;
                        }
                        if (a.paxNo > b.paxNo) {
                            return 1;
                        }
                        return 0;
                    }).groupBy("paxNo");

                    $.each(seatGroups, function (i, vals) {
                        var addonDetail = {
                            seats: [],
                            addons: []
                        };

                        for (var j = 0; j <= vals.length - 1; j++) {
                            var key = vals[j].from + "/" + vals[j].to + "/" + vals[j].designator;
                            addonDetail.seats.push(key);
                        }
                        addonDetails.push(addonDetail);
                    });
                }

                return addonDetails;
            },
            calcPromoPrice(callback, isClear) {
                var self = this;
                var cardNumber = $("#txtCreditCardNumber").val();
                var promoCode = $("#txtPromoCode").val();
                var addonDetails = this.convertAddonsToModel();

                $.ajax({
                    type: "POST",
                    url: "/booking/get-price-summary",
                    data: {
                        packageId: this.packageQuery.id,
                        creditCardNumber: cardNumber,
                        promoCode: isClear ? null : promoCode,
                        applyInsurance: this.isApplyInsurance,
                        addonDetails: addonDetails
                    },
                    success: function (data) {
                        self.packageQuery.priceSummary = data;
                        if (callback) {
                            callback(data);
                        }
                    }
                });
            },
            attachBookingForm() {
                var self = this;
                self.checkSumMessage = "";
                $("#frmBooking").ajaxSubmit({
                    before: function () {
                        $('#btnBookingNow').prop('disabled', true);
                        $('#loading-page').show();
                    },
                    success: function (data) {
                        if (data.success) {
                            switch (data.action) {
                                case "Alert":
                                    if (data.message && data.message.length > 0) {
                                        $('#btnBookingNow').prop('disabled', false);
                                        self.$swal(data.message)
                                        if (typeof dataLayer != 'undefined') {
                                            dataLayer.push({
                                                'event': 'errorMessage',
                                                'eventAction': 'paymentPage',
                                                'eventLabel': data.message
                                            });
                                        };
                                    }
                                    break;
                                case "Redirect":
                                    setTimeout(function () {
                                        $("#loading-page").removeClass('hidden');
                                    }, 300);
                                    postToUrl(data.redirectUrl, data.redirectValues);
                                    break;
                                case "ShowPopup":
                                    break;
                            }
                        } else {
                            if (data.message && data.message.length > 0) {
                                $('#btnBookingNow').prop('disabled', false);
                                self.checkSumMessage = data.message.split(".").join("");
                                if (data.message == 'Your package has been changed. Please kindly review your booking and reload this page.') {
                                    $('#modalCheckSum').modal('show');
                                }
                                else {
                                    self.$swal(data.message);
                                    if (typeof dataLayer != 'undefined') {
                                        dataLayer.push({
                                            'event': 'errorMessage',
                                            'eventAction': 'paymentPage',
                                            'eventLabel': data.message
                                        });
                                    };
                                }
                            }
                        }
                    },
                    complete: function () {
                        $('#page-loader').hide();
                    }
                });
            },
            hideSplashScreen() {
                $('#loading-page').addClass('hidden');
                $('#app').removeClass('modal-open');
            },
            onSummaryNextSection() {
                this.summaryNextSection();
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            reloadPage() {
                location.reload();
            },
            isSelectedAirAsiaFlights() {
                var self = this;
                var result = false;
                var airLineCodes = ["AK", "FD", "QZ", "Z2", "I5", "D7", "XJ", "XT", "DJ"];

                if (self.packageQuery.outboundFlight) {
                    result = airLineCodes.filter(x => x == self.packageQuery.outboundFlight.airlineCode).length > 0;
                }
                if (!result) {
                    return result;
                }
                if (self.packageQuery.inboundFlight) {
                    result = airLineCodes.filter(x => x == self.packageQuery.inboundFlight.airlineCode).length > 0;
                }
                return result;

            },
            trimStr() {
                var self = this;
                _.forEach(self.passengers, function (item, index) {
                    item.firstName = $.trim(item.firstName);
                    item.lastName = $.trim(item.lastName);
                })
            },
            populateData(data) {
                var self = this;
                if (!data) return;
                else {
                    var agentPortal = data;
                    let telephoneNo = "";
                    if (agentPortal.agentInfo.telephoneNo)
                        telephoneNo = agentPortal.agentInfo.telephoneNo.split(" ")[1];

                    self.personalDetails = {
                        title: "Mr",
                        firstName: agentPortal.agentInfo.agentName,
                        lastName: "Company",
                        emailAddress: agentPortal.agentInfo.emailAddress,
                        countryCode: agentPortal.agentInfo.countryCode || 'MY',
                        mobileNumber: telephoneNo,
                        city: agentPortal.agentInfo.city || 'Kuala Lumpur',
                        addressLine1: agentPortal.agentInfo.address || 'A-7-1, NorthPoint Offices, No.1, Medan Syed Putra Utara, Mid'
                    };
                }
            },
            getInsurance() {
                var self = this;
                $.ajax({
                    type: "POST",
                    url: "/booking/get-insurance",
                    data: {
                        packageId: this.packageQuery.id
                    },
                    success: function (data) {
                        if (!data.insurance)
                            console.log("Insurance is not available")
                        else 
                            self.insurance = data.insurance;
                    }
                });
            }
        }
    }
</script>
