﻿<template>
    <p class="star-rating" title="Star Rating">
        <i v-for="star in stars" :class="star" aria-hidden="true"></i>
    </p>
</template>
<script>
    export default {
        data() {
            return { stars: [] };
        },
        model: {
            prop: 'rating'
        },
        props: {
            rating: {
                type: Number,
                default: 0
            }
        },
        created() {
            this.createStars();
        },
        methods: {
            createStars: function () {
                var rating = parseFloat(this.rating);
                var min = Math.floor(rating);
                var stars = [];
                for (var i = 1; i <= min; i++) {
                    stars.push('icon icon-star star-on');
                }
                if (min < rating) {
                    stars.push('icon icon-half-star star-half');
                }
                this.stars = stars;
            }
        },
        watch: {
            rating(val) {
                this.createStars();
            }
        }
    }
</script>
<style scoped>
    .star-rating {
        display: inline-block;
    }

    .star-rating i {
        margin-right: 2px;
    }

    .star-on {
        color: #fb3;
    }

    .star-half {
        color: #fb3;
    }
</style>