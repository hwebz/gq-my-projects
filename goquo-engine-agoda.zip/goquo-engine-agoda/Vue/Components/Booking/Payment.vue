﻿<template>
    <div class="validation">
        <div class="bk-title">
            <strong v-lang.SELECT_YOUR_PAYMENT_METHOD></strong>
            <p v-lang.CHOOSE_YOUR_PAYMENT_METHOD></p>
        </div>
        <div class="bk-tabs">
            <div class="bk-tabs__header bk-tabs__header--left" v-if="paymentGateways.length > 0">
                <div class="bk-tabs__header--group nav nav-tabs">
                    <div v-if="gateways.credit.length > 0" class="bk-tabs__header__item" :class="{'active': gateways.credit[0].isActive}" href="#severals-credit-card" data-toggle="tab" role="tab" @click="choicePayment('credit card')">
                        <span v-lang.CREDIT_CARD></span>
                        <div class="icon">
                            <i class="icon-payment"></i>
                        </div>
                    </div>
                    <div v-if="gateways.onaccount.length > 0" class="bk-tabs__header__item" :class="{'active': gateways.onaccount[0].isActive}" href="#severals-on-account" data-toggle="tab" role="tab" @click="choicePayment('on account')">
                        <span v-lang.ON_ACCOUNT></span>
                        <div class="icon">
                            <i class="icon-payment"></i>
                        </div>
                    </div>
                    <div v-if="gateways.internetbanking.length > 0" class="bk-tabs__header__item" :class="{'active': gateways.internetbanking[0].isActive}" href="#severals-internetbanking" data-toggle="tab" role="tab" @click="choicePayment('internet banking')">
                        <span v-lang.INTERNET_BANKING></span>
                        <div class="icon">
                            <i class="icon-payment"></i>
                        </div>
                    </div>
                    <div v-if="gateways.offlinePayment.length > 0" class="bk-tabs__header__item" :class="{'active': gateways.offlinePayment[0].isActive}" href="#severals-offline-payment" data-toggle="tab" role="tab" @click="choicePayment('offline payment')">
                        <span v-lang.OFFLINE_PAYMENT></span>
                        <div class="icon">
                            <i class="icon-payment"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bk-tabs__content tab-content">
                <template v-if="paymentGateways.length == 0">
                    <p class="no-margin" v-lang.THERE_ARE_NO_PAYMENT_METHOD_FOUND></p>
                </template>
                <template v-else>
                    <div id="severals-credit-card" class="tab-pane" :class="{'active show': gateways.credit[0].isActive}" v-if="gateways.credit.length > 0">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="mtr-input">
                                        <input class="mtr-ipt card-name text-uppercase" id="txtCreditCardName" name="CreditCardName" v-on:keypress="inputOnlyCharacter" type="text" required maxlength="50" data-val="true" data-num="false"
                                               :data-val-required="translateText('REQUIRED_FIELD', 'Required field')"
                                               :data-val-regex="translateText('PLEASE_NOT_ALL_SPACES', 'Please not all space')" data-val-regex-pattern="(?!^ +$)^.+$"
                                               tabindex="1" autocomplete="cc-name">
                                        <span class="mtr-text" v-lang.NAME_ON_CARD></span>
                                        <span class="mtr-bar"></span>
                                        <small class="mtr-notify" data-valmsg-replace="true" data-valmsg-for="CreditCardName"></small>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="mtr-input">
                                        <input class="mtr-ipt card-serial" type="text" maxlength="19" data-num="true" id="CreditCardNumberDisplay" name="CreditCardNumberDisplay"
                                               v-model="cardInfos.number"
                                               :data-val-required="translateText('REQUIRED_FIELD', 'Required field')"
                                               data-val="true"
                                               :data-val-regex="translateText('PLEASE_ENTER_VALID_CARD_NUMBER')"
                                               data-val-regex-pattern="^([0-9]{4}\s{1}[0-9]{4}\s{1}[0-9]{4}\s{1}[0-9]{4})$"
                                               placeholder="XXXX-XXXX-XXXX-XXXX" required tabindex="2" autocomplete="cc-number" v-on:keypress="inputOnlyNumberic">
                                        <input type="hidden" name="CreditCardNumber" id="txtCreditCardNumber" />
                                        <span class="mtr-text" v-lang.CARD_NUMBER></span>
                                        <span class="mtr-bar"></span>
                                        <small class="mtr-notify" data-valmsg-replace="true" data-valmsg-for="CreditCardNumberDisplay"></small>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="row">
                                            <div class="col-md-6 mtr-input-date ">
                                                <div class="form-group">
                                                    <div class="mtr-input">
                                                        <select id="txtCreditCardExpireMonth" name="CreditCardExpireMonth" class="mtr-ipt" data-val="true" :data-val-required="translateText('REQUIRED_FIELD', 'Required field')"
                                                                tabindex="4" autocomplete="cc-exp-month">
                                                            <option value="" v-lang.MONTH></option>
                                                            <option value="1">01</option>
                                                            <option value="2">02</option>
                                                            <option value="3">03</option>
                                                            <option value="4">04</option>
                                                            <option value="5">05</option>
                                                            <option value="6">06</option>
                                                            <option value="7">07</option>
                                                            <option value="8">08</option>
                                                            <option value="9">09</option>
                                                            <option value="10">10</option>
                                                            <option value="11">11</option>
                                                            <option value="12">12</option>
                                                        </select>
                                                        <span class="mtr-text" v-lang.MONTH></span>
                                                        <span class="mtr-bar"></span>
                                                        <span class="mtr-notify" data-valmsg-replace="true" data-valmsg-for="CreditCardExpireMonth"></span>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="col-md-6 mtr-input-date ">
                                                <div class="form-group">
                                                    <div class="mtr-input">
                                                        <select id="txtCreditCardExpireYear" name="CreditCardExpireYear" class="mtr-ipt" data-val="true" :data-val-required="translateText('REQUIRED_FIELD', 'Required field')"
                                                                tabindex="5" autocomplete="cc-exp-year" data-rule-ccexp="true">
                                                            <option value="" v-lang.YEAR></option>
                                                            <option v-for="year in years" :value="year">{{year}}</option>
                                                        </select>
                                                        <span class="mtr-text" v-lang.YEAR></span>
                                                        <span class="mtr-bar"></span>
                                                        <span class="mtr-notify" data-valmsg-replace="true" data-valmsg-for="CreditCardExpireYear"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group ">
                                            <div class="mtr-input">
                                                <input class="mtr-ipt card-ccv" type="text" maxlength="3" placeholder="XXX" name="CreditCardCvvCode" onkeypress="return event.charCode >= 0 && event.charCode <= 999"
                                                       id="txtCreditCardCvvCode" minlength="3" data-num="true"
                                                       data-val="true" :data-val-required="translateText('REQUIRED_FIELD', 'Required field')" required tabindex="3"
                                                       autocomplete="cc-csc" v-on:keypress="inputOnlyNumberic">
                                                <span class="mtr-text" v-lang.CVV></span>
                                                <span class="mtr-bar"></span>
                                                <small class="mtr-notify" data-valmsg-replace="true" data-valmsg-for="CreditCardCvvCode"></small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="image-card">
                                    <div class="card__payment">
                                        <div class="front">
                                            <div class="type">
                                                <img class="bankid" src="" alt="">
                                            </div>
                                            <span class="chip"></span>
                                            <span class="card_number">
                                                &#x25CF;&#x25CF;&#x25CF;&#x25CF; &#x25CF;&#x25CF;&#x25CF;&#x25CF; &#x25CF;&#x25CF;&#x25CF;&#x25CF;
                                                &#x25CF;&#x25CF;&#x25CF;&#x25CF;
                                            </span>
                                            <div class="date">
                                                <span class="date_value">
                                                    <span class="date_value_month"></span>/
                                                    <span class="date_value_year"></span>
                                                </span>
                                            </div>
                                            <span class="fullname text-uppercase" v-lang.FULL_NAME></span>
                                        </div>
                                        <div class="back">
                                            <div class="magnetic"></div>
                                            <div class="bar"></div>
                                            <span class="seccode">&#x25CF;&#x25CF;&#x25CF;</span>
                                            <span class="chip"></span>
                                            <span class="disclaimer" v-lang.THIS_CARD_IS_PROPERTY_OF_BANK></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="severals-offline-payment" class="tab-pane" :class="{'active in': gateways.offlinePayment[0].isActive}" v-if="gateways.offlinePayment.length > 0">
                        <div class="row">
                            <div class="col-xs-6 col-sm-6 col-md-6">
                                <div class="row">
                                    <div class="form-group col-xs-6 col-sm-6 col-md-6" v-for="paymentGateway in gateways.offlinePayment">
                                        <label class="radio-inline radio-box">
                                            <input type="radio" :value="paymentGateway" v-model="selectedPayment" />
                                            <span v-if="paymentGateway.urlImage"><img class="img-payment-ali" :src="paymentGateway.urlImage"></span>
                                            <span v-else="">{{paymentGateway.paymentName}}</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <!--<div class="col-xs-6 col-sm-6 col-md-6" v-if="isShow && selectedPayment && selectedPayment.category == 'Offline Payment'">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>{{paymentReferenceName}}</label><em>*</em>
                                            <input v-model="paymentReference" type="text" class="form-control text-uppercase" id="txtPaymentReference" maxlength="255" name="PaymentReference" data-val="true" :data-val-required="translateText('REQUIRED', 'Required')" required="required" tabindex="1" />
                                            <span data-valmsg-replace="true" data-valmsg-for="PaymentReference"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>-->
                        </div>
                    </div>
                    <div id="severals-on-account" class="tab-pane" :class="{'active in': gateways.onaccount[0].isActive}" v-if="gateways.onaccount.length > 0">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group col-xs-12 col-sm-12 col-md-12">
                                            <label class="radio-inline radio-box">
                                                <input type="radio" value="1" v-model="onAccountSelected" />
                                                <span v-lang.ON_ACCOUNT_X="{0: balanceInfo}"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <input v-if="selectedPayment" type="hidden" :value="selectedPayment.id" name="PaymentGatewayId" autocomplete="off" tabindex="1" />
                </template>
            </div>
        </div>
    </div>
</template>
<script>
export default {
        props: ["paymentGateways", "packageQuery"],
        data() {
            return {
                paymentCategory: 'credit card',
                years: [],
                balanceInfo: "",
                paymentReference: null,
                isReadonly: false,
                gateways: {
                    credit: [],
                    internetbanking: [],
                    offlinePayment: [],
                    onaccount: []
                },
                cardInfos: {
                    number: null,
                    name: null,
                    ccv: null,
                    expire: {
                        month: null,
                        year: null
                    }
                },
                selectedPayment: {},
                paymentReferenceName: "EYEMD Number",
                customerCreditNumber: null,
                readOnly: false,
                isShow: false,
                firstLoad: true,
                onAccountSelected: 1
            }
        },
        created() {
            var self = this;
            var start = new Date().getFullYear();
            var end = start + 15;
            for (var i = start; i <= end; i++) {
                this.years.push(i);
            }
            var currency = self.packageQuery.currency;

            $.ajax({
                type: "POST",
                url: "/booking/get-payment-options/" + currency,
                success: function (data) {
                    if (data && data.length > 0) {
                        self.balanceInfo = data[0].displayName;
                    }
                }
            });
        },
        mounted() {
            //Geeting card type based on the cardnumber value
            var _cardNumber = $('.cc-number');
            var _mastercard = $('.mastercard');
            var _visa = $('.visa');
            var cardType;

            var self = this;

            _cardNumber.keyup(function (event) {
                _visa.addClass('cc-iconhide');
                _mastercard.addClass('cc-iconhide');
                cardType = self.creditCardTypeFromNumber(_cardNumber.val());
                if (cardType === "mastercard") {
                    _mastercard.removeClass('cc-iconhide');
                } else if (cardType === "visa") {
                    _visa.removeClass('cc-iconhide');
                }
            });

            for (var i = 0; i < this.paymentGateways.length; i++) {

                if (this.paymentGateways[i].isActive) {
                    this.selectedPayment = this.paymentGateways[i];
                }
                switch (this.paymentGateways[i].category.toLowerCase()) {
                    case 'credit card':
                        this.gateways.credit.push(this.paymentGateways[i]);
                        break;
                    case 'internet banking':
                        this.gateways.internetbanking.push(this.paymentGateways[i]);
                        break;
                    case 'offline payment':
                        this.gateways.offlinePayment.push(this.paymentGateways[i]);
                        break;
                    case 'on account':
                        this.gateways.onaccount.push(this.paymentGateways[i]);
                        break;
                }
            }

        },
        updated(){
            if(this.firstLoad){
                this.cardEffect();
                this.firstLoad = false;
            }
        },

        methods: {
            creditCardTypeFromNumber(num) {
                num = num.replace(/[^\d]/g, '');
                if (num.match(/^5\d{3}/)) {
                    return 'mastercard';
                } else if (num.match(/^4\d{3}/)) {
                    return 'visa';
                }
                return 'NULL';
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            inputOnlyNumberic: function (event) {
                if ((event.which < 48 || event.which > 57)) {
                    event.preventDefault();
                }
            },
            inputOnlyCharacter: function (event) {
                if (!(event.which >= 65 && event.which <= 122) && (event.which != 32 && event.which != 0)) {
                    event.preventDefault();
                }
            },
            cardEffect: function () {
                var self = this;
                var cards = [{
                    nome: "mastercard",
                    colore: "#0061A8",
                    src: "https://upload.wikimedia.org/wikipedia/commons/0/04/Mastercard-logo.png"
                }, {
                    nome: "visa",
                    colore: "#E2CB38",
                    src: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/2000px-Visa_Inc._logo.svg.png"
                }, {
                    nome: "dinersclub",
                    colore: "#888",
                    src: "http://www.worldsultimatetravels.com/wp-content/uploads/2016/07/Diners-Club-Logo-1920x512.png"
                }, {
                    nome: "americanExpress",
                    colore: "#108168",
                    src: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/American_Express_logo.svg/600px-American_Express_logo.svg.png"
                }, {
                    nome: "discover",
                    colore: "#86B8CF",
                    src: "https://lendedu.com/wp-content/uploads/2016/03/discover-it-for-students-credit-card.jpg"
                }, {
                    nome: "dankort",
                    colore: "#0061A8",
                    src: "https://upload.wikimedia.org/wikipedia/commons/5/51/Dankort_logo.png"
                }];

                var month = 0;
                var html = document.getElementsByTagName('html')[0];
                var number = "";

                var selected_card = -1;

                $(document).click(function (e) {
                    if (!$(e.target).is(".card-ccv") || !$(e.target).closest(".card-ccv").length) {
                        $(".card__payment").css("transform", "rotatey(0deg)");
                        $(".seccode").css("color", "var(--text-color)");
                    }
                    if (!$(e.target).is(".card-expire") || !$(e.target).closest(".card-expire").length) {
                        $(".date_value").css("color", "var(--text-color)");
                    }
                    if (!$(e.target).is(".card-serial") || !$(e.target).closest(".card-serial").length) {
                        $(".card_number").css("color", "var(--text-color)");
                    }
                    if (!$(e.target).is(".card-name") || !$(e.target).closest(".card-name").length) {
                        $(".fullname").css("color", "var(--text-color)");
                    }
                });


                //Card number input
                $(".card-serial").keyup(function (event) {
                    $(".card_number").text($(this).val());
                    number = $(this).val();

                    if (parseInt(number.substring(0, 2)) > 50 && parseInt(number.substring(0, 2)) < 56) {
                        selected_card = 0;
                    } else if (parseInt(number.substring(0, 1)) == 4) {
                        selected_card = 1;
                    } else if (parseInt(number.substring(0, 2)) == 36 || parseInt(number.substring(0, 2)) ==
                        38 || parseInt(number.substring(0, 2)) == 39) {
                        selected_card = 2;
                    } else if (parseInt(number.substring(0, 2)) == 34 || parseInt(number.substring(0, 2)) ==
                        37) {
                        selected_card = 3;
                    } else if (parseInt(number.substring(0, 2)) == 65) {
                        selected_card = 4;
                    } else if (parseInt(number.substring(0, 4)) == 5019) {
                        selected_card = 5;
                    } else {
                        selected_card = -1;
                    }

                    if (selected_card != -1) {
                        html.setAttribute("style", "--card-color: " + cards[selected_card].colore);
                        $(".bankid").attr("src", cards[selected_card].src).show();
                    } else {
                        html.setAttribute("style", "--card-color: #cecece");
                        $(".bankid").attr("src", "").hide();
                    }

                    if ($(".card_number").text().length === 0) {
                        $(".card_number").html(
                            "&#x25CF;&#x25CF;&#x25CF;&#x25CF; &#x25CF;&#x25CF;&#x25CF;&#x25CF; &#x25CF;&#x25CF;&#x25CF;&#x25CF; &#x25CF;&#x25CF;&#x25CF;&#x25CF;"
                        );
                    }
                }).on("keydown input focus", function (event) {
                    $(".card_number").css("color", "white");
                    let _this = $(this), parts = [], strFormat = "";
                    let value = _this.val().replace(/\s+/g, '');

                    for (let i = 0; i < value.length; i += 4)
                        parts.push(value.substring(i, i + 4));

                    if (parts.length > 0) {
                        for (let i = 0; i < parts.length; i++) {
                            if (i == parts.length - 1)
                                strFormat += parts[i];
                            else
                                strFormat += parts[i] + " ";
                        }
                    }
                    $(".card-serial").val(strFormat);
                    $(".cc-number").val(strFormat);
                    $("#txtCreditCardNumber").val(strFormat);
                    self.cardInfos.number = strFormat;
                })

                //Name Input
                $(".card-name").keyup(function () {
                    $(".fullname").text($(this).val());
                    if ($(".card-name").val().length === 0) {
                        $(".fullname").text("FULL NAME");
                    }
                    return event.charCode;
                }).focus(function () {
                    $(".fullname").css("color", "white");
                });
                $("#txtCreditCardExpireMonth").change(function () {
                    var cardMonth = $("#txtCreditCardExpireMonth").val()
                    $(".date_value_month").html(cardMonth);
                })
                $("#txtCreditCardExpireYear").change(function () {
                    var cardYear = $("#txtCreditCardExpireYear").val()
                    $(".date_value_year").html(cardYear);
                })
                $(".date_value").focusout(function () {
                    $(".date_value").css("color", "var(--text-color)");
                });
                //Security code Input
                $(".card-ccv").focus(function () {
                    $(".card__payment").css("transform", "rotatey(180deg)");
                    $(".seccode").css("color", "white");
                }).keyup(function () {
                    $(".seccode").text($(this).val());
                    if ($(this).val().length === 0) {
                        $(".seccode").html("&#x25CF;&#x25CF;&#x25CF;");
                    }
                }).focusout(function () {
                    $(".card__payment").css("transform", "rotatey(0deg)");
                    $(".seccode").css("color", "var(--text-color)");
                });
            },
            choicePayment(method) {
                var self = this;

                _.forEach(this.paymentGateways, function (val, i) {
                    if (val.category == self.capitalizeStr(method)) {
                        val.isActive = true;
                    } else val.isActive = false;
                })
                var selectedPayment = $.grep(this.paymentGateways, function (x) {
                    return x.isActive;
                })
                this.selectedPayment = selectedPayment[0];

                this.paymentCategory = method;

            },
            formatCurrencyOnAccount(value) {
                return (parseFloat(value).toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            },

            checkEquivalent(currencyConvert, b2bCurrency) {
                if (currencyConvert == b2bCurrency)
                    return true;
                else
                    return false;
            },
            capitalizeStr(str) {
                var regex = /\b[a-z]/g;
                str = str.toLowerCase().replace(regex, function (letter) {
                    return letter.toUpperCase();
                });
                return str;
            }
        }
    }
</script>
