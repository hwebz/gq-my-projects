﻿export default {
    data() {
        return {
            paxSeats: []
        };
    },
    methods: {
        parseAddonModel(paxNo) {
            var results = [];
            var addons = this.getSelectedAddonsByPax(paxNo);

            if (addons == undefined || addons.length === 0)
                return results;

            for (var i = 0; i < addons.length; i++) {
                results.push(addons[i].from + "/" + addons[i].to + "/" + addons[i].addonType + "/" + addons[i].code);
            }
            return results;
        },
        parseSeatModel() {
            var results = [];
            var seats = this.getSelectedSeatsByPax();
            for (var i = 0; i < seats.length; i++) {
                results.push(seats[i].from + "/" + seats[i].to + "/" + seats[i].designator);
            }
            return results;
        },
        getSelectedAddonsByPax(index) {
            var arr = [];
            var addons = this.addOnSelecteds.filter(function (x) { return x.paxNo === index });

            for (var j = 0; j < this.seatLegs.length; j++) {
                var pc = this.seatLegs[j].currentPriorityCheckin;
                if (pc && pc.enabled) {
                    if (index === 0) {
                        arr.push(pc);
                    } else {
                        var checkin = this.getPriorityCheckinByCode(this.legs[j], "XCK0");
                        if (checkin) {
                            arr.push(checkin);
                        }
                    }
                }
            }

            return addons;
        },
        getSelectedSeatsByPax() {
            if (!this.passenger.seats) return [];

            var seats = [];
            
            for (var legKey in this.passenger.seats) {
                if (this.passenger.seats.hasOwnProperty(legKey)) {
                    var s = this.passenger.seats[legKey];
                    if (typeof s === "object") {
                        if (s) {
                            seats.push(s);
                        }
                    }
                }
            }
            return seats;
        },
        getPriorityCheckinByCode(legs, code) {
            return legs.priorityCheckin.addonInfoList.find(function (x) { return x.code === code });
        },
        trimSpace(value, type) {
            var self = this;
            switch (type.toLowerCase()) {
            case "firstname":
                self.passenger.firstName = $.trim(value);
                break;
            case "lastname":
                self.passenger.lastName = $.trim(value);
                break;
            }
        }
    },
    watch: {
        "passenger.seats": function() {
            this.paxSeats = this.parseSeatModel();
        }
    }
};