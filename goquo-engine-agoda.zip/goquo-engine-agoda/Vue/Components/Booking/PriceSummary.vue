﻿<template>
    <div class="sidebar-control">
        <div class="siderbar-detail">
            <ul>
                <li v-if="packageQuery.hasFlight && packageQuery.hasHotel">
                    <span v-lang.PACKAGE_PRICE></span>
                    <span class="right">
                            {{packageQuery.currency}}
                            {{formatPrice(packageQuery.priceSummary.packagePrice)}}
                        </span>
                </li>
                <li v-if="!packageQuery.hasHotel && packageQuery.priceSummary.flightPrice">
                    <span v-lang.FLIGHT_PRICE></span>
                    <span class="right">
                            {{packageQuery.currency}} 
                            {{formatPrice(packageQuery.priceSummary.flightPrice) }}
                        </span>
                </li>
                <li v-if="!packageQuery.hasFlight && packageQuery.hasHotel">
                    <span v-lang.HOTEL_PRICE></span>
                    <span class="right">
                            {{packageQuery.currency}} 
                            {{formatPrice(packageQuery.priceSummary.hotelPrice) }}
                        </span>
                </li>
                <li v-for="group in baggageSummary">
                    <span v-lang.CHECKED_BAGGAGE_X="{0: group.addon.name}"></span>
                    <span class="right">
                            {{packageQuery.currency}}
                            {{formatPrice(group.price)}}
                        </span>
                </li>
                <li v-if="sportSummary.length > 0">
                    <span v-lang.SPORTS_EQUIPMENT></span>
                    <span class="right">
                            {{packageQuery.currency}}
                            {{formatPrice(sportSummary.sum('price')) }}
                        </span>
                </li>
                <li v-for="group in mealSummary">
                    <span>{{group.addon.name}}</span>
                    <span class="right">
                            {{packageQuery.currency}}
                            {{formatPrice(group.price) }}
                        </span>
                </li>
                <li v-for="group in seatSummary">
                    <span v-if="isBusinessClass(group.seat.cabinClass)" v-lang.BUSINESS_SEAT></span>
                    <span v-if="!isBusinessClass(group.seat.cabinClass) && group.seat.name.indexOf('COOL') !== -1" v-lang.COOL_SEAT></span>
                    <span v-if="!isBusinessClass(group.seat.cabinClass) && group.seat.name.indexOf('COOL') === -1" v-lang.STANDARD_SEAT></span>
                    <span class="right">
                            {{packageQuery.currency}}
                            {{formatPrice(group.price) }}
                        </span>
                </li>
                <li v-if="priorityCheckinPrice">
                    <span v-lang.PRIORITY_CHECKIN></span>
                    <span class="right">
                            {{packageQuery.currency}}
                            {{formatPrice(priorityCheckinPrice) }}
                        </span>
                </li>
                <li v-if="packageQuery.priceSummary.taxesAndFees > 0">
                    <span v-lang.TAXES_FEES></span>
                    <span class="right">
                            {{packageQuery.currency}}
                            {{formatPrice(packageQuery.priceSummary.taxesAndFees) }}
                        </span>
                </li>
                <li v-if="packageQuery.priceSummary.toursPrice > 0">
                    <span v-lang.TOUR_PRICE></span>
                    <span class="right">
                            {{packageQuery.currency}}
                            {{formatPrice(packageQuery.priceSummary.toursPrice) }}
                        </span>
                </li>
                <li v-if="packageQuery.priceSummary.transfersPrice > 0">
                    <span v-lang.TRANSFER_PRICE></span>
                    <span class="right">
                            {{packageQuery.currency}}
                            {{formatPrice(packageQuery.priceSummary.transfersPrice)}}
                        </span>
                </li>
                <li v-if="packageQuery.priceSummary.insurancePrice > 0">
                    <span v-lang.INSURANCE_PRICE></span>
                    <span class="right">
                            {{packageQuery.currency}}
                            {{formatPrice(packageQuery.priceSummary.insurancePrice)}}
                        </span>
                </li>
                <li v-if="packageQuery.priceSummary.promoPrice > 0">
                    <span v-lang.COUPON_APPLIED></span>
                    <span class="right">
                            - {{packageQuery.currency}} 
                            {{formatPrice(packageQuery.priceSummary.promoPrice) }}
                        </span>
                </li>
                <li v-if="packageQuery.priceSummary.gstPrice > 0">
                    <span v-lang.GST></span>
                    <span class="right">
                            {{packageQuery.currency}} 
                            {{formatPrice(packageQuery.priceSummary.gstPrice) }}
                        </span>
                </li>
                <li v-if="packageQuery.priceSummary.otherChargeMarkupPrice > 0">
                    <span v-lang.SERVICE_CHARGE></span>
                    <span class="right">
                            {{packageQuery.currency}} 
                            {{formatPrice(packageQuery.priceSummary.otherChargeMarkupPrice) }}
                        </span>
                </li>
                <li class="hightline">
                    <span v-if="packageQuery.hasFlight && packageQuery.hasHotel || (packageQuery.hasHotel && packageQuery.hasTour)" v-lang.TOTAL_PACKAGE_PRICE></span>
                    <span v-if="!packageQuery.hasFlight && packageQuery.hasHotel && !packageQuery.hasTour" v-lang.TOTAL_HOTEL_PRICE></span>
                    <span v-if="packageQuery.hasFlight && !packageQuery.hasHotel" v-lang.TOTAL_FLIGHT_PRICE></span>
                    <span v-if="packageQuery.hasTour && !packageQuery.hasFlight && !packageQuery.hasHotel" v-lang.TOTAL_TOUR_PRICE></span>
                    <span v-if="packageQuery.hasTransfer && !packageQuery.hasFlight && !packageQuery.hasHotel" v-lang.TOTAL_TRANSFER_PRICE></span>
                    <span class="right">
                        {{packageQuery.currency}} 
                       {{formatPrice(packageQuery.priceSummary.totalPrice) }}
                    </span>
                </li>
            </ul>
        </div>
        <!-- <div class="sidebar-total">
            <small>Total Hotel Price</small>
            <strong>{{packageQuery.currency}} {{formatPrice(packageQuery.priceSummary.totalPrice) }}</strong>
            <span>Inclusive of taxes and fees</span>
        </div> -->
        <div class="siderbar-promo" v-if="currentSection === 1 && packageQuery.priceSummary.priceChanged > 0">
            <span></span>
            <span v-lang.PLEASE_NOTE_THAT_YOUR_PRICE_HAS_CHANGED="{0: packageQuery.currency, 1: formatPrice(packageQuery.priceSummary.oldTotalPrice), 2: packageQuery.currency, 3: formatPrice(packageQuery.priceSummary.totalPrice)}"></span>
        </div>
        <!--<div class="sidebar-ruler" v-if="packageQuery.hasHotel">-->
            <!--<a v-if="!minHotelCancellationDate" id="btnCancellationPolicy1" href="javascript:void(0)" v-tooltip.top="'This booking is non-refundable and cannot be amended or modified. Failure to arrive at your hotel will be treated as a no-show and no refund will be given (Hotel policy).'" class="alert-msg">-->
                <!--<span>Low rate (non-refundable)</span>-->
            <!--</a>-->
            <!--<a v-else id="btnCancellationPolicy2" href="javascript:void(0)" class="alert-msg" v-tooltip.top="'Cancellation on this room is absolutely free if made before ' + minHotelCancellationDate">-->
                <!--<span>Free cancellation before</span> {{minHotelCancellationDate}}-->
            <!--</a>-->
        <!--</div>-->
        <!--<a class="bt-sidebar btn btn-lg btn-block btn-primary bt-effect" href="javascript:void(0)" @click="onSummaryNextSection" v-if="currentSection !== SECTION_PAYMENT">CONTINUE</a>-->
        <!--<button type="submit" class="bt-sidebar btn btn-lg btn-block btn-primary bt-effect" v-if="currentSection === SECTION_PAYMENT">-->
            <!--BOOK NOW-->
        <!--</button>-->
    </div>
</template>
<script>
    import Vue from 'vue';
    
    export default {
        props: ["packageQuery", "addons", "seatSelecteds", "currentSection", "hello"],
        data() {
            return {
                SECTION_GUEST_DETAILS: 1,
                SECTION_SEATS: 2,
                SECTION_PAYMENT: 3,
                baggageSummary: [],
                seatSummary: [],
                sportSummary: [],
                mealSummary: [],
                priorityCheckinPrice: null,
                minHotelCancellationDate: null
            }
        },
        created() {
            this.updatePriceSummary();
            
            if (!this.packageQuery.hasFlight && this.packageQuery.hotels && this.packageQuery.hotels.length > 0) {
                var hotel = this.packageQuery.hotels[0];
                var minHotelCancellationDate = null;
                var nonRefundable = false;
                for (var i = 0; i < hotel.availableRooms.length; i++) {
                    var cancelFreeBeforeDate = hotel.availableRooms[i].availableRoomTypes[0].cancelFreeBeforeDate;
                    if (cancelFreeBeforeDate) {
                        if (!minHotelCancellationDate) {
                            minHotelCancellationDate = cancelFreeBeforeDate;
                        } else {
                            var oldDate = new Date(minHotelCancellationDate);
                            var newDate = new Date(cancelFreeBeforeDate);
                            if (newDate < oldDate) {
                                minHotelCancellationDate = cancelFreeBeforeDate;
                            }
                        }
                    } else {
                        nonRefundable = true;
                    }
                }

                if (minHotelCancellationDate && !nonRefundable) {
                    this.minHotelCancellationDate = Vue.moment(minHotelCancellationDate).format('DD/MM/YYYY');
                }
            }
        },
        methods: {
            updatePriceSummary() {
                this.baggageSummary = this.getAddonSummary(1);
                this.seatSummary = this.getSeatSummary();
            },
            isBusinessClass(cabinClass) {
                return (cabinClass === 2 || cabinClass === 3 || cabinClass === 6);
            },
            getAddonSummary(type) {
                var addons = this.getAddonByType(type);
                if (addons && addons.length === 0)
                    return [];

                var groups = [];
                if (type === 1) {
                    groups = this.groupBy(addons, "name");
                } else {
                    groups = this.groupBy(addons, "code");
                }

                var summary = {
                    details: []
                };

                for (var i = 0; i < groups.length; i++) {
                    var g = groups[i];
                    summary.details.push({
                        code: g.key,
                        price: this.sum(g.items, function (a) { return a.feeDetail.totalPrice; }),
                        addon: g.items[0]
                    });
                }
                return summary.details;
            },
            getAddonByType(type) {
                var addOnsByType = [];
                var arrAddons = [];
                for (var i = 0; i < this.addons.length; i++) {
                    if (this.addons[i].addonType === type) {
                        addOnsByType.push(this.addons[i]);
                    }
                }
                return addOnsByType;
            },
            getSeatSummary() {
                if (this.seatSelecteds.length == 0) {
                    return [];
                }

                var summary = {
                    details: []
                };

                var groups = this.groupBy(this.seatSelecteds, "group");
                for (var i = 0; i < groups.length; i++) {
                    var g = groups[i];
                    summary.details.push({
                        code: g.key,
                        price: this.sum(g.items, function (a) { return a.feeAmount; }),
                        seat: g.items[0]
                    });
                }
                return summary.details;
            },
            groupBy(arr, fieldName) {
                var groups = [];
                if (arr) {
                    for (var i = 0; i < arr.length; i++) {
                        var item = arr[i];
                        var existGroup = this.firstOrDefault(groups, function (g) { return g.key === item[fieldName] });
                        if (existGroup == null) {
                            var newGroup = {
                                key: item[fieldName],
                                items: [item]
                            };
                            groups.push(newGroup);
                        } else {
                            existGroup.items.push(item);
                        }
                    }
                }

                return groups;
            },
            onSummaryNextSection() {

            },
            firstOrDefault(arr, condition) {
                if (arr) {
                    for (var i = 0; i < arr.length; i++) {
                        if (condition(arr[i]))
                            return arr[i];
                    }
                }
                return null;
            },
            sum(arr, calc) {
                var totals = 0;
                for (var i = 0; i < arr.length; i++) {
                    totals += calc(arr[i]);
                }

                // To fixed number
                return parseFloat(totals.toFixed(this.packageQuery.currencyDecimals));
            },
            onSummaryNextSection() {
                this.$emit('onSummaryNextSection');
            },
            formatPrice(price) {
                return (price.toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',')
            }
        }
    }
</script>
