﻿<template>
    <div class="bk-box">
        <input type="hidden" :value="passenger.passengerType" :name="'Passengers[{0}].PassengerType'|stringFormat(passenger.passengerIndex)">
        <input type="hidden" :value="'Passengers[{0}].'|stringFormat(passenger.passengerIndex)" :name="'Passengers[{0}].ModelPrefix'|stringFormat(passenger.passengerIndex)">
        <input type="hidden" :value="passenger.roomIndex" :name="'Passengers[{0}].RoomIndex'|stringFormat(passenger.passengerIndex)">
        <div class="bk-box__title">
            <strong>
                <span v-lang.PASSENGER></span> {{passenger.passengerIndex + 1}} - <span v-lang.INFANT></span>
            </strong>
                <p  v-lang.INFANT_AGE_POLICY></p>
        </div>
        <div class="bk-box__wrap">
            <div class="form-group">
                <span>
                    <small v-lang.TITLE></small>
                    <div class="radio-pure-box">
                        <div class="radio-pure" v-bind:class="{'active': passenger.title === 'Mstr'}">
                            <input type="radio" :id="'C-Mstr'+passenger.passengerIndex" :name="'Passengers[{0}].Title'|stringFormat(passenger.passengerIndex)" value="Mstr" v-model="passenger.title">
                            <label :for="'C-Mstr'+passenger.passengerIndex" v-lang.TITLE_MASTER></label>
                        </div>
                        <div class="radio-pure" v-bind:class="{'active': passenger.title === 'Miss'}">
                            <input type="radio" :id="'C-Miss'+passenger.passengerIndex" :name="'Passengers[{0}].Title'|stringFormat(passenger.passengerIndex)" value="Miss" v-model="passenger.title">
                            <label  :for="'C-Miss'+passenger.passengerIndex" v-lang.TITLE_MISS></label>
                        </div>
                    </div>
                </span>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <div class="mtr-input">
                            <input class="mtr-ipt placeH-sm text-uppercase" type="text" :name="'Passengers[{0}].FirstName'|stringFormat(passenger.passengerIndex)" :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                                   required="required" data-val="true" v-model="passenger.firstName" :data-val-lettersonly="translateText('PLEASE_ENTER_LETTERS_ONLY', 'Please enter letters only.')"
                                   :data-val-regex="translateText('PLEASE_NOT_ALL_SPACES', 'Please not all space')"
                                   data-val-regex-pattern="(?!^ +$)^.+$"
                                   maxlength="26"
                                   v-on:blur="trimSpace(passenger.firstName, 'firstname')">
                            <span class="mtr-text" v-lang.FIRST_MIDDLE_NAMES>First & Middle Name(s)</span>
                            <span class="mtr-bar"></span>
                            <small class="mtr-notify" data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].FirstName'|stringFormat(passenger.passengerIndex)"></small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <div class="mtr-input">
                            <input class="mtr-ipt placeH-sm text-uppercase" type="text" :name="'Passengers[{0}].LastName'|stringFormat(passenger.passengerIndex)" :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                                   required="required" data-val="true" v-model="passenger.lastName" :data-val-lettersonly="translateText('PLEASE_ENTER_LETTERS_ONLY', 'Please enter letters only.')"
                                   :data-val-regex="translateText('PLEASE_NOT_ALL_SPACES', 'Please not all space')"
                                   data-val-regex-pattern="(?!^ +$)^.+$"
                                   maxlength="26"
                                   v-on:blur="trimSpace(passenger.lastName, 'lastName')">
                            <span class="mtr-text" v-lang.LAST_NAME>Last Name</span>
                            <span class="mtr-bar"></span>
                            <small class="mtr-notify" data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].LastName'|stringFormat(passenger.passengerIndex)"></small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <div class="mtr-input">
                            <select autocomplete="given-name" class="mtr-ipt" type="text" :name="'Passengers[{0}].Nationality'|stringFormat(passenger.passengerIndex)" :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                                    data-val="true" v-model="passenger.nationality" required>
                                <option value="" v-lang.SELECT_COUNTRY></option>
                                <option :value="country.code" v-for="country in countries">{{country.name}}</option>
                            </select>
                            <span class="mtr-text" v-lang.NATIONALITY></span>
                            <span class="mtr-bar"></span>
                            <small class="mtr-notify" data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].Nationality'|stringFormat(passenger.passengerIndex)"></small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <div class="mtr-input mtr-mutil-select show-error">
                            <div class="row">
                                <div class="col-4 mtr-input-date">
                                    <select :name="'Passengers[{0}].DayOfBirth'|stringFormat(passenger.passengerIndex)" :data-val-required="translateText('ENTER_DATE', 'Enter date')"
                                            data-val="true" required="required" class="mtr-ipt" autocomplete="bday-day" v-model="dob.day" @change="validateExpireDateEvent($event, '.validatedDOBDate')">
                                        <option value="" v-lang.DATE></option>
                                        <option v-for="day in days" :value="day">{{day}}</option>
                                    </select>
                                    <small class="mtr-notify" data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].DayOfBirth'|stringFormat(passenger.passengerIndex)"></small>

                                </div>
                                <div class="col-4 mtr-input-date">
                                    <select :name="'Passengers[{0}].MonthOfBirth'|stringFormat(passenger.passengerIndex)" :data-val-required="translateText('ENTER_MONTH', 'Enter month')"
                                            data-val="true" required="required" class="mtr-ipt" autocomplete="bday-month" v-model="dob.month" @change="validateExpireDateEvent($event, '.validatedDOBDate')">
                                        <option value="" v-lang.MONTH></option>
                                        <option v-for="month in months" :value="month">{{month}}</option>
                                    </select>
                                    <small class="mtr-notify" data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].MonthOfBirth'|stringFormat(passenger.passengerIndex)"></small>
                                </div>
                                <div class="col-4 mtr-input-date">
                                    <select :name="'Passengers[{0}].YearOfBirth'|stringFormat(passenger.passengerIndex)" :data-val-required="translateText('ENTER_YEAR', 'Enter year')"
                                            data-val="true" required="required" class="mtr-ipt" autocomplete="bday-year" v-model="dob.year" @change="validateExpireDateEvent($event, '.validatedDOBDate')">
                                        <option value="" v-lang.YEAR></option>
                                        <option v-for="year in years" :value="year">{{year}}</option>
                                    </select>
                                    <small class="mtr-notify" data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].YearOfBirth'|stringFormat(passenger.passengerIndex)"></small>
                                </div>
                            </div>
                            <span class="mtr-text" v-lang.DATE_OF_BIRTH></span>
                            <input class="mtr-ipt placeH-sm text-uppercase hidden-field validatedDOBDate" type="text" :name="'Passengers[{0}].FullExpireDate'|stringFormat(passenger.passengerIndex)"
                                   required="required" data-val="true" :data-val-required="translateText('INFANT_AGE_VALIDATION_MESSAGE', '')"
                                   :value="tempDate.dob ? tempDate.dob.year + '-' + tempDate.dob.month + '-' + tempDate.dob.day : ''">
                            <small class="mtr-notify field-validation-error">
                                <span v-lang.INFANT_AGE_VALIDATION_MESSAGE></span>
                            </small>
                        </div>
                    </div>
                </div>
                <!--<template v-if="hasFlight && packageQuery.isInternationalFlight">
                    <div class="col-md-6">
                        <div class="form-group">
                            <div class="mtr-input">
                                <input class="mtr-ipt placeH-sm text-uppercase" type="text" :name="'Passengers[{0}].PassportNo'|stringFormat(passenger.passengerIndex)" :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                                       required="required" data-val="true"
                                       v-model="passenger.passportNo"
                                       maxlength="11" data-val-regex="Invalid passport number"
                                       data-val-regex-pattern="^(([0-9]{8,9})|([a-zA-Z]{1}[0-9]{7,8})|([a-zA-Z]{1}[0-9]{10})|([a-zA-Z]{2}[0-9]{7}))$">
                                <span class="mtr-text" v-lang.PASSPORT_NO>Passport No</span>
                                <span class="mtr-bar"></span>
                                <small class="mtr-notify" data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].PassportNo'|stringFormat(passenger.passengerIndex)"></small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <div class="mtr-input mtr-mutil-select show-error">
                                <div class="row">
                                    <div class="col-4 mtr-input-date">
                                        <select :name="'Passengers[{0}].DayOfExpiryDate'|stringFormat(passenger.passengerIndex)" :data-val-required="translateText('ENTER_DATE', 'Enter date')"
                                                v-model="expireDate.day" data-val="true" required="required" class="mtr-ipt" autocomplete="bday-day" @change="validateExpireDateEvent($event, '.validatedExpireDate')">
                                            <option value="" v-lang.DATE>Date</option>
                                            <option v-for="day in days" :value="day">{{day}}</option>
                                        </select>
                                        <small class="mtr-notify" data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].DayOfExpiryDate'|stringFormat(passenger.passengerIndex)"></small>
                                    </div>
                                    <div class="col-4 mtr-input-date">
                                        <select :name="'Passengers[{0}].MonthOfExpiryDate'|stringFormat(passenger.passengerIndex)" :data-val-required="translateText('ENTER_MONTH', 'Enter month')"
                                                v-model="expireDate.month" data-val="true" required="required" class="mtr-ipt" autocomplete="bday-month" @change="validateExpireDateEvent($event, '.validatedExpireDate')">
                                            <option value="" v-lang.MONTH>Month</option>
                                            <option v-for="month in months" :value="month">{{month}}</option>
                                        </select>
                                        <small class="mtr-notify" data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].MonthOfExpiryDate'|stringFormat(passenger.passengerIndex)"></small>
                                    </div>
                                    <div class="col-4 mtr-input-date">
                                        <select :name="'Passengers[{0}].YearOfExpiryDate'|stringFormat(passenger.passengerIndex)" :data-val-required="translateText('ENTER_YEAR', 'Enter year')"
                                                v-model="expireDate.year" data-val="true" required="required" class="mtr-ipt" autocomplete="bday-year" @change="validateExpireDateEvent($event, '.validatedExpireDate')">
                                            <option value="" v-lang.YEAR>Year</option>
                                            <option v-for="year in expireYears" :value="year">{{year}}</option>
                                        </select>
                                        <small class="mtr-notify" data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].YearOfExpiryDate'|stringFormat(passenger.passengerIndex)"></small>
                                    </div>
                                </div>
                                <span class="mtr-text">Expiry Date</span>
                                <input class="mtr-ipt placeH-sm text-uppercase hidden-field validatedExpireDate" type="text" :name="'Passengers[{0}].FullExpireDate'|stringFormat(passenger.passengerIndex)"
                                       required="required" data-val="true" data-val-required="Please enter a valid expiry date"
                                       :value="tempDate.expireDate ? tempDate.expireDate.year + '-' + tempDate.expireDate.month + '-' + tempDate.expireDate.day : ''">
                                <small class="mtr-notify field-validation-error">
                                    <span v-lang.PLEASE_ENTER_VALID_EXPIRE_DATE></span>
                                </small>
                            </div>
                        </div>
                    </div>
                </template>-->
            </div>
            <div class="row" v-if="hasFlight">
                <div class="col-xs-12 col-md-6">
                    <div class="form-group">
                        <div class="mtr-input">
                            <input class="mtr-ipt" autocomplete="off" data-val="true" type="text" maxlength="11" minlength="11" :name="'Passengers[{0}].FrequentFlyerNumber'|stringFormat(passenger.passengerIndex)"
                                :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')" v-model="passenger.frequentFlyerNumber"
                                style="margin-top: 5px;" :data-val-regex="translateText('INVALID_FORMAT', 'Invalid Format')" />
                            <span class="mtr-text"><span v-lang.MILES_FREQUENT_FLYER_NUMBER="{0: siteInfo.name}"></span>
                                <small v-lang.OPTIONAL></small>
                            </span>
                            <span class="mtr-bar"></span>
                            <small class="mtr-notify" data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].FrequentFlyerNumber'|stringFormat(passenger.passengerIndex)"></small>
                        </div>
                    </div>
                </div>
                <input type="hidden" :name="'Passengers[{0}].PassportNo'|stringFormat(passenger.passengerIndex)" :value="'C12312312' + passenger.passengerIndex">
                <input type="hidden" :name="'Passengers[{0}].DayOfExpiryDate'|stringFormat(passenger.passengerIndex)" value="17" />
                <input type="hidden" :name="'Passengers[{0}].MonthOfExpiryDate'|stringFormat(passenger.passengerIndex)" value="04" />
                <input type="hidden" :name="'Passengers[{0}].YearOfExpiryDate'|stringFormat(passenger.passengerIndex)" value="2028" />
                <input type="hidden" :name="'Passengers[{0}].PassportIssueCountry'|stringFormat(passenger.passengerIndex)" value="VN" />
                <input type="hidden" :name="'AddonsDetails[{0}].Addons[{1}]'|stringFormat(passenger.addonIndex, index)" :value="addon" v-for="(addon, index) in parseAddonModel(passenger.passengerIndex)" />
                <input type="hidden" :name="'AddonsDetails[{0}].Seats[{1}]'|stringFormat(passenger.addonIndex, index)" :value="seat" v-for="(seat, index) in paxSeats" />
                <input type="hidden" :name="'AddonsDetails[{0}].PaxNo'|stringFormat(passenger.addonIndex)" :value="passenger.passengerIndex" />
            </div>
        </div>
    </div>


</template>
<script>
    import Vue from 'vue';
    import basePassenger from './basePassenger'
    export default {
        mixins: [basePassenger],
        props: ["passenger", "countries", "hasFlight", "addOnSelecteds", "seatLegs", "packageQuery", "siteInfo"],
        data() {
            return {
                days: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
                    27, 28, 29, 30, 31
                ],
                months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
                years: [],
                expireYears: [],
                expireDate: {
                    day: null,
                    month: null,
                    year: null
                },
                dob: {
                    day: null,
                    month: null,
                    year: null
                },
                tempDate: {
                    expireDate: {
                        day: 1,
                        month: 1,
                        year: 1900
                    },
                    dob: {
                        day: 1,
                        month: 1,
                        year: 1900
                    }
                }
            }
        },
        created() {
            var end = new Date(this.passenger.maxBirthDate);
            var start = new Date(this.passenger.minBirthDate);
            for (var i = end.getFullYear(); i >= start.getFullYear(); i--) {
                this.years.push(i);
            }

            var returnDate = new Date(this.packageQuery.returnDate);
            returnDate = returnDate.getFullYear();
            for (var i = returnDate; i <= returnDate + 15; i++) {
                this.expireYears.push(i);
            }

            if (this.passenger.dateOfBirth) {
                var dateOfBirth = new Date(this.passenger.dateOfBirth);
                this.dob.day = dateOfBirth.getDate();
                this.dob.month = dateOfBirth.getMonth();
                this.dob.year = dateOfBirth.getFullYear();
            }

            if (this.passenger.passportExpiryDate) {
                var expireDate = new Date(this.passenger.passportExpiryDate);
                this.expireDate.day = expireDate.getDate();
                this.expireDate.month = expireDate.getMonth();
                this.expireDate.year = expireDate.getFullYear();
            }
            this.passenger.title = 'Mstr';
        },
        mounted() {
            if (this.passenger.dateOfBirth) {
                var dob = new Date(this.passenger.dateOfBirth);
                var day = dob.getDate();
                var month = this.months[dob.getMonth()];
                var year = dob.getFullYear();
                $('[name="Passengers[' + this.passenger.passengerIndex + '].DayOfBirth"]').val(day);
                $('[name="Passengers[' + this.passenger.passengerIndex + '].MonthOfBirth"]').val(month);
                $('[name="Passengers[' + this.passenger.passengerIndex + '].YearOfBirth"]').val(year);
            }
        },
        methods: {
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            validateDate(day, month, year, context, selector) {
                let validateMessage = context.parents('.mtr-input').find(selector);
                var minDate = Vue.moment(this.passenger.minBirthDate);
                var maxDate = Vue.moment(this.passenger.maxBirthDate);
                var returnDate = Vue.moment(this.packageQuery.returnDate ? this.packageQuery.returnDate : this.packageQuery.departureDate);
                var selectedDate = Vue.moment(year + "-" + (month >= 10 ? month : '0' + month) + "-" + (day >= 10 ? day : '0' + day) + 'T00:00:00Z');
                var isInvalidExpireDate = returnDate.diff(selectedDate) > 0;
                var isInvalidDOBDate = selectedDate.diff(minDate) < 0 || selectedDate.diff(maxDate) > 0;

                if (day && month && year) {
                    switch (selector) {
                        case '.validatedDOBDate':
                            if (isInvalidDOBDate) {
                                this.tempDate.dob = null;
                                validateMessage.addClass('input-validation-error');
                            } else {
                                this.tempDate.dob = {
                                    day: day,
                                    month: month,
                                    year: year,
                                }
                                validateMessage.removeClass('input-validation-error');
                            }
                            break;
                        case '.validatedExpireDate':
                            if (isInvalidExpireDate) {
                                this.tempDate.expireDate = null;
                                validateMessage.addClass('input-validation-error');
                            } else {
                                this.tempDate.expireDate = {
                                    day: day,
                                    month: month,
                                    year: year,
                                }
                                validateMessage.removeClass('input-validation-error');
                            }
                            break;
                    }
                }
            },
            validateExpireDateEvent(e, selector) {
                let $this = $(e.target);
                let now = new Date();
                let eD = this.expireDate;
                let dob = this.dob;
                switch (selector) {
                    case '.validatedDOBDate':
                        this.validateDate(dob.day > 0 ? dob.day : null, dob.month > 0 ? dob.month : null, dob.year > 0 ? dob.year : null, $this, selector);
                        break;
                    case '.validatedExpireDate':
                        this.validateDate(eD.day > 0 ? eD.day : null, eD.month > 0 ? eD.month : null, eD.year > 0 ? eD.year : null, $this, selector);
                        break;
                }
            }
        }
    }
</script>
