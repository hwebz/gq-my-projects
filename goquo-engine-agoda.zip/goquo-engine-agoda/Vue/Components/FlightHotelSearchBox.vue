<template>
    <div>
        <form method="GET" action="/package/start-search" @submit="onValidate">
            <div class="search-grid flight-hotel-box" :class="{'part-stay': model.partialStay}">
                <div class="part-of-my-stay">
                    <DateRangePicker v-model="defaultDate" date-format="DD/MM/YYYY" v-if="model.partialStay" :endDate="model.returnDate" :startDate="model.departureDate" isMyTrip="true" />
                    <div class="reasons">
                        <h4 v-lang.THE_REASONS_WHY_YOU_CHOOSE_THE_HOTEL></h4>
                        <ul v-lang.PART_OF_MY_STAY_DESCRIPTION></ul>
                    </div>
                </div>
                <AjaxSelect name="From"
                            :placeholder="translateText('PLEASE_INPUT_AIRPORT', 'Please input airport or city name')"
                            :txtLabel="translateText('FROM', 'From')"
                            :defaultValue="from"
                            :defaultText="fromCityName"
                            icon="ico icon-location-arrow"
                            :accepted="true"
                            :url="'/api/get-global-airports'"
                            :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_SOURCE', 'Please choose a valid source')"
                            data-selected="true" />
                <AjaxSelect name="To"
                            :placeholder="translateText('PLEASE_INPUT_AIRPORT', 'Please input airport or city name')"
                            :txtLabel="translateText('TO', 'To')"
                            :defaultValue="to"
                            :defaultText="toCityName"
                            icon="ico icon-map-marker"
                            :accepted="true"
                            :url="'/api/get-global-airports'"
                            :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_DESTINATION', 'Please choose a valid destination')"
                            data-selected="true" />
                <DateRangePicker v-model="defaultDate" journeyType="1" date-format="DD/MM/YYYY" data-selected="true" @onChangeDateTime="onChangeDateTime" isChange="true" />
                <PaxSelector :maxRooms="3" data-selected="true" :isFlightHotel="true" />
                <CabinClass :cabinClass="cabinClass" :uniqueId="clientResources.uniqueId" />
            </div>
            <div class="part-of-my-stay-landing">
                <div class="search-grid search-grid-my-trip">
                    <div class="check-box-part-of-my-stay">
                        <input type="checkbox" id="part-of-my-stay" v-model="model.partialStay">
                        <label for="part-of-my-stay" v-lang.NEED_HOTEL_PART_STAY></label>
                    </div>
                </div>
            </div>
            <div class="search-button-wrap">
                <input type="hidden" name="OrderId" :value="packageQuery && packageQuery.orderId ? packageQuery.orderId : ''">
                <input type="hidden" name="Currency" :value="packageQuery && packageQuery.currency ? packageQuery.currency : 'USD'">
                <input type="hidden" name="JourneyType" value="1">
                <input type="hidden" name="ProductId" :value="product.id" />
                <button type="submit" class="bt-search bt-effect">
                    <span class="text-uppercase" v-lang.SEARCH_FLIGHT_HOTEL></span>
                </button>
            </div>
        </form>
    </div>
</template>

<script>
    import Vue from 'vue'
    import AjaxSelect from './AjaxSelect.vue'
    import DateRangePicker from './DateRangePicker.vue'
    import PaxSelector from "./PaxSelector.vue"
    import CabinClass from './CabinClass.vue'

    export default {
        data() {
            return {
                maxRooms: 3,
                PartialStay: false,
                DepartureDate: null,
                ReturnDate: null,
                model: {
                    partialStay: false,
                    returnDate: null,
                    departureDate: null
                },
                currency: "",
                defaultCurrency: "USD",
                uniqueId: null
            }
        },
        created() {
            var selectedDate = this.defaultDate.split(',');

            if (selectedDate && selectedDate.length > 1) {
                this.model.departureDate = new Date(selectedDate[0]);
                this.model.returnDate = new Date(selectedDate[1]);
            }
            if (this.packageQuery) {
                this.currency = this.packageQuery.currency;
            }
        },
        methods: {
            translateText(translateKey, defaultText, params) {
                return this.translate(this.$language, translateKey, params) || defaultText;
            },
            validateInput(context) {
                var parent = context.parents('.box-search');
                var label = parent.find(">strong");
                var labelVals = {
                    old: context.attr('data-label'),
                    new: context.attr('data-required-message')
                };

                if (!context.val()) {
                    parent.addClass('error');
                    label.text(labelVals.new);
                    return false;
                } else {
                    parent.removeClass('error');
                    label.text(labelVals.old);
                }
                return true;
            },
            onValidate(e) {
                var self = this;
                var box = $(self.$el)
                var errors = 0;
                box.find("input[name='From']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                box.find("input[name='To']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                if (errors == 0) {
                    return true;
                }
                if (e) e.preventDefault();
            },
            onChangeDateTime() {
                var self = this;
                var box = $(self.$el);
                var departureDate = box.find("input[name = 'DepartureDate']").val();
                var returnDate = box.find("input[name = 'ReturnDate']").val();
                if (departureDate && returnDate) {
                    self.model.departureDate = Vue.moment(departureDate).format('MM/DD/YYYY');
                    self.model.returnDate = Vue.moment(returnDate).format('MM/DD/YYYY');
                }
            },
        },
        props: ['product', 'defaultDate', 'from', 'fromCityName', 'to', 'toCityName', 'cabinClass', 'packageQuery', 'siteInfo', 'clientResources'],
        components: { PaxSelector, DateRangePicker, AjaxSelect, CabinClass }
    }

</script>
