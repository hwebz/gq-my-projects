﻿<template>
    <div>
        <form method="GET" action="/package/start-search" @submit="onValidate">
            <div class="search-grid flex-wrap flight-only-box">
                <div class="journey-type">
                    <label class="radio-inline">
                        <input type="radio" checked="checked" name="JourneyType" value="1" v-model="jnType" /> <span v-lang.ROUNDTRIP></span>
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="JourneyType" value="0" v-model="jnType" /> <span v-lang.ONE_WAY></span>
                    </label>
                </div>
                <AjaxSelect name="From"
                            :placeholder="translateText('PLEASE_INPUT_AIRPORT', 'Please input airport or city name')"
                            :txtLabel="translateText('FROM', 'From')"
                            :defaultValue="from"
                            :defaultText="fromCityName"
                            icon="ico icon-location-arrow"
                            :accepted="true"
                            :url="'/api/get-global-airports'"
                            :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_SOURCE', 'Please choose a valid source')"
                            data-selected="true" />
                <AjaxSelect name="To"
                            :placeholder="translateText('PLEASE_INPUT_AIRPORT', 'Please input airport or city name')"
                            :txtLabel="translateText('TO', 'To')"
                            :defaultValue="to"
                            :defaultText="toCityName"
                            icon="ico icon-map-marker"
                            :accepted="true"
                            :url="'/api/get-global-airports'"
                            :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_DESTINATION', 'Please choose a valid destination')"
                            data-selected="true" />
                <DateRangePicker v-model="defaultDate" date-format="DD/MM/YYYY" :journeyType="jnType" data-selected="true" isFlight="true" :minSpan="true" />
                <PaxSelector :maxRooms="3" data-selected="true" :isFlightOnly="true" />
                <CabinClass :cabinClass="cabinClass" :uniqueId="clientResources.uniqueId" />
            </div>
            <div class="search-button-wrap">
                <input type="hidden" name="OrderId" :value="packageQuery && packageQuery.orderId ? packageQuery.orderId : ''">
                <input type="hidden" name="Currency" :value="packageQuery && packageQuery.currency ? packageQuery.currency : 'USD'">
                <input type="hidden" name="ProductId" :value="product.id" />
                <button type="submit" class="bt-search bt-effect">
                    <span class="text-uppercase" v-lang.SEARCH_FLIGHTS></span>
                </button>
            </div>
        </form>
    </div>
</template>

<script>
    import AjaxSelect from './AjaxSelect.vue'
    import DateRangePicker from './DateRangePicker.vue'
    import PaxSelector from "./PaxSelector.vue"
    import CabinClass from "./CabinClass.vue"

    export default {
        data() {
            return {
                maxRooms: 3,
                PartialStay: false,
                DepartureDate: null,
                ReturnDate: null,
                dateRange: '06/02/2018,06/05/2018',
                jnType: 1,
                uniqueId: null
            }
        },
        mounted() {
            this.jnType = this.journeyType != 'undefined' ? this.journeyType : 1;
        },
        methods: {
            validateInput(context) {
                var parent = context.parents('.box-search');
                var label = parent.find(">strong");
                var labelVals = {
                    old: context.attr('data-label'),
                    new: context.attr('data-required-message')
                };

                if (!context.val()) {
                    parent.addClass('error');
                    label.text(labelVals.new);
                    return false;
                } else {
                    parent.removeClass('error');
                    label.text(labelVals.old);
                }
                return true;
            },
            onValidate(e) {
                var self = this;
                var box = $(self.$el)
                var errors = 0;
                box.find("input[name='From']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                box.find("input[name='To']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                if (errors == 0) {
                    return true;
                }
                if (e) e.preventDefault();
            },
            translateText(translateKey, defaultText, params) {
                return this.translate(this.$language, translateKey, params) || defaultText;
            }
        },
        props: ['product', 'defaultDate', 'from', 'fromCityName', 'to', 'toCityName', 'journeyType', 'cabinClass', 'packageQuery', 'siteInfo', 'clientResources'],
        watch: {
            journeyType: function (value) {
                if (value) {
                    this.jnType = value;
                }
            }
        },
        components: { PaxSelector, DateRangePicker, AjaxSelect, CabinClass }
    }

</script>
