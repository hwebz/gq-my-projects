﻿<template>
    <div>
        <div class="research flex-grow" v-show="hasErrorMessage">
            <div class="container" v-if="packageQuery && isCompleted">
                <nav class="crumbar">
                    <ul>
                        <li v-if="enabledFlights" v-lang.SEARCH_FLIGHTS_AND_HOTELS_FROM_TO="{0: packageQuery.fromCityName, 1: packageQuery.toCityName}"></li>
                        <li v-else v-lang.SEARCH_HOTELS_IN="{0: packageQuery.toCityName}"></li>
                    </ul>
                </nav>
                <div class="research__wrap">
                    <h1 v-if="enabledFlights" v-lang.YOUR_SEARCH_FLIGHTS_AND_HOTELS_FROM_TO="{0: packageQuery.fromCityName, 1: packageQuery.toCityName}"></h1>
                    <h1 v-else v-lang.YOUR_SEARCH_HOTELS_IN="{0: packageQuery.toCityName}"></h1>
                </div>
                <div class="research__content">
                    <div class="research__title">
                        <h2 v-lang.YOUR_SEARCH_DATE_FROM_TO="{0: (formatDate(packageQuery.departureDate, 'DD MMMM YYYY')), 1: (formatDate(packageQuery.returnDate, 'DD MMMM YYYY'))}"></h2>
                        <p v-lang.CHECK_YOUR_SPELLING_AND_TRY_AGAIN></p>
                    </div>
                    <div class="research__form">
                        <div class="search-wrap">
                            <div class="search-tabs search-research">
                                <div class="search-content">
                                    <template v-if="enabledFlights">
                                        <FlightHotelSearchBox :packageQuery="packageQuery" :product="product" :defaultDate="defaultDate" :from="packageQuery.from" :to="packageQuery.to" :fromCityName="fullFromCityName" :toCityName="fullToCityName" :clientResources="clientResources"/>
                                    </template>
                                    <template v-else>
                                        <HotelSearchBox :packageQuery="packageQuery" :product="product" :defaultDate="defaultDate" :to="packageQuery.to" :toCityName="fullToCityName" journeyType="1" />
                                    </template>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div v-show="!hasErrorMessage">
            <div v-if="packageQuery && isCompleted">
                <SessionTimeout :packageId="packageQuery.id" :secondTimeout="packageQuery.ttl"></SessionTimeout>
                <div class="page-title-tabs">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                <div v-if="enabledFlights">
                                    <h1 v-lang.FROM_X_TO_X="{0: packageQuery.fromCityName, 1: packageQuery.toCityName}"></h1>
                                    <h6 v-if="cheapestHotelPrice" v-lang.FLIGHT_HOTEL_FROM_PRICE="{0: packageQuery.currency, 1: cheapestHotelPrice}"></h6>
                                </div>
                                <div v-else>
                                    <h1 v-lang.HOTELS_IN="{0: packageQuery.toCityName}"></h1>
                                    <h6 v-if="cheapestHotelPrice" v-lang.HOTEL_FROM_PRICE="{0: packageQuery.currency, 1: cheapestHotelPrice}"></h6>
                                </div>
                                <div class="date-time-person">
                                    <span>
                                        <i class="icon-calendar"></i>
                                        <span>{{ formatDate(packageQuery.departureDate, 'DD MMM') }} - {{ formatDate(packageQuery.returnDate, 'DD MMM') }}</span>
                                    </span>
                                    <span>
                                        <i class="icon-user"></i>
                                        <span>
                                            {{defaultRoomCount}} {{defaultRoomCount > 1 ? translateText('ROOMS', 'Rooms') : translateText('ROOM', 'Room')}} - {{calculatePaxCount}} {{calculatePaxCount == 1 ? translateText('PASSENGER', 'Passenger') : translateText('PASSENGERS', 'Passengers')}}
                                        </span>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-5 text-right">
                                <a class="btn-title-tabs" href="#modalChangeDate" data-toggle="modal" data-target="#modalChangeDate">
                                    <i class="icon-search"></i><span v-lang.EDIT_SEARCH></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <FlightHotelSelector v-if="enabledFlights"
                                     :packageQuery="packageQuery"
                                     :isSearchCompleted="isSearchCompleted"
                                     :hasErrorMessage="hasErrorMessage"
                                     :loading="loading"
                                     :enabledFlights="enabledFlights"
                                     :priceSummary="priceSummary"
                                     :product="product"
                                     :flightStore="flightStore"
                                     :hotelSelected="hotelSelected"
                                     :hotelStore="hotelStore"
                                     @onShowPriceSummaryPaneHotel="onShowPriceSummaryPaneHotel"
                                     @onGoToHotelDetailUrl="gotoHotelInfoPage" />
                <div class="content-wrap">
                    <div class="content-wrap-tabs">
                        <div class="content-tabs-header" id="change-products-tabs" v-if="enabledFlights">
                            <div class="container nav nav-tabs">
                                <button class="item-tabs-header nav-item nav-link active" href="#tabs-hotel" data-sync="true" data-toggle="tab" role="tab" @click="syncTabs">
                                    <i class="icon-hotel"></i>
                                    <span v-lang.CHANGE_HOTEL></span>
                                </button>
                                <button class="item-tabs-header nav-item nav-link" href="#tabs-flight" data-sync="true" data-toggle="tab" role="tab" @click="syncTabs">
                                    <i class="icon-flight"></i>
                                    <span v-lang.CHANGE_FLIGHT></span>
                                </button>
                            </div>
                        </div>
                        <div class="content-tabs-main tab-content">
                            <div class="content-tabs-wrap tab-pane active show" role="tabpanel" id="tabs-hotel">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-lg-3">
                                            <HotelFilters v-if="loading.hotelFirstLoad"
                                                          :packageQuery="packageQuery"
                                                          :hotelStore="hotelStore"
                                                          :flightStore="flightStore"
                                                          :hotelsOptions="hotelsOptions"
                                                          :isSearchCompleted="isSearchCompleted"
                                                          :enabledFlights="enabledFlights"
                                                          @changed="onFiltersChanged"
                                                          @onTogglePaneChanged="togglePane"
                                                          :flightChangePrice="flightChangePrice"></HotelFilters>
                                        </div>

                                        <div class="col-lg-9">
                                            <div class="avai-findbar-wrap avai-findbar-mobie">
                                                <div class="avai-findbar-title d-block d-sm-none">
                                                    <strong v-lang.SORT></strong>
                                                    <div class="avai-findbar-close" @click="togglePane({element: '.avai-findbar-mobie', isClosed: false})">
                                                        <i class="icon-remove"></i>
                                                    </div>
                                                </div>
                                                <div class="avai-findbar">
                                                    <a class="item-avai-find" :class="{'active': hotelsOptions.sortOrderBy === 'Priority;DESC'}" href="javascript:void(0);" @click="setSortOrderBy('Priority;DESC')" v-lang.MOST_POPULAR></a>
                                                    <a class="item-avai-find" :class="{'active': hotelsOptions.sortOrderBy === 'CheapestPrice;ASC'}" href="javascript:void(0);" @click="setSortOrderBy('CheapestPrice;ASC')" v-lang.PRICE_LOW_TO_HIGH></a>
                                                    <a class="item-avai-find" :class="{'active': hotelsOptions.sortOrderBy === 'CheapestPrice;DESC'}" href="javascript:void(0);" @click="setSortOrderBy('CheapestPrice;DESC')" v-lang.PRICE_HIGH_TO_LOW></a>
                                                    <a class="item-avai-find" :class="{'active': hotelsOptions.sortOrderBy === 'Name;ASC'}" href="javascript:void(0);" @click="setSortOrderBy('Name;ASC')" v-lang.NAME_A_TO_Z></a>
                                                    <a class="item-avai-find" :class="{'active': hotelsOptions.sortOrderBy === 'Name;DESC'}" href="javascript:void(0);" @click="setSortOrderBy('Name;DESC')" v-lang.NAME_Z_TO_A></a>
                                                </div>
                                            </div>
                                            <div class="avai-pills">
                                                <span class="avai-pills__item" v-if="hotelsOptions.hotelName"><span v-lang.HOTEL_NAME></span>: {{hotelsOptions.hotelName}} <i class="ico icon-remove" @click="removeFilter($event, 'name')"></i></span>
                                                <span class="avai-pills__item" v-if="(hotelsOptions.minPrice > hotelStore.minPrice || hotelsOptions.maxPrice < hotelStore.maxPrice) && hotelsOptions.maxPrice != hotelsOptions.minPrice">
                                                    <span v-lang.PRICE></span>: {{packageQuery.currency}} {{formatPrice(calculateTotalPrice(hotelsOptions.minPrice))}} - {{packageQuery.currency}} {{formatPrice(calculateTotalPrice(hotelsOptions.maxPrice))}}
                                                    <i class="ico icon-remove" @click="removeFilter($event, 'price')"></i>
                                                </span>
                                                <span class="avai-pills__item" v-if="hotelsOptions.stars.length > 0">
                                                    <span v-lang.HOTEL_STARS></span>:
                                                    <span v-for="(star, starIndex) in getSelectedStars">{{star}}{{(starIndex + 1) == getSelectedStars.length ? '' : ', '}}</span>
                                                    <i class="ico icon-remove" @click="removeFilter($event, 'star')"></i>
                                                </span>

                                                <span class="avai-pills__item" v-if="hotelsOptions.regionId && hotelsOptions.regionName">
                                                    <span>{{hotelsOptions.regionName}}</span>
                                                    <span v-if="hotelsOptions.minDistance > 0 || hotelsOptions.maxDistance < 5">: {{hotelsOptions.minDistance}} - {{hotelsOptions.maxDistance}}km</span>
                                                    <i class="ico icon-remove" @click="removeFilter($event, 'region')"></i>
                                                </span>

                                                <span class="avai-pills__item" v-if="hotelsOptions.facilities.length > 0">
                                                    <span>{{hotelsOptions.facilities.length > 1 ? translateText('FACILITIES'): translateText('FACILITY')}}</span>
                                                    <span v-for="(fac, facIndex) in hotelsOptions.facilities"><span :class="'icon icon-' + showIconClassFacility(fac)"></span>{{(facIndex + 1) == hotelsOptions.facilities.length ? '' : ', '}}</span>
                                                    <i class="ico icon-remove" @click="removeFilter($event, 'facilities')"></i>
                                                </span>
                                            </div>
                                            <LoadBar :isLoading="loading.hotelResult" />

                                            <HotelAvailability v-if="loading.hotelFirstLoad"
                                                               :packageQuery="packageQuery"
                                                               :isSearchCompleted="isSearchCompleted"
                                                               :hasErrorMessage="hasErrorMessage"
                                                               :errorMessage="hotelErrorMessage"
                                                               :flightStore="flightStore"
                                                               :hotelStore="hotelStore"
                                                               :hotelsOptions="hotelsOptions"
                                                               :hotelSelected="hotelSelected"
                                                               :hotelMapSelected="hotelMapSelected"
                                                               :loading="loading"
                                                               :enabledFlights="enabledFlights"
                                                               :showMapView="showMapView"
                                                               :flightChangePrice="flightChangePrice"
                                                               @onRemoveFilters="removeFilters"
                                                               @onRemoveAllFilters="removeAllFilters"
                                                               @onFiltersChanged="onFiltersChanged"
                                                               @onHotelMapSelectedChanged="changeHotelMapSelected"
                                                               @onSetSortOrder="setSortOrderBy"
                                                               @onHotelSelectedChange="onHotelSelectedChange"
                                                               @onShowPriceSummaryPaneHotel="onShowPriceSummaryPaneHotel"
                                                               @pageChanged="onPageChanged"
                                                               @showHotelMapView="showHotelMapView"></HotelAvailability>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="content-tabs-wrap tab-pane" id="tabs-flight" v-if="enabledFlights">
                                <div class="container">
                                    <div class="row">
                                        <FlightFilters :packageQuery="packageQuery"
                                                       :showOutboundFlights="showOutboundFlights"
                                                       :flightAggreation="showOutboundFlights ? flightStore.outboundAggreation : flightStore.inboundAggreation"
                                                       :flightStore="flightStore"
                                                       @onTogglePaneChanged="togglePane"
                                                       @onDepartureTimesChanged="onDepartureTimesChanged"
                                                       @onArrivalTimesChanged="onArrivalTimesChanged"
                                                       @onFilterByNumberOfStops="filterByNumberOfStops"
                                                       @onFilterByAirlines="filterByAirlines" />
                                        <FlightAvailability v-if="showOutboundFlights"
                                                            direction="0"
                                                            :loading="loading"
                                                            :flightLoadCompleted="flightLoadCompleted"
                                                            :isSearchCompleted="isSearchCompleted"
                                                            :errorMessage="errorMessage"
                                                            :flights="flightStore.outboundFlights"
                                                            :flightStore="flightStore"
                                                            :flightAggreation="flightStore.outboundAggreation"
                                                            :hotelSelected="hotelSelected"
                                                            :product="product"
                                                            @onSortedFlights="sortFlights"
                                                            @onChangeFlight="onFlightChanged"
                                                            @onShowPriceSummaryPaneFlight="onShowPriceSummaryPaneFlight"
                                                            @onPaginationChanged="onFlightPaginationChanged" />
                                        <FlightAvailability v-else
                                                            direction="1"
                                                            :loading="loading"
                                                            :flightLoadCompleted="flightLoadCompleted"
                                                            :isSearchCompleted="isSearchCompleted"
                                                            :errorMessage="errorMessage"
                                                            :flights="flightStore.inboundFlights"
                                                            :flightStore="flightStore"
                                                            :flightAggreation="flightStore.inboundAggreation"
                                                            :hotelSelected="hotelSelected"
                                                            :product="product"
                                                            @onSortedFlights="sortFlights"
                                                            @onClearOutbound="clearOutbound"
                                                            @onChangeFlight="onFlightChanged"
                                                            @onShowPriceSummaryPaneFlight="onShowPriceSummaryPaneFlight"
                                                            @onPaginationChanged="onFlightPaginationChanged" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <button class="btn btn-primary btn-effect bt-selected animated bt-effect-animated fixed" v-if="enabledFlights" @click="gotoHotelInfoPage(hotelSelected.url)">Book</button>
                <div class="modal fade modal-md" id="modalChangeDate" :class="{'has-hotel': !enabledFlights}" tabindex="-1" role="dialog" aria-hidden="true" v-show="!hasErrorMessage">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-title ">
                                <strong v-if="enabledFlights" v-lang.SEARCH_FLIGHTS_AND_HOTELS></strong>
                                <strong v-else v-lang.SEARCH_HOTELS></strong>
                                <button class="modal-close" data-dismiss="modal">
                                    <i class="icon-remove"></i>
                                </button>
                            </div>
                            <form method="GET" action="/package/start-search" data-val="true" @submit="onValidate">
                                <div class="search-tabs search-popup" v-if="!enabledFlights">
                                    <div class="search-content">
                                        <div class="search-grid">
                                            <AjaxSelect name="To"
                                                        :placeholder="translateText('CHOOSE_A_DESTINATION', 'Choose a destination, property name or address....')"
                                                        type="hotel"
                                                        :defaultValue="model.to"
                                                        :defaultText="model.toCityName"
                                                        :txtLabel="translateText('WHERE_ARE_YOU_GOING', 'Where are you going?')"
                                                        icon="ico icon-map-marker"
                                                        :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_DESTINATION', 'Please choose a valid destination')"
                                                        @onValidate="onValidate"
                                                        :url="'/api/search-regions'" />
                                            <DateRangePicker v-model="defaultDate" date-format="DD/MM/YYYY" journeyType="1" />
                                            <PaxSelector :maxRooms="5" :isHotelOnly="true" />
                                        </div>
                                    </div>
                                </div>
                                <div class="search-tabs search-popup" v-else>
                                    <div class="search-content">
                                        <div class="search-grid">
                                            <AjaxSelect name="From"
                                                        :placeholder="translateText('PLEASE_INPUT_AIRPORT', 'Please input airport or city name')"
                                                        :txtLabel="translateText('FROM', 'From')"
                                                        icon="ico icon-location-arrow"
                                                        :accepted="true"
                                                        :url="'/api/get-global-airports'"
                                                        :defaultValue="packageQuery.from"
                                                        :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_SOURCE', 'Please choose a valid source')"
                                                        @onValidate="onValidate"
                                                        :defaultText="fullFromCityName" />
                                            <AjaxSelect name="To"
                                                        :placeholder="translateText('PLEASE_INPUT_AIRPORT', 'Please input airport or city name')"
                                                        :txtLabel="translateText('TO', 'To')"
                                                        icon="ico icon-map-marker"
                                                        :defaultValue="packageQuery.to"
                                                        :defaultText="fullToCityName"
                                                        :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_SOURCE', 'Please choose a valid source')"
                                                        @onValidate="onValidate"
                                                        :accepted="true"
                                                        :url="'/api/get-global-airports'" />
                                            <DateRangePicker v-model="defaultDate" date-format="DD/MM/YYYY" journeyType="1" @onChangeDateTime="onChangeDateTime" isChange="true" />
                                            <PaxSelector :maxRooms="3" :isFlightHotel="true" />
                                            <CabinClass :cabinClass="packageQuery.cabinClass" :uniqueId="clientResources.uniqueId" />
                                        </div>
                                    </div>
                                    <div class="part-of-my-stay">
                                        <div class="search-grid">
                                            <div class="check-box-part-of-my-stay" style="width:100%;">
                                                <input type="checkbox" id="part-of-my-stay" v-model="model.partialStay">
                                                <label for="part-of-my-stay" v-lang.NEED_HOTEL_PART_STAY></label>
                                            </div>
                                            <DateRangePicker v-model="defaultDateForMytrip" date-format="DD/MM/YYYY" v-if="model.partialStay" :endDate="model.returnDate" :startDate="model.departureDate" isMyTrip="true" />
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="hidden" name="OrderId" :value="packageQuery.orderId" />
                                    <input type="hidden" name="Currency" :value="packageQuery.currency" />
                                    <input type="hidden" name="JourneyType" value="1">
                                    <input type="hidden" name="ProductId" :value="packageQuery.productId" />
                                    <button :id="product.type == 'Flight_Hotel' ? 'btnSumitSearchFormFlightHotel' : 'btnSumitSearchFormHotel'" class="btn btn-sm btn-primary bt-effect" type="submit" v-lang.SEARCH></button>
                                    <button class="btn btn-sm btn-default bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <a class="back-to-top" href="#" @click="backTop">
                    <i class="icon icon-up-chevron"></i>
                    <span v-lang.BACK_TO_TOP></span>
                </a>
            </div>
            <div v-else>
                <div class="page-title-tabs">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                <div class="lda">
                                    <div class="lda__bar lda__bar--h34"></div>
                                    <div class="lda__bar lda__bar--50"></div>
                                </div>
                            </div>
                            <div class="col-md-5 text-right">
                                <a class="btn-title-tabs bt-effect">
                                    <div class="lda__bar"></div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="fh-tabs__wrap" v-if="enabledFlights">
                    <div class="container">
                        <div class="fh-tabs__overview">
                            <div class="fh-tabs__item fh-tabs__hotel active">
                                <div class="picture">
                                    <div class="lda">
                                        <div class="lda__bar lda__bar--full"></div>
                                    </div>
                                </div>
                                <div class="detail">
                                    <div class="lda">
                                        <div class="lda__bar"></div>
                                        <div class="lda__bar lda__bar--50"></div>
                                        <div class="lda__bar lda__bar--split"></div>
                                        <div class="lda__bar lda__bar--split"></div>
                                        <div class="lda__bar"></div>
                                        <div class="lda__bar"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="fh-tabs__item fh-tabs__flight">
                                <div class="title"><strong v-lang.FLIGHT></strong></div>
                                <div class="flight-way__tabs">
                                    <div class="flight-way__view">
                                        <div class="lda__wrap">
                                            <div class="lda">
                                                <div class="lda__bar"></div>
                                                <div class="lda__bar lda__bar--split lda__bar--50"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="flight-way__tabs">
                                    <div class="flight-way__view">
                                        <div class="lda__wrap">
                                            <div class="lda">
                                                <div class="lda__bar"></div>
                                                <div class="lda__bar lda__bar--split lda__bar--50"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="fh-tabs__item fh-tabs__control">
                                <div class="lda lda--fbot">
                                    <div class="lda__bar lda__bar--50"></div>
                                    <div class="lda__bar lda__bar--50"></div>
                                    <div class="lda__bar lda__bar--50"></div>
                                    <div class="lda__bar lda__bar--split"></div>
                                    <div class="lda__bar lda__bar--two"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="content-wrap">
                    <div class="content-wrap-tabs">
                        <div class="content-tabs-header" v-if="enabledFlights">
                            <div class="container">
                                <a class="item-tabs-header active">
                                    <i class="icon-hotel"></i>
                                    <span v-lang.CHANGE_HOTEL></span>
                                </a>
                                <a class="item-tabs-header" href="#">
                                    <i class="icon-flight"></i>
                                    <span v-lang.CHANGE_FLIGHT></span>
                                </a>
                            </div>
                        </div>
                        <div class="content-tabs-main">
                            <div class="tab-pane active show">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-lg-3">
                                            <div class="sidebar-wrap">
                                                <div class="sidebar__maps">
                                                    <div class="lda">
                                                        <div class="lda__bar lda__bar--h110"></div>
                                                    </div><a class="bt-maps" href="#" v-lang.VIEW_ON_MAP></a>
                                                </div>
                                                <div class="sidebar__search">
                                                    <form action="">
                                                        <input class="ipt-search" type="text" placeholder="Search for hotels">
                                                        <button class="bt-search" type="submit"><i class="icon-search"></i></button>
                                                    </form>
                                                </div>
                                                <div class="sidebar__box">
                                                    <div class="sidebar__title">
                                                        <h2 v-lang.PRICE_RANGE></h2>
                                                    </div>
                                                    <div class="sidebar__content">
                                                        <div class="sidebar__price">
                                                            <div class="lda">
                                                                <div class="lda__bar lda__bar--h60"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="sidebar__title">
                                                        <h2 v-lang.STAR_RATING></h2>
                                                    </div>
                                                    <div class="sidebar__content">
                                                        <div class="sidebar__rating">
                                                            <div class="lda">
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="sidebar__title">
                                                        <h2 v-lang.PRICE_RANGE></h2>
                                                    </div>
                                                    <div class="sidebar__content">
                                                        <div class="sidebar__dropdown">
                                                            <div class="lda">
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="sidebar__title">
                                                        <h2 v-lang.NEIGHBORHOOD></h2>
                                                    </div>
                                                    <div class="sidebar__content">
                                                        <div class="sidebar__dropdown">
                                                            <div class="lda">
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-9">
                                            <div class="avai-findbar-wrap avai-findbar-mobie">
                                                <div class="avai-findbar">
                                                    <a class="item-avai-find"><div class="lda__bar"></div></a>
                                                    <a class="item-avai-find"><div class="lda__bar"></div></a>
                                                    <a class="item-avai-find"><div class="lda__bar"></div></a>
                                                </div>
                                            </div>

                                            <div class="avai-hotel">
                                                <div class="fh-tabs__overview" v-for="n in 5" :key="n">
                                                    <div class="fh-tabs__item fh-tabs__hotel">
                                                        <div class="picture">
                                                            <div class="lda">
                                                                <div class="lda__bar lda__bar--full"></div>
                                                            </div>
                                                        </div>
                                                        <div class="detail">
                                                            <div class="lda">
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar lda__bar--50"></div>
                                                                <div class="lda__bar lda__bar--split"></div>
                                                                <div class="lda__bar lda__bar--split"></div>
                                                                <div class="lda__bar lda__bar--50"></div>
                                                                <div class="lda__bar lda__bar--50"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="fh-tabs__item fh-tabs__control">
                                                        <div class="lda lda--fbot">
                                                            <div class="lda__bar lda__bar--50"></div>
                                                            <div class="lda__bar lda__bar--50"></div>
                                                            <div class="lda__bar lda__bar--50"></div>
                                                            <div class="lda__bar lda__bar--split lda__bar--50"></div>
                                                            <div class="lda__bar lda__bar--two"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="paganition-wrap">
                                                    <a class=" bt-effect"><div class="lda__bar"></div></a>
                                                    <span class="count-page"><div class="lda__bar"></div></span>
                                                    <a class="bt-effect"><div class="lda__bar"></div></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="modalPriceBreakdown" tabindex="-1" role="dialog" aria-hidden="true" v-if="packageQuery && isSearchCompleted && !hasErrorMessage">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body modal-body-gray npd">
                        <div class="flight-detail-title">
                            <strong v-lang.PRICE_BREAKDOWN></strong>
                            <button class="modal-close" data-dismiss="modal">
                                <i class="icon-remove"></i>
                            </button>
                        </div>
                        <div class="price-summary-table">
                            <table class="responsive">
                                <thead>
                                    <tr>
                                        <th colspan="4">
                                            <span v-if="enabledFlights" v-lang.FLIGHT_HOTEL></span>
                                            <span v-else v-lang.HOTEL></span> <span v-lang.PRICES></span>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th scope="col">{{displayPrice == 1 ? translateText('PASSENGER', 'Passengers') : translateText('NIGHTS', 'Nights')}}</th>
                                        <th scope="col">{{displayPrice == 1 ? translateText('PRICE_PER_PAX', 'Price/pax') : translateText('PRICE_PER_NIGHT', 'Price/night')}}</th>
                                        <th scope="col">{{displayPrice == 1 ? translateText('NO_OF_PASSENGERS', 'No. of Passengers') : translateText('NO_OF_NIGHTS', 'No. of Nights')}}</th>
                                        <th scope="col" v-lang.TOTAL_PRICE></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td scope="row" :data-label="displayPrice == 1 ? translateText('PASSENGERS', 'Passengers') : translateText('NIGHTS', 'Nights')">
                                            <span v-if="displayPrice == 1" v-lang.PER_PASSENGER></span>
                                            <span v-else v-lang.PER_NIGHT></span>
                                        </td>
                                        <td :data-label="displayPrice == 1 ? translateText('PRICE_PER_PAX', 'Price/pax') : translateText('PRICE_PER_NIGHT', 'Price/night')">{{packageQuery.currency}} {{displayPrice == 1 ? formatPrice(priceSummary.adultPrice) : formatPrice(priceSummary.nightPrice)}}</td>
                                        <td :data-label="displayPrice == 1 ? translateText('NO_OF_PASSENGERS', 'No. of Passengers') : translateText('NO_OF_NIGHTS', 'No. of Nights')">{{displayPrice == 1 ? calculatePaxCount : calculateNights()}}</td>
                                        <td data-label="Total price">{{packageQuery.currency}} {{displayPrice == 1 ? formatPrice(priceSummary.adultPrice * calculatePaxCount) :  formatPrice(priceSummary.nightPrice * calculateNights())}}</td>
                                    </tr>
                                </tbody>
                            </table>
                            <table>
                                <thead>
                                <tr>
                                    <th v-lang.TOTAL_PRICE_INCLUDES_TAXES_AND_FEES></th>
                                    <th>{{packageQuery.currency}} {{formatPrice(priceSummary.totalPrice)}}</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-primary bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import Vue from 'vue'
    import {
        mapState
    } from 'vuex'
    import _ from 'lodash';
    import Cookie from 'js-cookie'
    import FlightAvailability from './FlightAvailability.vue'
    import HotelAvailability from './HotelAvailability.vue'
    import HotelFilters from './HotelFilters.vue'
    import FlightFilters from './FlightFilters.vue'
    import FlightHotelSelector from './FlightHotelSelector.vue';
    import AjaxSelect from './AjaxSelect.vue'
    import DateRangePicker from './DateRangePicker.vue'
    import PaxSelector from './PaxSelector.vue'
    import AjaxTypeahead from './AjaxTypeahead.vue'
    import LoadBar from './LoadBar.vue';
    import FlightHotelSearchBox from './FlightHotelSearchBox.vue'
    import HotelSearchBox from './HotelSearchBox.vue'
    import SessionTimeout from './SessionTimeout.vue'
    import CabinClass from "./CabinClass.vue";
import { debug } from 'util';

    export default {
        components: {
            CabinClass,
            FlightAvailability,
            HotelAvailability,
            HotelFilters,
            FlightFilters,
            FlightHotelSelector,
            AjaxSelect,
            DateRangePicker,
            PaxSelector,
            AjaxTypeahead,
            LoadBar,
            FlightHotelSearchBox,
            HotelSearchBox,
            SessionTimeout
        },
        data() {
            return {
                packageQuery: null,
                enabledFlights: false,
                hasErrorMessage: false,
                errorMessage: "",
                flightErrorMessage: null,
                hotelErrorMessage: null,
                enabledMapView: true,
                showMapView: false,
                showMapFull: false,
                isSearchCompleted: false,
                waitingProducts: 0,
                flightLoadCompleted: false,
                abortPing: false,
                previousStatus: {},
                showOutboundFlights: true,
                flightStore: {
                    flights: [],
                    inboundFlights: [],
                    outboundFlights: [],
                    outboundFlight: null,
                    inboundFlight: null,
                    outboundAggreation: {
                        totalPages: 0,
                        nonStop: false,
                        hasStops: false,
                        airlines: []
                    },
                    inboundAggreation: {
                        totalPages: 0,
                        nonStop: false,
                        hasStops: false,
                        airlines: []
                    },
                    outboundFilters: {
                        direction: 'OutBound',
                        pageIndex: 1,
                        pageSize: 10,
                        sortBy: "SolutionPrice",
                        sortByDesc: false,
                        outboundFilter: {
                            minDepartureTime: "00:00",
                            maxDepartureTime: "24:00",
                            minArrivalTime: "00:00",
                            maxArrivalTime: "24:00"
                        }
                    },
                    inboundFilters: {
                        direction: 'InBound',
                        pageIndex: 1,
                        pageSize: 10,
                        sortBy: "SolutionPrice",
                        sortByDesc: false,
                        inboundFilter: {
                            minDepartureTime: "00:00",
                            maxDepartureTime: "24:00",
                            minArrivalTime: "00:00",
                            maxArrivalTime: "24:00"
                        }
                    }
                },
                dataViewMap: {
                    isHotelDetail: false,
                    hotels: []
                },
                hotelStore: {
                    totalHotels: 0,
                    totalFilteredHotels: 0,
                    minPrice: 0,
                    maxPrice: 0,
                    hotels: [],
                    currentPage: 1,
                    pageSize: 25,
                    importantLocations: [],
                    facilities: [],
                    iconClassFacilities: [],
                },
                hotelsOptions: {
                    sortOrderBy: "Priority;DESC",
                    sortOrderByAsc: false,
                    hotelName: '',
                    minPrice: 0,
                    maxPrice: 0,
                    stars: [],
                    roomBoards: [],
                    facilities: [],
                    regionId: null,
                    regionName: null,
                    tripAdvisorRating: [],
                    minDistance: 0,
                    maxDistance: 5
                },
                hotelSelected: null,
                hotelMapSelected: null,
                loading: {
                    flightDetails: false,
                    hotelFirstLoad: false,
                    hotelResult: true,
                    flightPagination: false,
                    hotelPagination: false
                },
                model: {
                    from: null,
                    to: null,
                    departureDate: null,
                    returnDate: null,
                    checkIn: null,
                    checkOut: null,
                    partialStay: false
                },
                flightChangePrice: 0,
                defaultDate: null,
                defaultDateForMytrip: null,
                isFirstLoad: true,
                cheapestHotel: true,
                priceSummary: {
                    adultPrice: 0,
                    childPrice: 0,
                    nightPrice: 0,
                    totalPrice: 0
                },
                cheapestHotel: null,
                cheapestHotelPrice: null,
                hotelCheapest: null,
                checkInUrl: null,
                pingCount: 0,
                clientResources: null,
                totalRoom: 0,
                isCompleted: false,
                searchConditions: {
                    adultCount: 0,
                    childCount: 0,
                    infantCount: 0
                },
                defaultRoomCount: 0
            }
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            baseUrl: state => state.workContext.baseUrl,
            product: state => state.workContext.product,
            depatureDisableDateUrl() {
                if (!this.packageQuery) {
                    return null;
                }
                return "/package/get-disabled-dates?from=" + this.model.from + "&to=" + this.model.to;
            },
            returnDisableDateUrl() {
                if (!this.packageQuery) {
                    return null;
                }
                return "/package/get-disabled-dates?from=" + this.model.to + "&to=" + this.model.from;
            },
            roomCount() {
                return this.packageQuery.paxInfos.length;
            },
            persons() {
                return 1;
            },
            hotelStay() {
                var start = this.packageQuery.checkIn || this.packageQuery.departureDate;
                var end = this.packageQuery.checkOut || this.packageQuery.returnDate;
                return Vue.moment(end).diff(moment(start), 'days');
            },
            calculatePaxCount() {
                return this.searchConditions.adultCount + this.searchConditions.childCount + this.searchConditions.infantCount;
            },
            adultCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                }
                return count;
            },
            childCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.childCount;
                }
                return count;
            },
            infantCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.infantCount;
                }
                return count;
            },
            fullFromCityName() {
                var self = this;
                return self.packageQuery.fromCityName + ' (' + self.packageQuery.from + ') ,' + self.packageQuery.fromCountryName;
            },
            fullToCityName() {
                var self = this;
                return self.packageQuery.toCityName + ' (' + self.packageQuery.to + ') ,' + self.packageQuery.toCountryName;
            },
            getSelectedStars() {
                return this.hotelsOptions.stars.filter(star => {
                    return Number.isInteger(parseFloat(star));
                })
            },
            displayPrice: state => state.workContext.product.displayPrice,
        }),
        created() {
            var self = this;
            var packageId = $("#PackageId").val();
            $.post('/package/work-context/' + packageId, function (data) {
                if (!data.packageQuery) {
                    window.location.reload();
                }

                if (data.defaultFilterStars != null && data.defaultFilterStars.length > 0) {
                    self.hotelsOptions.stars = data.defaultFilterStars;
                }
                self.packageQuery = data.packageQuery;
                self.totalRoom = self.packageQuery.paxInfos.length;
                self.searchConditions = {
                    adultCount: self.adultCount,
                    childCount: self.childCount,
                    infantCount: self.infantCount
                }
                self.defaultRoomCount = self.packageQuery.paxInfos.length;

                self.flightStore.outboundFilters.packageId = data.packageQuery.id;
                self.flightStore.inboundFilters.packageId = data.packageQuery.id;

                self.model.from = data.packageQuery.from;
                self.model.to = data.packageQuery.to;
                self.model.toCityName = data.packageQuery.toCityName;
                self.model.toCountryName = data.packageQuery.toCountryName;
                self.model.regionId = self.$route.query.RegionId;
                self.model.hotelCode = self.$route.query.HotelCode;
                self.model.departureDate = data.packageQuery.departureDate;
                self.model.returnDate = data.packageQuery.returnDate;

                if (data.product.products.some(function (x) { return x.productType === 1; })) {
                    // Flight
                    self.enabledFlights = true;
                    self.waitingProducts++;
                }

                // Hotel
                self.waitingProducts++;

                self.model.checkIn = data.packageQuery.checkIn ? data.packageQuery.checkIn : data.packageQuery.departureDate;
                self.model.checkOut = data.packageQuery.checkOut ? data.packageQuery.checkOut : data.packageQuery.returnDate;
                self.curCabinClass = data.packageQuery.cabinClass;

                var checkInUrl = self.getUrlParam("CheckIn");
                var checkOutUrl = self.getUrlParam("CheckOut");
                self.checkInUrl = self.getUrlParam("CheckIn");

                if (checkInUrl && checkOutUrl) {
                    self.model.partialStay = true;
                } else {
                    self.model.partialStay = false;
                }


                self.hotelsOptions.regionId = self.model.regionId;

                switch (data.siteInfo.sortOrderBy) {
                    case "Priority":
                        self.hotelsOptions.sortOrderBy = data.siteInfo.sortOrderBy + ";DESC";
                        break;
                    default:
                        self.hotelsOptions.sortOrderBy = data.siteInfo.sortOrderBy + ";ASC";
                        break;
                }

                self.enabledFlights = data.product.products.some(x => x.productType == 1);
                data.baseUrl = $("#baseURL").val();

                self.setClassFacilities();
                if (data.product.products.some(function (x) { return x.productType === 1; })) {
                    // Flight
                    self.enabledFlights = true;
                    self.waitingProducts++;
                }

                $.getJSON(data.baseUrl + '/resources.json', function (res) {
                    data.clientResources = res;
                    self.clientResources = res;
                }).always(function () {
                    self.$store.commit('setWorkContext', data);
                }).done(function (p) {
                    self.isCompleted = true;
                });

 				// Hotel
                self.waitingProducts++;
                self.$store.commit('setWorkContext', data);
                
                var checkInDate = data.packageQuery.checkIn != undefined ? data.packageQuery.checkIn : data.packageQuery.departureDate;
                var checkOutDate = data.packageQuery.checkOut != undefined ? data.packageQuery.checkOut : data.packageQuery.returnDate;
                var key = Vue.moment.utc(checkInDate).format('YYYYMMDD') + "-" + Vue.moment.utc(checkOutDate).format('YYYYMMDD');
                self.createPingRequest(key);
                self.setupSessionTimeout(data.packageQuery.ttl);

                self.getStaticHotels();
                self.getRegions();

                if (jQuery().fotorama) {
                    console.log("Initialization fotorama");
                    $('.fotorama').fotorama();
                }

                // set default date
                var startDate = Vue.moment.utc(self.model.departureDate).format('MM/DD/YYYY');
                var endDate = Vue.moment.utc(self.model.returnDate).format('MM/DD/YYYY');

                self.defaultDate = startDate + ',' + endDate;
                self.defaultDateForMytrip = Vue.moment.utc(self.model.checkIn).format('MM/DD/YYYY') + ',' + Vue.moment.utc(self.model.checkOut).format('MM/DD/YYYY');
                $(".foo-copy-right").addClass('extra-padding');

                self.scrollTabsSelected();
            }).fail(function () {
                window.location.reload();
            });
            window.mapviewActionQueue = [];
            window.priceFac = function (h) {
                var price = self.totalPackagePrice(h);
                var paxCount = 0;
                for (var i = 0; i < h.availableRooms.length; i++) {
                    paxCount += h.availableRooms[i].adults;
                    paxCount += h.availableRooms[i].children;
                }
                var displayPrice = self.$store.state.workContext.product.displayPrice;
                var nightCount = self.calculateNights();

                if (displayPrice == 0) {
                    var formatPrice = (parseFloat(price.replace(",", "")) / nightCount).toFixed(self.packageQuery.currencyDecimals);
                }
                if (displayPrice == 1) {
                    var formatPrice = (parseFloat(price.replace(",", "")) / paxCount).toFixed(self.packageQuery.currencyDecimals);
                }

                return self.packageQuery.currency + " " + formatPrice.replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            };

            var startDate = Vue.moment().format('MM/DD/YYYY');
            var endDate = Vue.moment().add(2, 'days').format('MM/DD/YYYY');

            self.defaultDate = startDate + ',' + endDate;

        },
        mounted() {
            $(window).on('scroll', function () {
                let btt = $(".back-to-top");
                if ($(window).scrollTop() > 200) btt.addClass('shown');
                else btt.removeClass('shown');
            });
        },
        methods: {
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            getHotelDetailUrl(baseUrl) {
                var href = baseUrl;
                var indexOfMask = baseUrl.indexOf("?");
                if (indexOfMask > -1) {
                    href += "&";
                } else {
                    href += "?";
                }
                if (this.flightStore.outboundFlight != null) {
                    href += "outboundFlightId=" + this.flightStore.outboundFlight.id;

                    if (this.flightStore.inboundFlight != null) {
                        href += "&inboundFlightId=" + this.flightStore.inboundFlight.id;
                    }
                }
                return href;
            },
            gotoHotelInfoPage(baseUrl) {
                window.open(this.getHotelDetailUrl(baseUrl), '_blank');
            },
            syncTabs(e) {
                var $this = $(e.target);
                var href = $this.attr('href');
                href = href ? href : $this.parents(".item-tabs-header").attr('href');
                href = $('.nav-tabs .fh-tabs__item[href="' + href + '"]');
                if (typeof href !== 'undefined' && href.length > 0) {
                    href.tab('show');
                }
            },
            getMinPrice(callback) {
                var self = this;

                var parameters = jQuery.extend(true, {}, this.hotelsOptions);

                parameters.packageId = this.packageQuery.id;
                parameters.pageIndex = 1;
                parameters.pageSize = 1;

                // Process sorting
                parameters.sortOrderBy = "CheapestPrice";
                parameters.sortOrderByAsc = true;

                $.ajax({
                    url: '/package/get-static-hotels',
                    data: parameters,
                    type: 'POST',
                    success: function (data) {
                        if (!data.hotels || data.hotels.length == 0) {
                            return;
                        }

                        var hotel = data.hotels.filter(h => h.cheapestPrice > 0)[0];
                        self.prepareHotel(hotel);
                        self.cheapestHotel = hotel;
                        self.calculateTotalPackagePrice(hotel, callback);
                        self.hotelCheapest = hotel;
                    }
                });
            },
            calculateTotalPackagePrice(hotel, callback) {
                var self = this;
                var cheapestHotelPrice = 0;
                if (hotel) {
                    for (var j = 0; j < hotel.availableRooms.length; j++) {
                        for (var k = 0; k < hotel.availableRooms[j].availableRoomTypes.length; k++) {
                            var availableRoomType = hotel.availableRooms[j].availableRoomTypes[k];
                            if (availableRoomType.selected) {
                                cheapestHotelPrice += availableRoomType.totalPrice;
                                break;
                            }
                        }
                    }
                }
                if (self.enabledFlights) {
                    if (self.flightLoadCompleted) {
                        if (self.flightStore.outboundFlight) {
                            cheapestHotelPrice += self.flightStore.outboundFlight.solutionPrice;
                        }
                        if (self.flightStore.inboundFlight) {
                            var priceChanged = this.flightStore.inboundFlight.solutionPrice - this.flightStore.outboundFlight.solutionPrice;
                            if (priceChanged != 0)
                                cheapestHotelPrice += priceChanged;
                        }
                    }
                }
                if (cheapestHotelPrice) {
                    self.cheapestHotelPrice = (cheapestHotelPrice.toFixed(self.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
                }

                if (callback) {
                    callback();
                }
            },
            validateInput(context) {
                var parent = context.parents('.box-search');
                var label = parent.find(">strong");
                var labelVals = {
                    old: context.attr('data-label'),
                    new: context.attr('data-required-message')
                };

                if (!context.val()) {
                    parent.addClass('error');
                    label.text(labelVals.new);
                    return false;
                } else {
                    parent.removeClass('error');
                    label.text(labelVals.old);
                }
                return true;
            },
            onChangeDateTime() {
                var self = this;
                var box = $(self.$el);
                var departureDate = box.find("input[name = 'DepartureDate']").val();
                var returnDate = box.find("input[name = 'ReturnDate']").val();
                if (departureDate && returnDate) {
                    self.model.departureDate = Vue.moment(departureDate).format('MM/DD/YYYY');
                    self.model.returnDate = Vue.moment(returnDate).format('MM/DD/YYYY');
                }
            },
            onValidate(e) {
                var self = this;
                var box = $(self.$el)
                var errors = 0;
                box.find("input[name='From']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                box.find("input[name='To']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                if (errors == 0) {
                    return true;
                }
                if (e) e.preventDefault();
            },
            calculateTotalPrice(hotelPrice) {
                var price = 0;
                if (this.flightStore.outboundFlight)
                    price += this.flightStore.outboundFlight.solutionPrice;
				if (this.flightStore.inboundFlight) {
                    var priceChanged = this.flightStore.inboundFlight.solutionPrice - this.flightStore.outboundFlight.solutionPrice;
                    if (priceChanged != 0)
                        price += priceChanged;
                }
                return (price + hotelPrice);
            },
            getFlightFilters(packageId) {
                var self = this;
                $.ajax({
                    url: "/package/get-flight-filters",
                    data: {
                        packageId: packageId
                    },
                    type: "POST",
                    success: function (data) {
                        if (data.outboundAirlines)
                            self.flightStore.outboundAggreation.airlines = Object.keys(data.outboundAirlines).map(function (x) { return { key: x, value: data.outboundAirlines[x], selected: false }; });
                        if (data.inboundAirlines)
                            self.flightStore.inboundAggreation.airlines = Object.keys(data.inboundAirlines).map(function (x) { return { key: x, value: data.inboundAirlines[x], selected: false }; });
                    }
                })
            },
            sortDicByValue(object) {
                var sorted = [];
                var listAirports = [];
                for (var key in object) {
                    if (object[key] == null) {
                        object[key] = key;
                    }
                }
                var listValue = Object.values(object);
                listValue.sort();

                for (var i = 0; i < listValue.length; i++) {
                    for (var k in object) {
                        if (object[k] == listValue[i]) {
                            listAirports.push(
                                {
                                    key: k,
                                    value: listValue[i]
                                }
                            )
                        }
                    }
                }
                return listAirports;
            },
            createPingRequest: function (key, isReSearchHotel = false) {
                var self = this;

                if (self.hasErrorMessage || self.abortPing) {
                    // Ping in 60 seconds only
                    return;
                }

                var productTypes = [];
                if (self.enabledFlights) {
                    // Flight
                    productTypes.push({
                        productType: 1,
                        storedKey: ''
                    });
                }

                // Hotel
                productTypes.push({
                    productType: 2,
                    storedKey: key
                });

                var baseUrl = "/package/product-status/" + self.packageQuery.id;

                $.post(baseUrl, { productTypeStatuses: productTypes }, function (data) {
                    if (data.length > 0) {
                        if (data.some(x => x.status == 3)) {
                            window.location = '/package/restart-search/' + self.packageQuery.id;
                        }
                        var completed = data.every(x => x.status == 1);
                        var haveErrors = data.some(x => x.status == 2);

                        if (haveErrors) {
                            self.notifyErrorMessage(data.find(x => x.status == 2).message);
                        } else {
                            for (var j = 0; j < data.length; j++) {
                                var item = data[j];

                                if (item.status === 1 || item.progress !== 0) {
                                    switch (item.product) {
                                        case 1:
                                            if (item.status === 1) {
                                                if (!self.searchFlightsCompleted) {
                                                    console.log("notifyFlightsCompleted");
                                                    self.searchFlightsCompleted = true;
                                                    self.getFlights(self.flightStore.outboundFilters, true);
                                                    self.getFlightFilters(self.packageQuery.id);
                                                }
                                            } else {
                                                let previous = self.previousStatus[item.product];
                                                let newData = item.progress > 0 && (!previous || previous.progress < item.progress);

                                                if (newData) {
                                                    console.log("notifyNewFlights");
                                                    self.getFlights(self.flightStore.outboundFilters, true);
                                                }

                                                self.previousStatus[item.product] = item;
                                            }
                                            break;
                                        case 2:
                                            if (item.status === 1) {
                                                if (isReSearchHotel) {
                                                    console.log("notifyHotelResearch");
                                                    self.getStaticHotels(self.hotelStore.currentPage, true, function () {
                                                        self.waitingProducts--;
                                                        self.totalHotels = self.hotelStore.totalFilteredHotels;
                                                    });
                                                    self.getMinPrice();
                                                    self.getHotelFilters();
                                                    
                                                }
                                                if (!self.searchHotelsCompleted) {
                                                    console.log("notifyHotelsCompleted");
                                                    self.searchHotelsCompleted = true;
                                                    self.getStaticHotels(self.hotelStore.currentPage, true, function () {
                                                        self.waitingProducts--;
                                                        self.totalHotels = self.hotelStore.totalFilteredHotels;
                                                    });
                                                    self.getMinPrice();
                                                    self.getHotelFilters();                                                    
                                                }
                                            }
                                            else {
                                                let previous = self.previousStatus[item.product];
                                                let newData = !previous || previous.progress < item.progress;

                                                if (newData) {
                                                    console.log("notifyNewHotels");
                                                    self.getStaticHotels(self.hotelStore.currentPage);
                                                }

                                                self.previousStatus[item.product] = item;
                                            }
                                            break;
                                    }
                                }
                            }

                            if (!completed) {
                                self.createPingRequest(key);
                            }
                        }
                    } else {
                        self.createPingRequest(key);
                    }
                });
            },
            hideSplashScreen() {
                _.debounce(function () {
                    $('#loading-page').addClass('hidden');
                    $('#app').removeClass('modal-open');
                }, 500)();
            },
            calculatePriceSummary(param) {
                if (param) {
                    if (typeof param != 'object') {
                        this.priceSummary = {
                            adultPrice: ((param + this.totalFlightPrice()) / this.calculatePaxCount),
                            nightPrice: ((param + this.totalFlightPrice()) / this.calculateNights()),
                            totalPrice: param + this.totalFlightPrice()
                        };
                    } else {
                        let flightPrice = param.solutionPrice;
                        this.priceSummary = {
                            adultPrice: ((this.hotelSelected.cheapestPrice + flightPrice) / this.calculatePaxCount),
                            nightPrice: ((this.hotelSelected.cheapestPrice + flightPrice) / this.calculateNights()),
                            totalPrice: this.hotelSelected.cheapestPrice + flightPrice
                        };
                    }
                }
            },
            notifyErrorMessage(errorMessage) {
                var self = this;
                console.log("notifyErrorMessage: " + errorMessage);
                this.hasErrorMessage = true;
                this.errorMessage = errorMessage;

                if (typeof dataLayer != 'undefined') {
                    dataLayer.push({
                        'event': 'errorMessage',
                        'eventAction': 'productStatus',
                        'eventLabel': errorMessage
                    });
                };
                self.hideSplashScreen();
            },
            setupSessionTimeout(ttl) {
                // Server TTL is 30 mins, only allow browser TTL 20 mins
                var counter = ttl - 600;
                var packageId = this.packageQuery.id;
                var self = this;
                setInterval(function () {
                    counter = counter - 1;
                    self.pingCount++;

                    if (self.pingCount >= 60 && !self.abortPing) {
                        self.abortPing = true;
                    }

                    if (counter <= 0) {
                        //window.location = '/package/start-over/' + packageId;
                    }
                }, 1000);
            },
            getFlights(filters, isFirstTime = false) {
                var self = this;
                self.errorMessage = "";
                self.loading.flightPagination = true;
                $.ajax({
                    url: "/package/get-flights",
                    data: filters,
                    type: "POST",
                    success: function (data) {
                        if (!data.flights || data.flights.length == 0) {
                            self.errorMessage = data.errorMessage;
                            if (isFirstTime) self.notifyErrorMessage(data.errorMessage);
                            if (self.showOutboundFlights) {
                                self.flightStore.outboundFlights = data.flights;
                                self.flightStore.outboundAggreation.totalFlights = 0;
                                self.flightStore.outboundAggreation.totalPages = 0;
                            }
                            else {
                                self.flightStore.inboundFlights = data.flights;
                                self.flightStore.inboundAggreation.totalFlights = 0;
                                self.flightStore.inboundAggreation.totalPages = 0;
                            }

                            return;
                        }

                        var totalPages = 0;
                        var pageSize = filters.direction == 'OutBound' ? self.flightStore.outboundFilters.pageSize : self.flightStore.inboundFilters.pageSize;
                        if (data.totalFlights % pageSize === 0) {
                            totalPages = data.totalFlights / pageSize;
                        } else {
                            totalPages = parseInt(data.totalFlights / pageSize) + 1;
                        }

                        var newFlights;

                        if (filters.direction == 'OutBound') {
                            if (filters.pageIndex > 1) {
                                self.flightStore.outboundFlights.push(...data.flights);
                                newFlights = self.flightStore.outboundFlights;
                            } else {
                                self.flightStore.outboundFlights = data.flights;
                                newFlights = data.flights;
                            }

                            self.flightStore.outboundAggreation.totalFlights = data.totalFlights;
                            self.flightStore.outboundAggreation.totalPages = totalPages;

                            // Select cheapest flight
                            if (filters.sortBy === 'SolutionPrice' && !filters.sortByDesc) {
                                if (!self.flightStore.outboundFlightId) {
                                    self.flightStore.outboundFlight = newFlights.sort(function (x, y) {
                                        return x.solutionPrice - y.solutionPrice;
                                    })[0];
                                } else {
                                    self.flightStore.outboundFlight = newFlights.find(function (x) {
                                        return x.id === self.flightStore.outboundFlightId;
                                    });
                                }

                                if (self.packageQuery.journeyType === 1 && self.flightStore.outboundFlight) {
                                    self.flightStore.inboundFilters.outboundFilter = { flightKey: self.flightStore.outboundFlight.key };
                                    self.getFlights(self.flightStore.inboundFilters);
                                }
                            }
                        }
                        else {
                            if (filters.pageIndex > 1) {
                                self.flightStore.inboundFlights.push(...data.flights);
                                newFlights = self.flightStore.inboundFlights;
                            } else {
                                self.flightStore.inboundFlights = data.flights;
                                newFlights = data.flights;
                            }

                            self.flightStore.inboundAggreation.totalFlights = data.totalFlights;
                            self.flightStore.inboundAggreation.totalPages = totalPages;

                            // Select cheapest flight
                            if (filters.sortBy === 'SolutionPrice' && !filters.sortByDesc) {
                                if (!self.flightStore.inboundFlightId) {
                                    self.flightStore.inboundFlight = newFlights.sort(function (x, y) {
                                        return x.solutionPrice - y.solutionPrice;
                                    }).find(function (x) {
                                        return x.direction === 1;
                                    });
                                } else {
                                    self.flightStore.inboundFlight = newFlights.find(function (x) {
                                        return x.id == self.flightStore.inboundFlightId;
                                    });
                                }
                            }
                        }

                        //self.applySearchHotelByBestCheckInDate();
                        self.loading.flightDetails = true;
                        self.flightLoadCompleted = true;
                        self.flightErrorMessage = null;
                        self.loading.flightPagination = false;
                        self.waitingProducts--;

                        // Force refresh hotels loading
                        self.forceRenderHotels();
                    },
                    error: function () {
                        self.hasErrorMessage = true;
                    }
                });
            },
            getStaticHotels(newPage, isUpdated = true, callback) {
                this.hotelStore.currentPage = newPage || 1;
                var parameters = jQuery.extend(true, {}, this.hotelsOptions);

                parameters.packageId = this.packageQuery.id;
                parameters.pageIndex = this.hotelStore.currentPage;
                parameters.pageSize = this.hotelStore.pageSize;
                if (parameters.pageIndex === 1 && !isUpdated) {
                    this.loading.hotelResult = false;
                } else {
                    this.loading.hotelPagination = true;
                }

                // Process sorting
                if (parameters.sortOrderBy.indexOf(";") > -1) {
                    var split = parameters.sortOrderBy.split(";");
                    parameters.sortOrderBy = split[0];
                    parameters.sortOrderByAsc = split[1] === "ASC";
                }

                var self = this;

                $.ajax({
                    url: '/package/get-static-hotels',
                    data: parameters,
                    type: 'POST',
                    success: function (data) {
                        self.loading.hotelResult = true;
                        if (!data.hotels || data.hotels.length == 0) {
                            self.hotelStore.hotels = [];
                            if (self.loading.hotelFirstLoad) {
                                self.hotelErrorMessage = data.errorMessage;
                            } else {
                                self.notifyErrorMessage(data.errorMessage);
                            }
                            return;
                        }

                        for (var i = 0; i < data.hotels.length; i++) {
                            var hotel = data.hotels[i];
                            self.prepareHotel(hotel);
                        }

                        if (parameters.pageIndex > 1) {
                            self.hotelStore.hotels.push(...data.hotels);
                        } else {
                            self.hotelStore.hotels = data.hotels;
                        }

                        if (self.cheapestHotel) {
                            self.cheapestHotel = false;
                        }
                        if (isUpdated) {
                            self.hotelSelected = self.hotelStore.hotels[0];
                        }
                        if (data.hotels && data.hotels.length == 1) {
                            window.selectedHotel = hotel;
                        }

                        self.hotelStore.totalFilteredHotels = data.totalFiltedHotels;
                        if (data.totalHotels % self.hotelStore.pageSize === 0) {
                            self.hotelStore.totalPages = data.totalFiltedHotels / self.hotelStore.pageSize;
                        } else {
                            self.hotelStore.totalPages = parseInt(data.totalFiltedHotels / self.hotelStore.pageSize) + 1;
                        }

                        self.loading.hotelFirstLoad = true;
                        self.hotelErrorMessage = null;
                        self.loading.hotelPagination = false;

                        if (self.hotelStore.hotels.length > 0) {
                            self.hideSplashScreen();
                        }

                        if (callback) {
                            callback();
                        }

                        self.movetoRegion();
                        self.getTrustyouData(self.hotelStore.hotels);
                    }
                });
            },
            getHotels() {
                if (!this.hotelStore.hotels || this.hotelStore.hotels.length === 0) {
                    this.getStaticHotels(1);
                    return;
                }

                var hotelIds = this.hotelStore.hotels.map(x => x.hotelId);
                var self = this;

                $.ajax({
                    url: '/package/get-hotels',
                    data: {
                        packageId: this.packageQuery.id,
                        hotelIds: hotelIds
                    },
                    traditional: true,
                    type: 'POST',
                    success: function (data) {
                        if (data.hotels && data.hotels.length > 0) {
                            if (!self.hotelSelected || self.hotelSelected.cheapestPrice == 0) self.hotelSelected = data.hotels[0];
                        }
                        // Fill hotels price
                        for (var i = 0; i < data.hotels.length; i++) {
                            var hotel = data.hotels[i];

                            var originHotel = self.hotelStore.hotels.find(function (x) {
                                return x.hotelId === hotel.hotelId;
                            });

                            if (originHotel) {
                                self.prepareHotel(hotel);
                                originHotel.cheapestPrice = hotel.cheapestPrice;
                                originHotel.availableRooms = hotel.availableRooms;
                                originHotel.priorityMessage1 = hotel.priorityMessage1;
                                originHotel.priorityMessage2 = hotel.priorityMessage2;
                                originHotel.priorityMessage3 = hotel.priorityMessage3;
                            }
                        }

                        self.hideSplashScreen();
                    }
                });
            },
            prepareHotel(hotel) {
                if (hotel && hotel.availableRooms) {
                    hotel.specialOffers = [];
                    for (var j = 0; j < hotel.availableRooms.length; j++) {

                        for (var k = 0; k < hotel.availableRooms[j].availableRoomTypes.length; k++) {
                            var availableRoomType = hotel.availableRooms[j].availableRoomTypes[k];
                            if (k === 0) {
                                availableRoomType.selected = true;
                            } else {
                                availableRoomType.selected = false;
                            }

                            if (availableRoomType.specialOffers && availableRoomType.specialOffers.length > 0) {
                                for (var l = 0; l < availableRoomType.specialOffers.length; l++) {
                                    hotel.specialOffers.push(availableRoomType.specialOffers[l]);
                                }
                            }
                        }
                    }
                }
            },
            getHotelFilters() {
                var self = this;
                $.ajax({
                    url: '/package/get-hotel-filters',
                    data: {
                        packageId: this.packageQuery.id
                    },
                    traditional: true,
                    type: 'POST',
                    success: function (data) {
                        self.processHotelFilters(data);
                    }
                });
            },
            processHotelFilters(data) {
                if (!data) return;

                this.hotelStore.minPrice = this.hotelsOptions.minPrice = data.minPrice;
                this.hotelStore.maxPrice = this.hotelsOptions.maxPrice = data.maxPrice;
                this.hotelStore.totalHotels = data.totalHotels;

                // Hard code number of stars, as we always want to show 5 different options
                var stars = ['1', '2', '3', '4', '5'];

                this.hotelStore.stars = stars;
                this.hotelStore.facilities = data.facilities;
            },
            forceRenderHotels() {
                for (var i = 0; i < this.hotelStore.hotels.length; i++) {
                    var hotel = this.hotelStore.hotels[i];
                    Vue.set(this.hotelStore.hotels, i, hotel);
                }
            },
            getTrustyouData(hotels) {
                var self = this;
                self.loading.hotelReview = false;
                var goquoHotelIds = [];
                for (var i = 0; i < hotels.length; i++) {

                    // HACK: Filter out custom HMS hotels as api will return 500 error if there are more than 2 HMS hotel requests.
                    // HMS hotel requests can be removed because no TY data will return anyway
                    if (hotels[i].hotelId.indexOf('HMS') >= 0) { continue; }

                    goquoHotelIds.push(hotels[i].hotelId);
                }
                if (goquoHotelIds.length === 0) {
                    return;
                }
                $.ajax({
                    url: 'https://hotelinfonew.goquo.com/trustyou/v1/' + goquoHotelIds.toString(),
                    type: 'GET',
                    success: function (data) {
                        for (var j = 0; j < hotels.length; j++) {
                            var hotel = hotels[j];
                            var dataIndex = data.map(
                                function (hotelData) { if (hotelData) { return hotelData.id + "" } else { return "000" } }
                            ).indexOf(hotel.hotelId);

                            if (dataIndex !== -1 && data[dataIndex].data.score > 0) {
                                Vue.set(hotel, 'trustyou', data[dataIndex].data);
                                var reviewCircle = 300 - (data[dataIndex].data.score * 3);
                                Vue.set(hotel, 'reviewCircleScore', reviewCircle);
                            }
                        }
                        self.loading.hotelReview = true;

                        self.onTrustYouComplete(data);
                    },
                    error: function (status) {

                    }
                });
            },
            onTrustYouComplete(data) { },
            getRegions() {
                var self = this;
                $.ajax({
                    type: 'POST',
                    data: {
                        packageId: this.packageQuery.id
                    },
                    url: '/package/get-regions',
                    success: function (data) {
                        self.hotelStore.importantLocations = data;
                    }
                });
            },
            onFiltersChanged() {
                // slideUp toggle for hotel detail
                var hotelDetails = $(".avai-hotel .fh-tabs__overview .fh-tabs__detail");
                if (typeof hotelDetails !== 'undefined' && hotelDetails.length > 0) {
                    hotelDetails.collapse('hide');
                }
                this.getStaticHotels(1);
                this.backTop();
            },
            backTop() {
                $('html,body').animate({
                    scrollTop: 0
                }, 'slow');
            },
            onPageChanged(page) {
                this.getStaticHotels(page, false);
            },
            setSortOrderBy(orderBy) {
                let orderByText = orderBy || this.hotelsOptions.sortOrderBy;
                if (orderByText.indexOf(";") !== -1) {
                    if (orderByText === 'Priority') {
                        this.hotelsOptions.sortOrderBy = 'Priority';
                        this.hotelsOptions.sortOrderByAsc = false;
                    } else {
                        if (this.hotelsOptions.sortOrderBy === orderByText) {
                            this.hotelsOptions.sortOrderByAsc = !this.hotelsOptions.sortOrderByAsc;
                        } else {
                            this.hotelsOptions.sortOrderBy = orderByText;
                        }
                    }
                }
                this.getStaticHotels(1, false);
            },
            totalPackagePrice(hotel) {
                var price = this.totalPackagePriceValue(hotel);

                if (price === 0) {
                    return "-";
                }
                return (price.toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            totalPackagePriceValue(hotel) {
                if (hotel.cheapestPrice === 0) {
                    return 0;
                }

                if (this.enabledFlights && !this.flightStore.outboundFlight) {
                    return 0;
                }

                if (!hotel.availableRooms) {
                    return 0;
                }

                var price = 0;
                for (var j = 0; j < hotel.availableRooms.length; j++) {
                    for (var k = 0; k < hotel.availableRooms[j].availableRoomTypes.length; k++) {
                        var availableRoomType = hotel.availableRooms[j].availableRoomTypes[k];
                        if (availableRoomType.selected) {
                            price += availableRoomType.totalPrice;
                            break;
                        }
                    }
                }
                price += this.totalFlightPrice();

                return price;
            },
            totalFlightPrice() {
                var price = 0;
                if (this.flightStore.outboundFlight)
                    price += this.flightStore.outboundFlight.solutionPrice;
                if (this.flightStore.inboundFlight) {
                    var priceChanged = this.flightStore.inboundFlight.solutionPrice - this.flightStore.outboundFlight.solutionPrice;
                    if (priceChanged != 0)
                        price += priceChanged;
                }
                return price;
            },
            toggleMapView() {
                if (!this.enabledMapView) {
                    return;
                }

                this.showMapView = !this.showMapView;

                if (this.showMapView) {
                    this.renderMap();
                } else {
                    this.showMapFull = false;
                }
            },
            toggleFilter() {
                $("#filterPanelResult .filter-body").toggleClass('is-open');
            },
            showHotelMapView(hotel) {
                window.selectedHotel = hotel;
                this.showMapFull = true;
                this.showMapView = true;
                this.renderMap();
                this.movetoLocation(hotel.latitude, hotel.longitude);
            },
            renderMap() {
                var sefl = this;
                sefl.dataViewMap.hotels = sefl.hotelStore.hotels;
                var map = document.getElementById("mapBox").contentWindow;
                if (sefl.mapViewRendered) {
                    map.postMessage(sefl.dataViewMap, '*');
                    return;
                }
                sefl.mapViewRendered = true;
                $("#mapBox").attr("src", "/package/map-view/" + sefl.packageQuery.id);
                $('iframe').load(function () {
                    map.postMessage(sefl.dataViewMap, '*');
                });
            },
            movetoRegion() {
                if (this.hotelStore.hotels && this.hotelStore.hotels.length > 0) {
                    for (var i = 0; i < this.hotelStore.hotels.length; i++) {
                        var h = this.hotelStore.hotels[i];
                        if (isValidCoordinate(h.latitude, h.longitude)) {
                            this.movetoLocation(h.latitude, h.longitude);
                            return;
                        }
                    }
                } else {
                    // var map = document.getElementById("mapBox").contentWindow;
                    // this.dataViewMap.hotels = this.hotelStore.hotels;
                    // map.postMessage(this.dataViewMap, '*');
                }

                window.top.mapPos = null;
            },
            movetoLocation(lat, lon) {
                var map = document.getElementById("mapBox") ? document.getElementById("mapBox").contentWindow : null;
                if (map) {
                    window.top.mapPos = {
                        zoom: 12,
                        latitude: lat,
                        longitude: lon
                    };

                    this.dataViewMap.hotels = this.hotelStore.hotels;
                    map.postMessage(this.dataViewMap, '*');

                    if (map.hasOwnProperty("movetoLocation")) {
                        map.movetoLocation(lat, lon, 12);
                    } else {
                        window.mapviewActionQueue.push(function () {
                            //map.movetoLocation(lat, lon, 12);
                        });
                    }
                }
            },
            resetFilter() {
                window.selectedHotel = null;
                while (this.hotelsOptions.facilities.length > 0) {
                    this.hotelsOptions.facilities.pop();
                }
                this.hotelsOptions.regionId = null;
                this.onFiltersChanged();
            },
            clearSelection(fieldName, event) {
                event.preventDefault();
                $(fieldName).trigger('click');
                return false;
            },
            isInt(value) {
                return !isNaN(value) && (function (x) {
                    return (x | 0) === x;
                })(parseFloat(value))
            },
            clearStars(star, event) {
                event.preventDefault();
                $("#" + star + "star").trigger('click');
                return false;
            },
            calculateNights() {
                var oneDay = 24 * 60 * 60 * 1000;
                var checkinDate = Date.parse(this.packageQuery.checkIn ? this.packageQuery.checkIn : this.packageQuery.departureDate);
                var checkoutDate = Date.parse(this.packageQuery.checkOut ? this.packageQuery.checkOut : this.packageQuery.returnDate);
                var nights = Math.round(Math.abs((checkoutDate - checkinDate) / (oneDay)));
                return nights;
            },
            submitForm() {
                if (this.model.from == this.model.to) {
                    $('#notifySelectDestination').modal('toggle');
                } else {
                    $('#fFlightHotelSearch').submit();
                }
            },
            onHotelSelectedChange(hotel) {
                this.hotelSelected = hotel;
                if (!this.enabledFlights) this.gotoHotelInfoPage(this.hotelSelected.url);
            },
            onFlightChanged(flight) {
                var self = this;
                if (flight.direction == 0) {
                    self.flightStore.outboundFlight = flight;
                    self.flightStore.inboundFlight = null;
                    self.flightStore.inboundFlights = [];

                    self.showOutboundFlights = false;
                    self.flightStore.inboundFilters.pageIndex = 1;
                    self.flightStore.inboundFilters.outboundFilter = { flightKey: flight.key };
                    self.flightStore.inboundAggreation.airlines.forEach(function (x) {
                        x.selected = false;
                    });
                    self.getFlights(self.flightStore.inboundFilters);
                } else {
                    self.flightStore.inboundFlight = flight;
                }
                //self.applySearchHotelByBestCheckInDate();
            },
            formatPrice(price) {
                return (price.toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',')
            },
            onShowPriceSummaryPaneHotel(hotelPrice) {
                this.calculatePriceSummary(hotelPrice);
            },
            onShowPriceSummaryPaneFlight(flight) {
                this.calculatePriceSummary(flight);
            },
            removeFilter(event, field) {
                switch (field) {
                    case 'name':
                        this.hotelsOptions.hotelName = null;
                        $('.sidebar__search .ipt-search').val('');
                        break;
                    case 'price':
                        this.hotelsOptions.minPrice = this.hotelStore.minPrice;
                        this.hotelsOptions.maxPrice = this.hotelStore.maxPrice;
                        break;
                    case 'star':
                        this.hotelsOptions.stars = [];
                        break;
                    case 'region':
                        delete this.hotelsOptions.regionName;
                        delete this.hotelsOptions.latitude;
                        delete this.hotelsOptions.longitude;
                        this.hotelsOptions.regionId = undefined;
                        this.hotelsOptions.minDistance = 0;
                        this.hotelsOptions.maxDistance = 5;
                        break;
                    case 'facilities':
                        this.hotelsOptions.facilities = [];
                        break;
                }
                this.getStaticHotels(this.hotelStore.currentPage);
            },
            removeFilters(obj) {
                this.removeFilter(obj.event, obj.field);
            },
            removeAllFilters(e) {
                let self = this;
                let fields = ['name', 'price', 'star', 'region', 'facilities'];
                fields.map(field => {
                    self.removeFilter(e, field);
                });
            },
            changeHotelMapSelected(hotel) {
                // if (!this.enabledFlights) {
                //     this.hotelSelected = hotel;
                // } else {
                this.hotelMapSelected = hotel;
                //}
            },
            togglePane(obj) {
                if (!obj.isClosed) $(obj.element).toggleClass('is-open').promise().done(function () {
                    if ($(obj.element).hasClass('is-open')) {
                        $('.sidebar-overlay').addClass('is-active');
                        $('body').addClass('modal-open');
                    } else {
                        $('.sidebar-overlay').removeClass('is-active');
                        $('body').removeClass('modal-open');
                    }
                });
                else {
                    $(obj.element).removeClass('is-open').promise().done(function () {
                        $('.sidebar-overlay').removeClass('is-active');
                        $('body').removeClass('modal-open');
                    });
                }
            },
            onFlightPaginationChanged(pageIndex) {
                if (this.showOutboundFlights) {
                    this.flightStore.outboundFilters.pageIndex = pageIndex;
                    this.getFlights(this.flightStore.outboundFilters);
                }
                else {
                    this.flightStore.inboundFilters.pageIndex = pageIndex;
                    this.getFlights(this.flightStore.inboundFilters);
                }
            },
            sortFlights(options) {
                if (this.showOutboundFlights) {
                    this.flightStore.outboundFilters.pageIndex = 1;
                    this.flightStore.outboundFilters.sortBy = options.newSortBy;
                    this.flightStore.outboundFilters.sortByDesc = options.newSortByDesc;
                    this.getFlights(this.flightStore.outboundFilters);
                }
                else {
                    this.flightStore.inboundFilters.pageIndex = 1;
                    this.flightStore.inboundFilters.sortBy = options.newSortBy;
                    this.flightStore.inboundFilters.sortByDesc = options.newSortByDesc;
                    this.getFlights(this.flightStore.inboundFilters);
                }
            },
            filterByAirlines(airlines) {
                if (this.showOutboundFlights) {
                    var airlines = this.flightStore.outboundAggreation.airlines.filter(x => x.selected == true).map(x => x.key);

                    if (!this.flightStore.outboundFilters.outboundFilter) {
                        this.flightStore.outboundFilters.outboundFilter = {};
                    }

                    this.flightStore.outboundFilters.pageIndex = 1;
                    this.flightStore.outboundFilters.outboundFilter.airlineCodes = airlines;
                    this.getFlights(this.flightStore.outboundFilters);
                }
                else {
                    var airlines = this.flightStore.inboundAggreation.airlines.filter(x => x.selected == true).map(x => x.key);

                    if (!this.flightStore.inboundFilters.inboundFilter) {
                        this.flightStore.inboundFilters.inboundFilter = {};
                    }

                    this.flightStore.inboundFilters.pageIndex = 1;
                    this.flightStore.inboundFilters.inboundFilter.airlineCodes = airlines;
                    this.getFlights(this.flightStore.inboundFilters);
                }
            },
            filterByNumberOfStops() {
                var stops = [];
                if (this.showOutboundFlights) {

                    if (this.flightStore.outboundAggreation.nonStop == false || this.flightStore.outboundAggreation.oneStop == false || this.flightStore.outboundAggreation.hasStops == false) {
                        if (this.flightStore.outboundAggreation.nonStop) {
                            stops.push("0");
                        }

                        if (this.flightStore.outboundAggreation.oneStop) {
                            stops.push("1");
                        }

                        if (this.flightStore.outboundAggreation.hasStops) {
                            stops.push("2,3,4,5");
                        }
                    }

                    if (!this.flightStore.outboundFilters.outboundFilter) {
                        this.flightStore.outboundFilters.outboundFilter = {};
                    }

                    this.flightStore.outboundFilters.pageIndex = 1;
                    this.flightStore.outboundFilters.outboundFilter.stops = stops.join(",");
                    this.getFlights(this.flightStore.outboundFilters);
                }
                else {

                    if (this.flightStore.inboundAggreation.nonStop == false || this.flightStore.inboundAggreation.oneStop == false || this.flightStore.inboundAggreation.hasStops == false) {
                        if (this.flightStore.inboundAggreation.nonStop) {
                            stops.push("0");
                        }

                        if (this.flightStore.inboundAggreation.oneStop) {
                            stops.push("1");
                        }

                        if (this.flightStore.inboundAggreation.hasStops) {
                            stops.push("2,3,4,5");
                        }
                    }

                    if (!this.flightStore.inboundFilters.inboundFilter) {
                        this.flightStore.inboundFilters.inboundFilter = {};
                    }

                    this.flightStore.inboundFilters.pageIndex = 1;
                    this.flightStore.inboundFilters.inboundFilter.stops = stops.join(",");
                    this.getFlights(this.flightStore.inboundFilters);
                }
            },
            onDepartureTimesChanged(times) {
                if (this.showOutboundFlights) {
                    if (!this.flightStore.outboundFilters.outboundFilter) {
                        this.flightStore.outboundFilters.outboundFilter = {};
                    }

                    this.flightStore.outboundFilters.pageIndex = 1;
                    this.flightStore.outboundFilters.outboundFilter.minDepartureTime = times.min;
                    this.flightStore.outboundFilters.outboundFilter.maxDepartureTime = times.max;
                    this.getFlights(this.flightStore.outboundFilters);
                }
                else {
                    if (!this.flightStore.inboundFilters.inboundFilter) {
                        this.flightStore.inboundFilters.inboundFilter = {};
                    }

                    this.flightStore.inboundFilters.pageIndex = 1;
                    this.flightStore.inboundFilters.inboundFilter.minDepartureTime = times.min;
                    this.flightStore.inboundFilters.inboundFilter.maxDepartureTime = times.max;
                    this.getFlights(this.flightStore.inboundFilters);
                }
            },
            onArrivalTimesChanged(times) {
                if (this.showOutboundFlights) {
                    if (!this.flightStore.outboundFilters.outboundFilter) {
                        this.flightStore.outboundFilters.outboundFilter = {};
                    }

                    this.flightStore.outboundFilters.pageIndex = 1;
                    this.flightStore.outboundFilters.outboundFilter.minArrivalTime = times.min;
                    this.flightStore.outboundFilters.outboundFilter.maxArrivalTime = times.max;
                    this.getFlights(this.flightStore.outboundFilters);
                }
                else {
                    if (!this.flightStore.inboundFilters.inboundFilter) {
                        this.flightStore.inboundFilters.inboundFilter = {};
                    }

                    this.flightStore.inboundFilters.pageIndex = 1;
                    this.flightStore.inboundFilters.inboundFilter.minArrivalTime = times.min;
                    this.flightStore.inboundFilters.inboundFilter.maxArrivalTime = times.max;
                    this.getFlights(this.flightStore.inboundFilters);
                }
            },
            resetFilters() {
                this.flightStore.inboundFilters = {
                    direction: 'InBound',
                    pageIndex: 1,
                    pageSize: 10,
                    sortBy: "SolutionPrice",
                    sortByDesc: false,
                    inboundFilter: {
                        minDepartureTime: "00:00",
                        maxDepartureTime: "24:00",
                        minArrivalTime: "00:00",
                        maxArrivalTime: "24:00"
                    },
                    packageId: this.packageQuery.id
                };
                this.flightStore.inboundAggreation.airlines.forEach(function (x) {
                    x.selected = false;
                });
                this.flightStore.inboundAggreation.hasStops = false;
                this.flightStore.inboundAggreation.nonStop = false;

                this.flightStore.outboundFilters = {
                    direction: 'OutBound',
                    pageIndex: 1,
                    pageSize: 10,
                    sortBy: "SolutionPrice",
                    sortByDesc: false,
                    outboundFilter: {
                        minDepartureTime: "00:00",
                        maxDepartureTime: "24:00",
                        minArrivalTime: "00:00",
                        maxArrivalTime: "24:00"
                    },
                    packageId: this.packageQuery.id
                };
                this.flightStore.outboundAggreation.airlines.forEach(function (x) {
                    x.selected = false;
                });
                this.flightStore.outboundAggreation.hasStops = false;
                this.flightStore.outboundAggreation.nonStop = false;
            },
            clearOutbound() {
                this.showOutboundFlights = true;
                this.resetFilters();
                this.getFlights(this.flightStore.outboundFilters);
            },
            formatPrice(price) {
                return (price.toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',')
            },
            getBestCheckInDate() {
                var self = this;
                if (!self.siteInfo || !self.siteInfo.cutOffTime || !self.flightStore.outboundFlight)
                    return;

                var arrivalOutboundDate = new moment.utc(self.flightStore.outboundFlight.arrivalDate);
                var arrivalOutboundTime = new moment.utc(new moment.utc(self.flightStore.outboundFlight.arrivalDate).format("HH:mm"), "HH:mm");
                var cutOffTime = new moment.utc(self.siteInfo.cutOffTime, "HH:mm");

                var arrivalDateWithoutTime = new moment.utc(self.flightStore.outboundFlight.arrivalDate).set({
                    hour: 0, minute: 0, second: 0, millisecond: 0
                });
                var checkinDateWithoutTime = new moment.utc(self.packageQuery.checkIn || self.packageQuery.departureDate).set({
                    hour: 0, minute: 0, second: 0, millisecond: 0
                });
                var bestCheckInDate;
                var canNewCheckIn = new moment.utc(self.flightStore.outboundFlight.arrivalDate).subtract(1, "days");
                var canNewCheckInWithOutTime = new moment.utc(canNewCheckIn).set({
                    hour: 0, minute: 0, second: 0, millisecond: 0
                });

                if (!self.model.partialStay) {
                    if (arrivalOutboundTime.isSameOrBefore(cutOffTime, 'times')) {
                        if (checkinDateWithoutTime.isSame(canNewCheckInWithOutTime)) {
                            return;
                        }
                        else {
                            bestCheckInDate = canNewCheckIn;
                        }
                    }
                    else {
                        if (arrivalDateWithoutTime.isSame(checkinDateWithoutTime)) {
                            return;
                        } else {
                            bestCheckInDate = arrivalOutboundDate;
                        }
                    }
                }
                else {
                    var selectedCheckinDate = new moment.utc(self.checkInUrl);
                    var selectedCheckinDateWithoutTime = new moment.utc(self.checkInUrl).set({
                        hour: 0, minute: 0, second: 0, millisecond: 0
                    });

                    if (arrivalOutboundTime.isSameOrBefore(cutOffTime, 'times')) {
                        if (checkinDateWithoutTime.isSameOrAfter(canNewCheckInWithOutTime)) {
                            if (checkinDateWithoutTime.isSame(selectedCheckinDateWithoutTime)) {
                                return;
                            }
                            else {
                                if (selectedCheckinDateWithoutTime.isBefore(arrivalDateWithoutTime)) {
                                    bestCheckInDate = canNewCheckIn;
                                }
                                else {
                                    bestCheckInDate = selectedCheckinDate;
                                }
                            }
                        }
                        else {
                            bestCheckInDate = canNewCheckIn;
                        }

                    }
                    else {

                        if (checkinDateWithoutTime.isSameOrAfter(arrivalDateWithoutTime)) {
                            if (checkinDateWithoutTime.isSame(selectedCheckinDateWithoutTime)) {
                                return;
                            }
                            else {
                                if (selectedCheckinDateWithoutTime.isBefore(arrivalDateWithoutTime)) {
                                    bestCheckInDate = arrivalOutboundDate;
                                } else {
                                    bestCheckInDate = selectedCheckinDate;
                                }
                            }
                        }
                    }
                }
                return bestCheckInDate;
            },
            applySearchHotelByBestCheckInDate() {
                var self = this;
                var newCheckInDate = self.getBestCheckInDate();
                if (!newCheckInDate) {
                    return;
                }

                self.packageQuery.checkIn = new moment.utc(newCheckInDate).format("YYYY-MM-DD");
                self.packageQuery.checkOut = new moment.utc(self.packageQuery.checkOut || self.packageQuery.returnDate).format("YYYY-MM-DD");
                self.researchHotel(self.packageQuery.id, self.packageQuery.checkIn, self.packageQuery.checkOut);
            },
            researchHotel(packageId, checkInDate, checkOutDate) {
                var self = this;
                $.ajax({
                    url: "/package/research-hotel",
                    data: {
                        packageId: packageId,
                        checkInDate: checkInDate,
                        checkOutDate: checkOutDate
                    },
                    type: "POST",
                    beforeSend: function () {
                    },
                    success: function (data) {
                        if (data.status) {
                            var key = moment(checkInDate).format('YYYYMMDD') + "-" + moment(checkOutDate).format('YYYYMMDD');
                            //reset abortPing
                            self.abortPing = false;
                            self.pingCount = 0;
                            self.createPingRequest(key, true);
                        }
                    },
                    error: function () {
                        self.hasErrorMessage = true;
                    }
                });
            },
            funcScrollTabs() {
                var current = $(window).scrollTop();
                var i = $("#change-products-tabs");
                var n = i.find("> .nav-tabs");
                var h = i.offset() ? i.offset().top : 0;
                if (current > h) {
                    n.addClass("sticky");
                } else {
                    n.removeClass("sticky");
                }
            },
            scrollTabsSelected() {
                var self = this;
                $(window).on('scroll', _.throttle(function () {
                    if ($(window).width() < 768) self.funcScrollTabs();
                }, 100))
            },
            getUrlParam(parameter, defaultvalue) {
                var urlparameter = defaultvalue;
                if (window.location.href.indexOf(parameter) > -1) {
                    urlparameter = this.getUrlVars()[parameter];
                }
                return urlparameter;
            },
            getUrlVars() {
                var vars = {};
                var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function (m, key, value) {
                    vars[key] = value;
                });
                return vars;
            },
            showIconClassFacility(facKey) {
                var self = this;
                var classFac = '';
                self.hotelStore.iconClassFacilities.forEach(function (x) {
                    if (x.key === facKey) classFac = x.value;
                });
                return classFac;
            },
            setClassFacilities() {
                var self = this;
                self.hotelStore.iconClassFacilities = [{ key: 'AC', value: 'air-conditioner' },
                    { key: 'BU', value: 'business-person' },
                    { key: 'FIN', value: 'free-wifi' },
                    { key: 'IN', value: 'wifi' },
                    { key: 'INS', value: 'INS' },
                    { key: 'GY', value: 'gym' },
                    { key: 'ME', value: 'meeting-room' },
                    { key: 'PA', value: 'parking' },
                    { key: 'RE', value: 'restaurant' },
                    { key: 'RO', value: 'room-service' },
                    { key: 'SKR', value: 'smoking-area' },
                    { key: 'SP', value: 'spa' },
                    { key: 'SW', value: 'swimming' }];
            },
            formatDate(date, format) {
                return moment.utc(date).format(format);
            }
        },
        watch: {
            isSearchCompleted: function (val) {
                var self = this;
                if (val) {
                    self.calculateTotalPackagePrice(this.cheapestHotel);
                }
            },
            cheapestHotelPrice(val) {
                let self = this;
                if (val) {
                    var previousSearches = Cookie.getJSON('recentSearches') || [];
                    if (previousSearches.length > 0) previousSearches = previousSearches.filter(pre => {
                        return pre.fromCode !== self.packageQuery.from || pre.toCode !== self.packageQuery.to || pre.departureDate !== self.packageQuery.departureDate || pre.returnDate !== self.packageQuery.returnDate || pre.passengers !== self.calculatePaxCount
                    });
                    if (previousSearches.length > 3) {
                        previousSearches.splice(0, 1);
                    }
                    previousSearches.push({
                        id: self.packageQuery.productId,
                        from: self.packageQuery.fromCityName,
                        fromCode: self.packageQuery.from,
                        to: self.packageQuery.toCityName,
                        toCode: self.packageQuery.to,
                        thumbnail: self.hotelCheapest && self.hotelCheapest.imageInfos.length > 0 ? self.hotelCheapest.imageInfos[0].url : self.baseUrl + '/images/avai-pic.jpg',
                        product: self.product.type,
                        departureDate: self.packageQuery.departureDate,
                        returnDate: self.packageQuery.returnDate,
                        passengers: self.calculatePaxCount,
                        price: self.cheapestHotelPrice,
                        url: self.packageQuery.requestUrl,
                        currency: self.packageQuery.currency
                    });
                    Cookie.set('recentSearches', previousSearches, { expires: 1 });
                    // console.log(Cookie.getJSON('recentSearches'));
                }
            },
            "flightStore.outboundFlight" : function(val) {
                var self = this;
                if (val) {
                    self.applySearchHotelByBestCheckInDate();
                }
            },
            "hotelStore.hotels": function (val) {
                let self = this;
                if (val && val.length > 0 && val[0].cheapestPrice > 0) self.isSearchCompleted = true;

                // if (val && val.length > 0 && val[0].cheapestPrice === 0) {
                //     _.debounce(function () {
                //         self.getStaticHotels(self.hotelStore.currentPage);
                //         self.getHotelFilters();
                //     }, 5000)();
                // }
            },
            waitingProducts: function (newValue) {
                if (newValue == 0) {
                    this.isSearchCompleted = true;
                    this.$store.commit('setIsSearchCompleted');
                    console.log("isSearchCompleted");
                }
            },
            hasErrorMessage(value) {
                if (value)
                    $("#modalChangeDate").modal("hide")
            }
        }
    }
</script>
