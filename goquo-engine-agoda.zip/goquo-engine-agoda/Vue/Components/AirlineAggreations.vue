﻿<template>
    <div>
        <div class="airline-aggreations">
            <div class="col-xs-5 col-sm-3 col-md-2 airline-aggreations__header-text">
                <div class="airline-aggreations__header-item">
                    <p v-lang.AIRLINES></p>
                </div>
                <div class="airline-aggreations__header-item">
                    <p v-lang.NONSTOP></p>
                </div>
                <div class="airline-aggreations__header-item">
                    <p v-lang.ONE_PLUS_STOPS></p>
                </div>
            </div>
            <div class="col-xs-7 col-sm-9 col-md-10 airline-aggreations__item-wrapper" v-if="!flightFilterFirstLoad">
                <div class="airline-aggreations__left-arrow arrow-control" data-item="1" @click="moveSlide($event, 'prev')">
                    <span class="icon icon-left-chevron"></span>
                </div>
                <div class="airline-aggreations__item-slider-wrapper">
                    <div class="airline-aggreations__item-slider" :style="'width:' + sliderWidth + 'px'">
                        <div class="airline-aggreations__item" v-for="(airline, index) in airlineAggreations" v-bind:key="index">
                            <div class="airline-aggreations__logo">
                                <h5>{{airline.airlineName}}</h5>
                            </div>
                            <div class="airline-aggreations__nonstop-price">
                                <h5><a @click="filterFlightByAirline(airline.airlineCode, 0)" style="cursor: pointer;">{{airline.nonStopPrice ? packageQuery.currency + ' ' + airline.nonStopPrice : '&nbsp;'}}</a></h5>
                            </div>
                            <div class="airline-aggreations__stops-price">
                                <h5><a @click="filterFlightByAirline(airline.airlineCode, 1)" style="cursor: pointer;">{{airline.hasStopPrice ? packageQuery.currency + ' ' + airline.hasStopPrice : '&nbsp;'}}</a></h5>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="airline-aggreations__right-arrow arrow-control" data-item="1" @click="moveSlide($event, 'next')">
                    <span class="icon icon-right-chevron"></span>
                </div>
            </div>
            <div class="col-xs-7 col-sm-9 col-md-10 airline-aggreations__item-wrapper" v-if="flightFilterFirstLoad">
                <div class="airline-aggreations__left-arrow arrow-control">
                    <span class="icon icon-left-chevron"></span>
                </div>
                <div class="airline-aggreations__item-slider-wrapper">
                    <div class="airline-aggreations__item-slider">
                        <div class="airline-aggreations__item">
                            <div class="airline-aggreations__logo">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                            <div class="airline-aggreations__nonstop-price">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                            <div class="airline-aggreations__stops-price">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                        </div>
                        <div class="airline-aggreations__item">
                            <div class="airline-aggreations__logo">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                            <div class="airline-aggreations__nonstop-price">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                            <div class="airline-aggreations__stops-price">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                        </div>
                        <div class="airline-aggreations__item">
                            <div class="airline-aggreations__logo">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                            <div class="airline-aggreations__nonstop-price">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                            <div class="airline-aggreations__stops-price">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                        </div>
                        <div class="airline-aggreations__item">
                            <div class="airline-aggreations__logo">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                            <div class="airline-aggreations__nonstop-price">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                            <div class="airline-aggreations__stops-price">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                        </div>
                        <div class="airline-aggreations__item">
                            <div class="airline-aggreations__logo">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                            <div class="airline-aggreations__nonstop-price">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                            <div class="airline-aggreations__stops-price">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                        </div>
                        <div class="airline-aggreations__item">
                            <div class="airline-aggreations__logo">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                            <div class="airline-aggreations__nonstop-price">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                            <div class="airline-aggreations__stops-price">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="airline-aggreations__right-arrow arrow-control">
                    <span class="icon icon-right-chevron"></span>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</template>
<script>
    export default {
        props: ["airlineAggreations", "flightFilterFirstLoad", "packageQuery"],
        data() {
            return {
                sliderWidth: 2000
            }
        },
        methods: {
            moveSlide(event, direction) {
                event.preventDefault();
                event.stopImmediatePropagation();
                
                var $this = $(event.target);
                var airlineFilterSliderWrapper = $(".airline-aggreations__item-slider-wrapper").width();
                var airlineFilterSlider = $(".airline-aggreations__item-slider");
                var airlineFilterSliderItem = airlineFilterSlider.find(".airline-aggreations__item");
                var airlineFilterControls = $('.airline-aggreations .arrow-control');
                window.isFirstLoad = true;
                airlineFilterControls.removeClass('disabled');
                $this.addClass('disabled');
                
                if (typeof airlineFilterSlider !== 'undefined' && airlineFilterSlider.length > 0
                    && typeof airlineFilterSliderItem !== 'undefined' && airlineFilterSliderItem.length > 0
                    && typeof airlineFilterControls !== 'undefined' && airlineFilterControls.length > 0) {
                    var sliderItemWidth = airlineFilterSliderItem.outerWidth();
                    var rightLimitation = airlineFilterSliderItem.length - parseInt(airlineFilterSliderWrapper / sliderItemWidth);
                    var dataItem = parseInt($this.attr('data-item'));

                    if (window.isFirstLoad) {
                        airlineFilterSlider.css('width', sliderItemWidth * (airlineFilterSliderItem.length + 1) + 'px');
                        window.isFirstLoad = false;
                    }
                    
                    switch (direction) {
                        case 'next':
                            if (dataItem <= rightLimitation) {
                                airlineFilterSlider.css('transform', 'translate(-'+ (sliderItemWidth * dataItem) +'px, 0)');
                                setTimeout(function () {
                                    $this.removeClass('disabled');
                                    dataItem++;
                                    airlineFilterControls.attr('data-item', dataItem);
                                }, 500);
                            }
                            break;
                        case 'prev':
                            if (dataItem > 1) {
                                var currentSliderPosition = Math.abs(parseInt(airlineFilterSlider.css('transform').split(',')[4]));
                                airlineFilterSlider.css('transform', 'translate(-'+ (currentSliderPosition - sliderItemWidth)  +'px, 0)');
                                setTimeout(function () {
                                    $this.removeClass('disabled');
                                    dataItem--;
                                    airlineFilterControls.attr('data-item', dataItem);
                                }, 500);
                            }
                            break;
                        default:
                            break;
                    }
                }
                
                return false;
            },
            filterFlightByAirline: function (airlineCode, stops) {
                this.$emit('airlineChanged', airlineCode, stops);
            }
        }
    }
</script>