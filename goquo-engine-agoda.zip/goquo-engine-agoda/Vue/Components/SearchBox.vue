<template>
  <div>
      <div class="search-wrap">
          <div class="container">
              <div class="search-tabs"  >
                  <div class="search-head nav nav-tabs" role="tablist">
                      <a v-for="(product, index) in products" :class="index == 0 ? 'active' : ''" class="item-head-tabs nav-item nav-link" :href="'#product_' + product.id" role="tab" data-toggle="tab">
                          <i :class="product.iconCssClass" v-if="product.iconCssClass != null && product.iconCssClass.length > 0"></i>
                          <span>{{product.name}}</span>
                      </a>
                  </div>
                  <div class="search-body tab-content">
                      <div class="search-content tab-pane" role="tabpanel" :class="index == 0 ? 'active show':''" :id="'product_' + product.id" v-for="(product, index) in products">
                          <div v-if="product.type === 'Flight_Hotel' && isCompleted">
                              <FlightHotelSearchBox :packageQuery="packageQuery" :product="product" :defaultDate="defaultDate" cabinClass="1" :siteInfo="siteInfo" :clientResources="clientResources" />
                          </div>
                          <div v-if="product.type === 'Flight' && isCompleted">
                              <FlightSearchBox :packageQuery="packageQuery" :product="product" :defaultDate="defaultDate" :journeyType="1" cabinClass="1" :siteInfo="siteInfo" :clientResources="clientResources"/>
                          </div>
                          <div v-if="product.type === 'Hotel' && isCompleted">
                              <HotelSearchBox :packageQuery="packageQuery" :product="product" :defaultDate="defaultDate" :journeyType="1" :clientResources="clientResources"/>
                          </div>
                          <div v-if="product.type === 'Tour' && isCompleted">
                              <TourSearchBox :packageQuery="packageQuery" :product="product" :defaultDate="defaultDate" :journeyType="1" :clientResources="clientResources"/>
                          </div>
                          <div v-if="product.type === 'Transfer' && isCompleted">
                              <TransferSearchBox :packageQuery="packageQuery" :product="product" :defaultDate="defaultDate" :journeyType="1" :addedDates="true" :clientResources="clientResources"/>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="search-BackDrop" ></div>
          </div>
      </div>
      <section class="sec-home recent" v-if="recentSearches.length > 0">
          <div class="sec-content">
              <div class="container">
                  <h3 v-lang.RECENT_SEARCHES></h3>
                  <div class="benefit-home">
                      <div class="benefit-home__item" v-for="recent in recentSearches">
                          <div class="icon" :style="'background-image:url('+ recent.thumbnail +')'" :class="{'flight': recent.product === 'Flight'}">
                              <span class="product-icon">
                                  {{recent.product.replace('_', ' + ')}}
                              </span>
                          </div>
                          <div class="detail">
                              <strong>{{getRecentHeader(recent)}}</strong>
                              <span>
                                  <span class="info">
                                      <i class="icon-calendar"></i>
                                    <span>{{recent.departureDate | moment('DD MMM')}}
                                        <template v-if="recent.journeyType !== 'One-way'">
                                            - {{recent.returnDate | moment('DD MMM')}}
                                        </template>
                                    </span>
                                  </span>
                                  <span class="info">
                                      <i class="icon-user"></i>
                                    <span>{{recent.passengers}} {{recent.passengers > 1 ? translateText('PASSENGERS', 'Passengers') : translateText('PASSENGER', 'Passenger')}}</span>
                                  </span>
                                  <span class="info" v-if="recent.journeyType">
                                      <i class="icon-flight"></i>
                                    <span>{{recent.journeyType}}</span>
                                  </span>
                              </span>
                              <div class="recent-detail">
                                  <span>
                                      <small class="text-lowercase" v-lang.FROM></small>
                                      <strong class="price"><small>{{recent.currency}}</small> {{recent.price}}</strong>
                                  </span>
                                  <div>
                                      <a target="_blank" :href="recent.url" class="btn btn-primary bt-effect bt-selected" v-lang.SEARCH></a>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <template v-if="isPreciseTravels">
          <div class="precise" v-if="siteInfo">
              <section class="sec-home best-selling bgr-gray">
                  <div class="sec-content">
                      <div class="container">
                          <h3 class="title" v-lang.BEST_SELLING_DEALS></h3>
                          <div class="best-selling-home">
                              <div class="best-selling-home__item" v-for="n in 4">
                                  <div class="best-selling-home__item-bg" :style="'background-image: url(' + baseUrl + '/images/home/best-selling-' + n + '.jpg)'">
                                      <div class="best-selling-home__item-offer">
                                          <div class="best-selling-home__item-offer-left">
                                              <h4 class="best-selling-home__item-offer-left-title" v-lang.TRAVEL_NOW_PAY_LATER></h4>
                                              <p>
                                                  <i class="icon-clock"></i>
                                                  <span v-lang.TWO_DAYS_REMAINING></span>
                                              </p>
                                          </div>
                                          <div class="best-selling-home__item-offer-right">
                                              <p>
                                                  <span v-lang.USE_CODE></span>
                                                  <span class="promo-code">PRECISEOFF</span>
                                              </p>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </section>
              <section class="sec-home promo-banner">
                  <div class="sec-content">
                      <div class="container">
                          <a href="#">
                              <img :src="baseUrl + '/images/home/promo-banner.jpg'" alt="Precise Promo" />
                          </a>
                      </div>
                  </div>
              </section>
              <section class="sec-home trending">
                  <div class="sec-content">
                      <div class="container">
                          <h3 class="title" v-lang.TRENDING_AT></h3>
                          <div class="trending-home">
                              <div class="trending-home__item" v-for="des in destinations">
                                  <div class="trending-home__item-bg" :style="'background-image: url(' + baseUrl + '/images/home/' + des + '.jpg)'">
                                      <div class="trending-home__item-title">
                                          <h3>{{des}}</h3>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </section>
              <section class="sec-home why-choose-us bgr-gray">
                  <div class="sec-content">
                      <div class="container">
                          <h3 class="title" v-lang.WHY_CHOOSE_US></h3>
                          <p class="description" v-lang.HAPPY_CUSTOMERS></p>
                          <div class="benefit-home">
                              <div class="benefit-home__item">
                                  <div class="icon"><img :src="baseUrl + '/images/client-flight.png'" alt=""></div>
                                  <div class="detail" v-lang.PROMO_ONE></div>
                              </div>
                              <div class="benefit-home__item">
                                  <div class="icon"><img :src="baseUrl + '/images/price-tag.png'" alt=""></div>
                                  <div class="detail" v-lang.PROMO_TWO></div>
                              </div>
                              <div class="benefit-home__item">
                                  <div class="icon"><img :src="baseUrl + '/images/location-tag.png'" alt=""></div>
                                  <div class="detail" v-lang.PROMO_THREE></div>
                              </div>
                              <div class="benefit-home__item">
                                  <div class="icon"><img :src="baseUrl + '/images/free-tag.png'" alt=""></div>
                                  <div class="detail" v-lang.PROMO_FOUR></div>
                              </div>
                          </div>
                          <div class="sec-footer">
                              <h4 v-lang.REACH_US_ON></h4>
                              <div class="sec-footer__contacts">
                                  <a href="tel:123456789" class="btn btn-primary">
                                      <i class="icon-contact"></i>
                                      <strong v-lang.LINE_ONE></strong>:
                                      <span v-lang.PHONE_ONE></span>
                                  </a>
                                  <a href="tel:0987654321" class="btn btn-primary">
                                      <i class="icon-contact"></i>
                                      <strong v-lang.LINE_TWO></strong>:
                                      <span v-lang.PHONE_TWO></span>
                                  </a>
                                  <a href="tel:6781234589" class="btn btn-primary">
                                      <i class="icon-contact"></i>
                                      <strong v-lang.LINE_THREE></strong>:
                                      <span v-lang.PHONE_THREE></span>
                                  </a>
                              </div>
                          </div>
                      </div>
                  </div>
              </section>
          </div>
      </template>
      <template v-else>
          <section class="sec-home bgr-gray" v-if="siteInfo">
              <div class="sec-content">
                  <div class="container">
                      <div class="benefit-home">
                          <div class="benefit-home__item">
                              <div class="icon"><img :src="baseUrl + '/images/client-flight.png'" alt=""></div>
                              <div class="detail" v-lang.PROMO_ONE></div>
                          </div>
                          <div class="benefit-home__item">
                              <div class="icon"><img :src="baseUrl + '/images/price-tag.png'" alt=""></div>
                              <div class="detail" v-lang.PROMO_TWO></div>
                          </div>
                          <div class="benefit-home__item">
                              <div class="icon"><img :src="baseUrl + '/images/location-tag.png'" alt=""></div>
                              <div class="detail" v-lang.PROMO_THREE></div>
                          </div>
                          <div class="benefit-home__item">
                              <div class="icon"><img :src="baseUrl + '/images/free-tag.png'" alt=""></div>
                              <div class="detail" v-lang.PROMO_FOUR></div>
                          </div>
                      </div>
                  </div>
              </div>
          </section>
      </template>
  </div>
</template>

<script>
    import Vue from 'vue';
    import Cookie from 'js-cookie'
    import FlightHotelSearchBox from './FlightHotelSearchBox.vue'
    import FlightSearchBox from './FlightSearchBox.vue'
    import HotelSearchBox from './HotelSearchBox.vue'
    import TourSearchBox from './TourSearchBox.vue'
    import TransferSearchBox from './TransferSearchBox.vue'
    import { mapState } from 'vuex'

    export default {
        name: "SearchBox",
        data() {
            return {
                products: [],
                packageQuery: null,
                defaultDate: null,
                recentSearches: [],
                destinations: [
                    'japan', 'korea', 'malaysia', 'singapore', 'taiwan', 'thailand', 'vietnam'
                ],
                clientResources: null,
                isCompleted: false
            };
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            baseUrl: state => state.workContext.baseUrl,
            isPreciseTravels: state => {
                // return state.workContext.siteInfo ? state.workContext.siteInfo.name === "Precise Travels" : false
                return false;
            }
        }),
        created() {
            var self = this;
            $.post('/package/work-context', function (data) {
                data.baseUrl = $("#baseURL").val();
                self.$store.commit('setWorkContext', data);
                self.products = data.products;
                self.isComplete = true;

                $.getJSON(data.baseUrl + '/resources.json', function (res) {
                    data.clientResources = res;
                    self.clientResources = res;
                }).always(function () {
                    self.$store.commit('setWorkContext', data);
                    }).done(function (p) {
                        self.isCompleted = true;
                });
                // hide splash screen
                $('#app').removeClass('modal-open');

                setTimeout(function () {
                    $('#loading-page').addClass('hidden');

                    $('.best-selling .best-selling-home').slick({
                        infinite: true,
                        slidesToShow: 3,
                        slidesToScroll: 1,
                        dots: true,
                        responsive: [
                            {
                                breakpoint: 1024,
                                settings: {
                                    slidesToShow: 2
                                }
                            },
                            {
                                breakpoint: 768,
                                settings: {
                                    slidesToShow: 1,
                                    arrows: false
                                }
                            }
                        ]
                    });

                    $('.trending .trending-home').slick({
                        infinite: true,
                        slidesToShow: 4,
                        slidesToScroll: 1,
                        dots: true,
                        responsive: [
                            {
                                breakpoint: 1024,
                                settings: {
                                    slidesToShow: 2
                                }
                            },
                            {
                                breakpoint: 768,
                                settings: {
                                    slidesToShow: 1,
                                    arrows: false
                                }
                            }
                        ]
                    });
                }, 300);
            });

            var startDate = Vue.moment.utc().add(1, 'days').format('MM/DD/YYYY');
            var endDate = Vue.moment.utc().add(2, 'days').format('MM/DD/YYYY');

            this.defaultDate = startDate + ',' + endDate;
        },
        mounted() {
            let self = this;
            let recentSearches = Cookie.getJSON('recentSearches') || [];
            if (recentSearches.length > 0) self.recentSearches = recentSearches.reverse();
        },
        methods: {
            translateText(translateKey, defaultText, params) {
                return this.translate(this.$language, translateKey, params) || defaultText;
            },
            getRecentHeader(recent) {
                let txt = '';
                // {{recent.from}} ({{recent.fromCode}}) - {{recent.to}} ({{recent.toCode}})
                switch (recent.product) {
                    case 'Tour':
                        txt = 'Tours in ' + recent.to;
                        break;
                    case 'Hotel':
                        txt = 'Hotels in ' + recent.to;
                        break;
                    case 'Transfer':
                        txt = 'Transfers in ' + recent.to;
                        break;
                    default:
                        txt = recent.from + " - " + recent.to;
                        break;
                }
                return txt;
            }
        },
        components: {FlightHotelSearchBox, FlightSearchBox, HotelSearchBox, TourSearchBox, TransferSearchBox }
    }
</script>
