<template>
    <div class="modal fade" id="modalMapBox" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="maps__wrap">
                    <MapBoxFilters :hotelStore="hotelStore"
                                   :hotelsOptions="hotelsOptions"
                                   :flightStore="flightStore"
                                   :packageQuery="packageQuery"
                                   @changed="onFiltersChanged"
                                   :flightChangePrice="flightChangePrice"
                                   :isSearchCompleted="isSearchCompleted"/>
                    <div class="maps__wrap__sidebar">
                        <div class="maps-sb scroll-hoz">
                            <div class="maps-sb__find">
                                <div class="maps-sb__find__title">
                                    <strong v-if="!hasErrorMessage">{{hotelStore.hotels.length}} {{hotelStore.hotels.length > 1 ? 'properties' : 'property'}} available</strong>
                                    <div class="maps-sb__find__date"><i class="icon-calendar"></i><span>{{numNights}} ({{ packageQuery.departureDate| moment("DD MMM") }} - {{ packageQuery.returnDate| moment("DD MMM") }})</span></div>
                                </div>
                                <div class="maps-sb__find__row">
                                    <div class="avai-pills">
                                        <span class="avai-pills__item" v-if="hotelsOptions.hotelName"><span v-lang.HOTEL_NAME></span>: {{hotelsOptions.hotelName}} <i class="ico icon-remove" @click="removeFilter($event, 'name')"></i></span>
                                        <span class="avai-pills__item" v-if="(hotelsOptions.minPrice > hotelStore.minPrice || hotelsOptions.maxPrice < hotelStore.maxPrice) && hotelsOptions.maxPrice != hotelsOptions.minPrice">
                                                    <span v-lang.PRICE></span>: {{packageQuery.currency}} {{formatPrice(calculateTotalPrice(hotelsOptions.minPrice))}} - {{packageQuery.currency}} {{formatPrice(calculateTotalPrice(hotelsOptions.maxPrice))}}
                                                    <i class="ico icon-remove" @click="removeFilter($event, 'price')"></i>
                                                </span>
                                        <span class="avai-pills__item" v-if="hotelsOptions.stars.length > 0">
                                                    <span v-for="(star, starIndex) in getSelectedStars">{{star}}{{(starIndex + 1) == getSelectedStars.length ? '' : ', '}}</span>
                                                    <span>{{getSelectedStars.length > 1 ? ' stars': ' star'}}</span>
                                                    <i class="ico icon-remove" @click="removeFilter($event, 'star')"></i>
                                                </span>

                                        <span class="avai-pills__item" v-if="hotelsOptions.regionId && hotelsOptions.regionName">
                                                    <span>{{hotelsOptions.regionName}}: </span>
                                                    <span>{{hotelsOptions.minDistance}} - {{hotelsOptions.maxDistance}}km</span>
                                                    <i class="ico icon-remove" @click="removeFilter($event, 'region')"></i>
                                                </span>

                                        <span class="avai-pills__item" v-if="hotelsOptions.facilities.length > 0">
                                                    <span>{{hotelsOptions.facilities.length > 1 ? ' Facilities: ': 'Facility: '}}</span>
                                                    <span v-for="(fac, facIndex) in hotelsOptions.facilities"><span :class="'icon icon-' + setIconClassFacility(fac)"></span> {{(facIndex + 1) == hotelsOptions.facilities.length ? '' : ', '}}</span>
                                                    <i class="ico icon-remove" @click="removeFilter($event, 'facilities')"></i>
                                                </span>
                                    </div>
                                    <div class="maps-sb__find__sort"><span v-lang.SORT_BY></span>:
                                        <select class="form-control" name="#" :value="hotelsOptions.sortOrderBy" @change="setSortOrder($event)">
                                            <option value="Priority;DESC" selected v-lang.MOST_POPULAR></option>
                                            <option value="CheapestPrice;ASC" v-lang.PRICE_LOWEST></option>
                                            <option value="CheapestPrice;DESC" v-lang.PRICE_HIGHEST></option>
                                            <option value="Name;ASC" v-lang.NAME_A_TO_Z></option>
                                            <option value="Name;DESC" v-lang.NAME_Z_TO_A></option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div  v-if="hotelStore.hotels.length > 0">
                                <div class="maps-sb__list" id="maps-sb__list">
                                    <div class="maps-sb__item hotel"
                                         :class="{'js-active': hotel.hotelId == hotelSelected.hotelId && enabledFlights}"
                                         v-if="hotel.cheapestPrice > 0"
                                         @click="changeMapSelectedHotel(hotel)"
                                         v-for="(hotel, hotelIndex) in hotelStore.hotels"
                                         :key="hotelIndex" :id="hotel.hotelId"
                                         :hotelSelectedId="hotelSelected.hotelId"
                                         :data-lat="hotel.latitude"
                                         :data-lng="hotel.longitude"
                                         :data-title="hotel.name"
                                         :data-description="hotel.addressLines"
                                         :data-price="getAvgPrice(hotel)"
                                         :data-stars="hotel.stars"
                                         :data-trustyou-score="hotel.trustyou ? hotel.trustyou.score_display : ''"
                                         :data-trustyou-description="hotel.trustyou ? hotel.trustyou.score_description : ''"
                                         :data-trustyou-reviews_count="hotel.trustyou ? hotel.trustyou.reviews_count : ''"
                                         :data_url="hotel.imageInfos.length > 0 ? replaceImage(hotel.imageInfos[0].url) : image">
                                        <div class="picture" :title="hotel.name" :class="{'no-image': hotel.imageInfos.length == 0}" :style="{backgroundImage: `url('${hotel.imageInfos.length > 0 ? replaceImage(hotel.imageInfos[0].url) : image}')`}" ></div>
                                        <div class="detail">
                                            <h2 class="name">{{hotel.name}}</h2>
                                            <div class="title">
                                                <div class="rating">
                                                    <span class="icon-star" v-for="(star, starIndex) in Math.floor(hotel.stars)" :key="starIndex"></span>
                                                </div>
                                            </div>
                                            <div class="list-util">

                                                <i class="ico icon-location-arrow"></i>
                                                <span>{{hotel.addressLines}}</span>
                                            </div>
                                            <ul class="list-ruler-check">
                                                <li class="cancellation" v-if="hotel.availableRooms[0].availableRoomTypes[0].cancelFreeBeforeDate">
                                                    <i class="icon-check"></i>
                                                    <span v-lang.FREE_CANCELLATION_AVAILABLE></span>
                                                </li>
                                                <li class="non-refund" v-else>
                                                    <i class="icon-remove"></i>
                                                    <span v-lang.NONREFUNDABLE></span>
                                                </li>
                                            </ul>
                                            <div class="rating-globe" v-if="hotel.trustyou">
                                                <div :class="'reviews-score reviews-score__' + hotel.trustyou.score_description.toLowerCase().replace(/ +/g, '-')">
                                                    <span class="reviews-score__score">{{hotel.trustyou.score_display}}</span>
                                                </div>
                                                <div class="text">
                                                    <span>{{hotel.trustyou.score_description}}</span>
                                                    <span>{{hotel.trustyou.reviews_count}} {{hotel.trustyou.reviews_count > 1 ? 'reviews' : 'review'}}</span>
                                                </div>
                                            </div>
                                            <a class="btn bt-maps btn-outline-primary btn-sm bt-effect"
                                               :class="{'bt-selected': hotel.hotelId === hotelSelected.hotelId && enabledFlights}"
                                               href="javascript:void(0);"
                                               @click="changeHotel(hotel)"
                                               v-show="!(isSearchCompleted && hotel.cheapestPrice == 0)">
                                                <i class="icon-check" v-if="hotel.hotelId === hotelSelected.hotelId && enabledFlights"></i>
                                                {{hotel.hotelId === hotelSelected.hotelId && enabledFlights ? translateText('SELECTED', 'Selected') : translateText('SELECT', 'Select')}}
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div v-else>
                                <div class="maps-sb__list text-center">
                                    <h3 v-lang.OOPS></h3>
                                    <p v-lang.THERE_IS_NO_HOTEL_AVAILABLE></p>
                                    <button class="btn btn-sm btn-danger with-icon" @click="removeAllFilters"><i class="ico icon-remove"></i> <span v-lang.REMOVE_FILTERS></span></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="maps__wrap__content">
                        <div class="maps-area" id="map"></div>
                        <a class="btn btn-primary bt-effect bt-selected animated bt-effect-animated" href="javascript:void(0)" v-if="hotelSelected && !hasErrorMessage && enabledFlights" @click="gotoHotelInfoPage(hotelSelected.url)" v-lang.BOOK></a>
                    </div>
                    <div class="load load__bar" :class="{'load__bar--active': !loading.hotelResult && hotelStore.hotels.length > 0}">
                        <div class="line"></div>
                        <div class="line"></div>
                        <div class="line"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</template>
<script>
    import { mapState } from 'vuex'
    import MapBoxFilters from "./MapBoxFilters.vue";
    export default {
        components: { MapBoxFilters },
        props: ["hotelStore", "isSearchCompleted", "flightStore", "hotelsOptions", "packageQuery", "hasErrorMessage", "hotelSelected", "hotelMapSelected", "enabledFlights", "loading", "flightChangePrice"],
        data() {
            return {
                map: '',
                infowindow: new google.maps.InfoWindow()
            }
        },
        mounted() {
            var self = this;
            $('#modalMapBox').on('show.bs.modal', function () {
                self.initSelected(true)
            }).on('hidden.bs.modal', function () {
                $('.hotel-marker').removeClass('js-temp-active');
                $('#maps-sb__list > div').removeClass('js-temp-active');
            });
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            baseUrl: state => state.workContext.baseUrl,
            product() {
                return this.$store.state.workContext.product;
            },
            image() {
                return this.baseUrl + '/images/images-default.jpg';
            },
            numNights() {
                var returnDate = new Date(this.packageQuery.returnDate);
                var departureDate = new Date(this.packageQuery.departureDate);
                var numNights = parseInt((returnDate.getTime( )- departureDate.getTime())/(24*3600*1000));
                numNights = numNights > 1 ? (numNights + ' nights') : (numNights + ' night');
                
                return numNights;
            },
            getSelectedStars() {
                return this.hotelsOptions.stars.filter(star => {
                    return Number.isInteger(parseFloat(star));
                })
            }
        }),
        methods: {
            translateText(translateKey, defaultText, params) {
                return this.translate(this.$language, translateKey, params) || defaultText;
            },
            calculateTotalPrice(hotelPrice) {
                var price = 0;
                if (this.flightStore.outboundFlight) {
                    price += this.flightStore.outboundFlight.solutionPrice;
                }

                if (this.flightStore.inboundFlight) {
                    price += this.flightStore.inboundFlight.solutionPrice;
                }

                return (price + hotelPrice);
            },
            placeMarker(map, location, avatarUrl, title, description, stars, trustyou) {
                var self = this;
                var marker = new google.maps.Marker({
                    position: location,
                    map: map,
                    icon: self.baseUrl + '/images/img-emty.png'
                });
                self.infowindow.close()
                
                var infoWindowHTML = `<div class="infowindow__wrap">
                                        <div class="infowindow__img" style="background-image:url(${avatarUrl});"></div>
                                        <div class="infowindow__detail">
                                            <h5 class="infowindow__title">${title}</h5>
                                            <div class="infowindow__star">
                                                ${Array(parseInt(stars)).join(0).split(0).map((item, i) => `
                                                    <span class="icon-star"></span>
                                                `).join('')}
                                            </div>
                                            <span><i class="ico icon-location-arrow"></i> ${description}</span>
                                            ${typeof trustyou.score !== 'undefined' && trustyou.score != '' ? `
                                                <div class="infowindow__score">
                                                    <div class="reviews-score reviews-score__${trustyou.description.toLowerCase().replace(/ +/g, '-')}">${trustyou.score}</div>
                                                    <div class="text">
                                                        <span>${trustyou.description}</span>
                                                        <span>${trustyou.reviewsCount} ${parseInt(trustyou.reviewsCount) > 1 ? `reviews` : 'review'}</span>
                                                     </div>
                                                </div>
                                            ` : ``}
                                        </div>
                                     </div>`;
                
                setTimeout(function() {
                    self.infowindow.setContent(infoWindowHTML)
                    self.infowindow.open(map, marker);
                }, 500);
                self.map.panTo(location);
                google.maps.event.addListenerOnce(map, 'tilesloaded', function(){
                    self.map.panTo(location);
                });
            },
            initSelected(placeMarker) {
                var self = this;
                if (placeMarker) {
                    if ($(".js-temp-active").length == 0) {
                        self.initialize()
                    }
                    setTimeout(function () {
                        $('.maps-sb').animate({
                            scrollTop: ($('.maps-sb').scrollTop() + ($(".js-temp-active").length == 0 ? ($(".js-active").length > 0 ? $(".js-active").offset().top : 0) : $(".js-temp-active").offset().top)) - $(window).scrollTop() - ($('.maps__wrap__nav').height() * 1.22)
                        }, 1000)
                    }, 500)
                } else {
                    self.initialize()
                }
            },
            initialize() {
                var self = this;
                var mapCanvas = document.getElementById('map');
                var mapCenter = new google.maps.LatLng(self.hotelSelected.latitude, self.hotelSelected.longitude);
                var isSelectedDisplayed = self.hotelStore.hotels.filter(hotel => hotel.hotelId == self.hotelSelected.hotelId).length;
                if (isSelectedDisplayed == 0 && self.hotelStore.hotels.length > 0) {
                    mapCenter = new google.maps.LatLng(self.hotelStore.hotels[0].latitude, self.hotelStore.hotels[0].longitude)
                }
                var mapOptions = {
                    center: mapCenter,
                    zoom: 15,
                    scrollwheel: true,
                    zoomControl: true,
                    styles: [
                        {
                            featureType: "poi",
                            elementType: "labels",
                            stylers: [
                                { visibility: "off" }
                            ]
                        }
                    ]
                }

                self.map = new google.maps.Map(mapCanvas, mapOptions)
                var hotels = document.getElementById('maps-sb__list')
                if (typeof hotels !== 'undefined' && hotels) {
                    hotels = hotels.children;
                    for (var a = 0, al = hotels.length; a < al; a++) {
                        var hotelMarker = new customMarker(new google.maps.LatLng(hotels[a].getAttribute('data-lat'), hotels[a].getAttribute('data-lng')), self.map, {
                            class_name: 'hotel-marker ' + (hotels[a].getAttribute('id') == self.hotelSelected.hotelId && self.enabledFlights ? 'js-active' : ''),
                            marker_id: hotels[a].id,
                            lat: hotels[a].getAttribute('data-lat'),
                            lng: hotels[a].getAttribute('data-lng'),
                            price: hotels[a].getAttribute('data-price'),
                            title: hotels[a].getAttribute('data-title'),
                            avartarUrl: hotels[a].getAttribute('data_url'),
                            description: hotels[a].getAttribute('data-description'),
                            stars: hotels[a].getAttribute('data-stars'),
                            currency: self.packageQuery.currency,
                            trustyou: {
                                score: hotels[a].getAttribute('data-trustyou-score'),
                                description: hotels[a].getAttribute('data-trustyou-description'),
                                reviewsCount: hotels[a].getAttribute('data-trustyou-reviews_count')
                            }
                        })

                        // Make markers clickable
                        hotelMarker.addListener('click', function (event) {
                            // Get list of markers
                            var markers = document.querySelectorAll('.hotel-marker')

                            // Go thru list of markers
                            for (var m = 0, ml = markers.length; m < ml; m++) {
                                if (markers[m].getAttribute('data-marker_id') === this.div.getAttribute('data-marker_id')) {
                                    markers[m].classList.add('js-temp-active')
                                    var title = this.args.title
                                    var avatarUrl = this.args.avartarUrl
                                    var description = this.args.description
                                    var mapPosition = new google.maps.LatLng(this.args.lat, this.args.lng)
                                    var trustyou = {
                                        score: this.args.trustyou.score,
                                        description: this.args.trustyou.description,
                                        reviewsCount: this.args.trustyou.reviewsCount
                                    };
                                    var stars = this.args.stars;
                                    self.placeMarker(self.map, mapPosition, avatarUrl, title, description, stars, trustyou)
                                } else {
                                    markers[m].classList.remove('js-temp-active');
                                }
                            }

                            // Get list of hotels
                            var hotels = document.getElementById('maps-sb__list').children

                            // Go thru list of hotels
                            for (var h = 0, hl = hotels.length; h < hl; h++) {
                                if (hotels[h].id === this.div.getAttribute('data-marker_id')) {
                                    hotels[h].classList.add('js-temp-active')

                                    var hotel = self.hotelStore.hotels.filter((hotel) => hotel.hotelId == this.div.getAttribute('data-marker_id'))[0];
                                } else {
                                    hotels[h].classList.remove('js-temp-active')
                                }
                            }
                            $('.maps-sb').animate({
                                scrollTop: ($('.maps-sb').scrollTop() + ($(".js-temp-active").length == 0 ? ($(".js-active").length > 0 ? $(".js-active").offset().top : 0) : $(".js-temp-active").offset().top)) - $(window).scrollTop() - ($('.maps__wrap__nav').height() * 1.22)
                            }, 1000)
                        })

                        // Make list items clickable
                        hotels[a].addEventListener('click', function (event) {
                            // Get list of markers
                            var markers = document.querySelectorAll('.hotel-marker')
                            var isBtn = event.target.className.indexOf('bt-effect') > 0;
                            // Go thru list of markers
                            $('.hotel-marker').removeClass('js-temp-active')
                            for (var m = 0, ml = markers.length; m < ml; m++) {
                                if (markers[m].getAttribute('data-marker_id') === this.id) {
                                    markers[m].classList.add(isBtn ? 'js-active' : 'js-temp-active')
                                    var latNew = this.getAttribute('data-lat')
                                    var lngNew = this.getAttribute('data-lng')
                                    var title = this.getAttribute('data-title')
                                    var avatarUrl = this.getAttribute('data_url')
                                    var description = this.getAttribute('data-description')
                                    var mapPosition = new google.maps.LatLng(latNew, lngNew)
                                    var stars = this.getAttribute('data-stars');
                                    var trustyou = {
                                        score: this.getAttribute('data-trustyou-score'),
                                        description: this.getAttribute('data-trustyou-description'),
                                        reviewsCount: this.getAttribute('data-trustyou-reviews_count')
                                    };
                                    self.placeMarker(self.map, mapPosition, avatarUrl, title, description, stars, trustyou)
                                } else {
                                    markers[m].classList.remove(isBtn ? 'js-active' : 'js-temp-active')
                                }
                            }

                            // Get list of hotels
                            var hotelsInner = document.getElementById('maps-sb__list').children
                            // Go thru list of hotels
                            $('maps-sb__list > div').removeClass('js-temp-active');
                            for (var h = 0, hl = hotelsInner.length; h < hl; h++) {
                                if (hotelsInner[h].id === this.id) {
                                    if (self.enabledFlights) hotelsInner[h].classList.add(isBtn ? 'js-active' : 'js-temp-active')
                                    if (isBtn) self.changeHotel(self.hotelStore.hotels[h]);
                                } else {
                                    hotelsInner[h].classList.remove(isBtn ? 'js-active' : 'js-temp-active');
                                }
                            }
                            mapCenter = self.map.getCenter()
                        })
                    }
                } 
                
                google.maps.event.addDomListener(self.map, 'idle', function () {
                    mapCenter = self.map.getCenter();
                })
                google.maps.event.addDomListener(window, 'resize', function () {
                    self.map.panTo(mapCenter)
                })
                
                if (self.hotelStore.hotels.length > 0) {
                    if (isSelectedDisplayed > 0) {
                        self.placeMarker(self.map,
                            new google.maps.LatLng(self.hotelSelected.latitude, self.hotelSelected.longitude),
                            self.replaceImage(self.hotelSelected.imageInfos.length > 0 ? self.hotelSelected.imageInfos[0].url : self.image),
                            self.hotelSelected.name,
                            self.hotelSelected.addressLines,
                            self.hotelSelected.stars, {
                                score: self.hotelSelected.trustyou ? self.hotelSelected.trustyou.score_display : '',
                                description: self.hotelSelected.trustyou ? self.hotelSelected.trustyou.score_description : '',
                                reviewsCount: self.hotelSelected.trustyou ? self.hotelSelected.trustyou.reviews_count : ''
                            })
                    } else {
                        self.placeMarker(self.map,
                            new google.maps.LatLng(self.hotelStore.hotels[0].latitude, self.hotelStore.hotels[0].longitude),
                            self.replaceImage(self.hotelStore.hotels[0].imageInfos.length > 0 ? self.hotelStore.hotels[0].imageInfos[0].url : self.image),
                            self.hotelStore.hotels[0].name,
                            self.hotelStore.hotels[0].addressLines,
                            self.hotelStore.hotels[0].stars, {
                                score: self.hotelStore.hotels[0].trustyou ? self.hotelStore.hotels[0].trustyou.score_display : '',
                                description: self.hotelStore.hotels[0].trustyou ? self.hotelStore.hotels[0].trustyou.score_description : '',
                                reviewsCount: self.hotelStore.hotels[0].trustyou ? self.hotelStore.hotels[0].trustyou.reviews_count : ''
                            })
                    }
                } 
            },
            getAvgPrice(hotel) {
                var packagePrice = this.totalPackagePriceValue(hotel);

                if (packagePrice === 0) {
                    return "...";
                }

                var displayPrice = this.product.displayPrice;

                //price per night
                if (displayPrice === 0) {
                    return this.averagePricePerNight(packagePrice);
                }
                //price per person
                if (displayPrice === 1) {
                    return this.averagePricePerPerson(packagePrice);
                }
                //Price per room
                if (displayPrice === 2) {
                    return this.averagePricePerRoom(packagePrice);
                }
                return "...";
            },
            averagePricePerPerson(totalPackagePrice) {
                //var paxCount = this.calculatePaxCount();
                //var price = totalPackagePrice / paxCount;
                return (totalPackagePrice.toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            averagePricePerNight(totalPackagePrice) {
                //var nightCount = this.calculateNights();
                //totalPackagePrice = totalPackagePrice / nightCount;
                return (totalPackagePrice.toFixed(this.packageQuery.currencyDecimals) + "").replace(
                    /\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            calculateNights() {
                var oneDay = 24 * 60 * 60 * 1000;
                var returnDate = Date.parse(this.packageQuery.returnDate);
                var departureDate = Date.parse(this.packageQuery.departureDate);
                var nights = Math.round(Math.abs((returnDate - departureDate) / (oneDay)));
                return nights;
            },
            calculatePaxCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                    count += paxInfo.childCount;
                }
                return count;
            },
            totalPackagePriceValue(hotel) {
                if (hotel.cheapestPrice === 0) {
                    return 0;
                }

                if (this.enabledFlights && !this.flightStore.outboundFlight) {
                    return 0;
                }

                if (!hotel.availableRooms) {
                    return 0;
                }

                var price = 0;
                for (var j = 0; j < hotel.availableRooms.length; j++) {
                    for (var k = 0; k < hotel.availableRooms[j].availableRoomTypes.length; k++) {
                        var availableRoomType = hotel.availableRooms[j].availableRoomTypes[k];
                        if (availableRoomType.selected) {
                            //price += availableRoomType.price;
                            price += availableRoomType.totalPrice;
                            break;
                        }
                    }
                }

                price += this.totalFlightPrice();

                return price;
            },
            totalFlightPrice() {
                var price = 0;
                if (this.flightStore.outboundFlight)
                    price += this.flightStore.outboundFlight.solutionPrice;
                if (this.flightStore.inboundFlight) {
                    var priceChanged = this.flightStore.inboundFlight.solutionPrice - this.flightStore.outboundFlight.solutionPrice;
                    if (priceChanged != 0)
                        price += priceChanged;
                }
                return price;
            },
            replaceImage(path) {
                var replacedPath;
                if (path.indexOf('static.goquo.com') > -1) {
                    var imagePath = path.split("/");
                    replacedPath = path.replace(imagePath[3], imagePath[3] + '-w300');
                } else {
                    replacedPath = path;
                }

                // Force https
                if (replacedPath.indexOf('http://') == 0) {
                    return "https://" + replacedPath.substr(7);
                }
                return replacedPath;
            },
            changeHotel(hotel) {
                this.$emit('onHotelSelectedChange', hotel);
            },
            setSortOrder(event) {
                var self = this;
                var selectedValue = $(event.target).find('option:selected').val();
                switch (selectedValue) {
                    case 'Priority;DESC':
                        self.$emit('onSetSortOrder', 'Priority;DESC')
                        break;
                    case 'CheapestPrice;ASC':
                        self.$emit('onSetSortOrder', 'CheapestPrice;ASC')
                        break;
                    case 'CheapestPrice;DESC':
                        self.$emit('onSetSortOrder', 'CheapestPrice;DESC')
                        break;
                    case 'Name;ASC':
                        self.$emit('onSetSortOrder', 'Name;ASC')
                        break;
                    case 'Name;DESC':
                        self.$emit('onSetSortOrder', 'Name;DESC')
                        break;
                    default:
                        break;
                }
            },
            changeMapSelectedHotel(hotel) {
                this.$emit('onChangeHotelMapSelected', hotel);
            },
            setIconClassFacility(facKey) {
                var classFac = '';
                this.hotelStore.iconClassFacilities.forEach(function (x) {
                    if (x.key === facKey) classFac = x.value;
                });
                return classFac;
            },
            removeAllFilters(e) {
                let self = this;
                let fields = ['name', 'price', 'star', 'region', 'facilities'];
                fields.map(field => {
                    self.removeFilter(e, field);
                });
            },
            removeFilter(event, field) {
                this.$emit('onRemoveFilters', {
                    event: event,
                    field: field
                });
            },
            onFiltersChanged() {
                this.$emit('onFiltersChanged')
            },
            getHotelDetailUrl(baseUrl) {
                var href = baseUrl;
                var indexOfMask = baseUrl.indexOf("?");
                if (indexOfMask > -1) {
                    href += "&";
                } else {
                    href += "?";
                }
                if (this.flightStore.outboundFlight != null) {
                    href += "outboundFlightId=" + this.flightStore.outboundFlight.id;

                    if (this.flightStore.inboundFlight != null) {
                        href += "&inboundFlightId=" + this.flightStore.inboundFlight.id;
                    }
                }
                return href;
            },
            gotoHotelInfoPage(baseUrl) {
                window.open(this.getHotelDetailUrl(baseUrl), '_blank');
            },
            formatPrice(price) {
                return (price.toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',')
            }
        },
        watch: {
            hotelMapSelected(newValue, oldValue) {
                var self = this;
                if (oldValue || newValue) {
                    setTimeout(function() {
                        var markers = document.querySelectorAll('.hotel-marker');
                        // Go thru list of markers
                        for (var m = 0, ml = markers.length; m < ml; m++) {
                            if (markers[m].getAttribute('data-marker_id') == self.hotelMapSelected.hotelId) {
                                markers[m].classList.add('js-temp-active')
                            } else {
                                markers[m].classList.remove('js-temp-active')
                            }
                        }

                        self.placeMarker(self.map,
                            new google.maps.LatLng(self.hotelMapSelected.latitude, self.hotelMapSelected.longitude),
                            self.replaceImage(self.hotelMapSelected.imageInfos && self.hotelMapSelected.imageInfos.length > 0 ? self.hotelMapSelected.imageInfos[0].url : self.image),
                            self.hotelMapSelected.name,
                            self.hotelMapSelected.addressLines,
                            self.hotelMapSelected.stars, {
                                score: self.hotelMapSelected.trustyou ? self.hotelMapSelected.trustyou.score_display : '',
                                description: self.hotelMapSelected.trustyou ? self.hotelMapSelected.trustyou.score_description : '',
                                reviewsCount: self.hotelMapSelected.trustyou ? self.hotelMapSelected.trustyou.reviews_count : ''
                            });
                    }, 200);

                    var hotels = document.getElementById('maps-sb__list');

                    if (typeof hotels !== 'undefined' && hotels) {
                        hotels = hotels.children;
                        for (var h = 0, hl = hotels.length; h < hl; h++) {
                            if (hotels[h].id === self.hotelMapSelected.hotelId) {
                                hotels[h].classList.add('js-temp-active')
                            } else {
                                hotels[h].classList.remove('js-temp-active')
                            }
                        }
                    }
                }
            },
            hasErrorMessage: function (newValue, oldValue) {
                var self = this;
                if (newValue) {
                    setTimeout(function () {
                        self.initSelected(false)
                    }, 300);
                }
            },
            "hotelStore.hotels": function(val) {
                let self = this;
                self.initSelected(false);
            }
        }
    }
</script>
