<template>
    <input type="text"
           readonly="readonly"
           class="form-control datetime"
           autocomplete="off"
           data-val="true"
           :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')" />
</template>
<script>

    export default {
        model: {
            prop: 'value'
        },
        data() {
            return {
            }
        },
        computed: {
            datePickerDateFormat() {
                return this.$store.state.workContext.siteInfo.datePickerDateFormat;
            }
        },
        mounted: function () {
            var vm = this;
            var $element = $(vm.$el);
            var dateformat = $element.data("date-format");

            if (!dateformat) {
                dateformat = vm.$store.state.workContext.siteInfo.datePickerDateFormat;
            }

            if (!$element.attr('placeholder')) {
                $element.attr('placeholder', dateformat.toUpperCase());
            }

            this.disabledDatesValue = null;

            var options = {
                todayHighlight: true,
                orientation: "auto",
                format: dateformat,
                autoclose: true,
                beforeShowDay: function (date) {
                    if (!vm.disabledDatesValue) {
                        return true;
                    }

                    if (date < vm.disabledDatesValue.startDate || date > vm.disabledDatesValue.endDate) {
                        return false;
                    }

                    var year = date.getFullYear();
                    if (vm.disabledDatesValue.disabledDates && vm.disabledDatesValue.disabledDates[year]) {
                        var month = date.getMonth() + 1;
                        if (vm.disabledDatesValue.disabledDates[year][month]) {
                            var day = date.getDate();
                            var days = vm.disabledDatesValue.disabledDates[year][month];
                            if ($.inArray(day, days) > -1) {
                                return false;
                            }
                        }
                    }

                    return true;
                }
            };

            var startDate = new Date();

            // Start date
            if (this.startDate) {
                startDate = new Date(this.startDate);

                if (this.addOneDay) {
                    startDate.setDate(startDate.getDate() + 1);
                }
            }
            else {
                // Min days before
                if (this.minDaysBefore && this.minDaysBefore > 0) {
                    startDate.setDate(startDate.getDate() + parseInt(this.minDaysBefore));
                }
            }

            options.startDate = startDate;

            // End date
            if (this.endDate) {
                var dt = new Date(this.endDate);
                options.endDate = dt;
            }
            else {
                // Max days after
                if (this.maxDaysAfter && this.maxDaysAfter > 0) {
                    var dt = new Date();
                    dt.setDate(dt.getDate() + parseInt(this.maxDaysAfter));
                    options.endDate = dt;
                }
            }

            var $datepicker = $element.datepicker(options);
            if (this.value) {
                var datepicker = $datepicker.data('datepicker');
                datepicker.setUTCDate(new Date(this.value));
            }
            else if (this.defaultValue) {
                var datepicker = $datepicker.data('datepicker');
                datepicker.setUTCDate(new Date(this.defaultValue));
            }

            this.$datepicker = $datepicker;

            $datepicker.on("changeDate", function (ev) {
                if (!ev.date) {
                    return;
                }
                var date = new Date(ev.date);
                var localISOTime = new Date(date.getTime() - (date.getTimezoneOffset() * 60000)).toISOString();
                vm.$emit('input', localISOTime.replace('.000Z', 'Z'));
            }).data("datepicker");

            if (this.disableDateUrl && this.disableDateUrl.length > 0) {
                this.setupDisableDateUrl();
            }
        },
        props: ['value', 'defaultValue', 'startDate', 'endDate', 'maxDaysBetween', 'minDaysBefore', 'maxDaysAfter', 'autoFocus', 'addOneDay', 'disableDateUrl'],
        methods: {
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            setupDisableDateUrl: function () {
                var self = this;

                $.get(this.disableDateUrl, function (response) {
                    self.disabledDatesValue = response;
                    var datepicker = self.$datepicker.data('datepicker');
                    datepicker.update();
                });
            }
        },
        watch: {
            startDate: function (value) {
                var dt = new Date(value);

                if (this.addOneDay) {
                    dt.setDate(dt.getDate() + 1); 
                }                
                
                var datepicker = this.$datepicker.data('datepicker');
                datepicker.setStartDate(dt);

                var currentDate = datepicker.getDate();

                if (currentDate) {
                    if (currentDate < dt) {
                        datepicker.setDate(dt);
                    }
                }
                else {
                    datepicker.setDate(dt);
                }

                if (this.maxDaysBetween) {
                    var endDate = new Date(value);
                    endDate.setDate(endDate.getDate() + parseInt(this.maxDaysBetween)); 
                    datepicker.setEndDate(endDate);
                }

                if (this.autoFocus) {
                    this.$datepicker.focus();
                }                
            },
            endDate: function (value) {
                var dt = new Date(value);
                var datepicker = this.$datepicker.data('datepicker');
                datepicker.setEndDate(dt);
            },
            defaultValue: function (value) {
                if (!value) {
                    return;
                }
                var dt = new Date(value);
                var datepicker = this.$datepicker.data('datepicker');
                datepicker.setUTCDate(dt);
            },
            disableDateUrl: function () {
                this.setupDisableDateUrl();
            }
        }
    }

</script>
