﻿<template>
    <div>
        <div class="sidebar__togger">
            <a class="sidebar-filter" href="javascript:void(0)" @click="togglePane('.sidebar-wrap', false)">
                <i class="icon-filter"></i>
                <span v-lang.FILTER>Filter</span>
            </a>
            <a class="sidebar-filter" href="javascript:void(0)" id="bt-call-filters" @click="togglePane('.avai-findbar-mobie', false)">
                <i class="icon-sort-numeric-asc"></i>
                <span v-lang.SORT>Sort</span>
            </a>
            <a class="sidebar-filter" href="#modalMapBox" data-toggle="modal" id="bt-call-maps">
                <i class="icon-location-arrow"></i>
                <span v-lang.MAPS>Maps</span>
            </a>
        </div>
        <div class="sidebar-overlay" @click="togglePane('.sidebar-wrap, .avai-findbar-mobie', true)"></div>
        <div class="sidebar-wrap">
            <div class="sidebar__navi">
                <span>Filter by</span>
                <div class="sidebar__navi-close" @click="togglePane('.sidebar-wrap', false)">
                    <i class="icon-remove"></i>
                </div>
            </div>
            <div class="sidebar__maps" data-toggle="modal" data-target="#modalMapBox">
                <img :src="baseUrl + '/images/sidebar-map.jpg'" alt="">
                <a class="bt-maps" href="#" v-lang.VIEW_ON_MAP>View on map</a>
            </div>
            <AjaxTypeahead name="NameFilter"
                           :placeholder="translateText('SEARCH_FOR_HOTEL', 'Search for hotels')"
                           :defaultValue="hotelsOptions.hotelName"
                           :url="'/api/find-hotels/' + packageQuery.id"
                           @onHotelNameChange="onHotelNameChanged" />
            <div class="sidebar__box">
                <div class="sidebar__title">
                    <h2 v-if="enabledFlights" v-lang.TOTAL_PACKAGE_PRICE>Total Package Price</h2>
                    <h2 v-else v-lang.TOTAL_STAY_PRICE>Total Stay Price</h2>
                </div>
                <div class="sidebar__content">
                    <div class="sidebar__price">
                        <div class="result-sidebar-box" v-if="enabledFlights && flightStore.outboundFlight && flightStore.inboundFlight">
                            <IonRangeSlider v-if="!hotelStore.maxHotelPrice"
                                            :min="calculateTotalPrice(hotelStore.minPrice)"
                                            :max="calculateTotalPrice(hotelStore.maxPrice)"
                                            :from="calculateTotalPrice(hotelsOptions.minPrice)"
                                            :to="calculateTotalPrice(hotelsOptions.maxPrice)"
                                            :prefix="packageQuery.currency + ' '"
                                            prettifySeparator=","
                                            :currencyDecimals="packageQuery.currencyDecimals"
                                            @changed="setMinMaxPrice"
                                            :flightChangePrice="flightChangePrice" />
                        </div>
                        <div class="result-sidebar-box" v-if="!enabledFlights">
                            <IonRangeSlider v-if="!hotelStore.maxHotelPrice"
                                            :min="hotelStore.minPrice"
                                            :max="hotelStore.maxPrice"
                                            :from="hotelsOptions.minPrice"
                                            :to="hotelsOptions.maxPrice"
                                            :prefix="packageQuery.currency + ' '"
                                            prettifySeparator=","
                                            :currencyDecimals="packageQuery.currencyDecimals"
                                            @changed="setMinMaxPrice"
                                            :flightChangePrice="flightChangePrice" />
                        </div>
                    </div>
                </div>

                <div class="sidebar__title">
                    <h2 v-lang.STAR_RATING>Star rating</h2>
                </div>
                <div class="sidebar__content">
                    <div class="sidebar__rating">
                        <div class="rating-star-check">
                            <div class="rating-col" v-for="(star, starIndex) in hotelStore.stars" :key="starIndex">
                                <div class="rating-check">
                                    <input class="ipt-check" type="checkbox" name="checkbox01" :id="'checkbox' + star" :checked="isSelectedStar(star)" @change="toggleStarSelection(star)">
                                    <label class="ipt-label" :for="'checkbox' + star">
                                        <span class="box"></span>
                                        <div class="rating-star">
                                            <span class="icon-star" v-for="n in parseInt(star)" :key="n"></span>
                                        </div>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div v-if="hotelsOptions.regionId">
                    <div class="sidebar__title">
                        <h2>Distance Range</h2>
                    </div>
                    <div class="sidebar__content">
                        <div class="sidebar__price">
                            <div class="result-sidebar-box">
                                <IonRangeSlider v-if="!hotelStore.maxHotelPrice"
                                                min="0"
                                                max="5"
                                                :from="hotelsOptions.minDistance"
                                                :to="hotelsOptions.maxDistance"
                                                postfix=" km"
                                                prettifySeparator=","
                                                @changed="setRegionDistance" />
                            </div>
                        </div>
                    </div>
                </div>

                <div v-if="hotelStore.importantLocations.length > 1">
                    <div class="sidebar__title">
                        <h2 v-lang.LOCATIONS>Locations</h2>
                    </div>
                    <div class="sidebar__content">
                        <div class="sidebar__dropdown have-icons">
                            <ul>
                                <li class="item-dropdown" v-for="(importantLocation, index) in hotelStore.importantLocations">
                                    <div class="drop-text" data-toggle="collapse" :data-target="'#location-' + index">
                                        <span>{{translateText(importantLocation.key.split(' ').join('-'), importantLocation.key)}}</span>
                                        <i class="icon icon-add1"></i>
                                    </div>

                                    <ul class="item-sub-dropdown scroll-hoz collapse" :id="'location-' + index">
                                        <li v-for="location in importantLocation.regions">
                                            <div class="style-check">
                                                <input class="ipt-check" type="radio" name="selectedLocation" :id="'radio' + location.regionId" @click="setRegionId(location)" :value="location.regionId" :checked="hotelsOptions.regionId == location.regionId">
                                                <label class="ipt-label" :for="'radio' + location.regionId">
                                                    <span class="box"></span>
                                                    <div class="drop-text">
                                                        <span>{{location.regionName}}</span>
                                                    </div>
                                                </label>
                                            </div>

                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div v-if="hotelStore.facilities.length > 0">
                    <div class="sidebar__title">
                        <h2 v-lang.FACILITIES>Facilities</h2>
                    </div>
                    <div class="sidebar__content">
                        <div class="sidebar__dropdown">
                            <ul>
                                <li class="item-dropdown" v-for="(facility, facIndex) in hotelStore.facilities" :key="facIndex" v-if="facility.value">
                                    <div class="style-check">
                                        <input class="ipt-check" type="checkbox" name="checkbox01" :id="'facility-' + facility.key" @change="toggleFacilitySelection(facility.key)" :checked="isSelectedFacility(facility.key)">
                                        <label class="ipt-label" :for="'facility-' + facility.key">
                                            <span class="box"></span>
                                            <div class="drop-text">
                                                <!--<span :class="'icon icon-' + facility.key"></span>-->
                                                <span :class="'icon icon-' + setIconClassFacility(facility.key)"></span>
                                                <span>{{translateText(facility.key, facility.value)}}</span>
                                            </div>
                                        </label>
                                    </div>
                                </li>
                            </ul>
                            <!--<a class="more-dropdown" href="#">More</a>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import { mapState } from 'vuex'
    import AjaxTypeahead from "./AjaxTypeahead.vue"
    import IonRangeSlider from './IonRangeSlider.vue'

    export default {
        components: { AjaxTypeahead, IonRangeSlider },
        props: ["packageQuery", "hotelStore", "flightStore", "hotelsOptions", "isSearchCompleted", "flightChangePrice", "enabledFlights"],
        data() {
            return {
                isOpenSidebar: false,
                isOpenSort: false,
                isActiveOverLaySidebar: false
            }
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            baseUrl: state => state.workContext.baseUrl,
            selectHotelText() {
                return this.translate(this.$language, 'SELECT_HOTEL') || 'Select Hotel';
            }
        }),
        methods: {
            calculateTotalPrice(hotelPrice) {
                var price = 0;
                if (this.flightStore.outboundFlight) {
                    price += this.flightStore.outboundFlight.solutionPrice;
                }
                if (this.flightStore.inboundFlight) {
                    var priceChanged = this.flightStore.inboundFlight.solutionPrice - this.flightStore.outboundFlight.solutionPrice;
                    if (priceChanged != 0)
                        price += priceChanged;
                }
               
                return (price + hotelPrice).toFixed(this.packageQuery.currencyDecimals);
            },            
            setIconClassFacility(facKey) { 
                var classFac = '';
                this.hotelStore.iconClassFacilities.forEach(function (x) {
                    if (x.key === facKey) classFac = x.value;
                });
                return classFac;
            },
            isSelectedStar(star) {
                var index = this.hotelsOptions.stars.indexOf(star);
                if (index === -1)
                    return false;
                return true;
            },
            isSelectedFacility(facility) {
                var index = this.hotelsOptions.facilities.indexOf(facility);
                if (index === -1)
                    return false;
                return true;
            },
            toggleFacilitySelection(facility) {
                var idx = this.hotelsOptions.facilities.indexOf(facility);
                if (idx > -1) {
                    this.hotelsOptions.facilities.splice(idx, 1);
                } else {
                    this.hotelsOptions.facilities.push(facility);
                }
                this.$emit('changed');
            },
            setRegionId(region) {
                if (region) {
                    this.hotelsOptions.regionId = region.regionId;
                    this.hotelsOptions.latitude = region.centerLatitude;
                    this.hotelsOptions.longitude = region.centerLongitude;
                    this.hotelsOptions.regionName = region.regionName;
                } else {
                    this.hotelsOptions.regionId = null;
                    this.hotelsOptions.latitude = null;
                    this.hotelsOptions.longitude = null;
                    this.hotelsOptions.regionName = null;
                }
                this.$emit('changed');
            },
            toggleStarSelection(star) {
                this.internalToggleStarSelection(star);
                //if (star === "1") {
                //    this.internalToggleStarSelection("0");
                //}

                this.$emit('changed');
            },
            toggleFilter() {
                $("#filterPanelResult .filter-body").toggleClass('is-open');
            },
            internalToggleStarSelection(star) {
                var idx = this.hotelsOptions.stars.indexOf(star);
                if (idx > -1) {
                    this.hotelsOptions.stars.splice(idx, 1);
                    if (star < 5) {
                        idx = this.hotelsOptions.stars.indexOf((parseFloat(star) + 0.5) + "");
                        if (idx > -1) {
                            this.hotelsOptions.stars.splice(idx, 1);
                        }
                    }
                } else {
                    this.hotelsOptions.stars.push(star);
                    if (star < 5) {
                        this.hotelsOptions.stars.push((parseFloat(star) + 0.5) + "");
                    }
                }
                this.hotelsOptions.stars.sort(function (a, b) { return a - b; })
            },
            onHotelNameChanged(data) {
                this.hotelsOptions.hotelName = data;
                this.$emit('changed');
            },
            clearHotelName() {
                this.hotelsOptions.hotelName = null;
                this.$refs.hotelNameFilter.clearSelection();
                this.$emit('changed');
            },
            setMinMaxPrice(min, max) {
                var minPrice = min;
                var maxPrice = max;
                //Remove flight price from values
                if (this.flightStore.outboundFlight != null) {
                    minPrice -= this.flightStore.outboundFlight.solutionPrice;
                    maxPrice -= this.flightStore.outboundFlight.solutionPrice;
                }

                this.hotelsOptions.minPrice = parseFloat(minPrice.toFixed(this.packageQuery.currencyDecimals));
                this.hotelsOptions.maxPrice = parseFloat(maxPrice.toFixed(this.packageQuery.currencyDecimals));
                this.$emit('changed');
            },
            setRegionDistance(min, max) {
                this.hotelsOptions.minDistance = parseFloat(min.toFixed(this.packageQuery.currencyDecimals));
                this.hotelsOptions.maxDistance = parseFloat(max.toFixed(this.packageQuery.currencyDecimals));
                this.hotelsOptions.radius = max;
                this.$emit('changed');
            },
            togglePane(element, isClosed) {
                this.$emit('onTogglePaneChanged', {
                    element: element,
                    isClosed: isClosed
                });
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            }
        }
    }

</script>
