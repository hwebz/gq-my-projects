﻿<template>
    <div>
        <div class="avai-hotel" v-if="!errorMessage">
            <div class="countAvai">
                <p v-if="!(hotelStore.totalFilteredHotels > 0 && isSearchCompleted)" class="mt0">
                    <span v-lang.LOADING_HOTELS>Loading Hotels</span>
                    &hellip;
                </p>
                <p v-else class="mt0" v-lang.SHOWING_X_OF_X_HOTELS="{0: hotelStore.totalFilteredHotels, 1: Math.max(hotelStore.totalHotels, hotelStore.totalFilteredHotels)}"></p>
                <p class="mt0">
                    <span v-lang.CHECK_IN>Check-in</span>&nbsp;<strong>{{momentDateFormat(packageQuery.checkIn, 'ddd, DD MMM') || momentDateFormat(arrivalDate, 'ddd, DD MMM')}}</strong>.
                    <span v-lang.CHECK_OUT>Check-out</span>&nbsp;<strong>{{momentDateFormat(packageQuery.checkOut, 'ddd, DD MMM') || momentDateFormat(packageQuery.returnDate, 'ddd, DD MMM') }}</strong>
                    <span class="hotel-stay">
                        (<span v-if="hotelStay == 1" v-lang.ONE_NIGHT>1 night</span><span v-else v-lang.X_NIGHTS="{0: hotelStay}"></span>)
                    </span>
                </p>
            </div>
            
            <template v-if="loading.hotelResult">
                <div class="fh-tabs__overview" v-for="(hotel, hotelIndex) in hotelStore.hotels" :key="hotelIndex" @click="loadHotelInfo(hotel)">
                    <div class="fh-tabs__item fh-tabs__hotel">
                        <div class="picture" :class="{'no-image': hotel.imageInfos.length == 0}" :title="hotel.name" :style="{backgroundImage: `url('${hotel.imageInfos.length > 0 ? replaceImage(hotel.imageInfos[0].url) : baseUrl + '/images/images-default.jpg'}')`}">
                        </div>
                        <div class="detail">
                            <h2 class="name" :href="'#hotelDetail-' + hotel.hotelId.replace(/\:/g, '')" data-toggle="collapse">{{hotel.name}}</h2>
                            <div class="title">
                                <StarRating :rating="hotel.stars"></StarRating>
                            </div>
                            <ul class="list-detail" v-if="hotel.longitude && hotel.latitude && hotel.longitude != hotel.latitude">
                                <li>
                                    <span><i class="icon-location-arrow"></i>{{hotel.addressLines}}</span>
                                    <a href="#modalMapBox" data-toggle="modal" @click="changeHotelMapSelected(hotel)">
                                        <i class="ico icon-map-marker"></i><span v-lang.VIEW>View</span>
                                    </a>
                                </li>
                                <li v-if="hotel.trustyou && isSearchCompleted && !hasErrorMessage">
                                <span :class="'reviews-score reviews-score__' + hotel.trustyou.score_description.toLowerCase().replace(/ +/g, '-')">
                                    <span class="reviews-score__score">{{hotel.trustyou.score_display}}</span> |
                                    <span class="reviews-score__description">{{hotel.trustyou.score_description}}</span>
                                </span>
                                    <span>
                                        <span class="reviews-score__reviews" v-if="hotel.trustyou.reviews_count > 0">{{hotel.trustyou.reviews_count}} {{hotel.trustyou.reviews_count > 1 ? translateText('REVIEWS', 'reviews') : translateText('REVIEW', 'review')}}</span>
                                </span>
                                </li>
                            </ul>
                            <ul class="list-ruler-check">
                                <li class="cancellation" v-if="isHotelCancellation(hotel) === 'free'">
                                    <i class="icon-check"></i>
                                    <span v-lang.FREE_CANCELLATION_AVAILABLE>FREE cancellation available</span>
                                </li>
                                <li class="cancellation" v-if="isHotelCancellation(hotel) === 'apart'">
                                    <i class="icon-check"></i>
                                    <span v-lang.REFUNDABLE>Refundable</span>
                                </li>
                                <li class="non-refund" v-if="isHotelCancellation(hotel) === 'non'">
                                    <i class="icon-remove"></i>
                                    <span v-lang.NONREFUNDABLE>Non-refundable</span>
                                </li>
                            </ul>
                            <a class="bt-link" :href="'#hotelDetail-' + hotel.hotelId.replace(/\:/g, '')" data-toggle="collapse">
                                <i class="icon-down-chevron"></i><span v-lang.INFO>Info</span>
                            </a>
                        </div>
                    </div>
                    <div class="fh-tabs__item fh-tabs__control">
                        <div class="loading-price" v-bind:class="{'loading-price--active': isCanShowHotelPrice(hotel)}">
                            <div class="load load__bar load__bar--active">
                                <div class="line"></div>
                                <div class="line"></div>
                                <div class="line"></div>
                            </div>
                            <span class="loading-price--first" v-lang.LOADING_PRICE>Loading Price...</span>
                            <span class="loading-price--second" v-lang.CALCULATING_PRICE>Calculating Price...</span>
                            <span class="loading-price--third" v-lang.HOLD_ON_A_BIT>Hold on a bit!</span>
                        </div>
                        <div class="price-summary-panel">
                            <div class="per-price">
                                <div class="title-class" v-if="enabledFlights" v-lang.FLIGHT_HOTEL>FLIGHT + HOTEL</div>
                                <div class="title-class" v-else v-lang.HOTEL>HOTEL</div>
                                <div class="title-perperson">
                                    <span v-if="product.displayPrice == 0" v-lang.PER_NIGHT>per night</span>
                                    <span v-if="product.displayPrice == 1" v-lang.PER_PERSON>per person</span>
                                    <span v-if="product.displayPrice == 2" v-lang.PER_ROOM>per room</span>
                                </div>
                                <div class="price" v-if="isCanShowHotelPrice(hotel)">
                                    <span>{{packageQuery.currency}}</span>
                                    <strong>{{getAvgPrice(hotel)}}</strong>
                                </div>
                                <div class="price" v-if="isSearchCompleted && hotel.cheapestPrice == 0">
                                    <strong>SOLD OUT</strong>
                                </div>
                            </div>
                            <div class="total-package-price" v-if="isCanShowHotelPrice(hotel)">
                                <div class="title-class" v-if="enabledFlights" v-lang.TOTAL_PACKAGE_PRICE>TOTAL PACKAGE PRICE</div>
                                <div class="title-class" v-else>
                                    <span v-if="calculateNights() > 0 && calculateNights() == 1" v-lang.FOR_X_NIGHT="{0: calculateNights()}"></span>
                                    <span v-else v-lang.FOR_X_NIGHTS="{0: calculateNights()}"></span>
                                </div>
                                <div class="price">
                                    <span>{{packageQuery.currency}}</span>
                                    <strong>{{formatPrice(totalPackagePriceValue(hotel))}}</strong>
                                </div>
                            </div>
                        </div>
                        <a class="link-small" href="#modalPriceBreakdown" data-toggle="modal" @click="showPriceSummaryPaneHotel(hotel.cheapestPrice)" v-lang.PRICE_BREAKDOWN>Price breakdown</a>
                        <a class="btn btn-block btn-outline-primary bt-effect"
                           :class="{'bt-selected': hotel.hotelId === hotelSelected.hotelId && enabledFlights}"
                           href="javascript:void(0);"
                           v-show="hotel.cheapestPrice > 0"
                           @click="changeHotel(hotel)">
                            <i class="icon-check" v-if="hotel.hotelId === hotelSelected.hotelId && enabledFlights"></i>
                            {{hotel.hotelId === hotelSelected.hotelId && enabledFlights ? translateText('SELECTED', 'Selected') : translateText('SELECT', 'Select')}}
                        </a>
                    </div>
                    <div class="fh-tabs__item fh-tabs__detail collapse" :id="'hotelDetail-' + hotel.hotelId.replace(/\:/g, '')">
                        <div class="tabs-cls-detail">
                            <div class="tabs-cls-header nav nav-tabs">
                                <a class="item-tabs-cls nav-item nav-link active" data-toggle="tab" role="tab" :href="'#tab-item-' + hotel.hotelId + '-gallery'"><span v-lang.PHOTO>Photo</span></a>
                                <a class="item-tabs-cls nav-item nav-link"
                                   data-toggle="tab"
                                   data-analyst="map"
                                   role="tab"
                                   :href="'#tab-item-' + hotel.hotelId + '-map'"><span v-lang.MAPS>Maps</span></a>
                                <a class="item-tabs-cls nav-item nav-link" data-toggle="tab" role="tab" :href="'#tab-item-' + hotel.hotelId + '-services'" v-if="hotel.facilities.length > 0"><span v-lang.SERVICE>Service</span></a>
                                <a class="item-tabs-cls nav-item nav-link" data-toggle="tab" role="tab" :href="'#tab-item-' + hotel.hotelId + '-reviews'" v-if="hotel.trustyou"><span v-lang.REVIEWS>Reviews</span></a>
                                <a class="item-tabs-cls nav-item nav-link" data-toggle="tab" role="tab" :href="'#tab-item-' + hotel.hotelId + '-description'"><span v-lang.DESCRIPTION>Description</span></a>
                            </div>
                            <div class="tabs-cls-main tab-content">
                                <div role="tabpanel" :id="'tab-item-' + hotel.hotelId + '-gallery'" class="tabs-cls-content tabs-gallery tab-pane show active"
                                     v-if="hotel.imageInfos.length > 0">
                                    <div class="gallery__wrap">
                                        <div class="gallery__image">
                                            <div class="gallery__image-show" :id="'tab-item-' + hotel.hotelId + '-gallery-big-item'" :style="'background-image:url('+ hotel.imageInfos[0].url +')'">
                                            </div>
                                            <div class="go-left go-control" data-index="0" data-control="prev" @click="changeGalleryImage($event, '#tab-item-' + hotel.hotelId + '-gallery-big-item', hotel.imageInfos)">
                                                <i class="icon-left-chevron" style="pointer-events: none"></i>
                                            </div>
                                            <div class="go-right go-control" data-index="0" data-control="next" @click="changeGalleryImage($event, '#tab-item-' + hotel.hotelId + '-gallery-big-item', hotel.imageInfos)">
                                                <i class="icon-right-chevron" style="pointer-events: none"></i>
                                            </div>
                                        </div>
                                        <div class="gallery__thumbs">
                                            <div class="gallery__thumbs-item">
                                                <a class="thumb-item" href="javascript:void(0);" :data-image-index="i" :class="{'active': i === 0 }" v-for="(img, i) in hotel.imageInfos"
                                                   :style="'background-image:url('+ img.thumbnailUrl +')'" :key="i" @click="changeGalleryImage($event, '#tab-item-' + hotel.hotelId + '-gallery-big-item', img)"></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div role="tabpanel"
                                     :id="'tab-item-' + hotel.hotelId + '-map'"
                                     class="tabs-cls-content tabs-maps tab-pane"
                                     :data-index="hotelIndex">
                                    <div :id="'#tab-item-' + hotel.hotelId + '-map-item'" class="tabs-maps-detail maps-area"></div>
                                </div>
                                <div role="tabpanel" :id="'tab-item-' + hotel.hotelId + '-services'" class="tabs-cls-content tabs-services tab-pane scroll-hoz" v-if="hotel.facilities.length > 0">
                                    <div class="list-service">
                                        <div class="block-service">
                                            <div class="title">
                                                <strong v-lang.FACILITIES>Facilities</strong>
                                            </div>
                                            <div class="detail">
                                                <ul>
                                                    <li v-for="(facility, idx) in hotel.facilities" :key="idx" v-if="facility.code">
                                                        <!--<i :class="'icon icon-' + facility.code"></i>-->
                                                        {{facility.description ? facility.description : facility.name}}
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div role="tabpanel" :id="'tab-item-' + hotel.hotelId + '-reviews'" class="tabs-cls-content tabs-services tab-pane scroll-hoz  reviews-box" v-if="hotel.trustyou">
                                    <TrustYou :trustyou="hotel.trustyou" :hotelId="hotel.hotelId" />
                                </div>
                                <div role="tabpanel" :id="'tab-item-' + hotel.hotelId + '-description'" class="tabs-cls-content tabs-services tab-pane scroll-hoz">
                                    <div class="tabs-texts" v-html="hotel.description">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="paganition-wrap center" v-show="!showMapView">
                    <a class="item-paganition bt-effect"
                       :class="{'disabled': hotelStore.currentPage === hotelStore.totalPages, 'bt-loading': loading.hotelPagination}"
                       href="#"
                       @click.prevent="(hotelStore.currentPage === hotelStore.totalPages) || gotoHotelsPage(hotelStore.currentPage + 1)"><span v-lang.LOAD_MORE>Load more</span></a>
                </div>
            </template>
            <template v-else>
                <div class="fh-tabs__overview" v-for="n in 5" :key="n">
                    <div class="fh-tabs__item fh-tabs__hotel">
                        <div class="picture">
                            <div class="lda">
                                <div class="lda__bar lda__bar--full"></div>
                            </div>
                        </div>
                        <div class="detail">
                            <div class="lda">
                                <div class="lda__bar"></div>
                                <div class="lda__bar lda__bar--50"></div>
                                <div class="lda__bar lda__bar--split"></div>
                                <div class="lda__bar lda__bar--split"></div>
                                <div class="lda__bar lda__bar--50"></div>
                                <div class="lda__bar lda__bar--50"></div>
                            </div>
                        </div>
                    </div>
                    <div class="fh-tabs__item fh-tabs__control">
                        <div class="lda lda--fbot">
                            <div class="lda__bar lda__bar--50"></div>
                            <div class="lda__bar lda__bar--50"></div>
                            <div class="lda__bar lda__bar--50"></div>
                            <div class="lda__bar lda__bar--split lda__bar--50"></div>
                            <div class="lda__bar lda__bar--two"></div>
                        </div>
                    </div>
                </div>
                <div class="paganition-wrap">
                    <a class=" bt-effect"><div class="lda__bar"></div></a>
                    <span class="count-page"><div class="lda__bar"></div></span>
                    <a class="bt-effect"><div class="lda__bar"></div></a>
                </div>
            </template>
        </div>
        <div v-else class="no-hotel-available">
            <div>
                <h3 v-lang.OOPS>Oops!!!</h3>
                <p v-lang.THERE_IS_NO_HOTEL_AVAILABLE>There is no hotel available. Please try again with different search conditions.</p>
                <button class="btn btn-sm btn-danger with-icon" @click="removeFilter"><i class="ico icon-remove"></i> <span v-lang.REMOVE_FILTERS>Remove Filters</span></button>
            </div>
        </div>
        <MapBox :hotelStore="hotelStore"
                :hotelsOptions="hotelsOptions"
                :isSearchCompleted="isSearchCompleted"
                :flightStore="flightStore"
                :hasErrorMessage="hasErrorMessage"
                :hotelSelected="hotelSelected"
                :packageQuery="packageQuery"
                :loading="loading"
                :enabledFlights="enabledFlights"
                :hotelMapSelected="hotelMapSelected"
                :flightChangePrice="flightChangePrice"
                @onFiltersChanged="onFiltersChanged"
                @onRemoveFilters="removeFilters"
                @onSetSortOrder="onSetSortOrder"
                @onChangeHotelMapSelected="changeHotelMapSelected"
                @onHotelSelectedChange="changeHotel" />
    </div>
</template>
<script>
    import Vue from 'vue'
    import { mapState } from 'vuex'
    import StarRating from './StarRating.vue'
    import TrustYou from './TrustYou.vue'
    import MapBox from "./MapBox.vue"

    export default {
        props: ["packageQuery", "flightStore", "hotelStore", "loading", "hotelsOptions", "enabledFlights", "showMapView",
            "isSearchCompleted", "hasErrorMessage", "errorMessage", "hotelSelected", "hotelMapSelected", "flightChangePrice"
        ],
        components: {
            MapBox,
            StarRating,
            TrustYou
        },
        data() {
            return {
                showMapFull: false,
                infowindow: new google.maps.InfoWindow()
            };
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            baseUrl: state => state.workContext.baseUrl,
            product() {
                return this.$store.state.workContext.product;
            },
            hotelStay() {
                var start = moment(this.packageQuery.checkIn || this.arrivalDate);
                var end = moment(this.packageQuery.checkOut || this.packageQuery.returnDate);
                start.hours(0).minutes(0);
                return end.diff(start, 'days');
            },
            arrivalDate() {
                return this.flightStore.outboundFlight ? this.flightStore.outboundFlight.arrivalDate : 0;
            }
        }),
        updated() {
            var self = this;
            $("a[data-analyst='map']").unbind('show.bs.tab').on('show.bs.tab', function (e) {
                var target = $(e.target.hash);
                var targetMap = typeof target !== 'undefined' ? target.find('> div') : null;
                if (targetMap) {
                    var hotelIndex = target.attr('data-index');
                    var hotel = self.hotelStore.hotels[hotelIndex];

                    var myLatLng = { lat: parseFloat(hotel.latitude), lng: parseFloat(hotel.longitude) };

                    var map = new google.maps.Map(targetMap[0], {
                        center: myLatLng,
                        zoom: 18
                    });
                    // Create a marker and set its position.
                    var marker = new google.maps.Marker({
                        map: map,
                        position: myLatLng,
                        title: hotel.name
                    });

                    var infoWindowHTML = `<div class="infowindow__wrap">
                                        <div class="infowindow__img" style="background-image:url(${hotel.imageInfos.length > 0 ? hotel.imageInfos[0].url : self.baseUrl + '/images/images-default.jpg'});"></div>
                                        <div class="infowindow__detail">
                                            <h5 class="infowindow__title">${hotel.name}</h5>
                                            <div class="infowindow__star">
                                                ${Array(parseInt(hotel.stars)).join(0).split(0).map((item, i) => `
                                                    <span class="icon-star"></span>
                                                `).join('')}
                                            </div>
                                            <span><i class="ico icon-location-arrow"></i> ${hotel.addressLines}</span>
                                            ${typeof hotel.trustyou !== 'undefined' ? `
                                                <div class="infowindow__score">
                                                    <div class="reviews-score reviews-score__${hotel.trustyou.score_description.toLowerCase().replace(/ +/g, '-')}">${hotel.trustyou.score_display}</div>
                                                    <div class="text">
                                                        <span>${hotel.trustyou.score_description}</span>
                                                        <small>${hotel.trustyou.reviews_count} ${parseInt(hotel.trustyou.reviews_count) > 1 ? `reviews` : 'review'}</small>
                                                     </div>
                                                </div>
                                            ` : ``}
                                        </div>
                                     </div>`;

                    setTimeout(function() {
                        self.infowindow.setContent(infoWindowHTML);
                        self.infowindow.open(map, marker);
                    }, 500);
                }
            });
        },
        methods: {
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            isHotelCancellation(hotel) {
                let isCancellation = 'non';
                let availableRoomType = hotel.availableRooms[0].availableRoomTypes[0];
                if (availableRoomType && availableRoomType.freeCancellation && availableRoomType.freeCancellation !== 'undefined') isCancellation = 'free';  
                
                for (let i = 0; i < hotel.availableRooms.length; i++) {
                    for (let j = 0; j < hotel.availableRooms[i].availableRoomTypes.length; j++) {
                        if (hotel.availableRooms[i].availableRoomTypes[j].cancelFreeBeforeDate) return 'free';
                    }
                }

                if (!availableRoomType) return isCancellation;
                let cancelCharges = availableRoomType.roomCancelCharges != undefined && availableRoomType.roomCancelCharges ? availableRoomType.roomCancelCharges : [];
                
                if (cancelCharges.length > 0) {
                    for (let i = 0; i < cancelCharges.length; i++) {
                        if (cancelCharges[i].amount > 0) {
                            isCancellation = 'apart';
                        }
                    }
                }
                return isCancellation;
            },
            getSpecialOfferPrice(hotel, isDividePrice) {
                //isDividePrice true, specialoffer will be divided by number of pax or person depends on the product
                var specialOfferPrice = 0;
                var paxCount = this.calculatePaxCount();
                var nightCount = this.calculateNights();
                var displayPrice = this.$store.state.workContext.product.displayPrice;
                var availableRooms = hotel.availableRooms;
                if (!availableRooms) {
                    return 0;
                }
                for (var j = 0; j < availableRooms.length; j++) {
                    var specialOffer = this.getTotalSpecialOffersPerRoom(this.getSpecialOffers(hotel, j));

                    if (specialOffer) {
                        specialOfferPrice += Math.ceil(parseFloat(specialOffer));
                    } else {
                        specialOfferPrice = 0;
                    }
                }
                var roomPrice = specialOfferPrice / this.packageQuery.paxInfos.length;
                if (isDividePrice) {
                    //price per night
                    if (displayPrice === 0) {
                        return Math.ceil(parseFloat(specialOfferPrice / nightCount));
                    }
                    //price per person
                    if (displayPrice === 1) {
                        return Math.ceil(parseFloat(specialOfferPrice / paxCount));
                    }
                    //Price per room
                    if (displayPrice === 2) {
                        return Math.ceil(parseFloat(specialOfferPrice / roomPrice));
                    }
                }
                return specialOfferPrice;
            },
            getOriginalPrice(hotel) {
                if (!hotel.cheapestPrice && !loading.flightDetails) {
                    return "-";
                }
                var packagePrice = this.totalPackagePriceValue(hotel);
                var displayPrice = this.$store.state.workContext.product.displayPrice;

                //gets special offer price from the first Room

                var specialOfferAmount = this.getSpecialOfferPrice(hotel, false);

                //price per night
                if (displayPrice === 0) {
                    return this.averagePricePerNight(packagePrice + specialOfferAmount);
                }
                //price per person
                if (displayPrice === 1) {
                    return this.averagePricePerPerson(packagePrice + specialOfferAmount);
                }
                //Price per room
                if (displayPrice === 2) {
                    return this.averagePricePerRoom(packagePrice + specialOfferAmount);
                }
                return "-";
            },
            getSpecialOffers(hotel, index) {
                for (var j = 0; j < hotel.availableRooms[index].availableRoomTypes.length; j++) {
                    var availableRoomType = hotel.availableRooms[index].availableRoomTypes[j];
                    if (availableRoomType.selected) {
                        return availableRoomType.specialOffers;
                    }
                }
                return null;
            },
            // add all the special offers in a room
            getTotalSpecialOffersPerRoom(roomTypeSpecialOffer) {
                if (!roomTypeSpecialOffer) {
                    return 0;
                }

                var totalSpecialOfferPrice = 0;
                for (var k = 0; k < roomTypeSpecialOffer.length; k++) {
                    totalSpecialOfferPrice += roomTypeSpecialOffer[k].amount; //gets special offer object for the first room type
                }
                return Math.ceil(parseFloat(totalSpecialOfferPrice));
            },

            getAvgPrice(hotel) {
                var packagePrice = this.totalPackagePriceValue(hotel);

                if (packagePrice === 0) {
                    return "...";
                }

                var displayPrice = this.product.displayPrice;

                //price per night
                if (displayPrice === 0) {
                    return this.averagePricePerNight(packagePrice);
                }
                //price per person
                if (displayPrice === 1) {
                    return this.averagePricePerPerson(packagePrice);
                }
                //Price per room
                if (displayPrice === 2) {
                    return this.averagePricePerRoom(packagePrice);
                }
                return "...";
            },
            averagePricePerPerson(totalPackagePrice) {
                var paxCount = this.calculatePaxCount();
                var price = totalPackagePrice / paxCount;
                return (price.toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            averagePricePerNight(totalPackagePrice) {
                var nightCount = this.calculateNights();
                totalPackagePrice = totalPackagePrice / nightCount;
                return (totalPackagePrice.toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            calculateNights() {
                var oneDay = 24 * 60 * 60 * 1000;
                var checkinDate = Date.parse(this.packageQuery.checkIn ? this.packageQuery.checkIn : this.packageQuery.departureDate);
                var checkoutDate = Date.parse(this.packageQuery.checkOut ? this.packageQuery.checkOut : this.packageQuery.returnDate);
                var nights = Math.round(Math.abs((checkoutDate - checkinDate) / (oneDay)));
                return nights;
            },
            calculatePaxCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                    count += paxInfo.childCount;
                    count += paxInfo.infantCount;
                }
                return count;
            },
            totalPackagePriceValue(hotel) {
                if (hotel.cheapestPrice === 0) {
                    return 0;
                }

                if (this.enabledFlights && !this.flightStore.outboundFlight) {
                    return 0;
                }

                if (!hotel.availableRooms) {
                    return 0;
                }

                var price = 0;
                for (var j = 0; j < hotel.availableRooms.length; j++) {
                    for (var k = 0; k < hotel.availableRooms[j].availableRoomTypes.length; k++) {
                        var availableRoomType = hotel.availableRooms[j].availableRoomTypes[k];
                        if (availableRoomType.selected) {
                            //price += availableRoomType.price;
                            price += availableRoomType.totalPrice;
                            break;
                        }
                    }
                }

                price += this.totalFlightPrice();

                return price;
            },
            totalFlightPrice() {
                var price = 0;
                if (this.flightStore.outboundFlight)
                    price += this.flightStore.outboundFlight.solutionPrice;
                if (this.flightStore.inboundFlight) {
                    var priceChanged = this.flightStore.inboundFlight.solutionPrice - this.flightStore.outboundFlight.solutionPrice;
                    if (priceChanged != 0)
                        price += priceChanged;
                }
                return price;
            },
            getRoomTypeName(hotel, index) {
                if (!hotel.availableRooms || hotel.availableRooms.length === 0) return "";
                for (var j = 0; j < hotel.availableRooms[index].availableRoomTypes.length; j++) {
                    var availableRoomType = hotel.availableRooms[index].availableRoomTypes[j];
                    if (availableRoomType.selected) {
                        return availableRoomType.description;
                    }
                }
                return "";
            },
            replaceImage(path) {
                var replacedPath;
                if (path.indexOf('static.goquo.com') > -1) {
                    var imagePath = path.split("/");
                    replacedPath = path.replace(imagePath[3], imagePath[3] + '-w300');
                } else {
                    replacedPath = path;
                }

                // Force https
                if (replacedPath.indexOf('http://') == 0) {
                    return "https://" + replacedPath.substr(7);
                }
                return replacedPath;
            },
            gotoHotelsPage(page) {
                this.$emit('pageChanged', page);
            },
            showHotelMapView(hotel, event) {
                if (event) {
                    event.preventDefault();
                    event.stopPropagation();
                }

                if (this.isValidCoordinate(hotel.latitude, hotel.longitude)) {
                    this.$emit('showHotelMapView', hotel);
                }
                return false;
            },
            isValidCoordinate(latitude, longitude) {
                if (latitude && longitude) {
                    return true;
                }
                return false;
            },
            // Checks if a translation is available
            isTranslationAvailable(translation_key) {
                // TRUE if has translation, else FALSE
                return (this.translate(this.$language, translation_key)) ? true : false;
            },
            changeGalleryImage(event, element, source) {
                event.preventDefault();
                var ele = $(element);
                var self = $(event.target);

                if (typeof ele !== "undefined" && ele.length > 0 && typeof source === 'object') {
                    if (!Array.isArray(source)) {
                        ele.css({
                            backgroundImage: 'url(' + source.url + ')'
                        });

                        self.parent().find('.thumb-item').removeClass('active');
                        self.addClass('active');
                        ele.parent().find('.go-control').attr('data-index', self.attr('data-image-index'));
                    } else {
                        var imageIndex = self.attr('data-index') || null;
                        var imageControl = self.attr('data-control') || null;

                        if (imageIndex !== null && imageControl !== null) {

                            switch (imageControl) {
                                case 'next':
                                    self.parent().find('.go-control').attr('data-index', parseInt(imageIndex, 10) < (
                                        source.length - 1) ? parseInt(imageIndex, 10) + 1 : 0);
                                    break;
                                case 'prev':
                                    self.parent().find('.go-control').attr('data-index', parseInt(imageIndex, 10) > 0 ?
                                        parseInt(imageIndex, 10) - 1 : (source.length - 1));
                                    break;
                            }

                            ele.css({
                                backgroundImage: 'url(' + source[parseInt(self.attr('data-index'), 10)].url + ')'
                            });

                            var thumbItems = self.parents('.gallery__wrap').find('.thumb-item');
                            thumbItems.removeClass('active');
                            $(thumbItems.get(parseInt(self.attr('data-index')))).addClass('active');
                        }
                    }
                }

                return false;
            },
            isCanShowHotelPrice(hotel) {
                if (this.enabledFlights && !this.flightStore.outboundFlight) {
                    return false;
                }

                return hotel.cheapestPrice > 0;
            },
            loadHotelInfo(hotel) {
                if (hotel.description) {
                    return;
                }

                $.post('/package/get-hotel-info', {
                    packageId: this.packageQuery.id,
                    cityCode: this.packageQuery.to,
                    hotelId: hotel.hotelId
                }, function (data) {
                    Vue.set(hotel, 'description', data.description);
                    Vue.set(hotel, 'facilities', data.facilities);
                });
            },
            changeHotel(hotel) {
                this.$emit('onHotelSelectedChange', hotel);
            },
            showPriceSummaryPaneHotel(hotelPrice) {
                this.$emit('onShowPriceSummaryPaneHotel', hotelPrice);
            },
            changeHotelMapSelected(hotel) {
                this.$emit('onHotelMapSelectedChanged', hotel);
            },
            onSetSortOrder(order) {
                this.$emit('onSetSortOrder', order)
            },
            removeFilter() {
                this.$emit('onRemoveAllFilters');   
            },
            removeFilters(obj) {
                this.$emit('onRemoveFilters', obj);
            },
            onFiltersChanged() {
                this.$emit('onFiltersChanged');
            },
            formatPrice(price) {
                return (price.toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',')
            },
            momentDateFormat(currentDate, dateFormat) {
                if (!currentDate) return false;
                return moment.utc(currentDate).format(dateFormat);
            }
        }
    }
</script>