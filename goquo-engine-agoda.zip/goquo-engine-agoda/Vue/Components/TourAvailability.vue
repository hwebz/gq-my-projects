﻿<template>
    <div>
        <div class="research flex-grow" v-show="hasErrorMessage">
            <div class="container" v-if="packageQuery">
                <nav class="crumbar">
                    <ul>
                        <li v-lang.SEARCH_TOURS_IN="{0: packageQuery.toCityName}"></li>
                    </ul>
                </nav>
                <div class="research__wrap">
                    <h1 v-lang.YOUR_SEARCH_TOURS_IN="{0: packageQuery.toCityName}"></h1>
                </div>
                <div class="research__content">
                    <div class="research__title">
                        <h2 v-lang.YOUR_SEARCH_DATE_FROM_TO="{0: formatDate(packageQuery.departureDate, 'DD MMMM YYYY'), 1: formatDate(packageQuery.returnDate, 'DD MMMM YYYY')}"></h2>
                        <p v-lang.CHECK_YOUR_SPELLING_AND_TRY_AGAIN></p>
                    </div>
                    <div class="research__form">
                        <div class="search-wrap">
                            <div class="search-tabs search-research">
                                <div class="search-content">
                                    <TourSearchBox :packageQuery="packageQuery" :product="product" :defaultDate="defaultDate" :toCityName="fullToCityName" :to="packageQuery.to" journeyType="1" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div v-show="!hasErrorMessage">
            <div v-if="packageQuery">
                <SessionTimeout :packageId="packageQuery.id" :secondTimeout="packageQuery.ttl"></SessionTimeout>
                <div class="page-title-tabs" v-if="!loadingFilter && !loading.bookingTour && tours.length > 0">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                <div>
                                    <h1 v-lang.TOURS_IN_X="{0: packageQuery.toCityName}"></h1>
                                    <h6 v-if="cheapestTourPrice >= 0" v-lang.TOUR_FROM_X="{0: packageQuery.currency, 1: formatCurrency(cheapestTourPrice)}"></h6>
                                    <h6 v-else>
                                        <div class="lda">
                                            <div class="lda__bar"></div>
                                        </div>
                                    </h6>
                                </div>
                                <div class="date-time-person">
                                    <span>
                                        <i class="icon-calendar"></i>
                                        <span>{{ packageQuery.departureDate| moment("DD MMM") }} - {{ packageQuery.returnDate| moment("DD MMM") }}</span>
                                    </span>
                                    <span>
                                        <i class="icon-user"></i>
                                        <span>
                                            {{calculatePaxCount}} {{calculatePaxCount == 1 ? translateText('PASSENGER', 'Passenger') : translateText('PASSENGERS', 'Passengers')}}
                                        </span>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-5 text-right">
                                <a class="btn-title-tabs" href="#modalChangeDate" data-toggle="modal" data-target="#modalChangeDate">
                                    <i class="icon-search"></i><span v-lang.EDIT_SEARCH></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="page-title-tabs" v-else>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                <div class="lda">
                                    <div class="lda__bar lda__bar--h27"></div>
                                    <div class="lda__bar lda__bar--50"></div>
                                </div>
                            </div>
                            <div class="col-md-5 text-right">
                                <a class="btn-title-tabs">
                                    <div class="lda__bar"></div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="fh-tabs__wrap tour-selected" v-if="selectedTours && selectedTours.length > 0">
                    <div class="container">
                        <div class="fh-tabs__overview">
                            <div class="fh-tabs__item fh-tabs__hotel fh-tabs__transfer active">
                                <div class="title-option">
                                    <div class="title-option-name text-uppercase" v-lang.TOUR></div>
                                </div>
                                <ul>
                                    <li v-for="tour in selectedTours">
                                        <h4>{{tour.name}}</h4>
                                        <div class="title-option-tag">
                                            <a href="#">
                                                <i class="icon icon-user"></i>
                                                <span>x{{tour.adults + tour.children}}</span>
                                            </a>
                                            <a href="#">
                                                <span>{{tour.operatorDate | moment('DD MMM YYYY')}} {{tour.departureTime}}</span>
                                            </a>
                                            <a href="#" class="remove" @click="removeTour(tour, tours.indexOf(tour))">
                                                <span>X</span>
                                            </a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="fh-tabs__item fh-tabs__control">
                                <div class="title-class text-uppercase" v-lang.TOUR></div>
                                <div class="title-perperson text-uppercase" v-lang.TOTAL_PRICE></div>
                                <div class="price">
                                    <span>{{packageQuery.currency}}</span>
                                    <strong>{{packageQuery.priceSummary.toursPrice + packageQuery.priceSummary.gstPrice | formatCurrency}}</strong>
                                </div>
                                <a class="link-small" href="#modalPriceBreakdown" data-toggle="modal" @click.prevent="getFullTourInfo({gstMarkupPrice: packageQuery.priceSummary.toursPrice + packageQuery.priceSummary.gstPrice, isSummary: true}, 0, false)" v-lang.PRICE_BREAKDOWN></a>
                                <a class="btn btn-block btn-primary bt-effect bt-selected" href="#" @click="checkBookingTour($event,nextButtonUrl)" v-lang.BOOK></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="fh-tabs__wrap tour-selected" v-if="packageQuery.tours && packageQuery.tours.length > 0 && !(selectedTours && selectedTours.length > 0)">
                    <div class="container">
                        <div class="fh-tabs__overview">
                            <div class="fh-tabs__item fh-tabs__hotel fh-tabs__transfer active">
                                <div class="title-option">
                                    <div class="title-option-name text-uppercase" v-lang.TOUR></div>
                                </div>
                                <ul>
                                    <li v-for="n in [0, 1, 2]">
                                        <h4>
                                            <div class="lda__bar lda__bar--50"></div>
                                        </h4>
                                        <div class="title-option-tag">
                                            <div class="lda__bar lda__bar--50"></div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="fh-tabs__item fh-tabs__control">
                                <div class="lda lda--fbot">
                                    <div class="lda__bar lda__bar--50"></div>
                                    <div class="lda__bar lda__bar--50"></div>
                                    <div class="lda__bar lda__bar--50"></div>
                                    <div class="lda__bar lda__bar--split"></div>
                                    <div class="lda__bar lda__bar--two"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="avai-findbar-tour">
                        <div class="dropdownBox__wrap">
                            <div class="dropdownBox dropdown ionrangeslider">
                                <span>&nbsp;</span>
                                <div class="dropdownBox__name dropdown-toggle" data-toggle="dropdown">
                                    <div class="dropdownBox__title" v-lang.PRICE_RANGE></div>
                                    <div class="dropdownBox__text" v-if="!loadingFilter && !loading.bookingTour">{{packageQuery.currency}} {{selectedMinPrice}} - {{packageQuery.currency}} {{selectedMaxPrice}}</div>
                                    <div class="dropdownBox__text" v-else>
                                        <div class="lda__bar"></div>
                                    </div>
                                </div>
                                <div class="dropdownBox__button"><i class="icon-down-chevron"></i></div>
                                <div class="dropdownBox__button remove hidden" id="price-remove" @click="setTourPriceRanges(null, null)"><i class="icon icon-remove"></i></div>
                                <div class="dropdownBox__list dropdown-menu" @click="function(e) {e.stopPropagation();}">
                                    <div class="item">
                                        <IonRangeSlider v-if="!loadingFilter" :min="minPrice"
                                                        :max="maxPrice"
                                                        :from="selectedMinPrice"
                                                        :to="selectedMaxPrice"
                                                        :prefix="packageQuery.currency + ' '"
                                                        @changed="setTourPriceRanges"
                                                        prettifySeparator=","
                                                        :currencyDecimals="packageQuery.currencyDecimals" />
                                    </div>
                                </div>
                            </div>
                            <div class="dropdownBox dropdown" v-if="categories.length > 0">
                                <div class="dropdownBox__name dropdown-toggle" data-toggle="dropdown">
                                    <div class="dropdownBox__title" v-lang.ACTIVITY_TYPE></div>
                                    <div class="dropdownBox__text">
                                        <template v-if="categoriesFilter.length > 0">
                                            <span v-for="cat in categoriesFilter">{{cat.value.description}}, </span>
                                        </template>
                                        <span v-else v-lang.SELECT_ACTIVITY></span>
                                    </div>
                                </div>
                                <div class="dropdownBox__button"><i class="icon-down-chevron"></i></div>
                                <div class="dropdownBox__button remove hidden" id="activity-remove" @click="filterByCategory(null)"><i class="icon icon-remove"></i></div>
                                <div class="dropdownBox__list dropdown-menu">
                                    <div class="item" v-for="category in categories" @click="filterByCategory(category)" :class="{'active': category.selected}"><i class="icon icon-checked"></i>{{category.value.description}}</div>
                                </div>
                            </div>
                            <div class="dropdownBox dropdown">
                                <div class="dropdownBox__name dropdown-toggle" data-toggle="dropdown">
                                    <div class="dropdownBox__title" v-lang.SORT_BY></div>
                                    <div class="dropdownBox__text">{{sortingLabel}}</div>
                                </div>
                                <div class="dropdownBox__button"><i class="icon-down-chevron"></i></div>
                                <div class="dropdownBox__list dropdown-menu">
                                    <div class="item" @click="sorting('Priority', true)" :class="{'active': tourFilter.sortOrderBy === 'Priority' && tourFilter.sortOrderByAsc}" v-lang.PRIORITY></div>
                                    <div class="item" @click="sorting('Price', true)" :class="{'active': tourFilter.sortOrderBy === 'Price' && tourFilter.sortOrderByAsc}" v-lang.LOWEST_PRICE></div>
                                    <div class="item" @click="sorting('Price', false)" :class="{'active': tourFilter.sortOrderBy === 'Price' && !tourFilter.sortOrderByAsc}" v-lang.HIGHEST_PRICE></div>
                                    <div class="item" @click="sorting('Name', true)" :class="{'active': tourFilter.sortOrderBy === 'Name' && tourFilter.sortOrderByAsc}" v-lang.NAME_A_TO_Z></div>
                                    <div class="item" @click="sorting('Name', false)" :class="{'active': tourFilter.sortOrderBy === 'Name' && !tourFilter.sortOrderByAsc}" v-lang.NAME_Z_TO_A></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <template v-if="!isNoDataResult">
                        <TourResults :tours="tours" 
                                     :isLoadMore="isLoadMore"
                                     :tourInfor="tourInfor"
                                     :selectedTours="selectedTours"
                                     :packageQuery="packageQuery"
                                     :loading="loading" 
                                     :tempDepartures="tempDepartures"
                                     :loadingFilter="loadingFilter"
                                     @onChangeDeparture="obj => changeDeparture(obj.event, obj.tour, obj.departure, obj.index)"
                                     @onChangeTime="obj => changeTime(obj.tour, obj.index, obj.time)"
                                     @onFilterDepartures="obj => filterDepartures(obj.event, obj.tour, obj.index)"
                                     @onGetFullTourInfo="obj => getFullTourInfo(obj.tour, obj.index, obj.isShowModal)"
                                     @onChangeActivity="obj => changeActivity(obj.tour, obj.index, obj.option)"
                                     @onBookingTour="obj => bookingTour(obj.event, obj.tour, obj.index)"
                                     @onOperatorDateChanged="obj => onOperatorDateChanged(obj.operatorDate, obj.tour, obj.index)"
                                     @onChangeDeparturePointName="obj => changeDeparturePointName(obj.event, obj.tour, obj.index)"
                                     @onChangePax="obj => changePax(obj.event, obj.paxInfo, obj.tour, obj.index)"
                                     @onRemoveTour="obj => removeTour(obj.tour, obj.index)"
                                     @onGoToTourPage="gotoTourPage"/>
                    </template>
                    <template v-else>
                        <div class="no-hotel-available">
                            <div>
                                <h3 v-lang.OOPS></h3>
                                <p v-lang.THERE_IS_NO_TOUR_AVAILABLE></p>
                                <button class="btn btn-sm btn-danger with-icon" @click="removeFilters"><i class="ico icon-remove"></i> <span v-lang.REMOVE_FILTERS></span></button>
                            </div>
                        </div>
                    </template>
                </div>
                <div class="modal fade modal-md" id="modalChangeDate" tabindex="-1" role="dialog" aria-hidden="true" v-show="hasErrorMessage">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-title ">
                                <strong v-lang.SEARCH_TOUR></strong>
                                <button class="modal-close" data-dismiss="modal">
                                    <i class="icon-remove"></i>
                                </button>
                            </div>
                            <form method="GET" action="/package/start-search" data-val="true" @submit="onValidate">
                                <div class="search-tabs search-popup">
                                    <div class="search-content">
                                        <div class="search-grid">
                                            <AjaxSelect name="To"
                                                        :placeholder="translateText('CHOOSE_A_CITY', 'Choose a city...')"
                                                        :defaultValue="packageQuery.to" :defaultText="packageQuery.toCityName"
                                                        type="tour" 
                                                        :txtLabel="translateText('WHERE_ARE_YOU_GOING', 'Where are you going?')"
                                                        icon="ico icon-location-arrow"
                                                        :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_CITY', 'Please choose a city')"
                                                        @onValidate="onValidate"
                                                        :url="'/api/get-cities'" />
                                            <DateRangePicker v-model="defaultDate" journeyType="1" date-format="DD/MM/YYYY" isFlight="true" />
                                            <PaxSelector :maxRooms="3" :isTourOnly="true" />
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="hidden" name="OrderId" :value="packageQuery.orderId" />
                                    <input type="hidden" name="Currency" :value="packageQuery.currency" />
                                    <input type="hidden" name="ProductId" :value="packageQuery.productId" />
                                    <button id="btnSumitSearchFormTour" class="btn btn-sm btn-primary bt-effect" type="submit" v-lang.SEARCH></button>
                                    <button class="btn btn-sm btn-default bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!--<div class="modal fade big" id="modalTourDetail" tabindex="-1" role="dialog" aria-hidden="true" v-if="tourInfor">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-body modal-body-gray npd">
                                <div class="flight-detail-title">
                                    <strong>{{tourInfor.name}}</strong>
                                    <button class="modal-close" data-dismiss="modal">
                                        <i class="icon-remove"></i>
                                    </button>
                                </div>
                                <div class="fh-tabs__item fh-tabs__detail tour-modal">
                                    <div class="fh-tabs__detail-slider">
                                            <div class="fh-tabs__detail-slider-item" v-if="tourInfor.thumbnail"
                                                 :style="'background-image:url(' + tourInfor.thumbnail + ');'">
                                            </div>
                                            <div class="fh-tabs__detail-slider-item"
                                                 v-for="img in tourInfor.images"
                                                 v-if="tourInfor.images.length > 0"
                                                 :style="'background-image:url(' + img + ');'">
                                            </div>
                                    </div>
                                    <div class="fh-tabs__detail-slider-nav">
                                            <div class="fh-tabs__detail-slider-item" v-if="tourInfor.thumbnail"
                                                 :style="'background-image:url(' + tourInfor.thumbnail + ');'">
                                            </div>
                                            <div class="fh-tabs__detail-slider-item"
                                                 v-for="img in tourInfor.images"
                                                 v-if="tourInfor.images.length > 0"
                                                 :style="'background-image:url(' + img + ');'">
                                            </div>
                                    </div>
                                    <h4>Description</h4>
                                    <div class="fh-tabs__detail-description" v-html="tourInfor.summary"></div>
                                    <template v-if="tourInfor.salesPoints && tourInfor.salesPoints.length > 0">
                                        <h4>Interesting Points</h4>
                                        <div class="fh-tabs__detail-description">
                                            <ul class="interested-points">
                                                <li v-for="salePoint in tourInfor.salesPoints">
                                                    <i class="icon icon-check-mark"></i>
                                                    <span v-html="salePoint"></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </template>
                                    <template v-if="tourInfor.inclusions && tourInfor.inclusions.length > 0">
                                        <h4>Inclusions</h4>
                                        <div class="fh-tabs__detail-description">
                                            <ul class="interested-points">
                                                <li v-for="inclusion in tourInfor.inclusions">
                                                    <i class="icon icon-check-mark"></i>
                                                    <span v-html="inclusion"></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </template>
                                    <template v-if="tourInfor.exclusions && tourInfor.exclusions.length > 0">
                                        <h4>Exclusions</h4>
                                        <div class="fh-tabs__detail-description">
                                            <ul class="interested-points">
                                                <li v-for="exclusion in tourInfor.exclusions">
                                                    <i class="icon icon-cross"></i>
                                                    <span v-html="exclusion"></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </template>
                                    <template v-if="tourInfor.additionalInfo && tourInfor.additionalInfo.length > 0">
                                        <h4>Additional Information</h4>
                                        <div class="fh-tabs__detail-description">
                                            <ul class="interested-points">
                                                <li v-for="addInfo in tourInfor.additionalInfo">
                                                    <i class="icon icon-right-arrow"></i>
                                                    <span v-html="addInfo"></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </template>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-sm btn-primary bt-effect" type="button" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>-->
                
                <a class="back-to-top" href="#" @click="backTop">
                    <i class="icon icon-up-chevron"></i>
                    <span v-lang.BACK_TO_TOP></span>
                </a>
            </div>
        </div>
    </div>
</template>
<script>
    import Vue from 'vue'
    import _ from 'lodash';
    import { mapState } from 'vuex'
    import Cookie from 'js-cookie'
    import TourSearchBox from './TourSearchBox.vue';
    import IonRangeSlider from './IonRangeSlider.vue';
    import AjaxSelect from './AjaxSelect.vue'
    import DateRangePicker from './DateRangePicker.vue'
    import PaxSelector from './PaxSelector.vue'
    import SessionTimeout from './SessionTimeout.vue'
    import TourResults from "./TourResults.vue";
    
    export default {
        components: {TourResults, TourSearchBox, IonRangeSlider, PaxSelector, DateRangePicker, AjaxSelect, SessionTimeout },
        data() {
            return {
                packageQuery: null,
                product: null,
                tours: [],
                hasErrorMessage: false,
                isSearchCompleted: false,
                categories: [],
                categoriesFilter: [],
                minWidthSize: 500,
                minHeightSize: 375,
                maxPrice: 0,
                minPrice: 0,
                selectedMinPrice: 0,
                selectedMaxPrice: 0,
                isNoDataResult: false,
                pagination: {
                    current: 1,
                    toursPerPage: 10,
                    totalTours: 0,
                    totalPages: 1,
                    currentRowOnPage: 0
                },
                tourFilter: {
                    sortOrderBy: "Priority",
                    sortOrderByAsc: true,
                },
                pingCount: 0,
                errorMessage: null,
                nextButtonUrl: null,
                skipButtonUrl: null,
                hotelsName: '',
                selectedTours: [],
                addOnSelecteds: [],
                seatSelecteds: [],
                currentSection: 1,
                tourInfor: {},
                tourIndexInfor: 0,
                loading: {
                    bookingTour: false,
                    paginationLoading: false
                },
                loadingFilter: false,
                isFilterByPriceRageCategory: false,
                promoCode: null,
                defaultDate: null,
                cheapestTourPrice: null,
                cheapestTourThumbnail: null,
                tempDepartures: [],
                searchConditions: {
                    adultCount: 0,
                    childCount: 0,
                    infantCount: 0
                }
            }
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            baseUrl: state => state.workContext.baseUrl,
            calculatePaxCount() {
                return this.searchConditions.adultCount + this.searchConditions.childCount;
            },
            adultCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                }
                return count;
            },
            childCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.childCount;
                }
                return count;
            },
            infantCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.infantCount;
                }
                return count;
            },
            fullToCityName() {
                var self = this;
                return self.packageQuery.toCityName + ' (' + self.packageQuery.to + ') ,' + self.packageQuery.toCountryName;
            },
            sortingLabel() {
                let lbl = '';
                let filter = this.tourFilter;
                if (filter.sortOrderBy === 'Price') {
                    if (filter.sortOrderByAsc) lbl = 'LOWEST_PRICE';
                    else lbl = 'HIGHEST_PRICE';
                    //lbl += filter.sortOrderBy;
                } else if (filter.sortOrderBy === 'Name') {
                    //lbl = filter.sortOrderBy;
                    if (filter.sortOrderByAsc) lbl += 'NAME_A_TO_Z';
                    else lbl += 'NAME_Z_TO_A';
                } else {
                    lbl = filter.sortOrderBy;
                }
                return this.translateText(lbl.toUpperCase(), lbl);
            },
            isLoadMore() {
                let self = this;
                let pg = self.pagination;
                
                return (pg.current + 1) * pg.currentRowOnPage < pg.totalTours;
            }
        }),
        created() {
            var self = this;
            self.loadingFilter = true;
            var packageId = $('#PackageId').val();
            this.nextButtonUrl = $('#NextButtonUrl').val();
            this.skipButtonUrl = $('#SkipButtonUrl').val();

            $.post('/package/work-context/' + packageId, function (data) {
                data.baseUrl = $("#baseURL").val();
                $.getJSON(data.baseUrl + '/resources.json', function (res) {
                    data.clientResources = res;
                }).always(function () {
                    self.$store.commit('setWorkContext', data);
                })
               
                data.packageQuery.departureDate = moment.utc(data.packageQuery.departureDate);
                data.packageQuery.returnDate = moment.utc(data.packageQuery.returnDate);
                data.packageQuery.checkIn = moment.utc(data.packageQuery.checkIn);
                data.packageQuery.checkOut = moment.utc(data.packageQuery.checkOut);
                self.$store.commit('setWorkContext', data);
                self.packageQuery = data.packageQuery;

                self.searchConditions = {
                    adultCount: self.adultCount,
                    childCount: self.childCount,
                    infantCount: self.infantCount
                }
                self.promoCode = self.packageQuery.promoCode;
                if (!self.packageQuery.tours) {
                    Vue.set(self.packageQuery, "tours", []);
                }
                self.product = data.product;
                self.createPingRequest();

                if (self.packageQuery.hotels && self.packageQuery.hotels.length > 0) {
                    self.hotelsName = self.packageQuery.hotels[0].name;
                }

                // set default date
                let startDate = Vue.moment(self.packageQuery.departureDate).format('MM/DD/YYYY');
                let endDate = Vue.moment(self.packageQuery.returnDate).format('MM/DD/YYYY');

                self.defaultDate = startDate + ',' + endDate;
                $(".foo-copy-right").addClass('extra-padding');
            });
            self.loadingFilter = false;
        },
        mounted() {
            $(window).on('scroll', function() {
                let btt = $(".back-to-top");
                if ($(window).scrollTop() > 200) btt.addClass('shown');
                else  btt.removeClass('shown');
            });
        },
        methods: {
            formatDate(date, format) {
                return Vue.moment(date).format(format);
            },
            removeFilters() {
                let self = this;
                self.setTourPriceRanges(null, null); 
                self.filterByCategory(null);
            },
            backTop() {
                $('html,body').animate({
                    scrollTop: 0
                }, 'slow');
            },
            departureChanged(tour, code, name) {
                var vm = this;
                var $element = $(vm.$el);
                tour.departurePoint = code;
                tour.departurePointName = name;
                $element.find("input[name='DeparturePointName']").val(name);
            },
            changeDeparture(e, tour, departure, index) {
                this.departureChanged(tour, departure.code, departure.name);
                this.changeDeparturePoint(tour, index);
            },
            onOperatorDateChanged(operatorDate, tour, index) {
                tour.operatorDate = operatorDate;
                this.changeDailyRate(tour, index);
            },
            getDeparturePoints(tour) {
                let selectedDate = tour.operatorDate + "T00:00:00";
                
                tour.dailyRates.map(rate => {
                   if (rate.date === selectedDate) {
                       return rate.departures;
                   } 
                });
                
                return false;
            },
            initializeSlickSlider() {
                let eleSelector = '#modalTourDetail .fh-tabs__detail-slider';
                let eleNavSelector = '#modalTourDetail .fh-tabs__detail-slider-nav';
                let element = $(eleSelector);
                let elementNav = $(eleNavSelector);
                
                if ($.fn.slick) {
                    element.slick({
                        lazyLoad: 'ondemand',
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        centerMode: true,
                        arrows: false,
                        fade: true,
                        asNavFor: eleNavSelector
                    });
                    elementNav.slick({
                        slidesToShow: 10,
                        slidesToScroll: 1,
                        asNavFor: eleSelector,
                        focusOnSelect: true
                    });
                }
            },
            initializeMagnificPopup() {
                let pics = $(".tour-results .picture");
                if (typeof pics !== 'undefined' && pics.length > 0) {
                    pics.each(function(index, item) {
                        let $element = $(item);
                        if ($element.hasClass('magnificpopup')) return;
                        let imgs = $element.attr('data-tour-images').split('|');
                        let imgsObj = [];

                        if (imgs.length > 0) {
                            imgs.map(img => {
                                if (img != '') imgsObj.push({
                                    src: img
                                }) ;
                            });
                            $element.addClass('magnificpopup');
                            if ($.fn.magnificPopup) $element.magnificPopup({
                                items: imgsObj,
                                mainClass: 'mfp-with-zoom',
                                gallery: {
                                    enabled: true
                                },
                                type: 'image'
                            });
                        }
                    });
                }
            },
            changePax(event, paxInfo, tour, index) {
                let self = this;
                let selectedTour = self.tours[self.tours.indexOf(tour)];
                selectedTour.adults = paxInfo.adultCount;
                selectedTour.children = paxInfo.childCount;

                self.getTourBreakdown(tour, index);
            },
            validateInput(context) {
                let parent = context.parents('.box-search');
                let label = parent.find(">strong, >.dropdown-toggle > strong");
                let labelVals = {
                    old: context.attr('data-label'),
                    new: context.attr('data-required-message')
                };

                if (!context.val()) {
                    parent.addClass('error');
                    label.text(labelVals.new);
                    return false;
                } else {
                    parent.removeClass('error');
                    label.text(labelVals.old);
                }
                return true;
            },
            onValidate(e) {
                let self = this;
                let box = $(e.target);
                let errors = 0;
                box.find("input[name='To'], input[name='DeparturePoint']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                if (errors == 0) {
                    return true;
                }
                if (e) e.preventDefault();
            },
            createPingRequest: function () {
                var self = this;
                self.loading.bookingTour = true;
                this.pingCount++;

                if (this.pingCount >= 10) {
                    return;
                }

                var productTypes = [{
                    productType: 4,
                    storedKey: null
                }];

                $.post("/package/product-status/" + self.packageQuery.id, { productTypeStatuses: productTypes }, function (data) {
                    if (data.length > 0) {

                        if (data.some(x => x.status == 3)) {
                            window.location = '/package/restart-search/' + self.packageQuery.id;
                        }

                        var completed = data.every(x => x.status == 1);
                        var haveError = data.some(x => x.status == 2);
                        if (haveError) {
                            //self.checkBookingTour(self.nextButtonUrl);
                            self.notifyErrorMessage(data.find(x => x.status == 2).message);

                        } else {
                            if (completed) {
                                self.checkSearchComplete();
                                self.getResultsPage(1);
                            } else {
                                self.createPingRequest();
                            }
                        }
                    } else {
                        self.createPingRequest();
                    }
                    self.loading.bookingTour = false;
                });
            },
            notifyErrorMessage(errorMessage) {
                let self = this;
                console.log("notifyErrorMessage: " + errorMessage);
                self.hasErrorMessage = true;
                self.errorMessage = errorMessage;
                self.hideSplashScreen();
            },
            getResultsPage(newPage, hasFilters) {
                var self = this;
                if (newPage == 1) self.loading.bookingTour = true;
                else self.loading.paginationLoading = true;
                self.pagination.current = newPage;
                var data = {
                    packageId: self.packageQuery.id,
                    pageIndex: newPage,
                    pageSize: this.pagination.toursPerPage,
                    sortOrderBy: this.tourFilter.sortOrderBy,
                    sortOrderByAsc: this.tourFilter.sortOrderByAsc,
                    totalResult: this.pagination.totalTours,
                    categories: []
                };

                if (hasFilters) {
                    data.minPrice = self.selectedMinPrice;
                    data.maxPrice = self.selectedMaxPrice;
                    data.hasFilters = true;

                    var categoryIndex = 0;
                    for (var i = 0; i < self.categoriesFilter.length; i++) {
                        var category = self.categoriesFilter[i];
                        data["categories[" + categoryIndex + "].Description"] = category.value.description;
                        categoryIndex++;
                    }
                    self.pagination.current = newPage;
                }

                if (!this.hasErrorMessage) {
                    $.ajax({
                        url: 'get-tours',
                        data: data,
                        type: 'POST',
                        beforeSend: function () {
                            self.isFilterByPriceRageCategory = true;
                        },
                        success: function (response) {
                            var data = response;

                            if (data.tours.length == 0 || data.tours == null) {
                                self.hasErrorMessage = true;
                                self.isNoDataResult = true;
                                return;
                            } else {
                                self.isNoDataResult = false;
                                self.removeDuplicateImages(data.tours);
                                self.setThumbnailForTour(data.tours);
                                //self.removeImagesBySize(data.tours);
                                
                                if (newPage > 1) {
                                    self.tours.push(...data.tours)
                                } else {
                                    self.tours = data.tours;
                                }
                                
                                self.pagination.currentRowOnPage = data.tours.length;
                                self.pagination.totalTours = data.totalTours;

                                self.pagination.totalPages = Math.ceil(data.totalTours / self.pagination.toursPerPage);

                                let toursSelected = self.packageQuery.tours;
                                
                                if (toursSelected && toursSelected.length > 0) {
                                    self.selectedTours = [...toursSelected];
                                }
                                
                                $(data.tours).each(function (i, tour) {
                                    if (tour.selected) {
                                        // var isPushToSelected = true;
                                        // $.each(self.selectedTours, function (indexSelected, item) {
                                        //     if (tour.id === item.id) {
                                        //         isPushToSelected = false;
                                        //         return false;
                                        //     }
                                        // });
                                        // if (isPushToSelected) {
                                        //     self.selectedTours.push(tour);
                                        // }

                                        self.changeActivity(tour, i);
                                        self.changeDailyRate(tour, i);
                                        self.changeDeparturePoint(tour, i);
                                        tour.gstMarkupPrice = tour.price + tour.gstPrice;
                                    }
                                    else {
                                        //tour.operatorDate = "";
                                        //tour.children = 0;
                                        tour.activityCode = tour.activities[0].code;

                                        var activity = null;
                                        for (var i = 0; i < tour.activities.length; i++) {
                                            if (tour.activities[i].code == tour.activityCode) {
                                                activity = tour.activities[i];
                                            }
                                        }

                                        if (activity) {
                                            tour.dailyRates = activity.dailyRates;
                                        }
                                        else {
                                            tour.dailyRates = tour.activities[0].dailyRates;
                                        }

                                        tour.departures = [];

                                        tour.gstMarkupPrice = tour.activities[0].dailyRates && tour.activities[0].dailyRates.length > 0 ? (tour.activities[0].dailyRates[0].price + tour.gstPrice) : (tour.price + tour.gstPrice);
                                    }
                                    let selectedActivity = tour.activities.filter(act => {
                                        return act.code === tour.activityCode;
                                    })[0];
                                    let operDate = moment(String(tour.operatorDate ? tour.operatorDate : selectedActivity.dailyRates[0].date)).format('YYYY-MM-DD');
                                    tour.operatorDate = operDate;
                                });
                                //if (!self.cheapestTourPrice) self.cheapestTourPrice = self.tours[0].gstMarkupPrice;
                                if (newPage == 1) self.loading.bookingTour = false;
                                else self.loading.paginationLoading = false
                                self.isSearchCompleted = true;
                            }
                        },
                        complete: function () {
                            self.loading.bookingTour = false;
                            self.isFilterByPriceRageCategory = false;
                        }
                    });

                    let tempData = Object.assign({}, data);
                    tempData.sortOrderBy = 'Price';
                    tempData.pageSize = 1;
                    // get cheapestTourPrice
                    if (!self.cheapestTourPrice) {
                        $.ajax({
                            url: 'get-tours',
                            data: tempData,
                            type: 'POST',
                            success: function (response) {
                                if (response.tours.length == 0 || response.tours == null) {
                                    self.hasErrorMessage = true;
                                    self.isNoDataResult = true;
                                    return;
                                } else {
                                    let cheapestTour = response.tours[0];
                                    self.cheapestTourPrice = cheapestTour.price + cheapestTour.gstPrice;
                                    self.cheapestTourThumbnail = cheapestTour.thumbnail ? cheapestTour.thumbnail : cheapestTour.images[0];
                                }
                            },
                        });
                    }
                }
            },
            gotoTourPage: function () {
                let page = this.pagination.current + 1;
                this.getResultsPage(page, true);
            },
            changeActivity: function (tour, index, option = null) {
                var self = this;
                if (option) tour.activityCode = option.code;
                
                if (!tour.selected) {
                    if (tour.departures != undefined && tour.departures.length > 0) {
                        this.departureChanged(tour, '', '');
                    }

                    tour.operatorDate = '';
                    tour.departures = [];
                    tour.departureTime = '';
                    tour.departureTimes = null;
                }
                var activity = null;
                for (var i = 0; i < tour.activities.length; i++) {
                    if (tour.activities[i].code == tour.activityCode) {
                        activity = tour.activities[i];
                    }
                }

                //  tour.departures
                if (activity) {
                    tour.dailyRates = activity.dailyRates;
                }
                else {
                    tour.dailyRates = tour.activities[0].dailyRates;
                }
                Vue.set(self.tours, index, tour);
                self.changeDailyRate(tour, index);
            },
            changeTime(tour, index, time) {
                var self = this;
                if (time) {
                    tour.departureTime = time;
                }
                Vue.set(self.tours, index, tour);
            },
            changeDailyRate: function (tour, index) {
                let self = this;
                var dailyRates = tour.dailyRates;
                var operatorDate = tour.operatorDate ? tour.operatorDate : moment(dailyRates[0].date).format('YYYY-MM-DD');

                if (!tour.selected) {
                    if (tour.departures != undefined && tour.departures.length > 0) {
                        self.departureChanged(tour, '', '');
                    }
                    tour.departures = [];
                    tour.departureTime = '';
                    tour.departureTimes = null;
                }

                if (dailyRates != null) {
                    for (var i = 0; i < dailyRates.length; i++) {
                        if (operatorDate == moment(String(dailyRates[i].date)).format('YYYY-MM-DD')) {
                            tour.departures = dailyRates[i].departures;
                            self.tempDepartures = dailyRates[i].departures;
                        }
                    }
                }

                if (tour.departures != undefined && tour.departures.length > 0 && !tour.selected) {
                    self.departureChanged(tour, '', '');
                }
                Vue.set(self.tours, index, tour);
            },
            changeDeparturePointName(e, tour, index) {
                let self = this;
                let target = $(e.target);
                let deptVal = target.val();
                tour.departurePoint = deptVal;
                tour.departurePointName = deptVal;
                Vue.set(self.tours, index, tour);
            },
            filterDepartures: _.debounce(function(e, tour) {
                let self = this;
                let target = $(e.target);
                let deptVal = target.val();
                self.tempDepartures = [];
                for (var i = 0; i < tour.departures.length; i++) {
                    if (tour.departures[i].name.includes(deptVal)) self.tempDepartures.push(tour.departures[i]);
                }
            }, 100),
            changeDeparturePoint: function (tour, index) {
                var self = this;
                if (!tour.selected) {
                    tour.departureTime = '';
                }
                var departureTimes = [];
                var dailyRates = tour.dailyRates;
                var operatorDate = tour.operatorDate;
                tour.departureTimes = null;

                if (dailyRates != null) {
                    for (var i = 0; i < dailyRates.length; i++) {
                        if (operatorDate == moment(String(dailyRates[i].date)).format('YYYY-MM-DD')) {
                            var departures = dailyRates[i].departures;
                            for (var j = 0; j < departures.length; j++) {
                                var departure = departures[j];
                                if (departure.code == tour.departurePoint) {
                                    var times = departure.times;
                                    if (times) {
                                        for (var k = 0; k < times.length; k++) {
                                            departureTimes.push(times[k]);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    tour.departureTimes = departureTimes;
                    tour.departureTime = tour.departureTimes[0];
                }
                Vue.set(self.tours, index, tour);
            },
            getTourBreakdown: function (tour, index) {
                var self = this;
                tour.errorMessage = null;
                var adults = tour.adults;
                var children = tour.children;
                var packageId = $('#PackageId').val();

                $.ajax("/package/get-tour-breakdown", {
                    data: {
                        packageId: packageId,
                        tourId: tour.id,
                        adults: adults,
                        children: children,
                        activityCode: tour.activityCode
                    },
                    type: "POST",
                    success: function (response) {
                        var data = response;

                        if (data.success) {
                            tour.gstMarkupPrice = data.price + data.gstPrice;
                            tour.dailyRates[0].price = data.price;
                            tour.price = data.price;
                            tour.adults = data.adults;
                            tour.children = data.children;
                            tour.errorMessage = null;
                            tour.loading = false;
                            Vue.set(self.tours, index, tour);
                        } else {
                            self.translates = {
                                adults: tour.adults,
                                children: tour.children
                            };
                            tour.errorMessage = self.translateText('GET_TOUR_BREAKDOWN_ERROR', 'Get activity breakdown error.');
                            tour.loading = false;
                            Vue.set(self.tours, index, tour);
                        }
                    },
                    error: function () {
                        tour.loading = false;
                        Vue.set(self.tours, index, tour);
                    }
                });
            },
            bookingTour(event, tour, indexTours) {
                var self = this;
                event.preventDefault();
                if (!self.onValidate(event)) return false;
                if (self.validate(event)) {
                    var duplicated = false;
                    tour.loading = true;
                    var choseAdults = parseInt(self.calchoseAdults()) + parseInt(tour.adults);
                    Vue.set(self.tours, indexTours, tour);
                    $.each(self.selectedTours, function (index, item) {
                        var departureTime = '';
                        if (item.departureTime === null) {
                            departureTime = ''
                        }
                        else {
                            departureTime = item.departureTime
                        }

                        if (tour.operatorDate === item.operatorDate) {
                            duplicated = true;
                        }
                    });

                    if (duplicated === true) {
                        bootbox.confirm({
                            message: 'Your selected date and time for this tour has overlapped with a previously selected tour. Are you sure you want to continue?',
                            buttons: {
                                confirm: {
                                    label: 'Yes',
                                    className: 'btn-danger'
                                },
                                cancel: {
                                    label: 'No',
                                    className: 'btn-secondary'
                                }
                            },
                            callback: function (result) {
                                if (result) {
                                    self.doBookingTour(tour, indexTours);
                                } else {
                                    tour.loading = false;
                                    Vue.set(self.tours, indexTours, tour);
                                    return;
                                }
                            }
                        });
                    } else {
                        self.doBookingTour(tour, indexTours);
                    }
                }
            },
            calchoseAdults: function () {
                var self = this;
                var choseAdults = 0;
                if (self.selectedTours) {
                    $.each(self.selectedTours, function (index, item) {
                        choseAdults += parseInt(choseAdults) + parseInt(item.adults);
                    });
                }
                return choseAdults;
            },
            doBookingTour: function (tour, indexTours) {
                var self = this;
                tour.loading = true;
                $.ajax('/package/booking-tour', {
                    type: "POST",
                    data: {
                        PackageId: self.packageQuery.id,
                        TourId: tour.id,
                        OperatorDate: tour.operatorDate,
                        DeparturePoint: tour.departurePoint,
                        DepartureTime: tour.departureTime,
                        Adults: tour.adults,
                        Children: tour.children,
                        ActivityCode: tour.activityCode
                    },
                    beforeSend: function () {
                        tour.loading = true;
                    },
                    success: function (data) {
                        tour.loading = false;
                        if (data.success) {
                            tour.selected = true;
                            tour.errorMessage = null;
                            tour.price = data.price;
                            tour.gstMarkupPrice = data.gstPrice + data.price;
                            if (tour.departurePoint && tour.departurePoint.length > 0) {
                                $.each(tour.departures, function (index, item) {
                                    if (tour.departurePoint === item.code) {
                                        tour.departurePointName = item.name;
                                        return false;
                                    }
                                });
                            }
                            self.selectedTours.push(tour);
                            self.getPriceSummary(self.packageQuery.id);
                            $(".avai-tour .fh-tabs__detail").collapse('hide');
                            self.backTop();
                        }
                        else {
                            Vue.set(self.tours, indexTours, tour);
                            // if (data.message != null) {
                            //     bootbox.alert(data.message);
                            // }
                            // else {
                                bootbox.alert(self.translateText('CANNOT_ADD_THIS_ACTIVITY', 'Unable to add this tour. Kindly try again or contact us.'));
                            // }
                        }
                    },
                    complete: function () {
                        tour.loading = false;
                    }
                });
                Vue.set(self.tours, indexTours, tour);
            },
            checkBookingTour: function (event, nextUrl) {
                let self = this;
                event.preventDefault();
                if (self.packageQuery.hasFlight && self.packageQuery.hasHotel) {
                    window.location.replace(nextUrl);
                }
                else if (self.selectedTours.length > 0) {
                    window.location.href = nextUrl;
                } else {
                    bootbox.dialog({
                        message: 'Please select any tour and then continue.',
                        buttons: {
                            close: {
                                label: "Close",
                                className: "btn-danger",
                                callback: function () {
                                }
                            }
                        }
                    });
                }

                return false;
            },
            getPriceSummary(packageQueryId) {
                var self = this;

                $.ajax({
                    type: "POST",
                    url: "/booking/get-price-summary",
                    data: {
                        packageId: packageQueryId,
                        promoCode: self.packageQuery.promoCode,
                        creditCardNumber: "",
                        applyInsurance: false,
                        addonDetails: []
                    },
                    success: function (data) {
                        self.priceSummary = data;
                        self.packageQuery.priceSummary = data;
                    }
                });
            },
            removeTour: function (tour, indexTours) {
                var self = this;
                Vue.set(self.tours, indexTours, tour);
                $.ajax('/package/remove-tour', {
                    type: "POST",
                    data: {
                        packageId: self.packageQuery.id,
                        tourId: tour.id
                    },
                    beforeSend: function () {
                        tour.loading = true;
                    },
                    success: function (response) {
                        var data = response;

                        if (data.success) {
                            tour.selected = false;

                            var index = self.selectedTours.indexOf(tour);
                            if (index > -1) {
                                self.selectedTours.splice(index, 1);
                            }

                            self.getPriceSummary(self.packageQuery.id);
                            // self.$refs.bookingSummary.updatePriceSummary();
                            // self.$refs.bookingSummary.packageQuery.tours = self.selectedTours;
                        }
                        else {
                            bootbox.alert(data.message);
                        }
                        tour.loading = false;
                    },
                    complete: function () {
                        tour.loading = false;
                    }
                });
            },
            getFormTourPerPage: function (currentPage, pageSize) {
                var result = 0;
                var self = this;
                if (currentPage === 1) {
                    result = currentPage;
                }
                else {
                    result = ((currentPage - 1) * pageSize) + 1
                }
                return result;
            },
            getFormTourPerTotal: function (currentPage, pageSize, totalResult) {
                var result = 0;
                if (currentPage === 1) {
                    result = pageSize * currentPage
                }
                else {
                    result = pageSize * (currentPage)
                    if (result > totalResult) {
                        result = totalResult
                    }
                    return result
                }

                return result;
            },
            getFullTourInfo: function (tour, index, isShowModal) {
                let vm = this;
                vm.tourInfor = tour;
                vm.tourIndexInfor = index;
                if (isShowModal) setTimeout(function () {
                    $("#modalTourDetail").modal('show').on('shown.bs.modal', function () {
                        vm.initializeSlickSlider();
                    }).on('hidden.bs.modal', function () {
                        vm.tourInfor = null;
                    });
                }, 100);
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            calcPromoPrice(callback) {
                var self = this;
                var cardNumber = $("#txtCreditCardNumber").val();
                var promoCode = $("#txtPromoCode").val();

                $.ajax({
                    type: "POST",
                    url: "/booking/get-price-summary",
                    data: {
                        packageId: this.packageQuery.id,
                        creditCardNumber: cardNumber,
                        promoCode: promoCode,
                        applyInsurance: this.isApplyInsurance,
                        addonDetails: null
                    },
                    success: function (data) {
                        self.packageQuery.priceSummary = data;
                        if (callback) {
                            callback(data);
                        }
                    }
                });
            },
            validate(el) {
                var valid = true;
                var tmpElements = el.currentTarget.elements;
                var elements = [];
                for (var i = 0; i < tmpElements.length; i++) {
                    var field = tmpElements[i];
                    if ((field.nodeName === "INPUT" || field.nodeName === "SELECT") && $(field).attr("data-val") === 'true') {
                        if (field.value === "" || field.value === null || field.value === undefined) {
                            $(field).addClass("input-validation-error");
                            elements.push(field);
                        } else {
                            $(field).removeClass("input-validation-error");
                        }
                    }
                }

                if (elements.length > 0) {
                    valid = false;
                    $(elements[0]).focus();
                }
                return valid;
            },
            sorting: function (sortOrderBy, sortOrderByAsc) {
                let self = this;
                self.tourFilter.sortOrderBy = sortOrderBy;
                self.tourFilter.sortOrderByAsc = sortOrderByAsc;
                self.getResultsPage(1, true);
            },
            setTourPriceRanges: function (minPrice, maxPrice) {
                let self = this;
                if (minPrice && maxPrice) {
                    self.selectedMinPrice = minPrice;
                    self.selectedMaxPrice = maxPrice;
                    
                    if(self.selectedMinPrice > self.minPrice || self.selectedMaxPrice < self.maxPrice) $("#price-remove").removeClass('hidden');
                } else {
                    self.selectedMinPrice = self.minPrice;
                    self.selectedMaxPrice = self.maxPrice;
                    $("#price-remove").addClass('hidden');
                }
                self.getResultsPage(1, true);
            },
            filterByCategory: function (category) {
                let self = this;
                if (category) {
                    if (category.selected) {
                        for (var i = 0; i < self.categoriesFilter.length; i++) {
                            if (category.key == self.categoriesFilter[i].key) {
                                self.categoriesFilter.splice(i, 1);
                                category.selected = false
                            }
                        }
                    }
                    else {
                        category.selected = true;
                        self.categoriesFilter.push(category);
                    }
                    if (self.categoriesFilter.length > 0) $('#activity-remove').removeClass('hidden');
                } else {
                    self.categoriesFilter.map(cat => cat.selected = false);
                    self.categoriesFilter = [];
                    $('#activity-remove').addClass('hidden');
                }
                self.getResultsPage(1, true);
            },
            checkSearchComplete: function (callback) {
                var self = this;
                if (callback) {
                    callback();
                }

                if (!self.hasErrorMessage) {
                    $.ajax("/package/get-tour-filters", {
                        data: {
                            packageId: self.packageQuery.id
                        },
                        type: "POST",
                        success: function (data) {
                            self.minPrice = self.selectedMinPrice = data.minPrice.toFixed(self.packageQuery.currencyDecimals);
                            self.maxPrice = self.selectedMaxPrice = data.maxPrice.toFixed(self.packageQuery.currencyDecimals);

                            for (var property in data.categories) {
                                if (data.categories.hasOwnProperty(property)) {
                                    self.categories.push({
                                        key: property,
                                        value: data.categories[property],
                                        selected: false
                                    });
                                }
                            }
                            self.categories.sort((a, b) => (a.value.description > b.value.description) - (a.value.description < b.value.description));
                            self.isSearchCompleted = true;
                        },
                        error: function () {
                            self.isSearchCompleted = true;
                        }
                    });
                } else {
                    self.isSearchCompleted = true;
                }

                self.hideSplashScreen();
            },
            hideSplashScreen() {
                $('#loading-page').addClass('hidden');
                $('#app').removeClass('modal-open');
            },
            changeImage: function (event, urlImage, tourId) {
                event.preventDefault();
                var elId = '#image-' + tourId;
                var el = $(elId);
                if (typeof el !== 'undefined' && el.length > 0) {
                    el.css("background-image", 'url(' + urlImage + ')');
                }
                return false;
            },
            callRemoveTour: function (tour) {
                var self = this;
                $.ajax({
                    type: "POST",
                    url: "/package/remove-tour",
                    data: {
                        packageId: self.packageQuery.id,
                        tourId: tour.id
                    },
                    success: function (data) {
                        if (data.success) {
                            tour.selected = false;
                            var indexRemove = -1;
                            if (self.selectedTours) {
                                $.each(self.selectedTours, function (index, item) {
                                    if (tour.id === item.id) {
                                        indexRemove = index;
                                        return false;
                                    }
                                });
                            }
                            if (indexRemove > -1) {
                                self.selectedTours.splice(indexRemove, 1);
                            }

                            for (var i = 0; i < self.tours.length; i++) {
                                if (tour.id === self.tours[i].id) {
                                    self.tours[i].selected = false;
                                    break;
                                }
                            }


                            self.getPriceSummary(self.packageQuery.id);
                            self.$refs.bookingSummary.updatePriceSummary();
                            self.$refs.bookingSummary.packageQuery.tours = self.selectedTours;

                        }
                        else {
                            bootbox.alert(data.message);
                        }
                    }
                });
            },
            callOpenTourInfor: function (tour) {
                var self = this;
                for (var i = 0; i < self.tours.length; i++) {
                    if (tour.id === self.tours[i].id) {
                        self.tourIndexInfor = i;
                        self.tourInfor = self.tours[i];
                        break;
                    }
                }
                $("#my-modal").modal({
                    backdrop: 'static',
                    show: true
                });
                return false;
            },
            openFilter: function () {
                $(".filter .filter-body").toggleClass('is-open');

                return false;
            },
            getPaxCount: function (tour) {
                return parseInt(tour.adults) + parseInt(tour.children);
            },
            removeDuplicateImages: function (tours) {
                var self = this;
                $(tours).each(function (i, tour) {
                    var tmpArrFileName = [];
                    var tmpArrImages = [];
                    if (tour.images && tour.images.length > 0) {
                        $(tour.images).each(function (k, image) {
                            if (image) {
                                var fileName = self.getFileName(image);
                                if (tmpArrFileName.indexOf(fileName, 0) == -1) {
                                    tmpArrFileName.push(fileName);
                                    tmpArrImages.push(image);
                                }
                            }
                        });
                        tour.images = tmpArrImages;
                    }
                });
            },
            getFileName: function (image) {
                var startIndex = (image.indexOf('\\') >= 0 ? image.lastIndexOf('\\') : image.lastIndexOf('/'));
                var filename = image.substring(startIndex);
                if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
                    filename = filename.substring(1);
                }
                return filename;
            },
            removeImagesBySize(tours) {
                var self = this;
                $(tours).each(function (i, tour) {
                    if (tour.images && tour.images.length > 0) {
                        $(tour.images).each(function (k, image) {
                            if (image) {
                                var img = new Image();
                                img.src = image;
                                self.getImageSize(img, function (width, height) {
                                    if (parseInt(width) < parseInt(self.minWidthSize) || parseInt(height) < parseInt(self.minHeightSize)) {
                                        var indexImage = tour.images.indexOf(image, 0);
                                        if (indexImage > -1) {
                                            tour.images.splice(indexImage, 1);
                                        }
                                    }
                                });
                            }
                        });
                    }
                });
            },
            getImageSize: function (img, callback) {
                var $img = $(img);
                var wait = setInterval(function () {
                    var w = $img[0].naturalWidth,
                        h = $img[0].naturalHeight;
                    if (w && h) {
                        clearInterval(wait);
                        callback.apply(this, [w, h]);
                    }
                }, 30);
            },
            setThumbnailForTour: function (tours) {
                var self = this;
                $(tours).each(function (i, tour) {
                    if (tour.images.length === 0) {
                        if (tour.thumbnail) {
                            tour.images.push(tour.thumbnail);
                        }
                    }
                });
            },
            formatDate: function(date, convertType) {
                if (!date) return moment.utc();
                else return moment.utc(String(date)).format(convertType);
            },
            formatCurrency: function(value) {
                let curDecimals = this.$store.state.workContext.packageQuery.currencyDecimals;
                let val = value ? value.toFixed(curDecimals ? curDecimals : 0) : value;
                return (val + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            }
        },
        updated() {
            this.initializeMagnificPopup();
        },
        watch: {
            cheapestTourPrice(val) {
                let self = this;
                if (val) {
                    var previousSearches = Cookie.getJSON('recentSearches') || [];
                    if (previousSearches.length > 0) previousSearches = previousSearches.filter(pre => {
                        return pre.fromCode !== self.packageQuery.from || pre.toCode !== self.packageQuery.to || pre.departureDate !== self.packageQuery.departureDate || pre.returnDate !== self.packageQuery.returnDate || pre.passengers !== self.calculatePaxCount
                    });
                    if (previousSearches.length > 3) {
                        previousSearches.splice(0, 1);
                    }
                    previousSearches.push({
                        id: self.packageQuery.productId,
                        from: self.packageQuery.fromCityName,
                        fromCode: self.packageQuery.from,
                        to: self.packageQuery.toCityName,
                        toCode: self.packageQuery.to,
                        thumbnail: self.cheapestTourThumbnail,
                        product: self.product.type,
                        departureDate: self.packageQuery.departureDate,
                        returnDate: self.packageQuery.returnDate,
                        passengers: self.calculatePaxCount,
                        price: self.cheapestTourPrice,
                        url: self.packageQuery.requestUrl,
                        currency: self.packageQuery.currency
                    });
                    Cookie.set('recentSearches', previousSearches, {expires: 1});
                    // console.log(Cookie.getJSON('recentSearches'));
                }
            },
            hasErrorMessage(value) {
                if (value)
                    $("#modalChangeDate").modal("hide")
            }
        }
    }

</script>
