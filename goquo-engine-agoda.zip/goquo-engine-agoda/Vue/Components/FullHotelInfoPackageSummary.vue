﻿<template>
    <div class="hi-package-summary" v-if="packageQuery && hotelInfo">
        <a href="#package-detail" class="hidden-hx scroll-to wrapper-link hi-price-section">
            <div v-lang.FROM></div>

            <div>
                <span class="hi-price mb20" v-if="!isSearchCompleted">
                    <span class="load-icon">
                        <span class="bounce1"></span>
                        <span class="bounce2"></span>
                        <span class="bounce3"></span>
                    </span>
                </span>
                <span class="hi-price" v-if="isSearchCompleted && hotelInfo.cheapestPrice > 0">
                    <small>{{packageQuery.currency}}</small>
                    {{ totalPackagePrice }}
                </span>
                <span class="hi-price" v-lang.SOLD_OUT v-if="isSearchCompleted && hotelInfo.cheapestPrice === 0" v-lang.SOLD_OUT></span>
            </div>

            <div>
                <span v-lang.FOR_X_PEOPLE></span>
                {{adultCount}}
                <span v-if="adultCount == 1" v-lang.ADULT></span>
                <span v-else v-lang.ADULTS></span>
                <span v-if="childCount > 0">
                    + {{childCount}}
                    <span v-if="childCount == 1" v-lang.CHILD></span>
                    <span v-else v-lang.CHILDREN></span>
                </span>
                <span v-if="infantCount > 0">
                    + {{infantCount}}
                    <span v-if="infantCount == 1" v-lang.INFANT></span>
                    <span v-else v-lang.INFANTS></span>
                </span>
            </div>

            <div>
                <span v-if="productCount == 2" v-lang.INCLUDES_FLIGHT_HOTEL_TAXES></span>
                <span v-else v-lang.INCLUDES_TAXES_FEES></span>
            </div>

            <div class="div-link" v-lang.CHOOSE_A_ROOM></div>
        </a>

        <a href="#trustYouReview" class="hi-review-bar clearfix scroll-to" v-if="hotelInfo.trustyou && hotelInfo.trustyou.score > 0">
            <div class="review hi-review-score" v-bind:class="'review_' + hotelInfo.trustyou.score_description" v-if="hotelInfo.trustyou.reviews">
                <span class="review-score">{{hotelInfo.trustyou.score_display.toFixed(1)}}</span>
                <span class="review-desc">{{hotelInfo.trustyou.score_description}}</span>
            </div>
            <div class="hi-review-count">
                <div class="hi-review-count-text">
                    <small v-lang.BASED_ON_X_REVIEWS="{0: hotelInfo.trustyou.reviews_count.toLocaleString()}"></small>
                </div>
                <div class="div-link" v-lang.READ_REVIEWS></div>
            </div>
        </a>

        <a v-if="hotelInfo.latitude && hotelInfo.longitude" href="#locationMap" class="view-map hidden-hx scroll-to">
            <span class="view-map_text"><i class="icon icon-search"></i> <em v-lang.VIEW_ON_MAP></em></span>
        </a>

        <!--Form new Search starts-->
        <div class="hi-form" v-if="packageQuery.id == '00000000-0000-0000-0000-000000000000'">
            <h4 v-lang.START_NEW_SEARCH></h4>
            <form method="GET" class="mb30" action='/package/start-search' id="fHotelSearch" data-val="true">
                <div class="row custom loadCal loadCal-hi">
                    <div class="col-xs-12 col-sm-6">
                        <div class="form-group">
                            <label class="form-label" v-lang.CHECK_IN></label>
                            <DatePicker name="DepartureDate" v-model="packageQuery.departureDate"></DatePicker>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6">
                        <div class="form-group">
                            <label class="form-label" v-lang.CHECK_OUT></label>
                            <DatePicker name="ReturnDate" v-model="packageQuery.returnDate"></DatePicker>
                        </div>
                    </div>
                    <div class="col-xs-12">
                        <label class="form-label" v-lang.SELECT_ROOMS></label>
                        <PaxSelector></PaxSelector>
                    </div>
                    <div class="col-xs-12">
                        <input type="hidden" name="ProductId" value="product.Id" />
                        <input type="hidden" name="From" value="packageQuery.from" />
                        <input type="hidden" name="To" value="packageQuery.to" />
                        <input type="hidden" name="HotelCode" value="hotelId" />
                        <button id="searchForm" type="submit" class="btn btn-primary mt0" v-lang.SEARCH_FOR_ROOMS></button>
                    </div>
                </div>
            </form>
        </div>
        <!--Form new Search ends-->

    </div>
</template>

<script>
    export default {
        components: {},
        data() {
            return {
                
            }
        },
        computed: {
            packageQuery() {
                return this.$store.state.workContext.packageQuery;
            },
            hotelInfo() {
                return this.$store.state.hotelInfo;
            },
            isSearchCompleted() {
                return this.$store.state.isSearchCompleted;
            },
            adultCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                }
                return count;
            },
            childCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.childCount;
                }
                return count;
            },
            infantCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.infantCount;
                }
                return count;
            },
            productCount() {
                return this.$store.state.workContext.product.products.length;
            },
            totalPackagePrice() {
                return this.$store.state.totalPackagePrice;
            }
        },
        methods: {
        }
    }
</script>