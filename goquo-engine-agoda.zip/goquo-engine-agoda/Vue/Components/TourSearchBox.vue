<template>
    <div>
        <form method="GET" action="/package/start-search" data-val="true" @submit="onValidate">
            <div class="search-grid">
                <AjaxSelect name="To" 
                            :placeholder="translateText('CHOOSE_A_CITY', 'Choose a city...')" 
                            :defaultValue="to" :defaultText="toCityName" 
                            type="tour" 
                            :txtLabel="translateText('WHERE_ARE_YOU_GOING', 'Where are you going?')" 
                            icon="ico icon-location-arrow"
                            :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_CITY', 'Please choose a valid city')"
                            @onValidate="onValidate"
                            :url="'/api/get-cities'" />
                <DateRangePicker v-model="defaultDate" journeyType="1" date-format="DD/MM/YYYY" isFlight="true" />
                <PaxSelector :maxRooms="3" :isTourOnly="true" />
            </div>
            <div class="search-button-wrap">
                <input type="hidden" name="OrderId" :value="packageQuery && packageQuery.orderId ? packageQuery.orderId : ''">
                <input type="hidden" name="Currency" :value="currency || defaultCurrency">
                <input type="hidden" name="ProductId" :value="product.id" />
                <button id="btnSumitSearchFormTour" type="submit" class="bt-search bt-effect">
                    <span class="text-uppercase" v-lang.SEARCH_TOUR></span>
                </button>
            </div>
        </form>
    </div>
</template>

<script>
    import AjaxSelect from './AjaxSelect.vue'
    import DateRangePicker from './DateRangePicker.vue'
    import PaxSelector from './PaxSelector.vue'

    export default {
        data() {
            return {
                DepartureDate: null,
                ReturnDate: null,
                maxRooms: 3,
                currency: "",
                defaultCurrency: "USD"
            }
        },
        computed: {
        },
        mounted() {
            let self = this;
            if (self.packageQuery) {
                self.currency = self.packageQuery.currency;  
            }
        },
        methods: {
            translateText(translateKey, defaultText, params) {
                return this.translate(this.$language, translateKey, params) || defaultText;
            },
            validateInput(context) {
                let parent = context.parents('.box-search');
                let label = parent.find(">strong");
                let labelVals = {
                    old: context.attr('data-label'),
                    new: context.attr('data-required-message')
                };

                if (!context.val()) {
                    parent.addClass('error');
                    label.text(labelVals.new);
                    return false;
                } else {
                    parent.removeClass('error');
                    label.text(labelVals.old);
                }
                return true;
            },
            onValidate(e) {
                let self = this;
                let box = $(self.$el)
                let errors = 0;
                box.find("input[name='To']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                if (errors == 0) {
                    return true;
                }
                if (e) e.preventDefault();
            }
        },
        props: ['product', 'defaultDate', 'to', 'toCityName', 'packageQuery'],
        components: {AjaxSelect, DateRangePicker, PaxSelector}
    }

</script>
