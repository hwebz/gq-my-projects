﻿<template>
    <div v-if="packageQuery">
        <SessionTimeout :packageId="packageQuery.id" :secondTimeout="packageQuery.ttl"></SessionTimeout>
        <div class="page-title-tabs">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div v-if="enabledFlights">
                            <h1 v-lang.FROM_X_TO_X="{0: packageQuery.fromCityName, 1: packageQuery.toCityName}"></h1>
                        </div>
                        <div v-else>
                            <h1 v-lang.HOTELS_IN="{0: packageQuery.toCityName}"></h1>
                        </div>
                        <div class="date-time-person">
                            <span>
                                <i class="icon-calendar"></i>
                                <p>{{ packageQuery.departureDate| formatDate("DD MMM") }} - {{ packageQuery.returnDate| formatDate("DD MMM") }}</p>
                            </span>
                            <span>
                                <i class="icon-user"></i>
                                <span>
                                    {{roomCount}} {{roomCount > 1 ? translateText('ROOMS', 'Rooms') : translateText('ROOMS', 'Room')}} - {{calculatePaxCount}} {{calculatePaxCount == 1 ? translateText('PASSENGER', 'Passenger') : translateText('PASSENGERS', 'Passengers')}}
                                </span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <FlightHotelSelector :packageQuery="packageQuery"
                             v-if="moveOnAble() && hotelStore.hotels.length > 0"
                             :hotelInfo="hotelInfo"
                             :isSearchCompleted="isSearchCompleted"
                             :hasErrorMessage="hasErrorMessage"
                             :loading="loading"
                             :priceSummary="priceSummary"
                             :enabledFlights="enabledFlights"
                             :hotelSelected="hotelInfo"
                             :product="product"
                             :flightStore="flightStore"
                             @onShowPriceSummaryPaneHotel="calculatePriceSummary"
                             @onBookingNow="onBookingNow"
                             allowChange="true"
                             :hotelStore="hotelStore" />
        <div class="fh-tabs__wrap" v-else>
            <div class="container">
                <div class="fh-tabs__overview">
                    <div class="fh-tabs__item fh-tabs__hotel">
                        <div class="picture">
                            <div class="lda">
                                <div class="lda__bar lda__bar--full"></div>
                            </div>
                        </div>
                        <div class="detail">
                            <div class="lda">
                                <div class="lda__bar"></div>
                                <div class="lda__bar lda__bar--50"></div>
                                <div class="lda__bar lda__bar--split"></div>
                                <div class="lda__bar lda__bar--split"></div>
                                <div class="lda__bar"></div>
                                <div class="lda__bar"></div>
                            </div>
                        </div>
                    </div>
                    <div class="fh-tabs__item fh-tabs__flight" v-if="enabledFlights">
                        <div class="title"><strong v-lang.FLIGHT></strong></div>
                        <div class="flight-way__tabs">
                            <div class="flight-way__view">
                                <div class="lda__wrap">
                                    <div class="lda">
                                        <div class="lda__bar"></div>
                                        <div class="lda__bar lda__bar--split lda__bar--50"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="flight-way__tabs">
                            <div class="flight-way__view">
                                <div class="lda__wrap">
                                    <div class="lda">
                                        <div class="lda__bar"></div>
                                        <div class="lda__bar lda__bar--split lda__bar--50"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="fh-tabs__item fh-tabs__control">
                        <div class="lda lda--fbot">
                            <div class="lda__bar lda__bar--50"></div>
                            <div class="lda__bar lda__bar--50"></div>
                            <div class="lda__bar lda__bar--50"></div>
                            <div class="lda__bar lda__bar--split"></div>
                            <div class="lda__bar lda__bar--two"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-wrap">
            <template v-if="moveOnAble() && hotelStore.hotels.length > 0">
                <div class="container" v-for="(hotel, hotelIndex) in hotelStore.hotels" :key="" :key="hotelIndex">
                    <div class="list-select" v-if="hotelInfo.imageInfos.length > 0">
                        <div class="list-title"><strong v-lang.GALLERY></strong></div>
                        <div class="tabs-gallery">
                            <div class="gallery__wrap">
                                <div class="gallery__image">
                                    <div class="gallery__image-show" :data-tour-images="getHotelImages(hotelInfo)" id="full-hotel-info-page-big-item" :style="'background-image:url('+ hotelInfo.imageInfos[0].url +')'">
                                        <span class="picture__mask">
                                            <i class="icon icon-search"></i>
                                        </span>
                                    </div>
                                    <div class="go-left go-control" data-index="0" data-control="prev" @click="changeGalleryImage($event, '#full-hotel-info-page-big-item', hotelInfo.imageInfos)">
                                        <i class="icon-left-chevron" style="pointer-events: none"></i>
                                    </div>
                                    <div class="go-right go-control" data-index="0" data-control="next" @click="changeGalleryImage($event, '#full-hotel-info-page-big-item', hotelInfo.imageInfos)">
                                        <i class="icon-right-chevron" style="pointer-events: none"></i>
                                    </div>
                                </div>
                                <div class="gallery__thumbs">
                                    <div class="gallery__thumbs-item">
                                        <a class="thumb-item" href="javascript:void(0);" :data-image-index="i" :class="{'active': i === 0 }" v-for="(img, i) in hotelInfo.imageInfos"
                                           :style="`background-image:url(${img.thumbnailUrl || img.url})`" :key="i" @click="changeGalleryImage($event, '#full-hotel-info-page-big-item', img)"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="list-select" v-for="(availableRoom, availableRoomIndex) in hotel.availableRooms" :key="availableRoomIndex">
                        <div class="list-title"><strong v-lang.ROOM_X_THE_PRICE_INCLUDES="{0: availableRoomIndex + 1}"></strong></div>
                        <div class="item-select-room" v-for="(availableRoomType, availableRoomTypeIndex) in availableRoom.availableRoomTypes.slice(0, maxRooms)" :key="availableRoomTypeIndex">
                            <div class="detail">
                                <span class="hidden-supplier-code">{{ availableRoomType.hotelId }}</span>
                                <strong>{{availableRoomType.name}}</strong>
                                <span>{{availableRoomType.boardCodeDescription}}</span>
                                <small v-for="specialOffer in availableRoomType.specialOffers"
                                       :aria-label="specialOffer.SpecialOfferDescription"
                                       v-if="specialOffer.specialOfferName">{{specialOffer.specialOfferName}}</small>
                                <div class="notify">
                                    <div class="freecan" v-if="availableRoomType.hasBreakfast">
                                        <span><i class="icon-check"></i><span v-lang.FREE_BREAKFAST></span></span>
                                    </div>
                                    <div class="cancellation-policy">
                                        <a href="#" data-target="#modalCancellationPrice" class="bt-link" data-toggle="modal" @click.prevent="getCancellationPrice($event, hotelInfo.hotelId, availableRoomType.id)">
                                            <i class="icon-information"></i>
                                            <span v-lang.VIEW_CANCELLATION_POLICY></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="price">
                                <div class="price-wrapper">
                                    <div class="real-price">
                                        <span class="price-included">
                                            <strong v-if="enabledFlights" v-lang.FLIGHT_HOTEL></strong>
                                            <strong v-else v-lang.HOTEL>Hotel</strong>
                                            <span v-if="product.displayPrice == 0" v-lang.PER_NIGHT></span>
                                            <span v-if="product.displayPrice == 1" v-lang.PER_PERSON></span>
                                            <span v-if="product.displayPrice == 2" v-lang.PER_ROOM></span>
                                        </span>
                                        <div class="price-per">
                                            <small>{{packageQuery.currency}}</small>
                                            <strong v-if="product.displayPrice == 1 || product.displayPrice == 0">{{calcPackagePriceValue(hotel, availableRoomType.totalPrice, true)}}</strong>
                                        </div>
                                    </div>
                                    <span class="total-price">
                                        <span v-if="enabledFlights" v-lang.TOTAL_PACKAGE_PRICE></span>
                                        <span v-if="calculateNights() > 1" v-lang.FOR_X_NIGHTS="{0: calculateNights()}"></span>
                                        <span v-else v-lang.FOR_X_NIGHT="{0: calculateNights()}"></span>
                                        <span>
                                            {{packageQuery.currency}} <strong>{{calcPackagePriceValue(hotel, availableRoomType.totalPrice, false)}}</strong>
                                        </span>
                                    </span>
                                </div>
                                <a class="link-small" href="#modalPriceBreakdown" data-toggle="modal" @click="calculatePriceSummary(availableRoomType.totalPrice, true)" v-lang.PRICE_BREAKDOWN></a>
                                <a class="btn btn-sm btn-block bt-effect" v-if="hotel.availableRooms.length > 1"
                                   :class="{'btn-primary': availableRoomType.selected, 'btn-outline-primary': !availableRoomType.selected}"
                                   href="javascript:void(0)"
                                   @click="changeHotelRoomType(hotel, availableRoomIndex, availableRoomTypeIndex, false)">
                                    <i v-if="availableRoomType.selected" class="icon-check"></i>
                                    {{availableRoomType.selected ? translateText('SELECTED', 'Selected') : translateText('SELECT', 'Select')}}
                                </a>
                                <a class="btn btn-sm btn-block bt-effect btn-primary" v-else
                                   href="javascript:void(0)"
                                   @click="changeHotelRoomType(hotel, availableRoomIndex, availableRoomTypeIndex, true)" v-lang.BOOK></a>
                            </div>
                        </div>
                        <div class="showmore-item" v-if="isSearchCompleted && availableRoom.availableRoomTypes.length > 7">
                            <a href="javascript:void(0)" @click="showMoreRooms(availableRoom.availableRoomTypes.length)">
                                <span v-if="showDefaultText" v-lang.SHOW_MORE_ROOM></span>
                                <span v-else v-lang.SHOW_LESS_ROOM></span>
                            </a>
                        </div>
                    </div>
                    <!--<div class="continue-button text-right" v-if="hotelStore.hotels[0].availableRooms && hotelStore.hotels[0].availableRooms.length > 1">-->
                    <!--<button class="btn btn-primary btn-effect bt-selected animated bt-effect-animated" @click="onBookingNow">Book</button>-->
                    <!--</div>-->
                    <div id="full-hotel-info"></div>
                    <div class="list-select" v-if="hotelInfo.trustyou">
                        <div class="list-title"><strong v-lang.REVIEWS></strong></div>
                        <div class="list-service">
                            <TrustYou :trustyou="hotelInfo.trustyou" />
                        </div>
                    </div>
                    <div class="list-select" v-if="hotelInfo.facilities.length > 0">
                        <div class="list-title"><strong v-lang.SERVICE></strong></div>
                        <div class="list-service">
                            <div class="block-service">
                                <div class="title"><strong v-lang.FACILITIES></strong></div>
                                <div class="detail">
                                    <ul>
                                        <li v-for="(facility, idx) in hotelInfo.facilities" :key="idx" v-if="facility.code">
                                            <!--<i :class="'icon icon-' + facility.code"></i>-->
                                            {{facility.description ? facility.description : facility.name}}
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="list-select" v-if="hotelInfo.description || (hotelInfo.latitude && hotelInfo.longitude)">
                        <div class="list-title"><strong v-lang.SUMMARY></strong></div>
                        <div class="list-service">
                            <div class="block-service" v-if="hotelInfo.description">
                                <div class="title"><strong v-lang.DESCRIPTION></strong></div>
                                <div class="detail" v-html="hotelInfo.description"></div>
                            </div>
                            <div class="block-service maps-area" v-if="hotelInfo.latitude && hotelInfo.longitude">
                                <div class="title"><strong v-lang.LOCATION></strong></div>
                                <div class="detail" id="full-hotel-info-map">
                                    <iframe id="mapBox" name="mapBox" frameborder="0" and style="border:0" :src="hrefMapBox" width="100%" height="100%"></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <a class="back-to-top" href="#" @click="backTop">
                    <i class="icon icon-up-chevron"></i>
                    <span v-lang.BACK_TO_TOP></span>
                </a>
            </template>
            <template v-else>
                <div class="container">
                    <div class="list-select">
                        <div class="list-title">
                            <div class="lda__bar lda__bar lda__bar--h42"></div>
                        </div>
                        <div class="item-select-room">
                            <div class="detail">
                                <div class="lda__bar lda__bar--50"></div>
                                <div class="lda__bar lda__bar--50"></div>
                                <div class="lda__bar lda__bar--50"></div>
                                <div class="lda__bar lda__bar--50"></div>
                            </div>
                            <div class="price">
                                <div class="price-wrapper">
                                    <div class="real-price">
                                        <span class="price-included">
                                            <div class="lda__bar"></div>
                                            <div class="lda__bar"></div>
                                        </span>
                                        <div class="lda__bar"></div>
                                    </div>
                                    <span class="total-price">
                                        <div class="lda__bar"></div>
                                        <div class="lda__bar"></div>
                                    </span>
                                </div>
                                <div class="lda__bar"></div>
                                <div class="lda__bar"></div>
                            </div>
                        </div>
                        <div class="showmore-item">
                            <div class="lda__bar lda__bar--h34"></div>
                        </div>
                    </div>
                    <div class="list-select">
                        <div class="list-title">
                            <div class="lda__bar lda__bar--h34"></div>
                        </div>
                        <div class="list-service">
                            <div class="block-service">
                                <div class="title">
                                    <div class="lda__bar lda__bar--50"></div>
                                </div>
                                <div class="detail">
                                    <ul>
                                        <div class="lda__bar lda__bar--50"></div>
                                        <div class="lda__bar lda__bar--50"></div>
                                        <div class="lda__bar lda__bar--50"></div>
                                        <div class="lda__bar lda__bar--50"></div>
                                        <div class="lda__bar lda__bar--50"></div>
                                        <div class="lda__bar lda__bar--50"></div>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </template>
        </div>
        <div class="modal fade" id="modalPriceBreakdown" tabindex="-1" role="dialog" aria-hidden="true" v-if="packageQuery && isSearchCompleted && !hasErrorMessage">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body modal-body-gray npd">
                        <div class="flight-detail-title">
                            <strong v-lang.PRICE_BREAKDOWN></strong>
                            <button class="modal-close" data-dismiss="modal">
                                <i class="icon-remove"></i>
                            </button>
                        </div>
                        <div class="price-summary-table">
                            <table class="responsive">
                                <thead>
                                    <tr>
                                        <th colspan="4">
                                            <span v-if="enabledFlights" v-lang.FLIGHT_HOTEL></span>
                                            <span v-else v-lang.HOTEL>Hotel</span> <span v-lang.PRICES></span>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th scope="col">{{enabledFlights && displayPrice == 1 ? translateText('PASSENGERS', 'Passengers') : translateText('NIGHTS', 'Nights')}}</th>
                                        <th scope="col">{{enabledFlights && displayPrice == 1 ? translateText('PRICE_PER_PAX', 'Price/pax') : translateText('PRICE_PER_NIGHT', 'Price/night')}}</th>
                                        <th scope="col">{{enabledFlights && displayPrice == 1 ? translateText('NO_OF_PASSENGERS', 'No. of Passengers') : translateText('NO_OF_NIGHTS', 'No. of Nights')}}</th>
                                        <th scope="col" v-lang.TOTAL_PRICE>Total price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td scope="row" :data-label="enabledFlights && displayPrice == 1 ? translateText('PASSENGERS', 'Passengers') : translateText('NIGHTS', 'Nights')">{{enabledFlights && displayPrice == 1 ? translateText('PER_PASSENGER', 'Per Passenger') : translateText('PER_NIGHT', 'Per night')}}</td>
                                        <td :data-label="enabledFlights && displayPrice == 1 ? translateText('PRICE_PER_PAX', 'Price/pax') : translateText('PRICE_PER_NIGHT', 'Price/night')">{{packageQuery.currency}} {{enabledFlights && displayPrice == 1 ? formatPrice(priceSummary.adultPrice) : formatPrice(priceSummary.nightPrice)}}</td>
                                        <td :data-label="enabledFlights && displayPrice == 1 ? translateText('NO_OF_PASSENGERS', 'No. of Passengers') : translateText('NO_OF_NIGHTS', 'No. of Nights')">{{enabledFlights && displayPrice == 1 ? calculatePaxCount : calculateNights()}}</td>
                                        <td :data-label="translateText('TOTAL_PRICE', 'Total Price')">{{packageQuery.currency}} {{enabledFlights && displayPrice == 1 ? formatPrice(priceSummary.adultPrice * calculatePaxCount) :  formatPrice(priceSummary.nightPrice * calculateNights())}}</td>
                                    </tr>
                                </tbody>
                            </table>
                            <table>
                                <thead>
                                    <tr>
                                        <th v-lang.TOTAL_PRICE_INCLUDES_TAXES_AND_FEES></th>
                                        <th>{{packageQuery.currency}} {{formatPrice(priceSummary.totalPrice)}}</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-primary bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="modalCancellationPrice" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body modal-body-gray npd">
                        <div class="flight-detail-title">
                            <strong v-lang.CANCELLATION_POLICY></strong>
                            <button class="modal-close" data-dismiss="modal">
                                <i class="icon-remove"></i>
                            </button>
                        </div>
                        <div class="price-summary-table">
                            <div v-if="isLoadingCancellation">
                                <div class="detail">
                                    <div class="lda__bar lda__bar--50"></div>
                                    <div class="lda__bar"><span v-lang.LOADING></span></div>
                                </div>
                            </div>
                            <div v-else>
                                <table v-if="cancellation">
                                    <tbody>
                                        <template v-for="(cancelBefore, index) in cancellation.roomCancelCharges">
                                            <tr>
                                                <template v-if="cancelBefore.dateFrom && cancelBefore.dateTo">
                                                    <span v-if="dateDiff(cancelBefore.dateFrom, cancelBefore.dateTo)">
                                                        <template v-if="cancelBefore.amount > 0">
                                                            <strong>{{packageQuery.currency}} {{cancelBefore.amount | formatCurrency}}</strong>
                                                            <span v-lang.WILL_BE_CHARGED_FOR_CANCELLATION_FROM></span>
                                                            {{cancelBefore.dateFrom | formatDate("DD MMM")}} - {{cancelBefore.dateTo | formatDate("DD MMM YYYY")}}
                                                        </template>
                                                        <template v-else>
                                                            <strong v-lang.FREE_CANCELLATION></strong>
                                                            <span v-lang.BEFORE_AND_ON="{0: formatDate(cancelBefore.dateTo,'DD MMM YYYY')}"></span>:
                                                        </template>
                                                    </span>
                                                    <span v-else>
                                                        <span v-lang.ON_X="{0: formatDate(cancelBefore.dateFrom ,'DD MMM YYYY')}"></span>
                                                        <template v-if="cancelBefore.amount > 0">
                                                            <span v-lang.CHARGE></span>
                                                            <strong>{{packageQuery.currency}} {{cancelBefore.amount | formatCurrency}}</strong>
                                                        </template>
                                                        <template v-else>
                                                            <strong v-lang.FREE_CANCELLATION></strong>
                                                        </template>
                                                    </span>
                                                </template>
                                            </tr>
                                            <tr>
                                                <template v-if="cancelBefore.amount === cancellation.totalPrice">
                                                    <span>
                                                        <strong v-lang.NONREFUNDABLE></strong><span v-lang.AFTER="{0: formatDate(cancelBefore.dateTo ,'DD MMM YYYY')}"></span>
                                                    </span>
                                                </template>
                                            </tr>
                                        </template>
                                    </tbody>
                                </table>
                                <div class="notify" v-else>
                                    <div class="freecan non-refund">
                                        <span><i class="icon-remove"></i><span v-lang.NONREFUNDABLE></span></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <div class="modal-footer">
                    <button class="btn btn-sm btn-primary bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Vue from 'vue'
    import _ from 'lodash'
    import { mapState } from 'vuex'
    import Availability from './Availability.vue';
    import FlightHotelSelector from './FlightHotelSelector.vue';
    import FlightAvailability from './FlightAvailability.vue'
    import PaxSelector from './PaxSelector.vue'
    import TrustYou from './TrustYou.vue'
    import AjaxSelect from './AjaxSelect.vue'
    import DateRangePicker from './DateRangePicker.vue'
    import SessionTimeout from './SessionTimeout.vue'
    import Cookie from 'js-cookie'
    
    export default {
        extends: Availability,
        components: {
            FlightHotelSelector,
            FlightAvailability,
            PaxSelector,
            TrustYou,
            AjaxSelect,
            DateRangePicker,
            SessionTimeout
        },
        data() {
            return {
                showDefaultText: true,
                displayAllRooms: false,
                defaultMaxRooms: 5,
                maxRooms: 5,
                hotelId: null,
                hotelInfo: null,
                trustyou: null,
                priceSummary: {
                    adultPrice: 0,
                    childPrice: 0,
                    nightPrice: 0,
                    totalPrice: 0
                },
                infowindow: new google.maps.InfoWindow(),
                cancellation: null,
                isLoadingCancellation: false, 
                selectedMarkers: [],
                currentMarker: null,
                hrefMapBox: null,
            }
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            baseUrl: state => state.workContext.baseUrl,
            productCount() {
                return this.product.products.length;
            },
            adultCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                }
                return count;
            },
            childCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.childCount;
                }
                return count;
            },
            infantCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.infantCount;
                }
                return count;
            },
            depatureDisableDateUrl() {
                return "/package/get-disabled-dates?from=" + this.packageQuery.from + "&to=" + this.packageQuery.to;
            },
            returnDisableDateUrl() {
                return "/package/get-disabled-dates?from=" + this.packageQuery.to + "&to=" + this.packageQuery.from;
            },
            isFloatingMobile() {

            },
            calculatePaxCount() {
                return this.adultCount + this.childCount + this.infantCount;
            }
        }),
        created() {
            function randomNumber(min, max) {
                return (Math.floor(Math.random() * (max - min + 1)) + min);
            }

            function timeOutMessage(index, timeOut) {
                setTimeout(function () {
                    closeMessage(index);
                }, timeOut);
            }

            var random = randomNumber(1, 2);
            var randomViewHotel = randomNumber(10, 20);
            var randomMinute = randomNumber(1, 60);
            var randomHours = randomNumber(1, 5);
            var exitpopupMessage1 = $('#message1');
            var exitpopupMessage2 = $('#message2');
            var intervalId = 0;
            var maxHeight = 100;
            var messageIndex = 1;
            var arrayMessage = [];
            var contentMessage = $("#message" + random + " .content");

            var message1 = `<div class="row"><div class='col-md-2'><img src='/images/no_ppl_book.png' /></div><div class='col-md-10'>${this.translateText('MOST_RECENT_BOOKING', 'Most recent booking for this hotel less than (0) minutes ago', { 0: randomMinute })}</div></div>`;
            var message2 = `<div class="row"><div class='col-md-2'><img src='/images/view_hotel.png' /></div><div class='col-md-10'>${this.translateText('OTHERS_VIEWING', '(0) others viewing this hotel right now.', { 0: randomViewHotel})}</div></div>`;
            var message3 = `<div class="row"><div class='col-md-2 '><img src='/images/book_hotel.png' /></div><div class='col-md-10'>${this.translateText('PEOPLE_BOOKED_THIS_HOTEL', '(0) people booked this hotel in the last (1) hours.', { 0: randomViewHotel - 2, 1: randomHours })}</div></div>`;

            if (random === 1) {
                contentMessage.html(message1);
            } else {
                contentMessage.html(message2);
            }

            function showPopup() {
                var randomMessage = randomNumber(1, 3);
                var statusNumber = false;
                if (arrayMessage.length < 3) {
                    do {
                        if (arrayMessage.indexOf(randomMessage) === -1) {
                            arrayMessage.push(randomMessage);
                            statusNumber = true;
                        } else {
                            randomMessage = randomNumber(1, 3);
                        }
                    }
                    while (!statusNumber);

                    var message = randomMessage === 1 ? message1 : (randomMessage === 2 ? message2 : message3);
                    if (messageIndex === 1) {
                        exitpopupMessage1.css('bottom', '55px');
                        exitpopupMessage2.css('bottom', '115px');
                        $('#message1 .content').html(message);
                        exitpopupMessage1.find('.btnClose >a').unbind().on('click', function (e) {
                            event.preventDefault();
                            closeMessage(1);
                            return false;
                        });
                        exitpopupMessage1.fadeIn();
                        timeOutMessage(1, 10000);
                    } else {
                        exitpopupMessage2.css('bottom', '115px');

                        $('#message2 .content').html(message);
                        exitpopupMessage2.find('.btnClose >a').unbind().on('click', function (e) {
                            event.preventDefault();
                            closeMessage(2);
                            return false;
                        })
                        exitpopupMessage2.fadeIn();
                        timeOutMessage(2, 10000);
                    }
                    if (messageIndex === 2) {
                        clearInterval(intervalId);
                    }
                    messageIndex++;
                }
            }
            function closeMessage(index) {
                //document.body.style.marginBottom = '95px';
                if (index === 1) {
                    exitpopupMessage1.fadeOut();
                    exitpopupMessage2.css('bottom', '115px');
                } else {
                    exitpopupMessage2.fadeOut();
                }
            }
            setTimeout(function () {
                showPopup()

                setTimeout(function () {
                    showPopup()
                }, 5000);
            }, 5000);
        },
        mounted() {
            let self = this;
            self.hideSplashScreen();
        },
        updated() {
            this.initializeMagnificPopup();
        },
        methods: {
            getCancellationPrice(e, hotelId, roomTypeId) {
                if (!(hotelId && roomTypeId)) return;
                let self = this;
                self.isLoadingCancellation = true;
                let $element = $(e.target);
                let target = $($element.attr('href'));
                let parent = $element.parents(".detail");   

                var savedContent = Cookie.getJSON('roomCancellationCharges-' + roomTypeId) || null;
                if (!savedContent) {                    
                    parent.addClass('loading'); 
                    $.post('/package/get-hotel-room-cancellations', {
                        PackageId: self.packageQuery.id,
                        HotelId: hotelId,
                        RoomTypeId: roomTypeId,
                    }).done(function (data) {
                        if (data && data.status) {
                            _.forEach(data.hotelAvailable.availableRooms, function (room) {
                                _.forEach(room.availableRoomTypes, function (roomType) {
                                    if (roomType.id == roomTypeId) {
                                        self.cancellation = roomType.roomCancelCharges != undefined && roomType.roomCancelCharges && roomType.roomCancelCharges.length > 0 ? roomType : null;
                                        if (self.cancellation) Cookie.set('roomCancellationCharges-' + roomTypeId, self.cancellation, { expires: 1 });
                                        target.modal('show');
                                        parent.removeClass('loading');
                                        self.isLoadingCancellation = false;
                                        return;
                                    }
                                });
                            });
                        } else { 
                            self.cancellation = null;
                            parent.removeClass('loading');
                            self.isLoadingCancellation = false;
                        }
                    }).fail(function () {
                        self.cancellation = null;
                    }).always(function () {
                        target.modal('show');
                        parent.removeClass('loading');
                        self.isLoadingCancellation = false;
                    });
                } else {
                    self.cancellation = savedContent;
                    target.modal('show');
                    self.isLoadingCancellation = false;
                } 
            },
            backTop() {
                $('html,body').animate({
                    scrollTop: 0
                }, 'slow');
            },
            initHotelInfoMap() {
                let self = this;
                var hotel = self.hotelInfo;
                var myLatLng = {
                    lat: parseFloat(hotel.latitude),
                    lng: parseFloat(hotel.longitude)
                };
                var map = new google.maps.Map(document.getElementById('full-hotel-info-map'), {
                    center: myLatLng,
                    zoom: 18
                });
                // Create a marker and set its position.
                var marker = new google.maps.Marker({
                    map: map,
                    position: myLatLng,
                    title: hotel.name,
                    hotel: hotel,
                    labelClass: 'gm-label current'
                });

                var infoWindowHTML = `<div class="infowindow__wrap">
                                        <div class="infowindow__img" style="background-image:url(${hotel.imageInfos.length > 0 ? hotel.imageInfos[0].url : self.baseUrl + '/images/images-default.jpg'});"></div>
                                        <div class="infowindow__detail">
                                            <h5 class="infowindow__title">${hotel.name}</h5>
                                            <div class="infowindow__star">
                                                ${Array(parseInt(hotel.stars)).join(0).split(0).map((item, i) => `
                                                    <span class="icon-star"></span>
                                                `).join('')}
                                            </div>
                                            <span><i class="ico icon-location-arrow"></i> ${hotel.addressLines}</span><br/>
                                            <span><i class="ico icon-currency"></i> ${this.packageQuery.currency} <strong style='font-size: 20px; color: #003b99;'>${this.totalPackagePrice(hotel)}</strong></span>
                                            ${typeof hotel.trustyou !== 'undefined' ? `
                                                <div class="infowindow__score">
                                                    <div class="reviews-score reviews-score__${hotel.trustyou.score_description.toLowerCase().replace(/ +/g, '-')}">${hotel.trustyou.score_display}</div>
                                                    <div class="text">
                                                        <span>${hotel.trustyou.score_description}</span>
                                                        <small>${hotel.trustyou.reviews_count} ${parseInt(hotel.trustyou.reviews_count) > 1 ? `reviews` : 'review'}</small>
                                                     </div>
                                                </div>
                                            ` : ``}
                                        </div>
                                     </div>`;

                setTimeout(function () {
                    self.infowindow.setContent(infoWindowHTML);
                    self.infowindow.open(map, marker);
                    self.currentMarker = marker;
                }, 500);

                google.maps.event.addListener(marker, 'click', function () {
                    //marker.showContent();
                    self.currentMarker = marker;
                    //don't add selected effect and dont add currentMarker to selectedMarkers
                    //arraysfor current hotel'
                    self.currentMarker.set("labelClass", "gm-label selected");
                    self.selectedMarkers.push(marker);

                    //if selectedMarkers has more than 1 element, remove .selected class from previous element,
                    //then remove selectedMarkers[0] from the array
                    if (self.selectedMarkers.length > 1) {
                        var selected = self.selectedMarkers[0];
                        selected.set("labelClass", "gm-label");
                        self.selectedMarkers.splice(0, 1);
                    }

                    if (self.selectedMarkers.length > 0) {
                        setTimeout(function () {
                            self.infowindow.setContent(infoWindowHTML);
                            self.infowindow.open(map, marker);
                            self.currentMarker = marker;
                        }, 500);
                    }
                });

                google.maps.event.addListener(marker, "mouseover", function () {
                    if (marker.labelClass.indexOf('current') == -1 && marker.labelClass.indexOf('selected') == -1) {
                        marker.set("labelClass", "gm-label hovered");
                    }
                });

                google.maps.event.addListener(marker, "mouseout", function (e) {
                    $(".gm-label").removeClass('hovered');
                });

                // closes the pop up window when click on the map
                google.maps.event.addListener(map, 'click', function () {
                    self.infowindow.close();
                    $('.gm-label').removeClass('selected');
                });

                //on pop up window close, remove selected class
                google.maps.event.addListener(self.infowindow, 'closeclick', function () {
                    if (self.currentMarker.labelClass.indexOf('current') == -1) {
                        self.currentMarker.set("labelClass", "gm-label");
                    }
                    self.selectedMarkers.pop();
                });
            },
            getHotelImages(hotel) {
                let imgs = hotel.imageInfos;
                let imgStrings = '';

                if (hotel && imgs.length > 0) {
                    imgs.map(img => {
                        imgStrings += (img.url.replace("_b.", "_z.") + '|');
                    });
                }
                return (imgs.length > 0) ? imgStrings.substr(0, imgStrings.length - 1) : self.baseUrl + '/images/tour-default.png';
            },
            initializeMagnificPopup() {
                let pics = $("#full-hotel-info-page-big-item");
                if (typeof pics !== 'undefined' && pics.length > 0) {
                    pics.each(function(index, item) {
                        let $element = $(item);
                        let imgs = $element.attr('data-tour-images').split('|');
                        let imgsObj = [];

                        if (imgs.length > 0) {
                            imgs.map(img => {
                                if (img != '') imgsObj.push({
                                    src: img
                                }) ;
                            });

                            if ($.fn.magnificPopup) $element.magnificPopup({
                                items: imgsObj,
                                mainClass: 'mfp-with-zoom',
                                gallery: {
                                    enabled: true
                                },
                                type: 'image'
                            });
                        }
                    });
                }
            },
            changeGalleryImage(event, element, source) {
                event.preventDefault();
                var ele = $(element);
                var self = $(event.target);

                if (typeof ele !== "undefined" && ele.length > 0 && typeof source === 'object') {
                    if (!Array.isArray(source)) {
                        ele.css({
                            backgroundImage: 'url(' + source.url + ')'
                        });

                        self.parent().find('.thumb-item').removeClass('active');
                        self.addClass('active');
                        ele.parent().find('.go-control').attr('data-index', self.attr('data-image-index'));
                    } else {
                        var imageIndex = self.attr('data-index') || null;
                        var imageControl = self.attr('data-control') || null;

                        if (imageIndex !== null && imageControl !== null) {

                            switch (imageControl) {
                                case 'next':
                                    self.parent().find('.go-control').attr('data-index', parseInt(imageIndex, 10) < (
                                        source.length - 1) ? parseInt(imageIndex, 10) + 1 : 0);
                                    break;
                                case 'prev':
                                    self.parent().find('.go-control').attr('data-index', parseInt(imageIndex, 10) > 0 ?
                                        parseInt(imageIndex, 10) - 1 : (source.length - 1));
                                    break;
                            }

                            ele.css({
                                backgroundImage: 'url(' + source[parseInt(self.attr('data-index'), 10)].url +
                                    ')'
                            });

                            var thumbItems = self.parents('.gallery__wrap').find('.thumb-item');
                            thumbItems.removeClass('active');
                            $(thumbItems.get(parseInt(self.attr('data-index')))).addClass('active');
                        }
                    }
                }

                return false;
            },
            hideSplashScreen() {
                _.debounce(function () {
                    $('#loading-page').addClass('hidden');
                    $('#app').removeClass('modal-open');
                }, 500)();
            },
            isHotelCancellation(availableRoomType) {
                let isCancellation = 'non';
                if (!availableRoomType) return isCancellation;
                if (availableRoomType.cancelFreeBeforeDate) return 'free';
                let cancelCharges = availableRoomType.roomCancelCharges != undefined && availableRoomType.roomCancelCharges ? availableRoomType.roomCancelCharges : [];
                for (let i = 0; i < cancelCharges.length; i++) {
                    if (cancelCharges[i].amount > 0) {
                        isCancellation = 'apart';
                    }
                }
                return isCancellation;
            },
            loadHotelInfo(hotel) {
                let self = this;
                //if (self.hotelInfo) setTimeout(function() {
                //   self.initHotelInfoMap();
                //}, 1000);
                let hotelName = (hotel.originName && hotel.originName !== null) ? hotel.originName : hotel.name ; 
                let parramSearching = encodeURIComponent(hotelName + "," + hotel.addressLines);
                self.hrefMapBox = 'https://www.google.com/maps/embed/v1/place?key=AIzaSyCYNW1bQUyS-QQYLXoE_ULFFfzF6ZdTDUQ&q=' + parramSearching ;

                if (hotel.description) {
                   return;
                }

                $.post('/package/get-hotel-info', {
                    packageId: this.packageQuery.id,
                    cityCode: this.packageQuery.to,
                    hotelId: hotel.hotelId
                }, function (data) {
                    Vue.set(hotel, 'description', data.description);
                    Vue.set(hotel, 'facilities', data.facilities);
                });
            },
            dateDiff(fromDate, toDate) {
                var fDate = Vue.moment(fromDate.split('T')[0]);
                var tDate = Vue.moment(toDate.split('T')[0]);
                
                if (tDate.diff(fDate) > 0) return true;
                return false;
            },
            calculatePriceSummary(roomPrice, isPerPax = false) {
                if (roomPrice) {
                    let paxInfo = isPerPax ? this.packageQuery.paxInfos.length : 1;
                    this.priceSummary = {
                        adultPrice: ((roomPrice + (this.totalFlightPrice()/paxInfo)) / this.calculatePaxCount),
                        nightPrice: ((roomPrice + (this.totalFlightPrice()/paxInfo)) / this.calculateNights()),
                        totalPrice: roomPrice + (this.totalFlightPrice() / paxInfo)
                    };
                }
            },
            getStaticHotels(newPage, isUpdated = true, callback) {
                this.getHotels(callback);
            },
            bookingNow(hotel) {
                var data = {};
                data.packageId = this.packageQuery.id;
                
                if (this.flightStore.outboundFlight != null) {
                    data.outboundFlightId = this.flightStore.outboundFlight.id;
                }

                if (this.flightStore.inboundFlight != null) {
                    data.inboundFlightId = this.flightStore.inboundFlight.id;
                }

                if (hotel) {
                    data.hotelId = hotel.hotelId;
                    var roomTypeIds = [];

                    for (var i = 0; i < hotel.availableRooms.length; i++) {
                        for (var j = 0; j < hotel.availableRooms[i].availableRoomTypes.length; j++) {
                            var availableRoomType = hotel.availableRooms[i].availableRoomTypes[j];
                            if (availableRoomType.selected) {
                                roomTypeIds.push(availableRoomType.id);
                            }
                        }
                    }
                    data.roomTypeIds = roomTypeIds;
                }

                var self = this;
                $.ajax('/package/do-booking-agoda', {
                    traditional: true,
                    data: data,
                    type: "POST",
                    success: function (data) {
                        if (data.success) {
                            window.location = data.redirectUrl;
                        }

                        if (data.message) {
                            // if (self.enabledFlights) {
                            //     alert("oops! we are sorry, the fare you selected is no longer available, please select a different flight option.");
                            // } else {
                            //     alert("oops! we are sorry, there was a problem when we're trying to book your selected hotel.");
                            // }
                            alert(data.message)
                            
                            self.splashScreen(false);
                        }
                    },
                    error: function () {
                        self.splashScreen(false);
                    }
                });
            },
            getHotels(callback) {
                var self = this;
                self.hotelId = [this.$route.params.hotelId];

                $.ajax({
                    url: '/package/get-hotel-availables',
                    data: {
                        packageId: this.packageQuery.id,
                        hotelIds: self.hotelId
                    },
                    traditional: true,
                    type: 'POST',
                    success: function (data) {
                        for (var i = 0; i < data.hotels.length; i++) {
                            var hotel = data.hotels[i];
                            if (hotel.availableRooms) {
                                for (var j = 0; j < hotel.availableRooms.length; j++) {
                                    var availableRoom = hotel.availableRooms[j];
                                    for (var k = 0; k < availableRoom.availableRoomTypes.length; k++) {
                                        var availableRoomType = availableRoom.availableRoomTypes[k];
                                        availableRoomType.selected = k === 0;
                                    }
                                }
                            }                            
                        }

                        self.hotelStore.hotels = data.hotels;
                        if (data.hotels.length > 0) {
                            self.prepareHotel(data.hotels[0]);
                            self.hotelInfo = data.hotels[0];
                            window.selectedHotel = data.hotels[0];
                            self.getTrustyouData(self.hotelStore.hotels);
                            self.$store.commit('setHotelInfo', data.hotels[0]);
                            self.$store.commit('setTotalPackagePrice', self.totalPackagePrice(data.hotels[0]));

                            self.calculatePriceSummary(self.hotelInfo.cheapestPrice);

                            self.loadHotelInfo(self.hotelInfo);
                        }
                        if (callback) {
                            callback();
                        }
                    }
                });
            },
            forceRenderHotels() {
                for (var i = 0; i < this.hotelStore.hotels.length; i++) {
                    var hotel = this.hotelStore.hotels[i];
                    Vue.set(this.hotelStore.hotels, i, hotel);
                    this.$store.commit('setTotalPackagePrice', this.totalPackagePrice(hotel));
                }
            },
            getFlights() {
                var self = this;
                self.errorMessage = "";
                self.loading.flightPagination = true;

                $.ajax({
                    url: "/package/get-flight-solution",
                    data: { packageId: self.packageQuery.id, outboundFlightId: self.$route.query.outboundFlightId, inboundFlightId: self.$route.query.inboundFlightId  },
                    type: "POST",
                    success: function (data) {
                        self.flightStore.outboundFlights = [data.outbound];
                        self.flightStore.outboundFlight = data.outbound;
                        
                        self.flightStore.inboundFlights = [data.inbound];
                        self.flightStore.inboundFlight = data.inbound;

                        self.loading.flightDetails = true;
                        self.flightLoadCompleted = true;
                        self.flightErrorMessage = null;
                        self.loading.flightPagination = false;
                    }
                });
            },
            onTrustYouComplete(reviewData) {
                var self = this;
                if (reviewData && reviewData.length && reviewData.length > 0 && reviewData[0]) {
                    self.trustyou = reviewData[0].data;

                    // create a array for category
                    var category = ["all", "business", "couples", "families", "solo"];
                    var categoryData = [];
                    for (var i = 0; i < category.length; i++) {
                        var categoryList = self.trustyou.reviews[category[i]];

                        if (categoryList) {
                            categoryData.push(categoryList);
                            categoryList['category_name'] = category[i];
                        }
                    }
                    self.trustyou['category_items'] = categoryData;
                }
            },
            getRegions() { },
            showMoreRooms(totalRoomsAvailable) {
                if (!this.displayAllRooms) {
                    this.maxRooms = totalRoomsAvailable;
                    this.displayAllRooms = true;
                    this.showDefaultText = false;
                }
                else {
                    this.maxRooms = this.defaultMaxRooms;
                    this.displayAllRooms = false;
                    this.showDefaultText = true;
                }
            },
            changeHotelRoomType(hotel, roomIndex, roomTypeIndex, isBookNow) {
                var availableRoom = this.hotelInfo.availableRooms[roomIndex];
                for (var j = 0; j < availableRoom.availableRoomTypes.length; j++) {
                    if (roomTypeIndex === j) {
                        availableRoom.availableRoomTypes[j].selected = true;
                    } else {
                        availableRoom.availableRoomTypes[j].selected = false;
                    }
                }
                this.$store.commit('setTotalPackagePrice', this.totalPackagePrice(hotel));
                
                if (isBookNow) this.onBookingNow(); 
            },
            replaceImage(path) {
                if (path.indexOf('static.goquo.com') > -1) {
                    var imagePath = path.split("/");
                    var replacedPath = path.replace(imagePath[3], imagePath[3] + '-w300');
                    return replacedPath;
                } else {
                    return path;
                }
            },
            moveOnAble() {
                var fS = this.flightStore;
                var hS = this.hotelStore;
                if (this.enabledFlights && ((fS.inboundFlights == null || fS.inboundFlights.length === 0) && (fS.outboundFlights == null || fS.outboundFlights.length === 0))) return false;

                if (this.enabledHotels) {
                    if ((hS.hotels == null || hS.hotels.length === 0)) return false;
                    if (hS.hotels.length === 1) {
                        if (this.hotelInfo.cheapestPrice === 0) {
                            return false;
                        }
                    }
                }

                return true;
            },
            ceilingPrice(floatNum) {
                return Math.ceil(parseFloat(floatNum));
            },
            getSelectedAvailableRoomType(hotel, index) {
                for (var j = 0; j < hotel.availableRooms[index].availableRoomTypes.length; j++) {
                    var availableRoomType = hotel.availableRooms[index].availableRoomTypes[j];
                    if (availableRoomType.selected) {
                        return availableRoomType;
                    }
                }
                return null;
            },
            calcPackagePriceValue(hotel, roomPrice, isPerPax) {
                if (hotel.cheapestPrice === 0) {
                    return 0;
                }

                if (this.enabledFlights && !this.flightStore.outboundFlight) {
                    return 0;
                }

                if (!hotel.availableRooms) {
                    return 0;
                }

                var price = roomPrice;
                if (this.enabledFlights) {
                    price += (this.totalFlightPrice() / this.packageQuery.paxInfos.length);
                }
                
                if (isPerPax) {
                    if (this.product.displayPrice == 1) {
                        price = price / this.calculatePaxCount;
                    } else if (this.product.displayPrice == 0) {
                        price = price / this.calculateNights();
                    } 
                } 

                return price.toFixed(this.packageQuery.currencyDecimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            totalFlightPrice() {
                var price = 0;
                if (this.flightStore.outboundFlight)
                    price += this.flightStore.outboundFlight.solutionPrice;
                
                return price;
            },
            onFlightChanged(flight) {
                if (flight.direction === 0) {
                    this.flightStore.outboundFlight = flight;
                }
                else {
                    this.flightStore.inboundFlight = flight;
                }

                if (this.hotelInfo) {
                    this.$store.commit('setTotalPackagePrice', this.totalPackagePrice(this.hotelInfo));
                }
            },
            onBookingNow() {
                var self = this;
                
                this.splashScreen(true);
                
                setTimeout(function () {
                    self.bookingNow(self.hotelInfo);
                }, 1000);
                
            },
            splashScreen(isShow) {
                if (isShow) {
                    $('#loading-page-2').removeClass('hidden');

                    setTimeout(function () {
                        $('#app').addClass('modal-open');
                    }, 300);
                } else {
                    $('#app').removeClass('modal-open');

                    setTimeout(function () {
                        $('#loading-page-2').addClass('hidden');
                    }, 300);
                }
            },
            translateText(translateKey, defaultText, params) {
                return this.translate(this.$language, translateKey, params) || defaultText;
            },
            formatDate(date, format) {
                return moment.utc(date).format(format); 
            }
        }
    }
</script>
