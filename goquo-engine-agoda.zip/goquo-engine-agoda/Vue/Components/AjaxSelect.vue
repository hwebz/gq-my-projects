<template>
    <div class="box-search" :class="{'type-2': type == 'hotel' || type == 'tour'}">
        <strong>{{journeyType === 'ToAirport' ? txtToAirportLabel : txtLabel}}</strong>
        <div class="search-input dropdown">
            <i :class="icon"></i>
            <div class="ipt-show dropdown-toggle" :class="{'non-selectable': isToAirportTransfer}">
                <input class="ipt-search" type="text" :readonly="isToAirportTransfer"
                       :placeholder="placeholder"
                       @focus="selectAllText"
                       @keydown="onKey" />
            </div>
            <div class="flight-result-wrap dropdown-menu">
                <div class="flight-result-ddr" :class="{'severals': accepted}" v-if="results.length > 0 && isSearchCompleted">
                    <!--<div class="flight-result-ddr__item found any" v-if="accepted && !isToAirportTransfer"-->
                         <!--@click="onSelectLocation(results[0].code, results[0].name, results[0])">-->
                        <!--<i class="icon icon-confirm"></i>-->
                        <!--<div class="name-city">-->
                            <!--<p class="result-name" :data-latitude="results[0].latitude" :data-longitude="results[0].longitude">-->
                                <!--<b>{{searchTerm}} </b>-->
                                <!--(Any)-->
                                <!--<span class="country-name">{{results[0].cityName}}, {{results[0].countryName}}</span>-->
                            <!--</p>-->
                            <!--&lt;!&ndash;<b class="result-countrycode">{{results[0].code}}</b>&ndash;&gt;-->
                        <!--</div>-->
                    <!--</div>-->
                    <div class="flight-result-ddr__item found" v-for="(item, index) in results"
                         :key="index" @click="onSelectLocation(((type === 'hotel' || name === 'TransferSearchInfo.RegionId') ? item.cityCode : item.code), item.name, item)">
                        <i class="icon icon-location-arrow"></i>
                        <div class="name-city">
                            <p class="result-name" :data-latitude="item.latitude" :data-longitude="item.longitude"><span v-html="detectKeywords(item.name, searchTerm)"></span><span class="country-name" v-show="item.cityName && item.countryName">{{item.cityName}}, {{item.countryName}}</span></p>
                            <!--<b class="result-code">{{type == 'hotel' ? item.cityCode : item.code}}</b>-->
                        </div>
                    </div>
                </div>
                <div class="flight-result-ddr" v-if="results.length === 0 && isSearchCompleted && !isFirstLoad">
                    <div class="flight-result-ddr__item not-found">
                        <i class="icon icon-location-arrow"></i>
                        <div class="name-city">
                            <p class="result-name" v-lang.NO_MATCHING_RESULT_FOUND></p>
                        </div>
                    </div>
                </div>
                <div class="load load__bar" :class="{'load__bar--active': !isSearchCompleted}">
                    <div class="line"></div>
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
                <input type="hidden" :name="name" :value="defaultValue" :data-required-message="dataRequiredMessage" :data-label="txtLabel" />
                <input type="hidden" v-if="type === 'Transfer'" name="TransferSearchInfo.AccommodationGeoCoords" :value="defaultLocation" />
            </div>
        </div>
    </div>
</template>
<script>
    import _ from 'lodash';
    import axios from 'axios';

    export default {
        props: ['url', 'name', 'placeholder', 'defaultValue', 'defaultText', 'txtLabel', 'icon', 'closeOnClickPopup',
            'type', 'dataRequiredMessage', 'typeRegions', 'to', 'txtToAirportLabel', 'journeyType', 'cityCode', 'defaultLocation', 'tempTransferType', 'accepted'
        ],
        data() {
            return {
                results: [],
                isSearchCompleted: true,
                isFirstLoad: true,
                selected: -1,
                firstDefaultValue: true,
                hiddenRegionId: null,
                hiddenHotelId: null,
                searchTerm: null,
            }
        },
        computed: {
            isToAirportTransfer() {
                return (this.journeyType === 'ToAirport' && this.name === 'To')
            }
        },
        mounted: function () {
            let vm = this;
            let $element = $(vm.$el);
            let ua = navigator.userAgent.toLowerCase();
            let isAndroid = ua.indexOf("android") > -1;

            if (vm.type == "hotel") {
                vm.hiddenRegionId = $('<input type="hidden" name="RegionId" />');
                vm.hiddenHotelId = $('<input type="hidden" name="HotelCode" />');

                vm.hiddenRegionId.val(vm.regionId);
                vm.hiddenHotelId.val(vm.hotelCode);

                // Append some hidden fields
                $element.after(vm.hiddenHotelId);
                $element.after(vm.hiddenRegionId);
            }


            $element.find('.ipt-search').on('keyup keypress', _.debounce(function (e) {
                var $this = $(this);
                if (_.indexOf([37, 38, 39, 40, 13], e.keyCode) < 0 && !(e.keyCode === 9 && e.shiftKey)) {
                    $element.find("input[name='" + vm.name + "']").val('');
                    vm.isSearchCompleted = false;
                    var params = {
                        term: ''
                    };

                    if (vm.name === "TransferSearchInfo.RegionId") {
                        params.type = vm.typeRegions;
                        if (vm.journeyType !== 'ToAirport') {
                            params.airport = vm.to;
                        }
                        vm.$emit('onCityChanged', '');
                    }

                    vm.$emit('onLocationChanged', '');

                    let searchTerm = $this.val().toLowerCase();
                    params.term = vm.searchTerm = searchTerm.replace(/\b[a-z]/g, (letter) => letter.toUpperCase());

                    axios.get(vm.url, {
                        params: params
                    }).then(function (response) {
                        if (response.status === 200) {
                            vm.results = response.data;
                            vm.selected = -1;
                        }
                        vm.isFirstLoad = false;
                        vm.isSearchCompleted = true;
                    }).catch(function (error) {
                        console.log(error);
                        vm.isSearchCompleted = true;
                    });
                }
            }, 500)).on('focus', function () {
                let $this = $(this);
                //$this.val('');
                //$element.find("input[name='" + vm.name + "']").val('');

                if (vm.isToAirportTransfer) {
                    const formData = new FormData();
                    formData.set('cityCode', vm.cityCode);
                    formData.append('cultureCode', vm.$store.state.workContext.siteInfo.cultureCode);

                    axios.post(vm.url, formData).then(function (response) {
                        if (response.status === 200) {
                            vm.results = response.data;
                            vm.selected = -1;
                        }
                        vm.isFirstLoad = false;
                        vm.isSearchCompleted = true;
                    }).catch(function (error) {
                        console.log(error);
                        vm.isSearchCompleted = true;
                    });
                }
            }).delay(500).val(vm.defaultText);

            var button = $('.dropdown-toggle, .dropdown-toggle >input', $element);
            var dropdown = button.next(".dropdown-menu");
            var container = button.parent();

            button.on('click focus', function (event) {
                dropdown.show();
            }).on('blur', function () {
                setTimeout(function () {
                    dropdown.hide();
                }, 200);
            });

            $(document).click(function (event) {
                if (!button.has(event.target).length) {
                    setTimeout(function () {
                        dropdown.hide();
                    }, 200);
                }
            });
        },
        updated() {
            let vm = this;
            let $element = $(vm.$el);
            if ($element.find('.ipt-search').val() === "" && vm.firstDefaultValue && vm.defaultText) {
                $element.find('.ipt-search').val(vm.defaultText);
                vm.firstDefaultValue = false;
            }
        },
        methods: {
            detectKeywords(name, searchTerm) {
                let regex = new RegExp(searchTerm, 'ig');
                let replaced = name.replace(regex, function (match) {
                    return "<b>" + match + "</b>";
                });
                return replaced;
            },
            selectAllText(e) {
                $(e.target).select();
            },
            onKey: function (event) {
                self = this;
                var $element = $(self.$el);
                var resultItems = $element.find('.flight-result-ddr__item.found');

                switch (event.keyCode) {
                    case 40:
                        if (typeof resultItems !== 'undefined' && resultItems.length > 0) {
                            if (this.selected >= resultItems.length - 1) this.selected = 0;
                            else this.selected += 1;
                            resultItems.removeClass('selected');
                            var selectedItem = $(resultItems.get(this.selected))
                            selectedItem.addClass('selected');
                            var resultName = selectedItem.find('.result-name');
                            this.onSelectLocation(selectedItem.find('.result-code').text(), resultName.text(), {
                                latitude: resultName.attr("data-latitude"),
                                longitude: resultName.attr("data-longitude")
                            });
                        }
                        break;
                    case 38:
                        if (typeof resultItems !== 'undefined' && resultItems.length > 0) {
                            if (this.selected == 0) this.selected = resultItems.length - 1;
                            else this.selected -= 1;
                            resultItems.removeClass('selected');
                            var selectedItem = $(resultItems.get(this.selected));
                            selectedItem.addClass('selected');
                            var resultName = selectedItem.find('.result-name');
                            this.onSelectLocation(selectedItem.find('.result-code').text(), resultName.text(), {
                                latitude: resultName.attr("data-latitude"),
                                longitude: resultName.attr("data-longitude")
                            });

                        }
                        break;
                    case 13:
                        event.preventDefault();
                        event.stopPropagation();
                        $element.trigger("click");
                        break;
                }
            },
            onSelectLocation: function (code, name, item) {
                let vm = this;
                let $this = $(vm.$el);
                let tempCode = (vm.typeRegions === 'Hotel' ? "H" : "R") + ":" + item.id;
                if (vm.name === "TransferSearchInfo.RegionId") $this.find("input[name='" + vm.name + "']").val(tempCode);
                else $this.find("input[name='" + vm.name + "']").val(code);
                $this.find(".ipt-search").val(name);
                vm.$emit('onValidate');
                vm.$emit('onLocationChanged', code);

                if (vm.type === "Transfer") {
                    $("input[name='TransferSearchInfo.AccommodationGeoCoords']").val(item.latitude + "," + item.longitude);
                    vm.$emit('accommodationGeoCoords', { latitude: item.latitude, longitude: item.longitude })
                }

                if (vm.name === "TransferSearchInfo.RegionId") {
                    vm.$emit('onCityChanged', { code: tempCode, airportCode: code })
                }

                if (vm.type === "hotel") {
                    if (item.type !== "city") {
                        if (item.type === "hotel") {
                            vm.hiddenHotelId.val(item.id);
                            vm.hiddenRegionId.val("");
                        } else {
                            vm.hiddenRegionId.val(item.id);
                            vm.hiddenHotelId.val("");
                        }
                    } else {
                        vm.hiddenRegionId.val("");
                        vm.hiddenHotelId.val("");
                    }
                }
            },
            closeDrop: function () {
                self = this;
            }
        },
        watch: {
            // tempTransferType() {
            //      this.onSelectLocation('', '', {});
            // },
            defaultText(val) {
                let vm = this;
                let $element = $(vm.$el);
                $element.find(".ipt-search").val(val);
            },
            to(newVal, oldVal) {
                let geoCoords = $("input[name='TransferSearchInfo.AccommodationGeoCoords']");
                if (this.type === "Transfer" && this.journeyType !== 'ToAirport' && newVal !== oldVal) {
                    geoCoords.val('');
                    geoCoords.parents('.search-input').find('.ipt-search').val('');
                    this.results = [];
                    this.$emit('onCityChanged', { code: '', airportCode: '' })
                }
            },
            cityCode(newVal, oldVal) {
                let toBox = $("input[name='To']");
                if (this.journeyType === 'ToAirport' && newVal !== oldVal) {
                    toBox.val('');
                    toBox.parents('.search-input').find('.ipt-search').val('');
                    this.results = [];
                    this.$emit('onLocationChanged', '')
                }
            }
        }
    }
</script>