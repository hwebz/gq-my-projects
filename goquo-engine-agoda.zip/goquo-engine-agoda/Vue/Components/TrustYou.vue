﻿<template>
    <div class="hotel-reviews">
        <div class="hotel-reviews__title">
            <div class="hotel-reviews__summary">
                <div class="hotel-reviews__score">
                    <div :class="'pie ' + trustyou.score_description.toLowerCase().replace(/ +/g, '-')">
                        <span class="inner-pie"></span>
                        <span class="text-pie">{{trustyou.score_display}}</span>
                    </div>
                </div>
                <div class="hotel-reviews__score-text">
                    <span>{{trustyou.score_description}}</span>
                    <small v-if="trustyou.reviews_count > 1" v-lang.BASED_ON_X_REVIEWS="{0: trustyou.reviews_count}"></small>
                    <small v-else v-lang.BASED_ON_X_REVIEW="{0: trustyou.reviews_count}"></small>
                </div>
            </div>
            <!--<div class="hotel-reviews__badges" v-if="trustyou.badge_list.length > 0">
                <ul>
                    <li v-for="(badge , badgeIndex) in trustyou.badge_list.slice(0, 3)" :class="{ 'top-pick' : badgeIndex == 0 }">
                        <div class="hotel-reviews__badge"></div>
                        <div class="hotel-reviews__badge-name">
                            <span>{{badge.text}}</span>
                            <small>{{badge.subtext}}</small>
                        </div>
                    </li>
                </ul>
            </div>-->
            <img :src="baseUrl + '/images/trustyou.png'" alt="TrustYou" class="trustyou" />
        </div>
        <div class="hotel-reviews__content">
            <div class="hotel-reviews__nav nav nav-tabs">
                <a :href="hotelId ? '#reviews-all' + hotelId : '#reviews-all'"
                   v-if="trustyou.reviews.all"
                   class="nav-item nav-link active"
                   data-toggle="tab">
                    <span v-lang.ALL></span> ({{trustyou.reviews.all.reviews_percent}}%)
                </a>
                <a :href="hotelId ? '#reviews-business' + hotelId : '#reviews-business'"
                   v-if="trustyou.reviews.business"
                   class="nav-item nav-link"
                   :class="{'active': !trustyou.reviews.all}"
                   data-toggle="tab">
                    <span v-lang.BUSINESS></span> ({{trustyou.reviews.business.reviews_percent}}%)
                </a>
                <a :href="hotelId ? '#reviews-couples' + hotelId : '#reviews-couples'"
                   v-if="trustyou.reviews.couples"
                   class="nav-item nav-link"
                   :class="{'active': !trustyou.reviews.all && !trustyou.reviews.business}"
                   data-toggle="tab">
                    <span v-lang.COUPLES></span> ({{trustyou.reviews.couples.reviews_percent}}%)
                </a>
                <a :href="hotelId ? '#reviews-families' + hotelId : '#reviews-families'"
                   v-if="trustyou.reviews.families"
                   class="nav-item nav-link"
                   :class="{'active': !trustyou.reviews.all && !trustyou.reviews.business && !trustyou.reviews.couples}"
                   data-toggle="tab">
                    <span v-lang.FAMILIES></span> ({{trustyou.reviews.families.reviews_percent}}%)
                </a>
                <a :href="hotelId ? '#reviews-solo' + hotelId : '#reviews-solo'"
                   v-if="trustyou.reviews.solo"
                   class="nav-item nav-link"
                   :class="{'active': !trustyou.reviews.all && !trustyou.reviews.business && !trustyou.reviews.couples && !trustyou.reviews.families}"
                   data-toggle="tab">
                    <span v-lang.SOLO></span> ({{trustyou.reviews.solo.reviews_percent}}%)
                </a>
            </div>
            <div class="hotel-reviews__tab-pane tab-content" v-if="!isEmpty(trustyou.reviews)">
                <TrustYouCategory :tyCat="trustyou.reviews.all" :id="hotelId ? 'reviews-all' + hotelId : 'reviews-all'" :isActive="true" />
                <TrustYouCategory :tyCat="trustyou.reviews.business" :id="hotelId ? 'reviews-business' + hotelId : 'reviews-business'" :isActive="!trustyou.reviews.all" />
                <TrustYouCategory :tyCat="trustyou.reviews.couples" :id="hotelId ? 'reviews-couples' + hotelId : 'reviews-couples'" :isActive="!trustyou.reviews.all && !trustyou.reviews.business" />
                <TrustYouCategory :tyCat="trustyou.reviews.families" :id="hotelId ? 'reviews-families' + hotelId : 'reviews-families'" :isActive="!trustyou.reviews.all && !trustyou.reviews.business && !trustyou.reviews.couples" />
                <TrustYouCategory :tyCat="trustyou.reviews.solo" :id="hotelId ? 'reviews-solo' + hotelId : 'reviews-solo'" :isActive="!trustyou.reviews.all && !trustyou.reviews.business && !trustyou.reviews.couples && !trustyou.reviews.families" />
            </div>
        </div>
    </div>
</template>

<script>
    import { mapState } from 'vuex'
    import _ from 'lodash';
    import TrustYouCategory from './TrustYouCategory.vue';
    export default {
        data() {
            return {
            };
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            baseUrl: state => state.workContext.baseUrl,
            transform() {
                return 360 * this.trustyou.score / 100;
            },
        }),
        props: ['trustyou', 'hotelId'],
        methods: {
            isEmpty(obj) {
                return _.isEmpty(obj);
            }
        },
        components: {
            TrustYouCategory
        }
    }
</script>