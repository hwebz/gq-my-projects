﻿﻿<template>
    <div class="container" v-if="packageQuery && hotelTransfer && transfers.length > 0">
        <div class="avai-findbar-transfer">
            <div class="row">
                <div class="col-12">
                    <ul>
                        <li>
                            <i class="icon-location-arrow"></i>
                            <span v-if="isArrivalTransfers">
                                <span v-lang.FROM></span>: {{packageQuery.toAirportName}}
                                <template v-if="packageQuery.toCityName">
                                    , {{packageQuery.toCityName}}
                                </template>
                                <template v-if="packageQuery.toCountryName">
                                    , {{packageQuery.toCountryName}}
                                </template>
                            </span>
                            <span v-else>
                                <span v-lang.FROM></span>: {{hotelTransfer.name}}
                                <template v-if="hotelTransfer.address">
                                    , {{hotelTransfer.address}}
                                </template>
                            </span>
                        </li>
                        <li>
                            <i class="icon-map-marker"></i>
                            <span v-if="isArrivalTransfers">
                                <span v-lang.TO></span>: {{hotelTransfer.name}}
                                <template v-if="hotelTransfer.address">
                                    , {{hotelTransfer.address}}
                                </template>

                            </span>
                            <span v-else>
                                <span v-lang.TO></span>: {{packageQuery.toAirportName}}
                                <template v-if="packageQuery.toCityName">
                                    , {{packageQuery.toCityName}}
                                </template>
                                <template v-if="packageQuery.toCountryName">
                                    , {{packageQuery.toCountryName}}
                                </template>
                            </span>
                        </li>
                    </ul>
                </div>
                <!--<div class="col-sm-3 text-right">
                    <select class="form-control">
                        <option value="1">Price Lowest</option>
                        <option value="2">Price Up</option>
                        <option value="3">Rating Lowest</option>
                    </select>
                </div>-->
            </div>
        </div>
        <div class="avai-hotel avai-transfer">
            <div class="fh-tabs__overview" :key="!transfer.isReturnJourney ? `arrivalTransfer-${transferIndex}` : `departureTransfer-${transferIndex}`" v-for="(transfer, transferIndex) in (transfers.slice(0, defaultTransferPerPage))">
                <div class="fh-tabs__item fh-tabs__hotel fh-tabs__transfer">
                    <div class="picture" :style="'background-image:url('+ transfer.images[0].url +')'" v-if="transfer.images.length > 0">
                    </div>
                    <div class="picture" :style="'background-image:url(' + baseUrl +'/images/img-transfer.jpg)'" v-else></div>
                    <div class="detail">
                        <h2 class="name">{{transfer.name}}</h2>
                        <ul class="list-info">
                            <li><i class="icon-clock"></i><span><span v-lang.RIDE_TIME>Ride time</span>: {{transfer.approximateTransferTime}}</span></li>
                            <li><i class="icon-group"></i><span>{{transfer.selectedVehicle.minPassengers}} - {{transfer.selectedVehicle.maxPassengers}}</span></li>
                            <li><i class="icon-briefcase"></i><span>{{transfer.selectedVehicle.maxLuggage}}</span></li>
                            <li v-if="transfer.allowForCheckInTime"><i class="icon-clock"></i><span><span v-lang.ESTIMATE_CHECKIN_TIME>Estimate check-in time</span>: {{transfer.allowForCheckInTime}}</span></li>
                            <li v-if="((arrivalTransfer && isArrivalTransfers && arrivalTransfer.transferId == transfer.transferId ) || (departureTransfer && !isArrivalTransfers  && departureTransfer.transferId == transfer.transferId)) && transfer.selected == true">
                                <a href="#modalCancellationTransfer" class="bt-link" data-toggle="modal" @click.prevent="setCancellationTransfer(transfer.isReturnJourney)">
                                    <i class="icon-information"></i>
                                    <span v-lang.VIEW_CANCELLATION_POLICY></span>  
                                </a>
                            </li> 
                        </ul>
                        <div class="description">
                            <p>{{transfer.description}}</p>
                        </div>
                        <!--<a class="bt-link" href="#"><i class="icon-down-chevron"></i>Read more...</a>-->
                    </div>
                </div>
                <div class="fh-tabs__item fh-tabs__control">
                    <div class="title-class text-uppercase" v-lang.TRANSFER></div>
                    <div class="title-perperson text-uppercase" v-lang.TOTAL_TRANSFER_PRICE></div>
                    <div class="price">
                        <span>{{packageQuery.currency}}</span>
                        <strong>{{transfer.selectedVehicle.totalPrice | formatCurrency}}</strong>
                    </div>
                    <a class="link-small" href="#modalTransferPriceBreakdown" data-toggle="modal" @click="showTransferPrice(transfer)" v-lang.PRICE_BREAKDOWN></a>
                    <a class="btn btn-block btn-outline-primary bt-effect"
                       :class="{'bt-selected': isSelectedTransfer(transfer)}"
                       data-toggle="collapse"
                       :href="'#transferDetail-' + transfer.id">
                        <i class="icon icon-checked" v-if="isSelectedTransfer(transfer)"></i>
                        {{isSelectedTransfer(transfer) ? translateText('SELECTED', 'Selected') : translateText('SELECT', 'Select')}}
                    </a>
                </div>
                <div class="fh-tabs__item fh-tabs__detail collapse" :id="'transferDetail-' + transfer.id" :class="{'active': arrivalTransfer && transfer.id === arrivalTransfer.id}">
                    <div class="loading-mask" :class="{'active': transfer.selectedVehicle.loading}">
                        <div class="loading-mask__loading">
                            <span v-lang.PROCESSING></span>
                        </div>
                    </div>
                    <div class="loading-mask" v-if="arrivalTransfer" :class="{'active': transfer.id === arrivalTransfer.id}">
                        <div class="loading-mask__loading">
                            <a class="btn btn-danger" href="javascript:void(0);" @click.prevent="removeTransfer(transfer, true)">
                                <i class="ico icon-remove"></i>
                                <span v-lang.REMOVE_THIS_TRANSFER></span>
                            </a>
                        </div>
                    </div>
                    <div class="loading-mask" v-if="departureTransfer" :class="{'active': transfer.id === departureTransfer.id}">
                        <div class="loading-mask__loading">
                            <a class="btn btn-danger" href="javascript:void(0);" @click.prevent="removeTransfer(transfer, false)">
                                <i class="ico icon-remove"></i>
                                <span v-lang.REMOVE_THIS_TRANSFER></span>
                            </a>
                        </div>
                    </div>
                    <div class="transferBook">
                        <form method="POST" action="/BookingTransfer/Package" data-val="true" @submit.prevent="bookingTransfer($event, transfer, transfer.selectedVehicle,transferIndex)" :data-arrival="isArrivalTransfers">
                            <div class="search-tabs" :class="{'disabled': transfer.selectedVehicle.selected}">
                                <div class="search-body">
                                    <div class="search-content">
                                        <div class="search-grid">
                                            <div class="box-search" :class="{'disabled': isDisabledFlightNo}">
                                                <strong>{{flightNumberLabel}}</strong>
                                                <div class="search-input">
                                                    <i class="ico icon-flight"></i>
                                                    <div class="ipt-show">
                                                        <input class="ipt-search"
                                                               data-value="true"
                                                               :data-required-message="translateText('PLEASE_GIVE_US_YOUR_FLIGHT_NUMBER', 'Please give us your flight number')"
                                                               :data-label="translateText('GIVE_US_YOUR_FLIGHT_NUMBER', 'Give us your flight number for easier to pick you up')"
                                                               name="FlightNo"
                                                               type="text"
                                                               :readonly="isDisabledFlightNo"
                                                               v-model="transfer.selectedVehicle.flightNo"
                                                               @change="autoFillFlightNo"
                                                               :placeholder="translateText('FLIGHT_NUMBER_PLACEHOLDER', 'e.g: AK123, VJ987, OD456, ...')" />
                                                    </div>
                                                </div>
                                            </div>
                                            <DateRangePicker date-format="DD/MM/YYYY"
                                                             :value="defaultPickUpDateTime(transfer)"
                                                             :startDate="calculateStartDate(transfer)"
                                                             :endDate="calculateEndDate(transfer)"
                                                             data-selected="true"
                                                             :isTransfer="true"
                                                             :isSinglePicker="true"
                                                             isFlight="true"
                                                             journeyType="0"
                                                             @onPickupDateTimeChanged="departureDate => onPickupDateTimeChanged(departureDate, transfer)" />
                                            <div class="box-search small-box">
                                                <strong>
                                                    <span v-lang.NO_OF_VEHICLES></span>
                                                    <template v-if="!isNaN(getMaxVehicle(transfer.selectedVehicle)) && getMaxVehicle(transfer.selectedVehicle) > 0" v-lang.MAX_VEHICLES="{0: getMaxVehicle(transfer.selectedVehicle)}">
                                                    </template>
                                                </strong>
                                                <div class="search-input">
                                                    <i class="ico icon-car"></i>
                                                    <div class="ipt-show" id="ipt-room-guests">
                                                        <div class="add-adjusts-box">
                                                            <div class="adjusts-box">
                                                                <div class="form-adjusts">
                                                                    <span class="icon-minus-gross-horizontal-straight-line-symbol bt-add" @click="changeNoOfVehicle(transfer, transfer.selectedVehicle, '-')"></span>
                                                                    <strong class="adjust-count">{{transfer.selectedVehicle.noOfVehicle}}</strong>
                                                                    <span class="icon-add1 bt-add" @click="changeNoOfVehicle(transfer, transfer.selectedVehicle, '+')"></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <input type="hidden" name="NoOfVehicle" :value="transfer.selectedVehicle.noOfVehicle">
                                                    </div>
                                                </div>
                                            </div>
                                            <input type="hidden" name="AirportCode" :value="transfer.selectedVehicle.airportCode" />
                                            <input type="hidden" name="HotelCode" :value="transfer.selectedVehicle.hotelCode" />
                                            <input type="hidden" name="HotelName" :value="transfer.selectedVehicle.HotelName" />
                                            <input type="hidden" name="VehicleCode" :value="transfer.selectedVehicle.vehicleCode" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="submit-btn">
                                <input type="submit" class="btn btn-primary bt-effect bt-selected" :value="translateText('ADD_THIS_TRANSFER', 'Add this transfer')" />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="paganition-wrap text-center" v-if="isLoadMore">
                <a class="item-paganition bt-effect" href="#" @click.prevent="loadMore()" v-lang.LOAD_MORE></a>
            </div>
        </div>
    </div>
</template>
<script>
    import Vue from 'vue'
    import { mapState } from 'vuex'
    import DateRangePicker from './DateRangePicker.vue'

    export default {
        props: ['flightNumberLabel', 'transfers', 'packageQuery', 'hotelTransfer', 'isArrivalTransfers', 'arrivalTransfer', 'departureTransfer', 'isOneWay', 'isToAirport', 'totalPax', 'tempTransfer', 'isDisabledFlightNo'],
        components: { DateRangePicker },
        data() {
            return {
                isLoadMore: false,
                defaultTransferPerPage: 10,
                maxSize: 10
            }
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            baseUrl: state => state.workContext.baseUrl
        }),
        created() {
            this.checkShowLoadMore();
        },
        methods: {
            translateText(translateKey, defaultText, params) {
                return this.translate(this.$language, translateKey, params) || defaultText;
            },
            removeTransfer(transfer, isArrival) {
                this.$emit('onRemoveTransfer', {
                    transfer: transfer,
                    isArrival: isArrival
                });
            },
            calculateStartDate(transfer) {
                let self = this;
                if (self.isOneWay) {
                    if (self.isToAirport) {
                        let depDate = Vue.moment(transfer.arrivalDate);
                        return depDate.subtract(2, 'day');
                    }
                }
                return  Vue.moment(transfer.arrivalDate);
            },
            calculateEndDate(transfer) {
                let self = this;
                let rideTime = {
                    hours: transfer.approximateTransferTime ? parseInt(transfer.approximateTransferTime.split(":")[0]) : 0,
                    minutes: transfer.approximateTransferTime ? parseInt(transfer.approximateTransferTime.split(":")[1]) : 0
                };
                let checkInTime = {
                    hours: transfer.allowForCheckInTime ? parseInt(transfer.allowForCheckInTime.split(":")[0]) : 0,
                    minutes: transfer.allowForCheckInTime ? parseInt(transfer.allowForCheckInTime.split(":")[1]) : 0
                };
                let endDate = Vue.moment(transfer.returnDate);
                endDate.subtract(checkInTime.hours + rideTime.hours, 'hours');
                endDate.subtract(checkInTime.minutes + rideTime.minutes, 'minutes');

                if (self.isOneWay) {
                    if (self.isToAirport) {
                        let depDate = Vue.moment(transfer.arrivalDate);
                        depDate.subtract(checkInTime.hours + rideTime.hours, 'hours');
                        depDate.subtract(checkInTime.minutes + rideTime.minutes, 'minutes');
                        return depDate;
                    } else {
                        let depDate = Vue.moment(transfer.arrivalDate);
                        depDate.subtract(checkInTime.hours + rideTime.hours, 'hours');
                        depDate.subtract(checkInTime.minutes + rideTime.minutes, 'minutes');
                        return depDate.add(2, 'day');
                    }
                }
                return endDate;
            },
            defaultPickUpDateTime(transfer) {
                let self = this;
                let departureDate = self.calculateStartDate(transfer);
                let returnDate = self.calculateEndDate(transfer);
                if (transfer.selected) {
                    return moment(transfer.selectedVehicle.pickUpDate).format('YYYY-MM-DD') + " " + transfer.selectedVehicle.pickUpTime;
                } else {
                    if (self.isArrivalTransfers) return departureDate.format('YYYY-MM-DD HH:mm');
                    else return returnDate.format('YYYY-MM-DD HH:mm');
                }
            },
            changeNoOfVehicle(transfer, vehicle, sign) {
                let self = this;
                let numVehicle = vehicle.noOfVehicle;
                switch (sign) {
                    case '+':
                        if (numVehicle < self.getMaxVehicle(vehicle)) numVehicle++;
                        break;
                    case '-':
                        if (numVehicle > self.getMinVehicle(vehicle)) numVehicle--;
                        break;
                }
                self.$emit('onChangeNoOfVehicle', {
                    transfer: transfer,
                    vehicle: vehicle,
                    numVehicle: numVehicle
                });
            },
            getMinVehicle: function (vehicle) {
                var self = this;
                var minVehicle = vehicle.maxVehicle;
                if (vehicle.maxPassengers > 0) {
                    minVehicle = Math.ceil(parseInt(self.totalPax) / parseInt(vehicle.maxPassengers));
                }
                return minVehicle;
            },
            getMaxVehicle: function (vehicle) {
                if (vehicle.maxPassengers > 0 && vehicle.maxVehicle) {
                    return vehicle.maxVehicle
                }
                return this.totalPax;
            },
            setCancellationTransfer(isReturnJourney) {
                this.$emit('onSetCancellationTransfer', { 
                    isDeparture: isReturnJourney             
                });
            },
            autoFillFlightNo(event) {
                let self = this;
                this.$emit('onAutoFillFlightNo', {
                    isArrival: self.isArrivalTransfers,
                    event: event
                });
            },
            isSelectedTransfer(transfer) {
                let self = this;
                if (self.isArrivalTransfers) {
                    if (self.arrivalTransfer) return transfer.id === self.arrivalTransfer.id;
                } else {
                    if (self.departureTransfer) return transfer.id === self.departureTransfer.id;
                }
                return false;
            },
            onPickupDateTimeChanged(departureDate, transfer) {
                transfer.selectedVehicle.pickUpDate = departureDate.format('YYYY-MM-DD');
                transfer.selectedVehicle.pickUpTime = departureDate.format('HH:mm');
            },
            bookingTransfer(event, transfer, selectedVehicle, transferIndex) {
                if (!this.onValidate(event)) return false;
                this.$emit('onBookingTransfer', {
                    event: event,
                    transfer: transfer,
                    selectedVehicle: selectedVehicle,
                    transferIndex: transferIndex
                })
            },
            validateInput(context) {
                let parent = context.parents('.box-search');
                let label = parent.find(">strong");
                let labelVals = {
                    old: context.attr('data-label'),
                    new: context.attr('data-required-message')
                };

                if (!context.val()) {
                    parent.addClass('error');
                    label.text(labelVals.new);
                    return false;
                } else {
                    parent.removeClass('error');
                    label.text(labelVals.old);
                }
                return true;
            },
            onValidate(e) {
                let self = this;
                let box = $(self.$el)
                let errors = 0;
                box.find("input[name='FlightNo']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                if (errors == 0) {
                    return true;
                }
                if (e) e.preventDefault();
            },
            showTransferPrice(transfer) {
                this.$emit('onShowTransferPrice', {
                    transfer: transfer,
                    isSummary: false
                });
            },
            loadMore() {
                if (this.transfers.length > this.defaultTransferPerPage)
                    this.defaultTransferPerPage += this.maxSize;
                this.checkShowLoadMore();
            },
            checkShowLoadMore() {
                if (this.defaultTransferPerPage >= this.transfers.length)
                    this.isLoadMore = false
                else this.isLoadMore = true
            }
        }
    }
</script>
