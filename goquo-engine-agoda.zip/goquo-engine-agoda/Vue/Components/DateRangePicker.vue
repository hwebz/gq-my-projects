<template>
    <div class="box-search" :class="{'flight-only': isFlight}">
        <strong>{{dateLabel}}</strong>
        <div class="search-input">
            <i class="ico icon-calendar"></i>
            <div class="ipt-show">
                <small class="dateRangeNumNights">...</small>
                <span class="dateRangeLabel">...</span>
            </div>
            <div v-if="isMyTrip">
                <input type="hidden" name="CheckIn" />
                <input type="hidden" name="CheckOut" />
            </div>
            <div v-else>
                <template v-if="isTourResult">
                    <input type="hidden" name="OperatorDate" />
                </template>
                <template v-else>
                    <template v-if="isTransfer">
                        <input type="hidden" name="PickUpDate" />
                        <input type="hidden" name="PickUpTime" />
                    </template>
                    <template v-else>
                        <input type="hidden" name="DepartureDate" />
                        <input type="hidden" name="ReturnDate" />
                    </template>
                </template>
                <template v-if="type === 'Transfer'">
                    <input type="hidden" name="TransferSearchInfo.TravelTime" />
                    <input type="hidden" name="TransferSearchInfo.ReturnTime" />
                </template>
            </div>
        </div>
    </div>
</template>
<script>
    import Vue from 'vue';
    export default {
        model: {
            prop: 'value'
        },
        data() {
            return {
                dates: {
                    startDate: new Date(),
                    endDate: new Date()
                }
            }
        },
        computed: {
            datePickerDateFormat() {
                return this.$store.state.workContext.siteInfo.datePickerDateFormat;
            },
            dateLabel() {
                let lbl = '';
                if (this.type === 'Transfer') {
                    switch (this.journeyType) {
                        case 'Return':
                            lbl = this.translateText('FLIGHT_ARRIVE_DEPART_AT', 'Flight arrive/depart at');
                            break;
                        case 'FromAirport':
                            lbl = this.translateText('FLIGHT_ARRIVE_AT', 'Flight arrive at');
                            break;
                        case 'ToAirport':
                            lbl = this.translateText('FLIGHT_DEPART_AT', 'Flight depart at');
                            break;
                    }
                } else {
                    lbl = this.isFlight ? this.translateText('DATES', 'Dates') : this.translateText('FOR', 'For');
                }
                return lbl;
            }
        },
        mounted: function () {
            var vm = this;
            var $element = $(vm.$el);
            var dateformat = $element.data("date-format");

            if (!dateformat) {
                dateformat = vm.$store.state.workContext.siteInfo.datePickerDateFormat.toUpperCase();
            }

            this.disabledDatesValue = null;
            var options = {
                autoApply: true,
                customHeader: false,
                timePicker: (vm.type === "Transfer" || vm.isTransfer),
                timePickerIncrement: 15,
                timePicker24Hour: true,
                singleDatePicker: vm.isSinglePicker,
                minSpan: {
                    days: vm.minSpan ? 0 : 1
                },
                locale: {
                    format: dateformat
                },
                isInvalidDate: function (date) {
                    if (!vm.disabledDatesValue) {
                        return false;
                    }

                    if (date < vm.disabledDatesValue.startDate || date > vm.disabledDatesValue.endDate) {
                        return true;
                    }

                    var year = date.getFullYear();
                    if (vm.disabledDatesValue.disabledDates && vm.disabledDatesValue.disabledDates[year]) {
                        var month = date.getMonth() + 1;
                        if (vm.disabledDatesValue.disabledDates[year][month]) {
                            var day = date.getDate();
                            var days = vm.disabledDatesValue.disabledDates[year][month];
                            if ($.inArray(day, days) > -1) {
                                return true;
                            }
                        }
                    }

                    return false;
                },
            };

            var startDate = new Date();

            //adding minutes to set utc date
            var addingMinutes = startDate.getTimezoneOffset();
            startDate.setDate(startDate.getDate() + 1);

            // Start date
            if (this.startDate) {
                startDate = new Date(this.startDate);

                if (this.addOneDay) {
                    startDate.setMinutes(startDate.getMinutes() + 1440 + addingMinutes);
                }
            }
            else {
                // Min days before
                if (this.minDaysBefore && this.minDaysBefore > 0) {
                    var minutes = parseInt(this.minDaysBefore) * 60;
                    startDate.setMinutes(startDate.getMinutes() + minutes + addingMinutes);
                }
            }
            options.minDate = startDate;
            // End date
            if (this.endDate) {
                var dt = new Date(this.endDate);
                options.maxDate = dt;
            }
            else {
                // Max days after
                if (this.maxDaysAfter && this.maxDaysAfter > 0) {
                    var dt = new Date();
                    dt.setDate(dt.getDate() + parseInt(this.maxDaysAfter));
                    options.maxDate = dt;
                }
            }

            if ($element.data('daterangepicker')) {
                $element.data('daterangepicker').remove();
            }

            var $datepicker = $element.daterangepicker(options);

            if (this.value) {
                var datepicker = $datepicker.data('daterangepicker');
                var selectedDate = this.value.split(',');
                let startDate = new Date(selectedDate[0]);
                let endDate = new Date(selectedDate[1]);

                if (this.addedDates) endDate.setHours((new Date()).getHours() + 2);
                datepicker.setStartDate(startDate);
                datepicker.setEndDate(endDate);
            }
            else if (this.defaultValue) {
                var datepicker = $datepicker.data('daterangepicker');
                var selectedDate = this.defaultValue.split(',');
                datepicker.setStartDate(new Date(selectedDate[0]));
                datepicker.setEndDate(new Date(selectedDate[1]));
            }

            if (this.value || this.defaultValue) {
                var datepicker = $datepicker.data('daterangepicker');
                vm.setInputValue(datepicker.startDate, datepicker.endDate);
            }

            this.$datepicker = $datepicker;
            this.$element = $element;
            this.options = options;

            $datepicker.on('apply.daterangepicker', function (ev, picker) {
                vm.setInputValue(picker.startDate, picker.endDate);
                if (!vm.isMyTrip) {
                    vm.$emit('onChangeDate');
                }
            }).data("daterangepicker");

            if (this.disableDateUrl && this.disableDateUrl.length > 0) {
                this.setupDisableDateUrl();
            }
            this.changeJourneyType(this.journeyType);
        },
        props: ['value', 'defaultValue', 'startDate', 'endDate', 'maxDaysBetween', 'minDaysBefore', 'maxDaysAfter', 'autoFocus', 'addOneDay', 'disableDateUrl', 'isFlight', 'isMyTrip', 'journeyType', 'isChange', 'type', 'isTourResult', 'dailyRates', 'isTransfer', 'isSinglePicker', 'addedDates', 'minSpan'],
        methods: {
            setupDisableDateUrl: function () {
                var self = this;

                $.get(this.disableDateUrl, function (response) {
                    self.disabledDatesValue = response;
                    var datepicker = self.$datepicker.data('daterangepicker');
                    datepicker.update();
                });
            },
            setInputValue: function (departureDate, returnDate) {
                var $element = $(this.$el);
                var dDate = $element.find("input[name='DepartureDate']");
                var rDate = $element.find("input[name='ReturnDate']");
                var tTime = $element.find("input[name='TransferSearchInfo.TravelTime']");
                var rTime = $element.find("input[name='TransferSearchInfo.ReturnTime']");
                var opDate = $element.find("input[name='OperatorDate']");
                var pickupDate = $element.find("input[name='PickUpDate']");
                var pickupTime = $element.find("input[name='PickUpTime']");
                var dLabel = $element.find(".dateRangeLabel");
                var dNumNights = $element.find('.dateRangeNumNights');
                this.dates.startDate = departureDate;
                this.dates.endDate = returnDate;
                dDate.val(Vue.moment(departureDate).format('YYYY-MM-DD'));
                if ($element.data('daterangepicker').singleDatePicker) {
                    rDate.val(Vue.moment(departureDate).add(1, 'days').format('YYYY-MM-DD'));
                } else {
                    rDate.val(Vue.moment(returnDate).format('YYYY-MM-DD'));
                }

                if (this.isTourResult) {
                    opDate.val(Vue.moment(departureDate).format('YYYY-MM-DD'))
                    this.$emit('onOperatorDateChanged', Vue.moment(departureDate).format('YYYY-MM-DD'));
                }

                if (this.isTransfer) {
                    pickupDate.val(Vue.moment(departureDate).format('YYYY-MM-DD'));
                    pickupTime.val(Vue.moment(departureDate).format('HH:mm'));
                    this.$emit('onPickupDateTimeChanged', Vue.moment(departureDate));
                }

                if (this.type === "Transfer") {
                    tTime.val(Vue.moment(departureDate).format('HH:mm'));
                    rTime.val(Vue.moment(returnDate).format('HH:mm'));
                }

                if (this.journeyType == "1" || this.journeyType == "Return") {
                    var numNights = parseInt((returnDate.toDate().getTime() - departureDate.toDate().getTime()) / (24 * 3600 * 1000));
                    numNights = numNights > 1 ? (numNights + this.translateText('NIGHTS', ' nights')) : (numNights + this.translateText('NIGHT', ' night'));

                    dLabel.text(Vue.moment(departureDate).format('DD MMM') + ' - ' + returnDate.format('DD MMM'));

                    dNumNights.text(this.isFlight ? this.translateText('DEPARTURE', 'Departure') - this.translateText('ARRIVAL', 'Arrival') : numNights);
                } else {
                    dLabel.text(Vue.moment(departureDate).format('DD MMM YYYY'));
                    rDate.val('');
                }

                if (this.isTransfer) {
                    dLabel.text(Vue.moment(departureDate).format('DD MMM YYYY HH:mm'));
                }

                 // check is mytrip
                if (this.isMyTrip)
                    this.setInputForMyTrip(departureDate, returnDate);
            },
            setInputForMyTrip: function (checkIn, checkOut) {
                var $element = $(this.$el);
                var dDate = $element.find("input[name='CheckIn']");
                var rDate = $element.find("input[name='CheckOut']");
                var dLabel = $element.find(".dateRangeLabel");
                if (checkIn.isSame(checkOut)) {
                    var currentValue = this.value.split(",");
                    if (currentValue != null) {
                        checkIn = moment(currentValue[0]);
                        checkOut = moment(currentValue[1])
                    }
                }
                var dNumNights = $element.find('.dateRangeNumNights');
                var numNights = parseInt((checkOut.toDate().getTime() - checkIn.toDate().getTime()) / (24 * 3600 * 1000));
                numNights = numNights > 1 ? (numNights + this.translateText('NIGHTS', ' nights')) : (numNights + this.translateText('NIGHT', ' night'));
                dDate.val(checkIn.format('YYYY-MM-DD'));
                rDate.val(checkOut.format('YYYY-MM-DD'));
                dLabel.text(Vue.moment(checkIn).format('DD MMM') + ' - ' + checkOut.format('DD MMM'));
                dNumNights.text(this.isFlight ? 'CheckIn - CheckOut' : numNights);
            },
            onChangeDateTime: function () {
                var flag = this.isChange;
                if (flag) {
                    this.$emit('onChangeDateTime');
                }
            },
            changeJourneyType(value) {
                var self = this;
                var datepicker = self.$datepicker.data('daterangepicker');
                self.options.singleDatePicker = (parseInt(value) == 0 || value === "FromAirport" || value === "ToAirport");
                if (self.$element.data('daterangepicker')) {
                    self.$element.data('daterangepicker').remove();
                }
                var datepickerSingle = self.$element.daterangepicker(self.options, function (start, end, label) {
                    self.setInputValue(start, end);
                    self.onChangeDateTime();
                });

                // check is mytrip
                if (!self.isMyTrip) {
                    self.setInputValue(self.dates.startDate, self.dates.endDate);
                }
                var datepicker = self.$datepicker.data('daterangepicker');
                datepicker.setStartDate(self.dates.startDate);
                datepicker.setEndDate(self.dates.endDate);
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            }
        },
        watch: {
            startDate: function (value) {
                var dt = new Date(value);
                // adding minutes to get utc time
                var addingMinutes = dt.getTimezoneOffset();

                if (this.addOneDay) {
                    dt.setMinutes(dt.getMinutes() + 1440 + addingMinutes);
                }
                var datepicker = this.$datepicker.data('daterangepicker');

                if (this.isMyTrip) {
                    this.options.minDate = dt;
                    if (this.$element.data('daterangepicker')) {
                        this.$element.data('daterangepicker').remove();
                    }
                    var $datepickerMyTrip = this.$element.daterangepicker(this.options);
                    var datepickerMyTrip = $datepickerMyTrip.data('daterangepicker');
                    datepickerMyTrip.setStartDate(dt);
                    datepickerMyTrip.setEndDate(datepicker.endDate);
                }
                else {
                    datepicker.setStartDate(dt);
                    var currentDate = datepicker.startDate;

                    if (currentDate) {
                        if (currentDate < dt) {
                            datepicker.setStartDate(dt);
                        }
                    }
                    else {
                        datepicker.setStartDate(dt);
                    }

                    if (this.maxDaysBetween) {
                        var endDate = new Date(value);
                        endDate.setDate(endDate.getDate() + parseInt(this.maxDaysBetween));
                        datepicker.setEndDate(endDate);
                    }

                    if (this.autoFocus) {
                        this.$datepicker.focus();
                    }
                }
            },
            endDate: function (value) {
                var self = this;
                var dt = new Date(value);
                var datepicker = this.$datepicker.data('daterangepicker');
                if (this.isMyTrip) {
                    this.options.maxDate = dt;
                    if (this.$element.data('daterangepicker')) {
                        this.$element.data('daterangepicker').remove();
                    }
                    var $datepickerMyTrip = self.$element.daterangepicker(self.options, function (start, end, label) {
                        self.setInputValue(start, end);
                    });
                    var datepickerMyTrip = $datepickerMyTrip.data('daterangepicker');
                    datepickerMyTrip.setStartDate(datepicker.startDate);
                    datepickerMyTrip.setEndDate(dt);
                    this.setInputValue(datepickerMyTrip.startDate, datepickerMyTrip.endDate);
                }
                else {
                    datepicker.setEndDate(dt);
                }
            },
            defaultValue: function (value) {
                if (!value) {
                    return;
                }
                let dt = new Date(value);
                let datepicker = this.$datepicker.data('daterangepicker');
                datepicker.setStartDate(dt);
            },
            disableDateUrl: function () {
                this.setupDisableDateUrl();
            },
            journeyType: function (value) {
                this.changeJourneyType(value);
            }
        }
    }

</script>
