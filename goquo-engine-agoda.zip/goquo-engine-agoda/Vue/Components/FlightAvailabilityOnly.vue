<template>
    <div>
        <div class="research flex-grow" v-show="hasErrorMessage">
            <div class="container" v-if="packageQuery && isCompleted">
                <SessionTimeout :packageId="packageQuery.id" :secondTimeout="packageQuery.ttl"></SessionTimeout>
                <nav class="crumbar">
                    <ul>
                        <li v-lang.SEARCH_FLIGHTS_FROM_TO="{0: packageQuery.fromCityName, 1: packageQuery.toCityName}"></li>
                    </ul>
                </nav>
                <div class="research__wrap">
                    <h1 v-lang.YOUR_SEARCH_FLIGHTS_FROM_TO="{0: packageQuery.fromCityName, 1: packageQuery.toCityName}"></h1>
                </div>
                <div class="research__content">
                    <div class="research__title">
                        <h2 v-if="model.journeyType == 1" v-lang.YOUR_SEARCH_DATE_FROM_TO="{0: formatDate(packageQuery.departureDate, 'DD MMMM YYYY'), 1: formatDate(packageQuery.returnDate, 'DD MMMM YYYY')}"></h2>
                        <h2 v-else v-lang.YOUR_SEARCH_DATE_AT="{0: formatDate(packageQuery.departureDate, 'DD MMMM YYYY')}"></h2>
                        <p v-lang.CHECK_YOUR_SPELLING_AND_TRY_AGAIN></p>
                    </div>
                    <div class="research__form">
                        <div class="search-wrap">
                            <div class="search-tabs search-research">
                                <div class="search-content">
                                    <FlightSearchBox :product="product" 
                                                     :packageQuery="packageQuery"
                                                     :journeyType="model.journeyType" 
                                                     :defaultDate="defaultDate" 
                                                     :from="packageQuery.from" 
                                                     :to="packageQuery.to" 
                                                     :fromCityName="fullFromCityName" 
                                                     :toCityName="fullToCityName" 
                                                     :cabinClass="packageQuery.cabinClass" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div v-show="!hasErrorMessage">
            <div v-if="packageQuery && isCompleted">
                <div class="page-title-tabs">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                <div>
                                    <h1>{{packageQuery.fromCityName}} - {{packageQuery.toCityName}}</h1>
                                    <h6 v-if="cheapestFlightPrice" v-lang.FLIGHT_FROM_PRICE="{0: packageQuery.currency, 1: cheapestFlightPrice}"></h6>
                                    <h6 v-else>
                                        <div class="lda">
                                            <div class="lda__bar"></div>
                                        </div>
                                    </h6>
                                </div>
                                <div class="date-time-person">
                                    <span>
                                        <i class="icon-calendar"></i>
                                        <p>
                                            {{ formatDate(packageQuery.departureDate, 'DD MMM') }}
                                            <template v-if="packageQuery.journeyType">
                                                - {{ formatDate(packageQuery.returnDate, 'DD MMM') }}
                                            </template>
                                        </p>
                                    </span>
                                    <span>
                                        <i class="icon-user"></i>
                                        <p>
                                            {{calculatePaxCount}} {{calculatePaxCount == 1 ? translateText('PASSENGER', 'Passenger') : translateText('PASSENGERS', 'Passengers')}}
                                        </p>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-5 text-right">
                                <a class="btn-title-tabs" href="#modalChangeDate" data-toggle="modal" data-target="#modalChangeDate">
                                    <i class="icon-search"></i><span v-lang.EDIT_SEARCH></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="content-wrap">
                    <div class="content-tabs-main tab-content">
                        <div class="content-tabs-wrap tab-pane active show">
                            <div class="container">
                                <div class="row">
                                    <FlightFilters :packageQuery="packageQuery"
                                                   :showOutboundFlights="showOutboundFlights"
                                                   :flightAggreation="showOutboundFlights ? flightStore.outboundAggreation : flightStore.inboundAggreation"
                                                   :flightStore="flightStore"
                                                   :product="product"
                                                   @onTogglePaneChanged="togglePane"
                                                   @onDepartureTimesChanged="onDepartureTimesChanged"
                                                   @onArrivalTimesChanged="onArrivalTimesChanged"
                                                   @onFilterByNumberOfStops="filterByNumberOfStops"
                                                   @onFilterByAirlines="filterByAirlines" />
                                    <FlightAvailability v-if="showOutboundFlights"
                                                        direction="0"
                                                        :loading="loading"
                                                        :flightLoadCompleted="flightLoadCompleted"
                                                        :errorMessage="errorMessage"
                                                        :flights="flightStore.outboundFlights"
                                                        :flightStore="flightStore"
                                                        :flightAggreation="flightStore.outboundAggreation"
                                                        :product="product"
                                                        @onSortedFlights="sortFlights"
                                                        @onChangeFlight="onFlightChanged"
                                                        @onPaginationChanged="onFlightPaginationChanged"
                                                        @onShowPriceSummaryPaneFlight="onShowPriceSummaryPaneFlight"
                                                        isFlightOnly="true" />
                                    <FlightAvailability v-else
                                                        direction="1"
                                                        :loading="loading"
                                                        :flightLoadCompleted="flightLoadCompleted"
                                                        :errorMessage="errorMessage"
                                                        :flights="flightStore.inboundFlights"
                                                        :flightStore="flightStore"
                                                        :flightAggreation="flightStore.inboundAggreation"
                                                        @onSortedFlights="sortFlights"
                                                        @onClearOutbound="clearOutbound"
                                                        @onChangeFlight="onFlightChanged"
                                                        @onPaginationChanged="onFlightPaginationChanged"
                                                        @onShowPriceSummaryPaneFlight="onShowPriceSummaryPaneFlight"
                                                        isFlightOnly="true" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade modal-md" id="modalChangeDate" tabindex="-1" role="dialog" aria-hidden="true" v-show="hasErrorMessage">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-title ">
                                <strong v-lang.SEARCH_FLIGHTS></strong>
                                <button class="modal-close" data-dismiss="modal">
                                    <i class="icon-remove"></i>
                                </button>
                            </div>
                            <form method="GET" action="/package/start-search" data-val="true" @submit="onValidate">
                                <div class="search-tabs search-popup">
                                    <div class="search-content">
                                        <div class="journey-type">
                                            <label class="radio-inline">
                                                <input type="radio" checked="checked" name="JourneyType" value="1" v-model="model.journeyType" /> <span v-lang.ROUNDTRIP></span>
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="JourneyType" value="0" v-model="model.journeyType" /> <span v-lang.ONE_WAY></span>
                                            </label>
                                        </div>
                                        <div class="search-grid">
                                            <AjaxSelect name="From"
                                                        :placeholder="translateText('PLEASE_INPUT_AIRPORT', 'Please input airport or city name')"
                                                        :txtLabel="translateText('FROM', 'From')"
                                                        icon="ico icon-location-arrow"
                                                        :accepted="true"
                                                        :url="'/api/get-global-airports'"
                                                        :defaultValue="packageQuery.from"
                                                        :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_SOURCE', 'Please choose a valid source')"
                                                        @onValidate="onValidate"
                                                        :defaultText="fullFromCityName" />
                                            <AjaxSelect name="To"
                                                        :placeholder="translateText('PLEASE_INPUT_AIRPORT', 'Please input airport or city name')"
                                                        :txtLabel="translateText('TO', 'To')"
                                                        icon="ico icon-map-marker"
                                                        :defaultValue="packageQuery.to"
                                                        :defaultText="fullToCityName"
                                                        :dataRequiredMessage="translateText('PLEASE_CHOOSE_A_VALID_DESTINATION', 'Please choose a valid destination')"
                                                        @onValidate="onValidate"
                                                        :accepted="true"
                                                        :url="'/api/get-global-airports'"/>
                                            <DateRangePicker v-model="defaultDate" :journeyType="model.journeyType" date-format="DD/MM/YYYY" @onChangeDate="onChangeDate" isFlight="true" :minSpan="true" />
                                            <PaxSelector :maxRooms="3" :isFlightOnly="true" />
                                            <CabinClass :cabinClass="packageQuery.cabinClass" :uniqueId="clientResources.uniqueId" />
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="hidden" name="OrderId" :value="packageQuery.orderId" />
                                    <input type="hidden" name="Currency" :value="packageQuery.currency" />
                                    <input type="hidden" name="ProductId" :value="packageQuery.productId" />
                                    <button id="btnSumitSearchFormFlight" class="btn btn-sm btn-primary bt-effect" type="submit" v-lang.SEARCH></button>
                                    <button class="btn btn-sm btn-default bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="modalPriceBreakdown" tabindex="-1" role="dialog" aria-hidden="true" v-if="packageQuery && isSearchCompleted && !hasErrorMessage">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-body modal-body-gray npd">
                                <div class="flight-detail-title">
                                    <strong v-lang.PRICE_BREAKDOWN></strong>
                                    <button class="modal-close" data-dismiss="modal">
                                        <i class="icon-remove"></i>
                                    </button>
                                </div>
                                <div class="price-summary-table">
                                    <table class="responsive">
                                        <thead>
                                        <tr>
                                            <th colspan="4" v-lang.FLIGHT_PRICE></th>
                                        </tr>
                                        <tr>
                                            <th scope="col" v-lang.PASSENGERS></th>
                                            <th scope="col" v-lang.PRICE_PER_PAX></th>
                                            <th scope="col" v-lang.NO_OF_PASSENGERS></th>
                                            <th scope="col" v-lang.TOTAL_PRICE></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td scope="row" :data-label="translateText('PER_PASSENGER', 'Per Passenger')" v-lang.PER_PASSENGER></td>
                                            <td :data-label="translateText('PRICE_PER_PAX', 'Price/pax')">{{packageQuery.currency}} {{priceSummary.adultPrice | formatCurrency}}</td>
                                            <td :data-label="translateText('NO_OF_PASSENGERS', 'No. of Passengers')">{{calculatePaxCount}}</td>
                                            <td :data-label="translateText('TOTAL_PRICE', 'Total Price')">{{packageQuery.currency}} {{priceSummary.adultPrice * calculatePaxCount | formatCurrency}}</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    <table>
                                        <thead>
                                        <tr>
                                            <th v-lang.TOTAL_PRICE_INCLUDES_TAXES_AND_FEES></th>
                                            <th>{{packageQuery.currency}} {{priceSummary.totalPrice | formatCurrency}}</th>
                                        </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-sm btn-primary bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                            </div>
                        </div>
                    </div>
                </div>
                <a class="back-to-top" href="#" @click="backTop">
                    <i class="icon icon-up-chevron"></i>
                    <span v-lang.BACK_TO_TOP></span>
                </a>
            </div>
            <div v-else>
                <div class="page-title-tabs">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                <div class="lda">
                                    <div class="lda__bar lda__bar--h34"></div>
                                    <div class="lda__bar lda__bar--50"></div>
                                </div>
                            </div>
                            <div class="col-md-5 text-right">
                                <a class="btn-title-tabs">
                                    <div class="lda__bar"></div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="content-wrap">
                    <div class="content-wrap-tabs">
                        <div class="content-tabs-main">
                            <div class="tab-pane active show">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-lg-3">
                                            <div class="sidebar-wrap">
                                                <div class="sidebar__box">
                                                    <div class="sidebar__title">
                                                        <h2 v-lang.STOPS></h2>
                                                    </div>
                                                    <div class="sidebar__content">
                                                        <div class="sidebar__rating">
                                                            <div class="lda">
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="sidebar__title">
                                                        <h2 v-lang.AIRLINE_NAME></h2>
                                                    </div>
                                                    <div class="sidebar__content">
                                                        <div class="sidebar__dropdown">
                                                            <div class="lda">
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                                <div class="lda__bar"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="sidebar__title">
                                                        <h2 v-lang.DEPARTURE_TIME></h2>
                                                    </div>
                                                    <div class="sidebar__content">
                                                        <div class="sidebar__dropdown">
                                                            <div class="lda">
                                                                <div class="lda__bar lda__bar--h60"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="sidebar__title">
                                                        <h2 v-lang.ARRIVAL_TIME></h2>
                                                    </div>
                                                    <div class="sidebar__content">
                                                        <div class="sidebar__dropdown">
                                                            <div class="lda">
                                                                <div class="lda__bar lda__bar--h60"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-9">
                                            <div class="avai-flight">
                                                <div class="fh-tabs__title mb-3">
                                                    <h4>
                                                        <div class="lda__bar lda__bar--50 lda__bar--h34"></div>
                                                    </h4>
                                                    <div class="fh-tabs__right-info">
                                                        <div class="lda__bar lda__bar--h34"></div>
                                                    </div>
                                                    <div class="fh-tabs__utils">
                                                        <h4>
                                                            <div class="lda__bar lda__bar--50"></div>
                                                        </h4>
                                                        <div class="fh-tabs__sort">
                                                            <div class="lda__bar"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="fh-tabs__overview" v-for="n in 10" :key="n">
                                                    <div class="fh-tabs__item fh-tabs__flight">
                                                        <div class="flight-way__tabs">
                                                            <div class="flight-way__view">
                                                                <div class="flight-way__view">
                                                                    <div class="lda__wrap">
                                                                        <div class="lda">
                                                                            <div class="lda__bar"></div>
                                                                            <div class="lda__bar lda__bar--50"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="fh-tabs__item fh-tabs__control">
                                                        <div class="lda lda--fbot">
                                                            <div class="lda__bar lda__bar--50"></div>
                                                            <div class="lda__bar lda__bar--50"></div>
                                                            <div class="lda__bar lda__bar--two"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="paganition-wrap">
                                                    <div class="item-paganition lda__bar lda__bar--h60"></div>
                                                    <span class="count-page lda__bar"></span>
                                                    <div class="item-paganition lda__bar lda__bar--h60"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Vue from 'vue'
    import {
        mapState
    } from 'vuex'
    import Cookie from 'js-cookie'
    import FlightAvailability from './FlightAvailability.vue'
    import FlightFilters from './FlightFilters.vue'
    import AjaxSelect from './AjaxSelect.vue'
    import DateRangePicker from './DateRangePicker.vue'
    import PaxSelector from './PaxSelector.vue'
    import LoadBar from './LoadBar.vue';
    import FlightSearchBox from './FlightSearchBox.vue'
    import SessionTimeout from './SessionTimeout.vue'
    import CabinClass from "./CabinClass.vue";

    export default {
        components: {
            CabinClass,
            FlightAvailability,
            FlightFilters,
            AjaxSelect,
            DateRangePicker,
            PaxSelector,
            LoadBar,
            FlightSearchBox,
            SessionTimeout
        },
        data() {
            return {
                packageQuery: null,
                enabledFlights: false,
                hasErrorMessage: false,
                errorMessage: "",
                flightErrorMessage: null,
                enabledMapView: true,
                showMapView: false,
                showMapFull: false,
                isSearchCompleted: false,
                flightLoadCompleted: false,
                abortPing: false,
                previousStatus: {},
                showOutboundFlights: true,
                flightStore: {
                    flights: [],
                    inboundFlights: [],
                    outboundFlights: [],
                    outboundFlight: null,
                    inboundFlight: null,
                    outboundAggreation: {
                        totalPages: 0,
                        nonStop: false,
                        oneStop: false,
                        hasStops: false,
                        airlines: []
                    },
                    inboundAggreation: {
                        totalPages: 0,
                        nonStop: false,
                        oneStop: false,
                        hasStops: false,
                        airlines: []
                    },
                    outboundFilters: {
                        direction: 'OutBound',
                        pageIndex: 1,
                        pageSize: 10,
                        sortBy: "SolutionPrice",
                        sortByDesc: false,
                        outboundFilter: {
                            minDepartureTime: "00:00",
                            maxDepartureTime: "24:00",
                            minArrivalTime: "00:00",
                            maxArrivalTime: "24:00"
                        }
                    },
                    inboundFilters: {
                        direction: 'InBound',
                        pageIndex: 1,
                        pageSize: 10,
                        sortBy: "SolutionPrice",
                        sortByDesc: false,
                        inboundFilter: {
                            minDepartureTime: "00:00",
                            maxDepartureTime: "24:00",
                            minArrivalTime: "00:00",
                            maxArrivalTime: "24:00"
                        }
                    }
                },
                loading: {
                    flightDetails: false,
                    flightPagination: false
                },
                model: {
                    from: null,
                    to: null,
                    departureDate: null,
                    returnDate: null,
                    checkIn: null,
                    checkOut: null,
                    partialStay: false,
                    journeyType: 1
                },
                flightChangePrice: 0,
                defaultDate: null,
                defaultDateForMytrip: null,
                isFirstLoad: true,
                priceSummary: {
                    adultPrice: 0,
                    childPrice: 0,
                    totalPrice: 0
                },
                cheapestFlightPrice: null,
                cheapestFlights: {
                    outbound: null,
                    inbound: null
                },
                clientResources: null,
                searchConditions: {
                    adultCount: 0,
                    childCount: 0,
                    infantCount: 0
                },
                isCompleted: false
            }
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            baseUrl: state => state.workContext.baseUrl,
            product: state => state.workContext.product,
            depatureDisableDateUrl() {
                if (!this.packageQuery) {
                    return null;
                }
                return "/package/get-disabled-dates?from=" + this.model.from + "&to=" + this.model.to;
            },
            returnDisableDateUrl() {
                if (!this.packageQuery) {
                    return null;
                }
                return "/package/get-disabled-dates?from=" + this.model.to + "&to=" + this.model.from;
            },
            roomCount() {
                return this.packageQuery.paxInfos.length;
            },
            persons() {
                return 1;
            },
            calculatePaxCount() {
                return this.searchConditions.adultCount + this.searchConditions.childCount + this.searchConditions.infantCount;
            },
            adultCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                }
                return count;
            },
            childCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.childCount;
                }
                return count;
            },
            infantCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.infantCount;
                }
                return count;
            },
            fullFromCityName() {
                var self = this;
                return self.packageQuery.fromCityName + ' (' + self.packageQuery.from + ') ,' + self.packageQuery.fromCountryName;
            },
            fullToCityName() {
                var self = this;
                return self.packageQuery.toCityName + ' (' + self.packageQuery.to + ') ,' + self.packageQuery.toCountryName;
            }
        }),
        created() {
            var self = this;
            var packageId = $("#PackageId").val();
            $.post('/package/work-context/' + packageId, function (data) {
                if (!data.packageQuery) {
                    window.location.reload();
                }
                self.packageQuery = data.packageQuery;
                self.flightStore.outboundFilters.packageId = data.packageQuery.id;
                self.flightStore.inboundFilters.packageId = data.packageQuery.id;

                self.model.from = data.packageQuery.from;
                self.model.to = data.packageQuery.to;
                self.model.toCityName = data.packageQuery.toCityName;
                self.model.toCountryName = data.packageQuery.toCountryName;
                self.model.regionId = self.$route.query.RegionId;
                self.model.departureDate = data.packageQuery.departureDate;
                self.model.returnDate = data.packageQuery.returnDate;
                self.model.journeyType = data.packageQuery.journeyType;
                data.baseUrl = $("#baseURL").val();
                
                $.getJSON(data.baseUrl + '/resources.json', function (res) {
                    data.clientResources = res;
                    self.clientResources = res;
                }).always(function () {
                    self.$store.commit('setWorkContext', data);
                }).done(function (p) {
                    self.isCompleted = true;
                });
                
                self.searchConditions = {
                    adultCount: self.adultCount,
                    childCount: self.childCount,
                    infantCount: self.infantCount
                }

                self.$store.commit('setWorkContext', data);
                self.enabledFlights = true;

                var checkInDate = data.packageQuery.checkIn != undefined ? data.packageQuery.checkIn : data.packageQuery.departureDate;
                var checkOutDate = data.packageQuery.checkOut != undefined ? data.packageQuery.checkOut : data.packageQuery.returnDate;
                var key = Vue.moment(checkInDate).format('YYYYMMDD') + "-" + Vue.moment(checkOutDate).format('YYYYMMDD');
                self.createPingRequest(key);
                self.setupSessionTimeout(data.packageQuery.ttl);

                if (jQuery().fotorama) {
                    console.log("Initialization fotorama");
                    $('.fotorama').fotorama();
                }

                // set default date
                var startDate = Vue.moment(self.model.departureDate).format('MM/DD/YYYY');
                var endDate = Vue.moment(self.model.returnDate).format('MM/DD/YYYY');

                self.defaultDate = startDate + ',' + endDate;
                self.defaultDateForMytrip = Vue.moment(self.model.checkIn).format('MM/DD/YYYY') + ',' + Vue.moment(self.model.checkOut).format('MM/DD/YYYY');
                $(".foo-copy-right").addClass('extra-padding');
            }).fail(function () {
                window.location.reload();
            });
            window.mapviewActionQueue = [];
            window.priceFac = function (h) {
                var price = self.totalPackagePrice(h);
                var paxCount = 0;
                for (var i = 0; i < h.availableRooms.length; i++) {
                    paxCount += h.availableRooms[i].adults;
                    paxCount += h.availableRooms[i].children;
                }
                var displayPrice = self.$store.state.workContext.product.displayPrice;
                var nightCount = self.calculateNights();

                if (displayPrice == 0) {
                    var formatPrice = (parseFloat(price.replace(",", "")) / nightCount).toFixed(self.packageQuery.currencyDecimals);
                }
                if (displayPrice == 1) {
                    var formatPrice = (parseFloat(price.replace(",", "")) / paxCount).toFixed(self.packageQuery.currencyDecimals);
                }

                return self.packageQuery.currency + " " + formatPrice.replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            };

            var startDate = Vue.moment().format('MM/DD/YYYY');
            var endDate = Vue.moment().add(2, 'days').format('MM/DD/YYYY');

            this.defaultDate = startDate + ',' + endDate;
        },
        mounted() {
            $(window).on('scroll', function() {
                let btt = $(".back-to-top");
                if ($(window).scrollTop() > 200) btt.addClass('shown');
                else  btt.removeClass('shown');
            });
        },
        methods: {
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            backTop() {
                $('html,body').animate({
                    scrollTop: 0
                }, 'slow');
            },
            calculatePriceSummary(param) {
                if (param) {
                    if (typeof param != 'object') {
                        this.priceSummary = {
                            adultPrice: ((param + this.totalFlightPrice()) / this.calculatePaxCount),
                            totalPrice: param + this.totalFlightPrice()
                        };
                    } else {
                        let flightPrice = param.solutionPrice;
                        this.priceSummary = {
                            adultPrice: flightPrice / this.calculatePaxCount,
                            totalPrice: flightPrice
                        };
                    }
                }
            },
            onShowPriceSummaryPaneFlight(flight) {
                this.calculatePriceSummary(flight);
            },
            getHotelDetailUrl(baseUrl) {
                var href = baseUrl;
                var indexOfMask = baseUrl.indexOf("?");
                if (indexOfMask > -1) {
                    href += "&";
                } else {
                    href += "?";
                }
                if (this.flightStore.outboundFlight != null) {
                    href += "outboundFlightId=" + this.flightStore.outboundFlight.id;

                    if (this.flightStore.inboundFlight != null) {
                        href += "&inboundFlightId=" + this.flightStore.inboundFlight.id;
                    }
                }
                return href;
            },
            gotoHotelInfoPage(baseUrl) {
                window.open(this.getHotelDetailUrl(baseUrl), '_blank');
            },
            syncTabs(e) {
                var $this = $(e.target);
                var href = $this.attr('href');
                href = href ? href : $this.parents(".item-tabs-header").attr('href');
                href = $('.nav-tabs .fh-tabs__item[href="' + href + '"]');
                if (typeof href !== 'undefined' && href.length > 0) {
                    href.tab('show');
                }
            },
            getMinPrice() {
                var self = this;
                self.cheapestFlightPrice = 0;
                if (self.cheapestFlights.outbound) {
                    self.cheapestFlightPrice += self.cheapestFlights.outbound.totalPrice;
                }

                if (self.cheapestFlights.inbound) {
                    self.cheapestFlightPrice += self.cheapestFlights.inbound.totalPrice;
                }
                self.cheapestFlightPrice = (self.cheapestFlightPrice.toFixed(self.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            validateInput(context) {
                var parent = context.parents('.box-search');
                var label = parent.find(">strong");
                var labelVals = {
                    old: context.attr('data-label'),
                    new: context.attr('data-required-message')
                };

                if (!context.val()) {
                    parent.addClass('error');
                    label.text(labelVals.new);
                    return false;
                } else {
                    parent.removeClass('error');
                    label.text(labelVals.old);
                }
                return true;
            },
            onChangeDate(e) {
                var self = this;
                var box = $(self.$el);
                var departureDate = box.find("input[name = 'DepartureDate']").val();
                var returnDate = box.find("input[name = 'ReturnDate']").val();
                if (departureDate && returnDate) {
                    self.model.departureDate = Vue.moment(departureDate).format('MM/DD/YYYY');
                    self.model.returnDate = Vue.moment(returnDate).format('MM/DD/YYYY');
                }
            },
            onValidate(e) {
                var self = this;
                var box = $(self.$el)
                var errors = 0;
                box.find("input[name='From']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                box.find("input[name='To']").each(function () {
                    var $this = $(this);
                    if (!self.validateInput($this)) errors++;
                });
                if (errors == 0) {
                    return true;
                }
                if (e) e.preventDefault();
            },
            getFlightFilters(packageId) {
                var self = this;
                $.ajax({
                    url: "/package/get-flight-filters",
                    data: {
                        packageId: packageId
                    },
                    type: "POST",
                    success: function (data) {
                        if (data.outboundAirlines)
                            self.flightStore.outboundAggreation.airlines = Object.keys(data.outboundAirlines).map(function (x) { return { key: x, value: data.outboundAirlines[x], selected: false }; });

                        if (data.inboundAirlines)
                          self.flightStore.inboundAggreation.airlines = Object.keys(data.inboundAirlines).map(function (x) { return { key: x, value: data.inboundAirlines[x], selected: false }; });

                        if (self.packageQuery.journeyType) {
                            if (self.cheapestFlights.outbound && self.cheapestFlights.inbound) {
                                self.getMinPrice();
                            }
                        } else {
                            if (self.cheapestFlights.outbound) {
                                self.getMinPrice();
                            }
                        }
                    }
                })
            },
            sortDicByValue(object) {
                var sorted = [];
                var listAirports = [];
                for (var key in object) {
                    if (object[key] == null) {
                        object[key] = key;
                    }
                }
                var listValue = Object.values(object);
                listValue.sort();

                for (var i = 0; i < listValue.length; i++) {
                    for (var k in object) {
                        if (object[k] == listValue[i]) {
                            listAirports.push(
                                {
                                    key: k,
                                    value: listValue[i]
                                }
                            )
                        }
                    }
                }
                return listAirports;
            },
            createPingRequest: function (key) {
                var self = this;

                if (self.hasErrorMessage || self.abortPing) {
                    // Ping in 60 seconds only
                    return;
                }

                var productTypes = [];

                // Flight
                if (self.enabledFlights) {
                    self.enabledFlights = true;
                    productTypes.push({
                        productType: 1,
                        storedKey: ''
                    });
                }

                var baseUrl = "/package/product-status/" + self.packageQuery.id;

                $.post(baseUrl, {
                    productTypeStatuses: productTypes
                }, function (data) {
                    if (data.length > 0) {

                        if (data.some(x => x.status == 3)) {
                            window.location = '/package/restart-search/' + self.packageQuery.id;
                        }

                        var completed = data.every(x => x.status == 1);
                        var haveErrors = data.some(x => x.status == 2);

                        if (haveErrors) {
                            self.notifyErrorMessage(data.find(x => x.status == 2).message);
                        } else {
                            var item = data[0];
                            if (item.status === 1 || item.progress !== 0) {
                                switch (item.product) {
                                    case 1:
                                        if (item.status === 1) {
                                            if (!self.searchFlightsCompleted) {
                                                console.log("notifyFlightsCompleted");
                                                self.searchFlightsCompleted = true;
                                                self.getFlights(self.flightStore.outboundFilters, true);
                                                self.getFlightFilters(self.packageQuery.id);

                                                _.debounce(function () {
                                                    self.hideSplashScreen();
                                                }, 500)();
                                            }
                                        }
                                        else {
                                            var previous = self.previousStatus[item.product];
                                            var newData = item.progress > 0 && (!previous || previous.progress < item.progress);

                                            if (newData) {
                                                console.log("notifyNewFlights");
                                                self.getFlights(self.flightStore.outboundFilters, true);

                                                _.debounce(function () {
                                                    self.hideSplashScreen();
                                                }, 500)();
                                            }

                                            self.previousStatus[item.product] = item;
                                        }
                                        break;
                                }
                            }

                            if (completed) {
                                self.checkSearchComplete();
                            } else {
                                self.createPingRequest(key);
                            }
                        }
                    } else {
                        self.createPingRequest(key);
                    }
                });
            },
            checkSearchComplete() {
                if (!this.searchFlightsCompleted) {
                    return;
                }
                this.isSearchCompleted = true;
                this.$store.commit('setIsSearchCompleted');
                console.log("isSearchCompleted");
            },
            hideSplashScreen() {
                $('#loading-page').addClass('hidden');
                $('#app').removeClass('modal-open');
            },
            notifyErrorMessage(errorMessage) {
                var self = this;
                console.log("notifyErrorMessage: " + errorMessage);
                this.hasErrorMessage = true;
                this.errorMessage = errorMessage;

                if (typeof dataLayer != 'undefined') {
                    dataLayer.push({
                        'event': 'errorMessage',
                        'eventAction': 'productStatus',
                        'eventLabel': errorMessage
                    });
                };
                self.hideSplashScreen();
            },
            setupSessionTimeout(ttl) {
                // Server TTL is 30 mins, only allow browser TTL 20 mins
                var counter = ttl - 600;
                var pingCount = 0;
                var packageId = this.packageQuery.id;
                var self = this;
                setInterval(function () {
                    counter = counter - 1;
                    pingCount++;

                    if (pingCount >= 60 && !self.abortPing) {
                        self.abortPing = true;
                    }

                    if (counter <= 0) {
                        //window.location = '/package/start-over/' + packageId;
                    }
                }, 1000);
            },
            getFlights(filters, isSearch = false) {
                var self = this;
                self.errorMessage = "";
                self.loading.flightPagination = true;
                $.ajax({
                    url: "/package/get-flights",
                    data: filters,
                    type: "POST",
                    success: function (data) {
                        if (!data.flights || data.flights.length == 0) {
                            self.errorMessage = data.errorMessage;
                            if (isSearch) self.notifyErrorMessage(data.errorMessage);
                            if (self.showOutboundFlights) {
                                self.flightStore.outboundFlights = data.flights;
                                self.flightStore.outboundAggreation.totalFlights = 0;
                                self.flightStore.outboundAggreation.totalPages = 0;
                            }
                            else {
                                self.flightStore.inboundFlights = data.flights;
                                self.flightStore.inboundAggreation.totalFlights = 0;
                                self.flightStore.inboundAggreation.totalPages = 0;
                            }

                            return;
                        }

                        var totalPages = 0;
                        var pageSize = filters.direction == 'OutBound' ? self.flightStore.outboundFilters.pageSize : self.flightStore.inboundFilters.pageSize;
                        if (data.totalFlights % pageSize === 0) {
                            totalPages = data.totalFlights / pageSize;
                        } else {
                            totalPages = parseInt(data.totalFlights / pageSize) + 1;
                        }

                        if (filters.direction == 'OutBound') {
                            if (filters.pageIndex > 1) {
                                self.flightStore.outboundFlights.push(...data.flights);
                            } else {
                                self.flightStore.outboundFlights = data.flights;
                            }
                            self.flightStore.outboundAggreation.totalFlights = data.totalFlights;
                            self.flightStore.outboundAggreation.totalPages = totalPages;

                            // Select cheapest flight
                            if (!self.flightStore.outboundFlight) {
                                if (!self.flightStore.outboundFlightId) {
                                    self.flightStore.outboundFlight = data.flights.sort(function (x, y) {
                                        return x.solutionPrice - y.solutionPrice;
                                    })[0];
                                } else {
                                    self.flightStore.outboundFlight = data.flights.find(function (x) {
                                        return x.id === self.flightStore.outboundFlightId;
                                    });


                                }

                                if (self.packageQuery.journeyType === 1 && self.flightStore.outboundFlight) {
                                    self.flightStore.inboundFilters.outboundFilter = { flightKey: self.flightStore.outboundFlight.key };
                                    self.getFlights(self.flightStore.inboundFilters);
                                }
                            }

                            self.cheapestFlights.outbound = data.flights[0];
                        }
                        else {
                            if (filters.pageIndex > 1) {
                                self.flightStore.inboundFlights.push(...data.flights);
                            } else {
                                self.flightStore.inboundFlights = data.flights;
                            }
                            
                            self.flightStore.inboundAggreation.totalFlights = data.totalFlights;
                            self.flightStore.inboundAggreation.totalPages = totalPages;

                            // Select cheapest flight
                            if (!self.flightStore.inboundFlight) {

                                if (!self.flightStore.inboundFlightId) {
                                    self.flightStore.inboundFlight = data.flights.sort(function (x, y) {
                                        return x.solutionPrice - y.solutionPrice;
                                    }).find(function (x) {
                                        return x.direction === 1;
                                    });
                                } else {
                                    self.flightStore.inboundFlight = data.flights.find(function (x) {
                                        return x.id == self.flightStore.inboundFlightId;
                                    });
                                }
                            }
                            self.cheapestFlights.inbound = data.flights[0];
                        }

                        if (self.packageQuery.journeyType) {
                            if (self.cheapestFlights.outbound && self.cheapestFlights.inbound && filters.sortBy === "SolutionPrice" && !filters.sortByDesc) {
                                self.getMinPrice(function() {
                                    self.hideSplashScreen();
                                });
                            }
                        } else {
                            if (self.cheapestFlights.outbound && filters.sortBy === "SolutionPrice" && !filters.sortByDesc) {
                                self.getMinPrice(function() {
                                    self.hideSplashScreen();
                                });
                            }
                        }
                        
                        self.showProgressBar = false;
                        self.loading.flightDetails = true;
                        self.flightLoadCompleted = true;
                        self.flightErrorMessage = null;
                        self.loading.flightPagination = false;
                    },
                    error: function () {
                        self.hasErrorMessage = true;
                    }
                });
            },
            totalFlightPrice() {
                var price = 0;
                if (this.flightStore.outboundFlight)
                    price += this.flightStore.outboundFlight.solutionPrice;
                if (this.flightStore.inboundFlight) {
                    var priceChanged = this.flightStore.inboundFlight.solutionPrice - this.flightStore.outboundFlight.solutionPrice;
                    if (priceChanged != 0)
                        price += priceChanged;
                }

                return price;
            },
            toggleMapView() {
                if (!this.enabledMapView) {
                    return;
                }

                this.showMapView = !this.showMapView;

                if (this.showMapView) {
                    this.renderMap();
                } else {
                    this.showMapFull = false;
                }
            },
            toggleFilter() {
                $("#filterPanelResult .filter-body").toggleClass('is-open');
            },
            clearSelection(fieldName, event) {
                event.preventDefault();
                $(fieldName).trigger('click');
                return false;
            },
            isInt(value) {
                return !isNaN(value) && (function (x) {
                    return (x | 0) === x;
                })(parseFloat(value))
            },
            clearStars(star, event) {
                event.preventDefault();
                $("#" + star + "star").trigger('click');
                return false;
            },
            calculateNights() {
                var oneDay = 24 * 60 * 60 * 1000;
                var returnDate = Date.parse(this.packageQuery.returnDate);
                var departureDate = Date.parse(this.packageQuery.departureDate);
                var nights = Math.round(Math.abs((returnDate - departureDate) / (oneDay)));
                return nights;
            },
            submitForm() {
                if (this.model.from == this.model.to) {
                    $('#notifySelectDestination').modal('toggle');
                } else {
                    $('#fFlightHotelSearch').submit();
                }
            },
            onFlightChanged(flight) {
                var self = this;
                if (flight.direction == 0) {
                    self.flightStore.outboundFlight = flight;

                    if (self.packageQuery.journeyType == 0) {
                        setTimeout(function () {
                            self.onBookingNow();
                        }, 100);
                    } else {
                        self.flightStore.inboundFlight = null;
                        self.flightStore.inboundFlights = [];

                        self.showOutboundFlights = false;
                        self.flightStore.inboundFilters.pageIndex = 1;
                        self.flightStore.inboundFilters.outboundFilter = { flightKey: flight.key };
                        self.flightStore.inboundAggreation.airlines.forEach(function (x) {
                            x.selected = false;
                        });
                        self.getFlights(self.flightStore.inboundFilters);
                    }

                } else {
                    self.flightStore.inboundFlight = flight;
                    setTimeout(function () {
                        self.onBookingNow();
                    }, 100);
                }
            },
            formatPrice(price) {
                return (price.toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',')
            },
            removeFilters(obj) {
                this.removeFilter(obj.event, obj.field);
            },
            togglePane(obj) {
                if (!obj.isClosed) $(obj.element).toggleClass('is-open').promise().done(function () {
                    if ($(obj.element).hasClass('is-open')) {
                        $('.sidebar-overlay').addClass('is-active');
                        $('body').addClass('modal-open');
                    } else {
                        $('.sidebar-overlay').removeClass('is-active');
                        $('body').removeClass('modal-open');
                    }
                });
                else {
                    $(obj.element).removeClass('is-open').promise().done(function () {
                        $('.sidebar-overlay').removeClass('is-active');
                        $('body').removeClass('modal-open');
                    });
                }
            },
            onFlightPaginationChanged(pageIndex) {
                if (this.showOutboundFlights) {
                    this.flightStore.outboundFilters.pageIndex = pageIndex;
                    this.getFlights(this.flightStore.outboundFilters);
                }
                else {
                    this.flightStore.inboundFilters.pageIndex = pageIndex;
                    this.getFlights(this.flightStore.inboundFilters);
                }
            },
            sortFlights(options) {
                if (this.showOutboundFlights) {
                    this.flightStore.outboundFilters.pageIndex = 1;
                    this.flightStore.outboundFilters.sortBy = options.newSortBy;
                    this.flightStore.outboundFilters.sortByDesc = options.newSortByDesc;
                    this.getFlights(this.flightStore.outboundFilters);
                }
                else {
                    this.flightStore.inboundFilters.pageIndex = 1;
                    this.flightStore.inboundFilters.sortBy = options.newSortBy;
                    this.flightStore.inboundFilters.sortByDesc = options.newSortByDesc;
                    this.getFlights(this.flightStore.inboundFilters);
                }
            },
            filterByAirlines(airlines) {
                if (this.showOutboundFlights) {
                    var airlines = this.flightStore.outboundAggreation.airlines.filter(x => x.selected == true).map(x => x.key);

                    if (!this.flightStore.outboundFilters.outboundFilter) {
                        this.flightStore.outboundFilters.outboundFilter = {};
                    }

                    this.flightStore.outboundFilters.pageIndex = 1;
                    this.flightStore.outboundFilters.outboundFilter.airlineCodes = airlines;
                    this.getFlights(this.flightStore.outboundFilters);
                }
                else {
                    var airlines = this.flightStore.inboundAggreation.airlines.filter(x => x.selected == true).map(x => x.key);

                    if (!this.flightStore.inboundFilters.inboundFilter) {
                        this.flightStore.inboundFilters.inboundFilter = {};
                    }

                    this.flightStore.inboundFilters.pageIndex = 1;
                    this.flightStore.inboundFilters.inboundFilter.airlineCodes = airlines;
                    this.getFlights(this.flightStore.inboundFilters);
                }
            },
            filterByNumberOfStops() {
                var stops = [];
                if (this.showOutboundFlights) {

                    if (this.flightStore.outboundAggreation.nonStop == false || this.flightStore.outboundAggreation.oneStop == false || this.flightStore.outboundAggreation.hasStops == false) {
                        if (this.flightStore.outboundAggreation.nonStop) {
                            stops.push("0");
                        }

                        if (this.flightStore.outboundAggreation.oneStop) {
                            stops.push("1");
                        }

                        if (this.flightStore.outboundAggreation.hasStops) {
                            stops.push("2,3,4,5");
                        }
                    }

                    if (!this.flightStore.outboundFilters.outboundFilter) {
                        this.flightStore.outboundFilters.outboundFilter = {};
                    }

                    this.flightStore.outboundFilters.pageIndex = 1;
                    this.flightStore.outboundFilters.outboundFilter.stops = stops.join(",");
                    this.getFlights(this.flightStore.outboundFilters);
                }
                else {

                    if (this.flightStore.inboundAggreation.nonStop == false || this.flightStore.inboundAggreation.oneStop == false || this.flightStore.inboundAggreation.hasStops == false) {
                        if (this.flightStore.inboundAggreation.nonStop) {
                            stops.push("0");
                        }

                        if (this.flightStore.inboundAggreation.oneStop) {
                            stops.push("1");
                        }

                        if (this.flightStore.inboundAggreation.hasStops) {
                            stops.push("2,3,4,5");
                        }
                    }

                    if (!this.flightStore.inboundFilters.inboundFilter) {
                        this.flightStore.inboundFilters.inboundFilter = {};
                    }

                    this.flightStore.inboundFilters.pageIndex = 1;
                    this.flightStore.inboundFilters.inboundFilter.stops = stops.join(",");
                    this.getFlights(this.flightStore.inboundFilters);
                }
            },
            onDepartureTimesChanged(times) {
                if (this.showOutboundFlights) {
                    if (!this.flightStore.outboundFilters.outboundFilter) {
                        this.flightStore.outboundFilters.outboundFilter = {};
                    }

                    this.flightStore.outboundFilters.pageIndex = 1;
                    this.flightStore.outboundFilters.outboundFilter.minDepartureTime = times.min;
                    this.flightStore.outboundFilters.outboundFilter.maxDepartureTime = times.max;
                    this.getFlights(this.flightStore.outboundFilters);
                }
                else {
                    if (!this.flightStore.inboundFilters.inboundFilter) {
                        this.flightStore.inboundFilters.inboundFilter = {};
                    }

                    this.flightStore.inboundFilters.pageIndex = 1;
                    this.flightStore.inboundFilters.inboundFilter.minDepartureTime = times.min;
                    this.flightStore.inboundFilters.inboundFilter.maxDepartureTime = times.max;
                    this.getFlights(this.flightStore.inboundFilters);
                }
            },
            onArrivalTimesChanged(times) {
                if (this.showOutboundFlights) {
                    if (!this.flightStore.outboundFilters.outboundFilter) {
                        this.flightStore.outboundFilters.outboundFilter = {};
                    }

                    this.flightStore.outboundFilters.pageIndex = 1;
                    this.flightStore.outboundFilters.outboundFilter.minArrivalTime = times.min;
                    this.flightStore.outboundFilters.outboundFilter.maxArrivalTime = times.max;
                    this.getFlights(this.flightStore.outboundFilters);
                }
                else {
                    if (!this.flightStore.inboundFilters.inboundFilter) {
                        this.flightStore.inboundFilters.inboundFilter = {};
                    }

                    this.flightStore.inboundFilters.pageIndex = 1;
                    this.flightStore.inboundFilters.inboundFilter.minArrivalTime = times.min;
                    this.flightStore.inboundFilters.inboundFilter.maxArrivalTime = times.max;
                    this.getFlights(this.flightStore.inboundFilters);
                }
            },
            resetFilters() {
                this.flightStore.inboundFilters = {
                    direction: 'InBound',
                    pageIndex: 1,
                    pageSize: 10,
                    sortBy: "SolutionPrice",
                    sortByDesc: false,
                    inboundFilter: {
                        minDepartureTime: "00:00",
                        maxDepartureTime: "24:00",
                        minArrivalTime: "00:00",
                        maxArrivalTime: "24:00"
                    },
                    packageId: this.packageQuery.id
                };
                this.flightStore.inboundAggreation.airlines.forEach(function (x) {
                    x.selected = false;
                });
                this.flightStore.inboundAggreation.hasStops = false;
                this.flightStore.inboundAggreation.nonStop = false;

                this.flightStore.outboundFilters = {
                    direction: 'OutBound',
                    pageIndex: 1,
                    pageSize: 10,
                    sortBy: "SolutionPrice",
                    sortByDesc: false,
                    outboundFilter: {
                        minDepartureTime: "00:00",
                        maxDepartureTime: "24:00",
                        minArrivalTime: "00:00",
                        maxArrivalTime: "24:00"
                    },
                    packageId: this.packageQuery.id
                };
                this.flightStore.outboundAggreation.airlines.forEach(function (x) {
                    x.selected = false;
                });
                this.flightStore.outboundAggreation.hasStops = false;
                this.flightStore.outboundAggreation.nonStop = false;
            },
            clearOutbound() {
                this.showOutboundFlights = true;
                this.resetFilters();
                this.getFlights(this.flightStore.outboundFilters);
            },
            formatPrice(price) {
                return (price.toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',')
            },
            bookingNow() {
                var data = {};
                data.packageId = this.packageQuery.id;

                if (this.flightStore.outboundFlight != null) {
                    data.outboundFlightId = this.flightStore.outboundFlight.id;
                }

                if (this.flightStore.inboundFlight != null) {
                    data.inboundFlightId = this.flightStore.inboundFlight.id;
                }

                var self = this;

                $.ajax('/package/do-booking-agoda', {
                    traditional: true,
                    data: data,
                    type: "POST",
                    success: function (data) {
                        if (data.success) {
                            window.location = data.redirectUrl;
                        }

                        if (data.message) {
                            // alert("oops! we are sorry, the fare you selected is no longer available, please select a different flight option.");
                            alert(data.message);
                            self.splashScreen(false);
                        }
                    },
                    error: function () {
                        self.splashScreen(false);
                    }
                });
            },
            onBookingNow() {
                var self = this;

                this.splashScreen(true);

                setTimeout(function () {
                    self.bookingNow();
                }, 100);

            },
            splashScreen(isShow) {
                if (isShow) {
                    $('#loading-page-2').removeClass('hidden');

                    setTimeout(function () {
                        $('#app').addClass('modal-open');
                    }, 300);
                } else {
                    setTimeout(function () {
                        $('#loading-page-2').addClass('hidden');
                        $('#app').removeClass('modal-open');
                    }, 300);
                }
            },
            formatDate(currentDate, dateFormat) {
                if (!currentDate) return false;
                return moment.utc(currentDate).format(dateFormat);
            },
        },
        watch: {
            cheapestFlightPrice(val) { 
                let self = this;
                if (val) {
                    var previousSearches = Cookie.getJSON('recentSearches') || [];
                    if (previousSearches.length > 0) previousSearches = previousSearches.filter(pre => {
                        return pre.fromCode !== self.packageQuery.from || pre.toCode !== self.packageQuery.to || pre.departureDate !== self.packageQuery.departureDate || pre.returnDate !== self.packageQuery.returnDate || pre.passengers !== self.calculatePaxCount
                    });
                    if (previousSearches.length > 3) {
                        previousSearches.splice(0, 1);
                    }
                    previousSearches.push({
                        id: self.packageQuery.productId,
                        from: self.packageQuery.fromCityName,
                        fromCode: self.packageQuery.from,
                        to: self.packageQuery.toCityName,
                        toCode: self.packageQuery.to,
                        thumbnail: self.cheapestFlights.outbound ? ('https://gqcdn.s3.amazonaws.com/airline-logos/svg/' + self.cheapestFlights.outbound.airlineCode + '.svg') : self.baseUrl + '/images/images-default.jpg',
                        product: self.product.type,
                        departureDate: self.packageQuery.departureDate,
                        returnDate: self.packageQuery.returnDate,
                        passengers: self.calculatePaxCount,
                        price: self.cheapestFlightPrice,
                        url: self.packageQuery.requestUrl,
                        currency: self.packageQuery.currency,
                        journeyType: self.packageQuery.journeyType ? 'Return' : 'One-way'
                    });
                    Cookie.set('recentSearches', previousSearches, {expires: 1});
                    // console.log(Cookie.getJSON('recentSearches'));
                }
            },
            hasErrorMessage(value) {
                if (value)
                    $("#modalChangeDate").modal("hide")
            }
        }
    }
</script>
