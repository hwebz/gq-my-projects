﻿<template>
    <div class="col-lg-9">
        <div class="avai-flight">
            <div class="fh-tabs__selected-flight" v-if="flightStore.outboundFlight && direction != '0'">
                <div class="fh-tabs__selected-flight-thumb">
                    <div class="multi-flights">
                        <img :src="'https://gqcdn.s3.amazonaws.com/airline-logos/svg/' + flightStore.outboundFlight.legs[0].airlineCode + '.svg'" :alt="flightStore.outboundFlight.legs[0].airlineCode" />
                        <img v-for="(leg, legIndex) in flightStore.outboundFlight.legs" :src="'https://gqcdn.s3.amazonaws.com/airline-logos/svg/' + leg.airlineCode + '.svg'" :alt="leg.airlineCode" v-if="legIndex > 0 && leg.airlineCode !== flightStore.outboundFlight.legs[0].airlineCode" />
                    </div>
                    <div class="flight-info">
                        <template v-for="leg in flightStore.outboundFlight.legs">
                            <small><strong>{{leg.airlineName}}</strong> - {{leg.airlineCode}}{{leg.flightNumber}}</small>
                        </template>
                    </div>
                </div>
                <div class="fh-tabs__selected-flight-date">
                    <p>{{formatDate(flightStore.outboundFlight.departureDate, "ddd, MMM DD YYYY")}}</p>
                </div>
                <div class="fh-tabs__selected-flight-times">
                    <h5>
                        <strong>
                            {{formatDate(flightStore.outboundFlight.departureDate, 'HH:mm')}}
                        </strong>
                        <div class="line-time__direction">
                            <small>{{getDurationTime(flightStore.outboundFlight)}}</small>
                            <div class="ico-flight flight-depart">
                                <i class="icon-flight"></i>
                            </div>
                            <small v-if="flightStore.outboundFlight.stops == 0" v-lang.NONSTOP_LOWER></small>
                            <small v-if="flightStore.outboundFlight.stops == 1" v-lang.ONE_STOP_LOWER></small>
                            <small v-if="flightStore.outboundFlight.stops > 1" v-lang.ONE_PLUS_STOP_LOWER></small>
                            <small v-if="flightStore.outboundFlight.stops >= 1">
                                (<span v-lang.VIA></span> <template v-for="(leg, legIdx) in flightStore.outboundFlight.legs" v-if="legIdx < flightStore.outboundFlight.legs.length - 1">{{leg.arrivalAirportCode}}{{legIdx < flightStore.outboundFlight.legs.length - 2 ? ', ' : ''}}</template>)
                            </small>
                        </div>
                        <strong>
                            {{formatDate(flightStore.outboundFlight.arrivalDate, 'HH:mm')}}
                            <sup v-if="isNextDay(flightStore.outboundFlight) > 0">+{{isNextDay(flightStore.outboundFlight)}}</sup>
                        </strong>
                    </h5>
                </div>
                <div class="fh-tabs__selected-flight-btn">
                    <button class="btn btn-primary btn-effect" @click.prevent="clearOutbound" v-lang.CHANGE></button>
                </div>
            </div>
            <div class="fh-tabs__title">
                <h4 v-if="direction == '0'">
                    <template v-if="packageQuery.journeyType">
                        <span v-lang.OUTBOUND_FLIGHT></span>
                        <small> {{formatDate(packageQuery.departureDate, 'MMM DD, YYYY')}}</small>
                    </template>
                    <template v-else>
                        <span v-lang.ONE_WAY_FLIGHT></span>
                        <small> {{formatDate(packageQuery.departureDate, 'MMM DD, YYYY')}}</small>
                    </template>
                </h4>
                <h4 v-else><span v-lang.INBOUND_FLIGHT></span> <small> {{formatDate(packageQuery.returnDate, 'MMM DD, YYYY')}}</small></h4>
                <div class="fh-tabs__right-info">
                    <p v-lang.ALL_FLIGHT_TIMES_ARE_LOCAL_TIME></p>
                    <p v-if="packageQuery.journeyType" v-lang.PRICE_FOR_ROUNDTRIP_NOTE></p>
                    <p v-else v-lang.PRICE_FOR_ONE_WAY_NOTE></p>
                </div>
                <div class="fh-tabs__utils">
                    <p v-if="direction === '0'">
                        <span v-if="flightLoadCompleted" v-lang.X_FLIGHTS_FOUND="{0: flightStore.outboundAggreation.totalFlights}">
                        </span>
                        <span v-else v-lang.LOADING_FLIGHTS>
                            
                        </span>
                    </p>
                    <p v-else v-lang.X_FLIGHTS_FOUND="{0: flightStore.inboundAggreation.totalFlights}">
                    </p>
                    <div class="fh-tabs__sort">
                        <div class="mtr-input">
                            <select class="mtr-ipt" @change="changeSortBy" v-model="sortOrderBy">
                                <option value="SolutionPrice;ASC" v-lang.PRICE_LOWEST></option>
                                <option value="SolutionPrice;DESC" v-lang.PRICE_HIGHEST></option>
                                <option value="Duration;ASC" v-lang.DURATION_SHORTEST></option>
                                <option value="Duration;DESC" v-lang.DURATION_LONGEST></option>
                                <option value="DepartureTime;ASC" v-lang.DEPARTURE_TIME_EARLIEST></option>
                                <option value="DepartureTime;DESC" v-lang.DEPARTURE_TIME_LATEST></option>
                                <option value="ArrivalTime;ASC" v-lang.ARRIVAL_TIME_EARLIEST></option>
                                <option value="ArrivalTime;DESC" v-lang.ARRIVAL_TIME_LATEST></option>
                            </select>
                            <span class="mtr-bar"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div v-if="flightLoadCompleted">
                <div v-if="(!errorMessage || errorMessage == '') && flights.length > 0">
                    <div v-for="(flight, fIndex) in flights" :key="fIndex">
                        <div class="fh-tabs__overview">
                            <div class="fh-tabs__item fh-tabs__flight">
                                <div class="flight-way__tabs">
                                    <div class="flight-way__view">
                                        <div class="line-way">
                                            <div class="line-brand">
                                                <div class="line-brand__avartar multi-flights">
                                                    <img :src="'https://gqcdn.s3.amazonaws.com/airline-logos/svg/' + flight.legs[0].airlineCode + '.svg'" :alt="flight.legs[0].airlineCode" />
                                                    <img v-for="(leg, legIndex) in flight.legs" :src="'https://gqcdn.s3.amazonaws.com/airline-logos/svg/' + leg.airlineCode + '.svg'" :alt="leg.airlineCode" v-if="legIndex > 0 && leg.airlineCode !== flight.legs[0].airlineCode" />
                                                </div>
                                            </div>
                                            <div class="line-time">
                                                <div class="line-time__time">
                                                    <strong>{{formatDate(flight.departureDate, "HH:mm")}}</strong>
                                                    <span>{{flight.departureAirportCode}}</span>
                                                </div>
                                                <div class="line-time__direction">
                                                    <small>{{getDurationTime(flight)}}</small>
                                                    <div class="ico-flight flight-depart">
                                                        <i class="icon-flight"></i>
                                                    </div>
                                                    <small v-show="flight.stops === 0" v-lang.NONSTOP_LOWER></small>
                                                    <small v-show="flight.stops === 1" v-lang.ONE_STOP_LOWER></small>
                                                    <small v-show="flight.stops > 1" v-lang.ONE_PLUS_STOP_LOWER></small> 
                                                    <small v-show="flight.stops >= 1">
                                                        (<span v-lang.VIA></span>
                                                        <template v-for="(leg, legIdx) in flight.legs" v-if="legIdx < flight.legs.length - 1"> {{leg.arrivalAirportCode}}{{legIdx < flight.legs.length - 2 ? ', ' : ''}}</template>)
                                                    </small>
                                                    <!--<small v-for="leg in flight.legs">-->
                                                    <!--<i class="icon icon-flight"></i>-->
                                                    <!--{{leg.airlineName}} - {{leg.airlineCode}}{{leg.flightNumber}}: {{leg.cabinClass}}{{leg.airType ? ', ' + leg.airType : ''}}-->
                                                    <!--</small>-->
                                                </div>
                                                <div class="line-time__time">
                                                    <strong>
                                                        {{formatDate(flight.arrivalDate, "HH:mm")}}
                                                        <sup v-if="isNextDay(flight) > 0">+{{isNextDay(flight)}}</sup>
                                                    </strong>
                                                    <span>{{flight.arrivalAirportCode }}</span>
                                                </div>
                                            </div>
                                            <div class="line-control">
                                                <a class="btn btn-sm btn-link" href="#modalFlightAvaiDetail" data-toggle="modal" @click.prevent="onFlightDetailShown($event, flight)">
                                                    <span v-lang.DETAIL></span>
                                                    <i class="icon-information"></i>
                                                </a>
                                                <div class="line-descrip">
                                                    <span v-lang.HAND_LUGGAGE_INCLUDED></span>
                                                    <span class="cabinClass" :class="{'economy': flight.cabinClass === '1', 'business': flight.cabinClass === '2', 'first': flight.cabinClass === '3', 'premium': flight.cabinClass === '4'}" v-if="flight.legs[0]">{{translateText(flight.legs[0].cabinClass.toUpperCase(), flight.legs[0].cabinClass)}} <span v-lang.CLASS v-show="flight.legs[0].cabinClass != 'First Class'"></span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="red" v-if="(flight.direction == '0' && (flight.departureAirportCode != packageQuery.from || flight.arrivalAirportCode != packageQuery.to)) || (flight.direction == '1' && (flight.departureAirportCode != packageQuery.to || flight.arrivalAirportCode != packageQuery.from))">
                                            <small v-lang.PLAN_AHEAD></small>
                                        </div>
                                        <div class="yellow" v-if="flight.legs.length > 1">
                                            <small>
                                                <span v-lang.YOU_HAVE_TO_WAIT_FOR_NEXT_FLIGHT></span>
                                                <template v-for="(leg, legIndex) in flight.legs" v-if="legIndex < flight.legs.length - 1">
                                                    {{leg.arrivalCityName}} <span v-lang.FOR_LOWER></span> {{getTransitTime(leg.arrivalDate, flight.legs[legIndex + 1].departureDate)}}
                                                    <template v-if="legIndex > 0">, <span v-lang.AFTER_THAT_IN></span> {{leg.arrivalCityName}} for {{getTransitTime(leg.arrivalDate, flight.legs[legIndex + 1].departureDate)}}</template>
                                                </template>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="fh-tabs__item fh-tabs__control">
                                <div class="loading-price " :class="{'loading-price--active': flightAggreation.airlines.length > 0 | flightLoadCompleted}">
                                    <div class="load load__bar load__bar--active">
                                        <div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                    <span class="loading-price--first" v-lang.LOADING_PRICE></span>
                                    <span class="loading-price--second" v-lang.CALCULATING_PRICE></span>
                                    <span class="loading-price--third" v-lang.HOLD_ON_A_BIT></span>
                                </div>
                                <div class="price">
                                    <div class="title-class" v-if="!isFlightOnly" v-lang.FLIGHT_HOTEL>FLIGHT + HOTEL</div>
                                    <div class="title-class" v-else v-lang.FLIGHT>FLIGHT</div>
                                    <template v-if="!isFlightOnly">
                                        <small class="text-uppercase" v-if="product.displayPrice == 0" v-lang.PER_NIGHT></small>
                                        <small class="text-uppercase" v-if="product.displayPrice == 1" v-lang.PER_PERSON></small>
                                        <small class="text-uppercase" v-if="product.displayPrice == 2" v-lang.PER_ROOM></small>
                                    </template>
                                    <span>{{packageQuery.currency}}</span>
                                    <strong v-if="!isFlightOnly">{{direction == '0' ? getAvgPrice(flight) : getAvgPriceChange(flight)}}</strong>
                                    <strong v-else>{{direction == '0' ? getPrice(flight) : getPriceChange(flight)}}</strong>
                                </div>
                                <div class="total-package-price" v-if="!isFlightOnly">
                                    <div class="title-class text-uppercase" v-lang.TOTAL_PACKAGE_PRICE></div>
                                    <div class="price">
                                        <span>{{packageQuery.currency}}</span>
                                        <strong>{{direction == '0' ? getPrice(flight) : getPriceChange(flight)}}</strong>
                                    </div>
                                </div>
                                <a class="link-small" href="#modalPriceBreakdown" data-toggle="modal" @click="showPriceSummaryPaneFlight(flight)" v-lang.PRICE_BREAKDOWN></a>
                                <template v-if="isFlightOnly">
                                    <a class="btn btn-block btn-outline-primary bt-effect"
                                       @click.prevent="changeFlights(flight)"
                                       href="javascript:void(0)" v-lang.SELECT></a>
                                </template>
                                <template v-else>
                                    <a v-if="direction == '0'" class="btn btn-block btn-outline-primary bt-effect"
                                       :class="{'bt-selected': flightStore.outboundFlight.id === flight.id}"
                                       @click.prevent="changeFlights(flight)"
                                       href="javascript:void(0)">
                                        <i class="icon-check" v-if="flightStore.outboundFlight.id === flight.id"></i>
                                        {{flightStore.outboundFlight.id === flight.id ? translateText('SELECTED', 'Selected') : translateText('SELECT', 'Select')}}
                                    </a>
                                    <a v-else class="btn btn-block btn-outline-primary bt-effect"
                                       :class="{'bt-selected': flightStore.inboundFlight.id === flight.id}"
                                       @click.prevent="changeFlights(flight)"
                                       href="javascript:void(0)">
                                        <i class="icon-check" v-if="flightStore.inboundFlight.id === flight.id"></i>
                                        {{flightStore.inboundFlight.id === flight.id ? translateText('SELECTED', 'Selected') : translateText('SELECT', 'Select')}}
                                    </a>
                                </template>
                            </div>
                        </div>
                    </div>
                    <div v-if="flights.length > 0">
                        <div class="paganition-wrap center">
                            <a class="item-paganition bt-effect"
                               :class="{'disabled': pageIndex >= flightAggreation.totalPages, 'bt-loading': loading.flightPagination}"
                               href="#"
                               @click.prevent="goToFlightPage('next')" v-lang.LOAD_MORE></a>
                        </div>
                    </div>

                </div>
                <div v-else class="no-hotel-available">
                    <div v-if="errorMessage">
                        <h3 v-lang.OOPS></h3>
                        <p v-lang.THERE_IS_NO_FLIGHT_AVAILABLE></p>
                    </div>
                </div>
            </div>
            <div v-else>
                <div class="fh-tabs__overview" v-for="n in 10" :key="n">
                    <div class="fh-tabs__item fh-tabs__flight">
                        <div class="flight-way__tabs">
                            <div class="flight-way__view">
                                <div class="flight-way__view">
                                    <div class="lda__wrap">
                                        <div class="lda">
                                            <div class="lda__bar"></div>
                                            <div class="lda__bar lda__bar--50"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="fh-tabs__item fh-tabs__control">
                        <div class="lda lda--fbot">
                            <div class="lda__bar lda__bar--50"></div>
                            <div class="lda__bar lda__bar--50"></div>
                            <div class="lda__bar lda__bar--two"></div>
                        </div>
                    </div>
                </div>
                <div class="paganition-wrap">
                    <div class="item-paganition lda__bar lda__bar--h60"></div>
                    <span class="count-page lda__bar"></span>
                    <div class="item-paganition lda__bar lda__bar--h60"></div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="modalFlightAvaiDetail" tabindex="-1" role="dialog" aria-hidden="true" v-if="selectedFlight">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body modal-body-gray npd">
                        <div class="flight-detail-title">
                            <strong v-lang.ITINERARY></strong>
                            <button class="modal-close" data-dismiss="modal">
                                <i class="icon-remove"></i>
                            </button>
                        </div>
                        <div class="flight-detail-main">
                            <div class="time-duration">
                                <div class="time">
                                    <strong v-lang.DEPARTURE></strong>:
                                    <span>{{formatDate(selectedFlight.departureDate, "dddd, DD MMMM")}}</span>
                                </div>
                                <div class="duration" v-if="parseInt(getDurationTime(selectedFlight)) > 0">
                                    <strong v-lang.DURATION></strong>:
                                    <span>{{getDurationTime(selectedFlight)}}</span>
                                </div>
                            </div>
                            <div class="list-detail" v-for="(leg, legIndex) in selectedFlight.legs" :key="legIndex">
                                <div class="list-block">
                                    <div class="title">
                                        <span v-lang.DEPARTURE></span>
                                    </div>
                                    <ul class="detail">
                                        <li>
                                            <b>{{formatDate(leg.departureDate, 'HH:mm')}}</b>
                                            <span>{{formatDate(leg.departureDate, 'dddd, DD MMM')}}</span>
                                            <span class="highlight-sv" v-if="leg.stationType == 1" v-lang.BUS_SERVICE>Bus Service</span>
                                            <span class="highlight-sv" v-if="leg.stationType == 2" v-lang.TRAIN_SERVICE>Train Service</span>
                                            <span class="highlight-sv" v-if="leg.stationType == 3" v-lang.FERRY_SERVICE>Ferry Service</span>
                                        </li>
                                        <li>
                                            <b v-if="!leg.stationType || leg.stationType == 0">{{leg.departureAirportName}}</b>
                                            <b v-else-if="leg.stationType == 1">{{leg.departureCityName}} {{leg.airlineCode}} <strong v-lang.BUS_STATION>Bus Station</strong></b>
                                            <b v-else-if="leg.stationType == 2">{{leg.departureCityName}} {{leg.airlineCode}} <strong v-lang.TRAIN_STATION>Train Station</strong></b>
                                            <b v-else>{{leg.departureCityName}} {{leg.airlineCode}} Ferry Port</b>
                                            <span>({{leg.departureAirportCode}}) {{leg.departureCityName}}</span>
                                        </li>
                                    </ul>
                                </div>
                                <div class="list-block">
                                    <div class="title">
                                        <span v-lang.ARRIVAL></span>:
                                    </div>
                                    <ul class="detail">
                                        <li>
                                            <b>{{formatDate(leg.arrivalDate, 'HH:mm')}}<sup v-if="leg.diffDates > 0">+{{leg.diffDates}}</sup></b>
                                            <span>{{formatDate(leg.arrivalDate, 'dddd, DD MMM')}}</span>
                                        </li>
                                        <li>
                                            <b>{{leg.arrivalAirportName}}</b>
                                            <span>({{leg.arrivalAirportCode}}) {{leg.arrivalCityName}}</span>
                                        </li>
                                    </ul>
                                </div>
                                <div class="name-brand">
                                    <div class="title"></div>
                                    <div class="detail">
                                        <div class="avartar">
                                            <img :src="'https://gqcdn.s3.amazonaws.com/airline-logos/svg/' + leg.airlineCode + '.svg'" :alt="leg.airlineCode" />
                                        </div>
                                        <b>
                                            {{leg.airlineName}}
                                            <span>{{leg.stationType == 1 ? 'BUS' : ''}} {{leg.airlineCode}}{{leg.flightNumber}}</span>
                                            <span v-if="leg.airType">Aircraft - {{leg.airType}}</span>
                                        </b>
                                        <span v-if="leg.bookingClass">{{translateText(leg.cabinClass.toUpperCase(), leg.cabinClass)}} ({{leg.bookingClass}})</span>
                                        <span v-else><span v-lang.CLASS></span> - {{translateText(leg.cabinClass.toUpperCase(), leg.cabinClass)}}</span>
                                        <div v-if="!leg.stationType || leg.stationType == 0" class="service-name"></div>
                                        <div v-else-if="leg.stationType == 1" class="service-name" v-lang.NOTE_THIS_IS_BUS_SERVICE>Note: This is Bus Service</div>
                                        <div v-else-if="leg.stationType == 2" class="service-name" v-lang.NOTE_THIS_IS_TRAIN_STATION>Note: This is Train Station</div>
                                        <div v-else class="service-name" v-lang.NOTE_THIS_IS_FERRY_PORT>Note: This is Ferry Port</div>
                                    </div>
                                </div>
                                <div class="list-block">
                                    <div class="title"><p v-lang.BAG_FEES>Bag fees:</p></div>
                                    <div class="detail">
                                        <p v-if="selectedFlight.baggageFeeLink" v-lang.BAGGAGE_FEES_MESSAGE1="{0: selectedFlight.baggageFeeLink, 1 : leg.airlineName}"></p>
                                        <p v-else v-lang.BAGGAGE_FEES_MESSAGE2="{0: leg.airlineName, 1: leg.airlineName}"></p>
                                    </div>
                                </div>
                                <div class="duration-check" v-if="selectedFlight.stops > 0 && legIndex < selectedFlight.legs.length - 1">
                                    <div class="title"></div>
                                    <div class="detail">
                                        <i><span v-lang.TRANSIT_DURATION></span>: {{getTransitTime(selectedFlight.legs[legIndex].arrivalDate, selectedFlight.legs[legIndex + 1].departureDate)}} in {{leg.arrivalCityName}}</i>
                                        <strong v-lang.CHECK_BOARDING_TIME></strong>
                                        <span>
                                            {{formatDate(selectedFlight.legs[legIndex].arrivalDate, 'HH:mm')}} {{formatDate(selectedFlight.legs[legIndex].arrivalDate, 'dddd, DD MMM')}}
                                            - {{formatDate(selectedFlight.legs[legIndex + 1].departureDate, 'HH:mm')}} {{formatDate(selectedFlight.legs[legIndex + 1].departureDate, 'dddd, DD MMM')}}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-primary bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Vue from 'vue';

    export default {
        props: ["flightStore", "flights", "flightAggreation", "direction", "loading", "flightLoadCompleted", "errorMessage", "isFlightOnly", "hotelSelected", "product"],
        data() {
            return {
                selectedFlight: null,
                sortOrderBy: "SolutionPrice;ASC",
                searchConditions: {
                    adultCount: 0,
                    childCount: 0,
                    infantCount: 0
                }
            };
        },
        computed: {
            packageQuery() {
                return this.$store.state.workContext.packageQuery;
            },
            calculatePaxCount() {
                return this.searchConditions.adultCount + this.searchConditions.childCount + this.searchConditions.infantCount;
            },
            adultCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                }
                return count;
            },
            childCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.childCount;
                }
                return count;
            },
            infantCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.infantCount;
                }
                return count;
            },
            pageIndex() {
                if (this.direction == 0) {
                    return this.flightStore.outboundFilters.pageIndex;
                }

                return this.flightStore.inboundFilters.pageIndex;
            }
        },
        created() {
            this.searchConditions = {
                adultCount: this.adultCount,
                childCount: this.childCount,
                infantCount: this.infantCount
            }
        },
        methods: {
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            showPriceSummaryPaneFlight(flight) {
                this.$emit('onShowPriceSummaryPaneFlight', flight);
            },
            isNextDay(flight) {
                let dateDiff = 0;
                let departDate = Vue.moment.utc(flight.departureDate.split('T')[0]);
                let returnDate = Vue.moment.utc(flight.arrivalDate.split('T')[0]);
                // for (var i = 0; i < flight.legs.length; i++) {
                //     if (flight.legs[i].diffDates > 0) {
                //         dateDiff += flight.legs[i].diffDates;
                //     }
                // }
                dateDiff = returnDate.diff(departDate, 'days');
                return dateDiff;
            },
            getDurationTime(flight) {
                if (!flight) {
                    return "-";
                }
                if (flight.legs) {
                    var duration = 0;
                    for (var i = 0; i < flight.legs.length; i++) {
                        duration += flight.legs[i].duration;
                    }
                } else {
                    duration = flight.duration;
                }

                var hours = 0;
                var minutes = 0;

                if (duration > 0) {
                    hours = Math.floor(duration / 60);
                    minutes = duration - (hours * 60);
                    return hours + 'h ' + minutes + 'm';
                }
                else {
                    // var departureDate  = moment(new Date(flight.departureDate));
                    // var arrivalDate  = moment(new Date(flight.arrivalDate));
                    //
                    // var flightTime = moment.duration(arrivalDate.diff(departureDate));
                    // hours = flightTime.hours();
                    // minutes = flightTime.minutes();
                    return ' ';
                }
            },
            getTransitTime(arrivalDate, departureDate) {
                if (arrivalDate && departureDate) {
                    var arrival = Vue.moment.utc(arrivalDate);
                    var departure = Vue.moment.utc(departureDate);
                    var duration = departure.diff(arrival) / 60000; // convert to minute based

                    var hours = Math.floor(duration / 60);
                    var minutes = duration - (hours * 60);

                    return hours + 'h ' + minutes + 'm';
                }
                return '-';
            },
            getChangedPrice(flight) {
                var baseFlight = this.flightStore.inboundFlight || this.flightStore.outboundFlight;
                var changed = flight.solutionPrice - baseFlight.solutionPrice;

                changed = changed.toFixed(this.packageQuery.currencyDecimals);
                return changed;
            },
            getPriceChange(flight) {
                var changed = this.getChangedPrice(flight);
                return (changed >= 0 ? '+' : '-') + (Math.abs(changed).toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            getAvgPriceChange(flight) {
                var changed = this.getChangedPrice(flight);
                if (changed === 0) {
                    return "...";
                }

                var displayPrice = this.product.displayPrice;

                //price per night
                if (displayPrice === 0) {
                    changed =  this.averagePricePerNight(changed);
                }
                //price per person
                if (displayPrice === 1) {
                    changed = this.averagePricePerPerson(changed);
                }
                return (changed >= 0 ? '+' : '-') + (Math.abs(changed).toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            getPrice(flight) {
                var price = flight.solutionPrice + this.totalPackagePriceValue(this.hotelSelected);

                price = price.toFixed(this.packageQuery.currencyDecimals + "");
                return price.replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            totalPackagePriceValue(hotel) {
                if (!hotel) return 0;
                if (hotel.cheapestPrice === 0) {
                    return 0;
                }

                if (this.enabledFlights && !this.flightStore.outboundFlight) {
                    return 0;
                }

                if (!hotel.availableRooms) {
                    return 0;
                }

                var price = 0;
                for (var j = 0; j < hotel.availableRooms.length; j++) {
                    for (var k = 0; k < hotel.availableRooms[j].availableRoomTypes.length; k++) {
                        var availableRoomType = hotel.availableRooms[j].availableRoomTypes[k];
                        if (availableRoomType.selected) {
                            price += availableRoomType.totalPrice;
                            break;
                        }
                    }
                }

                return price;
            },
            getAvgPrice(flight) {
                let self = this;
                let packagePrice = flight.solutionPrice + self.totalPackagePriceValue(self.hotelSelected);

                if (packagePrice === 0) {
                    return "...";
                }

                var displayPrice = self.product.displayPrice;

                //price per night
                if (displayPrice === 0) {
                    packagePrice = self.averagePricePerNight(packagePrice);
                }
                //price per person
                if (displayPrice === 1) {
                    packagePrice = self.averagePricePerPerson(packagePrice);
                }
                return (packagePrice.toFixed(self.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            averagePricePerPerson(totalPackagePrice) {
                var paxCount = this.calculatePaxCount;
                var price = totalPackagePrice / paxCount;
                return price;
            },
            averagePricePerNight(totalPackagePrice) {
                var nightCount = this.calculateNights();
                totalPackagePrice = totalPackagePrice / nightCount;
                return totalPackagePrice;
            },
            calculateNights() {
                var oneDay = 24 * 60 * 60 * 1000;
                var returnDate = Date.parse(this.packageQuery.returnDate);
                var departureDate = Date.parse(this.packageQuery.departureDate);
                var nights = Math.round(Math.abs((returnDate - departureDate) / (oneDay)));
                return nights;
            },
            changeFlights(flight) {
                this.$emit('onChangeFlight', flight);
            },
            onFlightDetailShown(event, flight) {
                event.stopPropagation();
                var ele = $(event.target);

                this.selectedFlight = flight;
                setTimeout(function () {
                    $(ele.attr('href')).modal('show');
                }, 100);

                return false;
            },
            goToFlightPage(control) {
                var pageIndex = control == 'next' ? this.pageIndex + 1 : this.pageIndex - 1;
                this.$emit('onPaginationChanged', pageIndex);
            },
            changeSortBy() {
                var self = this;
                if (self.sortOrderBy != null) {
                    var valueSort = self.sortOrderBy.split(';');
                    var newSortBy = valueSort[0] == "SolutionPrice" ? "SolutionPrice" : valueSort[0] == "DepartureTime" ? "DepartureDate" : valueSort[0] == "ArrivalTime" ? "ArrivalDate" : valueSort[0];
                    var newSortByDesc = valueSort[1] == "DESC";
                    self.$emit('onSortedFlights', {
                        newSortBy,
                        newSortByDesc
                    });
                }
            },
            clearOutbound() {
                this.$emit('onClearOutbound')
            },
            formatDate(date, format) {
                return moment.utc(date).format(format);
            }
        }
    }
</script>
