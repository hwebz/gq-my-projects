﻿<template>
    <div class="fh-tabs__wrap" v-if="packageQuery">
        <div class="container">
            <div class="fh-tabs__overview nav nav-tabs">
                <div class="fh-tabs__item fh-tabs__hotel fh-tabs__transfer nav-item active" data-toggle="tab" href="#tabs-arrival" v-if="arrivalTransfer" @click="syncTabs">
                    <div class="title-option">
                        <div class="title-option-name">
                            <span class="text-uppercase" v-lang.ARRIVAL_TRANSFER></span>
                            <a href="#" class="remove" @click="removeTransfer(arrivalTransfer, true)">
                                <span>X</span>
                            </a>
                        </div>
                        <div class="title-option-tag">
                            <a href="#">
                                <i class="icon-car"></i>
                                <span>x{{arrivalTransfer.selectedVehicle.noOfVehicle}}</span>
                            </a>
                            <a href="#">
                                <span>{{arrivalTransfer.selectedVehicle.pickUpDate | moment("DD MMM YYYY")}}, {{arrivalTransfer.selectedVehicle.pickUpTime}}</span>
                            </a>
                            <a href="#" class="remove" @click="removeTransfer(arrivalTransfer, true)">
                                <span>X</span>
                            </a>
                        </div>
                    </div>
                    <div class="picture" :style="'background-image:url('+ arrivalTransfer.images[0] +')'" v-if="arrivalTransfer.images.length > 0">
                    </div>
                    <div class="picture" :style="'background-image:url(' + baseUrl + '/images/img-transfer.jpg)'" v-else></div>
                    <div class="detail">
                        <h2 class="name">{{arrivalTransfer.name}}</h2>
                        <ul class="list-info">
                            <li><i class="icon-clock"></i><span><span v-lang.RIDE_TIME>Ride time</span>: {{arrivalTransfer.approximateTransferTime}}</span></li>
                            <li><i class="icon-group"></i><span>{{arrivalTransfer.selectedVehicle.minPassengers}} - {{arrivalTransfer.selectedVehicle.maxPassengers}}</span></li>
                            <li><i class="icon-briefcase"></i><span>{{arrivalTransfer.selectedVehicle.maxLuggage}}</span></li>                            
                        </ul>
                        <ul class="list-detail">
                            <li>
                                <a href="#modalCancellationTransfer" class="bt-link" data-toggle="modal" @click.prevent="setCancellationTransfer(arrivalTransfer.isReturnJourney)" >
                                    <i class="icon-information"></i>
                                    <span v-lang.VIEW_CANCELLATION_POLICY></span>
                                </a>
                            </li>
                            <li>
                                <i class="icon-location-arrow"></i>
                                <span>
                                    <span v-lang.FROM></span>: {{packageQuery.toAirportName}}
                                    <template v-if="packageQuery.toCityName">
                                        , {{packageQuery.toCityName}}
                                    </template>
                                    <template v-if="packageQuery.toCountryName">
                                        , {{packageQuery.toCountryName}}
                                    </template>
                                </span>
                            </li>
                            <li>
                                <i class="icon-map-marker"></i>
                                <span>
                                    <span v-lang.TO></span>: {{hotelTransfer.name}}
                                    <template v-if="hotelTransfer.address">
                                        , {{hotelTransfer.address}}
                                    </template>
                                </span>
                            </li>
                        </ul>
                        <!--<a class="bt-link" href="#modalFlightDetail" data-toggle="modal" data-target="#modalFlightDetail">View details</a>-->
                    </div>
                </div>
                <div class="fh-tabs__item fh-tabs__hotel fh-tabs__transfer nav-item" data-toggle="tab" href="#tabs-departure" v-if="departureTransfer" @click="syncTabs">
                    <div class="title-option">
                        <div class="title-option-name">
                            <span class="text-uppercase" v-lang.DEPARTURE_TRANSFER></span>
                            <a href="#" class="remove" @click="removeTransfer(departureTransfer, false)">
                                <span>X</span>
                            </a>
                        </div>
                        <div class="title-option-tag">
                            <a href="#">
                                <i class="icon-car"></i>
                                <span>x{{departureTransfer.selectedVehicle.noOfVehicle}}</span>
                            </a>
                            <a href="#">
                                <span>{{departureTransfer.selectedVehicle.pickUpDate | moment("DD MMM YYYY")}}, {{departureTransfer.selectedVehicle.pickUpTime}}</span>
                            </a>
                            <a href="#" class="remove" @click="removeTransfer(departureTransfer, false)">
                                <span>X</span>
                            </a>
                        </div>
                    </div>
                    <div class="picture" :style="'background-image:url('+ departureTransfer.images[0] +')'" v-if="departureTransfer.images.length > 0">
                    </div>
                    <div class="picture" :style="'background-image:url(' + baseUrl + '/images/img-transfer.jpg)'" v-else></div>
                    <div class="detail">
                        <h2 class="name">{{departureTransfer.name}}</h2>
                        <ul class="list-info">
                            <li><i class="icon-clock"></i><span><span v-lang.RIDE_TIME>Ride time</span>: {{departureTransfer.approximateTransferTime}}</span></li>
                            <li><i class="icon-group"></i><span>{{departureTransfer.selectedVehicle.minPassengers}} - {{departureTransfer.selectedVehicle.maxPassengers}}</span></li>
                            <li><i class="icon-briefcase"></i><span>{{departureTransfer.selectedVehicle.maxLuggage}}</span></li>                            
                        </ul>
                        <ul class="list-detail">
                            <li>
                                <a href="#modalCancellationTransfer" class="bt-link" data-toggle="modal" @click.prevent="setCancellationTransfer(departureTransfer.isReturnJourney)" >
                                    <i class="icon-information"></i>
                                    <span v-lang.VIEW_CANCELLATION_POLICY></span>
                                </a>
                            </li>
                            <li v-if="departureTransfer.allowForCheckInTime">
                                <i class="icon-clock"></i><span><span v-lang.ESTIMATE_CHECKIN_TIME>Estimate check-in time</span>: {{departureTransfer.allowForCheckInTime}}</span>
                            </li>
                            <li>
                                <i class="icon-location-arrow"></i>
                                <span>
                                    <span v-lang.FROM></span>: {{hotelTransfer.name}}
                                    <template v-if="hotelTransfer.address">
                                        , {{hotelTransfer.address}}
                                    </template>
                                </span>
                            </li>
                            <li>
                                <i class="icon-map-marker"></i>
                                <span>
                                    <span v-lang.TO></span>: {{packageQuery.toAirportName}}
                                    <template v-if="packageQuery.toCityName">
                                        , {{packageQuery.toCityName}}
                                    </template>
                                    <template v-if="packageQuery.toCountryName">
                                        , {{packageQuery.toCountryName}}
                                    </template>
                                </span>
                            </li>
                        </ul>
                        <!--<a class="bt-link" href="#modalFlightDetail" data-toggle="modal" data-target="#modalFlightDetail">View details</a>-->
                    </div>
                </div>
                <div class="fh-tabs__item fh-tabs__control">
                    <div class="title-class text-uppercase" v-lang.TRANSFER></div>
                    <div class="title-perperson text-uppercase" v-lang.TOTAL_PRICE></div>
                    <div class="price">
                        <span>{{packageQuery.currency}}</span>
                        <strong>{{totalPrice | formatCurrency}}</strong>
                    </div>
                    <a class="link-small" href="#modalTransferPriceBreakdown" data-toggle="modal" @click="showTransferPrice(arrivalTransfer, departureTransfer)" v-lang.PRICE_BREAKDOWN></a>
                    <a class="btn btn-block btn-primary bt-effect bt-selected" href="#" @click="checkBookingTransfer" v-if="nextButtonUrl" v-lang.BOOK></a>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import { mapState } from 'vuex'
    export default {
        props: ['arrivalTransfer', 'departureTransfer', 'packageQuery', 'hotelTransfer', 'nextButtonUrl'],
        data() {
            return {
                
            }
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            baseUrl: state => state.workContext.baseUrl,
            totalPrice() {
                let vm = this;
                let total = 0;
                if (vm.arrivalTransfer) total += vm.arrivalTransfer.selectedVehicle.totalPrice;
                if (vm.departureTransfer) total += vm.departureTransfer.selectedVehicle.totalPrice;
                
                return total;
            }
        }),
        methods: {
            syncTabs(e) {
                var $this = $(e.target);
                var href = $this.attr('href');
                href = href ? href : $this.parents(".fh-tabs__item").attr('href');
                href = $('.nav-tabs .item-tabs-header[href="' + href + '"]');
                if (typeof href !== 'undefined' && href.length > 0) {
                    href.tab('show');
                }
            },
            showTransferPrice(arrivalTransfer, departureTransfer) {
                this.$emit('onShowTransferPrice', {
                    arrivalTransfer: arrivalTransfer,
                    departureTransfer: departureTransfer,
                    isSummary: true
                });
            },
            setCancellationTransfer(isReturnJourney) { 
                this.$emit('onSetCancellationTransfer', {
                    isDeparture: isReturnJourney
                });
            },
            checkBookingTransfer(e) {
                let self = this;
                this.$emit('onCheckBookingTransfer', {
                    event: e,
                    nextButtonUrl: self.nextButtonUrl 
                });
            },
            removeTransfer(transfer, isArrival) {
                this.$emit('onRemoveTransfer', {
                    transfer: transfer,
                    isArrival: isArrival
                });
            }
        }
    }
</script>