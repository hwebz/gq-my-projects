<template>
    <div id="loadbar" :class="{'completed': isLoading, 'go': !isLoading}"></div>
</template>
<script>
    export default {
        components: { },
        props: ['isLoading'],
        data() {
            return {
                firstTime: true
            }
        },
        updated() {
        },
        methods: {

        }
    }
</script>
<style>
    #loadbar{background:#4A90E2;height:2px;width:0;position:fixed;top:0;left:0;opacity:1}
    #loadbar.go{transition:all .7s ease-in;width:100%}
    #loadbar.go.long{transition:all 5s ease-out;width:80%}
    #loadbar.go.longer{transition:all 20s linear;width:95%}
    #loadbar.go.completed{transition:all .25s ease-out;width:100%;opacity:0;}
</style>