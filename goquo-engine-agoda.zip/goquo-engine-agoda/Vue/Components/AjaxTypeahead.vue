﻿<template>
    <div class="box-search">
        <div class="sidebar__search dropdown">
            <div class="dropdown-toggle" data-toggle="dropdown">
                <input class="ipt-search" :value="defaultValue" type="text" :placeholder="placeholder" />
                <button class="bt-search" type="button">
                    <i class="icon-search"></i>
                </button>
            </div>
            <!--<div class="dropdown-results-wrapper flight-result-wrap dropdown-menu" :class="{'prevent': closeOnClickPopup}">-->
                <!--<div class="flight-result-ddr" v-if="results.length > 0 && isSearchCompleted">-->
                    <!--<div class="scroll-hoz">-->
                        <!--<div class="flight-result-ddr__item" v-for="(item, index) in results" :key="index" @click="onSelectLocation(item.name)">-->
                            <!--<i class="icon icon-hotel"></i>-->
                            <!--<div class="name-city">-->
                                <!--<p class="result-name">{{item.name}}</p>-->
                            <!--</div>-->
                        <!--</div>-->
                    <!--</div>-->
                <!--</div>-->
                <!--<div class="flight-result-ddr" v-if="results.length == 0 && isSearchCompleted && !isFirstLoad">-->
                    <!--<div class="flight-result-ddr__item not-found">-->
                        <!--<i class="icon icon-location-arrow"></i>-->
                        <!--<div class="name-city">-->
                            <!--<p class="result-name">No matching result found.</p>-->
                        <!--</div>-->
                    <!--</div>-->
                <!--</div>-->
                <!--<div class="load load__bar" :class="{'load__bar&#45;&#45;active': !isSearchCompleted}">-->
                    <!--<div class="line"></div>-->
                    <!--<div class="line"></div>-->
                    <!--<div class="line"></div>-->
                <!--</div>-->
            <!--</div>-->
        </div>
    </div>
</template>
<script>
    import _ from 'lodash';
    import axios from 'axios';

    export default {
        props: ['url', 'name', 'placeholder', 'closeOnClickPopup','defaultValue'],

        data() {
            return {
                results: [],
                isSearchCompleted: true,
                isFirstLoad: true
            }
        },
        mounted: function () {
            var vm = this;
            var $element = $(vm.$el);

            $element.find('.ipt-search').on('keydown', _.debounce(function () {
                var $this = $(this);
                vm.isSearchCompleted = false;
                vm.onSelectLocation($this.val())
                // axios.get(vm.url,  {
                //     params: {
                //         term: $this.val()
                //     }
                // }).then(function (response) {
                //     if (response.status == 200) {
                //         vm.results = response.data;
                //     }
                //     vm.isFirstLoad = false;
                //     vm.isSearchCompleted = true;
                // }).catch(function (error) {
                //     console.log(error);
                //
                //     vm.isSearchCompleted = true;
                // });
            }, 500)).on('focus', function () {
                var $this = $(this);
                $this.val('');
                vm.onSelectLocation($this.val())
            });
        },
        methods: {
            onSelectLocation: function (name) {
                var vm = this;
                var $this = $(vm.$el);
                $this.find(".ipt-search").val(name);
                
                this.$emit('onHotelNameChange', name);
            }
        }
    }

</script>
