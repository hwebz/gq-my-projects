﻿<template>
    <div>
        <div class="avai-hotel avai-tour tour-results" v-if="!loadingFilter && !loading.bookingTour && tours.length > 0">
            <div class="fh-tabs__overview" v-for="(tour, index) in tours" :key="tour.code">
                <div class="fh-tabs__item fh-tabs__hotel">
                    <div class="picture" :data-tour-images="getTourImages(tour)" :style="'background-image: url(' + (tour.thumbnail ? tour.thumbnail : (tour.images && tour.images.length > 0 ? tour.images[0] : baseUrl + '/images/tour-default.png')) + ');'">
                                    <span class="picture__mask">
                                        <i class="icon icon-search"></i>
                                    </span>
                    </div>
                    <div class="detail">
                        <span class="hidden-supplier-code">{{ tour.providerCode }}</span>
                        <h2 class="name">{{tour.name}}</h2>
                        <div class="information">
                            <div class="address"><i class="icon-location-arrow"></i><span>{{packageQuery.toCityName}}, {{packageQuery.toCountryName}}</span></div>
                            <div class="time" v-if="tour.duration"><i class="icon-clock"></i><span>{{tour.duration}}</span></div>
                        </div>
                        <ul class="list-ruler-check">
                            <li v-if="tour.rating && tour.rating.average > 0">
                                        <span :class="'reviews-score reviews-score__' + getTourRating(tour.rating.average)">
                                            <span class="reviews-score__score">{{tour.rating.average}}</span> |
                                            <span class="reviews-score__description capitalize">{{getTourRating(tour.rating.average).replace(/[-]+/g, ' ')}}</span>
                                        </span>
                                <span>
                                            <span class="reviews-score__reviews" v-if="tour.review && tour.review.count > 0">{{tour.review.count}} {{tour.review.count > 1 ? 'reviews' : 'review'}}</span>
                                        </span>
                            </li>
                            <!--<li class="cancellation" v-if="Array.isArray(tour.cancellationPolicies)">-->
                            <!--<i class="icon-checked"></i> -->
                            <!--<span>Free Cancellation</span>-->
                            <!--</li>-->
                            <!--<li class="non-refund" v-else>-->
                            <!--<i class="icon-remove"></i>-->
                            <!--<span>Non-refundable</span>-->
                            <!--</li>-->
                        </ul>
                        <div class="description">
                            <template v-if="tour.salesPoints && tour.salesPoints.length > 0">
                                <ul class="interested-points">
                                    <li v-for="salePoint in tour.salesPoints">
                                        <i class="icon icon-check-mark"></i>
                                        {{salePoint}}
                                    </li>
                                </ul>
                            </template>
                            <p v-html="tour.summary" :class="{'has-sales-points': (tour.salesPoints && tour.salesPoints.length > 0)}"></p>
                        </div>
                        <!--<a class="bt-link" href="#modalTourDetail" @click.prevent="getFullTourInfo(tour, index, true)">View details...</a>-->
                        <a class="bt-link" data-toggle="collapse" :href="'#tourDetailInfo-' + tour.id" @click.prevent="triggerCollapse" v-lang.VIEW_DETAILS></a>
                    </div>
                </div>
                <div class="fh-tabs__item fh-tabs__control">
                    <div class="group-price">
                        <div class="title-class text-uppercase" v-lang.TOUR></div>
                        <div class="title-perperson text-uppercase" v-if="calculatePax(tour) > 1" v-lang.FOR_X_PERSONS="{0: calculatePax(tour)}"></div>
                        <div class="title-perperson text-uppercase" v-else v-lang.FOR_X_PERSON="{0: calculatePax(tour)}"></div>
                        <div class="price"><span>{{packageQuery.currency}}</span><strong>{{tour.gstMarkupPrice ? tour.gstMarkupPrice : tour.price | formatCurrency}}</strong></div>
                    </div>
                    <div class="group-price">
                        <!--<div class="title-class">For {{calculatePaxCount > 1 ? calculatePaxCount + ' persons' : calculatePaxCount + ' person'}}</div>-->
                        <!--<div class="price-total"><span>{{packageQuery.currency}}</span><strong>{{tour.gstMarkupPrice * calculatePaxCount | formatCurrency}}</strong></div>-->
                        <a class="link-small" href="#modalPriceBreakdown" data-toggle="modal" @click.prevent="getFullTourInfo(tour, index, false)" v-lang.PRICE_BREAKDOWN></a>
                    </div>
                    <a class="btn btn-block btn-outline-primary bt-effect" :class="{'bt-selected': tour.selected}" data-toggle="collapse" :href="'#tourDetail-' + tour.id"  @click.prevent="triggerCollapse">
                        <i class="icon icon-checked" v-if="tour.selected"></i>
                        {{tour.selected ? translateText('SELECTED', 'Selected') : translateText('SELECT', 'Select')}}
                    </a>
                </div>
                <div class="fh-tabs__item fh-tabs__detail collapse" :id="'tourDetail-' + tour.id" :class="{'active': tour.selected}">
                    <div class="loading-mask" :class="{'active': tour.loading}">
                        <div class="loading-mask__loading">
                            <span v-lang.PROCESSING></span>
                        </div>
                    </div>
                    <div class="loading-mask" :class="{'active': tour.selected}">
                        <div class="loading-mask__loading">
                            <a class="btn btn-danger" href="javascript:void(0);" @click.prevent="removeTour(tour, index)">
                                <i class="ico icon-remove"></i>
                                <span v-lang.REMOVE_THIS_TOUR></span>
                            </a>
                        </div>
                    </div>
                    <div class="tourBook">
                        <form action="/package/booking-tour" class="submit-tour" @submit="bookingTour($event, tour, index)" method="POST">
                            <div class="search-tabs">
                                <div class="search-body">
                                    <div class="search-content">
                                        <div class="search-grid">
                                            <div class="box-search dropdown flight-only activity-options">
                                                <div class="dropdown-toggle" data-toggle="dropdown">
                                                    <strong v-lang.ACTIVITY_OPTIONS></strong>
                                                    <div class="search-input daterange-picker">
                                                        <i class="ico icon-result-page"></i>
                                                        <div class="ipt-show">
                                                            <template v-if="tour.activities.length > 0">
                                                                <span class="single-line" v-for="act in tour.activities" v-if="act.code === tour.activityCode">{{act.name}}</span>
                                                            </template>
                                                            <span class="single-line" v-else v-lang.SELECT_OPTION></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="dropdown-menu">
                                                    <div class="dropdown-item" v-for="option in tour.activities" :class="{'active': option.code === tour.activityCode}" @click="changeActivity(tour, index, option)">
                                                        <i class="icon icon-checked" v-if="option.code === tour.activityCode"></i>
                                                        {{option.name}}
                                                    </div>
                                                </div>
                                                <input type="hidden" name="ActivityCode" :value="tour.activityCode" />
                                            </div>
                                            <DateRangePicker v-model="tour.operatorDate" date-format="DD/MM/YYYY" :startDate="packageQuery.departureDate" :endDate="packageQuery.returnDate" data-selected="true" isFlight="true" journeyType="0" :isTourResult="true" @onOperatorDateChanged="operatorDate => onOperatorDateChanged(operatorDate, tour, index)" :dailyRates="tour.dailyRates" />
                                            <div class="box-search dropdown flight-only activity-options departure-box">
                                                <div class="dropdown-toggle" data-toggle="dropdown">
                                                    <strong v-lang.DEPARTURE></strong>
                                                    <div class="search-input daterange-picker">
                                                        <i class="ico icon-map"></i>
                                                        <div class="ipt-show">
                                                            <input class="ipt-search"
                                                                   name="DeparturePointName"
                                                                   :id="'DeparturePointName-' + tour.id"
                                                                   type="text"
                                                                   @keyup="filterDepartures($event, tour, index)"
                                                                   @change="changeDeparturePointName($event, tour, index)"
                                                                   :placeholder="translateText('SELECT_DEPARTURE', 'Select departure...')" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="dropdown-menu">
                                                    <div class="dropdown-item" v-for="departure in tempDepartures" v-if="tour.departures != undefined && tour.departures.length > 0"
                                                         :class="{'active': departure.code === tour.departurePoint}"
                                                         @click="changeDeparture($event, tour, departure, index)">
                                                        <i class="icon icon-checked" v-if="departure.code === tour.departurePoint"></i>
                                                        {{departure.name}}
                                                    </div>
                                                </div>
                                                <input type="hidden" name="DeparturePoint" data-value="true" :data-required-message="translateText('PLEASE_CHOOSE_DEPARTURE_POINT', 'Please choose departure point')" data-label="Departure" :value="tour.departurePoint" />
                                            </div>
                                            <PaxSelector :maxRooms="3" data-selected="true" :isTourResult="true"  @onChangePax="paxInfo => changePax(null, paxInfo, tour, index)" :tour="tour" :paxInfo="paxInfoDetail" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tour-time" v-if="tour.departureTimes &&  tour.departureTimes.length > 0">
                                <span v-lang.AVAILABLE_TIME></span>
                                <div class="tour-time-list">
                                    <a class="btn btn-sm" :class="{'btn-outline-primary': tour.departureTime !== time,'btn-primary': tour.departureTime === time}" href="#" v-for="time in tour.departureTimes" @click.prevent="changeTime(tour, index, time)">{{time}}</a>
                                </div>
                                <input type="hidden" name="DepartureTime" :value="tour.departureTime" />
                            </div>
                            <div class="submit-btn">
                                <input type="button" class="btn btn-danger" v-if="tour.selected" @click="removeTour(tour, index)" :value="translateText('REMOVE_ACTIVITY', 'Remove activity')" />
                                <input type="submit" class="btn btn-primary bt-effect bt-selected" v-else :value="translateText('ADD_THIS_ACTIVITY' ,'Add this activity')" />
                            </div>
                        </form>
                    </div>
                </div>
                <div class="fh-tabs__item fh-tabs__detail collapse" :id="'tourDetailInfo-' + tour.id">
                    <div class="tabs-cls-detail">
                        <div class="tabs-cls-header nav nav-tabs">
                            <a class="item-tabs-cls nav-item nav-link active" data-toggle="tab" role="tab" :href="'#tab-item-' + tour.id + '-description'" v-lang.DESCRIPTION></a>
                            <a class="item-tabs-cls nav-item nav-link" data-toggle="tab" role="tab" :href="'#tab-item-' + tour.id + '-gallery'" v-if="tour.images.length > 0" v-lang.PHOTO></a>
                            <a class="item-tabs-cls nav-item nav-link" data-toggle="tab" role="tab" :href="'#tab-item-' + tour.id + '-reviews'" v-if="tour.rating && tour.review && tour.rating.average > 0" v-lang.REVIEWS></a>
                        </div>
                        <div class="tabs-cls-main tab-content">
                            <div role="tabpanel" :id="'tab-item-' + tour.id + '-gallery'" class="tabs-cls-content tabs-gallery tab-pane"
                                 v-if="tour.images.length > 0">
                                <div class="gallery__wrap">
                                    <div class="gallery__image">
                                        <div class="gallery__image-show" v-if="tour.thumbnail" :id="'tab-item-' + tour.id + '-gallery-big-item'" :style="'background-image:url('+ tour.thumbnail +')'">
                                        </div>
                                        <div class="gallery__image-show" v-else :id="'tab-item-' + tour.id + '-gallery-big-item'" :style="'background-image:url('+ tour.images[0] +')'">
                                        </div>
                                        <div class="go-left go-control" data-index="0" data-control="prev" @click="changeGalleryImage($event, '#tab-item-' + tour.id + '-gallery-big-item', [tour.thumbnail, ...tour.images])">
                                            <i class="icon-left-chevron" style="pointer-events: none"></i>
                                        </div>
                                        <div class="go-right go-control" data-index="0" data-control="next" @click="changeGalleryImage($event, '#tab-item-' + tour.id + '-gallery-big-item', [tour.thumbnail, ...tour.images])">
                                            <i class="icon-right-chevron" style="pointer-events: none"></i>
                                        </div>
                                    </div>
                                    <div class="gallery__thumbs">
                                        <div class="gallery__thumbs-item">
                                            <a class="thumb-item active" href="javascript:void(0);" :data-image-index="0" v-if="tour.thumbnail"
                                               :style="'background-image:url('+ tour.thumbnail +')'" key="0" @click="changeGalleryImage($event, '#tab-item-' + tour.id + '-gallery-big-item', tour.thumbnail)"></a>
                                            <a class="thumb-item" href="javascript:void(0);" :data-image-index="i + 1" :class="{'active': i === 1 && !tour.thumbnail }" v-for="(img, i) in tour.images"
                                               :style="'background-image:url('+ img +')'" :key="i + 1" @click="changeGalleryImage($event, '#tab-item-' + tour.id + '-gallery-big-item', img)"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div role="tabpanel" :id="'tab-item-' + tour.id + '-reviews'" class="tabs-cls-content tabs-services tab-pane scroll-hoz  reviews-box" v-if="tour.rating && tour.review && tour.rating.average > 0">
                                <div class="hotel-reviews">
                                    <div class="hotel-reviews__title">
                                        <div class="hotel-reviews__summary">
                                            <div class="hotel-reviews__score">
                                                <div :class="'pie ' + getTourRating(tour.rating.average)">
                                                    <span class="inner-pie"></span>
                                                    <span class="text-pie">{{tour.rating.average}}</span>
                                                </div>
                                            </div>
                                            <div class="hotel-reviews__score-text">
                                                <span class="capitalize">{{getTourRating(tour.rating.average).replace(/[-]+/g, ' ')}}</span>
                                                <small v-if="tour.review.count > 1" v-lang.BASED_ON_X_REVIEWS="{0: tour.review.count}"></small>
                                                <small v-else v-lang.BASED_ON_X_REVIEW="{0: tour.review.count}"></small>
                                            </div>
                                        </div>
                                        <div class="hotel-reviews__statistics">
                                            <div class="bar" v-for="(rating, key) in tour.rating.ratingCounts">
                                                <span class="title text-lowercase">{{key}} {{key > 1 ? translateText('STARS', 'Stars') : translateText('STAR', 'Star')}}</span>
                                                <div class="bar-box">
                                                    <div class="active-bar" :style="'width:' + ((rating/tour.review.count) * 100) + '%'"></div>
                                                </div>
                                                <span class="num">{{rating}}/{{tour.review.count}}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="hotel-reviews__content" v-if="tour.review && tour.review.comments.length > 0">
                                        <div class="hotel-reviews__tab-pane tour-comment">
                                            <div id="reviews-all"
                                                 class="tab-pane fade scroll-hoz active show">
                                                <div class="reviews-all__cat typical-list">
                                                    <ul class="summary-reviews typical-item">
                                                        <li v-for="comment in tour.review.comments">
                                                            <span class="ico icon-user"></span>
                                                            <span class="text">
                                                                            <span class="title">{{comment.name}} 
                                                                                <small v-lang.COMMENT_ON="{0: formatDate(comment.date, 'DD MMM HH:mm')}"></small>
                                                                                <span class="score">
                                                                                    <span :class="'reviews-score reviews-score__' + getTourRating(comment.rating)">
                                                                                        <span class="reviews-score__score">{{comment.rating}}</span> |
                                                                                        <span class="reviews-score__description capitalize">{{getTourRating(comment.rating).replace(/[-]+/g, ' ')}}</span>
                                                                                    </span>
                                                                                </span>
                                                                            </span>
                                                                            <span class="content">
                                                                                <span class="message" v-html="comment.comment"></span>
                                                                            </span>
                                                                        </span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div role="tabpanel" :id="'tab-item-' + tour.id + '-description'" class="tabs-cls-content tabs-gallery tab-pane scroll-hoz show active">
                                <div class="fh-tabs__item fh-tabs__detail tour-modal">
                                    <div class="fh-tabs__detail-description" v-html="tour.description"></div>
                                    <template v-if="tour.salesPoints && tour.salesPoints.length > 0">
                                        <h4 v-lang.INTERESTING_POINTS></h4>
                                        <div class="fh-tabs__detail-description">
                                            <ul class="interested-points">
                                                <li v-for="salePoint in tour.salesPoints">
                                                    <i class="icon icon-check-mark"></i>
                                                    <span v-html="salePoint"></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </template>
                                    <template v-if="tour.inclusions && tour.inclusions.length > 0">
                                        <h4 v-lang.INCLUSIONS></h4>
                                        <div class="fh-tabs__detail-description">
                                            <ul class="interested-points">
                                                <li v-for="inclusion in tour.inclusions">
                                                    <i class="icon icon-check-mark"></i>
                                                    <span v-html="inclusion"></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </template>
                                    <template v-if="tour.exclusions && tour.exclusions.length > 0">
                                        <h4 v-lang.EXCLUSIONS></h4>
                                        <div class="fh-tabs__detail-description">
                                            <ul class="interested-points">
                                                <li v-for="exclusion in tour.exclusions">
                                                    <i class="icon icon-cross"></i>
                                                    <span v-html="exclusion"></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </template>
                                    <template v-if="tour.additionalInfo && tour.additionalInfo.length > 0">
                                        <h4 v-lang.ADDITIONAL_INFORMATION></h4>
                                        <div class="fh-tabs__detail-description">
                                            <ul class="interested-points">
                                                <li v-for="addInfo in tour.additionalInfo">
                                                    <i class="icon icon-right-arrow"></i>
                                                    <span v-html="addInfo"></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </template>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="paganition-wrap text-center" v-if="isLoadMore">
                <a class="item-paganition bt-effect" href="#" :class="{'bt-loading': loading.paginationLoading}" @click.prevent="gotoTourPage" v-lang.LOAD_MORE></a>
            </div>
        </div>
        <div class="avai-hotel avai-tour" v-else>
            <div class="fh-tabs__overview"v-for="n in (isLoadMore ? 5 : 2)" :key="n">
                <div class="fh-tabs__item fh-tabs__hotel">
                    <div class="picture">
                        <div class="lda__bar lda__bar--full"></div>
                    </div>
                    <div class="detail">
                        <div class="name">
                            <div class="lda__bar"></div>
                            <div class="lda__bar"></div>
                        </div>
                        <div class="infomation">
                            <div class="address"><div class="lda__bar lda__bar--50"></div></div>
                            <div class="time"><div class="lda__bar lda__bar--50"></div></div>
                        </div>
                        <div class="description">
                            <div class="lda__bar"></div>
                            <div class="lda__bar"></div>
                            <div class="lda__bar"></div>
                            <div class="lda__bar"></div>
                            <div class="lda__bar"></div>
                        </div>
                    </div>
                </div>
                <div class="fh-tabs__item fh-tabs__control">
                    <div class="lda lda--fbot">
                        <div class="lda__bar lda__bar--50"></div>
                        <div class="lda__bar lda__bar--50"></div>
                        <div class="lda__bar lda__bar--50"></div>
                        <div class="lda__bar lda__bar--split lda__bar--50"></div>
                        <div class="lda__bar lda__bar--two"></div>
                    </div>
                </div>
                <div class="fh-tabs__item fh-tabs__detail"></div>
            </div>
            <div class="paganition-wrap text-center" v-if="isLoadMore">
                <div class="lda__bar"></div>
            </div>
        </div>
        <div class="modal fade" id="modalPriceBreakdown" tabindex="-1" role="dialog" aria-hidden="true" v-if="tourInfor">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body modal-body-gray npd">
                        <div class="flight-detail-title">
                            <strong v-lang.PRICE_BREAKDOWN></strong>
                            <button class="modal-close" data-dismiss="modal">
                                <i class="icon-remove"></i>
                            </button>
                        </div>
                        <div class="price-summary-table">
                            <table class="responsive">
                                <thead>
                                <tr>
                                    <th colspan="4" v-lang.TOUR_PRICES></th>
                                </tr>
                                <tr>
                                    <th scope="col" v-if="tourInfor.isSummary" v-lang.TOUR_NAME></th>
                                    <th scope="col" v-else v-lang.PASSENGERS></th>
                                    <th scope="col" v-lang.PRICE_PER_PAX></th>
                                    <th scope="col" v-lang.NO_OF_PASSENGERS></th>
                                    <th scope="col" v-lang.TOTAL_PRICE></th>
                                </tr>
                                </thead>
                                <tbody>
                                <template v-if="tourInfor.isSummary">
                                    <tr v-if="selectedTours.length > 0" v-for="tour in selectedTours">
                                        <td scope="row" :data-label="translateText('', 'Tour name')">{{tour.name}}</td>
                                        <td :data-label="translateText('PRICE_PER_PAX', 'Price/pax')">{{packageQuery.currency}} {{((tour.gstMarkupPrice ? tour.gstMarkupPrice : tour.price)/calculatePax(tour)) | formatCurrency}}</td>
                                        <td :data-label="translateText('NO_OF_PASSENGERS', 'No. of Passengers')">{{calculatePax(tour)}}</td>
                                        <td :data-label="translateText('TOTAL_PRICE', 'Total price')">{{packageQuery.currency}} {{tour.gstMarkupPrice ? tour.gstMarkupPrice : tour.price | formatCurrency}}</td>
                                    </tr>
                                </template>
                                <template v-if="!tourInfor.isSummary">
                                    <tr>
                                        <td scope="row" :data-label="translateText('PASSENGERS', 'Passengers')" v-lang.PER_PASSENGER></td>
                                        <td :data-label="translateText('PRICE_PER_PAX', 'Price/pax')">{{packageQuery.currency}} {{((tourInfor.gstMarkupPrice ? tourInfor.gstMarkupPrice : tourInfor.price)/calculatePax(tourInfor)) | formatCurrency}}</td>
                                        <td :data-label="translateText('NO_OF_PASSENGERS', 'No. of Passengers')">{{calculatePax(tourInfor)}}</td>
                                        <td :data-label="translateText('TOTAL_PRICE', 'Total price')">{{packageQuery.currency}} {{tourInfor.gstMarkupPrice ? tourInfor.gstMarkupPrice : tourInfor.price | formatCurrency}}</td>
                                    </tr>
                                </template>
                                </tbody>
                            </table>
                            <table>
                                <thead>
                                <tr>
                                    <th v-lang.TOTAL_PRICE_INCLUDES_TAXES_AND_FEES></th>
                                    <th>{{packageQuery.currency}} {{tourInfor.gstMarkupPrice ? tourInfor.gstMarkupPrice : tourInfor.price | formatCurrency}}</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-primary bt-effect" type="button" data-dismiss="modal" v-lang.CLOSE></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import Vue from 'vue'
    import { mapState } from 'vuex'
    import DateRangePicker from './DateRangePicker.vue'
    import PaxSelector from './PaxSelector.vue'
    export default {
        props: ['tours', 'loading', 'loadingFilter', 'packageQuery', 'isLoadMore', 'tempDepartures', 'tourInfor', 'selectedTours'],
        components: {
            DateRangePicker,
            PaxSelector
        },
        data() {
            return {
                
            };
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            product: state => state.workContext.product,
            baseUrl: state => state.workContext.baseUrl,
            paxInfoDetail() {
                let self = this;
                let paxInfo = {
                    adultCount: 0,
                    childCount: 0,
                    infantCount: 0
                };
                for (var i = 0; i < self.packageQuery.paxInfos.length; i++) {
                    let pax = self.packageQuery.paxInfos[i];
                    paxInfo.adultCount += pax.adultCount;
                    paxInfo.childCount += pax.childCount;
                    paxInfo.infantCount += pax.infantCount;
                }
                return paxInfo;
            }
        }),
        created() {
            if (this.product && this.product.type != "Tour") {
                setTimeout(() => this.validateSubmit(), 2000);
            }
        },
        methods: {
            formatDate(date, format) {
                return Vue.moment.utc(date).format(format);
            },
            translateText(translateKey, defaultText, params) {
                return this.translate(this.$language, translateKey, params) || defaultText;
            },
            calculatePax(tour) {
                return tour ? (tour.adults + tour.children) : 0;
            },
            triggerCollapse(e) {
                let target = $($(e.target).attr('href'));
                let allDetails = $(".tour-results .fh-tabs__item").not(target);

                allDetails.collapse('hide');
                target.collapse('toggle');
            },
            getFullTourInfo: function (tour, index, isShowModal) {
                this.$emit('onGetFullTourInfo', {
                    tour, index, isShowModal
                });
            },
            changeActivity(tour, index, option) {
                this.$emit('onChangeActivity', {
                    tour, index, option
                });
            },
            bookingTour(event, tour, index) {
                this.$emit('onBookingTour', {
                    event, tour, index
                })
            },
            onOperatorDateChanged(operatorDate, tour, index) {
                this.$emit('onOperatorDateChanged', {
                    operatorDate, tour, index
                })
            },
            changeDeparturePointName(event, tour, index) {
                this.$emit('onChangeDeparturePointName', {
                    event, tour, index
                })
            },
            changePax(event, paxInfo, tour, index) {
                this.$emit('onChangePax', {
                    event, paxInfo, tour, index
                })
            },
            removeTour(tour, index) {
                this.$emit('onRemoveTour', {
                    tour, index
                });
            },
            filterDepartures(event, tour, index) {
                this.$emit('onFilterDepartures', {
                    event, tour, index
                });
            },
            changeTime(tour, index, time) {
                this.$emit('onChangeTime', {
                    tour, index, time
                });    
            },
            changeDeparture(event, tour, departure, index) {
                this.$emit('onChangeDeparture', {
                    event, tour, departure, index
                })
            },
            changeGalleryImage(event, element, source) {
                event.preventDefault();
                var ele = $(element);
                var self = $(event.target);

                if (typeof ele !== "undefined" && ele.length > 0 && source) {
                    if (!Array.isArray(source)) {
                        ele.css({
                            backgroundImage: 'url(' + source + ')'
                        });

                        self.parent().find('.thumb-item').removeClass('active');
                        self.addClass('active');
                        ele.parent().find('.go-control').attr('data-index', self.attr('data-image-index'));
                    } else {
                        var imageIndex = self.attr('data-index') || null;
                        var imageControl = self.attr('data-control') || null;

                        if (imageIndex !== null && imageControl !== null) {

                            switch (imageControl) {
                                case 'next':
                                    self.parent().find('.go-control').attr('data-index', parseInt(imageIndex, 10) < (
                                        source.length - 1) ? parseInt(imageIndex, 10) + 1 : 0);
                                    break;
                                case 'prev':
                                    self.parent().find('.go-control').attr('data-index', parseInt(imageIndex, 10) > 0 ?
                                        parseInt(imageIndex, 10) - 1 : (source.length - 1));
                                    break;
                            }

                            ele.css({
                                backgroundImage: 'url(' + source[parseInt(self.attr('data-index'), 10)] + ')'
                            });

                            var thumbItems = self.parents('.gallery__wrap').find('.thumb-item');
                            thumbItems.removeClass('active');
                            $(thumbItems.get(parseInt(self.attr('data-index')))).addClass('active');
                        }
                    }
                }

                return false;
            },
            getTourRating(score) {
                if (score) {
                    if (score >= 4.5) {
                        return 'excellent';
                    } else if (score >= 4) {
                        return 'very-good';
                    } else if (score >= 3.5) {
                        return 'good';
                    } else if (score >= 3) {
                        return 'fair';
                    } else {
                        return 'poor';
                    }
                }
                return '';
            },
            gotoTourPage() {
                this.$emit('onGoToTourPage');
            },
            getTourImages(tour) {
                let imgs = tour.images;
                let imgStrings = tour.thumbnail ? tour.thumbnail + '|' : '';

                if (tour && imgs.length > 0) {
                    imgs.map(img => {
                        imgStrings += (img + '|');
                    });
                }
                return (tour.thumbnail || tour.images.length > 0) ? imgStrings.substr(0, imgStrings.length - 1) : this.baseUrl + '/images/tour-default.png';
            },
            validateSubmit() {
                $(".submit-tour").each(function () {
                    $(this).validate();
                })
            }
        }
    }
</script>
