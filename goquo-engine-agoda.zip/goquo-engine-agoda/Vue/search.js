﻿import Vue from 'vue'
import UUID from 'vue-uuid'
import VueRouter from 'vue-router'
import VueResource from 'vue-resource';
import Vuex from 'vuex';
import VueMoment from 'vue-moment'
import MultiLanguage from './Libs/vue-multilanguage'
import VTooltip from 'v-tooltip'
import VueSwal from 'vue-swal'
import resources from './resources'
import 'babel-polyfill'

import Availability from './Components/Availability.vue'
import FlightAvailabilityOnly from './Components/FlightAvailabilityOnly.vue'
import FullHotelInfo from './Components/FullHotelInfo.vue'
import FullHotelInfoPackageSummary from './Components/FullHotelInfoPackageSummary.vue'
import TourAvailability from './Components/TourAvailability.vue'
import TransferAvailability from './Components/TransferAvailability.vue'

var hdfCultureCode = document.getElementById('hdfCultureCode');
var languages = {
    default: hdfCultureCode ? hdfCultureCode.value.toLowerCase() : 'en-us'
};

for (var key in resources) {
    if (resources.hasOwnProperty(key)) {
        var resourceKey = resources[key];
        for (var culture in resourceKey) {
            if (resourceKey.hasOwnProperty(culture)) {
                if (!languages[culture]) {
                    languages[culture] = {};
                }

                var language = languages[culture];
                language[key] = resourceKey[culture];
            }
        }
    }
}

Vue.use(VueRouter);
Vue.use(UUID);
Vue.use(Vuex);
Vue.use(VueResource);
Vue.use(VueMoment);
Vue.use(VueSwal);
Vue.use(MultiLanguage, languages);
Vue.use(VTooltip);

Vue.filter("formatCurrency", function (value) {
    let curDecimals = store.state.workContext.packageQuery.currencyDecimals;
    let val = value ? value.toFixed(curDecimals ? curDecimals : 0) : value;
    return (val + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
});

Vue.filter("stringFormat", function (value) {
    var args = Array.prototype.slice.call(arguments, 1);
    return value.replace(/{(\d+)}/g, function (match, number) {
        return typeof args[number] != 'undefined'
            ? args[number]
            : match;
    });
});

Vue.filter("formatDate", function (date, convertType) {
    if (!date) return moment.utc();
    else return moment.utc(String(date)).format(convertType);
});

const router = new VueRouter({
    mode: 'history',
    base: __dirname,
    routes: [
        {
            path: '/package/search',
            components: {
                content: Availability
            }
        },
        {
            path: '/package/search-hotel',
            components: {
                content: Availability
            }
        },
        {
            path: '/package/search-flight',
            components: {
                content: FlightAvailabilityOnly
            }
        },
        {
            path: '/package/search-tour',
            components: {
                content: TourAvailability
            }
        },
        {
            path: '/package/search-transfer',
            components: {
                content: TransferAvailability
            }
        },
        {
            path: '/package/hotel/:country/:cityName/:cityCode/:hotelName/:hotelId',
            components: {
                content: FullHotelInfo,
                packageSummary: FullHotelInfoPackageSummary
            }
        }
    ]
});

var store = new Vuex.Store({
    debug: false,
    state: {
        workContext: {},
        hotelInfo: {},
        totalPackagePrice: "-",
        isSearchCompleted: false,
        defaultDate: null
    },
    mutations: {
        setWorkContext(state, workContext) {
            state.workContext = workContext;
        },
        setHotelInfo(state, hotelInfo) {
            state.hotelInfo = hotelInfo;
        },
        setIsSearchCompleted(state) {
            state.isSearchCompleted = true;
        },
        setTotalPackagePrice(state, totalPackagePrice) {
            state.totalPackagePrice = totalPackagePrice;
        },
        setDefaultDate(defaultDate) {
            state.defaultDate = defaultDate;
        }
    }
});

var app = document.getElementById("app");
if (app) {
    new Vue({
        router,
        store
    }).$mount('#app');    
}