﻿import Vue from 'vue'
import UUID from 'vue-uuid'
import VueRouter from 'vue-router'
import Vuex from 'vuex';
import VueSwal from 'vue-swal'
import VueMoment from 'vue-moment'
import MultiLanguage from './Libs/vue-multilanguage'
import 'babel-polyfill'

import resources from './resources'
import SearchBox from './Components/SearchBox.vue'
import ModifySearchBox from './Components/ModifySearchBox.vue'

var hdfCultureCode = document.getElementById('hdfCultureCode');
var languages = {
    default: hdfCultureCode ? hdfCultureCode.value.toLowerCase() : 'en-us'
};

for (var key in resources) {
    if (resources.hasOwnProperty(key)) {
        var resourceKey = resources[key];
        for (var culture in resourceKey) {
            if (resourceKey.hasOwnProperty(culture)) {
                if (!languages[culture]) {
                    languages[culture] = {};
                }

                var language = languages[culture];
                language[key] = resourceKey[culture];
            }
        }
    }
}

Vue.use(VueRouter);
Vue.use(UUID);
Vue.use(Vuex);
Vue.use(VueMoment);
Vue.use(VueSwal);
Vue.use(MultiLanguage, languages);

Vue.filter("formatCurrency", function (value) {
    let curDecimals = store.state.workContext.packageQuery.currencyDecimals;
    let val = value ? value.toFixed(curDecimals ? curDecimals : 0) : value;
    return (val + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
});

Vue.filter("stringFormat", function (value) {
    var args = Array.prototype.slice.call(arguments, 1);
    return value.replace(/{(\d+)}/g, function (match, number) {
        return typeof args[number] != 'undefined'
            ? args[number]
            : match;
    });
});

Vue.filter("formatDate", function (date, convertType) {
    if (!date) return moment.utc();
    else return moment.utc(String(date)).format(convertType);
});

const router = new VueRouter({
    mode: 'history',
    base: __dirname,
    routes: [
        {
            path: '/',
            components: {
                content: SearchBox
            }
        },
        {
            path: '/not-available',
            components: {
                content: ModifySearchBox
            }
        }
    ]
});

var store = new Vuex.Store({
    debug: false,
    state: {
        workContext: {},
        defaultDate: null
    },
    mutations: {
        setWorkContext(state, workContext) {
            state.workContext = workContext;
        },
        setDefaultDate(defaultDate) {
            state.defaultDate = defaultDate;
        }
    }
});

var app = document.getElementById("app");
if (app) {
    new Vue({
        router,
        store
    }).$mount('#app');    
}