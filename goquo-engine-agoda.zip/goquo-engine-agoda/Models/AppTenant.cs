﻿using System;
using System.Collections.ObjectModel;

namespace Agoda.Models
{
    public class AppTenant
    {
        public string Name { get; set; }

        public string[] Hostnames { get; set; }

        public Guid SiteId { get; set; }

        public string ApiAccessToken { get; set; }
        
        public string BaseUrl { get; set; }

        public string[] DefaultFilterStars { get; set; }

        public string AgentPortalUrl { get; set; }

        public string AgentPortalBackendUrl { get; set; }

        public string LocalizationUrl { get; set; }
    }

    public class MultitenancyOptions
    {
        public Collection<AppTenant> Tenants { get; set; }
    }
}
