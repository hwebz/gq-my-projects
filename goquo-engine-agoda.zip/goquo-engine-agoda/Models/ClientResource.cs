namespace Agoda.Models
{
    public class ClientResource
    {      
        public string Name { get; set; }
        public string Slogan { get; set; }
        public string BookingOwner { get; set; }
        public string Copyright { get; set; }

        /// <summary>
        /// Config on/off for client
        /// </summary>
        public int? UniqueId { get; set; }


        public ClientResource()
        {
            
        }
    }
}