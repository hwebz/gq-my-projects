﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Agoda.Models;

namespace AgodaWithClient.Web.Multitenancy
{
    public class TenantAppSettingsMiddleware
    {
        private readonly RequestDelegate next;

        public TenantAppSettingsMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            var appTenant = context.RequestServices.GetService<AppTenant>();
            context.Items["x-access-site"] = appTenant.SiteId;
            context.Items["x-access-token"] = appTenant.ApiAccessToken;

            // Call the next delegate/middleware in the pipeline
            await next(context);
        }
    }
}
