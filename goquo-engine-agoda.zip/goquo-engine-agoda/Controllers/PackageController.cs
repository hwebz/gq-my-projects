﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Agoda.Models;
using GoQuoEngine.Client;
using GoQuoEngine.Client.Controllers;
using GoQuoEngine.Client.Data.Domain;
using GoQuoEngine.Client.Models;
using GoQuoEngine.Client.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;

namespace Agoda.Controllers
{
    [Route("package")]
    public class PackageController : BaseAgentPackageController
    {
        private readonly IClientEngine clientEngine;
        private readonly IStringLocalizer<BasePackageController> localizer;
        private readonly AppTenant appTenant;

        public PackageController(IClientEngine clientEngine, IOptions<AppSettings> appSettings,
            IStringLocalizer<BasePackageController> localizer, IAgentBookingService agentBookingService, AppTenant appTenant) : base(clientEngine, appSettings, localizer, agentBookingService)
        {
            this.clientEngine = clientEngine;
            this.localizer = localizer;
            this.appTenant = appTenant;
        }

        protected override async Task<dynamic> GetWorkContextModel(Guid? packageId)
        {
            var model = await base.GetWorkContextModel(packageId);
            model.defaultFilterStars = appTenant.DefaultFilterStars;
            return model;
        }

        [HttpPost, Route("do-booking-agoda")]
        public async Task<IActionResult> DoBookingAgoda(Guid packageId, string outboundFlightId, string inboundFlightId, string hotelId, string[] roomTypeIds,
            string nextRequestUrl)
        {
            var packageQuery = await clientEngine.GetPackageQuery(packageId);

            if (packageQuery == null)
            {
                return Json(new
                {
                    success = true,
                    redirectUrl = "/"
                });
            }

            var request = new DoBookingRequest
            {
                PackageId = packageId,
                OutboundFlightId = outboundFlightId,
                InboundFlightId = inboundFlightId,
                HotelId = hotelId,
                RoomTypeIds = roomTypeIds
            };

            var response = await clientEngine.DoBooking(request);

            if (!response.Success)
            {
                return Json(new
                {
                    success = false,
                    message = localizer[response.Message].ToString()
                });
            }
            string urlAction = string.IsNullOrEmpty(nextRequestUrl) ? Url.Action("Booking", "Booking", new { packageId = packageQuery.Id }) : nextRequestUrl; ;

            return Json(new
            {
                success = true,
                redirectUrl = urlAction
            });
        }
        protected override IActionResult OnStartSearch(Product product, RouteValueDictionary values)
        {
            switch (product.Products[0].ProductType)
            {
                case ProductType.Flight:
                    if (product.Products.Count == 1)
                    {
                        return RedirectToAction("SearchFlight", values);
                    }
                    break;
                case ProductType.Hotel:
                    if (!product.Products.Any(x => x.ProductType == ProductType.Flight))
                    {
                        return RedirectToAction("SearchHotel", values);
                    }
                    break;
                case ProductType.Tour:
                    return RedirectToAction("SearchTour", values);
                case ProductType.Transfer:
                    return RedirectToAction("SearchTransfer", values);
                case ProductType.Car:
                    return RedirectToAction("SearchRentalCars", values);
                case ProductType.TourPackage:
                    return RedirectToAction("SearchTourPackage", values);
            }

            if (product.Products.Any(x => x.ProductType == ProductType.Flight) && product.Products.Any(x => x.ProductType == ProductType.Tour) && product.Products.Count == 2)
            {
                return RedirectToAction("SearchFlightTour", values);
            }

            return RedirectToAction("Search", values);
        }
    }
}
