﻿using GoQuoEngine.Client.Controllers;
using GoQuoEngine.Client.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;

namespace Agoda.Controllers
{
    [Route("booking")]
    public class BookingController : BaseAgentBookingController
    {
        public BookingController(IClientEngine clientEngine, IStringLocalizer<BaseBookingController> localizer, IAgentBookingService agentBookingService) : base(clientEngine, localizer, agentBookingService)
        {
        }
    }
}
