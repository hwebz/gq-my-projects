﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Agoda.Models;
using AgodaWithClient.Services;
using GoQuoEngine.Client.Caching;
using GoQuoEngine.Client.Controllers;
using GoQuoEngine.Client.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.StackExchangeRedis;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using StackExchange.Redis;

namespace Agoda.Controllers
{
    public class ApiController : BaseApiController
    {
        private readonly IClientEngine clientEngine;
        public ApiController(IClientEngine clientEngine, ILogger<BaseApiController> logger) : base(clientEngine, logger)
        {
            this.clientEngine = clientEngine;
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpGet, Route("test-timeout/{seconds}")]
        public async Task<IActionResult> TestTimeout(int seconds)
        {
            await Task.Delay(seconds * 1000);
            return Content($"Ok with timeout: {seconds} seconds.");
        }

        protected override string GetAgentPortalBackendUrl()
        {
            var appTenant = HttpContext.RequestServices.GetService<AppTenant>();

            if (!string.IsNullOrEmpty(appTenant.AgentPortalBackendUrl))
            {
                return appTenant.AgentPortalBackendUrl;
            }

            return appTenant.AgentPortalUrl;
        }

        protected override async Task<IActionResult> ClearAllCaches()
        {
            await Task.CompletedTask;

            try
            {
                var distributedCache = HttpContext.RequestServices.GetService<IDistributedCache>() as AppTenantDistributedCache;

                if (distributedCache != null)
                {
                    distributedCache.Clear();
                    return Content("ok");
                }
                else
                {
                    return Content("Not supported yet.");
                }
            }
            catch (Exception ex)
            {
                return Content(ex.Message);
            }
        }

        [HttpGet, HttpPost, Route("get-global-airports")]
        public override async Task<IActionResult> GetGlobalAirports(string term)
        {
            var airports = await clientEngine.GetGlobalAirports(GetCultureCode(), term);
            return Json(airports);
        }
    }
}
