var gulp = require("gulp"),
    concat = require("gulp-concat"),
    uglify = require("gulp-uglify"),
    autoprefixer = require('gulp-autoprefixer'),
    sass = require('gulp-sass'),
    gulpif = require('gulp-if');
    uglifycss = require('gulp-uglifycss'),
    sourcemaps = require('gulp-sourcemaps'),
    browserSync = require('browser-sync').create();
var webroot = "./wwwroot/";

var clients = [
    'multi-sites/Agoda/',
    'multi-sites/Demo/',
    'multi-sites/Explura/',
    'multi-sites/Severals/',
    'multi-sites/Via.com/',
    'multi-sites/Precise/',
    'multi-sites/AirAsia/',
    'multi-sites/StarAlliance/',
    'multi-sites/Belgogo/',
    'multi-sites/Hainan/',
    'multi-sites/AtlasGlobal/',
    'multi-sites/EgyptAir/',
    'multi-sites/Castrol/',
    'multi-sites/Etihad/'
];

var scssRoots = webroot + 'scss/';

var scssDests = webroot;

/*=========== File paths ==============*/
var scssFiles = webroot + 'scss/**/*.scss',
    dest = webroot + 'css';

gulp.task('bs-reload', function () {
        browserSync.reload();
});
    
gulp.task('browserSync', function () {
    browserSync.instance = browserSync.init({
        startPath: '/',
        port:50001
      });
});


/*=========== SCSS files to CSS ==============*/
gulp.task('styles', function () {
    for (var i = 0; i < clients.length; i++) {
        var root = scssRoots + clients[i];
        var dest = scssDests + clients[i] + 'css/';
        var scss = gulp.src(root + 'main.scss')
            .pipe(sourcemaps.init({ loadMaps: true }))
            .pipe(sass().on('error', sass.logError))
            .pipe(sourcemaps.init({ loadMaps: true }))
            .pipe(autoprefixer('last 2 versions'))
            .pipe(gulp.dest(dest));
        
        scss.pipe(concat('main.min.css'))
            .pipe(uglifycss())
            .pipe(gulp.dest(dest));
        
        scss.pipe(sourcemaps.write('/'),{
                includeContent: false, sourceRoot: '../wwwroot/dest/'
            })
            .pipe(gulp.dest(dest))
            .pipe(browserSync.reload({ stream: true }));
    }
});


/*=========== Minified CSS ==============*/
// gulp.task('styles-min', ['styles'], function () {
//     for (var i = 0; i < scssDests.length; i++) {
//         gulp.src(scssDests[i] + 'main.css')
//             .pipe(concat('main.min.css'))
//             .pipe(uglifycss())
//             .pipe(gulp.dest(scssDests[i]));
//     }
// });

/*=========== JS ==============*/
gulp.task('javascript', function () {
    return gulp.src([
        webroot + "js-new/lib/**/*.js",
        webroot + 'js-new/**/*.js'
    ])
        .pipe(gulpif(process.env.ENV === 'development', sourcemaps.init()))
        .pipe(concat('main.js'))
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest(dest));
});

/*=========== Minified js ==============*/
gulp.task("javascript-min", ['javascript'], function () {
    return gulp.src(webroot + 'dest/main.js')
        .pipe(concat('main.min.js'))
        .pipe(uglify())
        .pipe(gulp.dest(dest));
});

/*=========== Gulp SCSS Watch ==============*/
gulp.task('watch', function () {
    gulp.watch(scssFiles, ['styles']);
});

gulp.task("all", ['javascript-min', 'styles']);