﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Agoda.Models;
using Agoda.Services;
using Agoda.Web.Multitenancy;
using AgodaWithClient.Web.Multitenancy;
using Autofac;
using Autofac.Extensions.DependencyInjection;
using GoQuoEngine.Client;
using GoQuoEngine.Client.Localization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Localization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.Extensions.Localization;
using Microsoft.Net.Http.Headers;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using StackExchange.Redis;
using AgodaWithClient.Extensions;

namespace Agoda
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public IContainer ApplicationContainer { get; private set; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            services.Configure<MultitenancyOptions>(Configuration.GetSection("Multitenancy"));
            services.AddMultitenancy<AppTenant, AppTenantResolver>();

            services.AddResponseCompression(options =>
            {
                options.EnableForHttps = true;
            });

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            // Localization
            services.AddSingleton<IStringLocalizerFactory, GoQuoEngineStringLocalizerFactory>();
            services.AddTransient(typeof(IStringLocalizer<>), typeof(StringLocalizer<>));

            services.AddCors(options =>
            {
                options.AddPolicy("AllowAnyOrigin", builder => builder.AllowAnyOrigin());
            });

            var redisConnection = Configuration.GetConnectionString("RedisConnection");
            if (!string.IsNullOrEmpty(redisConnection))
            {
                var redis = ConnectionMultiplexer.Connect(redisConnection);

                services.AddDataProtection()
                    .SetApplicationName("Agoda")
                    .PersistKeysToStackExchangeRedis(redis, "Agoda-DataProtection-Keys");

                services.AddTenantStackExchangeRedisCache(options => {
                    options.InstanceName = "AgodaCache_";
                    options.Configuration = redisConnection;
                });
            }

            services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(60);
            });

            services.AddMvc()
                .AddViewLocalization(LanguageViewLocationExpanderFormat.Suffix)
                .AddDataAnnotationsLocalization()
                .AddJsonOptions(options =>
                {
                    options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
                })
                .AddCookieTempDataProvider(options =>
                {
                    options.Cookie.SameSite = Microsoft.AspNetCore.Http.SameSiteMode.Lax;
                });

            services.AddEngineClient(Configuration);

            var containerBuilder = new ContainerBuilder();
            containerBuilder.Populate(services);

            ApplicationContainer = containerBuilder.Build();

            // Create the IServiceProvider based on the container.
            return new AutofacServiceProvider(ApplicationContainer);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseMiddleware<ErrorHandlingMiddleware>();
            }
            else
            {
                app.UseExceptionHandler("/error");
                app.UseMiddleware<ErrorHandlingMiddleware>();
            }
            
            app.UseResponseCompression();

            app.UseStaticFiles(new StaticFileOptions
            {
                OnPrepareResponse = context =>
                {
                    var headers = context.Context.Response.GetTypedHeaders();
                    headers.CacheControl = new CacheControlHeaderValue
                    {
                        MaxAge = TimeSpan.FromDays(1)
                    };
                }
            });

            app.UseMultitenancy<AppTenant>();

            app.UseAuthentication();

            app.UseSession();

            app.UseEngineClient(typeof(TenantAppSettingsMiddleware));

            var supportedCultures = new[]
            {
                new CultureInfo("en-US"),
                new CultureInfo("zh-CN"),
                new CultureInfo("zh-HK"),
                new CultureInfo("ru-RU"),
                new CultureInfo("fr-FR"),
                new CultureInfo("ar-SA"),
                new CultureInfo("tr-TR"),
                new CultureInfo("ar-AE"),
                new CultureInfo("th-TH"),
                new CultureInfo("ja-JP"),
                new CultureInfo("ko-KR")
            };

            app.UseRequestLocalization(new RequestLocalizationOptions
            {
                DefaultRequestCulture = new RequestCulture("en-US"),
                SupportedCultures = supportedCultures,
                SupportedUICultures = supportedCultures,
                RequestCultureProviders = new List<IRequestCultureProvider>
                {
                    new QueryStringRequestCultureProvider
                    {
                        QueryStringKey = "CultureCode",
                        UIQueryStringKey = "CultureCode"
                    },
                    new CookieRequestCultureProvider
                    {
                        CookieName = "CultureCode"
                    }
                }
            });

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
