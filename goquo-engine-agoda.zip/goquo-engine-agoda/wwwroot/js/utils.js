﻿/* jQuery extensions */
(function ($) {
    $.fn.ajaxSubmit = function (opt) {
        var f = this;
        f.submit(function (e) {
            e.preventDefault();
            
            if (!f.valid())
                return false;

            if (opt.before)
                opt.before();

            $.ajax({
                cache: false,
                async: true,
                type: f.attr('method').toUpperCase(),
                url: f.attr('action'),
                data: f.serialize(),
                dataType: "json",
                error: function (xhr, status, error) {
                    if (opt.error)
                        opt.error(xhr, status, error);
                },
                success: function (data, status, xhr) {
                    var contentType = xhr.getResponseHeader("Content-Type") || "text/html";
                    if (contentType.indexOf("application/x-javascript") !== -1) {
                        // jQuery already executes JavaScript for us
                        return;
                    }

                    if (opt.success)
                        opt.success(data, status, xhr);
                },
                complete: function (xhr, status) {
                    if (opt.complete)
                        opt.complete(xhr, status);
                }
            });
            return false;
        });
        return this;
    };
})(jQuery);

if (typeof Object.assign != 'function') {
    Object.assign = function (target) {
        'use strict';
        if (target == null) {
            throw new TypeError('Cannot convert undefined or null to object');
        }

        target = Object(target);
        for (var index = 1; index < arguments.length; index++) {
            var source = arguments[index];
            if (source != null) {
                for (var key in source) {
                    if (Object.prototype.hasOwnProperty.call(source, key)) {
                        target[key] = source[key];
                    }
                }
            }
        }
        return target;
    };
}

/* Others */
Number.prototype.padLeft = function (n, str) {
    var x = n - String(this).length + 1;
    if (x <= 0) return this.toString();
    return Array(x).join(str || '0') + this;
};

Array.prototype.smartIndexOf = function (f) {
    if (typeof (f) !== "function") {
        var item = f;
        f = function (x) {
            return x === f;
        }
    };
        
    for (var i = 0; i < this.length; i++) {
        if (f(this[i]))
            return i;
    }
    return -1;
};
Array.prototype.all = function (f) {
    if (this.length == 0) return false;

    for (var i = 0; i < this.length; i++)
        if (!f(this[i])) return false;

    return true;
};
Array.prototype.groupBy = function (prop) {
    return this.reduce(function (groups, item) {
        const val = item[prop];
        groups[val] = groups[val] || [];
        groups[val].push(item);
        return groups;
    }, {});
};
function isValidCoordinate(lat, lon) {
    var x = parseFloat(lat);
    var y = parseFloat(lon);
    if (x == NaN) return false;
    if (y == NaN) return false;
    if (x === 0 && y === 0) return false;
    return true;
};

function postToUrl(url, values) {
    var submitForm = jQuery('<form>', {
        'action': url,
        'method': 'POST',
        'target': '_top'
    });

    if (values) {
        for (var key in values) {
            var value = values[key];
            
            submitForm.append(jQuery('<input>', {
                'name': key,
                'value': value,
                'type': 'hidden'
            }));
        }
    }

    submitForm.hide().appendTo("body").submit();
}