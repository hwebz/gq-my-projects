customMarker.prototype = new google.maps.OverlayView()
customMarker.prototype.draw = function () {
    var self = this
    var div = this.div

    if (!div) {
        div = this.div = document.createElement('div')
        div.className = self.args.class_name

        if (typeof (self.args.marker_id) !== 'undefined') {
            div.dataset.marker_id = self.args.marker_id
        }
        if (typeof (self.args.price) !== 'undefined') {
            div.innerHTML = self.args.price + '<span class="currency">' + self.args.currency + '</span>'
        }

        google.maps.event.addDomListener(div, 'click', function (event) {
            google.maps.event.trigger(self, 'click')
        })

        var panes = self.getPanes()
        panes.overlayImage.appendChild(div)
    }

    var point = self.getProjection().fromLatLngToDivPixel(self.latlng)

    if (point) {
        div.style.left = point.x + 'px'
        div.style.top = point.y + 'px'
    }
}

function customMarker(latlng, map, args) {
    // Initialize all properties.
    this.latlng = latlng
    this.args = args
    // Explicitly call setMap on this overlay.
    this.setMap(map)
}