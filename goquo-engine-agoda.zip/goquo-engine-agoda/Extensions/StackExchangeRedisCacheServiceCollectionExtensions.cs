﻿using AgodaWithClient.Services;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.StackExchangeRedis;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace AgodaWithClient.Extensions
{
    public static class StackExchangeRedisCacheServiceCollectionExtensions
    {
        public static IServiceCollection AddTenantStackExchangeRedisCache(this IServiceCollection services, Action<RedisCacheOptions> setupAction)
        {
            if (services == null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            if (setupAction == null)
            {
                throw new ArgumentNullException(nameof(setupAction));
            }

            services.AddOptions();
            services.Configure(setupAction);
            services.Add(ServiceDescriptor.Singleton<IDistributedCache, AppTenantDistributedCache>());

            return services;
        }
    }
}
