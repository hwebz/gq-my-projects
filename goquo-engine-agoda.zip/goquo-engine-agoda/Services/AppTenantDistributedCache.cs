﻿using GoQuoEngine.Client.Caching;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.StackExchangeRedis;
using Microsoft.Extensions.Options;
using System.Threading;
using System.Threading.Tasks;
using GoQuoEngine.Client.Caching;

namespace AgodaWithClient.Services
{
    public class AppTenantDistributedCache : RedisHybridDistributedCache, IDistributedCache
    {
        private readonly IHttpContextAccessor httpContextAccessor;

        public AppTenantDistributedCache(IOptions<RedisCacheOptions> optionsAccessor, IHttpContextAccessor httpContextAccessor) : base(optionsAccessor)
        {
            this.httpContextAccessor = httpContextAccessor;
        }

        private string GetCacheKey(string key)
        {
            return key + ":" + httpContextAccessor.HttpContext.Items["x-access-site"].ToString();
        }

        byte[] IDistributedCache.Get(string key)
        {
            return Get(GetCacheKey(key));
        }

        Task<byte[]> IDistributedCache.GetAsync(string key, CancellationToken token = default(CancellationToken))
        {
            return GetAsync(GetCacheKey(key), token);
        }

        void IDistributedCache.Refresh(string key)
        {
            Refresh(GetCacheKey(key));
        }

        Task IDistributedCache.RefreshAsync(string key, CancellationToken token = default(CancellationToken))
        {
            return RefreshAsync(GetCacheKey(key), token);
        }

        void IDistributedCache.Remove(string key)
        {
            Remove(GetCacheKey(key));
        }

        Task IDistributedCache.RemoveAsync(string key, CancellationToken token = default(CancellationToken))
        {
            return RemoveAsync(GetCacheKey(key), token);
        }

        void IDistributedCache.Set(string key, byte[] value, DistributedCacheEntryOptions options)
        {
            Set(GetCacheKey(key), value, options);
        }

        Task IDistributedCache.SetAsync(string key, byte[] value, DistributedCacheEntryOptions options, CancellationToken token = default(CancellationToken))
        {
            return SetAsync(GetCacheKey(key), value, options);
        }
    }
}
