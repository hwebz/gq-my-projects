﻿import Vue from 'vue'
import VueRouter from 'vue-router'
import VueResource from 'vue-resource';
import Vuex from 'vuex';
import VueMoment from './Libs/vue-moment'
import MultiLanguage from './Libs/vue-multilanguage'
import VTooltip from 'v-tooltip'
import VueSwal from 'vue-swal'
import resources from './resources'
import LodashForVue from 'lodash-for-vue'

const SearchBox = () => import(
    /* webpackChunkName: "search-box" */ './Components/SearchBox.vue'
);

const Availability = () => import(
    /* webpackChunkName: "availability" */ './Components/Availability.vue'
);

const FullHotelInfo = () => import(
    /* webpackChunkName: "full-hotel-info" */ './Components/FullHotelInfo.vue'
);

const FullHotelInfoPackageSummary = () => import(
    /* webpackChunkName: "full-hotel-info-summary" */ './Components/FullHotelInfoPackageSummary.vue'
);

const TourAvailability = () => import(
    /* webpackChunkName: "tour-availability" */ './Components/TourAvailability.vue'
);

const TransferAvailability = () => import(
    /* webpackChunkName: "transfer-availability" */ './Components/TransferAvailability.vue'
);

const Booking = () => import(
    /* webpackChunkName: "booking" */ './Components/Booking/Booking.vue'
);

const FlightHotelSearch = () => import(
    /* webpackChunkName: "transfer-availability" */ './Components/FlightHotelSearch.vue'
    );

const HotelSearch = () => import(
    /* webpackChunkName: "booking" */ './Components/HotelSearch.vue'
    );

var hdfCultureCode = document.getElementById('hdfCultureCode');
var languages = {
    default: hdfCultureCode ? hdfCultureCode.value.toLowerCase() : 'en-us'
};

for (var key in resources) {
    if (resources.hasOwnProperty(key)) {
        var resourceKey = resources[key];
        for (var culture in resourceKey) {
            if (resourceKey.hasOwnProperty(culture)) {
                if (!languages[culture]) {
                    languages[culture] = {};
                }

                var language = languages[culture];
                language[key] = resourceKey[culture];
            }
        }
    }
}

Vue.use(VueRouter);
Vue.use(Vuex);
Vue.use(VueResource);
Vue.use(VueMoment);
Vue.use(MultiLanguage, languages);
Vue.use(VTooltip);
Vue.use(VueSwal);
Vue.use(LodashForVue);


Vue.filter("formatCurrency", function (value) {
    return (value + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
});

Vue.filter("stringFormat", function (value) {
    var args = Array.prototype.slice.call(arguments, 1);
    return value.replace(/{(\d+)}/g, function (match, number) {
        return typeof args[number] != 'undefined'
            ? args[number]
            : match;
    });
});
Vue.filter("formatDate", function (date, convertType) {
    if (date) {
        return moment(String(date)).format(convertType);
    }
});
Vue.filter("numberRounder", function (value, roundNumber) {
    return (parseFloat(value).toFixed(roundNumber) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
});

Vue.filter("numberRoundRate", function (value, roundNumber) {
    return (Math.round(value * 10) / 10).toFixed(roundNumber);
});

const router = new VueRouter({
    mode: 'history',
    base: __dirname,
    routes: [
        {
            path: '/',
            components: {
                content: SearchBox
            }
        },
        {
            path: '/flight-hotel',
            components: {
                content: FlightHotelSearch
            }
        },
        {
            path: '/hotel',
            components: {
                content: HotelSearch
            }
        },
        {
            path: '/package/search',
            components: {
                content: Availability
            }
        },
        {
            path: '/package/search-hotel',
            components: {
                content: Availability
            }
        },
        {
            path: '/package/hotel/:country/:cityName/:cityCode/:hotelName/:hotelId',
            components: {
                content: FullHotelInfo,
                packageSummary: FullHotelInfoPackageSummary
            }
        },
        {
            path: '/package/search-tour',
            components: {
                content: TourAvailability
            }
        },
        {
            path: '/package/search-transfer',
            components: {
                content: TransferAvailability
            }
        },
        {
            path: '/package/booking/:id',
            components: {
                content: Booking
            }
        }
    ]
});

var store = new Vuex.Store({
    debug: false,
    state: {
        workContext: {},
        hotelInfo: {},
        totalPackagePrice: "-",
        isSearchCompleted: false,
        confirmTaxSuccess: false
    },
    mutations: {
        setWorkContext(state, workContext) {
            state.workContext = workContext;
        },
        setHotelInfo(state, hotelInfo) {
            state.hotelInfo = hotelInfo;
        },
        setIsSearchCompleted(state) {
            state.isSearchCompleted = true;
        },
        setTotalPackagePrice(state, totalPackagePrice) {
            state.totalPackagePrice = totalPackagePrice;
        },
        setConfirmTaxStatus(state, status) {
            state.confirmTaxSuccess = status;
        }
    }
});

var app = document.getElementById("app");
if (app) {
    new Vue({
        router,
        store
    }).$mount('#app');
}