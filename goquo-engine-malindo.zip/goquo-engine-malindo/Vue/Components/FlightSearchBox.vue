﻿<template>
    <div class="flight-hotel-search" ng-controller="flightOnlySearchController" ng-init="init({ isAvailable:1 })">
        <h2>Find Your Perfect Packages</h2>
        <form method="GET" action="/package/start-search" data-val="true">
            <table class="table-layout-search">
                <tr>
                    <td class="width-200">
                        <div class="form-group form-group-icon-left">
                            <i class="icon icon-map input-icon"></i>
                            <label>From</label>
                            <select id="From" name="From"
                                    ng-ajax-select="/api/get-airports"
                                    placeholder="Select Depart Airport"
                                    data-val="true"
                                    maxinput="0"
                                    class="form-control"
                                    data-val-required="Please enter a value."></select>
                        </div>
                    </td>
                    <td class="width-200">
                        <div class="form-group form-group-icon-left">
                            <i class="icon icon-map input-icon"></i>
                            <label>To</label>
                            <select id="To" name="To"
                                    ng-ajax-select="/api/get-airports"
                                    placeholder="Select Arrival Airport"
                                    data-val="true"
                                    class="form-control"
                                    data-val-required="Please enter a value."></select>
                        </div>
                    </td>
                    <td class="width-140">
                        <div class="form-group form-group-icon-left form-group-filled">
                            <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                            <label>Departing Date</label>
                            <input type="text"
                                   ng-date-picker=""
                                   ng-date-picker-check-in="fFlightHotelSearch_CheckIn"
                                   ng-date-picker-check-out="fFlightHotelSearch_CheckOut"
                                   data-start-date-picker=""
                                   ng-model="DepartureDate"
                                   name="DepartureDate"
                                   readonly="readonly"
                                   id="fFlightHotelSearch_DepartureDate"
                                   class="form-control datetime"
                                   autocomplete="off"
                                   data-val="true"
                                   data-val-required="Please enter a value." />
                        </div>
                    </td>
                    <td class="width-140">
                        <div class="form-group form-group-icon-left form-group-filled">
                            <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                            <label>Returning Date</label>
                            <input type="text"
                                   ng-date-picker=""
                                   ng-date-picker-check-in="fFlightHotelSearch_CheckIn"
                                   ng-date-picker-check-out="fFlightHotelSearch_CheckOut"
                                   data-end-date-picker=""
                                   ng-model="ReturnDate"
                                   class="form-control datetime"
                                   name="ReturnDate"
                                   readonly="readonly"
                                   id="fFlightOnly_ReturnDate"
                                   autocomplete="off"
                                   data-val="true"
                                   data-val-required="Please enter a value." />

                            <input type="text"
                                   class="form-control datetime hide"
                                   readonly="readonly"
                                   id="fFlightOnly_ReturnDate_Oneway"
                                   autocomplete="off"
                                   data-val="true"
                                   data-val-required="Please enter a value." disabled="disabled" />
                        </div>
                    </td>

                    <td class="room-column">
                        <div class="form-group form-group-icon-left">
                            <label>{{'Traverller(s)'|translate}}</label>
                            <div ng-flight-only-pax-selector></div>
                        </div>
                    </td>
                    <td class="submit-column">
                        <input type="hidden" name="ProductId" :value="product.id" />
                        <button type="submit" id="searchForm" class="btn btn-block btn-primary">Search for Package</button>
                    </td>
                </tr>
            </table>
            <div>
                <label class="radio-inline">
                    <input type="radio" name="JourneyType" checked="checked" ng-click="checkJourneyType('return')" value="Return" /> Return
                </label>
                <label class="radio-inline">
                    <input type="radio" name="JourneyType" value="OneWay" ng-click="checkJourneyType('oneway')" /> One Way
                </label>
            </div>
        </form>
        <div class="clearfix"></div>
    </div>
</template>

<script>
import {AjaxSelect, DatePicker, PaxSelector} from 'goquo-components'
export default {
    data() {
        return {
          maxRooms: 3,
          PartialStay: false,
          DepartureDate: null,
          ReturnDate: null
        }
    },
    computed: {
    },
    methods: {},
    props: ['product'],
    components: {
      'ajax-select': AjaxSelect,
      'date-picker': DatePicker,
      'pax-selector': PaxSelector
    }
}

</script>