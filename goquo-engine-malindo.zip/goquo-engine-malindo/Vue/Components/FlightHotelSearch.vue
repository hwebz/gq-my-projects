<template>

    <div class="bg-front bg-front-mob-rel">
        <div class="container">
            <div class="search-tabs search-tabs-bg search-tabs-abs-bottom" style="z-index: 10">

                <div class="tabbable">
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation active" v-for="(product, index) in products" v-if="product.type == 'Flight_Hotel'">
                            <a :href="'#product_' + product.id" role="tab" data-toggle="tab">
                                <i :class="product.iconCssClass" v-if="product.iconCssClass != null && product.iconCssClass.length > 0"></i>
                                <span>{{translateText(product.type.toUpperCase(), product.name)}}</span>
                            </a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane booking-tabs fade active in" :id="'product_' + product.id" v-for="(product, index) in products" v-if="product.type == 'Flight_Hotel'">
                            <div class="row">
                                <FlightHotelSearchForm :model="model" :packageQuery="packageQuery" :product="product"></FlightHotelSearchForm>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    import Vue from 'vue';
    import FlightHotelSearchForm from './FlightHotelSearchForm.vue'

    export default {
        name: "SearchBox",
        data() {
            return {
                products: [],
                packageQuery: null,
                model: {
                    from: null,
                    to: null,
                    toFullText: null,
                    departureDate: null,
                    returnDate: null,
                    checkIn: null,
                    checkOut: null,
                    partialStay: false,
                    cultureCode: null,
                    promoCode: null
                }
            };
        },
        created() {
            var self = this;
            self.model.promoCode = self.$route.query.PromoCode;
            self.model.departureDate = Vue.moment();
            $.post('/package/work-context', function (data) {
                self.$store.commit('setWorkContext', data);
                self.products = data.products;
            });
        },
        methods: {
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            }
        },
        components: { FlightHotelSearchForm }
    }
</script>
