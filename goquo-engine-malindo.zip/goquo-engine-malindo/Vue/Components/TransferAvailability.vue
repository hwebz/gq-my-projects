﻿<template>
    <div v-if="packageQuery" id="list-result">
        <SessionTimeout :packageId="packageQuery.id" :secondTimeout="packageQuery.ttl"></SessionTimeout>
        <div class="book-loading-body" v-show="loading.bookingTransfer">
            <div class="book-loading-caption">
                <img src="/images/small_loading.gif" alt="loader" />
                <span v-lang.BOOKING_TRANSFER>Loading Transfers...</span>
            </div>
        </div>

        <section class="error-overlay" v-if="hasErrorMessage">
            <div class="container">
                <div class="error-overlay-content">
                    <img class="not-found" src="/images/not-found.svg" alt="not-found" />
                    <h3>{{errorMessage}}</h3>
                    <a class="btn btn-lg btn-backtohome" href="/">
                        <span v-lang.BACKTOHOME>Back to Home</span>
                    </a>
                    <a class="btn btn-primary btn-lg" data-toggle="modal" data-target="#modifySearch">
                        <span v-lang.MODIFY_SEARCH>MODIFY SEARCH</span>
                    </a>
                </div>
            </div>
        </section>
        <div id="page-loader" class="fade in background-@cultureCode"></div>
        <div id="transferPage" class="availability">
            <div class="container">
                <!--Modify search start-->
                <div class="modal fade booking-tabs mod-search loadCal" id="modifySearch" role="search" aria-labelledby="myModalLabel">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content" style="width:1000px">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title" id="myModalLabel" v-lang.SEARCH_FOR_AIRPORT_TRANSFER>Search for Airport Transfers</h4>
                            </div>
                            <div class="modal-body clearfix">
                                <TransferSearchBox :product="product" :hotelTransfer="hotelTransfer"></TransferSearchBox>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Modify End start-->
                <div class="row hotel-details">
                    <div class="col-xs-12 col-sm-12 col-md-8">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="title-section">
                                    <h4 class="title"><span v-lang.CHOOSE_YOUR_TRANSFER_IN>Choose your Transfer in</span> <span class="txt-primary">{{packageQuery.toCityName}}</span></h4>
                                </div>
                                <span class="text-right">
                                    <a class="btn btn-primary modify-search-btn" data-toggle="modal" data-target="#modifySearch">
                                        <span v-lang.MODIFY_SEARCH>MODIFY SEARCH</span>
                                    </a>
                                </span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="alert alert-danger panel-collapse" v-show="hasErrorMessage" v-html="errorMessage" style="margin: 0 0 25px 0;"></div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="date-infor">
                                    <div v-if="packageQuery.transferSearchInfo.transferType === 'Return'">
                                        <div class="separated">
                                            <strong v-lang.DEPARTING>Departing</strong><span>: {{packageQuery.departureDate | formatDate('ddd, DD MMM YYYY')}} {{packageQuery.transferSearchInfo.travelTime}}</span>
                                            <span class="horizontal-space"></span>
                                        </div>
                                        <div class="separated">
                                            <strong v-lang.RETURNING>Returning</strong><span>: {{packageQuery.returnDate | formatDate('ddd, DD MMM YYYY')}} {{packageQuery.transferSearchInfo.returnTime}}</span>
                                            <span class="horizontal-space"></span>
                                        </div>
                                    </div>
                                    <div v-if="packageQuery.transferSearchInfo.transferType === 'FromAirport'">
                                        <div class="separated">
                                            <strong v-lang.DEPARTING>Departing</strong><span>: {{packageQuery.departureDate | formatDate('ddd, DD MMM YYYY')}} {{packageQuery.transferSearchInfo.travelTime}}</span>
                                            <span class="horizontal-space"></span>
                                        </div>
                                    </div>
                                    <div v-if="packageQuery.transferSearchInfo.transferType === 'ToAirport'">
                                        <div class="separated">
                                            <strong v-lang.RETURNING>Returning</strong><span>: {{packageQuery.departureDate | formatDate('ddd, DD MMM YYYY')}} {{packageQuery.transferSearchInfo.travelTime}}</span>
                                            <span class="horizontal-space"></span>
                                        </div>
                                    </div>

                                    <div class="separated">
                                        <span v-if="adults > 0"><strong v-lang.GUEST>Guest(s)</strong>:  <span v-lang.ADULTS>Adult(s)</span> x {{adults}}</span>
                                        <span v-if="childs > 0">, <span v-lang.CHILDREN>Children</span> x {{childs}}</span>
                                        <span v-if="infants > 0">, <span v-lang.INFANTS>Infant(s)</span> x {{infants}}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-7 col-md-8" id="transfer-main-content">
                        <div v-if="isSearchCompleted && hasArrivalTransfer" class="transfer-list transfer-arrival">
                            <h4 v-lang.ARRIVAL_PICK_UP_TRANSFER>Arrival Pick-up Transfer</h4>
                            <div class="location">
                                <p class="sub-title">
                                    <strong v-lang.Pick_UP_AT>Pick-up at</strong>: <span>{{packageQuery.toAirportName}} ({{packageQuery.to}})</span>
                                    <br />
                                    <span v-if="hotelTransfer">
                                        <strong v-lang.DROP_OFF_AT>Drop-off at</strong>: <span>{{hotelTransfer.name + ', ' + hotelTransfer.address}}</span>
                                    </span>
                                </p>
                            </div>
                            <div class="hotel-list cursor-default" v-for="(transfer,transferIndex) in arrivalTransfers">
                                <div class="row">
                                    <div class="col-xs-12">
                                        <div class="result-item hotel-result col-xs-12 no-padding">
                                            <div class="result-content result-left">
                                                <div v-if="transfer.images.length > 0" :title="transfer.name" :style="{backgroundImage: `url('${transfer.images[0].url}')`}"
                                                     class="result-img">
                                                </div>
                                                <div v-if="transfer.images.length == 0" :title="transfer.name" :style="{backgroundImage: `url('/images/transfer-default.jpg')`}"
                                                     class="result-img">
                                                </div>
                                            </div>
                                            <div class="result-content result-right transfer">
                                                <div class="result-include">
                                                    <small>from</small>
                                                    <div class="result-price" v-if="!transferSelected.arrivalTransfer || transferSelected.arrivalTransfer.transferId != transfer.transferId">
                                                        <strong>{{packageQuery.currency}}&nbsp;<span>{{transfer.selectedVehicle.totalPrice | numberRounder(packageQuery.currencyDecimals)}}</span></strong>
                                                    </div>
                                                    <div class="result-price" v-else>
                                                        <strong>{{packageQuery.currency}}&nbsp;<span>{{transferSelected.arrivalTransfer.totalPrice | numberRounder(packageQuery.currencyDecimals)}}</span></strong>
                                                    </div>
                                                </div>
                                                <div class="result-view">
                                                    <span v-show="transfer.selected || transfer.isExpand" class="btn btn-default" data-transfer-type="Arrivaltransfer" @click="toggle($event,transfer,arrivalTransfers)" v-lang.SELECTED_TRANSFER>Selected Transfer</span>

                                                    <span v-show="!transfer.selected && !transfer.isExpand && !hasAddArrivalTransfer" class="btn btn-default" data-transfer-type="Arrivaltransfer" @click="toggle($event,transfer,arrivalTransfers)" v-lang.SELECT_TRANSFER> Select Transfer </span>

                                                    <span v-show="!transfer.selected && !transfer.isExpand && hasAddArrivalTransfer" class="btn btn-default" data-transfer-type="Arrivaltransfer" @click="toggle($event,transfer,arrivalTransfers)" v-lang.CHANGE_TO_THIS_TRANSFER> CHANGE TO THIS TRANSFER</span>
                                                </div>
                                            </div>
                                            <div class="result-content result-center">
                                                <div class="result-center-hotelinfo">
                                                    <h4>
                                                        <a class="mb10" @click="showTransferInfo(transfer)" v-show="transfer.name && transfer.name != ''">
                                                            {{transfer.name}}
                                                        </a>
                                                        <a class="mb10" @click="showTransferInfo(transfer)" v-if="transfer.accommodations.length > 0" v-show="transfer.name && transfer.name != ''">
                                                            Transfer from {{packageQuery.toAirportName}} to {{transfer.accommodations[0].name}}
                                                        </a>
                                                        <a class="view-more" @click="showTransferInfo(transfer)">
                                                            <i class="icon icon-info-circle" aria-hidden="true"></i>
                                                        </a>
                                                    </h4>
                                                </div>
                                                <div class="result-center-packageinfo">
                                                    <div class="flight-info">
                                                        <p v-show="transfer.approximateTransferTime!=''">
                                                            <i class="icon icon-clock" aria-hidden="true"></i>
                                                            <span><strong v-lang.ESTIMATE_TRANSFER_TIME>Estimate Transfer Time</strong>: <span>{{transfer.approximateTransferTime}}</span></span>
                                                        </p>
                                                        <p v-show="transfer.allowForCheckInTime!=''">
                                                            <i class="icon icon-clock" aria-hidden="true"></i>
                                                            <span><strong v-lang.ESTIMATE_CHECKIN_TIME>Estimate Checkin Time</strong>: <span>{{transfer.allowForCheckInTime}}</span></span>
                                                        </p>
                                                        <p v-show="transfer.selectedVehicle.maxPassengers != 0">
                                                            <i class="icon icon-group" aria-hidden="true"></i>
                                                            <span><strong v-lang.CAPACITY>Capacity</strong>: <span>{{transfer.selectedVehicle.minPassengers}} - {{transfer.selectedVehicle.maxPassengers}} <span v-lang.PASSENGERS>passengers</span></span></span>
                                                        </p>
                                                        <p v-show="transfer.selectedVehicle.maxLuggage != 0">
                                                            <i class="icon icon-baggage" aria-hidden="true"></i>
                                                            <span><strong v-lang.LUGGAGE>Luggage</strong>: <span>{{transfer.selectedVehicle.maxLuggage}}</span></span>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <!-- v-if="transfer.providerCode == 'HolidayTaxis'" -->
                                    <div class="col-xs-12">
                                        <div :id="'transfer'+ transfer.id.trim()" class="toggle-panel depart-transfers" :style="displaySelected(transfer.isExpand)">
                                            <form method="POST" action="/BookingTransfer/Package" data-val="true" v-on:submit.prevent="bookingTransfer($event, transfer, transfer.selectedVehicle,transferIndex)">
                                                <div class="panel-custom">
                                                    <div class="row high-zindex">
                                                        <div class="col-xs-12 col-sm-3">
                                                            <div class="input-group has-margin">
                                                                <span class="input-group-addon" v-lang.FLIGHT_NO>
                                                                    Flight No
                                                                </span>
                                                                <input name="FlightNo"
                                                                       class="form-control"
                                                                       max-length="15" type="text"
                                                                       v-model="transfer.selectedVehicle.flightNo"
                                                                       data-val="true"
                                                                       :disabled="transfer.selectedVehicle.selected"
                                                                       @change="autoFillFlightNo(arrivalTransfers,$event)" />
                                                            </div>
                                                            <span data-valmsg-for="FlightNo" data-valmsg-replace="true"></span>
                                                        </div>
                                                        <div class="col-xs-12 col-sm-4">
                                                            <div class="input-group input-vehicle has-margin">
                                                                <span class="sbg-Color input-group-addon" v-lang.NUMBER_OF_VEHICLE>
                                                                    Number of Vehicle
                                                                </span>
                                                                <select class="form-control"
                                                                        @change="changeNoOfVehicle(transfer, transfer.selectedVehicle)"
                                                                        name="NoOfVehicle"
                                                                        v-model="transfer.selectedVehicle.noOfVehicle"
                                                                        data-val="true"
                                                                        :disabled="transfer.selectedVehicle.selected"
                                                                        required="required"
                                                                        aria-required="true"
                                                                        :data-val-required="translateText('REQUIRED', 'Required')">
                                                                    <option v-for="n in range(getMinVehicle(transfer.selectedVehicle), getMaxVehicle(transfer.selectedVehicle))" :value="n">{{n}}</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-xs-12 col-sm-5" v-DateTimePicker="{ departureDate: transfer.selectedVehicle.pickUpDate, departTime:transfer.selectedVehicle.pickUpTime , originalReturnDate: packageQuery.departureDate, isChangeDateTime: isChangeDateTime , transferType: packageQuery.transferSearchInfo.transferType}">
                                                            <div class='input-group has-margin date datetimepicker PickupDateTime DepartureDateSearch' data-date-input="PickUpDate" data-time-input="PickUpTime">
                                                                <span class="input-group-addon" :data-date-selected="packageQuery.departureDate | formatDate('YYYY-MM-DD')+' '+packageQuery.transferSearchInfo.travelTime" v-lang.PICK_UP_ON>
                                                                    Pick-up on
                                                                </span>
                                                                <input type="hidden" name="PickUpDate" />
                                                                <input type="hidden" name="PickUpTime" />
                                                                <input type='text' class="form-control ignore" name="PickUpDateTimePicker" onkeydown="return false;" placeholder="ddd, dd MMM yyyy HH:mm" :disabled="transfer.selectedVehicle.selected" />
                                                            </div>
                                                            <span data-valmsg-for="PickUpDateTimePicker" data-valmsg-replace="true"></span>
                                                        </div>
                                                    </div>
                                                    <input type="hidden" name="AirportCode" v-model="transfer.selectedVehicle.airportCode" />
                                                    <input type="hidden" disabled="disabled" v-model="transfer.selectedVehicle.hotelCode" name="HotelCode" class="form-control" />
                                                    <input type="hidden" name="HotelName" v-model="transfer.selectedVehicle.HotelName" :disabled="transfer.selected || (transferSelected != null && transferSelected.arrivalTransfer)" />
                                                    <input name="VehicleCode" class="form-control input-flight-no"
                                                           max-length="15"
                                                           type="hidden" :disabled="transfer.selected || (transferSelected != null && transferSelected.arrivalTransfer)"
                                                           v-model="transfer.selectedVehicle.vehicleCode"
                                                           data-val="true" />
                                                    <div class="row">
                                                        <div class="price-details price-detRight">
                                                        </div>
                                                        <div class="col-xs-12 have-top-margin">
                                                            <button type="submit" class="btn btn-success btn-select pull-right"
                                                                    :class="transfer.selected ? 'btn-success' : 'btn-primary'"
                                                                    :disabled="transfer.selectedVehicle.selected">
                                                                <span class="text-uppercase" v-show="!transfer.selectedVehicle.selected" v-lang.ADD_THIS_TRANSFER>
                                                                    Add This Transfer
                                                                </span>
                                                                <span v-show="transfer.selectedVehicle.selected" class="text-uppercase">
                                                                    <span class="icon icon-check"></span> <span v-lang.TRANSFER_ADDED>Transfer Added</span>
                                                                </span>
                                                            </button>
                                                            <a class="btn pull-right remove-product" @click="removeTransfer($event, transfer, transfer.selectedVehicle,transferIndex)" v-show="transfer.selectedVehicle.selected">
                                                                <span>
                                                                    <i class="icon icon-times"></i> <span v-lang.REMOVE>Remove</span>
                                                                </span>
                                                            </a>
                                                            <a class="btn pull-right bt-loading" v-show="transfer.selectedVehicle.loading">
                                                                <i class="icon icon-spin">
                                                                </i><span v-lang.PROCESSING>Processing...</span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div v-if="isSearchCompleted && hasDepartureTransfer" class="transfer-list transfer-departure">
                            <h4 v-lang.DEPARTUR_PICK_UP_TRANSFER>Departure Pick-up Transfer</h4>
                            <div class="location">
                                <p class="sub-title">
                                    <strong v-lang.Pick_UP_AT>Pick-up at</strong>: <span v-if="hotelTransfer">{{hotelTransfer.name + ', ' + hotelTransfer.address}}</span>
                                    <br />
                                    <span v-if="hotelTransfer">
                                        <strong v-lang.DROP_OFF_AT>Drop-off at</strong>: <span>{{packageQuery.toAirportName}} ({{packageQuery.to}})</span>
                                    </span>
                                </p>
                            </div>
                            <div class="hotel-list cursor-default" v-for="(transfer,transferIndex) in departureTransfers">
                                <div class="row">
                                    <div class="col-xs-12">
                                        <div class="result-item hotel-result col-xs-12 no-padding">
                                            <div class="result-content result-left">
                                                <div v-if="transfer.images.length > 0" :title="transfer.name" :style="{backgroundImage: `url('${transfer.images[0].url}')`}"
                                                     class="result-img">
                                                </div>
                                                <div v-if="transfer.images.length == 0" :title="transfer.name" :style="{backgroundImage: `url('/images/transfer-default.jpg')`}"
                                                     class="result-img">
                                                </div>
                                            </div>
                                            <div class="result-content result-right transfer">
                                                <div class="result-include">
                                                    <small>from</small>
                                                    <div class="result-price" v-if="!transferSelected.departureTransfer || transferSelected.departureTransfer.transferId != transfer.transferId">
                                                        <strong>{{packageQuery.currency}}&nbsp;<span>{{transfer.selectedVehicle.totalPrice | numberRounder(packageQuery.currencyDecimals)}}</span></strong>
                                                    </div>
                                                    <div class="result-price" v-else>
                                                        <strong>{{packageQuery.currency}}&nbsp;<span>{{transferSelected.departureTransfer.totalPrice | numberRounder(packageQuery.currencyDecimals)}}</span></strong>
                                                    </div>
                                                </div>
                                                <div class="result-view">
                                                    <span v-show="transfer.selected || transfer.isExpand" class="btn btn-default" data-transfer-type="Departuretransfer" @click="toggle($event,transfer,departureTransfer)" v-lang.SELECTED_TRANSFER>Selected Transfer</span>

                                                    <span v-show="!transfer.selected && !transfer.isExpand && !hasAddDepartureTransfer" class="btn btn-default" data-transfer-type="Departuretransfer" @click="toggle($event,transfer,departureTransfer)" v-lang.SELECT_TRANSFER> Select Transfer </span>

                                                    <span v-show="!transfer.selected && !transfer.isExpand && hasAddDepartureTransfer" class="btn btn-default" data-transfer-type="Departuretransfer" @click="toggle($event,transfer,departureTransfer)" v-lang.CHANGE_TO_THIS_TRANSFER> CHANGE TO THIS TRANSFER</span>
                                                </div>
                                            </div>
                                            <div class="result-content result-center">
                                                <div class="result-center-hotelinfo">
                                                    <h4>
                                                        <a class="mb10" @click="showTransferInfo(transfer)" v-show="transfer.name && transfer.name != ''">
                                                            {{transfer.name}}
                                                        </a>
                                                        <a class="mb10" @click="showTransferInfo(transfer)" v-if="transfer.accommodations.length > 0" v-show="transfer.name && transfer.name != ''">
                                                            Transfer from {{packageQuery.toAirportName}} to {{transfer.accommodations[0].name}}
                                                        </a>
                                                        <a class="view-more" @click="showTransferInfo(transfer)">
                                                            <i class="icon icon-info-circle" aria-hidden="true"></i>
                                                        </a>
                                                    </h4>
                                                </div>
                                                <div class="result-center-packageinfo">
                                                    <div class="flight-info">
                                                        <p v-show="transfer.approximateTransferTime!=''">
                                                            <i class="icon icon-clock" aria-hidden="true"></i>
                                                            <span><strong v-lang.ESTIMATE_TRANSFER_TIME>Estimate Transfer Time</strong>: <span>{{transfer.approximateTransferTime}}</span></span>
                                                        </p>
                                                        <p v-show="transfer.allowForCheckInTime!=''">
                                                            <i class="icon icon-clock" aria-hidden="true"></i>
                                                            <span><strong v-lang.ESTIMATE_CHECKIN_TIME>Estimate Checkin Time</strong>: <span>{{transfer.allowForCheckInTime}}</span></span>
                                                        </p>
                                                        <p v-show="transfer.selectedVehicle.maxPassengers != 0">
                                                            <i class="icon icon-group" aria-hidden="true"></i>
                                                            <span><strong v-lang.CAPACITY>Capacity</strong>: <span>{{transfer.selectedVehicle.minPassengers}} - {{transfer.selectedVehicle.maxPassengers}} <span v-lang.PASSENGERS>passengers</span></span></span>
                                                        </p>
                                                        <p v-show="transfer.selectedVehicle.maxLuggage != 0">
                                                            <i class="icon icon-baggage" aria-hidden="true"></i>
                                                            <span><strong v-lang.LUGGAGE>Luggage</strong>: <span>{{transfer.selectedVehicle.maxLuggage}}</span></span>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <!--  v-if="transfer.providerCode == 'HolidayTaxis'" -->
                                    <div class="col-xs-12">
                                        <div :id="'transfer'+ transfer.id.trim()" class="toggle-panel return-transfers" :style="displaySelected(transfer.isExpand)">
                                            <form method="POST" action="/BookingTransfer/Package" data-val="true" v-on:submit.prevent="bookingTransfer($event,transfer, transfer.selectedVehicle,transferIndex)">
                                                <div class="panel-custom">
                                                    <div class="row high-zindex">
                                                        <div class="col-xs-12 col-sm-3">
                                                            <div class="input-group has-margin">
                                                                <span class="input-group-addon" v-lang.FLIGHT_NO>
                                                                    Flight No
                                                                </span>
                                                                <input name="FlightNo"
                                                                       class="form-control"
                                                                       max-length="15" type="text"
                                                                       v-model="transfer.selectedVehicle.flightNo"
                                                                       data-val="true"
                                                                       :disabled="transfer.selectedVehicle.selected"
                                                                       @change="autoFillFlightNo(departureTransfers,$event)"
                                                                       @click="clickFlightNo" />
                                                            </div>
                                                            <span data-valmsg-for="FlightNo" data-valmsg-replace="true"></span>
                                                        </div>
                                                        <div class="col-xs-12 col-sm-4">
                                                            <div class="input-group input-vehicle has-margin">
                                                                <span class="sbg-Color input-group-addon" v-lang.NUMBER_OF_VEHICLE>
                                                                    Number of Vehicle
                                                                </span>
                                                                <select class="form-control"
                                                                        @change="changeNoOfVehicle(transfer, transfer.selectedVehicle)"
                                                                        name="NoOfVehicle"
                                                                        v-model="transfer.selectedVehicle.noOfVehicle"
                                                                        data-val="true"
                                                                        :disabled="transfer.selectedVehicle.selected"
                                                                        required="required"
                                                                        aria-required="true"
                                                                        :data-val-required="translateText('REQUIRED', 'Required')">
                                                                    <option v-for="n in range(getMinVehicle(transfer.selectedVehicle), getMaxVehicle(transfer.selectedVehicle))" :value="n">{{n}}</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div v-if="packageQuery.transferSearchInfo.transferType != 'ToAirport'" class="col-xs-12 col-sm-5" v-DateTimePicker="{ returnDate: transfer.selectedVehicle.pickUpDate, checkInDate:packageQuery.departureDate, returnTime:transfer.selectedVehicle.pickUpTime, originalReturnDate: packageQuery.returnDate, isChangeDateTime: isChangeDateTime}">
                                                            <div class='input-group has-margin date datetimepicker PickupDateTime ReturnDateSearch' data-date-input="PickUpDate" data-time-input="PickUpTime">
                                                                <span class="input-group-addon" :data-date-selected="packageQuery.returnDate | formatDate('YYYY-MM-DD')+' '+packageQuery.transferSearchInfo.travelTime" v-lang.PICK_UP_ON>
                                                                    Pick-up on
                                                                </span>
                                                                <input type="hidden" name="PickUpDate" />
                                                                <input type="hidden" name="PickUpTime" />
                                                                <input type='text' class="form-control ignore" name="PickUpDateTimePicker" onkeydown="return false;" placeholder="ddd, dd MMM yyyy HH:mm" :disabled="transfer.selectedVehicle.selected" />
                                                            </div>
                                                            <span data-valmsg-for="PickUpDateTimePicker" data-valmsg-replace="true"></span>
                                                        </div>
                                                        <div v-else class="col-xs-12 col-sm-5" v-DateTimePicker="{ departureDate: transfer.selectedVehicle.pickUpDate, departTime:transfer.selectedVehicle.pickUpTime , originalReturnDate: packageQuery.departureDate, isChangeDateTime: isChangeDateTime, transferType: packageQuery.transferSearchInfo.transferType}">
                                                            <div class='input-group has-margin date datetimepicker PickupDateTime DepartureDateSearch' data-date-input="PickUpDate" data-time-input="PickUpTime">
                                                                <span class="input-group-addon" :data-date-selected="packageQuery.departureDate | formatDate('YYYY-MM-DD')+' '+packageQuery.transferSearchInfo.travelTime" v-lang.PICK_UP_ON>
                                                                    Pick-up on
                                                                </span>
                                                                <input type="hidden" name="PickUpDate" />
                                                                <input type="hidden" name="PickUpTime" />
                                                                <input type='text' class="form-control ignore" name="PickUpDateTimePicker" onkeydown="return false;" placeholder="ddd, dd MMM yyyy HH:mm" :disabled="transfer.selectedVehicle.selected" />
                                                            </div>
                                                            <span data-valmsg-for="PickUpDateTimePicker" data-valmsg-replace="true"></span>
                                                        </div>

                                                    </div>
                                                    <input type="hidden" disabled="disabled" v-model="transfer.selectedVehicle.hotelCode" name="HotelCode" class="form-control" />
                                                    <input type="hidden" name="AirportCode" :value="packageQuery.to" />
                                                    <input type="hidden" name="HotelName" v-model="transfer.selectedVehicle.hotelName"
                                                           :disabled="transfer.selected || (transferSelected != null && transferSelected.departureTransfer)" />
                                                    <input name="VehicleCode" class="form-control input-flight-no"
                                                           max-length="15"
                                                           type="hidden" :disabled="transfer.selected || (transferSelected != null && transferSelected.departureTransfer)"
                                                           v-model="transfer.selectedVehicle.vehicleCode"
                                                           data-val="true" />
                                                    <div class="row">
                                                        <div class="price-details price-detRight">
                                                        </div>
                                                        <div class="col-xs-12 have-top-margin">
                                                            <button type="submit" class="btn btn-success btn-select pull-right"
                                                                    :class="transfer.selected ? 'btn-success' : 'btn-primary'"
                                                                    :disabled="transfer.selectedVehicle.selected">
                                                                <span class="text-uppercase" v-show="!transfer.selectedVehicle.selected" v-lang.ADD_THIS_TRANSFER>
                                                                    Add This Transfer
                                                                </span>
                                                                <span v-show="transfer.selectedVehicle.selected" class="text-uppercase">
                                                                    <span class="icon icon-check"></span> <span v-lang.TRANSFER_ADDED>Transfer Added</span>
                                                                </span>
                                                            </button>
                                                            <a class="btn pull-right remove-product" @click="removeTransfer($event, transfer, transfer.selectedVehicle,transferIndex)" v-show="transfer.selectedVehicle.selected">
                                                                <span>
                                                                    <i class="icon icon-times"></i> <span v-lang.REMOVE>Remove</span>
                                                                </span>
                                                            </a>
                                                            <a class="btn pull-right bt-loading" v-show="transfer.selectedVehicle.loading">
                                                                <i class="icon icon-spin">
                                                                </i><span v-lang.PROCESSING>Processing...</span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" v-if="pagination.totalTransfers > 1">
                            <div class="col-xs-12">
                                <p>
                                    <small>
                                        <span v-lang.SHOWING_X_OF_X_TRANSFERS="{0: pagination.totalTransfers, 1: packageQuery.toCityName, 2: getFromTransferPerPage(pagination.current, pagination.transferPerPage), 3: getToTransferPerPage(pagination.current, pagination.transferPerPage, pagination.totalTransfers)}"></span>
                                    </small>
                                </p>
                                <nav aria-label="pagination">
                                    <ul class="pager">
                                        <li class="previous scroll-target">
                                            <a href="javascript:void(0)" v-bind:class="{'disabled': pagination.current === 1}" @click="(pagination.current === 1) || gotoTransferPage(pagination.current - 1)">
                                                <i class="icon icon-left-arrow"></i>
                                            </a>
                                        </li>
                                        <li class="text-center">
                                            <p v-lang.PAGE_X_OF_X="{0:pagination.current,1:pagination.totalPages}">
                                                <span :class="{'is-visible': pagination.current > 2}" @click="gotoTransferPage(1)" v-lang.GO_TO_FIRST_PAGE> Go to first page </span>
                                            </p>
                                        </li>
                                        <li class="next scroll-target" data-target="#trasfer-result">
                                            <a href="javascript:void(0)" :class="{'disabled': pagination.current === pagination.totalPages}" @click="(pagination.current === pagination.totalPages) || gotoTransferPage(pagination.current + 1)">
                                                <i class="icon icon-right-arrow"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-5 col-md-4">
                        <div class="panel-section transfer-summary" id="transfer-right-nav">
                            <div id="bookingSummary">
                                <BookingSummary :packageQuery="packageQuery" :addons="addOnSelecteds" :seatSelecteds="seatSelecteds" :currentSection="currentSection" ref="bookingSummary" v-on:onCalcPromoPrice="calcPromoPrice" :productType="product.type"></BookingSummary>
                                <div class="bk-footer-price" v-if="arrivalTransfer !== null">
                                    <a tabindex="0" data-toggle="modal" data-target="#showPriceSummary">
                                        <strong>
                                            {{packageQuery.currency}} <span>{{packageQuery.priceSummary.totalPrice | formatCurrency }}</span>
                                        </strong>
                                        <small>
                                            <span class="view-full-text" v-lang.FULL_PRICE_SUMMARY>Full price summary</span> <span class="icon icon-hand-pointer view-full-icon"></span>
                                        </small>
                                    </a>
                                </div>
                                <div class="bk-summary-list" v-if="transferSelected && (transferSelected.arrivalTransfer || transferSelected.departureTransfer)">
                                    <div v-if="nextButtonUrl">
                                        <a href="#" @click="checkBookingTransfer(nextButtonUrl)" class="btn btn-success btn-lg btn-block" v-lang.CONTINUE>
                                            Continue
                                        </a>
                                    </div>

                                    <div v-if="skipButtonUrl">
                                        <a :href="skipButtonUrl" class="btn btn-warning btn-lg btn-block" v-lang.SKIP_TRANSFER>
                                            Skip Transfer
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade bk-modal" id="showPriceSummary" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel" v-lang.PRICE_SUMMARY>Price Summary</h4>
                    </div>
                    <div class="modal-body">
                        <PriceSummary ref="priceSummary" :packageQuery="packageQuery" :addons="addOnSelecteds" :seatSelecteds="seatSelecteds" :currentSection="currentSection" :promoError="promoError" @onCalcPromoPriceChanged="onCalcPromoPriceChanged"></PriceSummary>
                    </div>
                </div>
            </div>
        </div>
        <!-- show transfer infor -->
        <div class="modal fade" id="transferInfor" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">{{transferInfo.name}}</h4>
                    </div>
                    <div class="modal-body">
                        <div v-show="transferInfo.description.length > 0">
                            <h4 v-lang.DESCRIPTION>Description</h4>
                            <p v-html="transferInfo.description"></p>
                        </div>
                        <div v-show="transferInfo.meetingPoint.length > 0">
                            <h4 v-lang.MEETING_POINT>Meeting Point</h4>
                            <p v-html="transferInfo.meetingPoint"></p>
                        </div>
                        <div v-show="transferInfo.conditions.length > 0">
                            <h4 v-lang.TRANSFER_CONDITIONS>Transfer Conditions</h4>
                            <div>
                                <p v-for="condition in transferInfo.conditions" v-html="condition"></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import Vue from 'vue'
    import BookingSummary from './Booking/BookingSummary.vue'
    import httpQueueService from './Booking/httpQueueService'
    import TransferSearchBox from './TransferSearchBox.vue'
    import PriceSummary from './Booking/PriceSummary.vue';
    import SessionTimeout from './SessionTimeout.vue'

    export default {
        mixins: [httpQueueService],
        components: { BookingSummary, TransferSearchBox, SessionTimeout, PriceSummary },
        data() {
            return {
                packageQuery: null,
                transfers: [],
                hasErrorMessage: false,
                errorMessage: "",
                isSearchCompleted: false,
                hasArrivalTransfer: false,
                hasDepartureTransfer: false,
                arrivalTransfer: null,
                departureTransfer: null,
                adults: 0,
                childs: 0,
                infants: 0,
                transferFilter: {
                    sortOrderBy: "Price",
                    sortOrderByAsc: true,
                    minPriceTransfer: 0,
                    maxPriceTransfer: 0
                },
                transferSelected: {},
                departureTransfers: [],
                arrivalTransfers: [],
                categories: [],
                hotelInfo: [],
                sortOrderBy: "Price",
                sortOrderByAsc: true,
                pagination: {
                    current: 1,
                    transferPerPage: 10,
                    totalTransfers: 0,
                    totalPages: 1,
                    currentRowOnPage: 0
                },
                nextButtonUrl: null,
                skipButtonUrl: null,
                addOnSelecteds: [],
                seatSelecteds: [],
                currentSection: 1,
                transferInfo: {
                    name: '',
                    description: '',
                    meetingPoint: '',
                    conditions: [],
                },
                loading: {
                    bookingTransfer: true
                },
                product: [],
                hotelTransfer: [],
                regionInfo: [],
                flightNo: '',
                isChangeDateTime: true,
                hasAddArrivalTransfer: false,
                hasAddDepartureTransfer: false,
                arrivalDateSelected: null,
                departureDateSelected: null,
                promoCode: null,
                promoError: null
            }
        },
        created() {
            var self = this;
            var packageId = $('#PackageId').val();
            this.nextButtonUrl = $('#NextButtonUrl').val();
            this.skipButtonUrl = $('#SkipButtonUrl').val();
            $.post('/package/work-context/' + packageId, function (data) {
                self.$store.commit('setWorkContext', data);
                data.packageQuery.departureDate = moment.utc(data.packageQuery.departureDate);
                data.packageQuery.returnDate = moment.utc(data.packageQuery.returnDate);
                data.packageQuery.checkIn = moment.utc(data.packageQuery.checkIn);
                data.packageQuery.checkOut = moment.utc(data.packageQuery.checkOut);
                self.packageQuery = data.packageQuery;

                if (self.packageQuery.departureTransfer == undefined) {
                    Vue.set(self.packageQuery, "departureTransfer", []);
                }
                if (self.packageQuery.arrivalTransfer == undefined) {
                    Vue.set(self.packageQuery, "arrivalTransfer", []);
                }

                if (self.packageQuery.transferSearchInfo && self.packageQuery.transferSearchInfo.travelTime && self.packageQuery.transferSearchInfo.returnTime) {
                    var strArr = self.packageQuery.transferSearchInfo.travelTime.split(":");
                    if (strArr && strArr.length > 0) {
                        self.packageQuery.departureDate.set({ hour: strArr[0], minute: strArr[1] });
                    }

                    strArr = self.packageQuery.transferSearchInfo.returnTime.split(":");
                    if (strArr && strArr.length > 0) {
                        self.packageQuery.returnDate.set({ hour: strArr[0], minute: strArr[1] });
                    }
                }

                self.product = data.product;
                self.getRegionInfo(function (result) {
                    self.hotelTransfer = result;
                });

                self.createPingRequest();

                for (var i = 0; i < self.packageQuery.paxInfos.length; i++) {
                    self.adults += self.packageQuery.paxInfos[i].adultCount;
                    self.childs += self.packageQuery.paxInfos[i].childCount;
                    self.infants += self.packageQuery.paxInfos[i].infantCount;
                }

                self.totalPax = self.adults + self.childs + self.infants;
            });
        },
        methods: {
            createPingRequest: function () {
                var self = this;
                this.pingCount++;

                if (this.pingCount >= 10) {
                    return;
                }

                var productTypes = [{
                    productType: 8,
                    storedKey: null
                }];

                $.post("/package/product-status/" + self.packageQuery.id, { productTypeStatuses: productTypes }, function (data) {
                    if (data.length > 0) {

                        if (data.some(x => x.status == 3)) {
                            window.location = '/package/restart-search/' + self.packageQuery.id;
                        }
                        var completed = data.every(x => x.status == 1);
                        var haveError = data.some(x => x.status == 2);

                        if (haveError) {
                            self.notifyErrorMessage(data.find(x => x.status == 2).message);
                            $('#page-loader').hide();
                            self.loading.bookingTransfer = false;
                            //self.checkBookingTransfer(self.nextButtonUrl);
                        } else {
                            if (completed) {
                                self.getResultsPage(1);
                                self.checkSearchComplete();
                            } else {
                                self.createPingRequest();
                            }
                        }
                    } else {
                        self.createPingRequest();
                    }
                });
            },
            gotoTransferPage(page) {
                $(".hotel-list div[id^='transfer']").removeClass('in');
                this.getResultsPage(page, true);
                $('html,body').animate({ scrollTop: $("#transfer-main-content").offset().top - 120 }, 'slow');
            },
            notifyErrorMessage(errorMessage) {
                console.log("notifyErrorMessage: " + errorMessage);
                this.hasErrorMessage = true;
                this.errorMessage = errorMessage;
            },
            setPickupTime: function (transfer, flightTime) {
                var flightTime = moment.duration(flightTime, "HH:mm");
                var checkinTime = moment.duration(transfer.allowForCheckInTime, "HH:mm");
                var transferTime = moment.duration(transfer.approximateTransferTime, "HH:mm");
                var totalTransfer = moment.duration(checkinTime + transferTime);

                var pickupTime = null;
                if (flightTime > totalTransfer) {
                    var time = flightTime.subtract(totalTransfer);
                    pickupTime = moment(time._data).format("HH:mm");
                    if (this.packageQuery.transferSearchInfo.transferType != 'ToAirport') {
                        transfer.selectedVehicle.pickUpDate = moment.utc(transfer.returnDate).subtract(day).format("YYYY-MM-DD");
                    }
                }
                else {
                    var day = moment.duration(1, 'days');
                    var transferDay = (this.packageQuery.transferSearchInfo.transferType != 'ToAirport' ? moment.utc(transfer.returnDate).subtract(day).format("YYYY-MM-DD") : moment.utc(transfer.vehicles[0].pickUpDate).subtract(day).format("YYYY-MM-DD"));
                    transfer.selectedVehicle.pickUpDate = transferDay;
                    var time = flightTime.add(day.asMilliseconds()).subtract(totalTransfer);
                    pickupTime = moment.utc(time._data).format("HH:mm");
                }
                transfer.selectedVehicle.pickUpTime = pickupTime;
            },


            getResultsPage(newPage, hasFilters) {
                var self = this;
                var data = {
                    packageId: self.packageQuery.id,
                    pageIndex: newPage,
                    pageSize: self.pagination.transferPerPage,
                    sortOrderBy: self.transferFilter.sortOrderBy,
                    sortOrderByAsc: self.transferFilter.sortOrderByAsc
                };

                if (hasFilters) {
                    data.minPrice = self.transferFilter.selectedMinPrice;
                    data.maxPrice = self.transferFilter.selectedMaxPrice;

                    var categoryIndex = 0;
                    for (var i = 0; i < self.categories.length; i++) {
                        var category = self.categories[i];
                        if (category.selected) {
                            data["categories[" + categoryIndex + "].Key"] = category.key;
                            data["categories[" + categoryIndex + "].Value"] = category.value;
                            categoryIndex++;
                        }
                    }
                    this.pagination.current = newPage;
                }

                self.loading.bookingTransfer = true;

                $.ajax({
                    url: "get-transfers",
                    data: data,
                    type: "POST",
                    success: function (compressed) {
                        self.transfers = compressed.transfers;
                        $.each(compressed.transfers, function (index, item) {
                            if (self.packageQuery.hasFlight && self.packageQuery.hasHotel && self.packageQuery.hotels && self.packageQuery.hotels.length > 0 && item.questions && item.questions.length > 1) {
                                item.questions[0].value = self.packageQuery.hotels[0].name;
                                item.questions[1].value = self.packageQuery.hotels[0].addressLines;
                            }
                            else if (self.hotelTransfer && item.questions && item.questions.length > 1) {
                                item.questions[0].value = self.hotelTransfer.name;
                                item.questions[1].value = self.hotelTransfer.address;
                            }

                            if (item.questions && item.questions.length > 2) {
                                item.questions[2].value = self.packageQuery.toCityName;
                            }

                            item.selectedVehicle = item.vehicles[0];
                            $.each(item.vehicles, function (i, vehicle) {
                                if (!item.selected) {
                                    if (vehicle.pickUpDate != null) {
                                        vehicle.pickUpDate = moment.utc(String(vehicle.pickUpDate)).format('YYYY-MM-DD');
                                    }
                                    if (self.packageQuery.transferSearchInfo) {
                                        vehicle.hotelCode = self.packageQuery.transferSearchInfo.accommodationGeoCoords;
                                        if (!item.isReturnJourney) {
                                            vehicle.pickUpTime = self.packageQuery.transferSearchInfo.travelTime;
                                            vehicle.flightTime = self.packageQuery.transferSearchInfo.travelTime;
                                            vehicle.flightNo = self.packageQuery.transferSearchInfo.outboundFlightNo;
                                        }
                                        else {
                                            if (self.packageQuery.transferSearchInfo.transferType != 'ToAirport') {
                                                vehicle.flightTime = self.packageQuery.transferSearchInfo.returnTime;
                                                self.setPickupTime(item, self.packageQuery.transferSearchInfo.returnTime);
                                                vehicle.flightNo = self.packageQuery.transferSearchInfo.inboundFlightNo;
                                            }
                                            else {
                                                vehicle.flightTime = self.packageQuery.transferSearchInfo.travelTime;
                                                vehicle.pickUpTime = self.packageQuery.transferSearchInfo.travelTime;
                                                self.setPickupTime(item, self.packageQuery.transferSearchInfo.travelTime);
                                                vehicle.flightNo = self.packageQuery.transferSearchInfo.inboundFlightNo;
                                            }
                                        }
                                    }

                                }
                                else {
                                    vehicle.pickUpDate = vehicle.pickUpDate.substr(0, 10);
                                }
                                if (vehicle.selected) {
                                    item.selectedVehicle = vehicle;
                                }
                            });

                            if (item.selected) {
                                // self.hasAddTransfer = true;

                                item.isExpand = true;
                                item.selectedVehicle.pickUpDate = item.selectedVehicle.pickUpDate.substr(0, 10);

                                var pickUpTime = item.vehicles[0].pickUpTime.split(":");
                                if (item.isReturnJourney) {
                                    self.departureTransfer = item;
                                    self.transferSelected.departureTransfer = item;
                                    self.hasAddDepartureTransfer = true;

                                    self.departureDateSelected = moment.utc(item.vehicles[0].pickUpDate);
                                    self.departureDateSelected.set({ hour: pickUpTime[0], minute: pickUpTime[1] });

                                } else {
                                    self.arrivalTransfer = item;
                                    self.transferSelected.arrivalTransfer = item;
                                    self.hasAddArrivalTransfer = true;

                                    self.arrivalDateSelected = moment.utc(item.vehicles[0].pickUpDate);
                                    self.arrivalDateSelected.set({ hour: pickUpTime[0], minute: pickUpTime[1] });
                                }
                            }
                            else {
                                item.isExpand = false;
                            }

                        });

                        self.pagination.currentRowOnPage = compressed.transfers.length;
                        self.pagination.totalTransfers = compressed.totalTransfers;
                        self.pagination.totalPages = Math.ceil(compressed.totalTransfers / self.pagination.transferPerPage);

                        self.departureTransfers = self.transfers.filter(function (x) { return x.isReturnJourney === true });
                        self.arrivalTransfers = self.transfers.filter(function (x) { return x.isReturnJourney === false });

                        self.hasArrivalTransfer = compressed.transfers.some(x => x.isReturnJourney == false);
                        self.hasDepartureTransfer = compressed.transfers.some(x => x.isReturnJourney == true);

                        self.loading.bookingTransfer = false;


                    },
                    complete: function () {
                        $('#page-loader').hide();
                        self.loading.bookingTransfer = false;
                    }
                });


            },
            checkSearchComplete: function (callback) {
                var self = this;
                if (callback) {
                    callback();
                }

                if (!self.hasErrorMessage) {
                    $.ajax("/package/get-transfer-filters", {
                        data: {
                            packageId: self.packageQuery.id
                        },
                        type: "POST",
                        success: function (compressed) {
                            var filters = compressed;
                            self.minPriceTransfer = self.selectedMinPrice = filters.minPrice;
                            self.maxPriceTransfer = self.selectedMaxPrice = filters.maxPrice;

                            for (var property in filters.categories) {
                                if (filters.categories.hasOwnProperty(property)) {
                                    self.categories.push({
                                        key: property,
                                        value: filters.categories[property],
                                        selected: false
                                    });
                                }
                            }

                            self.isSearchCompleted = true;
                        },
                        error: function () {
                            self.isSearchCompleted = true;
                        }
                    });
                } else {
                    self.isSearchCompleted = true;
                }
                self.isSearchCompleted = true;
            },
            checkBookingTransfer: function (nextUrl) {
                var self = this;
                if (self.packageQuery.hasFlight && self.packageQuery.hasHotel) {
                    window.location.replace(nextUrl);
                }
                else if (self.transferSelected.departureTransfer || self.transferSelected.arrivalTransfer) {
                    window.location.href = nextUrl;
                }
                else {
                    bootbox.dialog({
                        message: self.translateText('PLEASE_SELECT_ANY_TRANSFER', 'Please select any transfer and then continue.'),
                        buttons: {
                            close: {
                                label: "Close",
                                className: "btn-danger",
                                callback: function () {
                                }
                            }
                        }
                    });

                    $('#page-loader').hide();
                    self.loading.bookingTransfer = false;
                }

            },
            range: function (min, max) {
                var array = [],
                    j = 0;
                for (var i = min; i <= max; i++) {
                    array[j] = i;
                    j++;
                }
                return array;
            },
            changeNoOfVehicle: function (transfer, vehicle) {
                var self = this;
                $.ajax("/package/transfer-calculateprice-noofvehicle", {
                    data: {
                        packageId: self.packageQuery.id,
                        transferId: transfer.id,
                        vehicleCode: vehicle.vehicleCode,
                        noOfVehicle: vehicle.noOfVehicle
                    },
                    type: "POST",
                    success: function (response) {
                        if (response.success) {
                            if (transfer.isReturnJourney) {
                                vehicle.totalPrice = response.departureTransfer.totalPrice;
                            } else {
                                vehicle.totalPrice = response.arrivalTransfer.totalPrice;
                            }
                        } else {
                            bootbox.dialog({
                                message: response.message,
                                buttons: {
                                    close: {
                                        label: "Close",
                                        className: "btn-danger",
                                        callback: function () {
                                        }
                                    }
                                }
                            });
                        }
                    },
                    error: function (request, status, error) {
                    }
                });
            },
            getHotelName: function (transfer, vehicle, code) {
                if (transfer.accommodations != null) {
                    for (var i = 0; i < transfer.accommodations.length; i++) {
                        var hotelCode = transfer.accommodations[i].code;
                        if (hotelCode == code) {
                            vehicle.hotelName = transfer.accommodations[i].name;
                            return;
                        } else {
                            vehicle.hotelName = "";
                        }
                    }
                }
            },
            bookingTransfer: function (e, transfer, vehicle, index) {
                var self = this;
                e.preventDefault();
                var form = $(e.target);
                var datePicker = form.find('.PickupDateTime');

                var validFlightNo = self.validateFlightNo(form);
                if (validFlightNo) {
                    if (typeof datePicker !== 'undefined' && datePicker.length > 0) {
                        var tmpPickUpTime = datePicker.find('input[name="PickUpTime"]').val();
                        var tmpPickUpDate = datePicker.find('input[name="PickUpDate"]').val();
                        if (tmpPickUpTime.toString() != tmpPickUpDate.toString()) {
                            vehicle.pickUpDate = tmpPickUpDate;
                            vehicle.pickUpTime = tmpPickUpTime;
                        }
                    }

                    var pickUpTime = vehicle.pickUpTime.split(":");
                    if (transfer.isReturnJourney) {
                        self.departureDateSelected = moment.utc(vehicle.pickUpDate);
                        self.departureDateSelected.set({ hour: pickUpTime[0], minute: pickUpTime[1] });
                    }
                    else {

                        self.arrivalDateSelected = moment.utc(vehicle.pickUpDate);
                        self.arrivalDateSelected.set({ hour: pickUpTime[0], minute: pickUpTime[1] });
                    }

                    if (self.arrivalDateSelected != null && self.departureDateSelected != null && self.arrivalDateSelected > self.departureDateSelected) {
                        bootbox.dialog({
                            message: self.translateText('PLEASE_SELECT_DEPARTURE_PICKUP_TIME_AFTER_ARRIVAL_PICKUP_TIME', 'Please select departure pick-up time after arrival pick-up time'),
                            buttons: {
                                close: {
                                    label: "Close",
                                    className: "btn-danger",
                                    callback: function () {
                                    }
                                }
                            }
                        });
                    }
                    else {
                        vehicle.loading = true;
                        transfer.selectedVehicle = vehicle;

                        if (transfer.isReturnJourney) {
                            for (var i = 0; i < self.departureTransfers.length; i++) {
                                if (self.departureTransfers[i].selected && self.departureTransfers[i].selectedVehicle.selected) {
                                    self.removeTransfer(null, self.departureTransfers[i], self.departureTransfers[i].selectedVehicle, i);
                                }
                            }
                            Vue.set(self.departureTransfers, index, transfer);
                        }
                        else {
                            for (var i = 0; i < self.arrivalTransfers.length; i++) {
                                if (self.arrivalTransfers[i].selected && self.arrivalTransfers[i].selectedVehicle.selected) {
                                    self.removeTransfer(null, self.arrivalTransfers[i], self.arrivalTransfers[i].selectedVehicle, i);
                                }
                            }
                            Vue.set(self.arrivalTransfers, index, transfer);
                        }

                        if (self.hotelTransfer) {
                            vehicle.hotelName = self.hotelTransfer.name;
                        }

                        self.addToQueue("/package/booking-transfer", "POST", {
                            PackageId: self.packageQuery.id,
                            TransferId: transfer.id,
                            AirportCode: self.packageQuery.to,
                            HotelCode: vehicle.hotelCode,
                            FlightNo: vehicle.flightNo,
                            NoOfVehicle: vehicle.noOfVehicle,
                            FlightTime: vehicle.flightTime,
                            PickUpTime: vehicle.pickUpTime,
                            PickUpDate: vehicle.pickUpDate,
                            HotelName: vehicle.hotelName,
                            VehicleCode: vehicle.vehicleCode,
                            Answers: transfer.questions
                        },
                            function (data, status, xhr) {
                                var response = data;
                                if (response.success) {
                                    transfer.selected = true;
                                    vehicle.selected = true;
                                    transfer.isExpand = true;

                                    if (self.transferSelected == null) {
                                        self.transferSelected = {};
                                    }
                                    if (response.arrivalTransfer != null) {
                                        self.transferSelected.arrivalTransfer = response.arrivalTransfer;
                                        self.packageQuery.arrivalTransfer = response.arrivalTransfer;

                                        var arrivalPickUpTime = response.arrivalTransfer.vehicles[0].pickUpTime.split(":");
                                        self.arrivalDateSelected = moment.utc(response.arrivalTransfer.vehicles[0].pickUpDate);
                                        self.arrivalDateSelected.set({ hour: arrivalPickUpTime[0], minute: arrivalPickUpTime[1] });
                                    }
                                    if (response.departureTransfer != null) {
                                        self.transferSelected.departureTransfer = response.departureTransfer;
                                        self.packageQuery.departureTransfer = response.departureTransfer;

                                        var departurePickUpTime = response.departureTransfer.vehicles[0].pickUpTime.split(":");
                                        self.departureDateSelected = moment.utc(response.departureTransfer.vehicles[0].pickUpDate);
                                        self.departureDateSelected.set({ hour: departurePickUpTime[0], minute: departurePickUpTime[1] });
                                    }
                                    if (transfer.isReturnJourney) {
                                        self.departureTransfer = transfer;
                                        self.hasAddDepartureTransfer = true;
                                    }
                                    else {
                                        self.arrivalTransfer = transfer;
                                        self.hasAddArrivalTransfer = true;
                                    }
                                    self.getPriceSummary();
                                } else {
                                    bootbox.dialog({
                                        message: response.message,
                                        buttons: {
                                            close: {
                                                label: "Close",
                                                className: "btn-danger",
                                                callback: function () {
                                                }
                                            }
                                        }
                                    });
                                    self.transferSelected = {};
                                }

                                vehicle.loading = false;
                                transfer.selectedVehicle = vehicle;

                                if (transfer.isReturnJourney) {
                                    Vue.set(self.departureTransfers, index, transfer);
                                }
                                else {
                                    Vue.set(self.arrivalTransfers, index, transfer);
                                }
                            }, function (xhr, status, error) {
                                vehicle.loading = false;
                            });
                    }
                }
            },
            removeTransfer: function (e, transfer, vehicle, index, callback) {
                var self = this;
                var anchor = e != null ? $(e.target) : null;
                vehicle.loading = true;
                transfer.selectedVehicle = vehicle;

                if (transfer.isReturnJourney) {
                    Vue.set(self.departureTransfers, index, transfer);
                }
                else {
                    Vue.set(self.arrivalTransfers, index, transfer);
                }
                self.addToQueue("/package/remove-transfer", "POST", { packageId: self.packageQuery.id, transferId: transfer.id },
                    function (data, status, xhr) {
                        var response = data;
                        if (response.success) {
                            transfer.selected = false;
                            vehicle.selected = false;
                            transfer.isExpand = false;

                            if (transfer.isReturnJourney) {
                                self.departureTransfer = null;
                                self.transferSelected.departureTransfer = null;
                                self.packageQuery.departureTransfer = null;
                                self.hasAddDepartureTransfer = false;
                            } else {
                                self.arrivalTransfer = null;
                                self.transferSelected.arrivalTransfer = null;
                                self.packageQuery.arrivalTransfer = null;
                                self.hasAddArrivalTransfer = false;
                            }
                            self.hasTransfer = false;
                            self.getPriceSummary();
                            if (typeof callback === "function") {
                                callback();
                            }
                        } else {
                            bootbox.dialog({
                                message: response.message,
                                buttons: {
                                    close: {
                                        label: "Close",
                                        className: "btn-danger",
                                        callback: function () {
                                        }
                                    }
                                }
                            });
                        }
                        vehicle.loading = false;
                        if (transfer.isReturnJourney) {
                            Vue.set(self.departureTransfers, index, transfer);
                        }
                        else {
                            Vue.set(self.arrivalTransfers, index, transfer);
                        }
                        // self.hasAddTransfer = false;
                    }, function (xhr, status, error) {
                        vehicle.loading = false;
                    });

            },
            sorting: function (sortOrderBy) {
                var self = this;
                if (self.sortOrderBy === sortOrderBy) {
                    self.sortOrderByAsc = !self.sortOrderByAsc;
                } else {
                    self.sortOrderBy = sortOrderBy;
                    self.sortOrderByAsc = true;
                }
                self.getResultsPage(1, true);
            },
            getMaxVehicle: function (vehicle) {
                if (vehicle.maxPassengers == 0) {
                    return vehicle.maxVehicle
                }
                return this.totalPax;
            },
            getMinVehicle: function (vehicle) {
                var self = this;
                var minVehicle = vehicle.maxVehicle;
                if (vehicle.maxPassengers > 0) {
                    minVehicle = Math.ceil(parseInt(self.totalPax) / parseInt(vehicle.maxPassengers));
                }
                return minVehicle;
            },
            getFromTransferPerPage: function (currentPage, pageSize) {
                return (currentPage - 1) * pageSize + 1;
            },
            getToTransferPerPage: function (currentPage, pageSize, totalTransfer) {
                var toTransferPerPage = currentPage * pageSize;
                if (toTransferPerPage > totalTransfer) {
                    return totalTransfer;
                } else {
                    return toTransferPerPage;
                }
            },
            getPriceSummary: function () {
                var self = this;
                $.ajax("/booking/get-price-summary", {
                    data: {
                        packageId: self.packageQuery.id,
                        promoCode: self.packageQuery.promoCode,
                        creditCardNumber: ""
                    },
                    type: "POST",
                    success: function (response) {
                        self.packageQuery.priceSummary = response;
                        self.$refs.bookingSummary.updatePriceSummary();
                    },
                    error: function () {
                    }
                });
            },
            toggle: function (el, transfer, transfers) {
                var $this = $('#transfer' + transfer.id.trim());
                var transferType = $(el.target).data('transfer-type');

                if (transferType == 'Arrivaltransfer') {
                    $('.transfer-arrival .hotel-list .depart-transfers').not($this).slideUp('fast');
                } else if (transferType == 'Departuretransfer') {
                    $('.transfer-departure .hotel-list .return-transfers').not($this).slideUp('fast');
                }
                $this.slideToggle('fast');
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            showTransferInfo: function (transfer) {
                this.transferInfo.name = transfer.name;
                this.transferInfo.description = transfer.description;
                this.transferInfo.meetingPoint = transfer.meetingPoint;
                this.transferInfo.conditions = transfer.transferConditions;
                $("#transferInfor").modal('show');
            },
            getRegionInfo: function (callback) {
                var self = this;
                var regionid = self.packageQuery.transferSearchInfo.regionId;
                var firstChar = regionid.charAt(0);
                if (firstChar == "H" || firstChar == "R") {
                    var id = regionid.substr(2);
                    var url = '';
                    if (firstChar == "H") {
                        url = '/api/get-hotel-info';
                        var data = {
                            CityCode: self.packageQuery.to,
                            CultureCode: self.packageQuery.cultureCode,
                            HotelId: id,
                            PackageId: self.packageQuery.id
                        };
                        $.ajax({
                            url: url,
                            data: data,
                            type: "POST",
                            success: function (result) {
                                if (callback) {
                                    callback(result.hotelDetail);
                                }
                            }
                        });
                    }
                    else {
                        url = '/api/search-regions';
                        var data = {
                            cultureCode: self.packageQuery.cultureCode,
                            regionIds: id
                        };
                        $.ajax({
                            url: url,
                            data: data,
                            type: "POST",
                            success: function (result) {
                                self.regionInfo = result;
                                if (callback) {
                                    callback();
                                }
                            }
                        });
                    }
                }
                else {
                    $.ajax({
                        url: "/package/get-hotel-by-expedia-code/" + regionid + "/" + self.packageQuery.cultureCode,
                        type: "POST",
                        success: function (result) {
                            self.hotelInfo = result;
                            if (callback) {
                                callback();
                            }
                        }
                    });
                }
            },
            autoFillFlightNo: function (transfers, event) {
                this.isChangeDateTime = false;
                $.each(transfers, function (index, item) {
                    item.selectedVehicle.flightNo = event.target.value;
                });
            },
            clickFlightNo: function () {
                this.isChangeDateTime = false;

            },
            displaySelected: function (isExpand) {

                if (isExpand) {
                    return {
                        'display': 'block'
                    };
                }
                else {
                    return {
                        'display': 'none'
                    };
                }
            },
            onCalcPromoPriceChanged(promo) {
                let self = this;
                self.promoCode = promo;
                self.calcPromoPrice(function (priceSummry) {
                    if (priceSummry.promoPrice === 0) {
                        self.promoError = true;
                    }
                    else {
                        self.promoError = false;
                    }
                });
            },
            calcPromoPrice(callback) {
                var self = this;
                var cardNumber = $("#txtCreditCardNumber").val();
                var promoCode = $("#showPriceSummary .txtPromoCode").val();

                $.ajax({
                    type: "POST",
                    url: "/booking/get-price-summary",
                    data: {
                        packageId: this.packageQuery.id,
                        creditCardNumber: cardNumber,
                        promoCode: promoCode,
                        applyInsurance: this.isApplyInsurance,
                        addonDetails: null
                    },
                    success: function (data) {
                        self.packageQuery.priceSummary = data;
                        if (callback) {
                            callback(data);
                        }
                    }
                });
            },
            validateFlightNo: function (form) {
                var result = false;
                var elValidate = $(form.find("input[name='FlightNo']"))[0];
                var message = "";
                if (elValidate) {
                    var pattern = new RegExp('^[a-zA-Z0-9\\s]+$');
                    if (elValidate.value === null || elValidate.value.length === 0 || elValidate.value === undefined) {
                        $(elValidate).addClass("input-validation-error");
                        $(elValidate.parentElement.nextElementSibling).addClass("message-validation-error");
                        message = this.translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.');
                        $(elValidate.parentElement.nextElementSibling).text(message);
                    }
                    else if (!pattern.test(elValidate.value)) {
                        message = this.translateText('PLEASE_ANTER_ALPHA_NUMERIC_CHARACTERS_ONLY', 'Please enter alphanumeric characters only.');
                        $(elValidate.parentElement.nextElementSibling).addClass("message-validation-error");
                        $(elValidate.parentElement.nextElementSibling).text(message);
                        $(elValidate).addClass("input-validation-error");
                    }
                    else {
                        $(elValidate.parentElement.nextElementSibling).removeClass("message-validation-error");
                        $(elValidate.parentElement.nextElementSibling).text("");
                        $(elValidate).removeClass("input-validation-error");
                        result = true;
                    }
                }
                return result;
            }
        },
        watch: {
            flightNo: {
                handler: function (val, oldVal) {
                    this.flightNo = val;
                    this.isLoadDateTime = false;
                }
            }
        }
    }
    Vue.directive('DateTimePicker', function (element, dataBinding) {
        mounted: {
            if (dataBinding.value.isChangeDateTime) {
                var $this = $(element);
                var $datetimepicker = $this.find(".datetimepicker");
                var toDay = moment.utc();

                $datetimepicker.datetimepicker({
                    minDate: toDay,
                    format: 'DD/MM/YYYY HH:mm',
                    allowInputToggle: true,
                    sideBySide: true,
                    keepOpen: false,
                    icons: {
                        previous: 'icon icon-left-chevron',
                        next: 'icon icon-right-chevron',
                        up: 'icon icon-up-chevron',
                        down: 'icon icon-down-chevron',
                        time: 'icon icon-clock',
                        date: 'icon icon-calendar',
                        clear: 'icon icon-remove',
                        close: 'icon icon-times',
                        today: 'icon icon-calendar'
                    }
                });

                var numberDate = 1;

                $datetimepicker.each(function () {
                    var $this = $(this);
                    var departureDate = moment.utc(dataBinding.value.departureDate);
                    var returnDate = moment.utc(dataBinding.value.returnDate);
                    var originalReturnDate = moment.utc(dataBinding.value.originalReturnDate);

                    if ($this.hasClass('DepartureDateSearch')) {
                        if (dataBinding.value.departTime) {
                            var strArr = dataBinding.value.departTime.split(":");
                            departureDate.set({ hour: strArr[0], minute: strArr[1] });
                            originalReturnDate.set({ hour: strArr[0], minute: strArr[1] });
                        }

                        $this.data("DateTimePicker").date(departureDate);
                        if (dataBinding.value.transferType && dataBinding.value.transferType != "ToAirport") {
                            $this.data("DateTimePicker").minDate(originalReturnDate);
                            departureDate.set('date', departureDate.get('date') + numberDate);
                            $this.data("DateTimePicker").maxDate(departureDate);
                        }
                        else {
                            $this.data("DateTimePicker").maxDate(departureDate);
                            var minDate = moment.utc(originalReturnDate.set('date', originalReturnDate.get('date') - numberDate));
                            minDate.set({
                                hour: 0, minute: 0, second: 0, millisecond: 0
                            });
                            $this.data("DateTimePicker").minDate(minDate);
                        }

                    } else if ($this.hasClass('ReturnDateSearch')) {
                        if (dataBinding.value.returnTime) {
                            var strArr = dataBinding.value.returnTime.split(":");
                            returnDate.set({ hour: strArr[0], minute: strArr[1] });
                        }
                        $this.data("DateTimePicker").maxDate(returnDate);
                        var minDate = moment.utc(originalReturnDate.set('date', originalReturnDate.get('date') - numberDate));

                        var checkInDate = moment.utc(dataBinding.value.checkInDate);
                        if (checkInDate) {
                            if (minDate.get('date') === checkInDate.get('date') && minDate.get('month') === checkInDate.get('month') && minDate.get('year') === checkInDate.get('year')) {
                                $this.data("DateTimePicker").minDate(checkInDate);
                            }
                            else {
                                minDate.set({ hour: 0, minute: 0, second: 0, millisecond: 0 });
                                $this.data("DateTimePicker").minDate(minDate);
                            }
                        }
                        $this.data("DateTimePicker").date(returnDate);
                    }
                });

                $datetimepicker.on('dp.change dp.hide', function (e) {
                    var $this = $(this);
                    var date = moment.utc(e.date.toString());
                    var formatDate = moment.utc(String(date)).format('YYYY-MM-DD');
                    var formatTime = moment.utc(String(date)).format('HH:mm');
                    $this.find('input[name="PickUpDate"]').val(formatDate);
                    $this.find('input[name="PickUpTime"]').val(formatTime);
                });
            }
        }
    });
</script>