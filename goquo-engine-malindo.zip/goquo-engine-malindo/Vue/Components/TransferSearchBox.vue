﻿<template>
    <div class="transfer-search" v-if="package">
        <!--<h2 v-lang.SEARCH_FOR_AIRPORT_TRANSFER>Search for Airport Transfers</h2>-->
        <form method="GET" action="/package/start-search" data-val="true" id="search-transfer" v-show="transfer.transferType != 'ToAirport'">
            <div class="input-daterange">
                <div class="row">
                    <input type="hidden" name="PromoCode" :value="promoCode" />
                    <div class="col-xs-12 col-sm-12 col-md-12 transfer-search-radio">
                        <div class="form-group form-group-icon-left">
                            <label for="Return" class="col-xs-12 col-sm-3 col-md-3">
                                <input type="radio" v-model="transfer.transferType" name="TransferSearchInfo.TransferType" value="Return" id="Return" checked /><strong v-lang.RETURN>Return</strong>
                            </label>
                            <label for="FromAirport" class="col-xs-12 col-sm-4 col-md-4">
                                <input type="radio" v-model="transfer.transferType" name="TransferSearchInfo.TransferType" value="FromAirport" id="FromAirport" /><strong v-lang.ONE_WAY_FROM_AIRPORT>One-way From Airport</strong>
                            </label>
                            <label for="ToAirport" class="col-xs-12 col-sm-4 col-md-4">
                                <input type="radio" v-model="transfer.transferType" name="TransferSearchInfo.TransferType" value="ToAirport" id="ToAirport" /><strong v-lang.ONE_WAY_TO_AIRPORT>One-way To Airport</strong>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="row flight-hotel-transfer">
                    <div class="col-xs-12 col-sm-6 col-md-6 flight right-icon right-icon-n">
                        <div class="form-group dropbox">
                            <i class="icon input-icon icon-location-arrow"></i>
                            <label v-lang.WHAT_AIRPORT_DO_YOU_ARRIVE_AT>What airport do you arrive at?</label>
                            <ajax-select id="To"
                                         name="To"
                                         v-model="transfer.airportCode"
                                         :placeholder="translateText('CHOOSE_A_CITY','Choose a city...')"
                                         :url="'/api/get-global-airports'"
                                         :defaultValue="transfer.airportCode"
                                         :defaultText="transfer.defaultTextFrom"></ajax-select>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6 form-group right-icon right-icon-n hotel">
                        <div class="form-group dropbox">
                            <i class="icon input-icon icon icon-map-marker"></i>
                            <label v-lang.WHAT_WOULD_YOU_LIKE_TO_BE_DROPPED_OFF>Where would you like to be dropped off?</label>
                            <div>
                                <Ajax-Select-City id="RegionId"
                                                  name="TransferSearchInfo.RegionId"
                                                  :to="transfer.airportCode"
                                                  :placeholder="translateText('PLEASE_ENTER_HOTEL_NAME','Please enter hotel name/location...')"
                                                  :url="'/api/search-regions'"
                                                  :typeRegions="typeRegions"
                                                  :defaultValue="transfer.regionId"
                                                  :defaultText="transfer.defaultTextTo"></Ajax-Select-City>
                            </div>
                        </div>
                    </div>
                    <div class="high-zindex">
                        <div class="departure-time flightTime">
                            <div class="col-xs-12 col-sm-6 col-md-3 right-icon right-icon-n">
                                <div class="form-group">
                                    <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                                    <label v-lang.WHEN_DOES_YOUR_FLIGHT_ARRIVE>When does your flight arrive?</label>
                                    <div class='component-datetimepicker'>
                                        <Date-Time-Picker name="DepartureDateTime"
                                                          v-model="transfer.DepartureDate"
                                                          :departureDate="transfer.departureDate">
                                        </Date-Time-Picker>
                                        <input type="hidden" name="DepartureDate" data-DepartureDate-date="DepartureDate" />
                                        <input type="hidden" name="TransferSearchInfo.TravelTime" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="return-time flightTime" v-if="transfer.transferType == 'Return'">
                            <div class="col-xs-12 col-sm-6 col-md-3 right-icon right-icon-n">
                                <div class="form-group">
                                    <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                                    <label v-lang.WHEN_DOES_YOUR_FLIGHT_DEPART>When does your flight depart?</label>
                                    <div class='component-datetimepicker'>
                                        <Date-Time-Picker :startDate="transfer.DepartureDate"
                                                          :autoFocus="false"
                                                          v-model="transfer.ReturnDate"
                                                          name="ReturnDateTime"
                                                          :returnDate="transfer.returnDate"
                                                          :isFlightDepart="true">
                                        </Date-Time-Picker>
                                        <input type="hidden" name="ReturnDate" data-ReturnDate-date="ReturnDate" />
                                        <input type="hidden" name="TransferSearchInfo.ReturnTime" data-ReturnTime-date="TransferSearchInfo.ReturnTime" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="return-time flightTime" v-if="transfer.transferType == 'FromAirport'" style="display:none;">
                            <div class="col-xs-12 col-sm-6 col-md-3 right-icon right-icon-n">
                                <div class="form-group">
                                    <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                                    <label v-lang.WHEN_DOES_YOUR_FLIGHT_DEPART>When does your flight depart?</label>
                                    <div class='component-datetimepicker'>
                                        <Date-Time-Picker :startDate="transfer.DepartureDate"
                                                          :autoFocus="false"
                                                          v-model="transfer.ReturnDate"
                                                          name="ReturnDateTime"
                                                          :returnDate="transfer.returnDate"
                                                          :isFlightDepart="true">
                                        </Date-Time-Picker>
                                        <input type="hidden" data-ReturnDate-date="ReturnDate" />
                                        <input type="hidden" data-ReturnTime-date="TransferSearchInfo.ReturnTime" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-4 col-md-2 no-padding right-icon right-icon-n">
                            <div class="form-group  form-group-filled">
                                <i class="icon icon-user input-icon input-icon-highlight"></i>
                                <label v-lang.PASSENGERS>Passengers</label>
                                <pax-selector :maxRooms="maxRooms" transfer="true"></pax-selector>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-4 right-icon right-icon-n">
                            <div class="form-group form-group-filled">
                                <i class="icon icon-money input-icon input-icon-highlight"></i>
                                <label><span v-lang.CURRENCY>Currency</span></label>
                                <SelectCurrency name="Currency" url="/api/get-currencies" v-model="transfer.currency"
                                                :placeholder="translateText('SELECT_YOUR_CURRENCY', 'Select your currency')"
                                                :defaultValue="transfer.currency">
                                </SelectCurrency>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <label>&nbsp;</label>
                        <div class="pull-right">
                            <input type="hidden" name="ProductId" :value="product.id" />
                            <button type="submit" id="searchForm" class="btn btn-primary" v-lang.SEARCH_FOR_TRANSFER>Search for Transfers</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <form method="GET" action="/package/start-search" data-val="true" id="search-transfer" v-show="transfer.transferType == 'ToAirport'" v-on:submit.prevent="validateOneWayToAirport($event)">
            <div class="input-daterange">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 transfer-search-radio">
                        <div class="form-group form-group-icon-left">
                            <label for="Return" class="col-xs-12 col-sm-3 col-md-3">
                                <input type="radio" v-model="transfer.transferType" name="TransferSearchInfo.TransferType" value="Return" id="Return" checked /><strong v-lang.RETURN>Return</strong>
                            </label>
                            <label for="FromAirport" class="col-xs-12 col-sm-4 col-md-4">
                                <input type="radio" v-model="transfer.transferType" name="TransferSearchInfo.TransferType" value="FromAirport" id="FromAirport" /><strong v-lang.ONE_WAY_FROM_AIRPORT>One-way From Airport</strong>
                            </label>
                            <label for="ToAirport" class="col-xs-12 col-sm-4 col-md-4">
                                <input type="radio" v-model="transfer.transferType" name="TransferSearchInfo.TransferType" value="ToAirport" id="ToAirport" /><strong v-lang.ONE_WAY_TO_AIRPORT>One-way To Airport</strong>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="row flight-hotel-transfer">
                    <div class="col-xs-12 col-sm-6 col-md-6 form-group hotel right-icon right-icon-n">
                        <div class="form-group">
                            <i class="icon icon-map-marker input-icon extra-right"></i>
                            <label v-lang.WHERE_WOULD_YOU_LIKE_TO_BE_PICKED_UP>Where would you like to be picked up?</label>
                            <Ajax-Select-City name="TransferSearchInfo.RegionId"
                                              isToAirPort="True"
                                              :placeholder="translateText('PLEASE_ENTER_HOTEL_NAME','Please enter hotel name/location...')"
                                              :url="'/api/search-regions'"
                                              :defaultValue="transfer.regionId"
                                              :typeRegions="typeRegions"
                                              :defaultText="transfer.defaultTextTo"></Ajax-Select-City>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6 flight right-icon right-icon-n">
                        <div class="form-group">
                            <i class="icon input-icon icon-location-arrow"></i>
                            <label v-lang.WHAT_AIRPORT_DO_YOU_ARRIVE_AT>What airport do you arrive at?</label>
                            <select id="one-way-to-airport" name="To" v-model="transfer.airportCode" :placeholder="translateText('PLEASE_SELECT_AN_AIRPORT','Please select an airport...')" class="form-control">
                                <option value="">{{translateText('PLEASE_SELECT_AN_AIRPORT','Please select an airport...')}}</option>
                                <option v-for="airport in airports" :value="airport.code">{{airport.name}}</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="departure-time flightTime">
                        <div class="col-xs-12 col-sm-6 col-md-3 right-icon right-icon-n">
                            <div class="form-group">
                                <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                                <label v-lang.WHEN_DOES_YOUR_FLIGHT_DEPART>When does your flight depart?</label>
                                <div class='component-datetimepicker'>
                                    <Date-Time-Picker name="DepartureDateTime"
                                                      v-model="transfer.departureDateOneWayTo"
                                                      :departureDate="transfer.departureDateOneWayTo"
                                                      id="DepartureDateSearch"
                                                      :transferType="transfer.transferType"
                                                      :isFlightDepart="true">
                                    </Date-Time-Picker>
                                    <input type="hidden" name="DepartureDate" />
                                    <input type="hidden" name="TransferSearchInfo.TravelTime" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-4 col-md-2 no-padding right-icon right-icon-n">
                        <div class="form-group  form-group-filled">
                            <i class="icon icon-user input-icon input-icon-highlight"></i>
                            <label v-lang.PASSENGERS>Passengers</label>
                            <pax-selector :maxRooms="maxRooms" transfer="true"></pax-selector>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4 right-icon right-icon-n">
                        <div class="form-group form-group-filled">
                            <i class="icon icon-money input-icon input-icon-highlight"></i>
                            <label><span v-lang.CURRENCY>Currency</span></label>
                            <SelectCurrency name="Currency" url="/api/get-currencies" v-model="transfer.currency"
                                            :placeholder="translateText('SELECT_YOUR_CURRENCY', 'Select your currency')"
                                            :defaultValue="transfer.currency">
                            </SelectCurrency>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <label>&nbsp;</label>
                        <div class="pull-right">
                            <input type="hidden" name="ProductId" :value="product.id" />
                            <button type="submit" id="searchForm" class="btn btn-primary" v-lang.SEARCH_FOR_TRANSFER>Search for Transfers</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>


</template>
<style>
    .notSelect {
        cursor: not-allowed;
        pointer-events: none;
        background-color: #d0cccc8f;
    }

        .notSelect .input-group {
            width: 100%;
        }
</style>
<script>
    import Vue from 'vue'
    import { mapState } from 'vuex'
    import {AjaxSelect, AjaxSelectCity, DatePicker, DateTimePicker, PaxSelector} from 'goquo-components'
    import SelectCurrency from './SelectCurrency.vue'

    export default {
        props: ['product', 'hotelTransfer'],
        components: {
            'ajax-select': AjaxSelect,
            'date-picker': DatePicker,
            'pax-selector': PaxSelector,
            'Ajax-Select-City': AjaxSelectCity,
            'Date-Time-Picker': DateTimePicker,
            'SelectCurrency': SelectCurrency
        },
        data() {
            return {
                maxRooms: 1,
                paxCount: 0,
                airports: [],
                cityCode: "",
                startDateOneWayTo: null,
                transfer: {
                    transferType: "Return",
                    airportCode: "",
                    dropoff: "",
                    departureDate: null,
                    returnDate: null,
                    departureDateOneWayTo: null,
                    from: "",
                    to: "",
                    defaultTextFrom: "",
                    defaultTextTo: "",
                    regionId: "",
                    currency: ''
                },
                typeRegions: 'Hotel',
                promoCode: null
            }
        },
        computed: mapState({
            package: state => state.workContext,
        }),
        created() {
            var self = this;
            var packageQuery = self.package.packageQuery;

            var toDay = new Date(new Date().setDate(new Date().getDate() + 2)),
                toDay2 = new Date(new Date().setDate(new Date().getDate() + 3)),
                timeDefault = "12:00";

            var formatDate1 = (toDay.getMonth() + 1) + "/" + toDay.getDate() + "/" + toDay.getFullYear() + " " + timeDefault;
            var formatDate2 = (toDay2.getMonth() + 1) + "/" + toDay2.getDate() + "/" + toDay2.getFullYear() + " " + timeDefault;
            self.transfer.departureDate = new Date(formatDate1);
            self.transfer.returnDate = new Date(formatDate2);
            self.transfer.departureDateOneWayTo = new Date(formatDate1);

            if (packageQuery != undefined && packageQuery != null) {
                self.transfer.airportCode = packageQuery.to;
                self.transfer.defaultTextFrom = packageQuery.toAirportName + ' (' + packageQuery.to + '), ' + packageQuery.toCountryName;

                var travelHour = packageQuery.transferSearchInfo.travelTime.split(":")[0];
                var travelMin = packageQuery.transferSearchInfo.travelTime.split(":")[1];
                self.transfer.departureDate = new Date(new Date(packageQuery.departureDate).setHours(travelHour, travelMin));
                self.transfer.departureDateOneWayTo = self.transfer.departureDate;

                if (packageQuery.transferSearchInfo.returnTime && packageQuery.returnDate) {
                    var returnHour = packageQuery.transferSearchInfo.returnTime.split(":")[0];
                    var returnMin = packageQuery.transferSearchInfo.returnTime.split(":")[1];
                    self.transfer.returnDate = new Date(new Date(packageQuery.returnDate).setHours(returnHour, returnMin));
                }
                else {
                    self.transfer.returnDate = new Date(packageQuery.departureDate);
                    self.transfer.returnDate.setDate(self.transfer.returnDate.getDate() + 1);
                    self.transfer.returnDate.setHours("12", "0");
                }

                self.transfer.transferType = packageQuery.transferSearchInfo.transferType;
                self.transfer.regionId = packageQuery.transferSearchInfo.regionId;

                if (self.transfer.regionId) {
                    self.getAirportByCityCode(self.$route.query.To);
                }

                self.transfer.currency = packageQuery.currency;

                var regionId = packageQuery.transferSearchInfo.regionId;
                var id = regionId.substr(2);
                var firstChar = regionId.charAt(0);
                var data = {
                    cityCode: packageQuery.to,
                    cultureCode: packageQuery.cultureCode,
                    hotelId: id,
                    packageId: packageQuery.id
                };

                $.ajax({
                    url: '/api/get-hotel-info',
                    data: data,
                    type: "POST",
                    success: function (result) {
                        if (result.hotelDetail) {
                            self.transfer.defaultTextTo = result.hotelDetail.name + ", " + result.hotelDetail.address;
                        }
                    }
                });
            }

            self.$on('UpdateAirports', function (data) {
                self.airports = data;
                self.transfer.airportCode = "";
            });

            if (packageQuery != undefined && packageQuery.promoCode != undefined) {
                self.promoCode = packageQuery.promoCode;
            }
        },
        methods: {
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            getAirportByCityCode(cityCode) {
                var self = this;
                $.ajax({
                    type: 'POST',
                    url: '/api/get-airports-of-city',
                    data: {
                        cityCode: cityCode,
                        cultureCode: "en-US"
                    },
                    success: function (data) {
                        self.airports = data;
                        if (self.airports && self.airports > 0) {
                            for (var i = 0; i < data.length; i++) {
                                Vue.set(self.airports, i, data[i]);
                            }
                        }
                    }
                });
            },
            validateOneWayToAirport(event) {
                var el = $("#one-way-to-airport");
                if (el) {
                    if (el.val() === null || el.val().length === 0 || el.val() === undefined) {
                        el.addClass("input-validation-error");
                    }
                    else {
                        el.removeClass("input-validation-error");
                        $(event)[0].target.submit();
                    }
                }
            }

        }
    }
</script>