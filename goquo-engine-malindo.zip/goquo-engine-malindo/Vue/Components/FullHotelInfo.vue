﻿<template>
    <div>
        <div v-if="packageQuery">
            <SessionTimeout :packageId="packageQuery.id" :secondTimeout="packageQuery.ttl"></SessionTimeout>
            <!-- Loader -->
            <div class="book-loading-body" v-show="loading.bookingPageHI">
                <div class="book-loading-caption">
                    <img src="/images/small_loading.gif" alt="loader" />
                    <span v-lang.GENERATING_BOOKING>Generating Booking</span>
                </div>
            </div>

            <!--PACKAGE DETAIL-->
            <div class="hi-package" id="package-detail">
                <div class="hi-package-header">
                    <div class="hi-package-tittle">
                        <span v-if="productCount == 2" v-lang.PACKAGE_DETAILS>Package Details</span>
                        <span v-else v-lang.HOTEL_DETAILS>Hotel Details</span>

                        <small>
                            <strong>{{packageQuery.departureDate | moment("ddd, DD MMM")}}</strong> &mdash; <strong>{{packageQuery.returnDate | moment("ddd, DD MMM")}}</strong>
                        </small>
                    </div>

                    <div class="hi-package-price">

                        <span class="hi-price mb20" v-if="!isSearchCompleted">
                            <span class="load-icon">
                                <span class="bounce1"></span>
                                <span class="bounce2"></span>
                                <span class="bounce3"></span>
                            </span>
                        </span>

                        <span v-if="isSearchCompleted && hotelInfo">
                            <span class="hi-price" v-if="hotelInfo.cheapestPrice > 0">
                                <small v-if="hotelStore.hotels[0].availableRooms.length <= 1">from</small>
                                <small>{{packageQuery.currency}}</small>
                                {{ totalPackagePrice(hotelInfo)}}
                            </span>
                            <span class="hi-price" v-if="hotelInfo.cheapestPrice === 0" v-lang.SOLD_OUT>
                                SOLD OUT
                            </span>
                        </span>

                        <div class="hi-package-price_paxinfo">
                            <small>
                                <span v-lang.FOR_X_PEOPLE>For</span>

                                {{adultCount}}
                                <span v-if="adultCount == 1" v-lang.ADULT>adult</span>
                                <span v-else v-lang.ADULTS>adults</span>

                                <span v-if="childCount > 0">
                                    + {{childCount}}
                                    <span v-if="childCount == 1" v-lang.CHILD>child</span>
                                    <span v-else v-lang.CHILDREN>children</span>
                                </span>

                                <span v-if="infantCount > 0">
                                    + {{infantCount}}
                                    <span v-if="infantCount == 1" v-lang.INFANT>infant</span>
                                    <span v-else v-lang.INFANTS>infants</span>
                                </span>
                            </small>
                            <div class="hi-include">
                                <span v-if="productCount == 2" v-lang.INCLUDES_FLIGHT_HOTEL_TAXES></span>
                                <!--<span v-else v-lang.INCLUDES_TAXES_FEES></span>-->
                            </div>
                        </div>
                    </div>
                </div>

                <div class="hi-flight clearfix" id="flightDetails" v-if="enabledFlights">
                    <!--Flight Loader-->
                    <div v-if="!enabledFlights" class="flight-container">
                        <div class="flight-section dropdown">
                            <div class="flight-icon">
                                <span class="icon icon-flight"></span><div class="load"></div>
                            </div>
                            <div class="flight-timeinfo tp-display-block" style="display:grid">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                        </div>
                        <div class="flight-section dropdown">
                            <div class="flight-icon">
                                <span class="icon icon-flight-return"></span><div class="load"></div>
                            </div>
                            <div class="flight-timeinfo tp-display-block" style="display:grid">
                                <div class="load"></div>
                                <div class="load load50"></div>
                            </div>
                        </div>
                    </div>
                    <!--Import flight section-->
                    <FlightAvailability v-if="enabledFlights" :loading="loading" :flightStore="flightStore" :hotelStore="hotelStore" @flightChanged="onFlightChanged"></FlightAvailability>
                </div>

                <!--HOTEL ROOM SELECTION-->
                <div v-if="isSearchCompleted && hotelInfo">
                    <div v-if="hotelInfo.cheapestPrice === 0">
                        <strong class="hi-sold-out" v-lang.ALL_ROOMS_SOLD_OUT>All rooms sold out</strong>
                    </div>
                </div>

                <!--HOTEL INFO MODIFY SEARCH-->
                <div v-if="product.products.length == 1 && isSearchCompleted && hotelInfo && hotelInfo.cheapestPrice === 0">
                    <div class="hi-form">
                        <h4 v-lang.MODIFY_SEARCH>Modify Search</h4>
                        <form method="GET" class="mb30" action='/package/start-search' id="fHotelSearch" data-val="true">
                            <div class="row custom">
                                <div class="col-xs-12 col-sm-6 col-md-3">
                                    <div class="form-group">
                                        <label class="form-label" v-lang.CHECK_IN>Check-in</label>
                                        <date-picker name="DepartureDate" v-model="packageQuery.departureDate" :value="packageQuery.departureDate"
                                                     id="fFlightHotelSearch_DepartureDate"></date-picker>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-3">
                                    <div class="form-group">
                                        <label class="form-label" v-lang.CHECK_OUT>Check-out</label>
                                        <date-picker name="ReturnDate" v-model="packageQuery.departureDate" :value="packageQuery.returnDate"
                                                     id="fFlightHotelSearch_ReturnDate"></date-picker>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-3">
                                    <label class="form-label" v-lang.SELECT_ROOMS>Select Rooms</label>
                                    <PaxSelector :maxRooms="3"></PaxSelector>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-3">
                                    <input type="hidden" name="ProductId" :value="product.id" />
                                    <input type="hidden" name="From" :value="packageQuery.from" />
                                    <input type="hidden" name="To" :value="packageQuery.to" />
                                    <input type="hidden" name="HotelCode" :value="$route.params.hotelId" />
                                    <button id="searchForm" type="submit" class="btn btn-primary search-button" v-lang.SEARCH_FOR_ROOMS>
                                        Search for Rooms
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!--HOTEL INFO MODIFY SEARCH ends-->
                <!--HOTEL ROOM LOADER START-->
                <div class="hi-room clearfix" v-if="!isSearchCompleted">
                    <div class="hi-room-header">
                        <div class="hi-room-number">
                            <div>
                                <i class="icon icon-hotel hi-room-icon"></i>
                            </div>
                        </div>

                        <div class="hi-pax-count-icon">
                            <i class="icon icon-user"></i>
                        </div>

                        <div class="hi-pax-count">
                            <div class="load"></div>
                        </div>
                    </div>

                    <div class="hi-room-content">
                        <div class="hi-room-img hide">
                            <div class="load loadH100"></div>
                        </div>
                        <div class="hi-room-info">
                            <br />
                            <div class="load"></div>
                            <div class="load load50"></div>
                            <div class="load load25"></div>
                        </div>
                        <div class="hi-room-price-info">
                            <div class="hi-room-price" style="float:right; width:100%;">
                                <br />
                                <div class="load mt10"></div>
                                <div class="load load50 pull-right"></div>
                                <div class="load"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="hi-floating-summary" v-if="!isSearchCompleted">
                    <div class="hi-summary-amt">
                        <div class="hi-package-tittle"> <div class="load load25"></div></div>
                        <div class="hi-total-amt">
                            <span class="load-icon clearfix">
                                <span class="bounce1"></span>
                                <span class="bounce2"></span>
                                <span class="bounce3"></span>
                            </span>
                        </div>
                        <br />
                        <br />
                        <div class="ab1-small-text">
                            <div class="load load50"></div>
                        </div>
                    </div>
                </div>
                <!--HOTEL ROOM LOADER END-->

                <div id="listAvailableRoomTypes" v-if="isSearchCompleted" class="clearfix"
                     v-for="(hotel, hotelIndex) in hotelStore.hotels">
                    <div class="hi-room clearfix" :id="'abRoom'+hotelIndex" v-for="(availableRoom, availableRoomIndex) in hotel.availableRooms" :key="availableRoomIndex">
                        <div class="hi-room-header">
                            <div class="hi-room-number">
                                <i class="icon icon-hotel hi-room-icon"></i> <div v-if="!isSearchCompleted" class="load"></div>
                                <span><span v-lang.ROOM>Room</span> {{availableRoomIndex + 1}}</span>
                                <small class="hi-room-date">
                                    <span v-lang.CHECK_IN>Check-in</span>&nbsp;<strong>{{packageQuery.checkIn || packageQuery.departureDate | moment("ddd, DD MMM")}}</strong>.
                                    <span v-lang.CHECK_OUT>Check-out</span>&nbsp;<strong>{{packageQuery.checkOut || packageQuery.returnDate | moment("ddd, DD MMM") }}</strong>
                                    <span class="hotel-stay">
                                        (<span v-if="hotelStay == 1" v-lang.ONE_NIGHT>1 night</span><span v-else v-lang.X_NIGHTS="{0: hotelStay}"></span>)
                                    </span>
                                </small>
                            </div>
                            <div class="hi-room-paxinfo">
                                <div class="hi-pax-count-icon">
                                    <i class="icon icon-user" v-for="adults in packageQuery.paxInfos[availableRoomIndex].adultCount"></i>
                                    <i class="icon icon-user child" v-for="children in packageQuery.paxInfos[availableRoomIndex].childCount"></i>
                                    <i class="icon icon-user infant" v-for="infant in packageQuery.paxInfos[availableRoomIndex].infantCount"></i>
                                </div>
                                <div class="hi-pax-count">
                                    <span v-if="packageQuery.paxInfos[availableRoomIndex].adultCount > 0">
                                        {{packageQuery.paxInfos[availableRoomIndex].adultCount}}
                                        <span v-if="packageQuery.paxInfos[availableRoomIndex].adultCount == 1" v-lang.ADULT>adult</span>
                                        <span v-else v-lang.ADULTS>adults</span>
                                    </span>
                                    <span v-if="packageQuery.paxInfos[availableRoomIndex].childCount > 0">
                                        +{{packageQuery.paxInfos[availableRoomIndex].childCount}}
                                        <span v-if="packageQuery.paxInfos[availableRoomIndex].childCount == 1" v-lang.CHILD>child</span>
                                        <span v-else v-lang.CHILDREN>children</span>
                                    </span>
                                    <span v-if="packageQuery.paxInfos[availableRoomIndex].infantCount > 0">
                                        +{{packageQuery.paxInfos[availableRoomIndex].infantCount}}
                                        <span v-if="packageQuery.paxInfos[availableRoomIndex].infantCount == 1" v-lang.INFANT>infant</span>
                                        <span v-else v-lang.INFANTS>infants</span>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="hi-room-content"
                             v-bind:class="{'ab1-limit-rooms' : availableRoom.availableRoomTypes.length > 7}"
                             v-for="(availableRoomType, availableRoomTypeIndex) in availableRoom.availableRoomTypes.slice(0, maxRooms)" :key="availableRoomTypeIndex">
                            <div class="hi-room-img hide" v-if="availableRoomType.images && availableRoomType.images.length > 0"
                                 :style="{backgroundImage: `url('${replaceImage(availableRoomType.images[0])}')`}">
                            </div>
                            <div class="hi-room-img hide" v-if="!availableRoomType.images || availableRoomType.images.length == 0"></div>
                            <div class="hi-room-info">
                                <div class="hi-room-tittle" v-bind:class="{'selected' : availableRoomType.selected }">{{availableRoomType.name}}</div>
                                <span style="color: transparent; top: 5px; left: 5px; position: absolute;">{{availableRoomType.hotelId}}</span>
                                <div v-for="specialOffer in availableRoomType.specialOffers"
                                     :aria-label="specialOffer.SpecialOfferDescription"
                                     v-if="specialOffer.specialOfferName" class="hi-room-deal">
                                    {{specialOffer.specialOfferName}}
                                </div>
                                <div class="hi-board-type">{{availableRoomType.boardCodeDescription}}</div>
                                <div v-if="!enabledFlights && availableRoomType.cancelFreeBeforeDate" class="hi-free-cancelation">
                                    <span v-lang.FREE_CANCELLATION_BEFORE>Free cancellation before</span>
                                    <strong>{{availableRoomType.cancelFreeBeforeDate | moment("DD/MM/YYYY")}}</strong>
                                </div>
                                <div v-else v-lang.NON_REFUNDABLE>Non-refundable</div>
                            </div>
                            <div class="hi-room-price-info">
                                <div class="hi-room-price">
                                    <div class="hi-save-price"
                                         v-if="availableRoomType.specialOffers.length && availableRoomType.specialOffers[0].amount && availableRoomType.specialOffers[0].amount!='' && availableRoomType.specialOffers[0].amount > 10">
                                        <span v-lang.SAVE>SAVE</span>
                                        {{packageQuery.currency}} {{ceilingPrice(availableRoomType.specialOffers[0].amount).toString().replace(/\B(?=(?:\d{3})+(?!\d))/g, ',')}}
                                    </div>
                                    <div class="real-price">
                                        {{packageQuery.currency}}
                                        <span v-if="product.type=='Flight_Hotel'" class="hi-price">{{calcHotelDifferentPrice(hotel, availableRoomIndex, availableRoomType.totalPrice) | formatCurrency}} </span>
                                        <span v-else class="hi-price">{{calcTotalPackagePriceForRoom(hotel, availableRoom, availableRoomType) | formatCurrency}} </span>
                                    </div>
                                    <div v-if="enabledFlights">
                                        <span v-lang.FLIGHT_HOTEL_PACKAGES></span>
                                    </div>
                                    <div>
                                        <span v-lang.FOR>For</span>
                                        <span v-if="hotelStay == 1" v-lang.ONE_NIGHT>1 night</span><span v-else v-lang.X_NIGHTS="{0: hotelStay}"></span>
                                    </div>
                                </div>
                                <div class="hi-room-select" v-if="hotelStore.hotels[0].availableRooms.length > 1">
                                    <label class="btn hi-select-room-btn selected" v-if="availableRoomType.selected">
                                        <span class="hi-room-selection hi-selected-room">
                                            <span><i class="icon icon-check-mark"></i></span>
                                            <b v-lang.SELECTED key="selected">Selected</b>
                                        </span>
                                    </label>
                                    <label class="btn hi-select-room-btn" v-if="!availableRoomType.selected" @click="changeHotelRoomType(hotel, availableRoomIndex, availableRoomTypeIndex)">
                                        <span class="hi-room-selection hi-select-room">
                                            <span></span>
                                            <b v-lang.SELECT key="select">Select</b>
                                        </span>
                                    </label>
                                </div>
                                <div class="hi-room-select" v-else>
                                    <label class="btn hi-select-room-btn selected book" @click="changeHotelRoomType(hotel, availableRoomIndex, availableRoomTypeIndex);bookingNow(hotelInfo);">
                                        <span class="hi-room-selection hi-select-room">
                                            <b v-lang.BOOK key="select">Book</b>
                                        </span>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="hi-show-more-btn" v-if="isSearchCompleted && availableRoom.availableRoomTypes.length > 7">
                            <button class="btn primary-btn" data-alttext="" :data-parenttab="'#abRoom' + hotelIndex"
                                    @click="showMoreRooms(availableRoom.availableRoomTypes.length)">
                                <span v-show="!showDefaultText">- <span v-lang.SHOW_LESS_ROOMS>Show Less Rooms</span></span>
                                <span v-show="showDefaultText">+ <span v-lang.SHOW_MORE_ROOMS>Show More Rooms</span></span>
                            </button>
                        </div>
                    </div>
                    <!--HOTEL ROOM SELECTION ends-->
                    <!--FLOATING MOBILE SUMMARY-->
                    <div class="hi-floating-summary" v-if="moveOnAble() && hotelStore.hotels.length > 0 && (enabledFlights || hotelStore.hotels[0].availableRooms.length > 1)">
                        <div class="hi-summary-amt">
                            <span class="hi-package-tittle">
                                <span v-if="productCount > 1" v-lang.TOTAL_PACKAGE_PRICE>Total Package Price</span>
                                <span v-else v-lang.TOTAL_PRICE>Total Price</span>
                            </span>
                            <div class="hi-total-amt">
                                <span class="load-icon" v-if="!isSearchCompleted">
                                    <span class="bounce1"></span>
                                    <span class="bounce2"></span>
                                    <span class="bounce3"></span>
                                </span>
                                <small>{{packageQuery.currency}}</small>
                                <span class="hi-price" v-if="isSearchCompleted && hotelInfo && hotelInfo.cheapestPrice > 0"> {{ totalPackagePrice(hotelInfo)}} </span>
                                <span class="hi-price" v-if="isSearchCompleted && hotelInfo && hotelInfo.cheapestPrice === 0" v-lang.SOLD_OUT> SOLD OUT</span>
                            </div>

                            <small v-if="productCount > 1" class="ab1-small-text">
                                <span v-lang.FOR_X_PEOPLE>for</span>
                                {{adultCount + childCount + infantCount}}
                                <span v-if="adultCount == 1 && childCount + infantCount == 0 " v-lang.ADULTLOWERCASE>adult</span>
                                <span v-else-if="adultCount > 1 && childCount + infantCount == 0" v-lang.ADULTSSIMPLE>adults</span>
                                <span v-else v-lang.PEOPLE>people</span> &
                                <span v-if="hotelStay > 1" v-lang.X_NIGHTS="{0: hotelStay}">nights</span>
                                <span v-else v-lang.ONE_NIGHT>night</span>
                                <span v-if="productCount == 2" v-lang.INCLUDES_FLIGHT_HOTEL_TAXES>inc. flight, hotel & taxes</span>
                            </small>

                            <small v-else class="ab1-small-text">
                                <span v-if="productCount == 2">
                                    <span v-lang.FOR_X_PEOPLE>For</span>
                                    {{adultCount}}
                                    <span v-if="adultCount == 1" v-lang.ADULT>adult</span>
                                    <span v-else v-lang.ADULTS>adults</span>

                                    <span v-if="childCount > 0">
                                        + {{childCount}}
                                        <span v-if="childCount == 1" v-lang.CHILD>child</span>
                                        <span v-else v-lang.CHILDREN>children</span>
                                    </span>

                                    <span v-if="infantCount > 0">
                                        + {{infantCount}}
                                        <span v-if="infantCount == 1" v-lang.INFANT>infant</span>
                                        <span v-else v-lang.INFANT>infants</span>
                                    </span>
                                </span>
                                <span v-else>
                                    <span v-lang.FOR_X_PEOPLE>for</span>
                                    {{adultCount + childCount + infantCount}}
                                    <span v-if="(adultCount + childCount + infantCount) == 1">
                                        <span v-lang.PERSON>person</span> &
                                    </span>
                                    <span v-else>
                                        <span v-if="adultCount == 1 && childCount + infantCount == 0 " v-lang.ADULTLOWERCASE>adult</span>
                                        <span v-else-if="adultCount > 1 && childCount + infantCount == 0" v-lang.ADULTSLOWERCASE>adults</span>
                                        <span v-else v-lang.PEOPLE>people</span> &
                                    </span>
                                    <span v-if="hotelStay > 1" v-lang.X_NIGHTS="{0: hotelStay}">nights</span>
                                    <span v-else v-lang.ONE_NIGHT>night</span>
                                </span>
                                <br />

                                <span v-if="productCount == 2" v-lang.INCLUDES_FLIGHT_HOTEL_TAXES>inc. flight, hotel & taxes</span>
                                <!--<span v-else v-lang.INCLUDES_TAXES_FEES>inc. taxes & fees</span>-->

                            </small>
                        </div>
                        <button v-if="isSearchCompleted && hotelInfo && hotelInfo.cheapestPrice > 0 && hotelStore.hotels[0].availableRooms.length > 1"
                                type="button" class="btn btn-lg btn-success hi-btn" @click="bookingNow(hotelInfo)" v-lang.CONTINUE>
                            Continue
                        </button>
                        <button data-show="shown" v-if="isSearchCompleted && hotelInfo && hotelInfo.cheapestPrice > 0 && hotelStore.hotels[0].availableRooms.length > 1"
                                type="button" class="btn btn-lg btn-success hi-btn sticky-continue-btn shown" @click="bookingNow(hotelInfo)">
                            <span class="icon icon-right-arrow"></span><span v-lang.CONTINUE>Continue</span>
                        </button>
                    </div>
                    <!--FLOATING MOBILE SUMMARY ENDS-->
                </div>
            </div>
            <!--PACKAGE DETAIL ENDS-->
            <!--HOTEL TRUST YOU REVIEW-->
            <TrustYou :trustyou="trustyou"></TrustYou>
            <!--HOTEL TRUST YOU REVIEW ENDS-->
        </div>
        <div v-if="true">
            <div class="modal fade booking-tabs mod-search loadCal tabbed-popup" id="modifySearch" role="search" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <ul class="nav nav-tabs">
                            <li v-if="flightHotelProduct && !hideTabFlight && product.type === 'Flight_Hotel'" class="active"><a data-toggle="tab" href="#flight-hotel-search">Flight + Hotel Packages</a></li>
                            <li v-else-if="flightHotelProduct && !hideTabFlight"><a data-toggle="tab" href="#flight-hotel-search">Flight + Hotel Packages</a></li>
                            <li v-if="hotelProduct && product.type === 'Hotel'" class="active"><a data-toggle="tab" href="#hotel-search">Hotel</a></li>
                            <li v-else-if="hotelProduct"><a data-toggle="tab" href="#hotel-search">Hotel</a></li>
                        </ul>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <div class="tab-content">
                            <div id="flight-hotel-search" class="tab-pane fade in active" v-if="flightHotelProduct && !hideTabFlight && product.type === 'Flight_Hotel'">
                                <div class="modal-body clearfix">
                                    <FlightHotelSearchForm :model="model" :packageQuery="packageQuery" :product="flightHotelProduct" :hotelDetail="hotelInfo"></FlightHotelSearchForm>
                                </div>
                            </div>
                            <div id="flight-hotel-search" class="tab-pane fade in" v-else-if="flightHotelProduct && !hideTabFlight">
                                <div class="modal-body clearfix">
                                    <FlightHotelSearchForm :model="model" :packageQuery="packageQuery" :product="flightHotelProduct" :hotelDetail="hotelInfo"></FlightHotelSearchForm>
                                </div>
                            </div>
                            <div id="hotel-search" class="tab-pane fade in active" v-if="hotelProduct && product.type === 'Hotel'">
                                <div class="modal-body clearfix">
                                    <HotelSearchForm :model="model" :packageQuery="packageQuery" :product="hotelProduct" :hotelDetail="hotelInfo"></HotelSearchForm>
                                </div>
                            </div>
                            <div id="hotel-search" class="tab-pane fade in" v-else-if="hotelProduct">
                                <div class="modal-body clearfix">
                                    <HotelSearchForm :model="model" :packageQuery="packageQuery" :product="hotelProduct" :hotelDetail="hotelInfo"></HotelSearchForm>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Vue from 'vue'
    import { mapState } from 'vuex'
    import Availability from './Availability.vue';
    import FlightAvailability from './FlightAvailability.vue'
    import {DatePicker} from 'goquo-components'
    import TrustYou from './TrustYou.vue'
    import SessionTimeout from './SessionTimeout.vue'
    import FlightHotelSearchForm from './FlightHotelSearchForm.vue'
    import HotelSearchForm from './HotelSearchForm.vue'
    import PaxSelector from './PaxSelector.vue'
    export default {
        extends: Availability,
        components: {
            FlightAvailability,
            PaxSelector,
            DatePicker,
            TrustYou,
            SessionTimeout,
            FlightHotelSearchForm,
            HotelSearchForm
        },
        data() {
            return {
                showDefaultText: true,
                displayAllRooms: false,
                defaultMaxRooms: 5,
                maxRooms: 5,
                hotelId: null,
                hotelInfo: null,
                trustyou: null,
                dataViewMap: {
                    isHotelDetail: true,
                    totalPackagePrice: 0,
                    hotels: []
                }
            }
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            productCount() {
                return this.product.products.length;
            },
            adultCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                }
                return count;
            },
            childCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.childCount;
                }
                return count;
            },
            infantCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.infantCount;
                }
                return count;
            },
            depatureDisableDateUrl() {
                return "/package/get-disabled-dates?from=" + this.packageQuery.from + "&to=" + this.packageQuery.to;
            },
            returnDisableDateUrl() {
                return "/package/get-disabled-dates?from=" + this.packageQuery.to + "&to=" + this.packageQuery.from;
            },
            isFloatingMobile() {

            }
        }),
        created() {
            if (this.$route.query) {
                this.flightStore.outboundFlightId = this.$route.query.outboundFlightId;
                this.flightStore.inboundFlightId = this.$route.query.inboundFlightId;

                this.model.to = this.$route.params.cityCode;
                this.model.hotelCode = this.$route.params.hotelId;
                this.model.toFullText = $("#hdfToFullText").val();
            }
        },
        methods: {
            getStaticHotels(newPage, callback) {
                this.getHotels(callback);
            },
            bookingNow(hotel) {
                this.loading.bookingPageHI = true;

                var data = {};
                data.packageId = this.packageQuery.id;

                if (this.flightStore.outboundFlight != null) {
                    data.outboundFlightId = this.flightStore.outboundFlight.id;
                }

                if (this.flightStore.inboundFlight != null) {
                    data.inboundFlightId = this.flightStore.inboundFlight.id;
                }

                if (hotel) {
                    data.hotelId = hotel.hotelId;
                    var roomTypeIds = [];

                    for (var i = 0; i < hotel.availableRooms.length; i++) {
                        for (var j = 0; j < hotel.availableRooms[i].availableRoomTypes.length; j++) {
                            var availableRoomType = hotel.availableRooms[i].availableRoomTypes[j];
                            if (availableRoomType.selected) {
                                roomTypeIds.push(availableRoomType.id);
                            }
                        }
                    }
                    data.roomTypeIds = roomTypeIds;
                }

                var self = this;

                $.ajax('/package/do-booking', {
                    traditional: true,
                    data: data,
                    type: "POST",
                    success: function (data) {
                        if (data.success) {
                            window.location = data.redirectUrl;
                        }

                        if (data.message) {
                            alert(data.message);

                            self.loading.bookingPageHI = false;
                        }
                    },
                    error: function () {
                        self.loading.bookingPageHI = false;
                    }
                });
            },
            getHotels(callback) {
                var self = this;
                self.hotelId = [this.$route.params.hotelId];

                $.ajax({
                    url: '/package/get-hotel-availables',
                    data: {
                        packageId: this.packageQuery.id,
                        hotelIds: self.hotelId
                    },
                    traditional: true,
                    type: 'POST',
                    success: function (data) {
                        for (var i = 0; i < data.hotels.length; i++) {
                            var hotel = data.hotels[i];
                            if (hotel.availableRooms) {
                                for (var j = 0; j < hotel.availableRooms.length; j++) {
                                    var availableRoom = hotel.availableRooms[j];
                                    for (var k = 0; k < availableRoom.availableRoomTypes.length; k++) {
                                        var availableRoomType = availableRoom.availableRoomTypes[k];
                                        availableRoomType.selected = k === 0;
                                    }
                                }
                            }
                        }

                        self.hotelStore.hotels = data.hotels;
                        if (data.hotels.length > 0) {
                            self.prepareHotel(data.hotels[0]);
                            self.hotelInfo = data.hotels[0];
                            window.selectedHotel = data.hotels[0];
                            self.getTrustyouData(self.hotelStore.hotels);
                            self.$store.commit('setHotelInfo', data.hotels[0]);
                            self.$store.commit('setTotalPackagePrice', self.totalPackagePrice(data.hotels[0]));
                            
                            self.dataViewMap.totalPackagePrice = self.totalPackagePrice(data.hotels[0]);
                            self.dataViewMap.hotels = data.hotels;
                            self.dataViewMap.currency = self.packageQuery.currency;

                            var map = document.getElementById("mapBox").contentWindow;
                            $('iframe').load(function () {
                                map.postMessage(self.dataViewMap, '*');
                            });
                        }
                        if (callback) {
                            callback();
                        }
                    }
                });
            },
            forceRenderHotels() {
                for (var i = 0; i < this.hotelStore.hotels.length; i++) {
                    var hotel = this.hotelStore.hotels[i];
                    Vue.set(this.hotelStore.hotels, i, hotel);
                    this.$store.commit('setTotalPackagePrice', this.totalPackagePrice(hotel));
                }
            },
            onTrustYouComplete(reviewData) {
                var self = this;
                if (reviewData && reviewData.length && reviewData.length > 0 && reviewData[0]) {
                    self.trustyou = reviewData[0].data;

                    // create a array for category
                    var category = ["all", "business", "couples", "families", "solo"];
                    var categoryData = [];
                    for (var i = 0; i < category.length; i++) {
                        var categoryList = self.trustyou.reviews[category[i]];

                        if (categoryList) {
                            categoryData.push(categoryList);
                            categoryList['category_name'] = category[i];
                        }
                    }
                    self.trustyou['category_items'] = categoryData;
                }
            },
            getRegions() { },
            showMoreRooms(totalRoomsAvailable) {
                if (!this.displayAllRooms) {
                    this.maxRooms = totalRoomsAvailable;
                    this.displayAllRooms = true;
                    this.showDefaultText = false;
                }
                else {
                    this.maxRooms = this.defaultMaxRooms;
                    this.displayAllRooms = false;
                    this.showDefaultText = true;
                }
            },
            changeHotelRoomType(hotel, roomIndex, roomTypeIndex) {
                var self = this;
                var availableRoom = this.hotelInfo.availableRooms[roomIndex];
                for (var j = 0; j < availableRoom.availableRoomTypes.length; j++) {
                    if (roomTypeIndex === j) {
                        availableRoom.availableRoomTypes[j].selected = true;
                    } else {
                        availableRoom.availableRoomTypes[j].selected = false;
                    }
                }

                this.$store.commit('setTotalPackagePrice', this.totalPackagePrice(hotel));

                self.dataViewMap.totalPackagePrice = self.totalPackagePrice(hotel);
                var map = document.getElementById("mapBox").contentWindow;
                map.postMessage(self.dataViewMap, '*');
            },
            replaceImage(path) {
                if (path.indexOf('static.goquo.com') > -1) {
                    var imagePath = path.split("/");
                    var replacedPath = path.replace(imagePath[3], imagePath[3] + '-w300');
                    return replacedPath;
                } else {
                    return path;
                }
            },
            moveOnAble() {
                if (this.enabledFlights && (this.flightStore.flights == null || this.flightStore.flights.length === 0)) return false;

                if (this.enabledHotels) {
                    if ((this.hotelStore.hotels == null || this.hotelStore.hotels.length === 0)) return false;
                    if (this.hotelStore.hotels.length === 1) {
                        if (this.hotelInfo.cheapestPrice === 0) {
                            return false;
                        }
                    }
                }

                return true;
            },
            ceilingPrice(floatNum) {
                return Math.ceil(parseFloat(floatNum));
            },
            getSelectedAvailableRoomType(hotel, index) {
                for (var j = 0; j < hotel.availableRooms[index].availableRoomTypes.length; j++) {
                    var availableRoomType = hotel.availableRooms[index].availableRoomTypes[j];
                    if (availableRoomType.selected) {
                        return availableRoomType;
                    }
                }
                return null;
            },
            calcTotalPackagePriceForRoom(hotel, availableRoom, availableRoomType) {
                if (hotel.cheapestPrice === 0) {
                    return 0;
                }

                if (this.enabledFlights && !this.flightStore.outboundFlight) {
                    return 0;
                }

                if (!hotel.availableRooms) {
                    return 0;
                }

                var price = availableRoomType.totalPrice;
                var totalPaxCount = this.calculatePaxCount();
                var totalRoomPaxCount = availableRoom.adults + availableRoom.children;
                price += (this.totalFlightPrice() / totalPaxCount * totalRoomPaxCount);

                return price.toFixed(this.packageQuery.currencyDecimals);
            },
            onFlightChanged(flight) {
                if (flight.direction === 0) {
                    this.flightStore.outboundFlight = flight;
                }
                else {
                    this.flightStore.inboundFlight = flight;
                }

                if (this.hotelInfo) {
                    this.$store.commit('setTotalPackagePrice', this.totalPackagePrice(this.hotelInfo));
                }
            },
            calcHotelDifferentPrice(hotel, roomIndex, roomTypePrice, plusSymbol, minusSymbol) {
                var selectedRoomType = this.getSelectedAvailableRoomType(hotel, roomIndex);
                var price = roomTypePrice - selectedRoomType.totalPrice;
                price = price.toFixed(this.packageQuery.currencyDecimals);
                var flag = price < 0;
                if (plusSymbol == null) {
                    plusSymbol = "+";
                }
                if (minusSymbol == null) {
                    minusSymbol = "-";
                }
                price = (price + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
                if (flag) {
                    return minusSymbol + price.replace('-', '');
                } else {
                    return plusSymbol + price;
                }
            },
        }
    }
</script>