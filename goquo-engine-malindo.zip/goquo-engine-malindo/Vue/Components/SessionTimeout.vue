﻿<template>
    <div id="divSessionTime" class="relative hidden">
        <div class='sessionTimeOut'>Your session will expire in <span></span> mins</div>
    </div>
</template>

<script>
    export default {
        props: ['packageId', 'sessionTimeout', 'secondTimeout'],
        data() {
            return {}
        },
        mounted: function () {
            var vm = this;
            var $element = $(vm.$el);
            var n = new Date();

            var secondTimeOut = vm.secondTimeout;

            var timeout = (vm.sessionTimeout != undefined && vm.sessionTimeout != "") ? parseInt(vm.sessionTimeout) : 25;
            var seconds = secondTimeOut > 0 ? secondTimeOut : timeout * 60;

            function setTimer() {
                var x = new Date() - n;
                var remain = seconds - Math.floor(x / 1000);

                $(".sessionTimeOut span", $element).html(parseInt(remain / 60).padLeft(2, '0') + ":" + (remain % 60).padLeft(2, '0'));

                if (remain <= 0) {
                    window.location.href = "/package/start-over/" + vm.packageId;
                }
            };

            setInterval(function () { setTimer(); }, 1000);
        },
        methods: {

        }
    }
</script>
