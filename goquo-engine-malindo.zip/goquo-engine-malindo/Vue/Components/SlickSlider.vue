<template>
    <div style="width: 100%;">
        <div :id="sliderClass + itemIndex" :class="sliderClass" class="slick-slider result-img" v-if="typeof item !== 'undefined' && item.length > 0">
            <div class="result-img-item" v-for="(thumb, index) in item" v-if="index < 5">
                <img v-if="index==0" :data-original="isReplaceImage == 'true' ? replaceImage(isTour ? thumb : thumb.url) : (isTour ? thumb : thumb.url)"
                     :class="'lazy image-lightbox' + itemIndex">
                <img v-else :data-lazy="isReplaceImage == 'true' ? replaceImage(isTour ? thumb : thumb.url) : (isTour ? thumb : thumb.url)"
                     :class="'image-lightbox' + itemIndex">
            </div>
        </div>
        <div v-else class="slick-slider result-img">
            <div class="slick-list draggable">
                <div class="slick-track"></div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: ['sliderClass', 'item', 'itemIndex', 'isReplaceImage', 'isTour'],
        mounted: function () {
            // init slick slider
            $("img.lazy").lazyload();
            $('#' + this.sliderClass + this.itemIndex).not('.slick-initialized').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                infinite: true,
                dots: false,
                responsive: [
                    {
                        breakpoint: 480,
                        settings: {
                            dots: false
                        }
                    }
                ]
            });


        },
        updated: function () {
            $("img.lazy").lazyload();
            $('#' + this.sliderClass + this.itemIndex).slick('unslick');
            $('#' + this.sliderClass + this.itemIndex).slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                infinite: true,
                dots: false,
                responsive: [
                    {
                        breakpoint: 480,
                        settings: {
                            dots: false
                        }
                    }
                ]
            });


        },
        methods: {
            replaceImage(path) {
                var replacedPath;
                if (!this.isTour) {
                    if (typeof path !== 'undefined' && path.indexOf('static.goquo.com') > -1) {
                        var imagePath = path.split("/");
                        replacedPath = path.replace(imagePath[3], imagePath[3] + '-w300');
                    } else {
                        replacedPath = path;
                    }

                    // Force https
                    if (typeof replacedPath !== 'undefined' && replacedPath.indexOf('http://') == 0) {
                        return "https://" + replacedPath.substr(7);
                    }
                }
                return replacedPath;
            }
        }
    }

</script>