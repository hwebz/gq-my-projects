<template>
  <div class="flight-hotel-search">
      <form method="GET" action="/package/start-search" data-val="true">
          <table class="table-layout-search">
            <tr>
              <td class="width-200">
                <div class="form-group form-group-icon-left">
                    <i class="icon input-icon icon-location-arrow"></i>    
                    <label>From</label>
                    <ajax-select name="From" :placeholder="'Select Depart Airport'" :url="'/api/get-airports'"></ajax-select>
                </div>
              </td>
              <td class="width-200">
                <div class="form-group form-group-icon-left">
                    <i class="icon input-icon icon icon-map-marker"></i>
                    <label>To</label>
                    <ajax-select name="To" :placeholder="'Select Arrival Airport'" :url="'/api/get-airports'"></ajax-select>
                </div>
              </td>
              <td class="width-140">
                <div class="form-group form-group-icon-left form-group-filled">
                    <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                    <label>Departing Date</label>
                    <date-picker name="DepartureDate" v-model="DepartureDate" :defaultValue="DepartureDate"></date-picker>
                </div>
              </td>
              <td class="width-140">
                <div class="form-group form-group-icon-left form-group-filled">
                    <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                    <label>Returning Date</label>
                    <date-picker name="ReturnDate" :startDate="DepartureDate" :defaultValue="ReturnDate" addOneDay="true" autoFocus="true"></date-picker>
                </div>
              </td>
              <td class="room-column">
                <div class="form-group form-group-icon-left">
                    <i class="icon icon-user input-icon input-icon-highlight"></i>
                    <label>Room(s) & Traverller(s)</label>
                    <pax-selector :maxRooms="3"></pax-selector>
                </div>
              </td>
              <td class="submit-column">
                  <input type="hidden" name="JourneyType" value="Return">
                  <input type="hidden" name="ProductId" :value="product.id" />
                  <input type="hidden" name="cultureCode" :value="cultureCode" />
                  <p class="note" ng-totals-days-nights="{0} Days {1} Nights"></p>
                  <button type="submit" id="searchForm" class="btn btn-block btn-primary search-button">Search for Package</button>
              </td>
            </tr>
          </table>
          <div class="hide">
              <label class="radio-inline">
                  <input type="radio" name="JourneyType" checked="checked" value="Return" /> Return
              </label>
              <label class="radio-inline">
                  <input type="radio" name="JourneyType" value="OneWay" /> One Way
              </label>
          </div>
          <div class="row hide">
              <div class="col-md-6 col-xs-12">
                  <label>
                      <input type="checkbox" ng-model="PartialStay" name="PartialStay">
                      <span>I only need a hotel for part of my trip</span>
                  </label>
              </div>

          </div>
          <div class="">
              <div class="col-md-6 col-xs-12 single-field">
                  <div class="col-md-6 col-xs-12 single-field" v-if="PartialStay">
                      <div class="form-group form-group-icon-left form-group-filled">
                          <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                          <label>Check in</label>
                          <input type="text"
                                 ng-model="checkin"
                                 ng-check-in-check-out=""
                                 data-start-date-picker2=""
                                 name="CheckIn"
                                 readonly="readonly"
                                 id="fFlightHotelSearch_CheckIn"
                                 class="form-control datetime"
                                 autocomplete="off"
                                 data-val="true" data-val-required="Please enter a value." />
                      </div>
                  </div>
                  <div class="col-md-6 col-xs-12 single-field ng-hide" v-if="PartialStay">
                      <div class="form-group form-group-icon-left form-group-filled">
                          <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                          <label>Check out</label>
                          <input type="text"
                                 ng-model="checkout"
                                 ng-check-in-check-out=""
                                 data-end-date-picker2=""
                                 class="form-control datetime"
                                 name="CheckOut"
                                 readonly="readonly"
                                 id="fFlightHotelSearch_CheckOut"
                                 autocomplete="off"
                                 data-val="true" data-val-required="Please enter a value." />
                      </div>
                  </div>
              </div>
          </div>
          <div class="clearfix"></div>
      </form>
  </div>
</template>

<script>
import Vue from 'vue'
import { AjaxSelect, DatePicker } from 'goquo-components'
import PaxSelector from './PaxSelector.vue'
export default {
    data() {
        return {
          maxRooms: 3,
          PartialStay: false,
          DepartureDate: Vue.moment().add(1, 'day'),
        }
    },
    computed: {
        ReturnDate() {
            return Vue.moment(this.DepartureDate).add(1, 'day');
        },
        cultureCode() {
            return $("#hdfCultureCode").val();
        }
    },
    methods: {},
    props: ['product'],
    components: {
      'ajax-select': AjaxSelect,
      'date-picker': DatePicker,
      'pax-selector': PaxSelector
    }
}

</script>
