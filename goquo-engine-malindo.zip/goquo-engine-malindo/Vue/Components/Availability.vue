﻿<template>
    <div>
        <div v-if="packageQuery">
            <SessionTimeout :packageId="packageQuery.id" :secondTimeout="packageQuery.ttl"></SessionTimeout>
            <!--Error Msg-->
            <section class="error-overlay" v-if="hasErrorMessage">
                <div class="container">
                    <div class="error-overlay-content">
                        <img class="not-found" src="/images/not-found.svg" alt="not-found" />
                        <h3>{{errorMessage}}</h3>
                        <a class="btn btn-lg btn-backtohome" href="/">
                            <span v-lang.BACKTOHOME>Back to Home</span>
                        </a>
                        <a class="btn btn-primary btn-lg" data-toggle="modal" data-target="#modifySearch">
                            <span v-lang.MODIFY_SEARCH>MODIFY SEARCH</span>
                        </a>
                    </div>
                </div>
            </section>
            <!--Modify search start-->
            <section class="modify-search">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-6 col-md-2" v-if="enabledFlights">
                            <div class="modify-search-list">
                                <i class="icon icon-maps"></i>
                                <p>
                                    <strong><span v-lang.ORIGIN>Origin</span></strong>
                                    <span>{{packageQuery.from}} - {{packageQuery.fromCityName}}</span>
                                </p>
                            </div>
                        </div>
                        <div class="col-xs-6 col-md-2">
                            <div class="modify-search-list">
                                <i class="icon icon-maps"></i>
                                <p>
                                    <strong><span v-lang.DESTINATION>Destination</span></strong>
                                    <span>{{packageQuery.to}} - {{packageQuery.toCityName}}</span>
                                </p>
                            </div>
                        </div>
                        <div class="col-xs-6 col-md-2">
                            <div class="modify-search-list">
                                <i class="icon icon-calendar"></i>
                                <p>
                                    <strong><span v-lang.DATES>Dates</span></strong>
                                    <span>
                                        {{ packageQuery.departureDate| moment("DD MMM") }} - {{ packageQuery.returnDate| moment("DD MMM") }}
                                    </span>
                                </p>
                            </div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <div class="modify-search-list">
                                <i class="icon icon-user"></i>
                                <p>
                                    <strong><span v-lang.ROOMS_PASSENGERS>Rooms and Passengers</span></strong>

                                    {{roomCount}}
                                    <span v-if="roomCount == 1" v-lang.ROOM>Room</span>
                                    <span v-else v-lang.ROOMS>Rooms</span>

                                    {{calculatePaxCount()}}
                                    <span v-if="calculatePaxCount() == 1" v-lang.PASSENGER>Passenger</span>
                                    <span v-else v-lang.PASSENGERS>Passengers</span>
                                </p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-3 pull-right">
                            <a class="btn btn-link btn-block" data-toggle="modal" data-target="#modifySearch"><span v-lang.MODIFY_SEARCH="">MODIFY SEARCH</span></a>
                        </div>
                    </div>
                </div>
            </section>
            <!--Modify End start-->
            <!--Hotel Modify form modal start-->
            <div class="modal fade booking-tabs mod-search loadCal" id="modifySearch" role="search" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content" v-if="enabledFlights">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="myModalLabel" v-lang.FLIGHT_HOTEL_PACKAGES>Flight + Hotel Packages</h4>
                        </div>
                        <div class="modal-body clearfix">
                            <FlightHotelSearchForm :model="model" :packageQuery="packageQuery" :product="product"></FlightHotelSearchForm>
                        </div>
                    </div>
                    <div class="modal-content" v-if="!enabledFlights">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="myModalLabel" v-lang.HOTELS>Hotels</h4>
                        </div>
                        <div class="modal-body clearfix">
                            <HotelSearchForm :model="model" :packageQuery="packageQuery" :product="product"></HotelSearchForm>
                        </div>
                    </div>
                </div>
            </div>
            <!--Hotel Modify form modal end-->
            <section>
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="title-section">
                                <h4>
                                    <span v-if="enabledFlights" class="title" v-lang.X_TO_X_PACKAGES="{0: packageQuery.fromCityName, 1: packageQuery.toCityName}"></span>
                                    <span v-else class="title" v-lang.HOTELS_IN_X="{0: packageQuery.toCityName}"></span>
                                </h4>
                            </div>
                            <FlightAvailability v-if="enabledFlights" :loading="loading" :flightStore="flightStore" :hotelStore="hotelStore" @flightChanged="onFlightChanged"></FlightAvailability>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 col-sm-4 col-xs-12 col-filter">
                            <div class="view-map hidden-xs" @click="toggleMapView()" v-if="enabledMapView">
                                <span>
                                    <i class="icon icon-search"></i>
                                    <em v-show="!hotelStore.maxHotelPrice" v-lang.LOADING_MAP>Loading Map</em>
                                    <em v-show="showMapView && hotelStore.maxHotelPrice > 0" v-lang.CLOSE_MAP>Close Map</em>
                                    <em v-show="!showMapView && hotelStore.maxHotelPrice > 0" v-lang.MAP_VIEW>Map View</em>
                                </span>
                            </div>
                            <!--Loader filter - start-->
                            <div class="filter" v-if="!loading.hotelFirstLoad">
                                <div class="filter-body">
                                    <div class="filter-list">
                                        <div class="form-group">
                                            <label><span v-lang.TOTAL_PACKAGE_PRICE>Total package price</span></label>
                                            <div class="load"></div>
                                            <div class="load load50"></div>
                                            <div class="load load50"></div>
                                        </div>
                                    </div>
                                    <div class="filter-list">
                                        <div class="form-group">
                                            <label><span v-lang.HOTEL_NAME>Hotel Name</span></label>
                                            <div class="load"></div>
                                            <div class="load load50"></div>
                                            <div class="load load50"></div>
                                        </div>
                                    </div>
                                    <div class="filter-list">
                                        <div class="form-group">
                                            <label><span v-lang.STAR_RATING>Star Rating</span></label>
                                            <div class="load"></div>
                                            <div class="load load50"></div>
                                            <div class="load load50"></div>
                                        </div>
                                    </div>
                                    <div class="filter-list">
                                        <div class="form-group">
                                            <label><span v-lang.LOCATIONS>Locations</span></label>
                                            <div class="load"></div>
                                            <div class="load load50"></div>
                                            <div class="load load50"></div>
                                        </div>
                                    </div>
                                    <div class="filter-list">
                                        <div class="form-group">
                                            <label><span v-lang.FACILITIES>Facilities</span></label>
                                            <div class="load"></div>
                                            <div class="load load50"></div>
                                            <div class="load load50"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--Loader filter - end-->
                            <HotelFilters v-if="loading.hotelFirstLoad" :packageQuery="packageQuery" :hotelStore="hotelStore" :flightStore="flightStore" :hotelsOptions="hotelsOptions" :isSearchCompleted="isSearchCompleted" v-on:changed="onFiltersChanged" :flightChangePrice="flightChangePrice"></HotelFilters>
                        </div>
                        <div class="col-md-9 col-sm-8 col-xs-12">
                            <!--Title and sort start-->
                            <div class="row">
                                <div class="col-xs-12 col-sm-6 ">
                                    <div class="title-section">
                                        <p v-show="!isSearchCompleted" class="mt0">
                                            <span v-lang.LOADING_HOTELS>Loading Hotels</span>
                                            &hellip;
                                        </p>
                                        <p v-show="isSearchCompleted" class="mt0" v-lang.SHOWING_X_OF_X_HOTELS="{0: hotelStore.totalFilteredHotels, 1: Math.max(hotelStore.totalHotels, hotelStore.totalFilteredHotels)}"></p>
                                        <p class="mt0">
                                            <span v-lang.CHECK_IN>Check-in</span>&nbsp;<strong>{{packageQuery.checkIn || packageQuery.departureDate | moment("ddd, DD MMM")}}</strong>.
                                            <span v-lang.CHECK_OUT>Check-out</span>&nbsp;<strong>{{packageQuery.checkOut || packageQuery.returnDate | moment("ddd, DD MMM") }}</strong>
                                            <span class="hotel-stay">
                                                (<span v-if="hotelStay == 1" v-lang.ONE_NIGHT>1 night</span><span v-else v-lang.X_NIGHTS="{0: hotelStay}"></span>)
                                            </span>
                                        </p>
                                        <p class="gm-custom-panel" v-if="showMapView">
                                            <span v-lang.PRICE>Price</span>&nbsp;
                                            <span v-if="product.displayPrice == 0" v-lang.PER_NIGHT>per night</span>
                                            <span v-if="product.displayPrice == 1" v-lang.PER_PERSON>per person</span>
                                            <span v-if="product.displayPrice == 2" v-lang.PER_ROOM>per room</span>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-6">
                                    <div class="is-tablet-sticky" v-show="isSearchCompleted">
                                        <span class="filter-header filter-show filter-active" @click="toggleFilter()">
                                            <i class="icon icon-filter"></i> <span v-lang.FILTER_BY>Filter By</span>
                                        </span>
                                        <span class="mob-map" @click="toggleMapView()">
                                            <i class="icon icon-maps"></i> <span v-show="showMapView" v-lang.CLOSE_MAP>Close Map</span> <span v-show="!showMapView" v-lang.MAP_VIEW>Map View</span>
                                        </span>
                                    </div>
                                    <div class="dropdown sort-dropdown">
                                       <Sort @changValue="setSortOrderBy"/>
                                    </div>
                                </div>
                            </div>
                            <!--Title and sort end-->

                            <p class="custom-alert" v-show="hotelStore.totalFilteredHotels === 0 && isSearchCompleted && !showMapView" v-cloak>
                                <span class="icon icon-filter"></span><strong v-lang.NO_HOTELS_MATCH_YOUR_FILTERS>No hotels match your filters</strong>
                                <span v-lang.ADJUST_YOUR_FILTERS>You can see more hotels by adjusting your filters.</span>
                                <br />
                                <a href="javascript:void(0)" @click="resetFilter()">
                                    <span v-lang.CLEAR_FILTERS>Clear filters</span>
                                </a>
                            </p>
                            <div v-if="!loading.hotelFirstLoad">
                                <div class="result-item load-para">
                                    <div class="result-content result-left">
                                        <div class="load loadH100"></div>
                                    </div>
                                    <div class="result-content result-right">
                                        <br />
                                        <div class="load"></div>
                                        <div class="load load25 pull-right"></div>
                                    </div>
                                    <div class="result-content result-center">
                                        <div class="result-center-hotelinfo">
                                            <div class="load mt10"></div>
                                            <div class="load load50"></div>
                                            <div class="load load50"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="result-item load-para">
                                    <div class="result-content result-left">
                                        <div class="load loadH100"></div>
                                    </div>
                                    <div class="result-content result-right">
                                        <br />
                                        <div class="load"></div>
                                        <div class="load load25 pull-right"></div>
                                    </div>
                                    <div class="result-content result-center">
                                        <div class="result-center-hotelinfo">
                                            <div class="load mt10"></div>
                                            <div class="load load50"></div>
                                            <div class="load load50"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="result-item load-para">
                                    <div class="result-content result-left">
                                        <div class="load loadH100"></div>
                                    </div>
                                    <div class="result-content result-right">
                                        <br />
                                        <div class="load"></div>
                                        <div class="load load25 pull-right"></div>
                                    </div>
                                    <div class="result-content result-center">
                                        <div class="result-center-hotelinfo">
                                            <div class="load mt10"></div>
                                            <div class="load load50"></div>
                                            <div class="load load50"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div v-if="enabledMapView">
                                <div id="mapBoxContainer" :class="showMapFull?'mapFull':'mapInline'" v-show="showMapView">
                                    <div class="map_overlay" @click="toggleMapView()"></div>
                                    <iframe id="mapBox" name="mapBox" frameborder="0" style="overflow: hidden; height: 60vh; width: 100%" height="60vh" width="100%">Loading...</iframe>
                                </div>
                            </div>
                            <HotelAvailability v-if="loading.hotelFirstLoad" :packageQuery="packageQuery" :flightStore="flightStore" :hotelStore="hotelStore" :loading="loading" :enabledFlights="enabledFlights" :showMapView="showMapView" v-on:pageChanged="onPageChanged" v-on:showHotelMapView="showHotelMapView"></HotelAvailability>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</template>
<script>
    import Vue from 'vue'
    import { mapState } from 'vuex'
    import FlightAvailability from './FlightAvailability.vue'
    import HotelAvailability from './HotelAvailability.vue'
    import HotelFilters from './HotelFilters.vue'
    import SessionTimeout from './SessionTimeout.vue'
    import FlightHotelSearchForm from './FlightHotelSearchForm.vue'
    import HotelSearchForm from './HotelSearchForm.vue'
    import {Sort} from 'goquo-components'
    export default {
        components: { FlightAvailability, HotelAvailability, HotelFilters, SessionTimeout, FlightHotelSearchForm, HotelSearchForm, Sort },
        data() {
            return {
                packageQuery: null,
                enabledFlights: false,
                hasErrorMessage: false,
                enabledMapView: true,
                showMapView: false,
                showMapFull: false,
                showModifySearch: false,
                isSearchCompleted: false,
                waitingProducts: 0,
                abortPing: false,
                previousStatus: {},
                hotelProduct: null,
                flightHotelProduct: null,
                hideTabFlight: null,
                flightStore: {
                    flights: [],
                    outboundFlight: null,
                    inboundFlight: null
                },
                dataViewMap: {
                    isHotelDetail: false,
                    hotels: []
                },
                hotelStore: {
                    totalFilteredHotels: 0,
                    minHotelPrice: 0,
                    maxHotelPrice: 0,
                    hotels: [],
                    currentPage: 1,
                    pageSize: 25,
                    importantLocations: [],
                    facilities: []
                },
                hotelsOptions: {
                    sortOrderBy: "Priority;DESC",
                    sortOrderByAsc: false,
                    hotelName: null,
                    minPrice: 0,
                    maxPrice: 0,
                    minHotelPrice: 0,
                    maxHotelPrice: 0,
                    stars: ["3", "3.5", "4", "4.5", "5"],
                    roomBoards: [],
                    facilities: [],
                    tripAdvisorRating: [],
                    regionId: null,
                    minDistance: 0,
                    maxDistance: 5
                },
                loading: {
                    flightDetails: false,
                    hotelFirstLoad: false,
                    hotelResult: true,
                    hotelReview: false,
                    bookingPageHI: false
                },
                model: {
                    from: null,
                    to: null,
                    toFullText: null,
                    departureDate: null,
                    returnDate: null,
                    checkIn: null,
                    checkOut: null,
                    partialStay: false,
                    cultureCode: null,
                    regionId: null
                },
                flightChangePrice: 0,
                checkInUrl: null
            }
        },
        computed: mapState({
            siteInfo: state => state.workContext.siteInfo,
            product: state => state.workContext.product,
            roomCount() {
                return this.packageQuery.paxInfos.length;
            },
            persons() {
                return 1;
            },
            hotelStay() {
                var start = this.packageQuery.checkIn || this.packageQuery.departureDate;
                var end = this.packageQuery.checkOut || this.packageQuery.returnDate;
                return moment(end).diff(moment(start), 'days');
            }
        }),
        created() {
            var self = this;
            self.model.regionId = self.$route.query.RegionId;
            self.hotelsOptions.regionId = self.model.regionId;

            var packageId = $("#PackageId").val();
            
            $.post('/package/work-context/' + packageId, function (data) {
                self.$store.commit('setWorkContext', data);

                if (data.packageQuery) {
                    data.packageQuery.departureDate = moment.utc(data.packageQuery.departureDate);
                    data.packageQuery.returnDate = moment.utc(data.packageQuery.returnDate);
                    data.packageQuery.checkIn = moment.utc(data.packageQuery.checkIn);
                    data.packageQuery.checkOut = moment.utc(data.packageQuery.checkOut);

                    self.packageQuery = data.packageQuery;
                    self.model.from = data.packageQuery.from;
                    self.model.to = data.packageQuery.to;
                    self.model.toCityName = data.packageQuery.toCityName;
                    self.model.toCountryName = data.packageQuery.toCountryName;
                    self.model.fromFullText = data.packageQuery.fromCityName + " (" + data.packageQuery.from + ") ," + data.packageQuery.fromCountryName;
                    self.model.toFullText = data.packageQuery.toCityName + " (" + data.packageQuery.to + ") ," + data.packageQuery.toCountryName;
                    self.model.cultureCode = data.packageQuery.cultureCode;
                    self.model.departureDate = data.packageQuery.departureDate;
                    self.model.returnDate = data.packageQuery.returnDate;
                    self.model.checkIn = data.packageQuery.checkIn;
                    self.model.checkOut = data.packageQuery.checkOut;


                    var checkInUrl = self.getUrlParam("CheckIn");
                    var checkOutUrl = self.getUrlParam("CheckOut");
                    self.checkInUrl = self.getUrlParam("CheckIn");

                    if (checkInUrl && checkOutUrl) {
                        self.model.partialStay = true;
                    } else {
                        self.model.partialStay = false;
                    }

                    if (data.product.products.some(function (x) { return x.productType === 1; })) {
                        // Flight
                        self.enabledFlights = true;
                        self.waitingProducts++;
                    }

                    // Hotel
                    self.waitingProducts++;

                    var checkInDate = data.packageQuery.checkIn ? data.packageQuery.checkIn : data.packageQuery.departureDate;
                    var checkOutDate = data.packageQuery.checkOut ? data.packageQuery.checkOut : data.packageQuery.returnDate;
                    var key = moment.utc(checkInDate).format('YYYYMMDD') + "-" + moment.utc(checkOutDate).format('YYYYMMDD');
                    self.createPingRequest(key);

                    self.getStaticHotels();
                    self.getRegions();
                }

                self.hotelProduct = data.products.filter(x => x.type == 'Hotel')[0];
                self.flightHotelProduct = data.products.filter(x => x.type == 'Flight_Hotel')[0];

                $.ajax({
                    url: '/api/get-airports',
                    data: {
                        term: self.packageQuery.hotelDestination
                    },
                    traditional: true,
                    type: 'GET',
                    success: function (data) {
                        if (data.length === 0) {
                            self.hideTabFlight = true;
                        }
                        else {
                            self.hideTabFlight = false;
                        }
                    }
                });


                if (jQuery().fotorama) {
                    console.log("Initialization fotorama");
                    $('.fotorama').fotorama();
                }
            }).fail(function () {
                window.location.reload();
            });

            window.mapviewActionQueue = [];
            window.priceFac = function (h) {
                var price = self.totalPackagePrice(h);
                var paxCount = 0;
                for (var i = 0; i < h.availableRooms.length; i++) {
                    paxCount += h.availableRooms[i].adults;
                    paxCount += h.availableRooms[i].children;
                }
                var displayPrice = self.$store.state.workContext.product.displayPrice;
                var nightCount = self.calculateNights();

                if (displayPrice == 0) {
                    var formatPrice = (parseFloat(price.replace(",", "")) / nightCount).toFixed(self.packageQuery.currencyDecimals);
                }
                if (displayPrice == 1) {
                    var formatPrice = (parseFloat(price.replace(",", "")) / paxCount).toFixed(self.packageQuery.currencyDecimals);
                }

                return self.packageQuery.currency + " " + formatPrice.replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            };
        },
        mounted() {
        },
        methods: {
            createPingRequest: function (key) {
                var self = this;

                if (self.hasErrorMessage || self.abortPing) {
                    // Ping in 60 seconds only
                    return;
                }

                var productTypes = [];
                if (self.enabledFlights) {
                    // Flight
                    productTypes.push({
                        productType: 1,
                        storedKey: ''
                    });
                }

                // Hotel
                productTypes.push({
                    productType: 2,
                    storedKey: key
                });

                var baseUrl = "/package/product-status/" + self.packageQuery.id;

                $.post(baseUrl, { productTypeStatuses: productTypes }, function (data) {
                    if (data.length > 0) {

                        if (data.some(x => x.status == 3)) {
                            window.location = '/package/restart-search/' + self.packageQuery.id;
                        }

                        var completed = data.every(x => x.status == 1);
                        var haveErrors = data.some(x => x.status == 2);

                        if (haveErrors) {
                            self.notifyErrorMessage(data.find(x => x.status == 2).message);
                        } else {
                            for (var j = 0; j < data.length; j++) {
                                var item = data[j];

                                if (item.status === 1 || item.progress !== 0) {
                                    switch (item.product) {
                                        case 1:
                                            if (!self.searchFlightsCompleted) {
                                                console.log("notifyFlightsCompleted");
                                                self.searchFlightsCompleted = true;
                                                self.getFlights();
                                            }
                                            break;
                                        case 2:
                                            if (item.status === 1) {
                                                console.log("notifyHotelsCompleted");
                                                if (!self.searchHotelsCompleted) {
                                                    self.searchHotelsCompleted = true;
                                                    self.getStaticHotels(self.hotelStore.currentPage, function () {
                                                        self.waitingProducts--;
                                                        self.totalHotels = self.hotelStore.totalFilteredHotels;
                                                    });
                                                    self.getHotelFilters();
                                                }
                                            }
                                            else {
                                                var previous = self.previousStatus[item.product];
                                                var newData = !previous || previous.progress < item.progress;

                                                if (newData) {
                                                    console.log("notifyNewHotels");
                                                    self.getStaticHotels(self.hotelStore.currentPage);
                                                 //   self.getHotelFilters();
                                                }

                                                self.previousStatus[item.product] = item;
                                            }
                                            break;
                                    }
                                }
                            }

                            if (!completed) {
                                self.createPingRequest(key);
                            }
                        }
                    } else {
                        self.createPingRequest(key);
                    }
                });
            },
            notifyErrorMessage(errorMessage) {
                console.log("notifyErrorMessage: " + errorMessage);
                this.hasErrorMessage = true;
                this.errorMessage = errorMessage;

                if (typeof dataLayer != 'undefined') {
                    dataLayer.push({
                        'event': 'errorMessage',
                        'eventAction': 'productStatus',
                        'eventLabel': errorMessage
                    });
                };
            },
            getFlights() {
                var self = this;

                $.ajax({
                    url: "/package/get-flights",
                    data: { packageId: this.packageQuery.id },
                    type: "POST",
                    success: function (data) {
                        if (!data.flights || data.flights.length == 0) {
                            if (data.errorMessage) {
                                self.notifyErrorMessage(data.errorMessage);
                            }
                            return;
                        }

                        var flights = data.flights;

                        self.flightStore.totalFilteredFlight = data.totalFlights;
                        self.flightStore.flights = flights;

                        if (data.totalFlights === 0) {
                            self.hasErrorMessage = true;
                            self.errorMessage = data.errorMessage;
                            if (typeof dataLayer != 'undefined') {
                                dataLayer.push({
                                    'event': 'errorMessage',
                                    'eventAction': 'getFlights',
                                    'eventLabel': data.errorMessage
                                });
                            };
                        }

                        // Select cheapest flights
                        if (!self.flightStore.outboundFlightId) {
                            self.flightStore.outboundFlight = flights.filter(function (x) {
                                x.keyGroupCabinClass = x.departureDate + "-" + x.arrivalDate;
                                return x.direction === 0;
                            }).sort(function (a, b) {
                                if (a.price < b.price) {
                                    return -1;
                                }
                                if (a.price > b.price) {
                                    return 1;
                                }
                                return 0;
                            })[0];
                        } else {
                            self.flightStore.outboundFlight = flights.find(function (x) {
                                x.keyGroupCabinClass = x.departureDate + "-" + x.arrivalDate;
                                return x.id === self.flightStore.outboundFlightId && x.direction === 0;
                            });
                        }

                        if (self.packageQuery.journeyType === 1) {
                            if (!self.flightStore.inboundFlightId) {
                                var departureRoute = self.flightStore.outboundFlight.departureAirportCode + self.flightStore.outboundFlight.arrivalAirportCode;

                                self.flightStore.inboundFlight = flights.filter(function (x) {
                                    x.keyGroupCabinClass = x.departureDate + "-" + x.arrivalDate;
                                    if (x.direction !== 1) {
                                        return false;
                                    }
                                    var returnRoute = x.arrivalAirportCode + x.departureAirportCode;
                                    return departureRoute === returnRoute;
                                }).sort(function (a, b) {
                                    if (a.price < b.price) {
                                        return -1;
                                    }
                                    if (a.price > b.price) {
                                        return 1;
                                    }
                                    return 0;
                                })[0];
                            } else {
                                self.flightStore.inboundFlight = flights.find(function (x) {
                                    x.keyGroupCabinClass = x.departureDate + "-" + x.arrivalDate;
                                    return x.id === self.flightStore.inboundFlightId && x.direction === 1;
                                });
                            }
                        }

                        self.applySearchHotelByBestCheckInDate();
                        self.showProgressBar = false;
                        self.loading.flightDetails = true;
                        self.waitingProducts--;

                        // Force refresh hotels loading
                        self.forceRenderHotels();
                    },
                    error: function () {
                        self.hasErrorMessage = true;
                    }
                });
            },
            getStaticHotels(newPage, callback) {
                this.loading.hotelResult = false;
                this.hotelStore.currentPage = newPage || 1;
                var parameters = jQuery.extend(true, {}, this.hotelsOptions);

                parameters.packageId = this.packageQuery.id;
                parameters.pageIndex = this.hotelStore.currentPage;
                parameters.pageSize = this.hotelStore.pageSize;

                // Process sorting
                if (parameters.sortOrderBy.indexOf(";") > -1) {
                    var split = parameters.sortOrderBy.split(";");
                    parameters.sortOrderBy = split[0];
                    parameters.sortOrderByAsc = split[1] === "ASC";
                }

                var self = this;

                $.ajax({
                    url: '/package/get-static-hotels',
                    data: parameters,
                    type: 'POST',
                    success: function (data) {

                        for (var i = 0; i < data.hotels.length; i++) {
                            var hotel = data.hotels[i];
                            self.prepareHotel(hotel);
                        }

                        self.hotelStore.hotels = data.hotels;
                        if (data.hotels && data.hotels.length == 1) {
                            window.selectedHotel = hotel;
                        }

                        if (data.hotels.length > 0 && data.hotels.all(function (i) { return i.cheapestPrice === 0; })) {
                            //self.getHotels();
                        }
                        else {
                            self.showProgressBar = false;
                        }

                        self.hotelStore.totalFilteredHotels = data.totalFiltedHotels;
                        if (data.totalHotels % self.hotelStore.pageSize === 0) {
                            self.hotelStore.totalPages = data.totalFiltedHotels / self.hotelStore.pageSize;
                        } else {
                            self.hotelStore.totalPages = parseInt(data.totalFiltedHotels / self.hotelStore.pageSize) + 1;
                        }

                        self.loading.hotelResult = true;
                        self.loading.hotelFirstLoad = true;

                        if (callback) {
                            callback();
                        }

                        self.movetoRegion();
                        self.getTrustyouData(self.hotelStore.hotels);
                    }
                });

                self.getHotelFilters();
            },
            getHotels() {
                if (!this.hotelStore.hotels || this.hotelStore.hotels.length === 0) {
                    this.getStaticHotels(1);
                    return;
                }

                var self = this;
                var hotelIds = self.hotelStore.hotels.map(x => x.hotelId);

                $.ajax({
                    url: '/package/get-hotels',
                    data: {
                        packageId: this.packageQuery.id,
                        hotelIds: hotelIds
                    },
                    traditional: true,
                    type: 'POST',
                    success: function (data) {

                        // Fill hotels price
                        for (var i = 0; i < data.hotels.length; i++) {
                            var hotel = data.hotels[i];
                            var hotelId = hotel.hotelId;

                            var originHotel = self.hotelStore.hotels.find(function (x) {
                                return x.hotelId === hotelId;
                            });

                            if (originHotel) {
                                self.prepareHotel(hotel);
                                originHotel.cheapestPrice = hotel.cheapestPrice;
                                originHotel.availableRooms = hotel.availableRooms;
                                originHotel.priorityMessage1 = hotel.priorityMessage1;
                                originHotel.priorityMessage2 = hotel.priorityMessage2;
                                originHotel.priorityMessage3 = hotel.priorityMessage3;
                            }
                        }
                    }
                });
            },
            prepareHotel(hotel) {
                hotel.specialOffers = [];
                if (hotel.availableRooms) {
                    for (var j = 0; j < hotel.availableRooms.length; j++) {

                        for (var k = 0; k < hotel.availableRooms[j].availableRoomTypes.length; k++) {
                            var availableRoomType = hotel.availableRooms[j].availableRoomTypes[k];
                            if (k === 0) {
                                availableRoomType.selected = true;
                            } else {
                                availableRoomType.selected = false;
                            }

                            if (availableRoomType.specialOffers && availableRoomType.specialOffers.length > 0) {
                                for (var l = 0; l < availableRoomType.specialOffers.length; l++) {
                                    hotel.specialOffers.push(availableRoomType.specialOffers[l]);
                                }
                            }
                        }
                    }
                }
            },
            getHotelFilters() {
                var self = this;
                $.ajax({
                    url: '/package/get-hotel-filters',
                    data: {
                        packageId: this.packageQuery.id
                    },
                    traditional: true,
                    type: 'POST',
                    success: function (data) {
                        self.processHotelFilters(data);
                    }
                });
            },
            processHotelFilters(data) {
                if (!data) return;

                var minPrice = data.minPrice;
                var maxPrice = data.maxPrice;
                this.hotelStore.minHotelPrice = data.minPrice;
                this.hotelStore.maxHotelPrice = data.maxPrice;

                if (this.flightStore.outboundFlight != null) {
                    minPrice += this.flightStore.outboundFlight.totalPrice;
                    maxPrice += this.flightStore.outboundFlight.totalPrice;
                }

                if (this.flightStore.inboundFlight != null) {
                    minPrice += this.flightStore.inboundFlight.totalPrice;
                    maxPrice += this.flightStore.inboundFlight.totalPrice;
                }

                this.hotelStore.minPrice = Math.floor(minPrice);
                this.hotelStore.maxPrice = Math.ceil(maxPrice);
                this.hotelStore.totalHotels = data.totalHotels;

                // Hard code number of stars, as we always want to show 5 different options
                var stars = ['1', '2', '3', '4', '5'];

                this.hotelStore.stars = stars;
                this.hotelStore.facilities = data.facilities;
            },
            forceRenderHotels() {
                for (var i = 0; i < this.hotelStore.hotels.length; i++) {
                    var hotel = this.hotelStore.hotels[i];
                    Vue.set(this.hotelStore.hotels, i, hotel);
                }
            },
            getTrustyouData(hotels) {
                var self = this;
                self.loading.hotelReview = false;
                var goquoHotelIds = [];
                for (var i = 0; i < hotels.length; i++) {

                    // HACK: Filter out custom HMS hotels as api will return 500 error if there are more than 2 HMS hotel requests.
                    // HMS hotel requests can be removed because no TY data will return anyway
                    if (hotels[i].hotelId.indexOf('HMS') >= 0) { continue; }

                    goquoHotelIds.push(hotels[i].hotelId);
                }
                if (goquoHotelIds.length === 0) {
                    return;
                }
                $.ajax({
                    url: 'https://hotelinfonew.goquo.com/trustyou/v1/' + goquoHotelIds.toString(),
                    type: 'GET',
                    success: function (data) {
                        for (var j = 0; j < hotels.length; j++) {
                            var hotel = hotels[j];
                            var dataIndex = data.map(
                                function (hotelData) { if (hotelData) { return hotelData.id + "" } else { return "000" } }
                            ).indexOf(hotel.hotelId);

                            if (dataIndex !== -1 && data[dataIndex].data.score > 0) {
                                Vue.set(hotel, 'trustyou', data[dataIndex].data);
                                var reviewCircle = 300 - (data[dataIndex].data.score * 3);
                                Vue.set(hotel, 'reviewCircleScore', reviewCircle);
                            }
                        }
                        self.loading.hotelReview = true;

                        self.onTrustYouComplete(data);
                    },
                    error: function (status) {

                    }
                });
            },
            onTrustYouComplete(data) {
            },
            getRegionTypes() {
                var self = this;
                $.ajax({
                    type: 'POST',
                    data: {
                        packageId: this.packageQuery.id
                    },
                    url: '/api/get-region-types',
                    success: function (data) {
                        for (var i = 0; i < data.length; i++) {
                            data[i].isLoaded = false;
                            data[i].regions = [];
                        }

                        self.hotelStore.importantLocations = data;
                    }
                });
            },
            getRegions() {
                var self = this;
                $.ajax({
                    type: 'POST',
                    data: {
                        packageId: this.packageQuery.id
                    },
                    url: '/package/get-regions',
                    success: function (data) {
                        self.hotelStore.importantLocations = data;
                    }
                });
            },
            onFlightChanged(flight) {
                this.flightChangePrice = 0;
                if (flight.direction === 0) {
                    this.flightStore.outboundFlight = flight;
                    this.flightChangePrice += this.flightStore.outboundFlight.totalPrice;
                }
                else {
                    this.flightStore.inboundFlight = flight;
                    this.flightChangePrice += this.flightStore.inboundFlight.totalPrice;
                }
                this.applySearchHotelByBestCheckInDate();
            },
            setSortOrderBy(orderBy) {
                this.hotelsOptions.sortOrderBy = orderBy;// = orderBy || this.hotelsOptions.sortOrderBy;
                if (orderBy.indexOf(";") === -1) {
                    if (orderBy === 'Priority') {
                        this.hotelsOptions.sortOrderBy = 'Priority';
                        this.hotelsOptions.sortOrderByAsc = false;
                    } else {
                        if (this.hotelsOptions.sortOrderBy === orderBy) {
                            this.hotelsOptions.sortOrderByAsc = !this.hotelsOptions.sortOrderByAsc;
                        } else {
                            this.hotelsOptions.sortOrderBy = orderBy;
                        }
                    }
                }

                this.getStaticHotels(1);
            },
            onFiltersChanged() {
                this.getStaticHotels(1);
            },
            onPageChanged(page) {
                this.getStaticHotels(page);
                $('html,body').animate({ scrollTop: $("#hotelSection").offset().top - 120 }, 'slow');
            },
            calculatePaxCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                    count += paxInfo.childCount;
                    count += paxInfo.infantCount;
                }
                return count;
            },
            totalPackagePrice(hotel) {
                var price = this.totalPackagePriceValue(hotel);

                if (price === 0) {
                    return "-";
                }
                return (price.toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            totalPackagePriceValue(hotel) {
                if (hotel.cheapestPrice === 0) {
                    return 0;
                }

                if (this.enabledFlights && !this.flightStore.outboundFlight) {
                    return 0;
                }

                if (!hotel.availableRooms) {
                    return 0;
                }

                var price = 0;
                for (var j = 0; j < hotel.availableRooms.length; j++) {
                    for (var k = 0; k < hotel.availableRooms[j].availableRoomTypes.length; k++) {
                        var availableRoomType = hotel.availableRooms[j].availableRoomTypes[k];
                        if (availableRoomType.selected) {
                            price += availableRoomType.totalPrice;
                            break;
                        }
                    }
                }
                price += this.totalFlightPrice();

                return price;
            },
            totalFlightPrice() {
                var price = 0;
                if (this.flightStore.outboundFlight) {
                    price += this.flightStore.outboundFlight.totalPrice;
                }

                if (this.flightStore.inboundFlight) {
                    price += this.flightStore.inboundFlight.totalPrice;
                }

                return price;
            },
            toggleMapView() {
                if (!this.enabledMapView) {
                    return;
                }

                this.showMapView = !this.showMapView;

                if (this.showMapView) {
                    this.renderMap();
                } else {
                    this.showMapFull = false;
                    $(".slick-slider").resize();
                }
            },
            toggleFilter() {
                $("#filterPanelResult .filter-body").toggleClass('is-open');
            },
            showHotelMapView(hotel) {
                window.selectedHotel = hotel;
                this.showMapFull = true;
                this.showMapView = true;
                this.renderMap();
                this.movetoLocation(hotel.latitude, hotel.longitude);
            },
            renderMap() {
                var sefl = this;
                sefl.dataViewMap.hotels = sefl.hotelStore.hotels;
                var map = document.getElementById("mapBox").contentWindow;
                if (sefl.mapViewRendered) {
                    map.postMessage(sefl.dataViewMap, '*');
                    return;
                }
                sefl.mapViewRendered = true;
                $("#mapBox").attr("src", "/package/map-view/" + sefl.packageQuery.id);
                $('iframe').load(function () {
                    map.postMessage(sefl.dataViewMap, '*');
                });
            },
            movetoRegion() {
                if (this.hotelStore.hotels && this.hotelStore.hotels.length > 0) {
                    for (var i = 0; i < this.hotelStore.hotels.length; i++) {
                        var h = this.hotelStore.hotels[i];
                        if (isValidCoordinate(h.latitude, h.longitude)) {
                            this.movetoLocation(h.latitude, h.longitude);
                            return;
                        }
                    }
                }
                else {
                    var map = document.getElementById("mapBox").contentWindow;
                    this.dataViewMap.hotels = this.hotelStore.hotels;
                    map.postMessage(this.dataViewMap, '*');
                }

                window.top.mapPos = null;
            },
            movetoLocation(lat, lon) {
                var map = document.getElementById("mapBox").contentWindow;
                window.top.mapPos = {
                    zoom: 15,
                    latitude: lat,
                    longitude: lon
                };

                this.dataViewMap.hotels = this.hotelStore.hotels;
                map.postMessage(this.dataViewMap, '*');

                if (map.hasOwnProperty("movetoLocation")) {
                    map.movetoLocation(lat, lon, 15);
                }
                else {
                    window.mapviewActionQueue.push(function () {
                        //map.movetoLocation(lat, lon, 12);
                    });
                }
            },
            resetFilter() {
                window.selectedHotel = null;
                window.location.reload();
            },
            clearSelection(fieldName, event) {
                event.preventDefault();
                $(fieldName).trigger('click');
                return false;
            },
            isInt(value) {
                return !isNaN(value) && (function (x) { return (x | 0) === x; })(parseFloat(value))
            },
            clearStars(star, event) {
                event.preventDefault();
                $("#" + star + "star").trigger('click');
                return false;
            },
            calculateNights() {
                var oneDay = 24 * 60 * 60 * 1000;
                var returnDate = Date.parse(this.packageQuery.returnDate);
                var departureDate = Date.parse(this.packageQuery.departureDate);
                var nights = Math.round(Math.abs((returnDate - departureDate) / (oneDay)));
                return nights;
            },
            getBestCheckInDate() {
                var self = this;
                if (!self.siteInfo || !self.siteInfo.cutOffTime || !self.flightStore.outboundFlight)
                    return;

                var arrivalOutboundDate = new moment.utc(self.flightStore.outboundFlight.arrivalDate);
                var arrivalOutboundTime = new moment.utc(new moment.utc(self.flightStore.outboundFlight.arrivalDate).format("HH:mm"), "HH:mm");
                var cutOffTime = new moment.utc(self.siteInfo.cutOffTime, "HH:mm");

                var arrivalDateWithoutTime = new moment.utc(self.flightStore.outboundFlight.arrivalDate).set({
                    hour: 0, minute: 0, second: 0, millisecond: 0
                });
                var checkinDateWithoutTime = new moment.utc(self.packageQuery.checkIn || self.packageQuery.departureDate).set({
                    hour: 0, minute: 0, second: 0, millisecond: 0
                });
                var bestCheckInDate;
                var canNewCheckIn = new moment.utc(self.flightStore.outboundFlight.arrivalDate).subtract(1, "days");
                var canNewCheckInWithOutTime = new moment.utc(canNewCheckIn).set({
                    hour: 0, minute: 0, second: 0, millisecond: 0
                });

                if (!self.model.partialStay) {
                    if (arrivalOutboundTime.isSameOrBefore(cutOffTime, 'times')) {
                        if (checkinDateWithoutTime.isSame(canNewCheckInWithOutTime)) {
                            return;
                        }
                        else {
                            bestCheckInDate = canNewCheckIn;
                        }
                    }
                    else {
                        if (arrivalDateWithoutTime.isSame(checkinDateWithoutTime)) {
                            return;
                        } else {
                            bestCheckInDate = arrivalOutboundDate;
                        }
                    }
                }
                else {
                    if (arrivalOutboundTime.isSameOrBefore(cutOffTime, 'times')) {
                        if (checkinDateWithoutTime.isBefore(canNewCheckInWithOutTime)) {
                            bestCheckInDate = canNewCheckIn;
                        }

                    }
                    else {
                        if (checkinDateWithoutTime.isBefore(arrivalDateWithoutTime)) {
                            bestCheckInDate = arrivalOutboundDate;
                        }
                    }
                }
                return bestCheckInDate;
            },
            applySearchHotelByBestCheckInDate() {
                var self = this;
                var newCheckInDate = self.getBestCheckInDate();
                if (!newCheckInDate) {
                    return;
                }
                self.packageQuery.checkIn = new moment.utc(newCheckInDate).format("YYYY-MM-DD");
                self.packageQuery.checkOut = new moment.utc(self.packageQuery.checkOut || self.packageQuery.returnDate).format("YYYY-MM-DD");
                self.researchHotel(self.packageQuery.id, self.packageQuery.checkIn, self.packageQuery.checkOut);
            },
            researchHotel(packageId, checkInDate, checkOutDate) {
                var self = this;
                $.ajax({
                    url: "/package/research-hotel",
                    data: {
                        packageId: packageId,
                        checkInDate: checkInDate,
                        checkOutDate: checkOutDate
                    },
                    type: "POST",
                    beforeSend: function () {
                    },
                    success: function (data) {
                        if (data.status) {
                            var key = moment(checkInDate).format('YYYYMMDD') + "-" + moment(checkOutDate).format('YYYYMMDD');
                            self.createPingRequest(key);
                        }
                    },
                    error: function () {
                        self.hasErrorMessage = true;
                    }
                });
            },
            getUrlParam(parameter, defaultvalue) {
                var urlparameter = defaultvalue;
                if (window.location.href.indexOf(parameter) > -1) {
                    urlparameter = this.getUrlVars()[parameter];
                }
                return urlparameter;
            },
            getUrlVars() {
                var vars = {};
                var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function (m, key, value) {
                    vars[key] = value;
                });
                return vars;
            }
        },
        watch: {
            waitingProducts: function (newValue) {
                if (newValue == 0) {
                    this.isSearchCompleted = true;
                    this.$store.commit('setIsSearchCompleted');
                    console.log("isSearchCompleted");
                }
            }
        }
    }
</script>