﻿<template>
    <div v-if="packageQuery" class="availability" id="list-result">
        <SessionTimeout :packageId="packageQuery.id" :secondTimeout="packageQuery.ttl"></SessionTimeout>
        <!-- Loader -->
        <div class="book-loading-body" v-show="loading.bookingTour || loadingFilter">
            <div class="book-loading-caption">
                <img src="/images/small_loading.gif" alt="loader" />
                <span v-lang.BOOKING_TOUR>Loading Activities...</span>
            </div>
        </div>

        <section class="error-overlay" v-if="hasErrorMessage">
            <div class="container">
                <div class="error-overlay-content">
                    <img class="not-found" src="/images/not-found.svg" alt="not-found" />
                    <h3>{{errorMessage.replace("Tour", "Activity")}}</h3>
                    <a class="btn btn-lg btn-backtohome" href="/">
                        <span v-lang.BACKTOHOME>Back to Home</span>
                    </a>
                    <a class="btn btn-primary btn-lg" data-toggle="modal" data-target="#modifySearch">
                        <span v-lang.MODIFY_SEARCH>MODIFY SEARCH</span>
                    </a>
                </div>
            </div>
        </section>

        <!--Modify search start-->
        <section class="modify-search">
            <div class="container">
                <div class="row">
                    <div class="col-xs-6 col-md-2">
                        <div class="modify-search-list">
                            <i class="icon icon-maps"></i>
                            <p>
                                <strong><span v-lang.DESTINATION>Destination</span></strong>
                                <span>{{packageQuery.to}} - {{packageQuery.toCityName}}</span>
                            </p>
                        </div>
                    </div>
                    <div class="col-xs-6 col-md-2">
                        <div class="modify-search-list">
                            <i class="icon icon-calendar"></i>
                            <p>
                                <strong><span v-lang.DATES>Dates</span></strong>
                                <span>
                                    {{ packageQuery.departureDate| moment("MMM DD") }} - {{ packageQuery.returnDate| moment("MMM DD") }}
                                </span>
                            </p>
                        </div>
                    </div>
                    <div class="col-xs-6 col-md-3">
                        <div class="modify-search-list">
                            <i class="icon icon-user"></i>
                            <p>
                                <strong><span v-lang.PAX_INFO>Pax Info</span></strong>

                                {{adults + children}}
                                <span v-if="adults + children == 1" v-lang.PASSENGER>Passenger</span>
                                <span v-else v-lang.PASSENGERS>Passengers</span>
                            </p>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-3 pull-right">
                        <a class="btn btn-link btn-block" data-toggle="modal" data-target="#modifySearch"><span v-lang.MODIFY_SEARCH="">MODIFY SEARCH</span></a>
                    </div>
                </div>
            </div>
        </section>
        <!--Modify End start-->

        <div class="modal fade booking-tabs mod-search loadCal tour-modify-search" id="modifySearch" role="search" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel" v-lang.SEARCH_FOR_ACTIVITY>Search for Activity</h4>
                    </div>
                    <div class="modal-body clearfix">
                        <form method="GET" action="/package/start-search" data-val="true">
                            <div class="input-daterange">
                                <div class="row">
                                    <div class="col-md-12 right-icon right-icon-n">
                                        <input type="hidden" name="PromoCode" :value="promoCode" />
                                        <div class="form-group">
                                            <i class="icon icon-map-marker input-icon extra-right"></i>
                                            <label v-lang.Destination>Destination</label>
                                            <AjaxSelect id="To" name="To" :defaultValue="packageQuery.to" :defaultText="packageQuery.toCityName+ ' (' + packageQuery.to + '), ' + packageQuery.toCountryName" :placeholder="translateText('CHOOSE_A_CITY','Choose a city...')" :url="'/api/get-cities'"></AjaxSelect>
                                            <input type="hidden" name="To" value="packageQuery.to" />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 right-icon right-icon-n">
                                        <div class="form-group">
                                            <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                                            <label v-lang.START_DATE>Start Date</label>
                                            <DatePicker name="DepartureDate" v-model="packageQuery.departureDate"></DatePicker>
                                        </div>
                                    </div>
                                    <div class="col-md-6 right-icon right-icon-n">
                                        <div class="form-group">
                                            <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                                            <label v-lang.END_DATE>End Date</label>
                                            <DatePicker name="ReturnDate" v-model="packageQuery.returnDate" :startDate="packageQuery.departureDate" :addOneDay="1" autoFocus="true"></DatePicker>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 right-icon right-icon-n">
                                        <div class="form-group">
                                            <i class="icon icon-user input-icon input-icon-highlight"></i>
                                            <label v-lang.PAX_INFO>Pax Info</label>
                                            <PaxSelector :maxRooms="1" tour="true"></PaxSelector>
                                        </div>
                                    </div>
                                    <!--<div class="col-md-6">
                                        <div class="form-group form-group-icon-left">
                                            <i class="icon icon-money input-icon input-icon-highlight extra-right"></i>
                                            <label v-lang.CURRENCY>Currency</label>
                                            <SelectCurrency name="Currency" url="/api/get-currencies" placeholder="Select your currency" :defaultValue="packageQuery.currency"></SelectCurrency>
                                        </div>
                                    </div>-->
                                    <div class="col-md-12">
                                        <label>&nbsp;</label>
                                        <div class="pull-right">
                                            <input type="hidden" name="ProductId" :value="product.id" />
                                            <input type="hidden" name="CultureCode" value="en-US" />
                                            <button type="submit" id="searchForm" class="btn btn-primary" v-lang.SEARCH_FOR_ACTIVITY>Search for Activity</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <section class="hotel-details">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="title-section">
                                    <h4 class="title"><span v-lang.CHOOSE_YOUR_ACTIVITY_IN>Choose your Activity in</span> <span class="txt-primary">{{packageQuery.toCityName}}</span></h4>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="alert alert-danger panel-collapse" v-show="hasErrorMessage" v-html="errorMessage" style="margin: 0 0 25px 0;"></div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-8 col-md-9">
                                <nav v-if="!(isSearchCompleted && !hasErrorMessage)" role="navigation" class="navbar navbar-default customnav p-10">
                                    <div class="load"></div>
                                    <div class="load"></div>
                                </nav>
                                <nav v-if="isSearchCompleted && !hasErrorMessage" role="navigation" class="navbar navbar-default customnav">
                                    <div class="navbar-header">
                                        <a class="navbar-brand"><small class="title" v-lang.SORT_BY>Sort By</small><span class="icon icon-sort"></span></a>
                                    </div>

                                    <ul class="nav navbar-nav nav-tour">
                                        <li :class="{'active': tourFilter.sortOrderBy == 'Priority'}">
                                            <a v-on:click="sorting('Priority');">
                                                <span><span v-lang.MOST_POPULAR>Most Popular</span> <span class="icon icon-group"></span></span>
                                                <span class="icon icon-down-chevron hidden-xs hidden-icon"></span>
                                            </a>
                                        </li>
                                        <li :class="{'active': tourFilter.sortOrderBy == 'Price'}">
                                            <a v-on:click="sorting('Price');">
                                                <span><span v-lang.ACTIVITY_PRICE>Activity Price</span> <span class="icon icon-dollar-symbol"></span></span>
                                                <span class="icon icon-down-chevron" v-show="tourFilter.sortOrderBy == 'Price' && tourFilter.sortOrderByAsc == false"></span>
                                                <span class="icon icon-up-chevron" v-show="tourFilter.sortOrderBy == 'Price' && tourFilter.sortOrderByAsc"></span>
                                            </a>
                                        </li>
                                        <li :class="{'active': tourFilter.sortOrderBy == 'Name'}">
                                            <a v-on:click="sorting('Name');">
                                                <span><span v-lang.ACTIVITY_NAME>Activity Name</span> <span class="icon icon-camera"></span></span>
                                                <span class="icon icon-up-chevron" v-show="tourFilter.sortOrderBy == 'Name' && tourFilter.sortOrderByAsc"></span>
                                                <span class="icon icon-down-chevron" v-show="tourFilter.sortOrderBy == 'Name' && tourFilter.sortOrderByAsc == false"></span>
                                            </a>
                                        </li>
                                    </ul>

                                    <ul class="nav navbar-nav pull-right">
                                        <li class="active">
                                            <a v-on:click="openFilter()">
                                                <span class="icon icon-filter"></span>
                                            </a>
                                        </li>
                                    </ul>
                                </nav>
                                <p class="custom-alert" v-show="isNoDataResult" v-cloak>
                                    <span class="icon icon-filter"></span><strong v-lang.NO_TOURS_MATCH_YOUR_FILTERS>No tours match your filters</strong>
                                    <span v-lang.ADJUST_YOUR_FILTERS>You can see more tours by adjusting your filters.</span>
                                    <br />
                                    <a href="javascript:void(0)" @click="resetFilter()">
                                        <span v-lang.CLEAR_FILTERS>Clear filters</span>
                                    </a>
                                </p>
                                <div v-if="!hasErrorMessage && !isNoDataResult">
                                    <div class="sort-list tours-list">
                                        <div class="modal fade" id="my-modal" role="dialog" style="overflow-x:hidden; overflow-y:auto;">
                                            <div class="modal-dialog">
                                                <div class="modal-content" v-if="tourInfor">
                                                    <div class="modal-header">
                                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                        <h4 class="modal-title">{{tourInfor.name}} <span class="added-tour" v-if="tourInfor.selected"><i class="icon icon-checked" aria-hidden="true"></i>&nbsp;<span v-lang.ADDED>Added</span></span></h4>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-md-8 col-sm-12">
                                                                <div v-if="tourInfor.images && tourInfor.images.length > 0" id="tour-popup-carousel" class="carousel slide" data-ride="carousel">
                                                                    <div class="carousel-inner">
                                                                        <div class="item" v-if="" :class="{'active': !index}" v-for="(tourImage, index) in tourInfor.images">
                                                                            <img :src="tourImage" :alt="tourInfor.name" v-if="index === 0" onerror="this.src='/images/photo-not-available.png';">
                                                                            <img :data-lazy="tourImage" :alt="tourInfor.name" v-else>
                                                                        </div>
                                                                    </div>

                                                                    <!-- Left and right controls -->
                                                                    <a class="left carousel-control" href="#tour-popup-carousel" data-slide="prev" v-if="tourInfor.images.length > 1">
                                                                        <span class="icon icon-left-chevron"></span>
                                                                        <span class="sr-only">Previous</span>
                                                                    </a>
                                                                    <a class="right carousel-control" href="#tour-popup-carousel" data-slide="next" v-if="tourInfor.images.length > 1">
                                                                        <span class="icon icon-right-chevron"></span>
                                                                        <span class="sr-only">Next</span>
                                                                    </a>
                                                                </div>
                                                                <div v-else>
                                                                    <img src="/images/photo-not-available.png" :alt="tourInfor.name">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-sm-12">
                                                                <div class="col-xs-12 mb-15">
                                                                    <div class="total-price" :class="{'selected': tourInfor.selected}">
                                                                        <div class="price">
                                                                            <span>{{packageQuery.currency}}</span> <strong v-if="tourInfor.gstMarkupPrice">{{tourInfor.gstMarkupPrice | numberRounder(packageQuery.currencyDecimals)}}</strong>
                                                                        </div>
                                                                        <div>
                                                                            <small class="text-right" v-lang.FOR_X_PASSENGERS="{0: getPaxCount(tourInfor)}"></small>
                                                                        </div>
                                                                        <div class="price-inclusive">
                                                                            <small><span class="icon icon-check-mark"></span><span v-lang.INCLUDES_TAXES_FEES>includes taxes & fees</span></small>
                                                                        </div>

                                                                        <!--<div class="price">-->
                                                                        <!--<span v-lang.TOTAL>Total</span>&nbsp;<span>{{packageQuery.currency}} {{packageQuery.priceSummary.totalPrice | formatCurrency }}</span>-->
                                                                        <!--</div>-->
                                                                        <p>
                                                                            <small v-if="tourInfor.duration"><i class="icon icon-clock" aria-hidden="true"></i> <span><strong v-lang.DURATION>Duration</strong>: <span v-html="tourInfor.duration"></span></span></small>
                                                                        </p>
                                                                    </div>
                                                                    <div class="description" v-if="tourInfor.description">
                                                                        <p>{{tourInfor.description}}</p>
                                                                    </div>
                                                                    <input type="hidden" name="TourId" v-model="tourInfor.id" />
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-12">
                                                                <div class="form-tour-detail mt-15">
                                                                    <form method="POST" action="/package/booking-tour" data-val="true" v-on:submit.prevent="bookingTour($event,tourInfor, tourIndexInfor)">
                                                                        <div class="width-full">
                                                                            <div class="col-xs-12 col-sm-6" v-if="tourInfor.activities && tourInfor.activities.length > 0">
                                                                                <div class="form-group">
                                                                                    <label v-lang.OPTIONS>Options</label>
                                                                                    <select name="ActivityCode"
                                                                                            class="form-control text-uppercase"
                                                                                            :disabled="tourInfor.selected"
                                                                                            v-model="tourInfor.activityCode"
                                                                                            data-val="true"
                                                                                            @change="changeActivity(tourInfor)">
                                                                                        <option v-for="activity in tourInfor.activities" :value="activity.code">
                                                                                            {{activity.name}}
                                                                                        </option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="width-full">
                                                                            <div class="col-xs-12 col-sm-3">
                                                                                <div class="form-group">
                                                                                    <label v-lang.DATE>Date</label>
                                                                                    <select name="OperatorDate"
                                                                                            class="form-control text-uppercase"
                                                                                            :disabled="tourInfor.selected"
                                                                                            v-model="tourInfor.operatorDate"
                                                                                            data-val="true"
                                                                                            @change="changeDailyRate(tourInfor,tourIndexInfor)">
                                                                                        <option value="" v-lang.SELECT>Select</option>
                                                                                        <option v-for="dailyRate in tourInfor.dailyRates" :value="dailyRate.date |  formatDate('YYYY-MM-DD')">
                                                                                            {{dailyRate.date | formatDate('ddd DD MMM YYYY')}}
                                                                                        </option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="width-full">
                                                                            <div class="col-xs-12 col-sm-3" v-if="tourInfor.departures != undefined && tourInfor.departures.length > 0">
                                                                                <div class="form-group">
                                                                                    <label v-lang.DEPARTURE>Departure</label>
                                                                                    <select name="DeparturePoint" class="form-control text-uppercase"
                                                                                            v-if="tourInfor.departures != undefined && tourInfor.departures.length > 0"
                                                                                            :disabled="tourInfor.selected"
                                                                                            v-model="tourInfor.departurePoint"
                                                                                            @change="changeDeparturePoint(tourInfor,tourIndexInfor)"
                                                                                            data-val="true">
                                                                                        <option value="" v-lang.SELECT>Select</option>
                                                                                        <option v-for="departure in tourInfor.departures" :value="departure.code">{{departure.name}}</option>
                                                                                    </select>
                                                                                </div>
                                                                                <span data-valmsg-for="HotelName" data-valmsg-replace="true"></span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="width-full">
                                                                            <div class="col-xs-12 col-sm-3" v-if="tourInfor.departureTimes &&  tourInfor.departureTimes.length > 0">
                                                                                <div class="form-group">
                                                                                    <label v-lang.TIME>Time</label>
                                                                                    <select name="DepartureTime" id="DepartureTime"
                                                                                            v-model="tourInfor.departureTime"
                                                                                            class="form-control text-uppercase"
                                                                                            :disabled="tourInfor.selected"
                                                                                            data-val="true">
                                                                                        <option value="" v-lang.SELECT>Select</option>
                                                                                        <option v-for="time in tourInfor.departureTimes" :value="time">{{time}}</option>
                                                                                    </select>
                                                                                </div>
                                                                                <span data-valmsg-for="DepartureTime" data-valmsg-replace="true"></span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="width-full">
                                                                            <div class="col-xs-12 col-sm-3">
                                                                                <div class="form-group">
                                                                                    <label v-lang.ADULTS>Adults</label>
                                                                                    <select name="Adults" id="Adults"
                                                                                            class="form-control"
                                                                                            v-model="tourInfor.adults"
                                                                                            @change="getTourBreakdown(tourInfor,tourIndexInfor)"
                                                                                            :disabled="tourInfor.selected"
                                                                                            data-val="true">
                                                                                        <option v-for="item in adults" :value="item">{{item}}</option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="width-full">
                                                                            <div class="col-xs-12 col-sm-3" v-if="children > 0">
                                                                                <div class="form-group">
                                                                                    <label v-lang.CHILDREN>Children</label>
                                                                                    <select name="Children" id="Children"
                                                                                            class="form-control"
                                                                                            v-model="tourInfor.children"
                                                                                            @change="getTourBreakdown(tourInfor,tourIndexInfor)"
                                                                                            data-val="true"
                                                                                            :disabled="tourInfor.selected">
                                                                                        <option value="0">0</option>
                                                                                        <option v-for="item in children" :value="item">{{item}}</option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="width-full">
                                                                            <div class="col-xs-12 mr-top-12">
                                                                                <button type="submit" class="btn pull-right btn-success" v-if="!tourInfor.selected">
                                                                                    <span class="text-uppercase">
                                                                                        <span v-lang.ADD_THIS_ACTIVITY>
                                                                                            Add this activity
                                                                                        </span>
                                                                                    </span>
                                                                                </button>
                                                                                <a data-product="tourInfor" v-if="tourInfor.selected" class="btn pull-right btn-danger" v-on:click="removeTour(tourInfor, tourIndexInfor)">
                                                                                    <span class="text-uppercase">
                                                                                        <i class="icon icon-remove" aria-hidden="true"></i>
                                                                                        <span v-lang.REMOVE_ACTIVITY>Remove activity</span>
                                                                                    </span>
                                                                                </a>
                                                                                <a class="btn pull-right bt-loading" v-show="tourInfor.loading">
                                                                                    <i class="icon icon-spin"></i><span v-lang.PROCESSING>&nbsp;Processing...</span>
                                                                                </a>
                                                                                <a class="btn-remove" v-show="tourInfor.errorMessage">
                                                                                    <i class="fa"></i><span>&nbsp;{{tourInfor.errorMessage}}</span>
                                                                                </a>
                                                                            </div>
                                                                            <div class="col-xs-12 mr-top-12">
                                                                                <a v-if="tourInfor.selected" class="btn btn-continue-tour-selection btn-success pull-right" data-dismiss="modal">
                                                                                    <span class="text-uppercase">
                                                                                        <span v-lang.CONTINUE_ACTIVITY_SELECTION>Continue Activity Selection</span>
                                                                                    </span>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-12 mt-15 total-price-popup" v-if="nextButtonUrl && selectedTours && selectedTours.length > 0">
                                                                <div class="separated-line"></div>
                                                                <div class="price">
                                                                    <span v-lang.TOTAL>Total</span>&nbsp;<span>{{packageQuery.currency}} {{packageQuery.priceSummary.totalPrice | formatCurrency }}</span>
                                                                </div>
                                                                <div class="pull-right">
                                                                    <a href="#" v-on:click="checkBookingTour($event, nextButtonUrl)" class="btn btn-success pull-right" v-show="tours.length > 0">
                                                                        <span class="text-uppercase">
                                                                            <span v-lang.NEXT>Continue Booking</span>
                                                                            <i class="icon icon-right-arrow" aria-hidden="true"></i>
                                                                        </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="separated-line"></div>
                                                        <div v-if="tourInfor.summary != undefined && tourInfor.summary.length > 0">
                                                            <h4 v-lang.ACTIVITY_SUMMARY>Activity Summary</h4>
                                                            <p><span class="inline-p-element" v-html="tourInfor.summary"></span></p>
                                                        </div>
                                                        <div v-if="tourInfor.description != undefined && tourInfor.description.length > 0">
                                                            <p><strong v-lang.TOUR_DESCRIPTION>Description</strong></p>
                                                            <p><span v-html="tourInfor.description"></span></p>
                                                        </div>
                                                        <div v-if="tourInfor.inclusions != undefined && tourInfor.inclusions.length > 0">
                                                            <h4 v-lang.ACTIVITY_INCLUDES>Activity Includes</h4>
                                                            <ul>
                                                                <li v-for="inclusion in tourInfor.inclusions">
                                                                    <span v-html="inclusion"></span>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div v-if="tourInfor.note != undefined && tourInfor.note.length > 0">
                                                            <h4 v-lang.ACTIVITY_NOTE>Activity Note</h4>
                                                            <p><span v-html="tourInfor.note"></span></p>
                                                        </div>
                                                        <div v-if="tourInfor.salesPoints != undefined && tourInfor.salesPoints.length > 0">
                                                            <h4 v-lang.SALES_POINT>Sales Point</h4>
                                                            <ul>
                                                                <li v-for="salesPoints in tourInfor.salesPoints">
                                                                    <span v-html="salesPoints"></span>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div v-if="tourInfor.exclusions != undefined && tourInfor.exclusions.length > 0">
                                                            <h4 v-lang.EXCLUSION>Exclusion</h4>
                                                            <ul>
                                                                <li v-for="exclusion in tourInfor.exclusions">
                                                                    <span v-html="exclusion"></span>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div v-if="tourInfor.additionalInfo != undefined && tourInfor.additionalInfo.length > 0">
                                                            <h4 v-lang.ADDITIONAL_INFORMATION>Additional Information</h4>
                                                            <ul>
                                                                <li v-for="additionalInfo in tourInfor.additionalInfo">
                                                                    <span v-html="additionalInfo"></span>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="hotel-list tour-list" v-for="n in 10" v-if="!tours.length">
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-12 col-md-12">
                                                    <div class="result-item hotel-result">
                                                        <div class="result-content result-left">
                                                            <div class="image-tour-big">
                                                                <div class="result-img">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="result-content result-right">
                                                            <div class="result-price">
                                                                <div class="load load50" style="margin: auto 0 auto auto"></div>
                                                            </div>
                                                        </div>
                                                        <div class="result-content result-center">
                                                            <div class="result-center-hotelinfo">
                                                                <h4>
                                                                    <a class="mb10">
                                                                        <div class="load"></div>
                                                                    </a>
                                                                </h4>
                                                            </div>
                                                            <div class="result-center-packageinfo">
                                                                <div class="flight-info">
                                                                    <div class="load"></div>
                                                                    <div class="load"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="hotel-list tour-list" v-for="(tour, index ) in tours" :class="{'added': tour.selected}">
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-12 col-md-12">
                                                    <div class="result-item hotel-result">
                                                        <div class="result-content result-left">
                                                            <div class="image-tour-big">
                                                            <div v-if="tour.images && tour.images.length > 0" :id="'image-'+tour.id" :title="tour.name" class="result-img" :style="{backgroundImage: `url('${tour.images[0]}'),url('../images/photo-not-available.png')`}"></div>
                                                            <div v-if="!tour.images || tour.images.length == 0" :title="tour.name" class="result-img" style="background: transparent url('../images/photo-not-available.png') no-repeat center center;"></div>
                                                            </div>
                                                            <div v-if="tour.images && tour.images.length > 1" class="images-tour-smalls">
                                                            <a v-if="tourImageIndex < 3" v-for="(tourImage,tourImageIndex) in tour.images" href="javascript:void(0)" @click="changeImage($event, tourImage,tour.id)" :style="'background: transparent url(' + tourImage + ') no-repeat center center'"></a>
                                                            </div>
                                                            <!-- <SlickSlider sliderClass="tour-slick-slider" :item="tour.images" :itemIndex="index" isReplaceImage="false" isTour="true"></SlickSlider> -->
                                                        </div>
                                                        <div class="result-content result-right" v-on:click="getFulllTourInfo(tour,index)">
                                                            <div class="result-include">
                                                                <div class="result-price">
                                                                    <strong v-if="tour.gstMarkupPrice">{{packageQuery.currency}}&nbsp;<span>{{ tour.gstMarkupPrice | numberRounder(packageQuery.currencyDecimals)}}</span></strong>
                                                                    <div>
                                                                        <small class="text-right" v-lang.FOR_X_PASSENGERS="{0: getPaxCount(tour)}"></small>
                                                                    </div>
                                                                </div>
                                                                <div class="price-inclusive">
                                                                    <small><span class="icon icon-check-mark"></span><span v-lang.INCLUDES_TAXES_FEES>includes taxes & fees</span></small>
                                                                </div>
                                                                <div class="tour-added-wrapper tour-added-status" v-if="tour.selected">
                                                                    <span class="added-tour white"><i class="icon icon-checked" aria-hidden="true"></i>&nbsp;<span v-lang.ADDED>Added</span></span><br />
                                                                    <span v-lang.OPEN_ACTIVITY_TO_REMOVE>Open activity to remove</span>
                                                                </div>
                                                            </div>
                                                            <div class="result-view">
                                                                <span v-if="tour.selected" class="btn btn-default active" aria-expanded="true" v-lang.SELECTED_ACTIVITY>Selected</span>
                                                                <span v-if="!tour.selected" class="btn btn-default" aria-expanded="true" v-lang.SELECT_ACTIVITY>Select Activity</span>
                                                            </div>
                                                        </div>
                                                        <div class="result-content result-center" v-on:click="getFulllTourInfo(tour,index)">
                                                            <div class="result-center-hotelinfo">
                                                                <h4>
                                                                    <a class="mb10" v-on:click="getFulllTourInfo(tour,index)">
                                                                        {{tour.name}}
                                                                    </a>
                                                                </h4>
                                                            </div>
                                                            <div class="result-center-packageinfo" v-if="tour.duration || tour.summary">
                                                                <div class="flight-info">
                                                                    <p v-if="tour.duration != undefined && tour.duration.length > 0">
                                                                        <i class="icon icon-clock" aria-hidden="true"></i>
                                                                        <span><strong v-lang.DURATION>Duration</strong>: <span v-html="tour.duration"></span></span>
                                                                    </p>
                                                                    <p v-if="tour.summary != undefined && tour.summary.length > 0">
                                                                        <i class="icon icon-contact"></i>
                                                                        <span class="tour-summary"><strong v-lang.SUMMARY>Summary</strong>: <span class="inline-p-element" v-html="tour.summary.length > 180 ? (tour.summary.substr(0, 170) + '...') : tour.summary"></span></span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" v-if="isSearchCompleted && !hasErrorMessage">
                                        <div class="col-xs-12">
                                            <p v-show="pagination.totalTours > 0">
                                                <small v-lang.SHOWING_X_OF_X_ACTIVITIES="{0: pagination.totalTours , 1: packageQuery.toCityName, 2: getFormTourPerPage(pagination.current, pagination.toursPerPage), 3: getFormTourPerTotal(pagination.current, pagination.toursPerPage, pagination.totalTours)}">
                                                </small>
                                            </p>
                                            <p v-show="pagination.totalTours == 0">
                                                <small v-lang.X_ACTIVITY_FOUND_IN_X="{0: pagination.totalTours , 1: packageQuery.toCityName}">
                                                </small>
                                            </p>
                                            <nav aria-label="pagination" v-if="pagination.totalTours > 1">
                                                <ul class="pager">
                                                    <li class="previous scroll-target" data-target="#tour-result">
                                                        <a href="javascript:void(0)" v-if="pagination.current !== 1" @click="(pagination.current === 1) || gotoTourPage(pagination.current - 1)">
                                                            <i class="icon icon-left-arrow"></i>
                                                        </a>
                                                    </li>
                                                    <li class="text-center">
                                                        <p>
                                                            Page {{pagination.current}} of {{pagination.totalPages}}
                                                            <span :class="{'is-visible': pagination.current > 2}" @click="gotoTourPage(1)" v-lang.GO_TO_FIRST_PAGE> Go to first page </span>
                                                        </p>
                                                    </li>
                                                    <li class="next scroll-target" data-target="#tour-result">
                                                        <a href="javascript:void(0)" v-if="pagination.current !== pagination.totalPages" @click="(pagination.current === pagination.totalPages) || gotoTourPage(pagination.current + 1)">
                                                            <i class="icon icon-right-arrow"></i>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </nav>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-4 col-xs-12 col-filter" v-if="!hasErrorMessage">
                                <BookingSummary :packageQuery="packageQuery" isCurrentTourOnly="True" :addons="addOnSelecteds" :seatSelecteds="seatSelecteds" :currentSection="currentSection" :isSearchCompleted="isSearchCompleted" :productType="product.type" v-on:onCalcPromoPrice="calcPromoPrice" v-on:onCallRemoveTour="callRemoveTour" v-on:onOpenTourInfor="callOpenTourInfor" ref="bookingSummary"></BookingSummary>
                                <div class="bk-summary-list" v-if="nextButtonUrl && selectedTours && selectedTours.length > 0">
                                    <div>
                                        <a href="#" v-on:click="checkBookingTour($event,nextButtonUrl)" class="btn btn-success btn-lg btn-block" v-show="tours.length > 0" v-lang.CONTINUE>
                                            Continue
                                        </a>
                                    </div>
                                </div>
                                <div class="modal fade bk-modal" id="showPriceSummary" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                <h4 class="modal-title" id="myModalLabel" v-lang.PRICE_SUMMARY>Price Summary</h4>
                                            </div>
                                            <div class="modal-body">
                                                <PriceSummary ref="priceSummary" :packageQuery="packageQuery" :addons="addOnSelecteds" :seatSelecteds="seatSelecteds" :currentSection="currentSection" @onCalcPromoPriceChanged="onCalcPromoPriceChanged"></PriceSummary>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="bk-footer-price">
                                    <a tabindex="0" data-toggle="modal" data-target="#showPriceSummary">
                                        <strong>
                                            {{packageQuery.currency}} <span>{{packageQuery.priceSummary.totalPrice | formatCurrency }}</span>
                                        </strong>
                                        <small>
                                            <span class="view-full-text" v-lang.FULL_PRICE_SUMMARY>Full price summary</span> <span class="icon icon-hand-pointer view-full-icon"></span>
                                        </small>
                                    </a>
                                </div>
                                <div class="clearfix"></div>
                                <!--Loader filter - start-->
                                <div class="filter" v-if="!loading.hotelFirstLoad">
                                    <div class="filter-body">
                                        <h4 class="filter-title">Filters</h4>
                                        <span class="filter-close icon icon-remove" @click="openFilter()"></span>
                                        <div class="filter-list">
                                            <div class="form-group">
                                                <label class="booking-filters-title" v-lang.PRICE_RANGE>Price Range</label>

                                                <div v-if="!isSearchCompleted">
                                                    <div class="load"></div>
                                                    <div class="load load50"></div>
                                                    <div class="load load50"></div>
                                                </div>

                                                <div v-if="isSearchCompleted">
                                                    <IonRangeSlider v-show="maxPrice > minPrice"
                                                                    :min="minPrice"
                                                                    :max="maxPrice"
                                                                    :prefix="packageQuery.currency + ' '" prettifySeparator=","
                                                                    v-on:changed="setTourPriceRanges">
                                                    </IonRangeSlider>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="filter-list" v-if="!isSearchCompleted">
                                            <label class="booking-filters-title" v-lang.ACTIVITY_TYPE>Activity Type</label>

                                            <div>
                                                <div class="load"></div>
                                                <div class="load load50"></div>
                                                <div class="load load50"></div>
                                                <div class="load load50"></div>
                                                <div class="load load50"></div>
                                                <div class="load load50"></div>
                                                <div class="load load50"></div>
                                                <div class="load load50"></div>
                                                <div class="load load50"></div>
                                            </div>
                                        </div>
                                        <div class="filter-list" v-if="categories.length > 0">
                                            <label class="booking-filters-title" v-lang.ACTIVITY_TYPE>Activity Type</label>

                                            <div v-if="isSearchCompleted" v-for="(category,index) in categories">
                                                <input class="i-check" v-on:click="filterByCategory(category)" type="checkbox" :id="'tourType_'+ index" />
                                                <label for="'tourType_'+index">{{category.value.description}}</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>
<script>
    import Vue from 'vue'
    import BookingSummary from './Booking/BookingSummary.vue'
    import { AjaxSelect, DatePicker, PaxSelector, IonRangeSlider } from 'goquo-components'
    import SelectCurrency from './SelectCurrency.vue'
    import SessionTimeout from './SessionTimeout.vue'
    import PriceSummary from './Booking/PriceSummary.vue'
    import SlickSlider from './SlickSlider.vue';

    export default {
        components: { BookingSummary, AjaxSelect, DatePicker, PaxSelector, SelectCurrency, IonRangeSlider, SessionTimeout, SlickSlider, PriceSummary },
        data() {
            return {
                packageQuery: null,
                product: null,
                tours: [],
                hasErrorMessage: false,
                isSearchCompleted: false,
                categories: [],
                categoriesFilter: [],
                minWidthSize: 500,
                minHeightSize: 375,
                maxPrice: 0,
                minPrice: 0,
                selectedMinPrice: 0,
                selectedMaxPrice: 0,
                isNoDataResult: false,
                pagination: {
                    current: 1,
                    toursPerPage: 10,
                    totalTours: 0,
                    totalPages: 1,
                    currentRowOnPage: 0
                },
                totalPax: 0,
                adults: 0,
                children: 0,
                infants: 0,
                tourFilter: {
                    sortOrderBy: "Priority",
                    sortOrderByAsc: true
                },
                pingCount: 0,
                errorMessage: null,
                nextButtonUrl: null,
                skipButtonUrl: null,
                hotelsName: '',
                selectedTours: [],
                addOnSelecteds: [],
                seatSelecteds: [],
                currentSection: 1,
                tourInfor: {},
                tourIndexInfor: 0,
                loading: {
                    bookingTour: false
                },
                loadingFilter: false,
                isFilterByPriceRageCategory: false,
                promoCode: null,
                promoError: null
            }
        },
        created() {
            var self = this;
            self.loadingFilter = true;
            var packageId = $('#PackageId').val();
            this.nextButtonUrl = $('#NextButtonUrl').val();
            this.skipButtonUrl = $('#SkipButtonUrl').val();

            $.post('/package/work-context/' + packageId, function (data) {
                self.$store.commit('setWorkContext', data);
                data.packageQuery.departureDate = moment.utc(data.packageQuery.departureDate);
                data.packageQuery.returnDate = moment.utc(data.packageQuery.returnDate);
                data.packageQuery.checkIn = moment.utc(data.packageQuery.checkIn);
                data.packageQuery.checkOut = moment.utc(data.packageQuery.checkOut);

                self.packageQuery = data.packageQuery;
                self.promoCode = self.packageQuery.promoCode;
                if (!self.packageQuery.tours) {
                    Vue.set(self.packageQuery, "tours", []);
                }
                self.product = data.product;
                self.createPingRequest();

                for (var i = 0; i < self.packageQuery.paxInfos.length; i++) {
                    self.adults += self.packageQuery.paxInfos[i].adultCount;
                    self.children += self.packageQuery.paxInfos[i].childCount;
                    self.infants += self.packageQuery.paxInfos[i].infantCount;
                }

                self.totalPax = self.adults + self.children + self.infants;
                if (self.packageQuery.hotels && self.packageQuery.hotels.length > 0) {
                    self.hotelsName = self.packageQuery.hotels[0].name;
                }
            });
            self.loadingFilter = false;
        },
        methods: {
            createPingRequest: function () {
                var self = this;
                self.loading.bookingTour = true;
                this.pingCount++;

                if (this.pingCount >= 10) {
                    return;
                }

                var productTypes = [{
                    productType: 4,
                    storedKey: null
                }];

                $.post("/package/product-status/" + self.packageQuery.id, { productTypeStatuses: productTypes }, function (data) {
                    if (data.length > 0) {

                        if (data.some(x => x.status == 3)) {
                            window.location = '/package/restart-search/' + self.packageQuery.id;
                        }

                        var completed = data.every(x => x.status == 1);
                        var haveError = data.some(x => x.status == 2);
                        if (haveError) {
                            //self.checkBookingTour(self.nextButtonUrl);
                            self.notifyErrorMessage(data.find(x => x.status == 2).message);

                        } else {
                            if (completed) {
                                self.checkSearchComplete();
                                self.getResultsPage(1);
                            } else {
                                self.createPingRequest();
                            }
                        }
                    } else {
                        self.createPingRequest();
                    }
                    self.loading.bookingTour = false;
                });
            },
            notifyErrorMessage(errorMessage) {
                console.log("notifyErrorMessage: " + errorMessage);
                this.hasErrorMessage = true;
                this.errorMessage = errorMessage;
            },
            getResultsPage(newPage, hasFilters) {
                var self = this;
                self.loading.bookingTour = true;
                self.pagination.current = newPage;
                var data = {
                    packageId: self.packageQuery.id,
                    pageIndex: newPage,
                    pageSize: this.pagination.toursPerPage,
                    sortOrderBy: this.tourFilter.sortOrderBy,
                    sortOrderByAsc: this.tourFilter.sortOrderByAsc,
                    totalResult: this.pagination.totalTours,
                    categories: []
                };

                if (hasFilters) {
                    data.minPrice = self.selectedMinPrice;
                    data.maxPrice = self.selectedMaxPrice;
                    data.hasFilters = true;

                    var categoryIndex = 0;
                    for (var i = 0; i < self.categoriesFilter.length; i++) {
                        var category = self.categoriesFilter[i];
                        data["categories[" + categoryIndex + "].Description"] = category.value.description;
                        categoryIndex++;
                    }
                    self.pagination.current = newPage;
                }

                if (!this.hasErrorMessage) {
                    $.ajax({
                        url: 'get-tours',
                        data: data,
                        type: 'POST',
                        beforeSend: function () {
                            $('#page-loader').show();
                            self.isFilterByPriceRageCategory = true;
                        },
                        success: function (response) {
                            var data = response;

                            if (data.tours.length == 0 || data.tours == null) {
                                self.isNoDataResult = true;
                            } else {
                                self.isNoDataResult = false;
                                self.removeDuplicateImages(data.tours);
                                self.setThumbnailForTour(data.tours);
                                //self.removeImagesBySize(data.tours);

                                self.tours = data.tours;
                                self.pagination.currentRowOnPage = data.tours.length;
                                self.pagination.totalTours = data.totalTours;

                                self.pagination.totalPages = Math.ceil(data.totalTours / self.pagination.toursPerPage);

                                $(data.tours).each(function (i, tour) {
                                    if (tour.selected) {
                                        var operatorDate = moment(String(tour.operatorDate)).format('YYYY-MM-DD');
                                        tour.operatorDate = operatorDate;

                                        var isPushToSelected = true;
                                        $.each(self.selectedTours, function (indexSelected, item) {
                                            if (tour.id === item.id) {
                                                isPushToSelected = false;
                                                return false;
                                            }
                                        });
                                        if (isPushToSelected) {
                                            self.selectedTours.push(tour);
                                        }

                                        self.changeActivity(tour);
                                        self.changeDailyRate(tour);
                                        self.changeDeparturePoint(tour, i);
                                        tour.gstMarkupPrice = tour.price + tour.gstPrice;
                                    }
                                    else {
                                        tour.operatorDate = "";
                                        //tour.children = 0;
                                        tour.activityCode = tour.activities[0].code;

                                        var activity = null;
                                        for (var i = 0; i < tour.activities.length; i++) {
                                            if (tour.activities[i].code == tour.activityCode) {
                                                activity = tour.activities[i];
                                            }
                                        }

                                        if (activity) {
                                            tour.dailyRates = activity.dailyRates;
                                        }
                                        else {
                                            tour.dailyRates = tour.activities[0].dailyRates;
                                        }

                                        tour.departures = [];

                                        tour.gstMarkupPrice = tour.activities[0].dailyRates && tour.activities[0].dailyRates.length > 0 ? (tour.activities[0].dailyRates[0].price + tour.gstPrice) : (tour.price + tour.gstPrice);
                                    }
                                });

                                $('#page-loader').hide();
                                self.loading.bookingTour = false;
                                self.isSearchCompleted = true;
                            }
                        },
                        complete: function () {
                            $('#page-loader').hide();
                            self.loading.bookingTour = false;
                            self.isFilterByPriceRageCategory = false;
                        }
                    });
                }
            },
            gotoTourPage: function (newPage) {
                $(".hotel-list div[id^='booking-details']").removeClass('in');
                this.getResultsPage(newPage, true);
                $('html,body').animate({ scrollTop: 0 }, 'slow');
            },
            changeActivity: function (tour) {
                var self = this;
                if (!tour.selected) {
                    if (tour.departures != undefined && tour.departures.length > 0) {
                        tour.departurePoint = '';
                    }

                    tour.operatorDate = '';
                    tour.departures = [];
                    tour.departureTime = '';
                    tour.departureTimes = null;
                }

                var activity = null;
                for (var i = 0; i < tour.activities.length; i++) {
                    if (tour.activities[i].code == tour.activityCode) {
                        activity = tour.activities[i];
                    }
                }

                //  tour.departures
                if (activity) {

                    tour.dailyRates = activity.dailyRates;
                }
                else {
                    tour.dailyRates = tour.activities[0].dailyRates;
                }
                //Vue.set(self.tours, index, tour);
            },
            changeDailyRate: function (tour) {
                var self = this;
                var departureTimes = [];
                var dailyRates = tour.dailyRates;
                var operatorDate = tour.operatorDate;

                if (!tour.selected) {
                    if (tour.departures != undefined && tour.departures.length > 0) {
                        tour.departurePoint = '';
                    }
                    tour.departures = [];
                    tour.departureTime = '';
                    tour.departureTimes = null;
                }

                if (dailyRates != null) {
                    for (var i = 0; i < dailyRates.length; i++) {
                        if (operatorDate == moment(String(dailyRates[i].date)).format('YYYY-MM-DD')) {
                            tour.departures = dailyRates[i].departures;
                        }
                    }
                }

                if (tour.departures != undefined && tour.departures.length > 0 && !tour.selected) {
                    tour.departurePoint = '';
                }
                // Vue.set(self.tours, index, tour);
            },
            changeDeparturePoint: function (tour, index) {
                var self = this;
                if (!tour.selected) {
                    tour.departureTime = '';
                }
                var departureTimes = [];
                var dailyRates = tour.dailyRates;
                var operatorDate = tour.operatorDate;
                tour.departureTimes = null;

                if (dailyRates != null) {
                    for (var i = 0; i < dailyRates.length; i++) {
                        if (operatorDate == moment(String(dailyRates[i].date)).format('YYYY-MM-DD')) {
                            var departures = dailyRates[i].departures;
                            for (var j = 0; j < departures.length; j++) {
                                var departure = departures[j];
                                if (departure.code == tour.departurePoint) {
                                    var times = departure.times;
                                    if (times) {
                                        for (var k = 0; k < times.length; k++) {
                                            departureTimes.push(times[k]);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    tour.departureTimes = departureTimes;
                }
                Vue.set(self.tours, index, tour);
            },
            getTourBreakdown: function (tour, index) {
                var self = this;
                tour.loading = true;
                tour.errorMessage = null;
                var adults = tour.adults;
                var children = tour.children;
                var packageId = $('#PackageId').val();

                $.ajax("/package/get-tour-breakdown", {
                    data: {
                        packageId: packageId,
                        tourId: tour.id,
                        adults: adults,
                        children: children,
                        activityCode: tour.activityCode
                    },
                    type: "POST",
                    success: function (response) {
                        var data = response;

                        if (data.success) {
                            tour.gstMarkupPrice = data.price + data.gstPrice;
                            tour.dailyRates[0].price = data.price;
                            tour.price = data.price;
                            tour.adults = data.adults;
                            tour.children = data.children;
                            tour.errorMessage = null;
                            tour.loading = false;
                            Vue.set(self.tours, index, tour);
                        } else {
                            self.translates = {
                                adults: tour.adults,
                                children: tour.children
                            };
                            tour.errorMessage = self.translateText('GET_TOUR_BREAKDOWN_ERROR', 'Get activity breakdown error.');
                            tour.loading = false;
                            Vue.set(self.tours, index, tour);
                        }
                    },
                    error: function () {
                        tour.loading = false;
                        Vue.set(self.tours, index, tour);
                    }
                });
            },
            bookingTour: function (event, tour, indexTours) {
                var self = this;
                event.preventDefault();
                if (self.validate(event)) {
                    var duplicated = false;
                    tour.loading = true;
                    var choseAdults = parseInt(self.calchoseAdults()) + parseInt(tour.adults);
                    Vue.set(self.tours, indexTours, tour);
                    $.each(self.selectedTours, function (index, item) {
                        var departureTime = '';
                        if (item.departureTime === null) {
                            departureTime = ''
                        }
                        else {
                            departureTime = item.departureTime
                        }

                        if (tour.operatorDate === item.operatorDate) {
                            duplicated = true;
                        }
                    });

                    if (duplicated === true) {
                        bootbox.confirm({
                            message: 'Your selected date and time for this tour has overlapped with a previously selected tour. Are you sure you want to continue?',
                            buttons: {
                                confirm: {
                                    label: 'Yes',
                                    className: 'btn-danger'
                                },
                                cancel: {
                                    label: 'No',
                                    className: 'btn-secondary'
                                }
                            },
                            callback: function (result) {
                                if (result) {
                                    self.doBookingTour(tour, indexTours);
                                } else {
                                    tour.loading = false;
                                    Vue.set(self.tours, indexTours, tour);
                                    return;
                                }
                            }
                        });
                    } else {
                        self.doBookingTour(tour, indexTours);
                    }
                }
            },
            calchoseAdults: function () {
                var self = this;
                var choseAdults = 0;
                if (self.selectedTours) {
                    $.each(self.selectedTours, function (index, item) {
                        choseAdults += parseInt(choseAdults) + parseInt(item.adults);
                    });
                }
                return choseAdults;
            },
            doBookingTour: function (tour, indexTours) {
                var self = this;
                tour.loading = true;
                $.ajax('/package/booking-tour', {
                    type: "POST",
                    data: {
                        PackageId: self.packageQuery.id,
                        TourId: tour.id,
                        OperatorDate: tour.operatorDate,
                        DeparturePoint: tour.departurePoint,
                        DepartureTime: tour.departureTime,
                        Adults: tour.adults,
                        Children: tour.children,
                        ActivityCode: tour.activityCode
                    },
                    beforeSend: function () {
                        tour.loading = true;
                    },
                    success: function (data) {
                        if (data.success) {
                            tour.selected = true;
                            tour.errorMessage = null;
                            tour.price = data.price;
                            tour.gstMarkupPrice = data.gstPrice + data.price;
                            if (tour.departurePoint && tour.departurePoint.length > 0) {
                                $.each(tour.departures, function (index, item) {
                                    if (tour.departurePoint === item.code) {
                                        tour.departurePointName = item.name;
                                        return false;
                                    }
                                });
                            }
                            self.selectedTours.push(tour);

                            self.getPriceSummary(self.packageQuery.id);
                            if (typeof (self.$refs) != undefined) {
                                self.$refs.bookingSummary.packageQuery.tours = self.selectedTours;
                                self.$refs.bookingSummary.updatePriceSummary();
                            }
                        }
                        else {
                            tour.loading = false;
                            Vue.set(self.tours, indexTours, tour);
                            if (data.message != null) {
                                bootbox.alert(data.message);
                            }
                            else {
                                bootbox.alert(self.translateText('CANNOT_ADD_THIS_ACTIVITY', 'Cannot add this Activity. Please try again or contact us!'));
                            }
                        }
                    },
                    complete: function () {
                        tour.loading = false;
                    }
                });
                Vue.set(self.tours, indexTours, tour);
            },
            checkBookingTour: function (event, nextUrl) {
                event.preventDefault();
                if (this.packageQuery.hasFlight && this.packageQuery.hasHotel) {
                    window.location.replace(nextUrl);
                }
                else if (this.selectedTours.length > 0) {
                    window.location.href = nextUrl;
                } else {
                    bootbox.dialog({
                        message: 'Please select any tour and then continue.',
                        buttons: {
                            close: {
                                label: "Close",
                                className: "btn-danger",
                                callback: function () {
                                }
                            }
                        }
                    });
                }

                return false;
            },
            getPriceSummary(packageQueryId) {
                var self = this;

                $.ajax({
                    type: "POST",
                    url: "/booking/get-price-summary",
                    data: {
                        packageId: packageQueryId,
                        promoCode: self.packageQuery.promoCode,
                        creditCardNumber: "",
                        applyInsurance: false,
                        addonDetails: []
                    },
                    success: function (data) {
                        self.priceSummary = data;
                        self.packageQuery.priceSummary = data;
                    }
                });
            },
            removeTour: function (tour, indexTours) {
                var self = this;
                Vue.set(self.tours, indexTours, tour);
                $.ajax('/package/remove-tour', {
                    type: "POST",
                    data: {
                        packageId: self.packageQuery.id,
                        tourId: tour.id
                    },
                    beforeSend: function () {
                        tour.loading = true;
                    },
                    success: function (response) {
                        var data = response;

                        if (data.success) {
                            tour.selected = false;

                            var index = self.selectedTours.indexOf(tour);
                            if (index > -1) {
                                self.selectedTours.splice(index, 1);
                            }

                            self.getPriceSummary(self.packageQuery.id);
                            self.$refs.bookingSummary.updatePriceSummary();
                            self.$refs.bookingSummary.packageQuery.tours = self.selectedTours;
                        }
                        else {
                            bootbox.alert(data.message);
                        }
                    },
                    complete: function () {
                        tour.loading = false;
                    }
                });
            },
            getFormTourPerPage: function (currentPage, pageSize) {
                var result = 0;
                var self = this;
                if (currentPage === 1) {
                    result = currentPage;
                }
                else {
                    result = ((currentPage - 1) * pageSize) + 1
                }
                return result;
            },
            getFormTourPerTotal: function (currentPage, pageSize, totalResult) {
                var result = 0;
                if (currentPage === 1) {
                    result = pageSize * currentPage
                }
                else {
                    result = pageSize * (currentPage)
                    if (result > totalResult) {
                        result = totalResult
                    }
                    return result
                }

                return result;
            },
            getFulllTourInfo: function (tour, index) {
                this.tourInfor = tour;
                this.tourIndexInfor = index;
                $("#my-modal").modal({
                    backdrop: 'static',
                    show: true
                }).on('shown.bs.modal', function () {
                    $('#tour-popup-carousel').unbind('slide.bs.carousel').on('slide.bs.carousel', function (e) {
                        var image = $(e.relatedTarget).find('img[data-lazy]');
                        image.attr('src', image.data('lazy'));
                        image.removeAttr('data-lazy');
                    });
                });
                return false;
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            onCalcPromoPriceChanged(promo) {
                let self = this;
                self.promoCode = promo;
                self.calcPromoPrice(function (priceSummry) {
                    if (priceSummry.promoPrice === 0) {
                        self.promoError = true;
                    }
                    else {
                        self.promoError = false;
                    }
                });
            },
            calcPromoPrice(callback) {
                var self = this;
                var cardNumber = $("#txtCreditCardNumber").val();
                var promoCode = $("#showPriceSummary .txtPromoCode").val();

                $.ajax({
                    type: "POST",
                    url: "/booking/get-price-summary",
                    data: {
                        packageId: this.packageQuery.id,
                        creditCardNumber: cardNumber,
                        promoCode: promoCode,
                        applyInsurance: this.isApplyInsurance,
                        addonDetails: null
                    },
                    success: function (data) {
                        self.packageQuery.priceSummary = data;
                        if (callback) {
                            callback(data);
                        }
                    }
                });
            },
            validate(el) {
                var valid = true;
                var tmpElements = el.currentTarget.elements;
                var elements = [];
                for (var i = 0; i < tmpElements.length; i++) {
                    var field = tmpElements[i];
                    if ((field.nodeName === "INPUT" || field.nodeName === "SELECT") && $(field).attr("data-val") === 'true') {
                        if (field.value === "" || field.value === null || field.value === undefined) {
                            $(field).addClass("input-validation-error");
                            elements.push(field);
                        } else {
                            $(field).removeClass("input-validation-error");
                        }
                    }
                }

                if (elements.length > 0) {
                    valid = false;
                    $(elements[0]).focus();
                }
                return valid;
            },
            sorting: function (sortOrderBy) {
                var self = this;
                if (self.tourFilter.sortOrderBy === sortOrderBy) {
                    self.tourFilter.sortOrderByAsc = !self.tourFilter.sortOrderByAsc;
                } else {
                    self.tourFilter.sortOrderBy = sortOrderBy;
                    self.tourFilter.sortOrderByAsc = true;
                }
                self.getResultsPage(1, true);
            },
            setTourPriceRanges: function (minPrice, maxPrice) {
                var self = this;
                self.selectedMinPrice = minPrice;
                self.selectedMaxPrice = maxPrice;
                self.getResultsPage(1, true);
            },
            filterByCategory: function (category) {
                var self = this;
                if (category.selected) {
                    for (var i = 0; i < self.categoriesFilter.length; i++) {
                        if (category.key == self.categoriesFilter[i].key) {
                            self.categoriesFilter.splice(i, 1);
                            category.selected = false
                        }
                    }
                }
                else {
                    category.selected = true;
                    self.categoriesFilter.push(category);
                }
                self.getResultsPage(1, true);
            },
            checkSearchComplete: function (callback) {
                var self = this;
                if (callback) {
                    callback();
                }

                if (!self.hasErrorMessage) {
                    $.ajax("/package/get-tour-filters", {
                        data: {
                            packageId: self.packageQuery.id
                        },
                        type: "POST",
                        success: function (data) {
                            self.minPrice = self.selectedMinPrice = data.minPrice;
                            self.maxPrice = self.selectedMaxPrice = data.maxPrice;

                            for (var property in data.categories) {
                                if (data.categories.hasOwnProperty(property)) {
                                    self.categories.push({
                                        key: property,
                                        value: data.categories[property],
                                        selected: false
                                    });
                                }
                            }
                            self.isSearchCompleted = true;
                        },
                        error: function () {
                            self.isSearchCompleted = true;
                        }
                    });
                } else {
                    self.isSearchCompleted = true;
                }
            },
            changeImage: function (event, urlImage, tourId) {
                event.preventDefault();
                var elId = '#image-' + tourId;
                var el = $(elId);
                if (typeof el !== 'undefined' && el.length > 0) {
                    el.css("background-image", 'url(' + urlImage + ')');
                }
                return false;
            },
            callRemoveTour: function (tour) {
                var self = this;
                $.ajax({
                    type: "POST",
                    url: "/package/remove-tour",
                    data: {
                        packageId: self.packageQuery.id,
                        tourId: tour.id
                    },
                    success: function (data) {
                        if (data.success) {
                            tour.selected = false;
                            var indexRemove = -1;
                            if (self.selectedTours) {
                                $.each(self.selectedTours, function (index, item) {
                                    if (tour.id === item.id) {
                                        indexRemove = index;
                                        return false;
                                    }
                                });
                            }
                            if (indexRemove > -1) {
                                self.selectedTours.splice(indexRemove, 1);
                            }

                            for (var i = 0; i < self.tours.length; i++) {
                                if (tour.id === self.tours[i].id) {
                                    self.tours[i].selected = false;
                                    break;
                                }
                            }


                            self.getPriceSummary(self.packageQuery.id);
                            self.$refs.bookingSummary.updatePriceSummary();
                            self.$refs.bookingSummary.packageQuery.tours = self.selectedTours;

                        }
                        else {
                            bootbox.alert(data.message);
                        }
                    }
                });
            },
            callOpenTourInfor: function (tour) {
                var self = this;
                for (var i = 0; i < self.tours.length; i++) {
                    if (tour.id === self.tours[i].id) {
                        self.tourIndexInfor = i;
                        self.tourInfor = self.tours[i];
                        break;
                    }
                }
                $("#my-modal").modal({
                    backdrop: 'static',
                    show: true
                });
                return false;
            },
            openFilter: function () {
                $(".filter .filter-body").toggleClass('is-open');

                return false;
            },
            getPaxCount: function (tour) {
                return parseInt(tour.adults) + parseInt(tour.children);
            },
            removeDuplicateImages: function (tours) {
                var self = this;
                $(tours).each(function (i, tour) {
                    var tmpArrFileName = [];
                    var tmpArrImages = [];
                    if (tour.images && tour.images.length > 0) {
                        $(tour.images).each(function (k, image) {
                            if (image) {
                                var fileName = self.getFileName(image);
                                if (tmpArrFileName.indexOf(fileName, 0) == -1) {
                                    tmpArrFileName.push(fileName);
                                    tmpArrImages.push(image);
                                }
                            }
                        });
                        tour.images = tmpArrImages;
                    }
                });
            },
            getFileName: function (image) {
                var startIndex = (image.indexOf('\\') >= 0 ? image.lastIndexOf('\\') : image.lastIndexOf('/'));
                var filename = image.substring(startIndex);
                if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
                    filename = filename.substring(1);
                }
                return filename;
            },
            removeImagesBySize(tours) {
                var self = this;
                $(tours).each(function (i, tour) {
                    if (tour.images && tour.images.length > 0) {
                        $(tour.images).each(function (k, image) {
                            if (image) {
                                var img = new Image();
                                img.src = image;
                                self.getImageSize(img, function (width, height) {
                                    if (parseInt(width) < parseInt(self.minWidthSize) || parseInt(height) < parseInt(self.minHeightSize)) {
                                        var indexImage = tour.images.indexOf(image, 0);
                                        if (indexImage > -1) {
                                            tour.images.splice(indexImage, 1);
                                        }
                                    }
                                });
                            }
                        });
                    }
                });
            },
            getImageSize: function (img, callback) {
                var $img = $(img);
                var wait = setInterval(function () {
                    var w = $img[0].naturalWidth,
                        h = $img[0].naturalHeight;
                    if (w && h) {
                        clearInterval(wait);
                        callback.apply(this, [w, h]);
                    }
                }, 30);
            },
            setThumbnailForTour: function (tours) {
                var self = this;
                $(tours).each(function (i, tour) {
                    if (tour.images.length === 0) {
                        if (tour.thumbnail) {
                            tour.images.push(tour.thumbnail);
                        }
                    }
                });
            },
            resetFilter: function () {
                location.reload();
            }

        }
    }

</script>