﻿<template>
    <aside id="filterPanelResult" class="filter">
        <div class="filter-body" :class="{'filter-load': !isSearchCompleted}">
            <span class="filter-active"><span class="filter-close" @click="toggleFilter()">×</span><span v-lang.FILTER_BY>Filter By</span></span>
            <div class="filter-list">
                <div class="form-group">
                    <label v-if="packageQuery.from" v-lang.TOTAL_PACKAGE_PRICE>Total package price</label>
                    <label v-if="!packageQuery.from" v-lang.TOTAL_STAY_PRICE>Total stay price</label>
                    <div v-if="!hotelStore.maxHotelPrice">
                        <div class="load"></div>
                        <div class="load load50"></div>
                        <div class="load load50"></div>
                    </div>
                    <div v-show="hotelStore.maxHotelPrice">
                        <IonRangeSlider :min="hotelStore.minPrice"
                                        :max="hotelStore.maxPrice"
                                        :prefix="packageQuery.currency + ' '" prettifySeparator=","
                                        v-on:changed="setMinMaxPrice"
                                        :flightChangePrice="flightChangePrice">
                        </IonRangeSlider>
                    </div>
                </div>
            </div>
            <div class="filter-list">
                <div class="form-group">
                    <label>
                        <span v-lang.HOTEL_NAME>Hotel Name</span>
                        <small v-if="hotelsOptions.hotelName" @click="clearHotelName()" class="clear-filter pull-right" id="hotelName">x <span v-lang.CLEAR_HOTEL>Clear Hotel</span></small>
                    </label>
                    <AjaxSelect ref="hotelNameFilter" :url="'/api/find-hotels/' + packageQuery.id" v-on:changed="onHotelNameChanged" :placeholder="selectHotelText"></AjaxSelect>
                </div>
            </div>
            <div class="filter-list">
                <div class="form-group">
                    <label v-lang.STAR_RATING>Star Rating</label>
                    <span class="filter-star" v-for="star in hotelStore.stars">
                        <button class="btn btn-default" @click="toggleStarSelection(star)" :id="star + 'star'">
                            {{star}}
                            <span data-alt="1" class="icon icon-star" :class="{'selected': isSelectedStar(star)}"></span>
                        </button>
                    </span>
                </div>
            </div>
            <div class="filter-list" v-if="hotelsOptions.regionId">
                <div class="form-group">
                    <label v-lang.DISTANCE_RANGE>Distance Range</label>
                    <IonRangeSlider min="0" max="5" :to="hotelsOptions.maxDistance" :from="hotelsOptions.minDistance" postfix=" km" prettifySeparator="," v-on:changed="setRegionDistance"></IonRangeSlider>
                </div>
            </div>
            <div class="filter-list" v-if="hotelStore.importantLocations.length > 1">
                <div class="form-group">
                    <label>
                        <span v-lang.LOCATIONS>Locations</span>
                        <small class="clear-filter pull-right" v-if="hotelsOptions.regionId" onclick="$('input[name=selectedLocation]').attr('checked',false)" @click="setRegionId(null)" id="hotelDistance">x <span v-lang.CLEAR_FILTER>Clear Filter</span></small>
                    </label>
                    <div class="panel-group location-filter" id="locationPanel">
                        <!-- Temp hide POI filter-->
                        <div class="panel panel-default" v-for="(importantLocation, index) in hotelStore.importantLocations">
                            <h4 class="panel-title">
                                <a role="button" data-toggle="collapse" data-parent="#locationPanel"
                                   :href="'#filter_importantLocations_' + index" aria-expanded="true" aria-controls="collapseOne" class="collapsed accordion-toggle">
                                    {{importantLocation.key}}
                                </a>
                            </h4>

                            <div :id="'filter_importantLocations_' + index" class="panel-collapse collapse filter-collapse" role="tabpanel" aria-labelledby="headingOne">
                                <div v-for="location in importantLocation.regions">
                                    <div class="location radio radio-primary">
                                        <input type="radio" name="selectedLocation" :id="'radio' + location.regionId" @click="setRegionId(location)" :value="location.regionId">
                                        <label :for="'radio' + location.regionId">
                                            <span>{{location.regionName}}</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="filter-list" v-if="hotelStore.facilities.length > 0">
                <div class="form-group">
                    <label v-lang.FACILITIES>Facilities</label>
                    <div v-for="facility in hotelStore.facilities" class="checkbox checkbox-primary">
                        <input type="checkbox" class="i-check" :id="'facility-' + facility.key" @click="toggleFacilitySelection(facility.key)" :checked="isSelectedFacility(facility.key)" />
                        <label :for="'facility-' + facility.key" class="facility">
                            <span :class="'icon icon-' + facility.key"></span>
                            <span>{{facility.value}}</span>
                        </label>
                    </div>
                </div>
            </div>
        </div>
    </aside>
</template>
<script>
    import {AjaxSelect, IonRangeSlider} from 'goquo-components'
    
    export default {
        components: { AjaxSelect, IonRangeSlider},
        props: ["packageQuery", "hotelStore", "flightStore", "hotelsOptions", "isSearchCompleted", "flightChangePrice"],
        data() {
            return {
            }
        },
        computed: {
            selectHotelText() {
                return this.translate(this.$language, 'SELECT_HOTEL') || 'Select Hotel';
            }
        },
        methods: {
            isSelectedStar(star) {
                var index = this.hotelsOptions.stars.indexOf(star);
                if (index === -1)
                    return false;
                return true;
            },
            isSelectedFacility(facility) {
                var index = this.hotelsOptions.facilities.indexOf(facility);
                if (index === -1)
                    return false;
                return true;
            },
            toggleFacilitySelection(facility) {
                var idx = this.hotelsOptions.facilities.indexOf(facility);
                if (idx > -1) {
                    this.hotelsOptions.facilities.splice(idx, 1);
                } else {
                    this.hotelsOptions.facilities.push(facility);
                }
                this.$emit('changed');
            },
            setRegionId(region) {
                if (region) {
                    this.hotelsOptions.regionId = region.regionId;
                    this.hotelsOptions.latitude = region.centerLatitude;
                    this.hotelsOptions.longitude = region.centerLongitude;
                    this.hotelsOptions.regionName = region.regionName;
                } else {
                    this.hotelsOptions.regionId = null;
                    this.hotelsOptions.latitude = null;
                    this.hotelsOptions.longitude = null;
                    this.hotelsOptions.regionName = null;
                }
                this.$emit('changed');
            },
            toggleStarSelection(star) {
                this.internalToggleStarSelection(star);
                if (star === "1") {
                    this.internalToggleStarSelection("0");
                }

                this.$emit('changed');
            },
            toggleFilter() {
                $("#filterPanelResult .filter-body").toggleClass('is-open');
            },
            internalToggleStarSelection(star) {
                var idx = this.hotelsOptions.stars.indexOf(star);
                if (idx > -1) {
                    this.hotelsOptions.stars.splice(idx, 1);
                    idx = this.hotelsOptions.stars.indexOf((parseFloat(star) + 0.5) + "");
                    if (idx > -1) {
                        this.hotelsOptions.stars.splice(idx, 1);
                    }
                } else {
                    this.hotelsOptions.stars.push(star);
                    this.hotelsOptions.stars.push((parseFloat(star) + 0.5) + "");
                }
            },
            onHotelNameChanged(data) {
                this.hotelsOptions.hotelName = data.id;
                this.$emit('changed');
            },
            clearHotelName() {
                this.hotelsOptions.hotelName = null;
                this.$refs.hotelNameFilter.clearSelection();
                this.$emit('changed');
            },
            setMinMaxPrice(min, max) {
                if (this.hotelsOptions.hotelName == undefined) {
                    var minPrice = min;
                    var maxPrice = max;

                    //Remove flight price from values
                    if (this.flightStore.outboundFlight != null) {
                        minPrice -= this.flightStore.outboundFlight.price;
                        maxPrice -= this.flightStore.outboundFlight.price;

                        if (this.flightStore.inboundFlight != null) {
                            minPrice -= this.flightStore.inboundFlight.price;
                            maxPrice -= this.flightStore.inboundFlight.price;
                        }
                    }

                    this.hotelsOptions.minPrice = Math.floor(minPrice);
                    this.hotelsOptions.maxPrice = Math.ceil(maxPrice);
                    this.$emit('changed');
                }
            },
            setRegionDistance(min, max) {
                this.hotelsOptions.minDistance = min;
                this.hotelsOptions.maxDistance = max;
                this.hotelsOptions.radius = max;
                this.$emit('changed');
            }
        }
    }

</script>