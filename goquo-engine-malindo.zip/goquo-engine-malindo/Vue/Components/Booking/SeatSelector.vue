﻿<template>
    <div class="modal fade ss-section" :id="'seatselect-' + index" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <div class="modal-body clearfix">
                    <div>
                        <div class="col-xs-12 col-sm-6 col-sm-push-6">
                            <div class="cus-panel cus-panel-default cus-panel-normal">
                                <div class="cus-panel-heading">
                                    <div class="cus-panel-title">
                                        <span class="icon icon-flight"></span> {{leg.departureCityName}} ({{leg.from}}) - {{leg.arrivalCityName}} ({{leg.to}})
                                    </div>
                                    <p><span v-lang.DEPART_TIME_SHORT>Dep.</span> {{leg.departureDate | moment('DD MMM YYYY HH:mm a')}} | <span v-lang.ARRIVE_TIME_SHORT>Arr.</span> {{leg.arrivalDate | moment('DD MMM YYYY HH:mm a')}}</p>
                                </div>
                                <div class="cus-panel-body">
                                    <div class="cus-panel-body-split">
                                        <div class="ss-paxdetails" v-for="(passenger, paxIndex) in passengers" @click="setCurrentPax(paxIndex)" v-bind:class="{'active':isCurrentPax (passenger.firstName + passenger.lastName,selectedPas,paxIndex)}" v-show="passenger.passengerType !== 'Infant'">
                                            <label class="lb-nowrap">
                                                <span>{{passenger.title}}</span>.&nbsp;
                                                <span class="text-uppercase">{{passenger.firstName}}</span>&nbsp;
                                                <span class="text-uppercase">{{passenger.lastName}}</span>
                                            </label>
                                            <div class="ss-selectedseat">
                                                <strong class="label" v-if="getSeat(passenger)"
                                                        v-bind:class="{'label-standard': getSeat(passenger).group === leg.standardGroupCode || isBusinessClass(getSeat(passenger).cabinClass),
                                                                'label-sweet': getSeat(passenger).group === leg.coolseatGroupCode }">
                                                    {{getSeat(passenger) ? getSeat(passenger).designator : ""}}
                                                </strong>
                                                <div v-if="!getSeat(passenger)"><a :href="'#seatPanel{0}-{1}'|stringFormat(leg.from, leg.to)" class="ss-selectedseat-hightlight"><i class="icon icon-seat"></i> <span v-lang.SELECT>Select</span></a></div>
                                                <span v-if="getSeat(passenger)" @click="removeSeat(getSeat(passenger), paxIndex)" class="ss-remove"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="cus-panel cus-panel-default cus-panel-normal">
                                <div class="cus-panel-body cus-panel-legends">
                                    <ul class="ss-legends">
                                        <li class="split-legs">
                                            <span><i class="seat seat-standard active"></i></span>
                                            <p v-lang.SELECTED>Selected</p>
                                            <span><i class="seat seat-unavailable"></i></span>
                                            <p v-lang.UNAVAILABLE_SEAT>Unavailable Seat</p>
                                        </li>
                                        <li v-if="isBusinessClass(leg.seatRows[0].seats[0].cabinClass)">
                                            <span><i class="seat seat-standard"></i></span>
                                            <p><span v-lang.AVAILABLE_BUSINESS_SEAT>Available Business Seat</span> {{packageQuery.currency}} 0</p>
                                        </li>
                                        <li v-if="!isBusinessClass(leg.seatRows[0].seats[0].cabinClass)" v-for="seatGroup in leg.seatGroupFees">
                                            <span><i v-bind:class="{'seat seat-sweet': seatGroup.name.indexOf('COOL') != -1, 'seat seat-standard':seatGroup.name.indexOf('COOL') == -1}"></i></span>
                                            <p v-if="seatGroup.name.indexOf('COOL') != -1">
                                                <span v-lang.AVAILABLE_COOL_SEAT>Available Cool Seat</span>
                                                <em class="seatprice">{{packageQuery.currency}} {{seatGroup.totalPrice}}</em>
                                            </p>
                                            <p v-if="seatGroup.name.indexOf('COOL') == -1">
                                                <span v-lang.AVAILABLE_STANDARD_SEAT>Available Standard Seat</span>
                                                <em class="seatprice">{{packageQuery.currency}} {{seatGroup.totalPrice}}</em>
                                            </p>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <button type="button" class="btn btn-lg btn-block btn-primary hidden-xs" v-if="!isBusinessClass(leg.seatRows[0].seats[0].cabinClass)" data-dismiss="modal" v-lang.UPDATE_SEATS>Update Seats</button>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-sm-pull-6">
                            <div class="seat-panel" :id="'seatPanel{0}-{1}'|stringFormat(leg.from, leg.to)">
                                <div class="seat-row-all" v-if="isBusinessClass(leg.seatRows[0].seats[0].cabinClass)">
                                    <span class="seat-exitleft" v-lang.EXIT>Exit</span>
                                    <p class="ss-seattype" v-lang.BUSINESS_CLASS>Business Class</p>
                                    <div v-bind:class="{'businessClass':leg.columns.length <= 5, 'economyClass':leg.columns.length > 5}">
                                        <ul class="seat-row mb10">
                                            <li class="seat-text" v-for="column in leg.columns">{{column}}</li>
                                        </ul>
                                        <ul class="seat-row" v-bind:class="{'row-exit':row.seats[0].isExitRow}" v-for="row in leg.seatRows">
                                            <li v-for="seat in row.seats"
                                                v-bind:class="{
                                                            'seat-unavailable': (!isAvailable(seat) && seat.isSeat),
                                                            'seat-text': seat.isSeat === false,
                                                            'seat-standard': seat.isSeat === true,
                                                            'active': isSelected(seat),
                                                            'your-seat': isSelected(seat),
                                                        }"
                                                @click="toggleSeatSelect(seat)"
                                                class="seat"
                                                data-toggle="tooltip"
                                                data-placement="top"
                                                :title="seatPaxName(seat)"
                                                v-tooltip>
                                                <span v-if="seat.isSeat === false">{{seat.designator}}</span>
                                            </li>
                                        </ul>
                                    </div>
                                    <h4 class="seat-route" v-lang.REAR>REAR</h4>
                                </div>
                                <div class="seat-row-all" v-if="!isBusinessClass(leg.seatRows[0].seats[0].cabinClass)">
                                    <div class="wings left"></div>
                                    <div class="wings right"></div> <span class="seat-exitleft">Exit</span>
                                    <p class="ss-seattype" v-lang.ECONOMY_CLASS>Economy Class</p>
                                    <div class="economyClass">
                                        <ul class="seat-row mb10">
                                            <li class="seat-text" style="margin: 0 6px;" v-for="column in leg.columns">{{column}}</li>
                                        </ul>
                                        <ul class="seat-row" v-bind:class="{'row-exit':row.seats[0].isExitRow}" v-for="row in leg.seatRows">
                                            <li v-for="seat in row.seats"
                                                v-bind:class="{
                                                            'seat-unavailable': (!isAvailable(seat) && seat.isSeat),
                                                            'seat-standard': seat.group === leg.standardGroupCode && seat.isSeat === true,
                                                            'seat-sweet': seat.group === leg.coolseatGroupCode && seat.isSeat === true,
                                                            'seat-upfront': seat.group === 2,
                                                            'seat-text': seat.isSeat === false,
                                                            'active': isSelected(seat),
                                                            'your-seat': isSelected(seat),
                                                        }"
                                                @click="toggleSeatSelect(seat)"
                                                class="seat"
                                                data-toggle="tooltip"
                                                data-placement="top"
                                                :title="seatPaxName(seat)"
                                                v-tooltip>
                                                <span v-if="seat.isSeat === false">{{seat.designator}}</span>
                                            </li>
                                        </ul>
                                    </div>
                                    <span class="seat-exitleft" v-lang.EXIT>Exit</span>
                                    <h4 class="seat-route" v-lang.REAR>REAR</h4>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12" v-if="isTranslationAvailable('SEAT_NOTE_EXTRA')">
                            <div class="cus-alert cus-alert-info">
                                <p class="mb0" v-lang.SEAT_NOTE_EXTRA></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-lg btn-block btn-primary" data-dismiss="modal" v-lang.UPDATE_SEATS>Update Seats</button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: ["packageQuery", "leg", "index", "passengers", "seatSelecteds", "selectedPassenger", "firstSelectedPass"],
        data() {
            return {
                currentPax: 0,
                selectedPas: "",
                pasSetSeat: true
            }
        },
        watch: {
            selectedPassenger: function () {
                this.selectedPas = this.selectedPassenger;
                this.pasSetSeat = this.firstSelectedPass;
            }
        },
        mounted() {
            var standardGroup = this.leg.seatGroupFees.find(function (groupFee) { return groupFee.name.indexOf('COOL') === -1 });
            if (standardGroup) {
                this.leg.standardGroupCode = standardGroup.group;
            }

            var coolSeatGroup = this.leg.seatGroupFees.find(function (groupFee) { return groupFee.name.indexOf('COOL') !== -1 });
            if (coolSeatGroup) {
                this.leg.coolseatGroupCode = coolSeatGroup.group;
            } else {
                this.leg.coolseatGroupCode = '';
            }
        },
        methods: {
            isBusinessClass(cabinClass) {
                return (cabinClass === 2 || cabinClass === 3 || cabinClass === 6);
            },
            isCurrentPax(currentPas, selectedPas, paxIndex) {
                if (currentPas == selectedPas) {
                    if (this.pasSetSeat == true) {
                        this.pasSetSeat = false;
                    }
                    this.currentPax = paxIndex;
                    return true;
                }
                else {
                    return false;
                }
            },
            getSeat(passenger) {
                if (passenger.seats) {
                    return passenger.seats[this.leg.legKey];
                }

                return null;
            },
            isAvailable(seat) {
                if (!seat.isSeat)
                    return null;

                var available = seat.availability === "Open";

                var pax = this.getCurrentPax();
                if (!pax) {
                    return available;
                }

                if (available) {
                    if (pax.passengerType === "Child")
                        return this.isAvailableForChild(seat);
                }

                return available;
            },
            isAvailableForChild(seat) {
                if (this.leg.airCraft && this.leg.airCraft === "321") {
                    if (seat.row === 1) {
                        return false;
                    }
                    if ((seat.row === 11) && (seat.column === "B" || seat.column === "C" || seat.column === "D" || seat.column === "E")) {
                        return false;
                    }
                    if ((seat.row === 12) && (seat.column === "A" || seat.column === "F")) {
                        return false;
                    }
                    if (seat.row === 26) {
                        return false;
                    }
                } else {
                    if (seat.row === 12 || seat.row === 13) {
                        return false;
                    }
                }
                return true;
            },
            getCurrentPax() {
                if (this.currentPax < 0) return null;
                return this.passengers[this.currentPax];
            },
            isSelected(seat) {
                if (!seat) return false;
                var p = this.getSeatPax(seat);
                return p != null;
            },
            getSeatPax(seat) {
                var self = this;
                var p = this.passengers.find(function (p) {
                    var paxSeat = self.getSeat(p);
                    if (!paxSeat) {
                        return false;
                    }
                    return paxSeat.designator === seat.designator;

                });

                return p;
            },
            seatPaxName(seat) {
                var p = this.getSeatPax(seat);
                var name = "";
                if (p) {
                    name = p.title + ".";

                    if (p.firstName) {
                        name += p.firstName + " ";
                    }
                    if (p.LastName) {
                        name += p.lastName;
                    }
                }
                return name;
            },
            setCurrentPax(paxIndex) {
                if (this.passengers[paxIndex].passengerType === "Infant") {
                    paxIndex++;
                }
                this.currentPax = paxIndex;
                this.selectedPas = this.passengers[paxIndex].firstName + this.passengers[paxIndex].lastName
            },
            toggleSeatSelect(seat) {
                if (!seat.isSeat) return;
                var pax = this.getCurrentPax();
                if (!pax) return;

                if (this.getSeat(pax) === seat) {
                    this.removeSeat(seat, this.currentPax);
                } else {
                    this.selectSeat(seat);
                }
            },
            selectSeat(seat) {
                if (!this.isAvailable(seat)) return;
                if (this.isSelected(seat)) return;

                var pax = this.getCurrentPax();
                this.currentSeat = seat;

                this.addSeat(seat);
            },
            addSeat(seat) {
                if (this.currentPax < 0) return;

                var selectedSeat = jQuery.extend(true, {}, seat);
                selectedSeat.paxNo = this.currentPax;

                if (this.seatSelecteds.length > 0) {
                    var addedSeat = this.seatSelecteds.find(function (x) {
                        return x.paxNo == selectedSeat.paxNo && x.from == selectedSeat.from && x.to == selectedSeat.to;
                    });

                    if (addedSeat != null) {
                        var index = this.seatSelecteds.indexOf(addedSeat);
                        this.seatSelecteds.splice(index, 1);
                    }
                }

                this.seatSelecteds.push(selectedSeat);

                var self = this;
                this.calculateSeatPrice(function (response) {
                    var pax = self.getCurrentPax();
                    self.onSeatSelected(seat, pax, response);
                });
            },
            removeSeat(seat, paxNo) {
                seat.paxNo = paxNo;

                var addedSeat = this.seatSelecteds.find(function (x) {
                    return x.paxNo === seat.paxNo && x.from === seat.from && x.to === seat.to;
                });

                if (addedSeat != null) {
                    var index = this.seatSelecteds.indexOf(addedSeat);
                    this.seatSelecteds.splice(index, 1);
                }

                var self = this;
                this.calculateSeatPrice(function (response) {
                    var pax = self.getCurrentPax();
                    self.onSeatRemoved(seat, pax, response);
                });
            },
            calculateSeatPrice(callback) {
                this.$emit("onAddonsChanged", callback);
            },
            onSeatSelected(seat, passenger, response) {
                this.currentSeat = null;
                this.setSeat(passenger, seat);
                this.selectNextPax();
                this.$emit("onSeatChanged");
            },
            onSeatRemoved(seat, passenger, response) {
                this.currentSeat = null;
                this.setSeat(passenger, null);
                this.updatePriorityCheckin();
                this.$emit("onSeatChanged");
            },
            setSeat(passenger, seat) {
                if (!passenger.seats) {
                    this.$set(passenger, 'seats', {})
                }

                var seats = jQuery.extend(true, {}, passenger.seats);
                seats[this.leg.legKey] = seat;
                this.$set(passenger, 'seats', seats)

                this.$forceUpdate();
            },
            selectNextPax() {
                var paxCount = this.passengers.length;

                for (var i = 0; i < paxCount; i++) {
                    var passenger = this.passengers[i];
                    if (passenger.passengerType === "Infant")
                        continue;
                    if (this.getSeat(this.passengers[i]))
                        continue;
                    this.setCurrentPax(i);
                    break;
                }
            },
            updatePriorityCheckin() {

            },
            // Checks if a translation is available
            isTranslationAvailable(translation_key) {
                // TRUE if has translation, else FALSE
                return (this.translate(this.$language, translation_key)) ? true : false;
            }
        }
    }
</script>