﻿<template>
    <div class="bk-summary-section">
        <div class="bk-title">
            <a href="#bkSummaryPannel" class="bk-title-head chevron-toggle collapsed" data-toggle="collapse" v-lang.BOOKING_SUMMARY>Booking Summary</a>
        </div>
        <div id="bkSummaryPannel" class="collapse in">
            <div class="bk-summary-panel" v-if="packageQuery.outboundFlight || packageQuery.inboundFlight || (packageQuery.hotels && packageQuery.hotels.length > 0) || (packageQuery.tours && packageQuery.tours.length > 0) || (packageQuery.arrivalTransfer && packageQuery.arrivalTransfer.vehicles) || (packageQuery.departureTransfer && packageQuery.departureTransfer.vehicles)">
                <div class="bk-summary-bodyTop clearfix">
                    <h4 v-if="packageQuery.outboundFlight || packageQuery.inboundFlight"><span v-lang.FLIGHT_SUMMARY>Flight Summary</span></h4>
                    <div class="bk-summary-list" v-if="packageQuery.outboundFlight">
                        <h4><span class="icon icon-flight"></span> <span v-lang.DEPARTURE_FLIGHT>Departure Flight</span></h4>
                        <div class="bk-summary-flight" v-for="leg in packageQuery.outboundFlight.legs">
                            <div class="bk-summary-flightleft">
                                <span class="bk-summary-flightcode">{{leg.departureAirportCode}}</span>
                                <span class="bk-summary-flighttime">{{leg.departureDate|moment('HH:mm')}}</span>
                            </div>
                            <div class="bk-summary-flightcenter">
                                <span class="bk-summary-flightdate">{{leg.departureDate|moment('ddd, DD MMM YYYY')}}</span>
                                <div class="bk-summary-flightline">
                                    <div class="bk-dot"></div>
                                    <div class="bk-line"></div>
                                    <div class="bk-dot"></div>
                                </div>
                                <span class="bk-summary-flightinfo">{{leg.airlineCode}} {{leg.flightNumber}}, {{leg.airlineName}}</span>
                                <span class="bk-summary-flightcabin">{{leg.cabinClass}}</span>
                            </div>
                            <div class="bk-summary-flightright">
                                <span class="bk-summary-flightcode">{{leg.arrivalAirportCode}}</span>
                                <span class="bk-summary-flighttime">
                                    {{leg.arrivalDate|moment('HH:mm')}}
                                    <b class="ml15" v-if="leg.diffDates > 0">+{{leg.diffDates}}</b>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="bk-summary-list" v-if="packageQuery.inboundFlight">
                        <h4><span class="icon icon-flight-return"></span> <span v-lang.RETURN_FLIGHT>Return Flight</span></h4>
                        <div class="bk-summary-flight" v-for="leg in packageQuery.inboundFlight.legs">
                            <div class="bk-summary-flightleft">
                                <span class="bk-summary-flightcode">{{leg.departureAirportCode}}</span>
                                <span class="bk-summary-flighttime">{{leg.departureDate|moment('HH:mm')}}</span>
                            </div>
                            <div class="bk-summary-flightcenter">
                                <span class="bk-summary-flightdate">{{leg.departureDate|moment('ddd, DD MMM YYYY')}}</span>
                                <div class="bk-summary-flightline">
                                    <div class="bk-dot"></div>
                                    <div class="bk-line"></div>
                                    <div class="bk-dot"></div>
                                </div>
                                <span class="bk-summary-flightinfo">{{leg.airlineCode}} {{leg.flightNumber}}, {{leg.airlineName}}</span>
                                <span class="bk-summary-flightcabin">{{leg.cabinClass}}</span>
                            </div>
                            <div class="bk-summary-flightright">
                                <span class="bk-summary-flightcode">{{leg.arrivalAirportCode}}</span>
                                <span class="bk-summary-flighttime">
                                    {{leg.arrivalDate|moment('HH:mm')}}
                                    <b class="ml15" v-if="leg.diffDates > 0">+{{leg.diffDates}}</b>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="bk-summary-list" v-if="packageQuery.hotels && packageQuery.hotels.length > 0">
                        <div v-for="hotel in packageQuery.hotels">
                            <h4><span class="icon icon-hotel"></span> <span v-lang.HOTEL_SUMMARY>Hotel Summary</span></h4>
                            <div class="bk-hotelinfo">
                                <h5 class="bk-hotelname" :data-id="hotel.hotelId" id="sidesell-hotelname">{{hotel.name}}</h5>
                                <StarRating v-model="hotel.stars"></StarRating>
                                <p class="bk-hoteldate">
                                    <span>
                                        {{getHotelDate(packageQuery.departureDate, packageQuery.checkIn)|moment('ddd, DD MMM YYYY')}} - {{getHotelDate(packageQuery.returnDate, packageQuery.checkOut)|moment('ddd, DD MMM YYYY')}}
                                    </span>
                                </p>
                                <p class="bk-hotelrooms" v-for="(availableRoom, i) in hotel.availableRooms"><strong><span v-lang.ROOM>Room</span>:</strong> {{availableRoom.description}} <span class="bk-hotelavailableRoom">{{availableRoom.availableRoomTypes[0].boardCodeDescription}}</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="bk-summary-list tour-summary" v-if="packageQuery.tours && packageQuery.tours.length > 0 ">
                        <div>
                            <a href="#tourCollapse" class="toggle-menu" data-toggle="collapse"><h4 v-lang.ACTIVITY_SUMMARY>Activity Summary</h4> <span class="icon icon-down-chevron"></span></a>
                            <div id="tourCollapse" class="panel-collapse">
                                <div class="bk-hotelinfo" v-for="tour in packageQuery.tours">
                                    <h5 class="bk-hotelname bk-hotelname-tour" @click="showTourInfor(tour)">{{tour.name}}</h5>
                                    <p>
                                        <strong>Date:</strong>{{tour.operatorDate | moment('ddd, DD MMM YYYY')}}
                                    </p>
                                    <p v-if="tour.activityCode">
                                        <strong><span v-lang.OPTIONS>Options</span>:</strong>{{getTourActivies(tour)}}
                                    </p>
                                    <p v-if="tour.duration">
                                        <strong>Duration:</strong>{{tour.duration}}
                                    </p>
                                    <p v-if="tour.departurePointName">
                                        <strong>Departure:</strong>{{tour.departurePointName}}
                                    </p>
                                    <p v-if="tour.adults || tour.children">
                                        <span v-if="tour.adults">
                                            <strong><span v-lang.ADULTS>Adults</span>:</strong>{{tour.adults}}
                                        </span>
                                        &nbsp;&nbsp;
                                        <span v-if="tour.children">
                                            <strong><span v-lang.CHILDREN>Children</span>:</strong>{{tour.children}}
                                        </span>
                                    </p>
                                    <p class="text-right remove-tour" v-if="isCurrentTourOnly === 'True'">
                                        <a href="#" class="btn-remove" @click="removeTour(tour)">
                                            <span class="icon icon-remove"></span>
                                        </a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="bk-summary-list" v-if="(packageQuery.arrivalTransfer && packageQuery.arrivalTransfer.vehicles) || (packageQuery.departureTransfer && packageQuery.departureTransfer.vehicles)">
                        <div>
                            <h4><span class="icon icon-car"></span> <span v-lang.TRANSFER_SUMMARY>Transfer Summary</span></h4>
                            <div class="bk-transferinfo" v-if="packageQuery.arrivalTransfer && packageQuery.arrivalTransfer.vehicles && packageQuery.arrivalTransfer.vehicles.length > 0">
                                <span class="transfer-type" v-lang.ARRIVAL_TRANSFER>Arrival transfer</span>
                                <div class="clearfix"></div>
                                <h5 v-if="packageQuery.arrivalTransfer.vehicles[0].vehicleName"><span><span v-lang.VEHICLE>Vehicle</span>:</span> {{packageQuery.arrivalTransfer.vehicles[0].vehicleName}}</h5>
                                <p>
                                    <strong v-if="packageQuery.arrivalTransfer.vehicles[0].pickUpDate"><span v-lang.DATE>Date</span>:</strong> {{packageQuery.arrivalTransfer.vehicles[0].pickUpDate | moment('ddd DD MMM YYYY')}} {{packageQuery.arrivalTransfer.vehicles[0].pickUpTime}}
                                </p>
                                <p v-if="packageQuery.arrivalTransfer.approximateTransferTime"><strong><span v-lang.DURATION>Duration</span>:</strong> {{packageQuery.arrivalTransfer.approximateTransferTime}}</p>

                                <p v-if="packageQuery.arrivalTransfer.vehicles[0].airportName">
                                    <strong><span v-lang.PICKUP>Pickup</span>:</strong> {{packageQuery.arrivalTransfer.vehicles[0].airportName}}
                                </p>

                                <p v-if="packageQuery.arrivalTransfer.vehicles[0].hotelName">
                                    <strong><span v-lang.DROP_OFF>Drop Off</span>:</strong> {{packageQuery.arrivalTransfer.vehicles[0].hotelName}}
                                </p>
                                <p v-if="packageQuery.arrivalTransfer.vehicles[0].flightNo">
                                    <strong><span v-lang.FLIGHT_NUMBER>Flight Number</span>:</strong> {{packageQuery.arrivalTransfer.vehicles[0].flightNo}}
                                </p>
                                <p v-if="packageQuery.arrivalTransfer.vehicles[0].flightTime">
                                    <strong><span v-lang.FLIGHT_TIME>Flight Time</span>:</strong> {{packageQuery.arrivalTransfer.vehicles[0].flightTime}}
                                </p>
                            </div>
                            <div class="bk-transferinfo" v-if="packageQuery.departureTransfer && packageQuery.departureTransfer.vehicles && packageQuery.departureTransfer.vehicles.length > 0">
                                <span class="transfer-type" v-lang.DEPARTURE_TRANSFER>Departure transfer</span>
                                <div class="clearfix"></div>
                                <h5 v-if="packageQuery.departureTransfer.vehicles[0].vehicleName"><span><span v-lang.VEHICLE>Vehicle</span>:</span> {{packageQuery.departureTransfer.vehicles[0].vehicleName}}</h5>
                                <p>
                                    <strong v-if="packageQuery.departureTransfer.vehicles[0].pickUpDate"><span v-lang.DATE>Date</span>:</strong> {{packageQuery.departureTransfer.vehicles[0].pickUpDate | moment('ddd DD MMM YYYY')}} {{packageQuery.departureTransfer.vehicles[0].pickUpTime}}
                                </p>
                                <p v-if="packageQuery.departureTransfer.approximateTransferTime"><strong><span v-lang.DURATION>Duration</span>:</strong> {{packageQuery.departureTransfer.approximateTransferTime}}</p>

                                <p v-if="packageQuery.departureTransfer.allowForCheckInTime"><strong><span v-lang.CHECK_IN_TIME>Check-In Time</span>:</strong> {{packageQuery.departureTransfer.allowForCheckInTime}}</p>

                                <p v-if="packageQuery.departureTransfer.vehicles[0].hotelName">
                                    <strong><span v-lang.PICKUP>Pickup</span>:</strong> {{packageQuery.departureTransfer.vehicles[0].hotelName}}
                                </p>

                                <p v-if="packageQuery.departureTransfer.vehicles[0].airportName">
                                    <strong><span v-lang.DROP_OFF>Drop Off</span>:</strong> {{packageQuery.departureTransfer.vehicles[0].airportName}}
                                </p>
                                <p v-if="packageQuery.departureTransfer.vehicles[0].flightNo">
                                    <strong><span v-lang.FLIGHT_NUMBER>Flight Number</span>:</strong> {{packageQuery.departureTransfer.vehicles[0].flightNo}}
                                </p>
                                <p v-if="packageQuery.departureTransfer.vehicles[0].flightTime">
                                    <strong><span v-lang.FLIGHT_TIME>Flight Time</span>:</strong> {{packageQuery.departureTransfer.vehicles[0].flightTime}}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <div class="bk-summary-panel bk-hide-mobile" v-bind:class="{'isPayment': currentSection === 3, 'isPax': currentSection === 1}">
                <div class="bk-summary-list">
                    <div class="bk-summary-price">
                        <h4 v-lang.PRICE_SUMMARY>Price Summary</h4>
                        <!--Loading price summary section-->
                        <!--<div class="bk-pricesummary" v-if="!isSearchCompleted">
                            <div class="form-group">
                                <div class="load"></div>
                            </div>
                            <div class="form-group">
                                <div class="load"></div>
                            </div>
                        </div>-->
                        <!--Loading price summary end-->
                        <!--Price summary section-->
                        <div>
                            <PriceSummary ref="priceSummary" :packageQuery="packageQuery" :addons="addons" :seatSelecteds="seatSelecteds" :currentSection="currentSection" :productType="productType" :promoError="promoError" @onCalcPromoPriceChanged="calcPromoPriceChanged"></PriceSummary>
                        </div>
                        <!-- <div class="bk-summary-promo" v-if="isBookingPage">
                            <a class="btn btn-link btn-block" role="button" data-toggle="collapse" href="#collapsePromo" aria-expanded="false" aria-controls="collapsePromo" v-lang.PROMO_CODE>Promo Code</a>
                            <div class="collapse" id="collapsePromo">
                                <div class="input-group">
                                    <input type="text" class="form-control" id="txtPromoCode" v-model="promoCode" name="PromoCode" v-on:keypress="inputOnlyNumberic" />
                                    <span class="input-group-btn">
                                        <button type="button" class="btn btn-primary" @click="calcPromoPrice()" v-lang.APPLY>Apply</button>
                                    </span>
                                </div>
                                <span v-if="promoError"><span class="field-validation-error" v-lang.PROMO_CODE_NOT_VALID>Promo code is not valid!</span><br /></span>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
        <div class="bk-summary-panel p-default" v-if="packageQuery.hasHotel">
            <div class="bk-summary-list">
                <div class="bk-tandc-info">
                    <!--<span v-lang.VIEW_HOLIDAY_T_C><a href="http://www.malindoholidays.com/terms-conditions" target="_blank" class="view">View Holiday Terms & Conditions</a></span>-->
                    <div>
                        <a v-if="!minHotelCancellationDate" id="btnCancellationPolicy" href="javascript:void(0)" class="alert-msg" data-trigger="focus" title="Cancellation Policy" data-container="body" data-toggle="popover" data-placement="top" data-content="This booking is non-refundable and cannot be amended or modified. Failure to arrive at your hotel will be treated as a no-show and no refund will be given (Hotel policy).">
                            <span v-lang.LOW_RATE_NON_REFUNDABLE>Low rate (non-refundable)</span>
                        </a>
                        <a v-else id="btnCancellationPolicy" href="javascript:void(0)" class="alert-msg" data-trigger="focus" title="Cancellation Policy" data-container="body" data-toggle="popover" data-placement="top" :data-content="'Cancellation on this room is absolutely free if made before ' + minHotelCancellationDate">
                            <span v-lang.FREE_CANCELLATION_BEFORE>Free cancellation before</span> {{minHotelCancellationDate}}
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import {StarRating} from 'goquo-components'
    import PriceSummary from './PriceSummary.vue'
    export default {
        components: { StarRating, PriceSummary },
        props: ["packageQuery", "currentSection", "addons", "seatSelecteds", 'isSearchCompleted', 'isCurrentTourOnly', 'productType', 'isBookingPage'],
        data() {
            return {
                adults: [],
                childs: [],
                promoCode: this.packageQuery.promoCode,
                promoError: null,
                minHotelCancellationDate: null
            }
        },
        created() {
            if (this.packageQuery.departureTransfer == undefined) {
                this.packageQuery.departureTransfer = null;
            }
            if (this.packageQuery.arrivalTransfer == undefined) {
                this.packageQuery.arrivalTransfer = null;
            }

            if (!this.packageQuery.hasFlight && this.packageQuery.hotels && this.packageQuery.hotels.length > 0) {
                var hotel = this.packageQuery.hotels[0];
                var minHotelCancellationDate = null;
                var nonRefundable = false;
                for (var i = 0; i < hotel.availableRooms.length; i++) {
                    var cancelFreeBeforeDate = hotel.availableRooms[i].availableRoomTypes[0].cancelFreeBeforeDate;
                    if (cancelFreeBeforeDate) {
                        if (!minHotelCancellationDate) {
                            minHotelCancellationDate = cancelFreeBeforeDate;
                        }
                        else {
                            var oldDate = new Date(minHotelCancellationDate);
                            var newDate = new Date(cancelFreeBeforeDate);
                            if (newDate < oldDate) {
                                minHotelCancellationDate = cancelFreeBeforeDate;
                            }
                        }
                    }
                    else {
                        nonRefundable = true;
                    }
                }

                if (minHotelCancellationDate && !nonRefundable) {
                    this.minHotelCancellationDate = moment(minHotelCancellationDate).format('DD/MM/YYYY');
                }
            }
        },
        mounted() {
            $("#btnCancellationPolicy").popover();
        },
        methods: {
            getHotelDate(x, y) {
                if (y) {
                    return y;
                }
                return x;
            },
            updatePriceSummary() {
                if (typeof (this.$refs) != "undefined") {
                    this.$refs.priceSummary.updatePriceSummary();
                }
            },
             calcPromoPriceChanged(promo) {
                let self = this;
                self.promoCode = promo;
                self.calcPromoPrice();
            },
            calcPromoPrice() {
                var self = this;
                self.$emit("onCalcPromoPrice", function (priceSummry) {
                    if (priceSummry.promoPrice === 0) {
                        self.promoError = true;
                    }
                    else {
                        self.promoError = false;
                    }
                });
            },
            getTourActivies: function (tour) {
                var nameActivies = "";
                if (tour.activities && tour.activities.length > 0) {
                    for (var i = 0; i < tour.activities.length; i++) {
                        if (tour.activities[i].code == tour.activityCode) {
                            nameActivies = tour.activities[i].name;
                            break;
                        }
                    }
                }
                return nameActivies;
            },
            removeTour(tour) {
                this.$emit("onCallRemoveTour", tour);
            },
            showTourInfor(tour) {
                this.$emit("onOpenTourInfor", tour);
            },
            inputOnlyNumberic: function (event) {
                if (event.which == 13) {
                    event.preventDefault();
                }
            }
        }
    }
</script>