﻿<template>
    <div v-if="packageQuery">
        <SessionTimeout :packageId="packageQuery.id" :secondTimeout="packageQuery.ttl"></SessionTimeout>
        <!--breadcrumb-section start-->
        <section class="breadcrumb-section">
            <div class="container">
                <div class="row">
                    <ol class="breadcrumb" id="breadcrumb">
                        <li :class="{'active': currentSection === SECTION_GUEST_DETAILS}" @click="selectSectionPassenger(currentSection)"><i class="icon icon-user"></i> <span v-lang.PASSENGER_DETAILS>Passenger Details</span></li>
                        <li v-if="packageQuery.hasFlight" :class="{'active': currentSection === SECTION_SEATS, 'next disabled': currentSection < SECTION_SEATS}" @click="currentSection > SECTION_SEATS && selectSectionSeat()"><i class="icon icon-addon"></i> <span v-lang.ADDONS>Addons</span></li>
                        <li :class="{'active': currentSection === SECTION_PAYMENT, 'next disabled': currentSection < SECTION_PAYMENT}"><i class="icon icon-payment"></i> <span v-lang.PAYMENT>Payment</span></li>
                    </ol>
                </div>
            </div>
        </section>
        <!--breadcrumb-section end-->
        <!--Booking section start-->
        <section class="bk-section">
            <div class="container">

                <form method="POST" action="/booking/booking-now" id="frmBooking" name="bookingform" data-val="true">
                    <div class="row">

                        <!--Booking Summary-->
                        <div class="col-xs-12 col-sm-5 col-sm-push-7 col-md-4 col-md-push-8">
                            <div :class="{'isAddon-summary': currentSection === SECTION_SEATS}">
                                <BookingSummary :packageQuery="packageQuery" :addons="addOnSelecteds" :seatSelecteds="seatSelecteds" :isBookingPage="true" :currentSection="currentSection" ref="bookingSummary" v-on:onCalcPromoPrice="calcPromoPrice"></BookingSummary>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-7 col-sm-pull-5 col-md-8 col-md-pull-4">

                            <!--Page one-->
                            <div id="guest-details-tab" v-show="currentSection === SECTION_GUEST_DETAILS">
                                <div class="bk-title">
                                    <h4 class="bk-title-head"> <span class="icon icon-contact"></span> <span v-lang.CONTACT_DETAILS>Contact Details</span></h4>
                                </div>

                                <!--Contact Details-->
                                <ContactDetails v-show="currentSection === SECTION_GUEST_DETAILS" :countries="countries" :personalDetails="personalDetails"></ContactDetails>

                                <!--Passenger Details-->
                                <div class="bk-pax-details hight0">
                                    <div class="bk-title">
                                        <h4 class="bk-title-head"> <span class="icon icon-user"></span> <span v-lang.PASSENGER_DETAILS>Passenger Details</span> <span class="bk-all-field" v-lang.ALL_FIELDS_REQUIRED>All fields required</span></h4>
                                        <p v-lang.PASSENGER_NAME_MUST_MATCH_GOVERNMENT_ISSUED>Passenger name must match government-issued photo ID in Roman alphabet (A-Z).</p>
                                    </div>

                                    <div v-for="passenger in passengers">
                                        <MainPassenger v-if="passenger.passengerType === 'Adult'" :passenger="passenger" :countries="countries" :hasFlight="hasFlight" :addOnSelecteds="addOnSelecteds" :seatLegs="seatLegs" :personalDetails="personalDetails"></MainPassenger>
                                        <ChildPassenger v-if="passenger.passengerType === 'Child'" :passenger="passenger" :countries="countries" :hasFlight="hasFlight" :packageQuery="packageQuery" :addOnSelecteds="addOnSelecteds" :seatLegs="seatLegs"></ChildPassenger>
                                        <InfantPassenger v-if="passenger.passengerType === 'Infant'" :passenger="passenger" :countries="countries" :hasFlight="hasFlight" :addOnSelecteds="addOnSelecteds" :seatLegs="seatLegs"></InfantPassenger>
                                    </div>
                                </div>

                            </div>

                            <!--Page two-->
                            <div v-show="currentSection === SECTION_SEATS">
                                <!--Main Title-->
                                <div class="bk-title">
                                    <h2 class="bk-title-head"><span class="icon icon-addon"></span> <span v-lang.ADDONS>Addons</span></h2>
                                </div>

                                <!--Baggage Details-->
                                <Baggage :packageQuery="packageQuery" :addons="addons" :addOnSelecteds="addOnSelecteds" :passengers="passengers" v-on:onAddonsChanged="calculateAddonsPrice"></Baggage>

                                <!--Seats Details-->
                                <Seats :packageQuery="packageQuery" :seatLegs="seatLegs" :seatSelecteds="seatSelecteds" :passengers="passengers" v-on:onAddonsChanged="calculateAddonsPrice"></Seats>

                                <!--<div id="seat-modal-confirm" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
                                    <div class="modal-dialog modal-sm">
                                        <div class="modal-content">
                                            <div class="modal-body">
                                                <h5 v-lang.CONFIRM_CONTINUE_WITHOUT_SELECTING_ALL_SEATS>Are you sure you want to continue without selecting all seats?</h5>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="text-right">
                                                    <a title="Close" class="btn btn-secondory seat-modal-close" href="javascript:;" data-dismiss="modal" v-lang.SELECT_SEAT>Select Seat</a>
                                                    <button type="button" @click="nextSectionWithoutSeat()" class="btn btn-success" v-lang.CONTINUE>Continue</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>

                            <div v-show="currentSection === SECTION_PAYMENT">
                                <!--Passenger Info-->
                                <div class="bk-title hidden-hx">
                                    <h4 class="bk-title-head"> <span v-lang.PASSENGERS>Passengers</span> </h4>
                                </div>

                                <div class="cus-panel cus-panel-default cus-panel-normal hidden-hx">
                                    <div class="cus-panel-body cus-panel-body-split pp-paxinfo">
                                        <div class="ss-paxdetails" v-for="passenger in passengers">
                                            <label>
                                                <span>{{passenger.title}}</span>.&nbsp;
                                                <span class="text-uppercase">{{passenger.firstName}}</span>&nbsp;
                                                <span class="text-uppercase">{{passenger.lastName}}</span>
                                            </label>
                                            <div class="ss-selectedseat">
                                                <small> <span :class="'icon icon-' + passenger.passengerType.toLowerCase()"></span> {{passenger.passengerType}}</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!--Payment Info-->
                                <Payment :paymentGateways="paymentGateways" v-on:onCalcPromoPrice="calcPromoPrice" :packageQuery="packageQuery" :agentB2b="agentB2b"></Payment>

                                <div class="bk-title">
                                    <h4 class="bk-title-head"> <span v-lang.TERMS_AND_CONDITIONS>Terms and Conditions</span> </h4>
                                </div>

                                <div class="cus-panel cus-panel-default">
                                    <div class="cus-panel-body">
                                        <div class="form-group">
                                            <div class="checkbox checkbox-primary" v-if="packageQuery.packageType != 'B2C' && agentB2b == 'B2B'">
                                                <input name="isShowPriceInVoucher" id="isShowPriceInVoucher" v-model="isShowPriceInVoucher" class="styled" type="checkbox">
                                                <label class="styled" for="isShowPriceInVoucher" v-lang.SHOW_PAYMENT_SUMMARY_IN_VOUCHER>Show Payment Summary in voucher.</label>
                                                <input type="hidden" id="ShowPriceInVoucher" name="ShowPriceInVoucher" :value="isShowPriceInVoucher" />
                                            </div>

                                            <div class="checkbox checkbox-primary">
                                                <input name="TermsAndConditions" id="rulandreg" class="styled" type="checkbox" data-val="true" data-val-mandatory="Please read and agree to our terms and conditions">
                                                <label class="styled" for="rulandreg" v-lang.I_HAVE_READ_T_C>I have read the <a href="http://www.malindoholidays.com/terms-conditions" class="primary-color" target="_blank">terms &amp; conditions</a> for this booking.</label>
                                                <span data-valmsg-replace="true" data-valmsg-for="TermsAndConditions"></span>
                                            </div>
                                            <div class="checkbox checkbox-primary mb5" v-if="packageQuery.hasHotel">
                                                <input name="CancellationPolicies" id="policies" class="styled" type="checkbox" data-val="true" data-val-mandatory="Please read and agree to our cancellation policy">
                                                <label class="styled" for="policies" v-lang.I_HAVE_READ_CANCELLATION>I have read the cancellation policy for this booking.</label>
                                                <span data-valmsg-replace="true" data-valmsg-for="CancellationPolicies"></span>
                                            </div>


                                            <em class="bk-tandc-text" v-lang.PAYMENT_WILL_BE_PROCESSED_BY>Please note: your payment will be processed by Malindo Holidays</em>

                                            <input type="hidden" id="PackageId" name="PackageId" :value="packageQuery.id" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--Bottom Sticky price-->
                            <div class="bk-footer-price" v-show="currentSection !== SECTION_PAYMENT">
                                <a tabindex="0" data-toggle="modal" data-target="#showPriceSummary" >
                                    <strong>
                                        {{packageQuery.currency}} <span>{{packageQuery.priceSummary.totalPrice | formatCurrency }}</span>
                                    </strong>
                                    <small>
                                        <span class="view-full-text" v-lang.FULL_PRICE_SUMMARY>Full price summary</span> <span class="icon icon-hand-pointer view-full-icon"></span>
                                    </small>
                                </a>
                            </div>
                            <!--Bottom Sticky price end-->
                            <!--Button section start-->
                            <a class="btn btn-link bk-link mt10" v-if="currentSection !== 1" @click="prevSection()"><span class="icon icon-left-chevron icon"></span> <span v-lang.GO_BACK>Back</span></a>

                            <a class="btn btn-lg btn-success btn-continue pull-right hide" @click="summaryNextSection" v-show="currentSection !== SECTION_PAYMENT"> <span v-lang.CONTINUE>Continue</span></a>
                            <input type="hidden" name="Checksum" :value="packageQuery.checksum" />
                            <button type="submit" class="btn btn-lg btn-continue pull-right" v-show="currentSection === SECTION_PAYMENT"><span v-lang.BOOK_NOW>Book Now</span></button>
                            <!--Button section end-->
                            <!-- Modal -->
                            <div class="modal fade bk-modal" id="showPriceSummary" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" ref="vueModal">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title" id="myModalLabel" v-lang.PRICE_SUMMARY>Price Summary</h4>
                                        </div>
                                        <div class="modal-body">
                                            <PriceSummary ref="priceSummary" :packageQuery="packageQuery" :addons="addOnSelecteds" :seatSelecteds="seatSelecteds" :currentSection="currentSection" :promoError="promoError" @onCalcPromoPriceChanged="onCalcPromoPriceChanged"></PriceSummary>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="modalCheckSum" class="modal fade">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title" v-lang.PACKAGE_CHANGED>Package changed</h4>
                                        </div>
                                        <div class="modal-body text-center">
                                            {{translateText(checkSumMessage, 'Your package has been changed. Please kindly review your booking and reload this page.')}}
                                        </div>
                                        <div class="modal-footer"><button type="button" class="btn btn-primary" @click="reloadPage()" v-lang.RELOAD>Reload</button></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </section>
        <!--Booking section end-->
    </div>
</template>

<style>
</style>

<script>
    import ContactDetails from './ContactDetails.vue'
    import MainPassenger from './MainPassenger.vue'
    import ChildPassenger from './ChildPassenger.vue'
    import InfantPassenger from './InfantPassenger.vue'
    import Baggage from './Baggage.vue'
    import Seats from './Seats.vue'
    import Payment from './Payment.vue'
    import BookingSummary from './BookingSummary.vue'
    import PriceSummary from './PriceSummary.vue'
    import httpQueueService from './httpQueueService'
    import SessionTimeout from '../SessionTimeout.vue'
    export default {
        mixins: [httpQueueService],
        components: { ContactDetails, MainPassenger, ChildPassenger, InfantPassenger, Baggage, Seats, Payment, BookingSummary, PriceSummary, SessionTimeout },
        data() {
            return {
                SECTION_GUEST_DETAILS: 1,
                SECTION_SEATS: 2,
                SECTION_PAYMENT: 3,
                currentSection: 1, // Default is SECTION_GUEST_DETAILS
                packageQuery: null,
                personalDetails: null,
                passengers: [],
                countries: [],
                hasFlight: false,
                addons: {
                    seats: [],
                    baggages: {
                        departing: null,
                        returning: null
                    },
                    meals: [],
                    sportEquipments: {
                        departing: null,
                        returning: null
                    }
                },
                seatLegs: [],
                addOnSelecteds: [],
                seatSelecteds: [],
                paymentGateways: [],
                addonsLoaded: false,
                isApplyInsurance: false,
                isShowPriceInVoucher: false,
                agentB2b: null,
                checkSumMessage: "",
                promoCode: null,
                promoError: null
            }
        },
        watch: {
            currentSection: function () {
                // Track virtual page change

                // Only if GTM is present
                if (typeof dataLayer != 'undefined') {
                    let dataObject = { virtualPagePath: '', event: 'virtualPageView' };
                    if (this.currentSection === 1) { // Guest
                        dataObject.virtualPagePath = document.location.pathname;
                    }
                    if (this.currentSection === 2) { // Seat selection
                        dataObject.virtualPagePath = document.location.pathname.replace('booking/', 'booking/seats/');
                    }
                    if (this.currentSection === 3) { // Payment page
                        dataObject.virtualPagePath = document.location.pathname.replace('booking/', 'booking/payment/');
                    }

                    // If valid page path then we send data to GTM
                    if (dataObject.virtualPagePath) {
                        dataLayer.push(dataObject);
                    }
                }
            }
        },
        created() {
            var packageId = $("#PackageId").val();
            var self = this;
            $.post('/booking/get-work-context/' + packageId, function (data) {
                if (!data.packageQuery) {
                    window.location.reload();
                }
                self.packageQuery = data.packageQuery;
                self.hasFlight = data.packageQuery.outboundFlight != null;
                self.countries = data.countries;
                self.personalDetails = data.personalDetails || {
                    title: 'Mr',
                    countryCode: data.defaultCountry || 'MY',
                    city: 'Kuala Lumpur',
                    addressLine1: 'A-7-1, NorthPoint Offices, No.1, Medan Syed Putra Utara, Mid Valley City, 59200'
                };

                for (var i = 0; i < data.passengers.length; i++) {
                    var passenger = data.passengers[i];
                    passenger.nationality = passenger.nationality || data.defaultCountry || 'MY';
                    passenger.baggageDeparting = '';
                    passenger.baggageReturning = '';

                    if (passenger.dateOfBirth != null && passenger.dateOfBirth != '0001-01-01T00:00:00') {
                        passenger.dayOfBirth = new Date(passenger.dateOfBirth).getDate();
                        passenger.monthOfBirth = new Date(passenger.dateOfBirth).getMonth() + 1;
                        passenger.yearOfBirth = new Date(passenger.dateOfBirth).getFullYear();
                    }
                    else {
                        passenger.dayOfBirth = '';
                        passenger.monthOfBirth = '';
                        passenger.yearOfBirth = '';
                    }

                    switch (passenger.passengerType) {
                        case 'Adult':
                            passenger.title = passenger.title || 'Mr';
                            break
                        case 'Child':
                        case 'Infant':
                            passenger.title = passenger.title || 'Mstr';
                            break
                    }
                }

                self.passengers = data.passengers;
                self.paymentGateways = data.paymentGateways;
                self.agentB2b = data.agent;

                setTimeout(function () {
                    self.attachBookingForm();
                }, 100);

            }).fail(function () {
                window.location.reload();
            });
            
        },
        updated() {
            $.validator.unobtrusive.parse(document);
            
        },
        beforeUpdate() {
            $(this.$refs.vueModal).on("hidden.bs.modal", this.clearDataOnModal)
        },
        methods: {
            clearDataOnModal() {
                $(".field-validation-error").css("display" , 'none');
            },
            getAddons(outboundFlightFrom, inboundFlightFrom) {
                if (this.addonsLoaded) {
                    return;
                }
                $("#page-loader").show();

                var self = this;

                this.addToQueue("/package/get-baggages/" + this.packageQuery.id, "post", {}, function (response) {
                    self.availabilityBaggages(response, outboundFlightFrom, inboundFlightFrom);
                });

                this.addToQueue("/package/get-meals/" + this.packageQuery.id, "post", {}, function (response) {
                    self.availabilityMeals(response);
                });

                this.addToQueue("/package/get-sport-equipments/" + this.packageQuery.id, "post", {}, function (response) {
                    self.availabilitySportEquipment(response);
                });

                this.addToQueue("/package/get-seats/" + this.packageQuery.id, "post", { isOutboundFlight: true }, function (response) {
                    if (response) {
                        self.setSeatLegs(response, true);
                    }
                });

                this.addToQueue("/package/get-seats/" + this.packageQuery.id, "post", { isOutboundFlight: false }, function (response) {
                    if (response) {
                        self.setSeatLegs(response, false);
                    }
                });

                this.addToQueue("/package/get-priority-checkins/" + this.packageQuery.id, "post", {}, function (response) {
                    //$scope.availabilityPriorityChecking(response);

                    if (self.seatLegs.length === 0) {
                        self.nextSection();
                    }

                    $("#page-loader").hide();
                });

                this.addonsLoaded = true;
            },
            selectSectionPassenger(selected) {
                if (this.seatSelecteds && this.seatSelecteds.length > 0) {
                    $.each(this.passengers, function (index, passenger) {
                        passenger.seats = {};
                    });

                    this.seatSelecteds = [];
                    this.calculateAddonsPrice(function () { });
                }

                if (selected < this.SECTION_GUEST_DETAILS) {
                    return;
                }
                this.currentSection = this.SECTION_GUEST_DETAILS;
            },
            summaryNextSection() {
                if (this.currentSection === this.SECTION_SEATS) {
                    var numberOfPaxs = this.passengers.filter(function (x) {
                        return x.passengerType !== 'Infant';
                    }).length;
                    var totalSeats = numberOfPaxs * this.seatLegs.length;
                    // if (!this.seatSelecteds || this.seatSelecteds.length < totalSeats) {
                    //     $("#seat-modal-confirm").modal("show");
                    //     return;
                    // }
                }
                this.nextSection();
            },
            nextSectionWithoutSeat() {
                $("#seat-modal-confirm").modal("hide");
                this.nextSection();
            },
            nextSection() {
                var valid = this.validate();
                if (!valid) {
                    return;
                }

                // If from guest details page and no flight, skip the seat selection
                if (this.currentSection === this.SECTION_GUEST_DETAILS) {
                    if (this.packageQuery.hasFlight) {
                        // If FH

                        var outboundFlightFrom = this.packageQuery.outboundFlight.from;
                        var inboundFlightFrom = this.packageQuery.inboundFlight.from;
                        this.getAddons(outboundFlightFrom, inboundFlightFrom);

                        this.currentSection = this.SECTION_SEATS;
                    }
                    else {
                        // If HO or no flights
                        this.currentSection = this.SECTION_PAYMENT;
                    }
                }
                // From other pages
                else {
                    this.currentSection++;
                }

                $("html, body").animate({ scrollTop: 0 }, "nomal");
            },
            prevSection() {
                //Dont allow back on first page
                if (this.currentSection === this.SECTION_GUEST_DETAILS) {
                    return;
                }

                // If back from payment page, skip addon section if selected product doesnt have flight
                if (this.currentSection === this.SECTION_PAYMENT && !this.packageQuery.hasFlight) {
                    this.currentSection = this.SECTION_GUEST_DETAILS;
                    return;
                }

                // Change page
                this.currentSection--;
                $("html, body").animate({ scrollTop: 0 }, "nomal");
            },
            selectSectionSeat() {
                this.currentSection = this.SECTION_SEATS;
            },
            validate() {
                var valid = true;

                var fields = $("#guest-details-tab input[required], select[required], input[must-validate]");

                var elements = [];
                for (var i = 0; i < fields.length; i++) {
                    var field = fields[i];
                    if (!$(field).valid()) {
                        elements.push(field);
                    }
                }

                if (elements.length > 0) {
                    valid = false;
                    var position = $(elements[0]).offset();
                    $("html, body").animate({ scrollTop: position.top - 100 }, "500", "swing");
                    $(elements[0]).focus();
                }

                return valid;
            },
            availabilityBaggages(baggages, outboundFlightFrom, inboundFlightFrom) {
                this.updatePaxNoToNull(baggages);

                var departingBaggages = baggages.find(function (x) {
                    return x.from === outboundFlightFrom;
                });

                this.addons.baggages.departing = departingBaggages;

                var returningBaggages = baggages.find(function (x) {
                    return x.from === inboundFlightFrom;
                });

                this.addons.baggages.returning = returningBaggages;
            },
            availabilityMeals(meals) {

            },
            availabilitySportEquipment(sportEquipments) {

            },
            updatePaxNoToNull(addons) {
                $.each(addons, function (index, item) {
                    $.each(item.addonInfoList, function (i, addon) {
                        addon.paxNo = null;
                    });
                });
            },
            setSeatLegs(response, isOutboundFlight) {
                var self = this;
                $.each(response, function (legIndex, leg) {
                    if (leg.seats && leg.seats.length > 0) {
                        self.seatsMapping(leg);

                        if (isOutboundFlight) {
                            var obsegmentDetail = self.packageQuery.outboundFlight.legs
                                .find(function (entry) {
                                    return entry.departureAirportCode === leg.from && entry.arrivalAirportCode === leg.to;
                                });

                            leg.departureCityName = obsegmentDetail ? obsegmentDetail.departureCityName : leg.from;
                            leg.arrivalCityName = obsegmentDetail ? obsegmentDetail.arrivalCityName : leg.to;
                        } else {
                            var ibsegmentDetail = self.packageQuery.inboundFlight.legs
                                .find(function (entry) {
                                    return entry.departureAirportCode === leg.from && entry.arrivalAirportCode === leg.to;
                                });

                            leg.departureCityName = ibsegmentDetail ? ibsegmentDetail.departureCityName : leg.from;
                            leg.arrivalCityName = ibsegmentDetail ? ibsegmentDetail.arrivalCityName : leg.to;
                        }

                        var flightLeg = self.findFlightLeg("outboundFlight", leg);
                        if (!flightLeg) {
                            flightLeg = self.findFlightLeg("inboundFlight", leg);
                        }

                        if (flightLeg) {
                            leg.departureDate = flightLeg.departureDate;
                            leg.arrivalDate = flightLeg.arrivalDate;
                        }

                        self.seatLegs.push(leg);
                    }
                });
            },
            seatsMapping(leg) {
                var self = this;
                leg.seatRows = [];
                $.each(leg.rows, function (rowIndex, row) {
                    var seats = [];
                    $.each(leg.columns, function (columnIndex, column) {
                        //Join Row and Column to SeatName
                        var seatName = row + column;

                        //Check SeatName exist in list Seats response
                        var seat = self.getSeatByDesignator(leg.seats, seatName);

                        //Seat existed
                        if (seat !== null && seat !== undefined) {
                            seat.selected = false;
                            seat.paxNo = -1;
                            seat.isSeat = true;
                            seat.columnIndex = columnIndex;
                            seat.rowIndex = rowIndex;

                            seats.push(seat);
                        } else {
                            seats.push({
                                isSeat: true,
                                paxNo: -1,
                                selected: false,
                                group: 0
                            });
                        }

                        //Push Corridor to array for display
                        if (columnIndex === ((leg.columns.length / 2) - 1)) {
                            seats.push({
                                isSeat: false,
                                designator: row
                            });
                        }
                    });
                    leg.seatRows.push({
                        seats: seats
                    });
                });

                //Push Corridor to array for display
                var numberSeatBothSharp = leg.columns.length / 2;
                leg.columns.splice(numberSeatBothSharp, 0, "");
            },
            getSeatByDesignator(seats, designator) {
                return seats.find(function (x) { return x.designator === designator; });
            },
            findFlightLeg(direction, leg) {
                if (this.packageQuery[direction]) {
                    for (var i = 0; i < this.packageQuery[direction].legs.length; i++) {
                        var flightLeg = this.packageQuery[direction].legs[i];
                        if (flightLeg.departureAirportCode === leg.from && flightLeg.arrivalAirportCode === leg.to) {
                            return flightLeg;
                        }
                    }
                }

                return null;
            },
            calculateAddonsPrice(callback) {
                $("#page-loader").show();
                var self = this;

                var addons = this.convertAddonsToModel();

                var promoCode = this.packageQuery.promoCode;
                if (promoCode == undefined) {
                    promoCode = $(".bk-summary-promo .txtPromoCode").val() == "" ? "" : $(".bk-summary-promo .txtPromoCode").val();
                }

                this.addToQueue("/booking/get-price-summary", "post", {
                    packageId: this.packageQuery.id,
                    promoCode: promoCode,
                    creditCardNumber: "",
                    applyInsurance: this.isApplyInsurance,
                    addonDetails: addons
                }, function (data) {
                    self.packageQuery.priceSummary = data;

                    if (callback) {
                        callback(data);
                    }

                    self.$refs.bookingSummary.updatePriceSummary();
                    self.$refs.priceSummary.updatePriceSummary();
                    $("#page-loader").hide();
                }, function () {
                    window.location.reload();
                });
            },
            convertAddonsToModel() {
                var addonDetails = [];

                var addonGroups = this.addOnSelecteds.sort(function (a, b) {
                    if (a.paxNo < b.paxNo) {
                        return -1;
                    }
                    if (a.paxNo > b.paxNo) {
                        return 1;
                    }
                    return 0;
                }).groupBy("paxNo");

                $.each(addonGroups, function (i, vals) {
                    var addonDetail = {
                            seats: [],
                            addons: []
                        };

                    for (var j = 0; j <= vals.length - 1; j++) {
                        var key = vals[j].from + "/" + vals[j].to + "/" + vals[j].addonType + "/" + vals[j].code;
                        addonDetail.addons.push(key);
                    }
                    addonDetails.push(addonDetail);
                });

                var seatGroups = this.seatSelecteds.sort(function (a, b) {
                    if (a.paxNo < b.paxNo) {
                        return -1;
                    }
                    if (a.paxNo > b.paxNo) {
                        return 1;
                    }
                    return 0;
                }).groupBy("paxNo");

                $.each(seatGroups, function (i, vals) {
                    var addonDetail = {
                        seats: [],
                        addons: []
                    };

                    for (var j = 0; j <= vals.length - 1; j++) {
                        var key = vals[j].from + "/" + vals[j].to + "/" + vals[j].designator;
                        addonDetail.seats.push(key);
                    }
                    addonDetails.push(addonDetail);
                });

                return addonDetails;
            },
            onCalcPromoPriceChanged(promo) {
                let self = this;
                self.promoCode = promo;
                self.calcPromoPrice(function (priceSummry) {
                    if (priceSummry.promoPrice === 0) {
                        self.promoError = true;
                    }
                    else {
                        self.promoError = false;
                    }
                });
            },
            calcPromoPrice(callback) {
                var self = this;
                var cardNumber = $("#txtCreditCardNumber").val();
                var promoCode = $("#txtPromoCode").val();
                var addonDetails = this.convertAddonsToModel();

                $.ajax({
                    type: "POST",
                    url: "/booking/get-price-summary",
                    data: {
                        packageId: this.packageQuery.id,
                        creditCardNumber: cardNumber,
                        promoCode: promoCode,
                        applyInsurance: this.isApplyInsurance,
                        addonDetails: addonDetails
                    },
                    success: function (data) {
                        self.packageQuery.priceSummary = data;
                        if (callback) {
                            callback(data);
                        }
                         $(".field-validation-error").css("display" , 'inline-block');
                    }
                });
            },
            attachBookingForm() {
                var self = this;
                self.checkSumMessage = "";
                $("#frmBooking").ajaxSubmit({
                    before: function (data) {
                        $('#page-loader').show();
                        for (var i = 0; i < data.length; i++) {
                            var item = data[i];
                            switch (item.name) {
                                case 'Password':
                                case 'CreditCardName':
                                case 'CreditCardNumber':
                                case 'CreditCardCvvCode':
                                    item.value = aesEncrypt(item.value).toString();
                                    break;
                            }
                        }
                    },
                    success: function (data) {
                        if (data.success) {
                            switch (data.action) {
                                case "Alert":
                                    if (data.message && data.message.length > 0) {
                                        self.$swal(data.message)
                                        if (typeof dataLayer != 'undefined') {
                                            dataLayer.push({
                                                'event': 'errorMessage',
                                                'eventAction': 'paymentPage',
                                                'eventLabel': data.message
                                            });
                                        };
                                    }
                                    break;
                                case "Redirect":
                                    postToUrl(data.redirectUrl, data.redirectValues);
                                    break;
                                case "ShowPopup":
                                    break;
                            }
                        }
                        else {
                            if (data.message && data.message.length > 0) {
                                self.checkSumMessage = data.message.split(".").join("");
                                if (data.message == 'Your package has been changed. Please kindly review your booking and reload this page.') {
                                    $('#modalCheckSum').modal('show');
                                }
                                else {
                                    self.$swal(data.message)
                                    if (typeof dataLayer != 'undefined') {
                                        dataLayer.push({
                                            'event': 'errorMessage',
                                            'eventAction': 'paymentPage',
                                            'eventLabel': data.message
                                        });
                                    };
                                }
                            }
                        }
                    },
                    complete: function () {
                        $('#page-loader').hide();
                    }
                });
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            reloadPage() {
                location.reload();
            }
        },
        mounted() {
            
        },
    }

</script>