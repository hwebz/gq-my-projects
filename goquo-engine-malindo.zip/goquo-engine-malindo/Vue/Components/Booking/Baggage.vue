﻿<template>
    <div>
        <h4 class="text-uppercase title" v-lang.BAGGAGE>Baggage</h4>
        <!--<p class="subtitle" v-lang.MAXIMUM_BAGGAGE_PER_PERSON v-if="isTranslationAvailable('MAXIMUM_BAGGAGE_PER_PERSON')"></p>-->

        <!--Baggage Loader start-->
        <div class="row" v-if="addons.baggages.departing === null">
            <div class="col-xs-12 col-lg-6">
                <div class="cus-panel cus-panel-default cus-panel-normal">
                    <div class="cus-panel-heading">
                        <div class="cus-panel-title">
                            <div class="load load25"></div>
                            <span class="cus-panel-titlepriceright" style="position: absolute;top: -12px;right: 0;">
                                {{packageQuery.currency}}
                                <span class="load-icon" style="top: 1px;">
                                    <span class="bounce1"></span>
                                    <span class="bounce2"></span>
                                    <span class="bounce3"></span>
                                </span>
                            </span>
                        </div>
                    </div>
                    <div class="cus-panel-body cus-panel-body-split" style="width: 100%;">
                        <div class="ss-paxdetails">
                            <div class="load"></div>
                            <div class="load load50"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-lg-6">
                <div class="cus-panel cus-panel-default cus-panel-normal">
                    <div class="cus-panel-heading">
                        <div class="cus-panel-title">
                            <div class="load load25"></div>
                            <span class="cus-panel-titlepriceright" style="position: absolute;top: -12px;right: 0;">
                                {{packageQuery.currency}}
                                <span class="load-icon" style="top: 1px;">
                                    <span class="bounce1"></span>
                                    <span class="bounce2"></span>
                                    <span class="bounce3"></span>
                                </span>
                            </span>
                        </div>
                    </div>
                    <div class="cus-panel-body cus-panel-body-split" style="width: 100%;">
                        <div class="ss-paxdetails">
                            <div class="load"></div>
                            <div class="load load50"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Baggage Loader end-->

        <div v-if="addons.baggages && (addons.baggages.departing || addons.baggages.returning)">
            <div class="row">

                <!-- Departing -->
                <div class="col-xs-12 col-lg-6" v-if="addons.baggages.departing">
                    <div class="cus-panel cus-panel-default cus-panel-baggage">
                        <div class="cus-panel-heading p-default">
                            <div class="cus-panel-title">
                                <span>{{packageQuery.outboundFlight.from}} - {{packageQuery.outboundFlight.to}}</span> <!--<small v-lang.FREE_BAGGAGE_INCLUDED v-if="isTranslationAvailable('FREE_BAGGAGE_INCLUDED')"></small>-->

                                <span class="cus-panel-titlepriceright">
                                    {{packageQuery.currency}}
                                    <span>{{getTotalBaggagePriceByLeg(addons.baggages.departing.from, addons.baggages.departing.to)}}</span>
                                </span>
                                <span class="cus-panel-paxType">{{packageQuery.outboundFlight.departureDate | moment('ddd, DD MMM YYYY')}}</span>
                            </div>
                        </div>
                        <div class="cus-panel-body">
                            <div class="form-group cus-panel-body-split" v-for="(passenger, index) in passengers" v-if="passenger.passengerType !== 'Infant'">
                                <label class="lb-nowrap">
                                    <span>{{passenger.title}}</span>.&nbsp;
                                    <span class="text-uppercase">{{passenger.firstName}}</span>&nbsp;
                                    <span class="text-uppercase">{{passenger.lastName}}</span>
                                </label>

                                <select class="form-control" v-model="passenger.baggageDeparting" @change="addBaggages(passenger.baggageDeparting, true, index, addons.baggages.departing.from, addons.baggages.departing.to)">
                                    <option value="" v-if="passenger.passengerType === 'Adult'" v-lang.X_INCLUDED="{0: addons.baggages.departing.freeAdultBaggage}"></option>
                                    <option value="" v-if="passenger.passengerType === 'Child'" v-lang.X_INCLUDED="{0: addons.baggages.departing.freeChildrenBaggage}"></option>
                                    <option v-for="bag in addons.baggages.departing.addonInfoList" :value="bag.code">
                                        +{{bag.name}} {{packageQuery.currency}} {{bag.feeDetail.totalPrice}}
                                    </option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Returning -->
                <div class="col-xs-12 col-lg-6" v-if="addons.baggages.returning">
                    <div class="cus-panel cus-panel-default cus-panel-baggage">
                        <div class="cus-panel-heading p-default">
                            <div class="cus-panel-title">
                                <span>{{packageQuery.inboundFlight.from}} - {{packageQuery.inboundFlight.to}}</span> <!--<small v-lang.FREE_BAGGAGE_INCLUDED v-if="isTranslationAvailable('FREE_BAGGAGE_INCLUDED')"></small>-->
                                <span class="cus-panel-titlepriceright">
                                    {{packageQuery.currency}}
                                    <span>{{getTotalBaggagePriceByLeg(addons.baggages.returning.from, addons.baggages.returning.to)}}</span>
                                </span>
                                <span class="cus-panel-paxType">{{packageQuery.inboundFlight.departureDate | moment('ddd, DD MMM YYYY')}}</span>
                            </div>
                        </div>
                        <div class="cus-panel-body">
                            <div class="form-group cus-panel-body-split" v-for="(passenger, index) in passengers" v-if="passenger.passengerType !== 'Infant'">
                                <label class="lb-nowrap">
                                    <span>{{passenger.title}}</span>.&nbsp;
                                    <span class="text-uppercase">{{passenger.firstName}}</span>&nbsp;
                                    <span class="text-uppercase">{{passenger.lastName}}</span>
                                </label>
                                <select class="form-control" v-model="passenger.baggageReturning" @change="addBaggages(passenger.baggageReturning, false, index, addons.baggages.returning.from, addons.baggages.returning.to)">
                                    <option value="" v-if="passenger.passengerType === 'Adult'" v-lang.X_INCLUDED="{0: addons.baggages.returning.freeAdultBaggage}"></option>
                                    <option value="" v-if="passenger.passengerType === 'Child'" v-lang.X_INCLUDED="{0: addons.baggages.returning.freeChildrenBaggage}"></option>
                                    <option v-for="bag in addons.baggages.returning.addonInfoList" :value="bag.code">
                                        +{{bag.name}} {{packageQuery.currency}} {{bag.feeDetail.totalPrice}}
                                    </option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        props: ["packageQuery", "addons", "addOnSelecteds", "passengers"],
        data() {
            return {
            }
        },
        methods: {
            getTotalBaggagePriceByLeg(from, to) {
                var totalBag = 0;
                if (!this.addOnSelecteds.length) {
                    return totalBag;
                }
                $.each(this.addOnSelecteds, function (i, object) {
                    if (object.from === from && object.to === to) {
                        totalBag += object.feeDetail.totalPrice;
                    }
                });

                // To fixed number
                return parseFloat(totalBag.toFixed(this.packageQuery.currencyDecimals));
            },
            addBaggages(addOnCode, isDeparting, paxNo, from, to) {
                var source = null;
                var addOn;
                if (addOnCode !== "") {
                    if (isDeparting) {
                        source = this.addons.baggages.departing.addonInfoList;
                    } else {
                        source = this.addons.baggages.returning.addonInfoList;
                    }
                    var addonAvai = source.find(function (x) {
                        return x.code === addOnCode;
                    });
                    addOn = jQuery.extend(true, {}, addonAvai);
                    addOn.paxNo = paxNo;
                } else {
                    addOn = {
                        paxNo: paxNo,
                        code: null,
                        addonType: 1,
                        from: from,
                        to: to
                    };
                }

                if (this.addOnSelecteds.length > 0) {
                    var addedBaggage = this.addOnSelecteds.find(function (x) {
                        return x.paxNo == addOn.paxNo && x.from == addOn.from && x.to == addOn.to && x.addonType == 1;
                    });

                    if (addedBaggage != null) {
                        var index = 0;
                        for (var i = 0; i < this.addOnSelecteds.length; i++) {
                            if (addedBaggage.code == this.addOnSelecteds[i].code && addedBaggage.paxNo == this.addOnSelecteds[i].paxNo && addedBaggage.from == this.addOnSelecteds[i].from && addedBaggage.to == this.addOnSelecteds[i].to) {
                                index = i;
                            }
                        }
                        this.addOnSelecteds.splice(index, 1);
                    }
                }
                if (addOn.code != null) {
                    this.addOnSelecteds.push(addOn);
                }

                var self = this;
                this.calculateAddonsPrice();
            },
            calculateAddonsPrice(callback) {
                this.$emit("onAddonsChanged", callback);
            },
            // Checks if a translation is available
            isTranslationAvailable(translation_key) {
              // TRUE if has translation, else FALSE
              return (this.translate(this.$language, translation_key)) ? true : false;
            }
        }
    }
</script>