﻿<template>
    <div class="bk-pricesummary">
        <table border="0" cellspacing="0" cellpadding="0" class="table table-responsive">
            <tbody>
                <tr v-if="packageQuery.hasFlight && packageQuery.hasHotel">
                    <td v-lang.PACKAGE_PRICE>Package Price</td>
                    <td>
                        {{packageQuery.currency}}
                        {{packageQuery.priceSummary.packagePrice | formatCurrency }}
                    </td>
                </tr>
                <tr v-if="!packageQuery.hasHotel && packageQuery.priceSummary.flightPrice">
                    <td v-lang.FLIGHT_PRICE>Flight Price</td>
                    <td>{{packageQuery.currency}} {{packageQuery.priceSummary.flightPrice | formatCurrency }}</td>
                </tr>
                <tr v-if="!packageQuery.hasFlight && packageQuery.hasHotel">
                    <td v-lang.HOTEL_PRICE>Hotel Price</td>
                    <td>{{packageQuery.currency}} {{packageQuery.priceSummary.hotelPrice | formatCurrency }}</td>
                </tr>
                <tr v-for="group in baggageSummary">
                    <td>
                        <span><span v-lang.CHECKED_BAGGAGE>Checked baggage</span> {{group.addon.name}}</span>
                    </td>
                    <td>
                        <span>{{packageQuery.currency}}</span>&nbsp;
                        <span>{{group.price | formatCurrency }}</span>
                    </td>
                </tr>
                <tr v-if="sportSummary.length > 0">
                    <td v-lang.SPORTS_EQUIPMENT>Sports Equipment</td>
                    <td>
                        <span>{{packageQuery.currency}}</span>&nbsp;
                        <span>{{sportSummary.sum('price') | formatCurrency }}</span>
                    </td>
                </tr>

                <tr v-for="group in mealSummary">
                    <td data-toggle="tooltip" data-placement="top" :title="group.addon.name">{{group.addon.name}}</td>
                    <td>
                        <span>{{packageQuery.currency}}</span>&nbsp;
                        <span>{{group.price | formatCurrency }}</span>
                    </td>
                </tr>
                <tr v-for="group in seatSummary">
                    <td v-if="isBusinessClass(group.seat.cabinClass)">Business Seat</td>
                    <td v-if="!isBusinessClass(group.seat.cabinClass) && group.seat.name.indexOf('COOL') !== -1">Cool Seat</td>
                    <td v-if="!isBusinessClass(group.seat.cabinClass) && group.seat.name.indexOf('COOL') === -1">Standard Seat</td>
                    <td>
                        <span>{{packageQuery.currency}}</span>&nbsp;
                        <span>{{group.price  | formatCurrency }}</span>
                    </td>
                </tr>

                <tr v-if="priorityCheckinPrice">
                    <td v-lang.PRIORITY_CHECK_IN>Priority check-in</td>
                    <td>
                        <span>{{packageQuery.currency}}</span>&nbsp;
                        <span>{{priorityCheckinPrice | formatCurrency }}</span>
                    </td>
                </tr>

                <tr v-show="packageQuery.priceSummary.taxesAndFees > 0">
                    <td v-lang.TAXES_AND_FEES>Taxes & Fees</td>
                    <td>{{packageQuery.currency}} {{packageQuery.priceSummary.taxesAndFees  | formatCurrency }}</td>
                </tr>

                <tr v-show="packageQuery.priceSummary.toursPrice > 0">
                    <td v-lang.ACTIVITY_PRICE>Activity Price</td>
                    <td>{{packageQuery.currency}} {{(packageQuery.priceSummary.toursPrice)  | formatCurrency }}</td>
                </tr>

                <tr v-show="packageQuery.priceSummary.transfersPrice > 0">
                    <td v-lang.TRANSFER_PRICE>Transfer Price</td>
                    <td>{{packageQuery.currency}} {{(packageQuery.priceSummary.transfersPrice)  | formatCurrency }}</td>
                </tr>
                <tr v-show="packageQuery.priceSummary.insurancePrice > 0">
                    <td v-lang.INSURANCE_PRICE>Insurance Price</td>
                    <td>{{packageQuery.currency}} {{packageQuery.priceSummary.insurancePrice  | formatCurrency }}</td>
                </tr>

                <tr v-show="packageQuery.priceSummary.promoPrice > 0">
                    <td><span v-lang.COUPON_APPLIED>Coupon Applied</span> <br /><span class="label label-success">{{packageQuery.priceSummary.promoTitle}}</span></td>
                    <td class="red-text">- {{packageQuery.currency}} {{packageQuery.priceSummary.promoPrice  | formatCurrency }} </td>
                </tr>

                <tr v-show="packageQuery.priceSummary.gstPrice > 0">
                    <td v-lang.GST>GST</td>
                    <td>{{packageQuery.currency}} {{packageQuery.priceSummary.gstPrice | formatCurrency }}</td>
                </tr>

                <tr v-show="packageQuery.priceSummary.otherChargeMarkupPrice > 0">
                    <td v-lang.SERVICE_CHARGE>Service Charge</td>
                    <td>{{packageQuery.currency}} {{packageQuery.priceSummary.otherChargeMarkupPrice  | formatCurrency }}</td>
                </tr>
                <tr v-if="productTypeValue === 'Hotel' && packageQuery.toCountryName === 'Malaysia'">
                    <td colspan="2" style="font-weight:normal; text-align:left" v-lang.SALES_AND_SERVICE_TAX>Sales & Service Tax (SST) not included</td>
                </tr>
                <tr v-if="productTypeValue === 'Flight_Hotel' && packageQuery.toCountryName === 'Malaysia'">
                    <td colspan="2" style="font-weight:normal; text-align:left" v-lang.HOTEL_SALES_AND_SERVICE_TAX>Hotel Sales & Service Tax (SST) not included</td>
                </tr>
            </tbody>
        </table>
        <div class="bk-price">
            <div>
                <span v-if="!productTypeValue" v-lang.TOTAL_PACKAGE_PRICE>Total Package Price</span>
                <span v-if="productTypeValue === 'Transfer'" v-lang.TOTAL_TRANSFER_PRICE>Total Transfer Price</span>
                <span v-if="productTypeValue === 'Tour'" v-lang.TOTAL_ACTIVITY_PRICE>Total Activity Price</span>
                <span v-if="productTypeValue === 'Hotel'" v-lang.TOTAL_HOTEL_PRICE>Total Hotel Price</span>
                <span v-if="productTypeValue === 'Flight'" v-lang.TOTAL_FLIGHT_PRICE>Total Flight Price</span>

                <span class="bk-price-total">{{packageQuery.currency}} {{packageQuery.priceSummary.totalPrice | formatCurrency }}</span>
            </div>
            <small v-if="packageQuery.hasFlight" class="bk-price-include">(<span v-lang.INCLUDES_TAXES_FEES>inc taxes & fees</span>)</small>

            <span class="bk-promo" v-if="currentSection === 1 && packageQuery.priceSummary.priceChanged > 0">
                <span v-lang.PRICE_HAS_CHANGED_FROM>Please note that your price has changed from</span>
                <span class="bk-promo-defprice">{{packageQuery.currency}} {{packageQuery.priceSummary.oldTotalPrice | formatCurrency }}</span>
            </span>
            
        </div>
        <div class="bk-summary-promo">
            <a class="btn btn-block" href=".collapsePromo" data-toggle="collapse" v-lang.DO_YOU_HAVE_A_PROMO_CODE>
                Do you have a promo code?
            </a>
            <div class="collapse collapsePromo">
                <div class="input-group">
                    <input type="text" id="txtPromoCode" class="form-control txtPromoCode" v-model="promoCode" name="PromoCode" @keypress="inputOnlyNumberic" />
                    <span class="input-group-btn">
                        <button type="button" class="btn btn-primary" @click="calcPromoPriceChanged()" v-lang.APPLY>Apply</button>
                    </span>
                </div>
                <span v-if="promoError"><span class="field-validation-error" v-lang.PROMO_CODE_NOT_VALID>Promo code is not valid!</span><br /></span>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: ["packageQuery", "addons", "seatSelecteds", "currentSection", "hello", "productType" ,  "promoError"],
        data() {
            return {
                baggageSummary: [],
                seatSummary: [],
                sportSummary: [],
                mealSummary: [],
                priorityCheckinPrice: null,
                productTypeValue: null,
                 promoCode: null,
            }
        },
        created() {
            this.updatePriceSummary();
            if (!this.productType) {
                if (this.packageQuery.hasHotel && !this.packageQuery.hasFlight) {
                    this.productTypeValue = "Hotel";
                }
                else if (this.packageQuery.hasFlight && !this.packageQuery.hasHotel && !this.packageQuery.hasTransfer && !this.packageQuery.hasTour) {
                    this.productTypeValue = "Flight";
                }
                else if (this.packageQuery.hasFlight && this.packageQuery.hasHotel && !this.packageQuery.hasTransfer && !this.packageQuery.hasTour) {
                    this.productTypeValue = "Flight_Hotel";
                }
            }
            else {
                this.productTypeValue = this.productType;
            }
        },
        methods: {
            updatePriceSummary() {
                this.baggageSummary = this.getAddonSummary(1);
                this.seatSummary = this.getSeatSummary();
            },
            isBusinessClass(cabinClass) {
                return (cabinClass === 2 || cabinClass === 3 || cabinClass === 6);
            },
            getAddonSummary(type) {
                var addons = this.getAddonByType(type);
                if (addons && addons.length === 0)
                    return [];

                var groups = [];
                if (type === 1) {
                    groups = this.groupBy(addons, "name");
                } else {
                    groups = this.groupBy(addons, "code");
                }

                var summary = {
                    details: []
                };

                for (var i = 0; i < groups.length; i++) {
                    var g = groups[i];
                    summary.details.push({
                        code: g.key,
                        price: this.sum(g.items, function (a) { return a.feeDetail.totalPrice; }),
                        addon: g.items[0]
                    });
                }
                return summary.details;
            },
            getAddonByType(type) {
                var addOnsByType = [];
                var arrAddons = [];
                for (var i = 0; i < this.addons.length; i++) {
                    if (this.addons[i].addonType === type) {
                        addOnsByType.push(this.addons[i]);
                    }
                }
                return addOnsByType;
            },
            calcPromoPriceChanged() {
                var self = this;
                self.$emit('onCalcPromoPriceChanged', self.promoCode);
            },
            
             inputOnlyNumberic: function (event) {
                if (event.which == 13) {
                    event.preventDefault();
                }
            },
            getSeatSummary() {
                if (this.seatSelecteds.length == 0) {
                    return [];
                }

                var summary = {
                    details: []
                };

                var groups = this.groupBy(this.seatSelecteds, "group");
                for (var i = 0; i < groups.length; i++) {
                    var g = groups[i];
                    summary.details.push({
                        code: g.key,
                        price: this.sum(g.items, function (a) { return a.feeAmount; }),
                        seat: g.items[0]
                    });
                }
                return summary.details;
            },
            groupBy(arr, fieldName) {
                var groups = [];
                if (arr) {
                    for (var i = 0; i < arr.length; i++) {
                        var item = arr[i];
                        var existGroup = this.firstOrDefault(groups, function (g) { return g.key === item[fieldName] });
                        if (existGroup == null) {
                            var newGroup = {
                                key: item[fieldName],
                                items: [item]
                            };
                            groups.push(newGroup);
                        } else {
                            existGroup.items.push(item);
                        }
                    }
                }

                return groups;
            },
            firstOrDefault(arr, condition) {
                if (arr) {
                    for (var i = 0; i < arr.length; i++) {
                        if (condition(arr[i]))
                            return arr[i];
                    }
                }
                return null;
            },
            sum(arr, calc) {
                var totals = 0;
                for (var i = 0; i < arr.length; i++) {
                    totals += calc(arr[i]);
                }

                // To fixed number
                return parseFloat(totals.toFixed(this.packageQuery.currencyDecimals));
            }
        }
    }
</script>