﻿<template>
    <div>
        <div class="cus-panel cus-panel-default">
            <div class="cus-panel-heading">
                <div class="cus-panel-title" v-lang.WHERE_SEND_BOOKING>Where should we send your booking?</div>
            </div>
            <div class="cus-panel-body">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="form-group">
                            <label class="pr15 right-margin" v-lang.TITLE>Title</label>
                            <div class="radio radio-inline radio-primary" v-bind:class="{'active': personalDetails.title === 'Mr'}">
                                <label>
                                    <input type="radio" name="PersonalDetails.Title" value="Mr" v-model="personalDetails.title"> <span v-lang.TITLE_MISTER>Mr</span>
                                </label>
                            </div>
                            <div class="radio radio-inline radio-primary" v-bind:class="{'active': personalDetails.title === 'Mrs'}">
                                <label>
                                    <input type="radio" name="PersonalDetails.Title" value="Mrs" v-model="personalDetails.title"> <span v-lang.TITLE_MISSUS>Mrs</span>
                                </label>
                            </div>
                            <div class="radio radio-inline radio-primary" v-bind:class="{'active': personalDetails.title === 'Ms'}">
                                <label>
                                    <input type="radio" name="PersonalDetails.Title" value="Ms" v-model="personalDetails.title"> <span v-lang.TITLE_MS>Ms</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-md-6">
                        <div class="form-group">
                            <label v-lang.FIRST_NAME>First Name</label><em>*</em>
                            <input type="text"
                                   name="PersonalDetails.FirstName"
                                   id="PersonalDetails_FirstName"
                                   v-model="personalDetails.firstName"
                                   :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                                   required="required"
                                   data-val="true"
                                   class="form-control check-contact text-uppercase"
                                   :data-val-lettersonly="translateText('PLEASE_ENTER_LETTERS_ONLY', 'Please enter letters only.')"
                                   :data-val-regex="translateText('PLEASE_NOT_ALL_SPACES', 'Please not all space')"
                                   data-val-regex-pattern="(?!^ +$)^.+$"
								   maxlength="26"
                                   autocomplete="given-name" />
                            <span data-valmsg-replace="true" data-valmsg-for="PersonalDetails.FirstName"></span>
                        </div>
                    </div>
                    <div class="col-xs-12 col-md-6">
                        <div class="form-group">
                            <label v-lang.LAST_NAME>Last Name</label><em>*</em>
                            <input type="text"
                                   name="PersonalDetails.LastName"
                                   id="PersonalDetails_LastName"
                                   :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                                   required="required"
                                   data-val="true"
                                   class="form-control check-contact text-uppercase"
                                   v-model="personalDetails.lastName"
                                   :data-val-lettersonly="translateText('PLEASE_ENTER_LETTERS_ONLY', 'Please enter letters only.')"
                                   :data-val-regex="translateText('PLEASE_NOT_ALL_SPACES', 'Please not all space')"
                                   data-val-regex-pattern="(?!^ +$)^.+$"
                                   maxlength="26"
                                   autocomplete="family-name">
                            <span data-valmsg-replace="true" data-valmsg-for="PersonalDetails.LastName"></span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-md-6">
                        <div class="form-group">
                            <label><span v-lang.EMAIL_ADDRESS>Email address</span> <small v-lang.ITINERARY_SENT_HERE>(Itinerary will be sent here)</small><em>*</em></label>
                            <input type="email"
                                   name="PersonalDetails.EmailAddress"
                                   id="PersonalDetails_EmailAddress"
                                   v-model="personalDetails.emailAddress"
                                   maxlength="255"
                                   :data-val-email="translateText('ENTER_VALID_EMAIL', 'Please enter a valid email.')"
                                   :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                                   required="required"
                                   data-val="true"
                                   class="form-control check-contact text-lowercase"
                                   aria-required="true"
                                   autocomplete="email">
                            <span data-valmsg-replace="true" data-valmsg-for="PersonalDetails.EmailAddress"></span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-md-6">
                        <div class="bk-mobilefield">
                            <label><span v-lang.MOBILE_NUMBER>Mobile Number</span> <small v-lang.PHONE_ONLY_EMERGENCIES>(Only for emergencies)</small><em>*</em></label>
                            <div class="form-group">
                                <select name="PersonalDetails.CountryCode"
                                        id="PersonalDetails_CountryCode"
                                        v-model="personalDetails.countryCode"
                                        data-val-required="Required"
                                        required="required"
                                        data-val="true"
                                        class="form-control selectCountry check-contact">
                                    <option value="" v-lang.SELECT_COUNTRY>Select country</option>
                                    <option :value="country.code" v-for="country in countries">{{country.name}} ({{country.phoneCode}})</option>
                                </select>
                                <span data-valmsg-replace="true" data-valmsg-for="PersonalDetails.CountryCode"></span>
                            </div>
                            <div class="form-group">
                                <input v-model="personalDetails.mobileNumber"
                                       required="required"
                                       data-val="true"
                                       :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                                       :data-val-regex="translateText('ENTER_VALID_PHONE', 'Please enter a valid phone number.')"
                                       data-val-regex-pattern="^[0-9]+"
                                       class="form-control check-contact"
                                       value=""
                                       maxlength="25"
                                       name="PersonalDetails.MobileNumber"
                                       autocomplete="tel"
                                       aria-required="true">
                                <span data-valmsg-replace="true" data-valmsg-for="PersonalDetails.MobileNumber"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12">
                        <div class="bk-notes">
                            <p><em>* </em> <span v-lang.NOT_REQUIRE_TRAVELLING_PERSON>Does not need to be the person travelling</span></p>
                        </div>
                    </div>
                </div>

                <input type="hidden" name="PersonalDetails.City" v-model="personalDetails.city" />
                <input type="hidden" name="PersonalDetails.AddressLine1" v-model="personalDetails.addressLine1" />
            </div>
        </div>
        <input type="button" id="enablePax" class="btn btn-lg btn-success btn-continue pull-right" :value="translateText('CONTINUE', 'Continue')" @click="nextSection" />
    </div>
</template>
<style>
    
</style>
<script>

    export default {
        props: ["personalDetails", "countries"],
        data() {
            return {
            }
        },
        methods: {
            nextSection() {
                // Number of invalid fields
                var fieldLength = 0;

                //Getting each value from contact details
                $(".check-contact").each(function () {
                    var _input = $(this);
                    if (!_input.valid()) {
                        // Add to variable if invalid
                        fieldLength++;
                    }
                });

                // If no invalid fields then proceed
                if (!fieldLength) {
                    $(".bk-pax-details").removeClass("hight0");
                    $(".btn-success").removeClass("hide");
                    $("#enablePax").addClass("hide");

                    // Scroll to pax details after completion of contact details
                    $('html,body').animate({ scrollTop: $(".bk-pax-details").offset().top - 20 }, 500);

                    // Send contact information to server if sidesell loads correctly
                    if (typeof GQsidesell !== 'undefined' && typeof GQsidesell.saveContact == 'function') {
                        GQsidesell.saveContact();
                    }
                } 
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            }
        }
    }

</script>