﻿export default {
    data() {
        return {
            queue: [],
            running: false
        };
    },
    methods: {
        addToQueue: function (url, method, params, successCallback, errorCallback) {
            this.queue.push({
                url: url,
                method: method.toLowerCase(),
                params: params,
                successCallback: successCallback,
                errorCallback: errorCallback
            });

            if (this.running) return;

            this.startQuery();
        },
        startQuery() {
            if (this.queue.length === 0) {
                this.running = false;
                return;
            }
            this.running = true;

            var req = this.queue.shift();
            if (req) {
                this.query(req);
            }
        },
        query(request) {
            var self = this;
            if (request.method === "post") {
                $.post(request.url, request.params)
                    .done(function (response) {
                        try {
                            request.successCallback(response);
                        } catch (e) {
                            console.error(e);
                        }

                        self.startQuery();
                    }).fail(function (xhr, status, error) {
                        if (request.errorCallback) {
                            request.errorCallback(error);
                        } else {
                            console.log(error);
                        }
                    });
            }
            else {
                $.get(request.url, request.params)
                    .done(function (response) {
                        try {
                            request.successCallback(response);
                        } catch (e) {
                            console.error(e);
                        }
                        self.startQuery();
                    }).fail(function (xhr, status, error) {
                        console.log(error);
                    });
            }
        }
    }
};