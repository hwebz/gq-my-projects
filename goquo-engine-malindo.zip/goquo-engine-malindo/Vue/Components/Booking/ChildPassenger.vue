﻿<template>
    <div class="cus-panel cus-panel-default">
        <input type="hidden" value="Child" :name="'Passengers[{0}].PassengerType'|stringFormat(passenger.passengerIndex)">
        <input type="hidden" :value="'Passengers[{0}].'|stringFormat(passenger.passengerIndex)" :name="'Passengers[{0}].ModelPrefix'|stringFormat(passenger.passengerIndex)">
        <input type="hidden" :value="passenger.roomIndex" :name="'Passengers[{0}].RoomIndex'|stringFormat(passenger.passengerIndex)">

        <div class="cus-panel-heading p-default">
            <div class="cus-panel-title">
                <span v-lang.PASSENGER>Passenger</span> {{passenger.passengerIndex + 1}} - {{passenger.passengerType}}
                <span class="cus-panel-paxType" v-lang.CHILD_AGE_POLICY>Must be aged 2-11 years old at time of travel.</span>
            </div>
        </div>
        <div class="cus-panel-body">
            <div class="row">
                <div class="col-xs-12">
                    <div class="form-group">
                        <label class="pr15 right-margin" v-lang.TITLE>Title</label>
                        <div class="radio radio-primary radio-inline" v-bind:class="{'active': passenger.title === 'Mstr'}">
                            <label>
                                <input type="radio" :name="'Passengers[{0}].Title'|stringFormat(passenger.passengerIndex)" value="Mstr" v-model="passenger.title"> <span v-lang.TITLE_MASTER>Mstr</span>
                            </label>
                        </div>
                        <div class="radio radio-primary radio-inline" v-bind:class="{'active': passenger.title === 'Miss'}">
                            <label>
                                <input type="radio" :name="'Passengers[{0}].Title'|stringFormat(passenger.passengerIndex)" value="Miss" v-model="passenger.title"> <span v-lang.TITLE_MISS>Miss</span>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-md-6">
                    <div class="form-group">
                        <label v-lang.FIRST_MIDDLE_NAMES>First & Middle Name(s)</label><em>*</em>
                        <input type="text"
                               :name="'Passengers[{0}].FirstName'|stringFormat(passenger.passengerIndex)"
                               :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                               required="required"
                               data-val="true"
                               class="form-control placeH-sm text-uppercase"
                               v-model="passenger.firstName"
                               :data-val-lettersonly="translateText('PLEASE_ENTER_LETTERS_ONLY', 'Please enter letters only.')"
                               :data-val-regex="translateText('PLEASE_NOT_ALL_SPACES', 'Please not all space')"
                               data-val-regex-pattern="(?!^ +$)^.+$"
                               maxlength="26">
                        <span data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].FirstName'|stringFormat(passenger.passengerIndex)"></span>
                    </div>
                </div>
                <div class="col-xs-12 col-md-6">
                    <div class="form-group">
                        <label v-lang.LAST_NAME>Last Name</label><em>*</em>
                        <input type="text"
                               :name="'Passengers[{0}].LastName'|stringFormat(passenger.passengerIndex)"
                               :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                               required="required"
                               data-val="true"
                               class="form-control placeH-sm text-uppercase"
                               v-model="passenger.lastName"
                               data-val-lettersonly="Please enter letters only."
                               :data-val-regex="translateText('PLEASE_NOT_ALL_SPACES', 'Please not all space')"
                               data-val-regex-pattern="(?!^ +$)^.+$"
                               maxlength="26">
                        <span data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].LastName'|stringFormat(passenger.passengerIndex)"></span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-md-6">
                    <div class="form-group">
                        <label v-lang.NATIONALITY>Nationality</label><em>*</em>
                        <select :name="'Passengers[{0}].Nationality'|stringFormat(passenger.passengerIndex)"
                                :data-val-required="translateText('PLEASE_ENTER_A_VALUE', 'Please enter a value.')"
                                data-val="true"
                                class="form-control"
                                v-model="passenger.nationality" required>
                            <option value="" v-lang.SELECT_COUNTRY>Select country</option>
                            <option :value="country.code" v-for="country in countries">{{country.name}}</option>
                        </select>
                        <span data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].Nationality'|stringFormat(passenger.passengerIndex)"></span>
                    </div>
                </div>
                <div class="col-xs-12 col-md-6" v-if="!packageQuery.hasTransfer">
                    <div class="bk-dob date-selector">
                        <label><span v-lang.DATE_OF_BIRTH>Date Of Birth</span><em>*</em></label>
                        <div class="form-group">
                            <select :name="'Passengers[{0}].DayOfBirth'|stringFormat(passenger.passengerIndex)"
                                    v-on:change="dateChange(passenger.dayOfBirth, passenger.monthOfBirth, passenger.yearOfBirth, 'dateOfBirth', 'day')"
                                    :data-val-required="translateText('ENTER_DATE', 'Enter date')"
                                    data-val="true"
                                    :data-index="passenger.passengerIndex"
                                    :data-val-daterange-mindate="passenger.minBirthDate"
                                    :data-val-daterange-maxdate="passenger.maxBirthDate"
                                    required=""
                                    class="form-control"
                                    v-model="passenger.dayOfBirth"
                                    autocomplete="bday-day">
                                <option value="" v-lang.DATE>Date</option>
                                <option v-for="day in days" :value="day">{{day}}</option>
                            </select>
                            <span data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].DayOfBirth'|stringFormat(passenger.passengerIndex)"></span>
                        </div>
                        <div class="form-group">
                            <select :name="'Passengers[{0}].MonthOfBirth'|stringFormat(passenger.passengerIndex)"
                                    v-on:change="dateChange(passenger.dayOfBirth, passenger.monthOfBirth, passenger.yearOfBirth, 'dateOfBirth', '')"
                                    :data-val-required="translateText('ENTER_MONTH', 'Enter month')"
                                    data-val="true"
                                    :data-index="passenger.passengerIndex"
                                    :data-val-daterange-mindate="passenger.minBirthDate"
                                    :data-val-daterange-maxdate="passenger.maxBirthDate"
                                    required=""
                                    class="form-control"
                                    v-model="passenger.monthOfBirth"
                                    autocomplete="bday-month">
                                <option value="" v-lang.MONTH>Month</option>
                                <option v-for="month in months" :value="month">{{month}}</option>
                            </select>
                            <span data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].MonthOfBirth'|stringFormat(passenger.passengerIndex)"></span>
                        </div>
                        <div class="form-group">
                            <select :name="'Passengers[{0}].YearOfBirth'|stringFormat(passenger.passengerIndex)"
                                    v-on:change="dateChange(passenger.dayOfBirth, passenger.monthOfBirth, passenger.yearOfBirth, 'dateOfBirth', '')"
                                    :data-val-required="translateText('ENTER_YEAR', 'Enter year')"
                                    data-val="true"
                                    :data-index="passenger.passengerIndex"
                                    :data-val-daterange-mindate="passenger.minBirthDate"
                                    :data-val-daterange-maxdate="passenger.maxBirthDate"
                                    required=""
                                    class="form-control"
                                    v-model="passenger.yearOfBirth"
                                    autocomplete="bday-year">
                                <option value="" v-lang.YEAR>Year</option>
                                <option v-for="year in years" :value="year">{{year}}</option>
                            </select>
                            <span data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].YearOfBirth'|stringFormat(passenger.passengerIndex)"></span>
                        </div>
                        <input must-validate
                               :data-val-daterange="translateText('CHILD_AGE_INVALID', 'Child age invalid')"
                               :data-val-daterange-day="passenger.dayOfBirth"
                               :data-val-daterange-month="passenger.monthOfBirth"
                               :data-val-daterange-year="passenger.yearOfBirth"
                               :data-val-daterange-mindate="passenger.minBirthDate"
                               :data-val-daterange-maxdate="passenger.maxBirthDate"
                               :data-index="passenger.passengerIndex"
                               type="hidden"
                               data-val="true"
                               :name="'Passengers[' + passenger.passengerIndex + '].Dob'" />
                        <span v-show="passenger.dayOfBirth && passenger.monthOfBirth && passenger.yearOfBirth" :data-valmsg-for="'Passengers['+ passenger.passengerIndex +'].Dob'" data-valmsg-replace="true"></span>
                    </div>
                </div>
            </div>
            <div class="row" v-if="hasFlight">
                <div class="col-xs-12 col-md-6">
                    <div class="form-group">
                        <label><span v-lang.FREQUENT_FLYER_NUMBER>Malindo Miles Frequent Flyer Number</span> <small v-lang.OPTIONAL>(optional)</small></label>
                        <input autocomplete="off"
                               class="form-control"
                               data-val="true"
                               type="text"
                               maxlength="12"
                               minlength="11"
                               :name="'Passengers[{0}].FrequentFlyerNumber'|stringFormat(passenger.passengerIndex)"
                               v-model="passenger.frequentFlyerNumber"
                               style="margin-top: 5px;"
                               data-val-regex="The miles frequent flyer number entered is not valid.">
                        <span data-valmsg-replace="true" :data-valmsg-for="'Passengers[{0}].FrequentFlyerNumber'|stringFormat(passenger.passengerIndex)"></span>
                    </div>
                </div>
                <input type="hidden" :name="'AddonsDetails[{0}].Addons[{1}]'|stringFormat(passenger.addonIndex, index)" :value="addon" v-for="(addon, index) in parseAddonModel(passenger.passengerIndex)" />
                <input type="hidden" :name="'AddonsDetails[{0}].Seats[{1}]'|stringFormat(passenger.addonIndex, index)" :value="seat" v-for="(seat, index) in paxSeats" />
                <input type="hidden" :name="'AddonsDetails[{0}].PaxNo'|stringFormat(passenger.addonIndex)" :value="passenger.passengerIndex" />
            </div>
        </div>
    </div>
</template>
<script>
    import basePassenger from './basePassenger'
    export default {
        mixins: [basePassenger],
        props: ["packageQuery", "passenger", "hasFlight", "countries", "addOnSelecteds", "seatLegs"],
        data() {
            return {}
        },
        created() { },
        methods: {
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            }
        }
    }
</script>