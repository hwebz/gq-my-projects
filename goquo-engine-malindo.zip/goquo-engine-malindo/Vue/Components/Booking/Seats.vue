﻿<template>
    <div>
        <h4 class="text-uppercase title" v-lang.SEAT_SELECTION>Seat Selection</h4>
        <div class="row" v-if="seatLegs.length === 0">
            <div class="col-xs-12 col-lg-6">
                <div class="cus-panel cus-panel-default cus-panel-normal">
                    <div class="cus-panel-heading">
                        <div class="cus-panel-title">
                            <div class="load load25"></div>
                            <span class="cus-panel-titlepriceright" style="position: absolute;top: -12px;right: 0;">
                                {{packageQuery.currency}}
                                <span class="load-icon" style="top: 1px;">
                                    <span class="bounce1"></span>
                                    <span class="bounce2"></span>
                                    <span class="bounce3"></span>
                                </span>
                            </span>
                        </div>
                    </div>
                    <div class="cus-panel-body cus-panel-body-split" style="width: 100%;">
                        <div class="ss-paxdetails">
                            <div class="load load50" style="float: left;"></div>
                            <div class="ss-selectedseat">
                                <div class="ss-hideseat"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-lg-6">
                <div class="cus-panel cus-panel-default cus-panel-normal">
                    <div class="cus-panel-heading">
                        <div class="cus-panel-title">
                            <div class="load load25"></div>
                            <span class="cus-panel-titlepriceright" style="position: absolute;top: -12px;right: 0;">
                                {{packageQuery.currency}}
                                <span class="load-icon" style="top: 1px;">
                                    <span class="bounce1"></span>
                                    <span class="bounce2"></span>
                                    <span class="bounce3"></span>
                                </span>
                            </span>
                        </div>
                    </div>
                    <div class="cus-panel-body cus-panel-body-split" style="width: 100%;">
                        <div class="ss-paxdetails">
                            <div class="load load50" style="float: left;"></div>
                            <div class="ss-selectedseat">
                                <div class="ss-hideseat"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-lg-6" v-for="(leg, index) in seatLegs">
                <div>
                    <div class="cus-panel cus-panel-default cus-panel-normal cus-panel-seat">
                        <div class="cus-panel-heading p-default">
                            <div class="cus-panel-title">
                                {{leg.from}} - {{leg.to}}
                                <span class="cus-panel-titlepriceright">
                                    {{packageQuery.currency}}
                                    <span>{{getTotalSeatPriceByLeg(leg.from, leg.to)}}</span>
                                </span>
                                <span class="cus-panel-paxType">{{leg.departureDate | moment('ddd, DD MMM YYYY')}}</span>
                            </div>
                        </div>
                        <div class="cus-panel-body cus-panel-body-split cursor-pointer" data-toggle="modal" :data-target="'#seatselect-' + index">
                            <div class="ss-paxdetails" v-for="passenger in passengers" v-if="passenger.passengerType !== 'Infant'">
                                <label class="lb-nowrap">
                                    <span>{{passenger.title}}</span>.&nbsp;
                                    <span class="text-uppercase">{{passenger.firstName}}</span>&nbsp;
                                    <span class="text-uppercase">{{passenger.lastName}}</span>
                                </label>
                                <div class="ss-selectedseat" @click="setSelectedPassenger(passenger)">
                                    <div class="ss-showseat" v-if="getDesignatorByPax(leg.from, leg.to, passenger)">{{getDesignatorByPax(leg.from, leg.to, passenger)}}</div>
                                    <div class="ss-hideseat" v-if="!getDesignatorByPax(leg.from, leg.to, passenger)"></div>
                                </div>
                            </div>
                            <span class="bk-edit"><span class="bk-edit-click"><i class="icon icon-edit"></i> <span v-lang.EDIT_SEAT>Edit Seat</span></span></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Seats selection modal -->
        <SeatSelector v-for="(leg, index) in seatLegs" :key="index" :packageQuery="packageQuery" :leg="leg" :index="index" :passengers="passengers" :seatSelecteds="seatSelecteds" v-on:onAddonsChanged="calculateAddonsPrice" v-on:onSeatChanged="refreshUI" :selectedPassenger="selectedPassenger" :firstSelectedPass="firstSelectedPass"></SeatSelector>
    </div>
</template>

<script>
    import SeatSelector from './SeatSelector.vue'
    export default {
        components: { SeatSelector },
        props: ["packageQuery", "seatLegs", "passengers", "seatSelecteds"],
        data() {
            return {
                legActive: null,
                currentPax: 0,
                selectedPassenger: "",
                firstSelectedPass: false
            }
        },
        methods: {
            getTotalSeatPriceByLeg(from, to) {
                var total = 0;
                if (!this.seatSelecteds.length) {
                    return total;
                }

                $.each(this.seatSelecteds, function (i, object) {
                    if (object.from === from && object.to === to) {
                        total += object.feeAmount;
                    }
                });

                // To fixed number
                return parseFloat(total.toFixed(this.packageQuery.currencyDecimals));
            },
            getDesignatorByPax(from, to, passenger) {

                if (!this.seatSelecteds.length) {
                    return '';
                }

                if (!passenger.seats) {
                    return '';
                }

                var key = from + '-' + to;
                if (!passenger.seats[key]) {
                    return '';
                }

                return passenger.seats[key].designator;
            },
            calculateAddonsPrice(callback) {
                this.$emit("onAddonsChanged", callback);
            },
            setSelectedPassenger (passenger, event) {
                this.selectedPassenger = passenger.firstName + passenger.lastName;
                this.firstSelectedPass = true;
            },
            refreshUI() {
                this.$forceUpdate();
            }
        }
    }
</script>