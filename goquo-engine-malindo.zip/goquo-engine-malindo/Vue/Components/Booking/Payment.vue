﻿<template>
    <div>
        <div class="bk-title">
            <h4 class="bk-title-head"><span class="icon icon-payment"></span> <span v-lang.PAYMENT_DETAILS>Payment details</span></h4>
        </div>
        <div class="cus-panel cus-panel-default">
            <!--<div class="cus-panel-heading">
                <div class="cus-panel-title">
                    <span v-lang.CREDIT_DEBIT_CARD_DETAILS>Credit/Debit Card Details</span>
                    <span class="cus-panel-titlepriceright cc-head-image">
                        <span class="cc-images">
                            <img src="/images/visacard.png">
                            <img src="/images/mastercard.png">
                        </span>
                    </span>
                </div>
            </div>-->
            <div class="cus-panel-body">
                <div id="listPaymentMethods" v-show="paymentGateways.length > 0">
                    <div id="listPaymentMethods" class="hide">
                        <label class="radio-inline" v-for="(paymentGateway,index) in paymentGateways" v-if="!paymentGateway.curencies || paymentGateways.indexOf(packageQuery.currency)">
                            <input type="radio" :value="paymentGateway.id" name="PaymentGatewayId" v-bind:checked="setPaymentGetwayId(paymentCategory,paymentGateway.category)" autocomplete="off" tabindex="1" />
                            {{paymentGateway.displayName}}
                        </label>
                    </div>
                    <ul class="nav nav-tabs">
                        <li class="active" v-if="gateways.credit.length > 0"><a data-toggle="tab" href="#malindo-credit-card" v-on:click="choicePayment('credit card')" v-lang.CREDIT_CARD>Credit Card</a></li>
                        <li v-if="gateways.internetbanking.length > 0"><a data-toggle="tab" href="#malindo-over-the-internetbanking" v-on:click="choicePayment('internet banking')" v-lang.OVER_THE_INTERNET_BANKING>Internet Banking</a></li>
                        <li v-if="gateways.b2b.length > 0"><a data-toggle="tab" href="#malindo-b2b" v-on:click="choicePayment('on account')" v-lang.ON_ACCOUNT>On Account</a></li>
                    </ul>
                    <div class="tab-content">
                        <div id="malindo-credit-card" class="tab-pane fade in active row" v-if="gateways.credit.length > 0">
                            <div class="form-group col-xs-6 col-sm-4 col-md-3 hide" v-for="paymentGateway in gateways.credit" v-if="!paymentGateway.curencies || paymentGateways.indexOf(packageQuery.currency)">
                                <label class="radio-inline radio-box">
                                    <input type="radio" :value="paymentGateway.id" name="PaymentGatewayId" autocomplete="off" tabindex="1" checked />
                                </label>
                            </div>

                            <div id="paymentCardInfo hide">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label v-lang.NAME_ON_CARD>Name on the Card</label>
                                                    <input type="text" v-model="cardInfos.name" class="form-control text-uppercase" id="txtCreditCardName" maxlength="255" name="CreditCardName" data-val="true" :data-val-required="translateText('REQUIRED', 'Required')" :data-val-lettersonly="translateText('PLEASE_ENTER_LETTERS_ONLY', 'Please enter letters only.')" required="required" tabindex="1" autocomplete="cc-name" :data-val-regex="translateText('PLEASE_NOT_ALL_SPACES', 'Please not all space')" data-val-regex-pattern="(?!^ +$)^.+$" />
                                                    <span data-valmsg-replace="true" data-valmsg-for="CreditCardName"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-7">
                                                <div class="form-group c_num">
                                                    <label v-lang.CARD_NUMBER>Card Number</label>
                                                    <input type="tel" v-model="cardInfos.number" class="form-control cc-number" id="txtCreditCardNumber" maxlength="16" name="CreditCardNumber" data-num="true" data-val="true" :data-val-required="translateText('REQUIRED', 'Required')" required="required" tabindex="2" autocomplete="cc-number" data-rule-creditcard="true"  />
                                                    <i class="icon icon-visa visa cc-iconhide"></i>
                                                    <i class="icon icon-Expiry Datemastercard mastercard cc-iconhide"></i>
                                                    <span data-valmsg-replace="true" data-valmsg-for="CreditCardNumber"></span>
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="form-group cc-ccv">
                                                    <label v-lang.CVV>CVV</label>
                                                    <input type="tel" v-model="cardInfos.ccv" class="form-control c_cvv" id="txtCreditCardCvvCode" minlength="3" maxlength="3" name="CreditCardCvvCode" data-num="true" data-val="true" :data-val-required="translateText('REQUIRED', 'Required')" required="required" tabindex="3" autocomplete="cc-csc" v-on:keypress="inputOnlyNumberic"  />
                                                    <!-- <i class="icon icon-information c_cvvinfo left-pos"  v-tooltip="'Three-digit CVV number is printed on the signature panel on the back of the card'"></i> -->
                                                    <span data-valmsg-replace="true" data-valmsg-for="CreditCardCvvCode"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-xs-12">
                                                <div class="form-group expiry-date cc-datemonth">
                                                    <label v-lang.EXPIRY_DATE>Expiry Date</label>
                                                    <div class="form-fields clearfix">
                                                        <div class="form-group-date">
                                                            <div>
                                                                <select id="txtCreditCardExpireMonth" v-model="cardInfos.expire.month" name="CreditCardExpireMonth" class="form-control c_mon" data-val="true" :data-val-required="translateText('REQUIRED', 'Required')" tabindex="4" autocomplete="cc-month">
                                                                    <option :value="null" v-lang.MONTH>Month</option>
                                                                    <option value="1">01</option>
                                                                    <option value="2">02</option>
                                                                    <option value="3">03</option>
                                                                    <option value="4">04</option>
                                                                    <option value="5">05</option>
                                                                    <option value="6">06</option>
                                                                    <option value="7">07</option>
                                                                    <option value="8">08</option>
                                                                    <option value="9">09</option>
                                                                    <option value="10">10</option>
                                                                    <option value="11">11</option>
                                                                    <option value="12">12</option>
                                                                </select>
                                                                <span data-valmsg-replace="true" data-valmsg-for="CreditCardExpireMonth"></span>
                                                            </div>
                                                            <div>
                                                                <select id="txtCreditCardExpireYear" v-model="cardInfos.expire.year" name="CreditCardExpireYear" class="form-control c_year" data-val="true" :data-val-required="translateText('REQUIRED', 'Required')" tabindex="5" autocomplete="cc-year" data-rule-ccexp="true">
                                                                    <option :value="null" v-lang.YEAR>Year</option>
                                                                    <option v-for="year in years" :value="year">{{year}}</option>
                                                                </select>
                                                                <span data-valmsg-replace="true" data-valmsg-for="CreditCardExpireYear"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <input id="txtCreditCardExpire" name="CreditCardExpire" class="hide" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xs-12 cardholder" id="cardholder">
                                        <div class="card-wrap">
                                            <div class="card">
                                                <div class="front">
                                                    <div class="type">
                                                        <img class="bankid" />
                                                    </div>
                                                    <span class="chip"></span>
                                                    <span class="card_number">{{cardNumber}}</span>
                                                    <div class="date"><span class="date_value">{{cardExpireMonth}}/{{cardInfos.expire.year ? cardInfos.expire.year.toString().slice(2, 4): ''}}</span></div>
                                                    <span class="fullname">{{cardInfos.name == null ? cardInfos.name :cardInfos.name.toUpperCase()}}</span>
                                                </div>
                                                <div class="back">
                                                    <div class="magnetic"></div>
                                                    <div class="bar"></div>
                                                    <span class="seccode">&#x25CF;&#x25CF;&#x25CF;</span>
                                                    <span class="chip"></span><span class="disclaimer">This card is property of Random Bank of Random corporation. <br> If found please return to Random Bank of Random corporation - 21968 Paris, Verdi Street, 34 </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="malindo-over-the-internetbanking" class="tab-pane fade row" v-if="gateways.internetbanking.length > 0">
                            <div class="form-group col-xs-6 col-sm-4 col-md-3" v-for="paymentGateway in gateways.internetbanking" v-if="(!paymentGateway.curencies || paymentGateways.indexOf(packageQuery.currency))  && paymentCategory == 'internet banking'">
                                <label class="radio-inline radio-box">
                                    <input type="radio" :value="paymentGateway.id" name="PaymentGatewayId" autocomplete="off" tabindex="1" />
                                    <span></span>
                                    <span v-if="paymentGateway.urlImage"><img class="img-payment-ali" :src="paymentGateway.urlImage"></span>
                                    <span v-else="">{{paymentGateway.paymentName}}</span>
                                </label>
                            </div>
                        </div>
                        <div id="malindo-b2b" class="tab-pane fade row" v-if="gateways.b2b.length > 0">
                            <div v-for="(paymentGateway,index) in gateways.b2b" v-if="paymentGateway.displayName.toLowerCase() == 'on account'">
                                <label class="radio-inline">
                                    <input type="radio" v-if="index == 0" :value="balanceInfo" name="CreditBalanceInfo" checked="checked" autocomplete="off" />
                                    <input type="radio" v-else :value="paymentGateway.paymentName" name="CreditCardType" autocomplete="off" />
                                    <input type="hidden" :value="paymentGateway.id" name="PaymentGatewayId" autocomplete="off" tabindex="1" />
                                    <span v-lang.YOUR_CREADIT_LIMIT_IS>
                                            Your credit limit is
                                        </span>
                                        <span>{{balanceInfo}}</span>
                                    <br />
                                    <span v-lang.YOU_CAN_BOOK_ANY_BOOKINGS_THE_TOTAL_AMOUNT> You can book any bookings the total amount of which are lower than or equal to your credit limit.</span><br />
                                    <span v-lang.IF_THE_TOTAL_AMOUNT_IS_GREATER> If the total amount is greater than your credit limit, please top-up before booking.</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>
<script>
    export default {
        props: ["paymentGateways", "packageQuery"],
        data() {
            return {
                years: [],
                balanceInfo: "",
                paymentCategory: 'credit card',
                gateways: {
                    credit: [],
                    internetbanking: [],
                    b2b: [],
                },
                cardInfos: {
                    number: null,
                    name: null,
                    ccv: null,
                    expire: {
                        month: null,
                        year: null
                    }
                },
                firstLoad: true
            }
        },
        created() {
            var start = new Date().getFullYear();
            var end = start + 15;
            for (var i = start; i <= end; i++) {
                this.years.push(i);
            }

            var self = this;
            var currency = self.packageQuery.currency;

            $.ajax({
                type: "POST",
                url: "/booking/get-payment-options/" + currency,
                success: function (data) {
                    if (data && data.length > 0) {
                        self.balanceInfo = currency + " " + data[0].availabilityLimit;
                    }
                }
            });
        },
        computed: {
            cardNumber: function () {
                var cardNo = this.cardInfos.number ? this.cardInfos.number : '';
                return cardNo.slice(0, 4) + ' ' + cardNo.slice(4, 8) + ' ' + cardNo.slice(8, 12) + ' ' + cardNo.slice(12, 16);
            },
            cardExpireMonth: function () {
                var month = this.cardInfos.expire.month;
                return month ? (month < 10 ? '0' + month : month) : '';
            }
        },
        mounted() {
            for (var i = 0; i < this.paymentGateways.length; i++) {
                switch (this.paymentGateways[i].category.toLowerCase()) {
                    case 'credit card':
                        this.gateways.credit.push(this.paymentGateways[i]);
                        break;
                    case 'internet banking':
                        this.gateways.internetbanking.push(this.paymentGateways[i]);
                        break;
                    case 'b2b payment':
                        this.gateways.b2b.push(this.paymentGateways[i]);
                        break;
                }
            }
        },
        updated() {
            if (this.firstLoad) {

                //Geeting card type based on the cardnumber value
                var _cardNumber = $('.cc-number');
                var _mastercard = $('.mastercard');
                var _visa = $('.visa');
                var cardType;

                var self = this;
                var cards = [{
                    nome: "mastercard",
                    colore: "#0061A8",
                    src: "https://upload.wikimedia.org/wikipedia/commons/0/04/Mastercard-logo.png"
                }, {
                    nome: "visa",
                    colore: "#E2CB38",
                    src: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/2000px-Visa_Inc._logo.svg.png"
                }, {
                    nome: "dinersclub",
                    colore: "#888",
                    src: "http://www.worldsultimatetravels.com/wp-content/uploads/2016/07/Diners-Club-Logo-1920x512.png"
                }, {
                    nome: "americanExpress",
                    colore: "#108168",
                    src: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/American_Express_logo.svg/600px-American_Express_logo.svg.png"
                }, {
                    nome: "discover",
                    colore: "#86B8CF",
                    src: "https://lendedu.com/wp-content/uploads/2016/03/discover-it-for-students-credit-card.jpg"
                }, {
                    nome: "dankort",
                    colore: "#0061A8",
                    src: "https://upload.wikimedia.org/wikipedia/commons/5/51/Dankort_logo.png"
                }];
                var number = "";
                var html = document.getElementById("cardholder");
                var selected_card = -1;
                _cardNumber.keyup(function (event) {
                    $(".card_number").text($(this).val());
                    number = $(this).val();

                    if (parseInt(number.substring(0, 2)) > 50 && parseInt(number.substring(0, 2)) < 56) {
                        selected_card = 0;
                    } else if (parseInt(number.substring(0, 1)) == 4) {
                        selected_card = 1;
                    } else if (parseInt(number.substring(0, 2)) == 36 || parseInt(number.substring(0, 2)) == 38 || parseInt(number.substring(0, 2)) == 39) {
                        selected_card = 2;
                    } else if (parseInt(number.substring(0, 2)) == 34 || parseInt(number.substring(0, 2)) == 37) {
                        selected_card = 3;
                    } else if (parseInt(number.substring(0, 2)) == 65) {
                        selected_card = 4;
                    } else if (parseInt(number.substring(0, 4)) == 5019) {
                        selected_card = 5;
                    } else {
                        selected_card = -1;
                    }

                    if (selected_card != -1) {
                        html.setAttribute("style", "--card-color: " + cards[selected_card].colore);
                        $(".bankid").attr("src", cards[selected_card].src).show();
                    } else {
                        html.setAttribute("style", "--card-color: #cecece");
                        $(".bankid").attr("src", "").hide();
                    }

                    //if ($(".card_number").text().length === 0) {
                    //    $(".card_number").html("&#x25CF;&#x25CF;&#x25CF;&#x25CF; &#x25CF;&#x25CF;&#x25CF;&#x25CF; &#x25CF;&#x25CF;&#x25CF;&#x25CF; &#x25CF;&#x25CF;&#x25CF;&#x25CF;");
                    //}

                }).focus(function () {
                    $(".card_number").css("color", "white");
                }).on("keydown input", function () {

                    $(".card_number").text($(this).val());

                    if (event.key >= 0 && event.key <= 9) {
                        if ($(this).val().length === 4 || $(this).val().length === 9 || $(this).val().length === 14) {
                            $(this).val($(this).val());
                        }
                    }
                })
                $(".cc-ccv").click(function () {
                    $(".card").css("transform", "rotatey(180deg)");
                    $(".seccode").css("color", "white");
                }).keyup(function () {
                    $(".seccode").text($(".c_cvv").val());
                    if ($(".c_cvv").val().length === 0) {
                        $(".seccode").html("&#x25CF;&#x25CF;&#x25CF;");
                    }

                }).focusout(function () {
                    $(".card").css("transform", "rotatey(0deg)");
                    $(".seccode").css("color", "var(--text-color)");
                });
                _cardNumber.focusout(function () {
                    self.calcPromoPrice();
                });
                this.firstLoad = false;
            }
        },
        methods: {
            creditCardTypeFromNumber(num) {
                num = num.replace(/[^\d]/g, '');
                if (num.match(/^5\d{3}/)) {
                    return 'mastercard';
                } else if (num.match(/^4\d{3}/)) {
                    return 'visa';
                }
                return 'NULL';
            },
            calcPromoPrice() {
                var self = this;
                this.$emit("onCalcPromoPrice", function (priceSummry) { });
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            inputOnlyNumberic: function (event) {
                if ((event.which < 48 || event.which > 57)) {
                    event.preventDefault();
                }
            },
            inputOnlyCharacter: function (event) {
                if (!(event.which >= 65 && event.which <= 120) && (event.which != 32 && event.which != 0)) {
                    event.preventDefault();
                }
            },
            setPaymentGetwayId(paymentCategory, category) {
                if (paymentCategory == category.toLowerCase()) {
                    return true;
                }
                else {
                    return false;
                }
            },
            choicePayment(method) {
                this.paymentCategory = method;
            },
            formatCurrencyOnAccount(value) {
                return (parseFloat(value).toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            },
            inputOnlyNumberic: function (event) {
                if ((event.which < 48 || event.which > 57)) {
                    event.preventDefault();
                }
            },

            checkEquivalent(currencyConvert, b2bCurrency) {
                if (currencyConvert == b2bCurrency)
                    return true;
                else
                    return false;
            },
            displayB2b(currency, amount) {
                return currency + ' ' + amount;
            }
        }
    }
</script>