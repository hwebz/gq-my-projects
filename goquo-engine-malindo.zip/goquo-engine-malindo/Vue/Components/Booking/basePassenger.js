﻿export default {
    data() {
        return {
            days: [],
            months: [],
            years: [],
            daysOfExpiryDate: [],
            monthsOfExpiryDate: [],
            yearsOfExpiryDate: [],
            isCloneContactDetails: false,
            documentTypes: [
                {
                    key: "NATIONAL_ID_CARD",
                    name: "National ID Card"
                },
                {
                    key: "PASSPORT",
                    name: "Passport"
                },
                {
                    key: "IQUAMA_SAUDI",
                    name: "Iqama-Saudi Residence for Foreigners"
                }
            ],
            selectedDocumentType: "National ID Card",
            isShow: false,
            paxSeats: [],
            maxDays: 31,
            dayForLeap: 29,
            leapYears: [],
            leapYearsExpiry: [],
            daysBefore: [],
            monthsBefore: [],
            yearsBefore: [],
            monthsSpecial: [1, 3, 5, 7, 8, 10, 12],
            pax: {
                dayOfExpiry: "",
                monthOfExpiry: "",
                yearOfExpiry: ""
            },
            yearsExpiryBefore: []
        };
    },
    created() {
        var months = _.range(1, 13);
        var days = _.range(1, 32);
        this.months = months;
        this.days = days;
        this.monthsOfExpiryDate = months;
        this.daysOfExpiryDate = days;

        this.daysBefore = days;
        this.monthsBefore = months;

        // Year of Expiry Date
        var yearNow = new Date().getFullYear();
        var toDay = new Date();
        var yearsOfExpiryDate = (new Date(toDay.setFullYear(toDay.getFullYear() + 30))).getFullYear();
        for (yearNow; yearNow <= yearsOfExpiryDate; yearNow++) {
            if (this.detectLeapYear(yearNow)) {
                this.leapYearsExpiry.push(yearNow);
            }
            this.yearsOfExpiryDate.push(yearNow);
        }
        //Year of Birth
        var start = new Date(this.passenger.minBirthDate).getFullYear();
        var end = new Date(this.passenger.maxBirthDate).getFullYear();

        for (var i = start; i <= end; i++) {
            if (this.detectLeapYear(i)) {
                this.leapYears.push(i);
            }
            this.years.push(i);
        }

        this.years.reverse();
        this.leapYears.reverse();
        this.yearsBefore = this.years;
        this.yearsExpiryBefore = this.yearsOfExpiryDate;
    },
    methods: {
        parseAddonModel(paxNo) {
            var results = [];
            var addons = this.getSelectedAddonsByPax(paxNo);

            if (addons == undefined || addons.length === 0)
                return results;

            for (var i = 0; i < addons.length; i++) {
                results.push(addons[i].from + "/" + addons[i].to + "/" + addons[i].addonType + "/" + addons[i].code);
            }
            return results;
        },
        parseSeatModel() {
            var results = [];
            var seats = this.getSelectedSeatsByPax();
            for (var i = 0; i < seats.length; i++) {
                results.push(seats[i].from + "/" + seats[i].to + "/" + seats[i].designator);
            }
            return results;
        },
        getSelectedAddonsByPax(index) {
            var arr = [];
            var addons = this.addOnSelecteds.filter(function (x) { return x.paxNo === index });

            for (var j = 0; j < this.seatLegs.length; j++) {
                var pc = this.seatLegs[j].currentPriorityCheckin;
                if (pc && pc.enabled) {
                    if (index === 0) {
                        arr.push(pc);
                    } else {
                        var checkin = this.getPriorityCheckinByCode(this.legs[j], "XCK0");
                        if (checkin) {
                            arr.push(checkin);
                        }
                    }
                }
            }

            return addons;
        },
        getSelectedSeatsByPax() {
            if (!this.passenger.seats) return [];

            var seats = [];
            
            for (var legKey in this.passenger.seats) {
                if (this.passenger.seats.hasOwnProperty(legKey)) {
                    var s = this.passenger.seats[legKey];
                    if (typeof s === "object") {
                        if (s) {
                            seats.push(s);
                        }
                    }
                }
            }
            return seats;
        },
        getPriorityCheckinByCode(legs, code) {
            return legs.priorityCheckin.addonInfoList.find(function (x) { return x.code === code });
        },
            dateChange(day, month, year, typeDate, typeChange) {
            var self = this,
                isLeapYear,
                daysOfMonth,
                leapYears,
                yearsBefore;
            const str = "dateOfBirth";
            if (typeDate == str) {
                leapYears = this.leapYears;
                yearsBefore = this.yearsBefore;
            }
            else {
                leapYears = this.leapYearsExpiry;
                yearsBefore = this.yearsExpiryBefore;
            }
            if (parseInt(day) == 31) {
                if (typeDate == str) {
                    this.months = this.monthsSpecial;
                    this.years = yearsBefore;
                } else {
                    this.monthsOfExpiryDate = this.monthsSpecial;
                    this.yearsOfExpiryDate = yearsBefore;
                }
                return;
            }
            else {
                if (typeDate == str)
                    this.months = this.monthsBefore;
                else
                    this.monthsOfExpiryDate = this.monthsBefore;
            }

            if (parseInt(day) == 29 && parseInt(month) == 2) {
                if (typeDate == str) {
                    this.years = leapYears;
                    if (!this.years.includes(parseInt(this.passenger.yearOfBirth))) this.passenger.yearOfBirth = "";
                }
                else {
                    this.yearsOfExpiryDate = leapYears;
                    if (!this.yearsOfExpiryDate.includes(parseInt(this.pax.yearOfExpiry))) this.pax.yearOfExpiry = "";
                }
            } else {
                typeDate == str ? this.years = yearsBefore : this.yearsOfExpiryDate = yearsBefore;
            }           
            // Check leap year
            isLeapYear = self.detectLeapYear(parseInt(year));
            if (isLeapYear) {
                if (parseInt(month) == 2) {
                    if (typeChange != "day") {
                        if (typeDate == str) {
                            this.days = [];
                            this.passenger.dayOfBirth <= 29 ? this.passenger.dayOfBirth = self.passenger.dayOfBirth : this.passenger.dayOfBirth = "";
                        } else {
                            this.daysOfExpiryDate = [];
                            this.pax.dayOfExpiry <= 29 ? this.pax.dayOfExpiry = self.pax.dayOfExpiry : this.pax.dayOfExpiry = "";
                        }
                    }
                    daysOfMonth = this.dayForLeap;
                }
                else {
                    typeDate == str ? this.days = [] : this.daysOfExpiryDate = [];
                    if (!this.monthsSpecial.includes(parseInt(month)))
                        daysOfMonth = this.maxDays - 1;
                    else
                        daysOfMonth = this.maxDays;
                }
                if (daysOfMonth) {
                    let days = [];
                    for (let i = 1; i <= daysOfMonth; i++) {
                        days.push(i);
                    }
                    typeDate == str ? this.days = days : this.daysOfExpiryDate = days;
                }
            }
            else {
                if (this.monthsSpecial.includes(parseInt(month))) {
                    let days = [];
                    for (let k = 1; k <= this.maxDays; k++) {
                        days.push(k);
                    }
                    typeDate == str ? this.days = days : this.daysOfExpiryDate = days;
                }
                else {
                    let days = [];
                    if (month == "")
                        days = this.daysBefore;
                    else if (parseInt(day) == 29 && parseInt(month) == 2) {
                        if (typeDate == str)
                            this.passenger.dayOfBirth <= 29 ? this.passenger.dayOfBirth = self.passenger.dayOfBirth : this.passenger.dayOfBirth = "";
                        else this.pax.dayOfExpiry <= 29 ? this.pax.dayOfExpiry = self.pax.dayOfExpiry : this.pax.dayOfExpiry = "";
                        for (let j = 1; j <= this.maxDays - 2; j++) {
                            days.push(j);
                        }
                    }
                    else {
                        if (parseInt(month) == 2) {
                            for (let j = 1; j <= this.maxDays - 3; j++) {
                                days.push(j);
                            }
                        }
                        else {
                            for (let j = 1; j <= this.maxDays - 1; j++) {
                                days.push(j);
                            }
                        }
                    }
                    typeDate == str ? this.days = days : this.daysOfExpiryDate = days;
                }
            }
        },
        detectLeapYear(year) {
            return (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0));
        }
    },
    watch: {
        "passenger.seats": function() {
            this.paxSeats = this.parseSeatModel();
        }
    }
};