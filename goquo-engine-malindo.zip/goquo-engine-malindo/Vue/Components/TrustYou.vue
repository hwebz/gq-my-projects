﻿<template>
    <div v-if="trustyou && trustyou.score > 0">
        <div class="hi-ty-panel" id="trustYouReview">
            <div class="row custom hi-ty-panel-header">
                <div class="col-md-6 col-xs-4"><h3 v-lang.REVIEWS>Reviews</h3></div>
                <div class="col-md-6 col-xs-8 text-right">
                    <img src="/images/verified-reviews-large.png" style="width: auto;height: 25px;" />
                </div>
            </div>

            <div class="hi-review-summary " v-bind:class="'review review_' + trustyou.score_description">
                <div class="review-rating-circle">
                    <div class="progress-pie-chart" v-bind:class="[trustyou.score >= 50 ? 'gt-50' : '', trustyou.score]">
                        <div class="ppc-progress">
                            <div class="ppc-progress-fill" :style="{transform: 'rotate(' + transform + ' deg)'}"></div>
                        </div>
                        <div class="ppc-percents">
                            <span>{{numberRoundRate(trustyou.score_display,1)}}</span>
                        </div>
                    </div>
                </div>
                <div class="review-desc">
                    {{trustyou.score_description}}
                    <small v-lang.BASED_ON_X_REVIEWS="{0: trustyou.reviews_count.toLocaleString()}"></small>
                </div>

                <div class="hi-ty-badges" v-if="trustyou.badge_list.length">
                    <!--badge in trustyou.badge_list | orderBy: '-popularity' |  limitTo: 3sortBadgeList-->
                    <div class="hi-ty-badge" v-for="(badge , badgeIndex) in sortBadgeList"
                         ng-repeat="">
                        <div class="hi-ty-badge-icon" v-bind:class="{ 'top-pick' : badgeIndex == 0 }"></div>
                        <span class="badge-name">
                            {{badge.text}} <br />
                            <small>{{badge.subtext}}</small>
                        </span>
                    </div>
                </div>
            </div>

            <nav class="navbar navbar-default hi-ty-navbar">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#review-type" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <span class="navbar-brand visible-xs" v-lang.REVIEW_TYPE>Review Type</span>
                </div>

                <div class="collapse navbar-collapse" id="review-type">
                    <ul class="nav nav-pills nav-justified">
                        <li v-for="(reviewCategory, index) in trustyou.category_items"
                            v-bind:class="{'active' : index == 0 }"
                            v-if="reviewCategory.reviews_percent > 0">
                            <a :href="'#' + reviewCategory.category_name" :aria-controls="reviewCategory.category_name" data-toggle="tab">
                                {{reviewCategory.category_name}} ({{reviewCategory.reviews_percent}}%)
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <div class="tab-content clearfix">
                <div role="tabpanel" class="tab-pane fade"
                     v-for="(reviewContent, reviewContentIndex) in trustyou.category_items"
                     v-bind:class="{ 'active in' : reviewContentIndex == 0}" :id="reviewContent.category_name"
                     v-if="reviewContent.reviews_percent > 0">
                    <div class="row ">
                        <div class="col-md-12 col-xs-12">
                            <p class="text-center hi-ty-summary-text" v-if="trustyou.summary.text">"{{trustyou.summary.text}}"</p>
                        </div>
                    </div>

                    <div class="row custom" v-for="(categoryItem, categoryItemIndex) in reviewContent.category_list">
                        <div class="col-md-4 col-xs-12 hi-ty-process-bar">
                            <label :for="categoryItem.category_name">{{categoryItem.category_name}}</label>
                            <div class="bar review" v-bind:class="{'review_Excellent' : categoryItem.score >= 75, 'review_Very Good' : (categoryItem.score <= 75 && categoryItem.score >= 60), 'review_Good' : (categoryItem.score <= 59 && categoryItem.score >= 50), 'review_Fair' : (categoryItem.score <= 49 && categoryItem.score >= 35), 'review_Poor' : categoryItem.score < 35, 'off' : reviewContentIndex > 0}">
                                <div class="bar-meter" :style="{ width: categoryItem.score + '%' }"></div>
                            </div>
                        </div>
                        <div class="col-md-8 col-xs-12 review-summary">
                            <div class="hi-summary-sentences">
                                <span class="hi-summary-sentence" v-for="(sentence, sentenceIndex) in categoryItem.summary_sentence_list">
                                    {{sentence}}
                                </span>
                            </div>
                            <a v-if="categoryItem.highlight_list.length" data-toggle="collapse" aria-expanded="false"
                               :aria-controls="'highlights' + reviewContentIndex + categoryItemIndex"
                               :href="'#highlights' + reviewContentIndex + categoryItemIndex" class="review-expand collapsed"></a>
                            <ul :id="'highlights' + reviewContentIndex + categoryItemIndex" class="collapse hi-summary-sentences_highlight">
                                <li v-for="highlight in  categoryItem.highlight_list">"{{highlight}}"</li>
                            </ul>
                        </div>
                    </div>

                    <div class="hi-good-to-know" v-if="reviewContent.good_to_know_list.length">
                        <span class="hi-info-header" v-lang.GOOD_TO_KNOW>Good to know</span>
                        <ul class="hi-good-to-know-list">
                            <li v-for="goodToKnow in reviewContent.good_to_know_list">

                                <i v-if="goodToKnow.sentiment == 'neg'" class="icon icon-cross"></i>
                                <i v-if="goodToKnow.sentiment != 'neg'" class="icon icon-check-mark"></i>

                                {{goodToKnow.text}}
                                <div class="sub-text">
                                    <span v-for="highlights in goodToKnow.highlight_list">{{highlights}}. </span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
            };
        },
        computed: {
            transform() {
                return 360 * this.trustyou.score / 100;
            },
            sortBadgeList() {
                return this.trustyou.badge_list.sort(function (a, b) {
                    return b.popularity - a.popularity
                }).slice(0, 3);
            },
        },
        props: ['trustyou'],
        methods: {
            numberRoundRate: function (value, roundNumber) {
                return (Math.round(value * 10) / 10).toFixed(roundNumber);
            }
        }
    }
</script>