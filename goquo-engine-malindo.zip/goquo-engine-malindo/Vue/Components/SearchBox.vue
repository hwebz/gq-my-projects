<template>

    <div class="bg-front bg-front-mob-rel">
        <div class="container">
            <div class="search-tabs search-tabs-bg search-tabs-abs-bottom" style="z-index: 10">
                <h2 class="tab-text">
                    Book Flight + Hotel and <span>Save up to 31%</span>
                </h2>

                <div class="tabbable">
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" :class="index == 0?'active':''" v-for="(product, index) in products">
                            <a :href="'#product_' + product.id" role="tab" data-toggle="tab">
                                <i :class="product.iconCssClass" v-if="product.iconCssClass != null && product.iconCssClass.length > 0"></i>
                                <span>{{translateText(product.type.toUpperCase(), product.name)}}</span>
                            </a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane booking-tabs fade" :class="index == 0 ? 'in active':''" :id="'product_' + product.id" v-for="(product, index) in products">
                            <div v-if="product.type == 'Flight_Hotel'">
                                <FlightHotelSearchBox :product="product"></FlightHotelSearchBox>
                            </div>
                            <div v-if="product.type == 'Flight'">
                                <!--<flight-search-box></flight-search-box>-->
                            </div>
                            <div v-if="product.type == 'Hotel'">
                                <HotelSearchBox :product="product"></HotelSearchBox>
                            </div>
                            <div v-if="product.type == 'Tour'">
                                <TourSearchBox :product="product"></TourSearchBox>
                            </div>
                            <div v-if="product.type == 'Transfer'">
                                <TransferSearchBox :product="product" :hotelInfo="hotelInfo"></TransferSearchBox>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    import FlightHotelSearchBox from './FlightHotelSearchBox.vue'
    import HotelSearchBox from './HotelSearchBox.vue'
    import TourSearchBox from './TourSearchBox.vue'
    import TransferSearchBox from './TransferSearchBox.vue'

    export default {
        name: "SearchBox",
        data() {
            return {
                products: [],
                hotelInfo: [],
                packageQuery: null,
            };
        },
        created() {
            var self = this;
            $.post('/package/work-context', function (data) {
                self.$store.commit('setWorkContext', data);
                self.products = data.products;
            });
        },
        methods: {
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            }
        },
        components: { FlightHotelSearchBox, HotelSearchBox, TourSearchBox, TransferSearchBox }
    }
</script>
