<template>
    <form method="GET" action="/package/start-search" class="hotel-search" data-val="true">
        <table class="table-layout-search">
            <tbody>
                <tr>
                    <td colspan="2">
                        <div class="form-group form-group-icon-left">
                            <i class="icon input-icon icon-location-arrow"></i>
                            <label v-lang.WHERE_ARE_YOU_GOING>Where are you going?</label>
                            <ajax-typeahead :placeholder="'Choose a destination, property name or address...'" 
                                            :url="'/api/search-regions'"></ajax-typeahead>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="width-140">
                        <div class="form-group form-group-icon-left">
                            <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                            <label v-lang.CHECK_IN>Check in</label>
                            <date-picker name="DepartureDate" v-model="DepartureDate" :defaultValue="DepartureDate"></date-picker>
                        </div>
                    </td>
                    <td class="width-140">
                        <div class="form-group form-group-icon-left">
                            <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                            <label v-lang.CHECK_OUT>Check out</label>
                            <date-picker name="ReturnDate" :startDate="DepartureDate" :defaultValue="ReturnDate" addOneDay="true" autoFocus="true"></date-picker>
                        </div>
                    </td>
                    <td class="width-140">
                        <div class="form-group form-group-icon-left">
                            <i class="icon icon-user input-icon input-icon-highlight"></i>
                            <label v-lang.PAX_INFO>Pax Info</label>
                            <pax-selector :maxRooms="3"></pax-selector>
                        </div>
                    </td>
                    <td class="submit-column">
                        <input type="hidden" name="ProductId" :value="product.id" />
                        <input type="hidden" name="cultureCode" :value="cultureCode" />
                        <button id="searchForm" type="submit" class="btn btn-primary btn-block search-button">
                            <span v-lang.SEARCH_FOR_HOTELS>Search for Hotels</span>
                        </button>
                    </td>
                </tr>
            </tbody>
        </table>
        <div class="clearfix"></div>
    </form>
</template>

<script>
    import Vue from 'vue'
    import {AjaxSelect, AjaxTypeahead, DatePicker} from 'goquo-components'
    import PaxSelector from './PaxSelector.vue'
    export default {
        data() {
            return {
                DepartureDate: Vue.moment().add(1, 'day'),
                maxRooms: 3,
            }
        },
        computed: {
            ReturnDate() {
                return Vue.moment(this.DepartureDate).add(1, 'day');
            },
            cultureCode() {
                return $("#hdfCultureCode").val();
            }
        },
        created() {
            var self = this;
        },
        methods: {

        },
        props: ['product'],
        components: {
            'ajax-select': AjaxSelect,
            'date-picker': DatePicker,
            'pax-selector': PaxSelector,
            'ajax-typeahead': AjaxTypeahead,
        }
    }

</script>
