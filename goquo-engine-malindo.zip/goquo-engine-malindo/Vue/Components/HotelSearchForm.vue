<template>
    <form method="GET" action="/package/start-search" id="fHotelSearch" data-val="true" style="border: none">
        <div>
            <input type="hidden" name="PromoCode" :value="promoCode" />
            <div v-if="hotelDetail" class="col-xs-12">
                <div class="form-group">
                    <div>
                        <label v-lang.DESTINATION>Destination</label>
                    </div>
                    <span>{{hotelDetail.name}}</span>
                </div>
            </div>
            <div v-else class="col-xs-12">
                <div class="form-group right-icon">
                    <i class="icon icon-location-arrow input-icon"></i>
                    <label v-lang.WHERE_ARE_YOU_GOING>Where are you going?</label>
                    <AjaxTypeahead :url="'/api/search-regions'" :value="model.toFullText" :cityCode="model.to" :regionId="model.regionId" :hotelCode="model.hotelCode"></AjaxTypeahead>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6">
                <div class="form-group right-icon">
                    <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                    <label v-lang.CHECK_IN>Check-in</label>
                    <DatePicker name="DepartureDate" v-model="model.departureDate" :defaultValue="DepartureDate"></DatePicker>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6">
                <div class="form-group right-icon">
                    <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                    <label v-lang.CHECK_OUT>Check-out</label>
                    <DatePicker name="ReturnDate" v-model="model.returnDate" :startDate="model.departureDate" :defaultValue="ReturnDate" addOneDay="true"></DatePicker>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 two-fields">
                <div class="form-group right-icon">
                    <i class="icon icon-user input-icon input-icon-highlight"></i>
                    <label v-lang.ROOMS_PASSENGERS>Rooms and Passengers</label>
                    <PaxSelector :maxRooms="3"></PaxSelector>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 btn-modify">
                <input type="hidden" name="ProductId" :value="product.id" />
                <button type="submit" class="btn btn-primary btn-block mt-search search-button" v-lang.SEARCH_HOTEL>Search for Hotel</button>
            </div>
        </div>
    </form>
</template>
<script>
    import Vue from 'vue'
    import { AjaxTypeahead, DatePicker } from 'goquo-components'
    import PaxSelector from './PaxSelector.vue'
    export default {
        components: { DatePicker, PaxSelector, AjaxTypeahead },
        props: ['model', 'packageQuery', 'product', 'hotelDetail'],
        data() {
            return {
                promoCode: null,
                DepartureDate: Vue.moment(),
            }
        },
        computed: {
            ReturnDate() {
                return Vue.moment(this.DepartureDate).add(1, 'day');
            },
            depatureDisableDateUrl() {
                if (!this.packageQuery) {
                    return null;
                }
                return "/package/get-disabled-dates?from=" + this.model.from + "&to=" + this.model.to;
            },
            returnDisableDateUrl() {
                if (!this.packageQuery) {
                    return null;
                }
                return "/package/get-disabled-dates?from=" + this.model.to + "&to=" + this.model.from;
            }
        },
        created() {
            var self = this;
            if (self.packageQuery) {
                self.promoCode = self.packageQuery.promoCode;
            } else if (self.model.promoCode) {
                self.promoCode = self.model.promoCode;
            }
        },
        methods: {

        }
    }
</script>