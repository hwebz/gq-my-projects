<template>
    <div>
        <div class="global-discount" v-if="packageQuery.promoCode && packageQuery.priceSummary.promoTitle">
            <div class="global-discount__left">
                <span class="icon-discount"></span>
            </div>
            <div class="global-discount__right">
                <p v-lang.COUPON_APPLIED_X="{0: packageQuery.promoCode}" class="desktop"></p>
                <p v-lang.COUPON="{0: packageQuery.promoCode}" class="mobile"></p>
                <p v-lang.DISCOUNT_OFF="{0: packageQuery.priceSummary.promoTitle}"></p>
            </div>
        </div>
        <div class="result-list clearfix" v-if="!showMapView" id="hotelSection">
            <div v-for="(hotel, index) in hotelStore.hotels" :class="{'search-load': !loading.hotelResult}">
                <div class="result-item hotel-result">
                    <div class="result-content result-left">
                        <!--<div v-if="hotel.imageInfos.length > 0"-->
                        <!--:title="hotel.name" :style="{backgroundImage: `url('${replaceImage(hotel.imageInfos[0].url)}')`}"-->
                        <!--class="result-img">-->
                        <!--</div>-->
                        <SlickSlider sliderClass="hotel-slick-slider" :item="hotel.imageInfos" :itemIndex="index" isReplaceImage="true"></SlickSlider>
                        <div class="right-left wrap" v-if="hotel.priorityMessage1">
                            <span class="result-trendy-message">{{hotel.priorityMessage1}}</span>
                            <span class="result-trendy-message" v-if="hotel.priorityMessage2">{{hotel.priorityMessage2}}</span>
                            <span class="result-trendy-message" v-if="hotel.priorityMessage3">{{hotel.priorityMessage3}}</span>
                        </div>
                    </div>
                    <div class="result-content result-right" @click="gotoHotelInfoPage(hotel.url)">
                        <!--Adding total price end-->
                        <div class="save-price ribbon ribbon-right" v-if="getEmphasisedDiscount(hotel) > 0 && isHotelHasSpecialOffers(hotel) && ((packageQuery.from && flightStore.outboundFlight) || !packageQuery.from)">
                            <span>SAVE</span> {{packageQuery.currency}} <span class="price-emphasised">{{getEmphasisedDiscount(hotel)}}</span>
                        </div>
                        <div class="result-include">
                            <del v-if="getCrossOutPrice(hotel) > getSellingPrice(hotel) && hotel.cheapestPrice > 0">{{packageQuery.currency}} {{getCrossOutPrice(hotel) | formatCurrency}}</del>
                            <div class="result-price mb20" v-if="!(hotel.cheapestPrice > 0) || isNaN(getSellingPrice(hotel))">
                                <span class="load-icon">
                                    <span class="bounce1"></span>
                                    <span class="bounce2"></span>
                                    <span class="bounce3"></span>
                                </span>
                            </div>
                            <div class="result-price" v-else>
                                <span v-if="hotel.cheapestPrice > 0"><strong><span v-if="!isNaN(getSellingPrice(hotel))">{{packageQuery.currency}}</span> <span>{{getSellingPrice(hotel) | formatCurrency}}</span> </strong></span>
                                <span v-if="isSearchCompleted && hotel.cheapestPrice == 0" class="sold-out" v-lang.SOLD_OUT> SOLD OUT</span>

                                <span v-show="!(isSearchCompleted && hotel.cheapestPrice == 0)">
                                    <small class="text-right" v-if="product.displayPrice == 0" v-lang.PER_NIGHT="">per night</small>
                                    <small class="text-right" v-if="product.displayPrice == 1" v-lang.PER_PERSON="">per person</small>
                                    <small class="text-right" v-if="product.displayPrice == 2" v-lang.PER_ROOM="">per room</small>
                                </span>
                            </div>
                            <!--special discount start-->
                            <!--<div v-if="getSpecialOfferPrice(hotel, false) > 0 && ((packageQuery.from && flightStore.outboundFlight) || !packageQuery.from)">
                                <div class="result-discount-price">
                                    <strong>{{packageQuery.currency}} {{getSpecialOfferPrice(hotel, false)}}</strong>
                                    <span v-if="packageQuery.from" v-lang.PACKAGE_DISCOUNT>package discount</span>
                                    <span v-if="!packageQuery.from" v-lang.HOTEL_DISCOUNT>hotel discount</span>
                                </div>
                            </div>-->
                            <!--special discount end-->
                            <div class="price-inclusive" v-show="!(isSearchCompleted && hotel.cheapestPrice == 0)">
                                <span v-if="packageQuery.from" v-lang.INCLUDES_FLIGHT_HOTEL_TAXES="">includes flight, hotel & taxes</span>
                                <!--<span v-if="!packageQuery.from" v-lang.INCLUDES_TAXES_FEES="">includes taxes & fees</span>-->
                            </div>
                        </div>
                        <!--Adding total price-->
                        <div v-if="(calculatePaxCount() > 1 || calculateNights() > 1)">
                            <div class="result-total-price" v-if="totalPackagePriceValue(hotel) > 0">
                                <span v-if="product.displayPrice == 0">
                                    <span class="icon-night"></span>
                                    <span>x{{calculateNights()}}</span>
                                </span>
                                <span v-if="product.displayPrice == 1">
                                    <span class="icon-person"></span>
                                    <span>x{{calculatePaxCount()}}</span>
                                </span>
                                <strong v-if="totalPackagePriceValue(hotel) && totalPackagePriceValue(hotel) > 0">{{packageQuery.currency}} {{totalPackagePriceValue(hotel) | numberRounder(packageQuery.currencyDecimals)}}</strong>
                            </div>
                        </div>

                        <div class="result-view" v-show="!(isSearchCompleted && hotel.cheapestPrice == 0)">
                            <span class="btn btn-default" role="button" v-lang.CHOOSE_A_ROOM> Choose a room </span>
                        </div>
                    </div>
                    <div class="result-content result-center" @click="gotoHotelInfoPage(hotel.url)">
                        <div class="result-center-hotelinfo">
                            <!--Hotel Name-->
                            <h4>{{hotel.name}}</h4>
                            <!--Hotel Address-->
                            <p class="result-address" v-if="hotel.longitude && hotel.latitude && hotel.longitude != hotel.latitude">
                                <a @click="showHotelMapView(hotel, $event)">
                                    <i class="icon icon-maps" v-tooltip="'Map View'"></i>
                                    {{hotel.addressLines}}
                                </a>
                            </p>
                            <!--Hotel Star rating-->
                            <StarRating :rating="hotel.stars"></StarRating>
                            <!--Hotel reviews-->
                            <div class="review" v-if="!loading.hotelReview && !hotel.trustyou">
                                <div class="load"></div>
                            </div>
                            <div v-if="loading.hotelReview && hotel.trustyou" :class="'review review_' + hotel.trustyou.score_description">
                                <span class="review-score">{{hotel.trustyou.score_display | numberRoundRate(1)}}</span>
                                <p>
                                    <span>{{hotel.trustyou.score_description}}</span>
                                    <small>{{hotel.trustyou.reviews_count.toLocaleString()}}&nbsp;<small v-lang.X_REVIEWS>reviews</small></small>
                                </p>
                            </div>
                            <!-- Temp disable special offer -->
                            <!--p class="result-room-deal" v-if="hotel.specialOffers && hotel.specialOffers.length > 0 && hotel.specialOffers[0].specialOfferName != null">
                                <span class="icon icon-like"></span> {{hotel.specialOffers[0].specialOfferName}}
                            </p-->
                            <!--Facilities restricted to FREE WIFI/FREE INTERNET-->
                            <p class="result-features" v-if="isFreeWifi(hotel)">
                                <span class="tag special-tag"><span>Free</span><span>wifi</span></span>
                            </p>
                        </div>
                        <div class="result-center-packageinfo">
                            <!--Before flight info load-->
                            <div class="flight-info" v-if="!flightStore.outboundFlight && product.products[0].productType === 1">
                                <div class="load"></div>
                                <div class="load"></div>
                            </div>
                            <!--Package flight info-->
                            <div class="flight-info" v-else>
                                <p v-if="flightStore.outboundFlight">
                                    <i class="icon icon-flight"></i>
                                    <span class="result-center-packageinfo_flight">
                                        <span>{{flightStore.outboundFlight.legs[0].departureCityName}}</span> {{flightStore.outboundFlight.legs[0].departureAirportCode}} -
                                        <span>{{flightStore.outboundFlight.legs[flightStore.outboundFlight.stops].arrivalCityName}}</span> {{flightStore.outboundFlight.legs[flightStore.outboundFlight.stops].arrivalAirportCode}}
                                        <small v-if="flightStore.inboundFlight" v-lang.ROUND_TRIP>Round Trip</small>
                                        <small v-if="!flightStore.inboundFlight" v-lang.ONEWAY_TRIP>Oneway trip</small>
                                    </span>
                                </p>
                                <!--Package hotel info-->
                                <p>
                                    <i class="icon icon-hotel"></i>
                                    <span>{{getRoomTypeName(hotel, 0)}}</span>
                                </p>
                                <!--Package baggage info-->
                                <!--<p v-if="flightStore.outboundFlight && isTranslationAvailable('FREE_BAGGAGE_DETAILS')">
                                    <i class="icon icon-baggage"></i>
                                    <span class="luggage" v-lang.FREE_BAGGAGE_DETAILS="{0: airTypeOutBound}"></span>
                                </p>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row" v-if="!showMapView">
            <div class="col-xs-12">
                <nav aria-label="pagination">
                    <ul class="pager">
                        <li class="previous scroll-target" data-target="#hotelSection">
                            <a href="javascript:void(0)" v-bind:class="{'disabled': hotelStore.currentPage === 1}" @click="(hotelStore.currentPage === 1) || gotoHotelsPage(hotelStore.currentPage - 1)">
                                <i class="icon icon-left-arrow"></i>
                            </a>
                        </li>
                        <li class="text-center">
                            <p>
                                <strong v-lang.PAGE_X_OF_X="{0: hotelStore.currentPage, 1: hotelStore.totalPages}"></strong>
                                <span :class="{'is-visible': hotelStore.currentPage > 2}" @click="gotoHotelsPage(1)" v-lang.GO_TO_FIRST_PAGE> Go to first page </span>
                            </p>
                        </li>
                        <li class="next scroll-target" data-target="#hotelSection">
                            <a href="javascript:void(0)" v-bind:class="{'disabled': hotelStore.currentPage === hotelStore.totalPages}" @click="(hotelStore.currentPage === hotelStore.totalPages) || gotoHotelsPage(hotelStore.currentPage + 1)">
                                <i class="icon icon-right-arrow"></i>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <div id="snackbar" ref="snackbar">
            <span v-lang.COUPON_APPLIED_X="{0: packageQuery.promoCode}"></span>
        </div>
    </div>
</template>
<script>
   import {StarRating} from 'goquo-components'
    import SlickSlider from './SlickSlider.vue';

    export default {
        props: ["packageQuery", "flightStore", "hotelStore", "loading", "enabledFlights", "showMapView"],
        components: {StarRating,SlickSlider },
        data() {
            return {
                showMapFull: false,
                isSnackbar: true
            };
        },
        computed: {
            isSearchCompleted() {
                return this.loading.isSearchCompleted;
            },
            product() {
                return this.$store.state.workContext.product;
            },
            airTypeOutBound(){
                let self=this;

                 let fareType = {
                    "super saver": 0,
                    value: 1,
                    flexi: 2,
                    shuttle: 3,
                    business: 4
                }

                 _.map(this.flightStore.outboundFlight.legs, function(item){item.order=fareType[item.cabinClass.toLowerCase()]; return item });
                _.map(this.flightStore.inboundFlight.legs, function(item){item.order=fareType[item.cabinClass.toLowerCase()]; return item });
              
                let legoutbound = _.reduce(this.flightStore.outboundFlight.legs, function(a,b){
                    return a.order<b.order?a:b;
                })
                let leginbound = _.reduce(this.flightStore.inboundFlight.legs, function(a,b){
                    return a.order<b.order?a:b;
                })

                let upto = self.translate(this.$language, "FLIGHT_BAGGAGE_UPTO") || "up to";
                if(legoutbound.order != leginbound.order){
                    upto = self.translate(this.$language, "FLIGHT_BAGGAGE_FROM") || "from";
                }

                let typeClass = legoutbound.cabinClass;
                let airType = legoutbound.airType; 
                if(leginbound.order <legoutbound.order ){
                    typeClass = leginbound.cabinClass;
                    airType = leginbound.airType; 
                }          

                // if(airType=="ATR"){
                //     return upto + ' ' + 15;
                // }

                if(typeClass){
                    typeClass = typeClass.toLowerCase();
                }

                if(self.packageQuery.from =="DAC"|| self.packageQuery.to == "DAC"){
                    if(typeClass=='value' || typeClass== 'flexi' ){
                        return upto + ' ' + 35;
                    }
                    else if(typeClass == 'business'){
                        return upto + ' ' + 40;
                    }
                }

                switch(typeClass){
                    case 'super saver': return 0;
                    case 'value':
                        return upto + ' ' + 15;
                    case 'flexi':
                        return upto + ' ' + 30;
                    case 'business':
                        return upto + ' ' + 40;
                }
            }
        },
        updated() {
            this.showsnackbar()
        },
        methods: {
            //Show snackbar if the query string has promoCode key
            showsnackbar() {
                if (this.isSnackbar) {
                    if (this.packageQuery.promoCode && this.packageQuery.priceSummary.promoTitle) {
                        this.isSnackbar = false;
                        var x = document.getElementById("snackbar");
                        x.className = "show";
                        setTimeout(function () { x.className = x.className.replace("show", ""); }, 6000);
                    }
                }
            },
            getSpecialOfferPrice(hotel, isDividePrice) {
                //isDividePrice true, specialoffer will be divided by number of pax or person depends on the product
                var specialOfferPrice = 0;
                var paxCount = this.calculatePaxCount();
                var nightCount = this.calculateNights();
                var displayPrice = this.$store.state.workContext.product.displayPrice;
                var availableRooms = hotel.availableRooms;
                if (!availableRooms) {
                    return 0;
                }

                for (var j = 0; j < availableRooms.length; j++) {

                    //Special offer
                    specialOfferPrice += this.getTotalSpecialOffersPerRoom(this.getSpecialOffers(hotel, j));

                    //Hotel promo price
                    for (var k = 0; k < availableRooms[j].availableRoomTypes.length; k++) {
                        var availableRoomType = availableRooms[j].availableRoomTypes[k];
                        if (availableRoomType.selected) {
                            specialOfferPrice += availableRoomType.promoPrice;
                            break;
                        }
                    }
                }

                //OutboundFlight promo price
                if (this.flightStore.outboundFlight) {
                    specialOfferPrice += this.flightStore.outboundFlight.promoPrice;
                }

                //InboundFlight promo price
                if (this.flightStore.inboundFlight) {
                    specialOfferPrice += this.flightStore.inboundFlight.promoPrice;
                }
                if (isDividePrice) {

                    //price per night
                    if (displayPrice === 0) {
                        return parseFloat(specialOfferPrice / nightCount);
                    }
                    //price per person
                    if (displayPrice === 1) {
                        return parseFloat(specialOfferPrice / paxCount);
                    }
                    //Price per room
                    if (displayPrice === 2) {
                        var roomPrice = specialOfferPrice / this.packageQuery.paxInfos.length;
                        return parseFloat(specialOfferPrice / roomPrice);
                    }
                }
                return parseFloat(specialOfferPrice);
            },
            getSpecialOffers(hotel, index) {
                for (var j = 0; j < hotel.availableRooms[index].availableRoomTypes.length; j++) {
                    var availableRoomType = hotel.availableRooms[index].availableRoomTypes[j];
                    if (availableRoomType.selected) {
                        return availableRoomType.specialOffers;
                    }
                }
                return null;
            },
            isHotelHasSpecialOffers(hotel) {
                var result = false;
                var self = this;
                var specialOfferPrice = 0;
                for (var j = 0; j < hotel.availableRooms.length; j++) {
                    specialOfferPrice += self.getTotalSpecialOffersPerRoom(self.getSpecialOffers(hotel, j));
                }
                if (parseFloat(specialOfferPrice) > 0) {
                    result = true;
                }
                return result;
            },
            // add all the special offers in a room
            getTotalSpecialOffersPerRoom(roomTypeSpecialOffer) {
                if (!roomTypeSpecialOffer) {
                    return 0;
                }

                var totalSpecialOfferPrice = 0;
                for (var k = 0; k < roomTypeSpecialOffer.length; k++) {
                    totalSpecialOfferPrice += roomTypeSpecialOffer[k].amount;  //gets special offer object for the first room type
                }
                return parseFloat(totalSpecialOfferPrice);
            },
            getEmphasisedDiscount(hotel) {
                var crossPrice = parseFloat(this.getCrossOutPrice(hotel));
                var sellingPrice = parseFloat(this.getSellingPrice(hotel));
                return parseFloat(crossPrice - sellingPrice).toFixed(this.packageQuery.currencyDecimals);
            },
            getCrossOutPrice(hotel) {
                var self = this;
                var crossOutPrice = 0;
                var displayPrice = self.$store.state.workContext.product.displayPrice;
                var packagePrice = self.totalPackagePriceValue(hotel);
                var flightHotelDiscount = self.getSpecialOfferPrice(hotel, false);
                crossOutPrice = flightHotelDiscount + packagePrice;

                //price per night
                if (displayPrice === 0) {
                    var nightCount = self.calculateNights();
                    crossOutPrice = parseFloat(crossOutPrice / nightCount);
                }
                //price per person
                if (displayPrice === 1) {
                    var paxCount = self.calculatePaxCount();
                    crossOutPrice = parseFloat(crossOutPrice / paxCount);
                }
                // price per room
                if (displayPrice === 2) {
                    var rooms = self.packageQuery.paxInfos.length;
                    crossOutPrice = parseFloat(crossOutPrice / rooms);
                }
                return crossOutPrice.toFixed(self.packageQuery.currencyDecimals);
            },
            getSellingPrice(hotel) {
                var self = this;
                var packagePrice = self.totalPackagePriceValue(hotel);
                var sellingPrice = 0;
                var displayPrice = self.product.displayPrice;

                //price per night
                if (displayPrice === 0) {
                    var nightCount = self.calculateNights();
                    sellingPrice = parseFloat(packagePrice / nightCount);
                }
                //price per person
                if (displayPrice === 1) {
                    var paxCount = self.calculatePaxCount();
                    sellingPrice = parseFloat(packagePrice / paxCount);
                }
                // price per room
                if (displayPrice === 2) {
                    var rooms = self.packageQuery.paxInfos.length;
                    sellingPrice = parseFloat(packagePrice / rooms);
                }
                
                sellingPrice = sellingPrice.toFixed(self.packageQuery.currencyDecimals);

                return sellingPrice > 0 ? sellingPrice : 'Loading...';
            },
            calculateNights() {
                var start = this.packageQuery.checkIn || this.packageQuery.departureDate;
                var end = this.packageQuery.checkOut || this.packageQuery.returnDate;
                return moment(end).diff(moment(start), 'days');
            },
            calculatePaxCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                    count += paxInfo.childCount;
                    count += paxInfo.infantCount;
                }
                return count;
            },
            totalPackagePriceValue(hotel) {
                if (hotel.cheapestPrice === 0) {
                    return 0;
                }

                if (this.enabledFlights && !this.flightStore.outboundFlight) {
                    return 0;
                }

                if (!hotel.availableRooms) {
                    return 0;
                }

                var price = 0;
                for (var j = 0; j < hotel.availableRooms.length; j++) {
                    for (var k = 0; k < hotel.availableRooms[j].availableRoomTypes.length; k++) {
                        var availableRoomType = hotel.availableRooms[j].availableRoomTypes[k];
                        if (availableRoomType.selected) {
                            price += availableRoomType.totalPrice;
                            break;
                        }
                    }
                }

                price += this.totalFlightPrice();

                return price;
            },
            totalFlightPrice() {

                var price = 0;
                if (this.flightStore.outboundFlight) {
                    price += this.flightStore.outboundFlight.totalPrice;
                    //price += this.flightStore.outboundFlight.taxPrice;
                }

                if (this.flightStore.inboundFlight) {
                    price += this.flightStore.inboundFlight.totalPrice;
                    //price += this.flightStore.inboundFlight.taxPrice;
                }
                return price;
            },
            getRoomTypeName(hotel, index) {
                if (!hotel.availableRooms || hotel.availableRooms.length === 0) return "";
                for (var j = 0; j < hotel.availableRooms[index].availableRoomTypes.length; j++) {
                    var availableRoomType = hotel.availableRooms[index].availableRoomTypes[j];
                    if (availableRoomType.selected) {
                        return availableRoomType.description;
                    }
                }
                return "";
            },
            replaceImage(path) {
                var replacedPath;
                if (path.indexOf('static.goquo.com') > -1) {
                    var imagePath = path.split("/");
                    replacedPath = path.replace(imagePath[3], imagePath[3] + '-w300');
                } else {
                    replacedPath = path;
                }

                // Force https
                if (replacedPath.indexOf('http://') == 0) {
                    return "https://" + replacedPath.substr(7);
                }
                return replacedPath;
            },
            gotoHotelInfoPage(baseUrl) {
                window.open(this.getHotelDetailUrl(baseUrl), '_blank');
            },
            getHotelDetailUrl(baseUrl) {
                var href = baseUrl;
                var indexOfMask = baseUrl.indexOf("?");
                if (indexOfMask > -1) {
                    href += "&";
                } else {
                    href += "?";
                }
                if (this.flightStore.outboundFlight != null) {
                    href += "outboundFlightId=" + this.flightStore.outboundFlight.id;

                    if (this.flightStore.inboundFlight != null) {
                        href += "&inboundFlightId=" + this.flightStore.inboundFlight.id;
                    }
                }
                return href;
            },
            gotoHotelsPage(page) {
                this.$emit('pageChanged', page);
            },
            showHotelMapView(hotel, event) {
                if (event) {
                    event.preventDefault();
                    event.stopPropagation();
                }

                if (this.isValidCoordinate(hotel.latitude, hotel.longitude)) {
                    this.$emit('showHotelMapView', hotel);
                }
                return false;
            },
            isValidCoordinate(latitude, longitude) {
                if (latitude && longitude) {
                    return true;
                }
                return false;
            },
            // Checks if a translation is available
            isTranslationAvailable(translation_key) {
                // TRUE if has translation, else FALSE
                return (this.translate(this.$language, translation_key)) ? true : false;
            },
            isFreeWifi(hotel) {
                return hotel.facilities && hotel.facilities.some(function (x) { return x.code.toUpperCase() == 'FIN' });
            }
        }
    }

</script>