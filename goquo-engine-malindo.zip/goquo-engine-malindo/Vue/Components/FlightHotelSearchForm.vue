<template>
    <div>
        <form method="GET" action="/package/start-search" id="fFlightHotelSearch" data-val="true">
            <input type="hidden" name="PromoCode" :value="promoCode" />
            <div v-if="hotelDetail" class="col-xs-12">
                <div class="form-group">
                    <div>
                        <label v-lang.DESTINATION>Destination</label>
                    </div>
                    <span>{{hotelDetail.name}}</span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6">
                <div class="form-group right-icon">
                    <i class="icon icon-location-arrow"></i>
                    <label><span v-lang.FROM_DESTINATION>From</span></label>
                    <AjaxSelect name="From" v-model="model.from" url="/api/get-airports" placeholder="Select Depart Airport" :defaultValue="model.from" :defaultText="model.fromFullText" :cultureCode="model.cultureCode"></AjaxSelect>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 right-icon">
                <div class="form-group">
                    <i class="icon icon-map-marker"></i>
                    <label>
                        <span v-lang.TO_DESTINATION>To</span>
                    </label>
                    <input v-if="hotelDetail" name="To" type="hidden" :value="model.to" />
                    <AjaxSelect :disabled="hotelDetail ? true : false" name="To" v-model="model.to" url="/api/get-airports" placeholder="Select Arrival Airport" :defaultValue="model.to" :defaultText="model.toFullText" :cultureCode="model.cultureCode"></AjaxSelect>
                </div>
            </div>
            <div class="col-xs-6 right-icon">
                <div class="form-group right-icon">
                    <i class="icon icon-calendar"></i>
                    <label>
                        <span v-lang.DEPARTURE_DATE>Departure Date</span>
                    </label>
                    <DatePicker name="DepartureDate" v-model="model.departureDate" :disableDateUrl="depatureDisableDateUrl" :defaultValue="DepartureDate"></DatePicker>
                </div>
            </div>
            <div class="col-xs-6">
                <div class="form-group right-icon">
                    <i class="icon icon-calendar"></i>
                    <label><span v-lang.RETURN_DATE>Return Date</span></label>
                    <DatePicker name="ReturnDate" v-model="model.returnDate" :disableDateUrl="returnDisableDateUrl" :startDate="model.departureDate" :defaultValue="ReturnDate" autoFocus="true" addOneDay="true"></DatePicker>
                </div>
            </div>
            <!--To show Part of stay-->
            <div class="col-xs-12 mb10">
                <label>
                    <input type="checkbox" v-model="model.partialStay">
                    <span v-lang.NEED_HOTEL_PART_STAY>I only need a hotel for part of my trip</span>
                </label>
            </div>
            
            <div v-if="model.partialStay">
                <!--Checkin-->
                <div class="col-xs-6">
                    <div class="form-group right-icon">
                        <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                        <label><span v-lang.CHECK_IN>Check-in</span></label>
                        <DatePicker name="CheckIn" v-model="model.checkIn" :startDate="model.departureDate" :endDate="model.returnDate" :defaultValue="model.departureDate" :minusDays="1"></DatePicker>
                    </div>
                </div>
                <!--Checkout-->
                <div class="col-xs-6">
                    <div class="form-group form-group-filled right-icon">
                        <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                        <label><span v-lang.CHECK_OUT>Check-out</span></label>
                        <DatePicker name="CheckOut" v-model="model.checkOut" :startDate="model.checkIn" :endDate="model.returnDate" :defaultValue="model.returnDate" addOneDay="true"></DatePicker>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6">
                <div class="form-group right-icon">
                    <i class="icon icon-user"></i>
                    <label><span v-lang.ROOMS_PASSENGERS>Rooms and Passengers</span></label>
                    <PaxSelector :maxRooms="3"></PaxSelector>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 text-right btn-modify">
                <input type="hidden" name="JourneyType" value="Return" />
                <input type="hidden" name="HotelCode" :value="model.hotelCode" v-if="model.hotelCode" />
                <input type="hidden" name="ProductId" :value="product.id" />
                <button type="button" @click="submitForm()" class="btn btn-primary btn-block mt-search search-button" v-lang.SEARCH_PACKAGE>Search for Package</button>
            </div>

            <div class="modal fade notification-modal" id="notifySelectDestination" role="search" aria-labelledby="notifySelectDestination">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-body clearfix">
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <p>To city should not be same as From City. Please try again.</p>
                                </div>
                            </div>
                            <div class="col-xs-12 btn-modify">
                                <button type="button" class="btn btn-primary btn-block mt-search" data-dismiss="modal" aria-label="Close">OK</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </form>
    </div>
</template>
<script>
    import Vue from 'vue'
    import { AjaxSelect, DatePicker } from 'goquo-components'
    import PaxSelector from './PaxSelector.vue'
    export default {
        components: { AjaxSelect, DatePicker, PaxSelector },
        props: ['model', 'packageQuery', 'product', 'hotelDetail'],
        data() {
            return {
                promoCode: null,
                DepartureDate: Vue.moment(),
            }
        },
        computed: {
            ReturnDate() {
                return Vue.moment(this.DepartureDate).add(1, 'day');
            },
            depatureDisableDateUrl() {
                if (!this.packageQuery) {
                    return null;
                }
                return "/package/get-disabled-dates?from=" + this.model.from + "&to=" + this.model.to;
            },
            returnDisableDateUrl() {
                if (!this.packageQuery) {
                    return null;
                }
                return "/package/get-disabled-dates?from=" + this.model.to + "&to=" + this.model.from;
            }
        },
        created() {
            var self = this;
            if (self.packageQuery) {
                self.promoCode = self.packageQuery.promoCode || self.model.promoCode;
            } else if (self.model.promoCode) {
                self.promoCode = self.model.promoCode;
            }
        },
        methods: {
            submitForm() {
                if (this.model.from && this.model.to && this.model.from == this.model.to) {
                    $('#notifySelectDestination').modal('toggle');
                } else {
                    $('#fFlightHotelSearch').submit();
                }
            }
        }
    }
</script>