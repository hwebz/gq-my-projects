﻿<template>
    <div class="hi-package-summary" v-if="packageQuery && hotelInfo">
        <a href="#package-detail" class="hidden-hx scroll-to wrapper-link hi-price-section">
            <div>From</div>

            <div>
                <span class="hi-price mb20" v-if="!isSearchCompleted">
                    <span class="load-icon">
                        <span class="bounce1"></span>
                        <span class="bounce2"></span>
                        <span class="bounce3"></span>
                    </span>
                </span>
                <span class="hi-price" v-if="isSearchCompleted && hotelInfo.cheapestPrice > 0">
                    <small>{{packageQuery.currency}}</small>
                    {{ totalPackagePrice }}
                </span>
                <span class="hi-price" v-lang.SOLD_OUT v-if="isSearchCompleted && hotelInfo.cheapestPrice === 0">
                    SOLD OUT
                </span>
            </div>
            <div v-if="productCount == 1">
                <span v-lang.FOR_X_PEOPLE>for</span>
                {{adultCount + childCount + infantCount}}
                <span v-if="(adultCount + childCount + infantCount) == 1">
                    <span v-lang.PERSON>person</span> &
                </span>
                <span v-else>
                    <span v-if="adultCount == 1 && childCount + infantCount == 0 " v-lang.ADULTLOWERCASE>adult</span>
                    <span v-else-if="adultCount > 1 && childCount + infantCount == 0" v-lang.ADULTSLOWERCASE>adults</span>
                    <span v-else v-lang.PEOPLE>people</span> &
                </span>
                <span v-if="calculateNights > 1" v-lang.X_NIGHTS="{0: calculateNights}">nights</span>
                <span v-else v-lang.ONE_NIGHT>night</span>
            </div>
            <div v-else>
                <span v-lang.FOR_X_PEOPLE>for</span>
                {{adultCount}}
                <span v-if="adultCount == 1" v-lang.ADULT>adult</span>
                <span v-else v-lang.ADULTS>adults</span>
                <span v-if="childCount > 0">
                    + {{childCount}}
                    <span v-if="childCount == 1" v-lang.CHILD>child</span>
                    <span v-else v-lang.CHILDREN>children</span>
                </span>
                <span v-if="infantCount > 0">
                    + {{infantCount}}
                    <span v-if="infantCount == 1" v-lang.INFANT>infant</span>
                    <span v-else v-lang.INFANTS>infants</span>
                </span>
            </div>

            <div>
                <span v-if="productCount == 2" v-lang.INCLUDES_FLIGHT_HOTEL_TAXES>inc flight, hotel & taxes</span>
                <!--<span v-else v-lang.INCLUDES_TAXES_FEES>inc taxes & fees</span>-->
            </div>

            <div class="div-link" v-lang.CHOOSE_A_ROOM></div>
        </a>

        <a href="#trustYouReview" class="hi-review-bar clearfix scroll-to" v-if="hotelInfo.trustyou && hotelInfo.trustyou.score > 0">
            <div class="review hi-review-score" v-bind:class="'review_' + hotelInfo.trustyou.score_description" v-if="hotelInfo.trustyou.reviews">
                <span class="review-score">{{hotelInfo.trustyou.score_display | numberRoundRate(1)}}</span>
                <span class="review-desc">{{hotelInfo.trustyou.score_description}}</span>
            </div>
            <div class="hi-review-count">
                <div class="hi-review-count-text">
                    <small v-lang.BASED_ON_X_REVIEWS="{0: hotelInfo.trustyou.reviews_count.toLocaleString()}"></small>
                </div>
                <div class="div-link" v-lang.READ_REVIEWS>Read reviews</div>
            </div>
        </a>

        <a v-if="hotelInfo.latitude && hotelInfo.longitude" href="#locationMap" class="view-map hidden-hx scroll-to">
            <span class="view-map_text"><i class="icon icon-search"></i> <em v-lang.VIEW_ON_MAP>View On Map</em></span>
        </a>

        <!--Form new Search starts-->
        <div class="hi-form" v-if="packageQuery.id == '00000000-0000-0000-0000-000000000000'">
            <h4 v-lang.START_NEW_SEARCH>Start new search</h4>
            <form method="GET" class="mb30" action='/package/start-search' id="fHotelSearch" data-val="true">
                <div class="row custom loadCal loadCal-hi">
                    <div class="col-xs-12 col-sm-6">
                        <div class="form-group">
                            <label class="form-label" v-lang.CHECK_IN>Check-in</label>
                            <DatePicker name="DepartureDate" v-model="packageQuery.departureDate"></DatePicker>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6">
                        <div class="form-group">
                            <label class="form-label" v-lang.CHECK_OUT>Check-out</label>
                            <DatePicker name="ReturnDate" v-model="packageQuery.returnDate"></DatePicker>
                        </div>
                    </div>
                    <div class="col-xs-12">
                        <label class="form-label" v-lang.SELECT_ROOMS>Select Rooms</label>
                        <PaxSelector></PaxSelector>
                    </div>
                    <div class="col-xs-12">
                        <input type="hidden" name="ProductId" value="product.Id" />
                        <input type="hidden" name="From" value="packageQuery.from" />
                        <input type="hidden" name="To" value="packageQuery.to" />
                        <input type="hidden" name="HotelCode" value="hotelId" />
                        <button id="searchForm" type="submit" class="btn btn-primary mt0" v-lang.SEARCH_FOR_ROOMS>
                            Search for Rooms
                        </button>
                    </div>
                </div>
            </form>
        </div>
        <!--Form new Search ends-->

    </div>
</template>

<script>
    export default {
        components: {},
        data() {
            return {

            }
        },
        computed: {
            packageQuery() {
                return this.$store.state.workContext.packageQuery;
            },
            hotelInfo() {
                return this.$store.state.hotelInfo;
            },
            isSearchCompleted() {
                return this.$store.state.isSearchCompleted;
            },
            adultCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.adultCount;
                }
                return count;
            },
            childCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.childCount;
                }
                return count;
            },
            infantCount() {
                var count = 0;
                for (var i = 0; i < this.packageQuery.paxInfos.length; i++) {
                    var paxInfo = this.packageQuery.paxInfos[i];
                    count += paxInfo.infantCount;
                }
                return count;
            },
            productCount() {
                return this.$store.state.workContext.product.products.length;
            },
            totalPackagePrice() {
                return this.$store.state.totalPackagePrice;
            },
            calculateNights() {
                var packageQuery = this.$store.state.workContext.packageQuery;
                var start = packageQuery.checkIn || packageQuery.departureDate;
                var end = packageQuery.checkOut || packageQuery.returnDate;
                return moment(end).diff(moment(start), 'days');
            },
        },
        methods: {
        }
    }
</script>