<template>
    <select class="form-control" data-val="true" data-val-required="Please enter a value.">
        <option v-for="currency in currencies" :selected="defaultValue === currency.code" :value="currency.code">{{currency.code}} - {{currency.description}}</option>
    </select>
</template>
<script>
    export default {
        props: ['url', 'placeholder', 'defaultValue'],
        data() {
            return {
                currencies: []
            }
        },
        created() {
            var self = this;
            self.getCurrentcies(); 
        },
        mounted: function () {
            var vm = this;
            var $element = $(vm.$el);
            $element.select2({
                data: vm.currencies,
                placeholder: vm.placeholder,
                width: '100%',
            }).val(vm.value)
                .trigger('change')
                .on('select2:select', function (e) {
                    var data = e.params.data;
                    if (data && data.id) {
                        vm.$emit('input', data.id);
                    }
                    else {
                        vm.$emit('input', null);
                    }

                    vm.$emit('changed', data);
                })


            if ($element.is('[data-val-required]') && $element[0].form) {
                $($element[0].form).submit(function (event) {
                    var value = $element.val();
                    if (value == null || value === "") {
                        $element.parent().find("span.select2-container").addClass("input-validation-error").show();
                        event.preventDefault();
                    } else {
                        $element.parent().find("span.select2-container").removeClass("input-validation-error").show();
                    }
                });
            }
        },
        methods: {
            getCurrentcies() {
                var self = this;
                $.ajax({
                    url: self.url,
                    traditional: true,
                    type: 'POST',
                    success: function (data) {
                        if (data != null && data.length > 0) {
                            self.currencies = data;
                        }
                    }
                });
            },
            clearSelection() {
                $(this.$el).val(null).trigger('change');
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            }
        }
    }

</script>
