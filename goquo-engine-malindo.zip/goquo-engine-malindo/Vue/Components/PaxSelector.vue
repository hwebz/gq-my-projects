<template>
    <div class="dropdown">
        <span class="form-control dropdown-toggle">
            <span v-if="maxRooms == 1">
                <span class="paxCount">{{paxCount()}}</span> Pax(s)
            </span>
            <span v-if="maxRooms > 1">
                <span class="roomCount">
                    <span v-if="paxInfos.length == 1">1 Room</span>
                    <span v-if="paxInfos.length > 1">{{paxInfos.length}} Rooms</span>
                </span>
                <span class="paxCount">{{paxCount()}}</span> Pax(s)
            </span>
            <input type="hidden" class="roomCount" name="RoomCount" :value="paxInfos.length" />
        </span>
        <ul class="dropdown-menu addroompax" role="menu">
            <li v-for="(paxInfo, index) in paxInfos">
                <h5 v-show="maxRooms > 1"><strong>Room {{index+1}}</strong> <span class="removeRoom" v-show="index > 0" @click="removePaxInfo(index, $event)">x Remove</span></h5>
                <div class="row" v-if="tour || transfer">
                    <div class="col-xs-4">
                        <div class="form-group">
                            <label>Adults ({{$store.state.workContext.siteInfo.adultAge}}+)</label>
                            <select class="form-control adult" :name="'PaxInfos[' + index + '].AdultCount'" v-model="paxInfo.adultCount" autocomplete="off">
                                <option :value="n" v-for="n in range(1,9)">{{n}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-xs-4">
                        <div class="form-group">
                            <label>Children ({{$store.state.workContext.siteInfo.childAge}}-{{$store.state.workContext.siteInfo.adultAge-1}})</label>
                            <select class="form-control children" :name="'PaxInfos[' + index + '].ChildCount'" v-model="paxInfo.childCount" autocomplete="off">
                                <option :value="n" v-for="n in range(0,9)">{{n}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-xs-4" v-if="!tour">
                        <div class="form-group">
                            <label>Infants (0-{{$store.state.workContext.siteInfo.childAge}})</label>
                            <select class="form-control infant" :name="'PaxInfos[' + index + '].InfantCount'" v-model="paxInfo.infantCount" autocomplete="off">
                                <option :value="n" v-for="n in range(0,9)">{{n}}</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row" v-else>
                    <div class="col-xs-4">
                        <div class="form-group">
                            <label>Adults ({{$store.state.workContext.siteInfo.adultAge}}+)</label>
                            <select class="form-control adult" :name="'PaxInfos[' + index + '].AdultCount'" v-model="paxInfo.adultCount" autocomplete="off">
                                <option :value="n" v-for="n in range(1,3)">{{n}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-xs-4">
                        <div class="form-group">
                            <label>Children({{$store.state.workContext.siteInfo.childAge}}-{{$store.state.workContext.siteInfo.adultAge-1}})</label>
                            <select class="form-control children" :name="'PaxInfos[' + index + '].ChildCount'" v-model="paxInfo.childCount" autocomplete="off">
                                <option :value="n" v-for="n in range(0,3)">{{n}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-xs-4">
                        <div class="form-group">
                            <label>Infants  (0-{{$store.state.workContext.siteInfo.childAge}})</label>
                            <select class="form-control infant" :name="'PaxInfos[' + index + '].InfantCount'" v-model="paxInfo.infantCount" autocomplete="off">
                                <option :value="n" v-for="n in range(0,3)">{{n}}</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div v-if="tour && paxInfo.childCount > 0 || transfer && paxInfo.childCount > 0">
                    <div v-for="(child,indexChild) in paxInfo.childCount">
                        <input type="hidden" v-if="indexChild === 0" :name="'PaxInfos[' + index + '].ChildAge1'" :value="11" />
                        <input type="hidden" v-if="indexChild === 1" :name="'PaxInfos[' + index + '].ChildAge2'" :value="11" />
                        <input type="hidden" v-if="indexChild === 2" :name="'PaxInfos[' + index + '].ChildAge3'" :value="11" />
                    </div>
                </div>
                <div class="room2Child" v-if="paxInfo.childCount > 0 && !tour && !transfer">
                    <h6>Please add the ages of the children for this pax:</h6>
                    <div class="row">
                        <div class="col-xs-4">
                            <div class="form-group childAge child1">
                                <label style="white-space: nowrap;">1st Child age</label>
                                <select class="form-control infant" :name="'PaxInfos[' + index + '].ChildAge1'" v-model="paxInfo.childAge1">
                                    <option :value="n" v-for="n in childAges">{{n}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-4">
                            <div class="form-group childAge child2" v-show="paxInfo.childCount > 1">
                                <label style="white-space: nowrap;">2nd Child age</label>
                                <select class="form-control infant" :name="'PaxInfos[' + index + '].ChildAge2'" v-model="paxInfo.childAge2">
                                    <option :value="n" v-for="n in childAges">{{n}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-4">
                            <div class="form-group childAge child3" v-show="paxInfo.childCount > 2">
                                <label style="white-space: nowrap;">3rd Child age</label>
                                <select class="form-control infant" :name="'PaxInfos[' + index + '].ChildAge3'" v-model="paxInfo.childAge3">
                                    <option :value="n" v-for="n in childAges">{{n}}</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            <li class="text-center">
                <span class="addroom" v-show="maxRooms > 1 && paxInfos.length < maxRooms" @click="addPaxInfo()">Add an additional room <span class="icon icon-add"></span></span>
                <small class="red" v-show="maxRooms > 1 && paxInfos.length == maxRooms"> Max {{maxRooms}} rooms are allowed per booking </small>
                <small class="red" v-show="paxCountExcludeInfant() > 9"> You can only book Maximum 9 Passengers per Booking (Excluding infant)! </small>
            </li>
        </ul>
    </div>
</template>
<script>
    export default {
        name: "PaxSelector",
        data() {
            return {
                paxInfos: [],
                childAges: []
            }
        },
        methods: {
            addPaxInfo: function (event) {
                if (this.paxInfos.length >= this.maxRooms) {
                    return;
                }

                var childAge = this.$store.state.workContext.siteInfo.childAge;
                this.paxInfos.push({
                    adultCount: 2,
                    childCount: 0,
                    infantCount: 0,
                    childAge1: childAge,
                    childAge2: childAge,
                    childAge3: childAge
                });

                if (event) {
                    event.preventDefault();
                    event.stopPropagation();
                }
            },
            removePaxInfo: function (index, event) {
                this.paxInfos.splice(index, 1);
                if (event) {
                    event.preventDefault();
                    event.stopPropagation();
                }
            },
            paxCount: function () {
                var count = 0;
                for (var i = 0, len = this.paxInfos.length; i < len; i++) {

                    var paxInfo = this.paxInfos[i];
                    count += parseInt(paxInfo.adultCount + "");
                    count += parseInt(paxInfo.childCount + "");
                    count += parseInt(paxInfo.infantCount + "");
                }
                return count;
            },
            paxCountExcludeInfant: function () {
                var count = 0;
                for (var i = 0, len = this.paxInfos.length; i < len; i++) {

                    var paxInfo = this.paxInfos[i];
                    count += parseInt(paxInfo.adultCount + "");
                    count += parseInt(paxInfo.childCount + "");
                }

                if (count > 9) {
                    $(".search-button").hide();
                    bootbox.alert({
                        message: "You can only book Maximum 9 Passengers per Booking (Excluding infant)!",
                        size: 'large'
                    });
                }
                else { $(".search-button").show(); }
                return count;
            },
            range: function (min, max) {
                var array = [],
                    j = 0;
                for (var i = min; i <= max; i++) {
                    array[j] = i;
                    j++;
                }
                return array;
            },
        },
        props: ['maxRooms','tour','transfer'],
        mounted: function () {
            // default pax info
            var childAge = this.$store.state.workContext.siteInfo.childAge;
            var adultAge = this.$store.state.workContext.siteInfo.adultAge;

            for (var i = childAge; i <= adultAge - 1; i++) {
                this.childAges.push(i);
            }

            if (this.$store.state.workContext.packageQuery) {
                for (var i = 0; i < this.$store.state.workContext.packageQuery.paxInfos.length; i++) {
                    var paxInfo = JSON.parse(JSON.stringify(this.$store.state.workContext.packageQuery.paxInfos[i]));
                    if (paxInfo.childAge1 === 0) {
                        paxInfo.childAge1 = childAge;
                    }
                    if (paxInfo.childAge2 === 0) {
                        paxInfo.childAge2 = childAge;
                    }
                    if (paxInfo.childAge3 === 0) {
                        paxInfo.childAge3 = childAge;
                    }
                    this.paxInfos.push(paxInfo);
                }
            }
            else {
                if (this.paxInfos.length == 0) {
                    // Create default pax info
                    this.paxInfos.push({
                        adultCount: 2,
                        childCount: 0,
                        infantCount: 0,
                        childAge1: childAge,
                        childAge2: childAge,
                        childAge3: childAge
                    });
                }
            }

            var vm = this;
            var $element = $(vm.$el);
            var button = $('.dropdown-toggle', $element);
            var dropdown = button.next(".dropdown-menu");
            var container = button.parent();

            button.click(function (event) {
                dropdown.toggle();
            });

            $(document).click(function (event) {
                if (!container.has(event.target).length) {
                    dropdown.hide();
                }
            });
        }
    }
</script>
