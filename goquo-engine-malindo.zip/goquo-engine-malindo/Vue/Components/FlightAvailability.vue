﻿<template>
    <div>
        <div v-if="!loading.flightDetails" class="flight-container">
            <div class="flight-section dropdown">
                <div class="flight-icon">
                    <span class="icon icon-flight"></span><span class="flight-title" v-lang.DEPARTURE_FLIGHT>Departure Flight</span>
                </div>
                <div class="flight-timeinfo tp-display-block" style="display:grid">
                    <div class="load"></div>
                    <div class="load load50"></div>
                </div>
            </div>
            <div class="flight-section dropdown">
                <div class="flight-icon">
                    <span class="icon icon-flight-return"></span><span class="flight-title" v-lang.RETURN_FLIGHT>Return Flight</span>
                </div>
                <div class="flight-timeinfo tp-display-block" style="display:grid">
                    <div class="load"></div>
                    <div class="load load50"></div>
                </div>
            </div>
        </div>
        <div class="flight-container" v-if="loading.flightDetails">
            <div class="flight-section dropdown" v-if="outboundFlightSelected != null">
                <div class="flight-icon">
                    <span class="icon icon-flight"></span>
                    <span class="flight-title">
                        <span v-lang.DEPARTURE_FLIGHT>Departure Flight</span>
                        <a href="#flightinfo" data-toggle="modal">
                            <i class="icon icon-information"
                               @click="setFlightInfoPopup(outboundFlightSelected)"
                               v-tooltip="'More Info'"></i>
                        </a>
                    </span>
                </div>
                <div class="flight-timeinfo">
                    <div class="flight-timeinfoleft">
                        <strong class="flight-time">{{outboundFlightSelected.legs[0].departureDate | moment("HH:mm")}}</strong>
                        <span class="flight-date">{{outboundFlightSelected.legs[0].departureDate | moment("ddd, DD MMM")}}</span>
                        <span class="flight-city"
                              v-tooltip="outboundFlightSelected.legs[0].departureCityName + ', ' + outboundFlightSelected.legs[0].departureAirportName">
                            {{outboundFlightSelected.legs[0].departureAirportCode}} - {{outboundFlightSelected.legs[0].departureAirportName}}
                        </span>
                    </div>
                    <div class="flight-timeinfocenter">
                        <span class="icon icon-right-arrow"></span>
                        <span v-show="outboundFlightSelected.stops == 0" v-lang.NON_STOP>non-stop</span>
                        <span v-show="outboundFlightSelected.stops == 1" v-lang.ONE_STOP>1 stop</span>
                        <span v-show="outboundFlightSelected.stops > 1" v-lang.STOPS="{0: outboundFlightSelected.stops}"></span>
                    </div>
                    <div class="flight-timeinforight">
                        <strong class="flight-time">{{outboundFlightSelected.legs[outboundFlightSelected.stops].arrivalDate | moment("HH:mm")}}</strong>
                        <span class="flight-date">{{outboundFlightSelected.legs[outboundFlightSelected.stops].arrivalDate | moment("ddd, DD MMM")}}</span>
                        <span class="flight-city"
                              v-tooltip="outboundFlightSelected.legs[outboundFlightSelected.stops].arrivalCityName + ', ' + outboundFlightSelected.legs[outboundFlightSelected.stops].arrivalAirportName">
                            {{outboundFlightSelected.legs[outboundFlightSelected.stops].arrivalAirportCode }} - {{outboundFlightSelected.legs[outboundFlightSelected.stops].arrivalAirportName }}
                        </span>
                    </div>
                </div>
                <div class="flight-promo">
                </div>
                <div class="flight-changetime" v-if="flightStore.flights.length > 2">
                    <a href="#" data-toggle="dropdown" v-lang.CHANGE_TIME>Change Time</a>
                    <div class="flight-changeinfo dropdown-menu">
                        <div class="flight-changeinfo-wrapper">
                            <div class="flight-changeinfo-header">
                                <div class="flight-changeinfo-wrap labeled">
                                    <div v-lang.DEPART>
                                        Depart
                                    </div>
                                    <div class="flight-changeinfo-icon">

                                    </div>
                                    <div v-lang.ARRIVE>
                                        Arrive
                                    </div>
                                </div>
                                <div class="flight-changeinfo-wrap">
                                    <div class="flight-changeinfo-super">
                                        <p v-lang.SUPPERSAVER v-tooltip="translateText('FLIGHT_VALUE', 'Fee is chargeable to flight date and time change plus fare difference, per guest per sector.')">Value</p>
                                        <div class="flight-addons">
                                             <span class="icon-meal" v-tooltip="translateText('MEALS', 'Meals')"></span>
                                            <span class="icon-shield" v-tooltip="translateText('FLIGHT_MILES', 'Miles Included')"></span> 
                                        </div>
                                    </div>
                                    <div class="flight-changeinfo-value">
                                        <p v-lang.VALUE v-tooltip="translateText('FLIGHT_VALUE', 'Fee is chargeable to flight date and time change plus fare difference, per guest per sector.')">Value</p>
                                        <div class="flight-addons">
                                            <span class="icon-baggage" v-tooltip="translateTextBaggage('OUTBOUND', 'VALUE', '25kg Free')"></span>
                                            <span class="icon-meal" v-tooltip="translateText('MEALS', 'Meals')"></span>
                                            <span class="icon-shield" v-tooltip="translateText('FLIGHT_MILES', 'Miles Included')"></span>
                                        </div>
                                    </div>
                                    <div v-if="checkPremiumOrShuttle(outboundGroups,'shuttle')" class="flight-changeinfo-shuttle">
                                        <p v-lang.SHUTTLE v-tooltip="translateText('FLIGHT_SHUTTLE', 'Fee is chargeable to flight date and time change plus fare difference, per guest per sector.')">Shuttle</p>
                                        <div class="flight-addons">
                                            <span class="icon-baggage" v-tooltip="translateTextBaggage('OUTBOUND','SHUTTLE', '25kg Free')"></span>
                                            <span class="icon-meal" v-tooltip="translateText('MEALS', 'Meals')"></span>
                                            <span class="icon-shield" v-tooltip="translateText('FLIGHT_MILES', 'Miles Included')"></span>
                                        </div>
                                    </div>
                                    <div v-if="checkPremiumOrShuttle(outboundGroups,'flexi')" class="flight-changeinfo-premium">
                                        <p v-lang.FLEXI v-tooltip="translateText('FLEXI', 'Free Change Fee, only pay the cost in fare difference')">Flexi</p>
                                        <div class="flight-addons">
                                            <span class="icon-baggage" v-tooltip="translateTextBaggage('OUTBOUND', 'FLEXI', '25kg Free')"></span>
                                            <span class="icon-meal" v-tooltip="translateText('MEALS', 'Meals')"></span>
                                            <span class="icon-shield" v-tooltip="translateText('FLIGHT_MILES', 'Miles Included')"></span>
                                            <span class="icon-seat" v-tooltip="translateText('FLIGHT_SEAT', 'Free Seats <div>(Not applicable for Codeshare Flights)</div>')"></span>
                                        </div>
                                    </div>
                                    <div class="flight-changeinfo-business">
                                        <p v-lang.BUSINESS v-tooltip="translateText('FLIGHT_BUSINESS', 'Fee is chargeable to flight date and time change plus fare difference, per guest per sector.')">Business</p>
                                        <div class="flight-addons">
                                            <span class="icon-baggage" v-tooltip="translateTextBaggage('OUTBOUND','BUSINESS', '40kg Free')"></span>
                                            <span class="icon-meal" v-tooltip="translateText('MEALS', 'Meals')"></span>
                                            <span class="icon-shield" v-tooltip="translateText('FLIGHT_MILES', 'Miles Included')"></span>
                                            <span class="icon-seat" v-tooltip="translateText('FLIGHT_SEAT', 'Free Seats <div>(Not applicable for Codeshare Flights)</div>')"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="flight-changeinfo-flights-wrapper scrollbar-dynamic">
                                <div v-for="(flight, flightIndex) in outboundGroups" class="flight-changeinfo-flights" :key="flightIndex">
                                    <div class="flight-changeinfo-flights-wrap">
                                        <div v-for="(leg, legIndex) in flight.legs" :class="{'transit-flight': checkTransistionTime(legIndex,flight.legs)}" :key="legIndex">
                                            <p class="transit-time" v-if="checkTransistionTime(legIndex,flight.legs)">
                                                <strong v-if="checkFlightStopover(flight.legs[legIndex-1].flightNumber , flight.legs[legIndex].flightNumber)" v-lang.TRANSISTION_TIME>Transit time</strong>
                                                <strong v-if="!checkFlightStopover(flight.legs[legIndex-1].flightNumber , flight.legs[legIndex].flightNumber)" v-lang.STOPOVER_TIME>Stopover time</strong>
                                                : {{getTransistionTime(flight.legs[legIndex-1].arrivalDate, flight.legs[legIndex].departureDate)}}
                                            </p>
                                            <div>
                                                <h4>{{leg.departureDate | moment("HH:mm")}} <sup>{{checkOutboundDiffrenceDate(leg.departureDate,flight.legs,legIndex)}}</sup></h4>
                                                <p><span>{{leg.departureAirportName}}</span></p>
                                            </div>
                                            <div class="flight-changeinfo-icon">
                                                <small>{{leg.airlineName}}</small>
                                                <span class="icon-flight"></span>
                                                <small class="flight-changeinfo-icon__no">{{leg.airlineCode}} {{leg.flightNumber}}</small>
                                            </div>
                                            <div>
                                                <h4>{{leg.arrivalDate | moment("HH:mm")}} <sup>{{checkInboundDiffrenceDate(leg.departureDate,leg.arrivalDate)}}</sup></h4>
                                                <p><span v-if="leg.duration > 0"><strong v-lang.DURATION>Duration</strong>: {{getDurationTime(leg.duration)}}</span> <span>{{leg.arrivalAirportName}} </span></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flight-changeinfo-radio-wrap">
                                        <template v-for="(flightGroup, flightGroupIndex) in  checkFlightGroups(flight.flightGroups,flight)" >
                                            <div v-if="!(flightGroupIndex ==2 && !existFlexiOut && !existShuttleOut)" class="flight-changeinfo-radio" :key="flightGroupIndex">
                                                <label v-if="flightGroup != null && flight.supperSaverId != null && flightGroup.id == flight.supperSaverId" :for="'outbound-flight-ticket-supperSaver-' + flightIndex + flightGroupIndex">
                                                    <input type="radio" :id="'outbound-flight-ticket-supperSaver-' + flightIndex + flightGroupIndex" :value="flight.supperSaverId" name="OutboundFlightPrice" :checked="flightGroup.id === outboundFlightSelected.id" @click="setSelectedFlight(flightGroup, 'SUPPERSAVER')" />
                                                    <strong>{{calcFlightPrice(outboundFlightSelected.totalPrice, flight.pricesupperSaver, '+', '-')}} </strong>
                                                </label>

                                                <label v-if="flightGroup == null && flight.supperSaverId == null && flightGroupIndex == 0" v-lang.SOLD_OUT class="no-hover">
                                                    Sold Out
                                                </label>

                                                <label v-if="flightGroup != null && flight.valueId != null && flightGroup.id == flight.valueId" :for="'outbound-flight-ticket-value-' + flightIndex + flightGroupIndex">
                                                    <input type="radio" :id="'outbound-flight-ticket-value-' + flightIndex + flightGroupIndex" :value="flight.valueId" name="OutboundFlightPrice" :checked="flightGroup.id === outboundFlightSelected.id" @click="setSelectedFlight(flightGroup, 'VALUE')" />
                                                    <strong>{{calcFlightPrice(outboundFlightSelected.totalPrice, flight.priceValue, '+', '-')}} </strong>
                                                </label>

                                                <label v-if="flightGroup == null && flight.valueId == null && flightGroupIndex == 1" v-lang.SOLD_OUT class="no-hover">
                                                    Sold Out
                                                </label>

                                                <label v-if="flightGroup != null && flight.premiumId != null && flightGroup.id == flight.premiumId" class="price-count" :for="'outbound-flight-ticket-premium-' + flightIndex + flightGroupIndex">
                                                    <input type="radio" :id="'outbound-flight-ticket-premium-' + flightIndex + flightGroupIndex" :value="flight.premiumId" name="OutboundFlightPrice" :checked="flightGroup.id === outboundFlightSelected.id" @click="setSelectedFlight(flightGroup, 'FLEXI')" />
                                                    <strong>{{calcFlightPrice(outboundFlightSelected.totalPrice, flight.pricePremium, '+', '-')}}</strong>
                                                </label>


                                                <label v-if="flightGroup != null && flight.shuttleId != null && flight.premiumId == null  && flightGroup.id == flight.shuttleId" class="price-count" :for="'outbound-flight-ticket-shuttle-' + flightIndex + flightGroupIndex">
                                                    <input type="radio" :id="'outbound-flight-ticket-shuttle-' + flightIndex + flightGroupIndex" :value="flight.shuttleId" name="OutboundFlightPrice" :checked="flightGroup.id === outboundFlightSelected.id" @click="setSelectedFlight(flightGroup, 'SHUTTLE')" />
                                                    <strong>{{calcFlightPrice(outboundFlightSelected.totalPrice, flight.priceShuttle, '+', '-')}}</strong>
                                                </label>


                                                <label v-if="flightGroup == null && flight.premiumId == null && flight.shuttleId == null  && flightGroupIndex == 2" v-lang.SOLD_OUT class="no-hover">
                                                    Sold Out
                                                </label>

                                                <label v-if="flightGroup != null && flight.businessId != null && flightGroup.id == flight.businessId" class="price-count" :for="'outbound-flight-ticket-business-' + flightIndex + flightGroupIndex">
                                                    <input type="radio" :id="'outbound-flight-ticket-business-' + flightIndex + flightGroupIndex" :value="flight.businessId" name="OutboundFlightPrice" :checked="flightGroup.id === outboundFlightSelected.id" @click="setSelectedFlight(flightGroup,'BUSINESS')" />
                                                    <strong>{{calcFlightPrice(outboundFlightSelected.totalPrice, flight.priceBusiness, '+', '-')}}</strong>
                                                </label>
                                                
                                                <label v-if="airTypeOutBound =='BOEING' && flightGroup == null && flight.businessId == null && flightGroupIndex == 3" v-lang.SOLD_OUT class="no-hover">
                                                    Sold Out
                                                </label>
                                                <label v-if="airTypeOutBound =='ATR' && flightGroup == null && flight.businessId == null && flightGroupIndex == 3"  class="no-hover">
                                                    N/A
                                                </label>
                                            </div>
                                        </template >
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="flight-section dropdown" v-if="inboundFlightSelected != null">
                <div class="flight-icon">
                    <span class="icon icon-flight-return"></span>
                    <span class="flight-title">
                        <span v-lang.RETURN_FLIGHT>Return Flight</span>
                        <a href="#flightinfo" data-toggle="modal">
                            <i class="icon icon-information"
                               @click="setFlightInfoPopup(inboundFlightSelected)"
                               v-tooltip="'More Info'"></i>
                        </a>
                    </span>
                </div>
                <div class="flight-timeinfo">
                    <div class="flight-timeinfoleft">
                        <span class="flight-time">{{inboundFlightSelected.legs[0].departureDate | moment("HH:mm")}}</span>
                        <span class="flight-date">{{inboundFlightSelected.legs[0].departureDate | moment("ddd, DD MMM")}}</span>
                        <span class="flight-city"
                              v-tooltip="inboundFlightSelected.legs[0].departureCityName + ', ' + inboundFlightSelected.legs[0].departureAirportName">
                            {{inboundFlightSelected.legs[0].departureAirportCode}} - {{inboundFlightSelected.legs[0].departureAirportName}}
                        </span>
                    </div>
                    <div class="flight-timeinfocenter">
                        <span class="icon icon-right-arrow"></span>
                        <span v-show="inboundFlightSelected.stops == 0" v-lang.NON_STOP>non-stop</span>
                        <span v-show="inboundFlightSelected.stops == 1" v-lang.ONE_STOP>1 stop</span>
                        <span v-show="inboundFlightSelected.stops > 1" v-lang.STOPS="{0: inboundFlightSelected.stops}"></span>
                    </div>
                    <div class="flight-timeinforight">
                        <span class="flight-time">{{inboundFlightSelected.legs[inboundFlightSelected.stops].arrivalDate | moment("HH:mm")}}</span>
                        <span class="flight-date">{{inboundFlightSelected.legs[inboundFlightSelected.stops].arrivalDate | moment("ddd, DD MMM")}}</span>
                        <span class="flight-city"
                              v-tooltip="inboundFlightSelected.legs[inboundFlightSelected.stops].arrivalCityName + ', ' + inboundFlightSelected.legs[inboundFlightSelected.stops].arrivalAirportName">
                            {{inboundFlightSelected.legs[inboundFlightSelected.stops].arrivalAirportCode}} - {{inboundFlightSelected.legs[inboundFlightSelected.stops].arrivalAirportName}}
                        </span>
                    </div>
                </div>
                <div class="flight-promo"> </div>
                <div class="flight-changetime" v-if="flightStore.flights.length > 2">
                    <a href="#" data-toggle="dropdown" v-lang.CHANGE_TIME>Change Time</a>
                    <div class="flight-changeinfo dropdown-menu">
                        <div class="flight-changeinfo-wrapper">
                            <div class="flight-changeinfo-header">
                                <div class="flight-changeinfo-wrap labeled">
                                    <div v-lang.DEPART>
                                        Depart
                                    </div>
                                    <div class="flight-changeinfo-icon">

                                    </div>
                                    <div v-lang.ARRIVE>
                                        Arrive
                                    </div>
                                </div>
                                <div class="flight-changeinfo-wrap">
                                   <div class="flight-changeinfo-super">
                                        <p v-lang.SUPPERSAVER v-tooltip="translateText('FLIGHT_VALUE', 'Fee is chargeable to flight date and time change plus fare difference, per guest per sector.')">Value</p>
                                        <div class="flight-addons">
                                             <span class="icon-meal" v-tooltip="translateText('MEALS', 'Meals')"></span>
                                            <span class="icon-shield" v-tooltip="translateText('FLIGHT_MILES', 'Miles Included')"></span> 
                                        </div>
                                    </div>
                                    <div class="flight-changeinfo-value">
                                        <p v-lang.VALUE v-tooltip="translateText('FLIGHT_VALUE', 'Fee is chargeable to flight date and time change plus fare difference, per guest per sector.')">Value</p>
                                        <div class="flight-addons">
                                            <span class="icon-baggage" v-tooltip="translateTextBaggage('INBOUND','VALUE', '25kg Free')"></span>
                                            <span class="icon-meal" v-tooltip="translateText('MEALS', 'Meals')"></span>
                                            <span class="icon-shield" v-tooltip="translateText('FLIGHT_MILES', 'Miles Included')"></span>
                                        </div>
                                    </div>
                                    <div v-if="checkPremiumOrShuttle(inboundGroups,'shuttle')" class="flight-changeinfo-shuttle">
                                        <p v-lang.SHUTTLE v-tooltip="translateText('FLIGHT_SHUTTLE', 'Fee is chargeable to flight date and time change plus fare difference, per guest per sector.')">Shuttle</p>
                                        <div class="flight-addons">
                                            <span class="icon-baggage" v-tooltip="translateTextBaggage('INBOUND','SHUTTLE', '25kg Free')"></span>
                                            <span class="icon-meal" v-tooltip="translateText('MEALS', 'Meals')"></span>
                                            <span class="icon-shield" v-tooltip="translateText('FLIGHT_MILES', 'Miles Included')"></span>
                                        </div>
                                    </div>
                                    <div v-if="checkPremiumOrShuttle(inboundGroups,'flexi')" class="flight-changeinfo-premium">
                                        <p v-lang.FLEXI v-tooltip="translateText('FLIGHT_PREMIUM', 'Free Change Fee, only pay the cost in fare difference')">Flexi</p>
                                        <div class="flight-addons">
                                            <span class="icon-baggage" v-tooltip="translateTextBaggage('INBOUND','FLEXI', '25kg Free')"></span>
                                            <span class="icon-meal" v-tooltip="translateText('MEALS', 'Meals')"></span>
                                            <span class="icon-shield" v-tooltip="translateText('FLIGHT_MILES', 'Miles Included')"></span>
                                            <span class="icon-seat" v-tooltip="translateText('FLIGHT_SEAT', 'Free Seats <div>(Not applicable for Codeshare Flights)</div>')"></span>
                                        </div>
                                    </div>
                                    <div class="flight-changeinfo-business">
                                        <p v-lang.BUSINESS v-tooltip="translateText('FLIGHT_BUSINESS', 'Fee is chargeable to flight date and time change plus fare difference, per guest per sector.')">Business</p>
                                        <div class="flight-addons">
                                            <span class="icon-baggage" v-tooltip="translateTextBaggage('INBOUND','BUSINESS', '40kg Free')"></span>
                                            <span class="icon-meal" v-tooltip="translateText('MEALS', 'Meals')"></span>
                                            <span class="icon-shield" v-tooltip="translateText('FLIGHT_MILES', 'Miles Included')"></span>
                                            <span class="icon-seat" v-tooltip="translateText('FLIGHT_SEAT', 'Free Seats <div>(Not applicable for Codeshare Flights)</div>')"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="flight-changeinfo-flights-wrapper scrollbar-dynamic">
                                <div v-for="(flight,flightIndex) in inboundGroups" class="flight-changeinfo-flights" :key="flightIndex">
                                    <div class="flight-changeinfo-flights-wrap">
                                        <div v-for="(leg, legIndex) in flight.legs" :class="{'transit-flight': checkTransistionTime(legIndex,flight.legs)}" :key="legIndex">
                                            <p class="transit-time" v-if="checkTransistionTime(legIndex,flight.legs)">
                                                <strong v-if="checkFlightStopover(flight.legs[legIndex-1].flightNumber , flight.legs[legIndex].flightNumber)" v-lang.TRANSISTION_TIME>Transit time</strong>
                                                <strong v-if="!checkFlightStopover(flight.legs[legIndex-1].flightNumber , flight.legs[legIndex].flightNumber)" v-lang.STOPOVER_TIME>Stopover time</strong>
                                                : {{getTransistionTime(flight.legs[legIndex-1].arrivalDate, flight.legs[legIndex].departureDate)}}
                                            </p>
                                            <div>
                                                <h4>{{leg.departureDate | moment("HH:mm")}} <sup>{{checkOutboundDiffrenceDate(leg.departureDate,flight.legs,legIndex)}}</sup></h4>
                                                <p><span> {{leg.departureAirportName}}</span> </p>
                                            </div>
                                            <div class="flight-changeinfo-icon">
                                                <small>{{leg.airlineName}}</small>
                                                <span class="icon-flight"></span>
                                                <small class="flight-changeinfo-icon__no">{{leg.airlineCode}} {{leg.flightNumber}}</small>
                                            </div>
                                            <div>
                                                <h4>{{leg.arrivalDate | moment("HH:mm")}} <sup>{{checkInboundDiffrenceDate(leg.departureDate,leg.arrivalDate)}}</sup></h4>
                                                <p><span v-if="leg.duration > 0"><strong v-lang.DURATION>Duration</strong>:  {{getDurationTime(leg.duration)}}</span> <span>{{leg.arrivalAirportName}}</span></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flight-changeinfo-radio-wrap">
                                         <template v-for="(flightGroup, flightGroupIndex) in  checkFlightGroups(flight.flightGroups,flight)" >
                                             <div v-if="!(flightGroupIndex ==2 && !existFlexiIn && !existShuttleIn)" class="flight-changeinfo-radio" :key="flightGroupIndex">

                                                 <!-- <div v-for="(flightGroup, flightGroupIndex) in  checkFlightGroups(flight.flightGroups,flight)" class="flight-changeinfo-radio"> -->
                                                 <label v-if="flightGroup != null && flight.supperSaverId != null && flightGroup.id == flight.supperSaverId" :for="'inbound-flight-ticket-supperSaver-' + flightIndex + flightGroupIndex">
                                                     <input type="radio" :id="'inbound-flight-ticket-supperSaver-' + flightIndex + flightGroupIndex" :value="flight.supperSaverId" name="InboundFlightPrice" :checked="flightGroup.id === inboundFlightSelected.id" @click="setSelectedFlight(flightGroup, 'SUPPERSAVER')" />
                                                     <strong>{{calcFlightPrice(inboundFlightSelected.totalPrice, flight.pricesupperSaver, '+', '-')}} </strong>
                                                 </label>

                                                 <label v-if="flightGroup == null && flight.supperSaverId == null && flightGroupIndex == 0" v-lang.SOLD_OUT class="no-hover">
                                                     Sold Out
                                                 </label>

                                                 <label v-if="flightGroup != null && flight.valueId != null && flightGroup.id == flight.valueId" :for="'inbound-flight-ticket-value-' + flightIndex  + flightGroupIndex">
                                                     <input type="radio" :id="'inbound-flight-ticket-value-' + flightIndex + flightGroupIndex" :value="flight.valueId" name="InboundFlightPrice" :checked="flightGroup.id === inboundFlightSelected.id" @click="setSelectedFlight(flightGroup, 'VALUE')" />
                                                     <strong>{{calcFlightPrice(inboundFlightSelected.totalPrice, flight.priceValue, '+', '-')}} </strong>
                                                 </label>
                                                 <label v-if="flightGroup == null && flight.valueId == null && flightGroupIndex == 1" v-lang.SOLD_OUT class="no-hover">
                                                     Sold Out
                                                 </label>

                                                 <label v-if="flightGroup != null && flight.premiumId != null && flightGroup.id == flight.premiumId" class="price-count" :for="'inbound-flight-ticket-premium-' + flightIndex  + flightGroupIndex">
                                                     <input type="radio" :id="'inbound-flight-ticket-premium-' + flightIndex + flightGroupIndex" :value="flight.premiumId" name="InboundFlightPrice" :checked="flightGroup.id === inboundFlightSelected.id" @click="setSelectedFlight(flightGroup, 'FLEXI')" />
                                                     <strong>{{calcFlightPrice(inboundFlightSelected.totalPrice, flight.pricePremium, '+', '-')}}</strong>
                                                 </label>

                                                 <label v-if="flightGroup != null && flight.shuttleId != null && flight.premiumId == null && flightGroup.id == flight.shuttleId" class="price-count" :for="'inbound-flight-ticket-shuttle-' + flightIndex + flightGroupIndex">
                                                     <input type="radio" :id="'inbound-flight-ticket-shuttle-' + flightIndex + flightGroupIndex" :value="flight.shuttleId" name="InboundFlightPrice" :checked="flightGroup.id === inboundFlightSelected.id" @click="setSelectedFlight(flightGroup,'SHUTTLE')" />
                                                     <strong>{{calcFlightPrice(inboundFlightSelected.totalPrice, flight.priceShuttle, '+', '-')}}</strong>
                                                 </label>

                                                 <label v-if="flightGroup == null && flight.premiumId == null && flight.shuttleId == null && flightGroupIndex == 2" v-lang.SOLD_OUT class="no-hover">
                                                     Sold Out
                                                 </label>

                                                 <label v-if="flight.legs[0].airType != 'ATR' && flightGroup != null && flight.businessId != null && flightGroup.id == flight.businessId" class="price-count" :for="'inbound-flight-ticket-business-' + flightIndex + flightGroupIndex">
                                                     <input type="radio" :id="'inbound-flight-ticket-business-' + flightIndex + flightGroupIndex" :value="flight.businessId" name="InboundFlightPrice" :checked="flightGroup.id === inboundFlightSelected.id" @click="setSelectedFlight(flightGroup,'BUSINESS')" />
                                                     <strong>{{calcFlightPrice(inboundFlightSelected.totalPrice, flight.priceBusiness, '+', '-')}}</strong>
                                                 </label>

                                                 <label v-if="airTypeInBound =='BOEING' && flightGroup == null && flight.businessId == null && flightGroupIndex == 3" v-lang.SOLD_OUT class="no-hover">
                                                     Sold Out
                                                 </label>
                                                 <label v-if="airTypeInBound =='ATR' && flightGroup == null && flight.businessId == null && flightGroupIndex == 3" class="no-hover">
                                                     N/A
                                                 </label>
                                             </div>
                                         </template>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Flight more info-->
        <div class="modal flight-modal fade" id="flightinfo">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content clearfix">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title"><span v-lang.FROM_DESTINATION>From</span> {{flightInfoPopup.fromCityName}} <span v-lang.TO_DESTINATION>From</span> {{flightInfoPopup.toCityName}}</h4>
                    </div>
                    <div class="modal-body">
                        <div class="flight-section flight-popup" v-for="(leg, index) in flightInfoPopup.legs" :key="index">
                            <div class="flight-timeinfo">
                                <div class="flight-iconimg">
                                    <img :src="'https://gqcdn.s3.amazonaws.com/airline-logos/sm' + leg.airlineCode + '.gif'" :alt="leg.airlineCode" />
                                    <span>{{leg.airlineCode}} {{leg.flightNumber}}</span>
                                    <span>{{leg.cabinClass}}</span>
                                </div>
                                <div class="flight-timeinfo">
                                    <div class="flight-timeinfoleft">
                                        <span class="flight-time">{{leg.departureAirportCode}} - {{leg.departureDate | moment("HH:mm")}}</span>
                                        <span class="flight-date">{{leg.departureDate | moment("ddd, DD MMM")}}</span>
                                        <span class="flight-city"
                                              v-tooltip="leg.departureCityName + ', ' + leg.departureAirportName">
                                            {{leg.departureCityName}}, {{leg.departureAirportName}}
                                        </span>
                                    </div>
                                    <div class="flight-timeinfocenter">
                                        <span class="hidden-hx icon icon-right-chevron"></span>
                                    </div>
                                    <div class="flight-timeinforight">
                                        <span class="flight-time">{{leg.arrivalDate | moment("HH:mm")}} - {{leg.arrivalAirportCode}}</span>
                                        <span class="flight-date">{{leg.arrivalDate | moment("ddd, DD MMM")}}</span>
                                        <span class="flight-city"
                                              v-tooltip="leg.arrivalCityName + ',' + leg.arrivalAirportName">
                                            {{leg.arrivalCityName}}, {{leg.arrivalAirportName}}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    </div>
</template>

<script>
    export default {
        props: ["flightStore", "hotelStore", "loading"],
        data() {
            return {
                flightInfoPopup: {},
                outboundFlightSelected: null,
                inboundFlightSelected: null,
                outboundClass:'value',
                inboundClass:'value',
            };
        },
        computed: {
            packageQuery() {
                return this.$store.state.workContext.packageQuery;
            },
            outboundFlights() {
                return this.flightStore.flights.filter(function (flight) {
                    return flight.direction === 0
                });
            },
            inboundFlights() {
                if (!this.outboundFlightSelected) {
                    return [];
                }

                var self = this;
                var departureRoute = this.outboundFlightSelected.departureAirportCode + this.outboundFlightSelected.arrivalAirportCode;

                return this.flightStore.flights.filter(function (flight) {
                    if (flight.direction !== 1) {
                        return false;
                    }
                    flight.keyGroupCabinClass = flight.departureDate + "-" + flight.arrivalDate;
                    var returnRoute = flight.arrivalAirportCode + flight.departureAirportCode;
                    return departureRoute === returnRoute;
                });
            },
            outboundGroups() {
                return this.groupFlights(this.outboundFlights);
            },
            inboundGroups() {
                return this.groupFlights(this.inboundFlights);
            },
            existFlexiOut(){
                let lst = this.outboundGroups;
                  for (var i = 0; i < lst.length; i++) {
                       if (lst[i].premiumId != null ) {
                        return true;                    
                    }
                }
                return false
            },
            existShuttleOut(){
                let lst = this.outboundGroups;
                  for (var i = 0; i < lst.length; i++) {
                       if (lst[i].shuttleId != null ) {
                        return true;                    
                    }
                }
                return false
            },
            existFlexiIn(){
                let lst = this.inboundGroups;
                  for (var i = 0; i < lst.length; i++) {
                       if (lst[i].premiumId != null ) {
                        return true;                    
                    }
                }
                return false
            },
            existShuttleIn(){
                let lst = this.inboundGroups;
                  for (var i = 0; i < lst.length; i++) {
                       if (lst[i].shuttleId != null ) {
                        return true;                    
                    }
                }
                return false
            },
            airTypeOutBound(){
                let airType=this.outboundFlights[0].legs[0].airType;
                if(airType==738 || airType == 739){
                    return "BOEING"
                }
                else if(airType=="ATR"){
                    return "ATR"
                }
            },
            airTypeInBound(){
                let airType=this.inboundFlights[0].legs[0].airType;
                if(airType==738 || airType == 739){
                    return "BOEING"
                }
                else if(airType=="ATR"){
                    return "ATR"
                }
            },
            legsMin(){
                let self=this;

                let fareType = {
                    "super saver": 0,
                    value: 1,
                    flexi: 2,
                    shuttle: 3,
                    business: 4,
                }

                _.map(this.outboundFlightSelected.legs, function(item){item.order=fareType[item.cabinClass.toLowerCase()]; return item });
                _.map(this.inboundFlightSelected.legs, function(item){item.order=fareType[item.cabinClass.toLowerCase()]; return item });
              
                let legoutbound = _.reduce(this.outboundFlightSelected.legs, function(a,b){
                    return a.order < b.order?a:b;
                })
                let leginbound = _.reduce(this.inboundFlightSelected.legs, function(a,b){
                    return a.order < b.order?a:b;
                })
                return {legoutbound, leginbound}
             }
        },
        mounted() {
            $(document).on('click', '.flight-changetime .dropdown-menu', function (e) {
                e.stopPropagation();
            });
        },
        updated() {
            if (!this.outboundFlightSelected) {
                this.outboundFlightSelected = this.flightStore.outboundFlight;
            }

            if (!this.inboundFlightSelected) {
                this.inboundFlightSelected = this.flightStore.inboundFlight;
            }

            if ($('.scroll-content').length == 0) {
                $('.scrollbar-dynamic').scrollbar();
            }
        },
        methods: {
            calDaysDiff: function (start, end) {
                var d = moment("1970-01-01T00:00:00");

                var startDay = moment(start).diff(d, "days");
                var endDay = moment(end).diff(d, "days");

                return endDay - startDay;
            },
            calcFlightPrice: function (priceFlightSelected, priceFlightOther, plusSymbol, minusSymbol) {
                var price = priceFlightOther - priceFlightSelected;
                var flag = price < 0;
                if (plusSymbol == null) {
                    plusSymbol = "+";
                }
                if (minusSymbol == null) {
                    minusSymbol = "-";
                }

                price = (parseFloat(Math.abs(price)).toFixed(this.packageQuery.currencyDecimals) + "").replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');

                if (flag) {
                    return minusSymbol + " " + this.packageQuery.currency + " " + price;
                } else {
                    return plusSymbol + " " + this.packageQuery.currency + " " + price;
                }

            },
            setSelectedFlight: function (flight, type) {
                var flag = false;
                if (flight.direction === 0) {
                    if (this.outboundFlightSelected.id !== flight.id) {
                        this.outboundFlightSelected = flight;
                        this.$emit('flightChanged', flight);
                        flag = true;
                        this.outboundClass = type;
                    }
                } else {
                    if (this.inboundFlightSelected.id !== flight.id) {
                        this.inboundFlightSelected = flight;
                        this.$emit('flightChanged', flight);
                        flag = true;
                        this.inboundClass = type;
                    }
                }

                if (flag) {
                    // Update for price filter
                    var minPrice = this.hotelStore.minHotelPrice;
                    var maxPrice = this.hotelStore.maxHotelPrice;

                    if (this.outboundFlightSelected != null) {
                        minPrice += this.outboundFlightSelected.price;
                        maxPrice += this.outboundFlightSelected.price;
                    }

                    if (this.inboundFlightSelected != null) {
                        minPrice += this.inboundFlightSelected.price;
                        maxPrice += this.inboundFlightSelected.price;
                    }

                    this.hotelStore.minPrice = Math.floor(minPrice);
                    this.hotelStore.maxPrice = Math.ceil(maxPrice);
                }

                $(".flight-changetime").removeClass('open');
            },
            setFlightInfoPopup: function (flight) {
                this.flightInfoPopup = flight;
            },
            groupFlights(flights) {
                let fareType = {
                    valueCabin: '10',
                    premiumCabin: '11',
                    shuttleCabin: '12',
                    businessCabin: '2',
                    supperSaver: '28'
                }

                return  _.chain(flights).groupBy(function (x) {
                    return x.keyGroupCabinClass
                }).map(function (fGroups, grKey) {
                    return {
                        key: grKey,
                        valueId: _.get(_.find(fGroups, _.matchesProperty('cabinClass', fareType.valueCabin)), 'id'),
                        premiumId: _.get(_.find(fGroups, _.matchesProperty('cabinClass', fareType.premiumCabin)), 'id'),
                        shuttleId: _.get(_.find(fGroups, _.matchesProperty('cabinClass', fareType.shuttleCabin)), 'id'),
                        businessId: _.get(_.find(fGroups, _.matchesProperty('cabinClass', fareType.businessCabin)), 'id'),
                        supperSaverId: _.get(_.find(fGroups, _.matchesProperty('cabinClass', fareType.supperSaver)), 'id'),
                        priceValue: _.get(_.find(fGroups, _.matchesProperty('cabinClass', fareType.valueCabin)), 'totalPrice'),
                        pricePremium: _.get(_.find(fGroups, _.matchesProperty('cabinClass', fareType.premiumCabin)), 'totalPrice'),
                        priceShuttle: _.get(_.find(fGroups, _.matchesProperty('cabinClass', fareType.shuttleCabin)), 'totalPrice'),
                        pricesupperSaver: _.get(_.find(fGroups, _.matchesProperty('cabinClass', fareType.supperSaver)), 'totalPrice'),
                        priceBusiness: _.get(_.find(fGroups, _.matchesProperty('cabinClass', fareType.businessCabin)), 'totalPrice'),
                        departureDate: _.get(_.find(fGroups, 'departureDate'), 'departureDate'),
                        arrivalDate: _.get(_.find(fGroups, 'arrivalDate'), 'arrivalDate'),
                        legs: _.get(_.find(fGroups, 'legs'), 'legs'),
                        defaultChecked: "Value Peach",
                        flightGroups: fGroups,
                        stops: _.get(_.find(fGroups, function (x) { return x }), 'stops'),
                        cabinClass: _.get(_.find(fGroups, 'cabinClass'), 'cabinClass')
                    }
                    }).value();  
                            
            },
            getTransistionTime(depTime, arTime) {
                let subtractDate = moment.utc(arTime) - moment.utc(depTime),
                    tempTime = moment.duration(subtractDate),
                    hour = tempTime.hours() + "h",
                    minute = tempTime.minutes() + "m";
                return hour + " " + minute;
            },
            checkFlightStopover(flightNumberDep, flightNumberAr) {
                if (flightNumberDep == flightNumberAr) {
                    return true;
                }
                else {
                    return false;
                }
            },
            getDurationTime(duration) {
                if (duration > 0) {
                    hours = Math.floor(duration / 60);
                    minutes = duration - (hours * 60);
                    return hours + 'h ' + minutes + 'm';
                }
                else {
                    // var departureDate  = moment(new Date(flight.departureDate));
                    // var arrivalDate  = moment(new Date(flight.arrivalDate));
                    //
                    // var flightTime = moment.duration(arrivalDate.diff(departureDate));
                    // hours = flightTime.hours();
                    // minutes = flightTime.minutes();
                    return ' ';
                }
            },
            checkFlightGroups(flightGroups, flight) {
                var newFlightGroups = [null, null, null, null];               
              
                // if (flightGroups.length != 3) {
                flightGroups.sort(function (a, b) {
                    return parseFloat(a.totalPrice) - parseFloat(b.totalPrice);
                });
                
                for (var i = flightGroups.length - 1; i >= 0; i--) {               
                    switch(flightGroups[i].cabinClass){
                        case 28:
                        case '28':
                            newFlightGroups[0] = flightGroups[i];
                        break;
                        case 10:
                        case '10':
                            newFlightGroups[1] = flightGroups[i];
                        break;
                        case 11:
                        case 12:
                        case '11':
                        case '12':
                            newFlightGroups[2] = flightGroups[i];
                        break;
                        case 2:
                        case '2':
                            newFlightGroups[3] = flightGroups[i];
                        break;
                    }
                }               
                return newFlightGroups;             
            },
            checkTransistionTime(legIndex, legs) {
                if (legIndex > 0 && legs[legIndex - 1] != null) {
                    return true;
                }
                return false;
            },
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            },
            translateTextBaggage(type, typeClass, defaultText) {
               
                let self = this;
                let texts = ["FLIGHT_BAGGAGE0", "FLIGHT_BAGGAGE15","FLIGHT_BAGGAGE30","","FLIGHT_BAGGAGE40"]
                //chec with ATR
                let airtype = type=='OUTBOUND'? this.airTypeOutBound:this.airTypeInBound;
              

                // check from adc or to adc
                if(self.packageQuery.from =="DAC"|| self.packageQuery.to == "DAC"){
                    if(typeClass=='VALUE' || typeClass== 'FLEXI' ){
                        return self.translateText("FLIGHT_BAGGAGE35") || defaultText;
                    }
                    else if(typeClass == 'BUSINESS'){
                        return self.translateText("FLIGHT_BAGGAGE40") || defaultText;
                    }
                }
                switch (typeClass) {
                    case "VALUE":
                        if (type == 'OUTBOUND' && self.outboundClass == 'VALUE' && self.outboundFlightSelected.legs.length > 0) {
                            return self.translateText(texts[self.legsMin.legoutbound.order]) || defaultText;
                        }
                        if (type == 'INBOUND' && self.outboundClass == 'VALUE' && self.inboundFlightSelected.legs.length > 0) {                          
                            return self.translateText(texts[self.legsMin.leginbound.order]) || defaultText;
                        }
                        return self.translateText("FLIGHT_BAGGAGE15") || defaultText;                      
                    case "FLEXI":
                        if(type=='OUTBOUND' && self.outboundClass=='FLEXI' && self.outboundFlightSelected.legs.length>0){
                            return self.translateText(texts[self.legsMin.legoutbound.order]) || defaultText;
                        }
                        if(type=='INBOUND' && self.inboundClass=='FLEXI' && self.inboundFlightSelected.legs.length>0){                          
                            return self.translateText(texts[self.legsMin.leginbound.order]) || defaultText;
                        }
                        
                        return self.translateText( "FLIGHT_BAGGAGE30") || defaultText;                       
                    case "BUSINESS":
                        if(type=='OUTBOUND' && self.outboundClass=='BUSINESS' && self.outboundFlightSelected.legs.length>0){
                            return self.translateText(texts[self.legsMin.legoutbound.order]) || defaultText;
                        }
                        if(type=='INBOUND' && self.inboundClass=='BUSINESS' && self.inboundFlightSelected.legs.length>0){
                            return self.translateText(texts[self.legsMin.leginbound.order]) || defaultText;
                        }
                        return self.translateText("FLIGHT_BAGGAGE40") || defaultText; 
                    case "SHUTTLE":
                        return self.translateText("FLIGHT_BAGGAGE20") || defaultText; 

                }
            },
            checkPremiumOrShuttle(flight, cabinClass) {
                for (var i = 0; i < flight.length; i++) {
                    if (flight[i].shuttleId != null && cabinClass == 'shuttle') {
                        return true;
                    }
                    if (flight[i].premiumId != null && cabinClass == 'flexi') {
                        return true;
                    }
                    if (cabinClass == 'Economy SupperSaver') {
                        return true;
                    }
                }
            },
            checkOutboundDiffrenceDate(departureDateLeg, flightLegs, legIndex) {
                var result = '';
                if (legIndex > 0) {
                    var ddLeg = new Date(departureDateLeg);
                    ddLeg.setHours(0, 0, 0, 0);
                    var adLeg = new Date(flightLegs[legIndex - 1].arrivalDate);
                    adLeg.setHours(0, 0, 0, 0);
                    if (ddLeg.getDay() == adLeg.getDay()) {
                        result = '';
                    }
                    else {
                        if (ddLeg > adLeg) {
                            result = '(+1)';
                        }
                        else {
                            result = '(-1)';
                        }
                    }
                }
                return result;
            },
            checkInboundDiffrenceDate(departureDateLeg, arrivalDateLeg) {
                var result = '';
                var ddLeg = new Date(departureDateLeg);
                ddLeg.setHours(0, 0, 0, 0);
                var adLeg = new Date(arrivalDateLeg);
                adLeg.setHours(0, 0, 0, 0);

                if (ddLeg.getDay() == adLeg.getDay()) {
                    result = '';
                }
                else {
                    if (ddLeg < adLeg) {
                        result = '(+1)';
                    }
                    else {
                        result = '(-1)';
                    }
                }
                return result;
            }
        }
    }

</script>