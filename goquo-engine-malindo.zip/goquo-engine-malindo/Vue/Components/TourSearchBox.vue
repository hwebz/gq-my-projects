﻿<template>
    <div class="tour-search">
        <h2 v-lang.SEARCH_FOR_ACTIVITY>Search for Activities</h2>

        <form method="GET" action="/package/start-search" data-val="true">
            <div class="input-daterange">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group form-group-icon-left">
                            <i class="icon input-icon icon icon-map-marker"></i>
                            <label v-lang.Destination>Destination</label>
                            <ajax-select id="To" name="To" :placeholder="translateText('CHOOSE_A_CITY','Choose a city...')" :url="'/api/get-cities'"></ajax-select>
                            <input type="hidden" name="To" value="packageQuery.to" />
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group form-group-icon-left">
                            <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                            <label v-lang.START_DATE>Start Date</label>
                            <date-picker name="DepartureDate" v-model="DepartureDate"></date-picker>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group form-group-icon-left">
                            <i class="icon icon-calendar input-icon input-icon-highlight"></i>
                            <label v-lang.END_DATE>End Date</label>
                            <date-picker name="ReturnDate" :startDate="DepartureDate" :addOneDay="1" autoFocus="true"></date-picker>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group form-group-icon-left">
                            <i class="icon icon-user input-icon input-icon-highlight extra-right"></i>
                            <label v-lang.PAX_INFO>Pax Info</label>
                            <pax-selector :maxRooms="maxRooms" tour="true"></pax-selector>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <!--<div class="col-md-6">
                        <div class="form-group form-group-icon-left">
                            <i class="icon icon-money input-icon input-icon-highlight"></i>
                            <label v-lang.CURRENCY>Currency</label>
                            <select-currency name="Currency" url="/api/get-currencies" placeholder="Select your currency"></select-currency>
                        </div>
                    </div>-->
                    <div class="col-md-12">
                        <label>&nbsp;</label>
                        <div class="pull-right">
                            <input type="hidden" name="ProductId" :value="product.id" />
                            <input type="hidden" name="CultureCode" value="en-US" />
                            <input type="hidden" :value="paxCount" id="totalPax" />
                            <button type="submit" id="searchForm" class="btn btn-primary" v-lang.SEARCH_FOR_ACTIVITY>Search for Activities</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</template>

<script>
    import { mapState } from 'vuex'
    import {AjaxSelect, DatePicker, PaxSelector} from 'goquo-components'
    import SelectCurrency from './SelectCurrency.vue'
    export default {
        data() {
            return {
                maxRooms: 1,
                paxCount: 0,
                DepartureDate: null,
                ReturnDate: null
            }
        },
        computed: {
            packageQuery: state => state.workContext,
        },
        methods: {
            translateText(translateKey, defaultText) {
                return this.translate(this.$language, translateKey) || defaultText;
            }
        },
        props: ['product'],
        components: {
            'ajax-select': AjaxSelect,
            'date-picker': DatePicker,
            'pax-selector': PaxSelector,
            'select-currency': SelectCurrency
        }
    }

</script>