Malindo Air client project
--------------------------

*To be updated*