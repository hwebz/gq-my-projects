﻿using System.Net;
using System.Threading.Tasks;
using GoQuoEngine.Client;
using GoQuoEngine.Client.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace Malindo.Controllers
{
    public class HomeController : Controller
    {
        private readonly IClientEngine clientEngine;
        private readonly IOptions<AppSettings> appSettingsAccessor;

        public HomeController(IClientEngine clientEngine, IOptions<AppSettings> appSettingsAccessor)
        {
            this.clientEngine = clientEngine;
            this.appSettingsAccessor = appSettingsAccessor;
        }

        public async Task<IActionResult> Index()
        {
            var siteInfo = await clientEngine.GetSiteInfo();
            if (appSettingsAccessor.Value.RedirectToCms && !string.IsNullOrEmpty(siteInfo.Url))
            {
                return Redirect(siteInfo.Url);
            }
            return View();
        }

        [Route("error/{status?}")]
        public IActionResult Error(int? status)
        {
            if (status == 404)
            {
                HttpContext.Response.StatusCode = (int) HttpStatusCode.NotFound;
                return View("NotFound");
            }

            HttpContext.Response.StatusCode = (int) HttpStatusCode.InternalServerError;
            return View();
        }

        [Route("admin")]
        public IActionResult Admin()
        {
            return Redirect(appSettingsAccessor.Value.DashboardUrl);
        }

        [Route("hotel")]
        public IActionResult Hotel()
        {
            return View("Separated");
        }

        [Route("flight-hotel")]
        public IActionResult FlightHotel()
        {
            return View("Separated");
        }
    }
}
