﻿using System;
using System.Threading.Tasks;
using GoQuoEngine.Client.Controllers;
using GoQuoEngine.Client.Data.Domain;
using GoQuoEngine.Client.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;

namespace Malindo.Controllers
{
    [Route("booking")]
    public class BookingController : BaseAgentBookingController
    {
        private readonly IAgentBookingService agentAccountService;
        private readonly IClientEngine clientEngine;
        private readonly IStringLocalizer<BaseBookingController> localizer;

        public BookingController(IClientEngine clientEngine, IStringLocalizer<BaseBookingController> localizer, IAgentBookingService agentAccountService) : base(clientEngine, localizer, agentAccountService)
        {
            this.agentAccountService = agentAccountService;
            this.clientEngine = clientEngine;
            this.localizer = localizer;
        }

        public override async Task<IActionResult> GetWorkContext(Guid packageId)
        {
            var workContext = await base.GetWorkContext(packageId);

            if (!agentAccountService.IsAgentLogged) return workContext;

            var agentInfo = await agentAccountService.GetAgentInfo();

            if (agentInfo == null) return workContext;

            var jsonWorkContext = (JsonResult) workContext;
            var model = (dynamic) jsonWorkContext.Value;

            var personalDetail = new BookingPassengerInfo
            {
                Title = "Mr",
                AddressLine1 = agentInfo.AgentCode,
                City = agentInfo.City,
                PostCode = agentInfo.PostCode,
                EmailAddress = agentInfo.EmailAddress,
                CountryCode = agentInfo.CountryCode,
                MobileNumber = agentInfo.TelephoneNo.Split("-").Length == 1 ? agentInfo.TelephoneNo : agentInfo.TelephoneNo.Split("-")[1]
            };

            model.personalDetails = personalDetail;
            model.agent = "B2B";

            return Json(model);
        }
    }
}
