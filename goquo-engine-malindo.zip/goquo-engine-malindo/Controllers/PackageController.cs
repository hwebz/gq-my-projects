﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GoQuoEngine.Client;
using GoQuoEngine.Client.Controllers;
using GoQuoEngine.Client.Data.Domain;
using GoQuoEngine.Client.Data.Flights;
using GoQuoEngine.Client.Models;
using GoQuoEngine.Client.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Http;

namespace Malindo.Controllers
{
    [Route("package")]
    public class PackageController : BaseAgentPackageController
    {
        private readonly IClientEngine clientEngine;
        private readonly IStringLocalizer<BasePackageController> localizer;

        public PackageController(IClientEngine clientEngine, IOptions<AppSettings> appSettings,
            IStringLocalizer<BasePackageController> localizer, IAgentBookingService agentBookingService) : base(clientEngine, appSettings, localizer, agentBookingService)
        {
            this.clientEngine = clientEngine;
            this.localizer = localizer;
        }

        [Route("get-flights")]
        public override async Task<IActionResult> GetFlights(QueryFlightModel request)
        {
            var flights = (await clientEngine.GetFlights(request.PackageId)).ToList();

            if (flights.Count > 0)
            {
                var packageQuery = await clientEngine.GetPackageQuery(request.PackageId);
                var from = packageQuery.From;
                var to = packageQuery.To;

                // Remove flights return airport no same with depart airport
                flights.RemoveAll(x =>
                {
                    if (x.Direction == Direction.OutBound)
                    {
                        return x.DepartureAirportCode != from || x.ArrivalAirportCode != to;
                    }

                    return x.DepartureAirportCode != to || x.ArrivalAirportCode != from;
                });

                // Check must be have outbound + inbound flights
                if (flights.All(x => x.Direction != Direction.OutBound))
                {
                    flights = new List<FlightResponse>();
                }

                if (packageQuery.JourneyType != JourneyType.OneWay)
                {
                    if (flights.All(x => x.Direction != Direction.InBound))
                    {
                        flights = new List<FlightResponse>();
                    }
                }

                // Sort flights
                flights = flights.OrderBy(x => x.DepartureDate).ThenBy(x => x.Price).ToList();
            }

            return Json(new
            {
                Flights = flights,
                TotalFlights = flights.Count,
                ErrorMessage = flights.Count == 0
                    ? localizer[Constants.LocalizedStrings.FlightsNotAvailable].ToString()
                    : null
            });
        }

        [Route("search")]
        public override async Task<IActionResult> Search(RequestInfo model)
        {
            string cookieValueFromContext = HttpContext.Request.Cookies["isApp"];

            var isApp = Convert.ToString(Request.Query["isApp"]);
            if (isApp == "1" && cookieValueFromContext != "1")
            {

                SetCookie("isApp", "1", 4);
            }

            return await base.Search(model);
        }

        public override async Task<IActionResult> SearchTransfer(RequestInfo model)
        {
            await PrepareSearchTransferModel(model);

            return await base.SearchTransfer(model);
        }

        private async Task PrepareSearchTransferModel(RequestInfo model)
        {
            if (!string.IsNullOrEmpty(model.TransferSearchInfo?.RegionId))
            {
                var type = model.TransferSearchInfo.RegionId[0];
                switch (char.ToUpper(type))
                {
                    case 'H':
                        var hotelId = model.TransferSearchInfo.RegionId.Substring(2);
                        var hotelInfo = await clientEngine.GetHotelInfo(new HotelInfoRequest
                        {
                            CultureCode = GetCultureCode(),
                            HotelId = hotelId,
                            CityCode = model.To
                        });
                        model.TransferSearchInfo.AccommodationGeoCoords = hotelInfo.Latitude + "," + hotelInfo.Longitude;
                        break;
                    case 'R':
                        var regionId = Convert.ToInt64(model.TransferSearchInfo.RegionId.Substring(2));
                        var regionDetail = (await clientEngine.GetRegionInfo(GetCultureCode(), new long[] { regionId })).FirstOrDefault();
                        model.TransferSearchInfo.AccommodationGeoCoords = regionDetail.CenterLatitude + "," + regionDetail.CenterLatitude;
                        break;
                }
            }
        }

        private void SetCookie(string key, string value, int? expireTime)
        {
            CookieOptions option = new CookieOptions();

            if (expireTime.HasValue)
                option.Expires = DateTime.Now.AddHours(expireTime.Value);
            else
                option.Expires = DateTime.Now.AddHours(4);

            Response.Cookies.Append(key, value, option);
        }

        public override async Task<IActionResult> StartSearch(RequestInfo model)
        {
            await PrepareSearchTransferModel(model);
            return await base.StartSearch(model);
        }
    }
}
