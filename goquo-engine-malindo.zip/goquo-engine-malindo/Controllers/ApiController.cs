﻿using System;
using System.Threading.Tasks;
using GoQuoEngine.Client.Caching;
using GoQuoEngine.Client.Controllers;
using GoQuoEngine.Client.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Malindo.Controllers
{
    public class ApiController : BaseApiController
    {
        public ApiController(IClientEngine clientEngine, ILogger<ApiController> logger) : base(clientEngine, logger)
        {
        }

        [Route("test-timeout/{seconds}")]
        public async Task<IActionResult> TestTimeout(int seconds)
        {
            await Task.Delay(seconds * 1000);
            return Content($"Ok with timeout: {seconds} seconds.");
        }

        protected override async Task<IActionResult> ClearAllCaches()
        {
            await Task.CompletedTask;

            try
            {
                var distributedCache = HttpContext.RequestServices.GetService<IDistributedCache>() as RedisHybridDistributedCache;

                if (distributedCache != null)
                {
                    distributedCache.Clear();
                    return Content("ok");
                }
                else
                {
                    return Content("Not supported yet.");
                }
            }
            catch (Exception ex)
            {
                return Content(ex.Message);
            }
        }
    }
}
