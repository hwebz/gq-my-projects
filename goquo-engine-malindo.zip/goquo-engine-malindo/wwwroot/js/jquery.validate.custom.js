﻿// http://jqueryvalidation.org/creditcard-method/
// based on http://en.wikipedia.org/wiki/Luhn_algorithm


$.validator.addMethod("creditcard", function (value, element) {

    if (this.optional(element)) {
        return "dependency-mismatch";
    }

    // Accept only spaces, digits and dashes
    if (/[^0-9 \-]+/.test(value)) {
        return false;
    }

    var nCheck = 0,
        nDigit = 0,
        bEven = false,
        n, cDigit;

    value = value.replace(/\D/g, "");
    //value = value.replace(/\W/gi, '').replace(/(.{4})/g, '$1 ');
    // Basing min and max length on
    // http://developer.ean.com/general_info/Valid_Credit_Card_Types
    if (value.length < 13 || value.length > 19) {
        return false;
    }

    for (n = value.length - 1; n >= 0; n--) {
        cDigit = value.charAt(n);
        nDigit = parseInt(cDigit, 10);
        if (bEven) {
            if ((nDigit *= 2) > 9) {
                nDigit -= 9;
            }
        }

        nCheck += nDigit;
        bEven = !bEven;
    }

    return (nCheck % 10) === 0;
}, "Please enter a valid credit card number.");

//var checkMonth = false;
//Credit Card Expiration Year
$.validator.addMethod('ccexp', function (value, element) {

    //Get current month and year
    var minMonth = new Date().getMonth() + 1;
    var minYear = new Date().getFullYear();

    //Getting value from payemnt section
    var month = parseInt($("#txtCreditCardExpireMonth").val());
    var year = parseInt(value);

    //Checking the card expiration date
    //checkMonth = true;
    return (year > minYear || (year === minYear && month >= minMonth));
}, 'Your Credit Card Expiration date is invalid.');

//Credit Card Expiration month
//$.validator.addMethod('ccexpmonth', function (value, element) {
//    if (checkMonth) {
//        console.log("value:" + value)
//        console.log(jQuery.validator.methods.required.call(this, value, element));
//        return jQuery.validator.methods.required.call(this, value, element);
//    }
//    return true;
//},"test");




(function ($) {
    $.validator.setDefaults({
        ignore: ":hidden:not([must-validate])",
        highlight: function (element, errorClass, validClass) {
            $(element).addClass(errorClass);
        },
        unhighlight: function (element, errorClass, validClass) {
            $(element).removeClass(errorClass);
        }
    });

    $(document).on('change', '.date-selector select', function () {
        var index = $(this).data('index');
        var minDate = moment($(this).data('val-daterange-mindate'), "YYYY-MM-DDTHH:mm:ssZ");
        var maxDate = moment($(this).data('val-daterange-maxdate'), "YYYY-MM-DDTHH:mm:ssZ");

        var day = $('[name="Passengers[' + index + '].DayOfBirth"]').val();
        var month = $('[name="Passengers[' + index + '].MonthOfBirth"]').val();
        var year = $('[name="Passengers[' + index + '].YearOfBirth"]').val();

        if (day && month && year) {
            var strDate = year + "-" + month + "-" + day + "T00:00:00Z";
            var date = moment(strDate, "YYYY-MM-DDTHH:mm:ssZ");

            if (date > minDate && date <= maxDate) {
                $('span[data-valmsg-for="Passengers[' + index + '].Dob"]').removeClass('field-validation-error');
                $('span[data-valmsg-for="Passengers[' + index + '].Dob"]').empty();
            } else {
                $('[name="Passengers[' + index + '].Dob"]').valid();
            }
        }
 
    });

    $.validator.addMethod("daterange", function (value, element, params) {
        var index = $(element).attr('data-index');
        var minDate = moment(params.mindate, "YYYY-MM-DDTHH:mm:ssZ");
        var maxDate = moment(params.maxdate, "YYYY-MM-DDTHH:mm:ssZ");
        var day = $('[name="Passengers[' + index + '].DayOfBirth"]').val();
        var month = $('[name="Passengers[' + index + '].MonthOfBirth"]').val();
        var year = $('[name="Passengers[' + index + '].YearOfBirth"]').val();
        if (day && month && year) {
         
            var strDate = year + "-" + month + "-" + day + "T00:00:00Z";
            var date = moment(strDate, "YYYY-MM-DDTHH:mm:ssZ");
            if (date > minDate && date <= maxDate) {
                $('span[data-valmsg-for="Passengers[' + index + '].Dob"]').removeClass('field-validation-error');
                $('span[data-valmsg-for="Passengers[' + index + '].Dob"]').empty();
             
                return true;
            } else {
                if ($('.field-validation-error').length > 0) {
                    $("html, body").animate({ scrollTop: ($('.field-validation-error').offset().top - 300) }, 800);
                }
                return false;
            }
        } else if (day == "" || month == "" || year == "") {
            return false;
        }
        return false;
    });

    $.validator.unobtrusive.adapters.add("daterange", ["mindate", "maxdate"], function (options) {
        options.rules["daterange"] = options.params;
        options.messages["daterange"] = options.message;
    });
})(jQuery);
