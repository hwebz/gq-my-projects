
//Filter slider 
$(document).on('click', '.filter-active', function () {
    $('.filter-body').toggleClass("is-open");
});

//Pax Dropdown
$(document).on('click', '.closeDropdown', function () {
    $(".is-custom-dropdown").removeClass("show");
    $(".is-custom-dropdown").addClass("hide");
});


$(document).on('click', '[data-target="addroompax"]', function () {
    $(".is-custom-dropdown").addClass("show");
    return false;
});

$(document).on('click', function (event) {
    if (!$(event.target).closest(".is-custom-dropdown").length) {
        var className = $(event.target).attr("class");
        if (className != "label label-primary remove-room pull-right") {
            $(".is-custom-dropdown").removeClass("show");
        }
    }
});

//Sidbar Smoothscroll 
$(document).ready(function () {

    //smoothscroll
    $('.js-scroll').on('click', '.js-click', function (e) {
        e.preventDefault();
        $(this).addClass('active');
        var target = this.hash,
            menu = target;
        $target = $(target);
        $('html, body').animate({
            scrollTop: $target.offset().top - 50
        }, 'slow');
    });
});

//Scroll show price sticky in mobile view
$(document).scroll(function () {
    var y = $(this).scrollTop();
    if (y > 110) {
        $('.sticky').addClass('is-shown');
    } else {
        $('.sticky').removeClass('is-shown');
    }
}); 